package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by achakraborty on 3/16/2017.
 */
public class AddComment extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);

        String desc = "";
        String type = "";
        String testcode = "";
        String resultComment = "";
        String addNewComment = "N";
        String successfulAdd = "N";

        try {
            desc = ajaxResponse.getRequestParameter("desc", "");
            type = ajaxResponse.getRequestParameter("type", "");
            testcode = ajaxResponse.getRequestParameter("testcode", "");
            String tempDesc=desc;

            String sql = "";

            if ("Global".equalsIgnoreCase(type)) {
                //sql = "select notes from u_globalcomment where notes in('" + StringUtil.replaceAll(desc, ";", "','") + "')";
                tempDesc = tempDesc.replaceAll("\\r\\n", "@*@");
                tempDesc = tempDesc.replaceAll("\\r", "@*@");
                tempDesc = tempDesc.replaceAll("\\n", "@*@");
                tempDesc = tempDesc.replaceAll(" ", "@*@");

                sql = "select notes from u_globalcomment " +
                        "where REPLACE(REPLACE( notes, CHR(10), '@*@' ),' ','@*@') in('" + StringUtil.replaceAll(tempDesc, ";", "','") + "')";

            }else if ("Local".equalsIgnoreCase(type))
                sql = "select notes from u_ngcomment where linkkeyid1 in('" + StringUtil.replaceAll(testcode, ";", "','") + "')";

            DataSet dsCommentInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsCommentInfo == null)
                throw new SapphireException("Dataset is obtained as null. Please check the database connection.");

            if (dsCommentInfo.size() == 0) {
                resultComment = desc;
            } else {
                String descArr[] = StringUtil.split(desc, ";");
                if (descArr == null || descArr.length == 0)
                    throw new SapphireException("Comment Array object is obtained as null");
                HashMap<String,String> hmap = new HashMap<String,String>();
                for (int i = 0; i < descArr.length; i++) {
                    hmap.clear();
                    hmap.put("notes", descArr[i]);
                    DataSet dsFiltr = dsCommentInfo.getFilteredDataSet(hmap);
                    if (dsFiltr == null || dsFiltr.size() == 0) {
                        resultComment += ";" + descArr[i];
                    }
                }
            }

            if(!Util.isNull(resultComment)) {
                addNewComment="Y";
                if(resultComment.startsWith(";"))
                    resultComment = resultComment.substring(1);
                String resultCommentArr[]=StringUtil.split(resultComment,";");
                if(resultCommentArr!=null && resultCommentArr.length>0) {
                    PropertyList prop = new PropertyList();
                    if("Global".equalsIgnoreCase(type))
                        prop.setProperty(AddSDI.PROPERTY_SDCID, "GlobalComment");
                    else if("Local".equalsIgnoreCase(type)) {
                        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGComment");
                        prop.setProperty("linkkeyid1", testcode);
                        prop.setProperty("linksdcid", "testcode");
                    }
                    prop.setProperty("notes", resultComment);
                    prop.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(resultCommentArr.length));
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                    successfulAdd = "Y";
                }
            }

        }

        catch (Exception exp){
            ajaxResponse.setError(exp.getMessage());
        }
        finally {
            ajaxResponse.addCallbackArgument("notes", desc);
            ajaxResponse.addCallbackArgument("addNewComment", addNewComment);
            ajaxResponse.addCallbackArgument("successfuladd", successfulAdd);
            ajaxResponse.print();
        }
    }
}