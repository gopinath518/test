package sapphire.custom.ng.ajax;

import com.labvantage.sapphire.actions.sms.CreateStorageUnit;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * This Action is use to create extraction batch based on extraction type and
 * load the tubes in respective defined boxes . Created by mpandey on 7/4/2016.
 */

public class CreateNLoadElusionBatch extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                               ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String batchid = "";
        String vempmsg = "";
        try {
            if (ajaxResponse == null) {
                throw new SapphireException("AjaxResponse is obtained as null");
            }
            //TODO WILL CREATE MULTIPLE BATCH AT A TIME
            PropertyList prop = getActionProp(ajaxResponse);
            getActionProcessor().processAction("CreateNLoadElusionBatch", "1", prop);
            batchid = prop.getProperty("batchid");
            vempmsg = prop.getProperty("url");
            /*String exttube = ajaxResponse.getRequestParameter("exttube", "");
            String type = ajaxResponse.getRequestParameter("type", "");// type added to find out from which page elution tube is creating.
            String manualextraction = ajaxResponse.getRequestParameter("manualextraction", "");
            String volume = ajaxResponse.getRequestParameter("volume", "");
            String units = ajaxResponse.getRequestParameter("units", "");
            String comments = ajaxResponse.getRequestParameter("comments", "");// TODO ask Lito where to update this comments
            String reagent = ajaxResponse.getRequestParameter("reagent", ""); // TODO Validate reagent lot existance
            String instrument = ajaxResponse.getRequestParameter("instrument", "");// TODO validate instrument id
            String extractiontype = ajaxResponse.getRequestParameter("extractiontype", "");
            String fromtramstop = ajaxResponse.getRequestParameter("fromtramstop", "");

            if (Util.isNull(exttube)) {
                String errMsg = "";
                if ("Extraction".equalsIgnoreCase(fromtramstop)) {
                    errMsg = "Please scan some extraction tube(s) to create a batch.";
                } else {
                    errMsg = "Please scan some elution tube(s) to create a batch.";
                }
                throw new SapphireException(errMsg);
            }

            if (Util.isNull(exttube)) {
                String errMsg = "";
                if ("Extraction".equalsIgnoreCase(fromtramstop)) {
                    errMsg = "Please scan some extraction tube(s) to create a batch.";
                } else {
                    errMsg = "Please scan some elution tube(s) to create a batch.";
                }
                throw new SapphireException(errMsg);
            }

            *//*if (!"TNA".equalsIgnoreCase(extractiontype)) {
                extractiontype = getExtractionType(exttube);
            }*//*
            String arryCmmnts[] = null;
            if ("NONFFPE".equalsIgnoreCase(type) && "TNA".equalsIgnoreCase(extractiontype)) {
                arryCmmnts = StringUtil.split(comments, ";");
            }
            String sql = Util.parseMessage(MolecularSql.GET_SAMPLENON_FFPE_EXT, StringUtil.replaceAll(exttube, ";", "','"));
            DataSet dsExtractionTubeInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsExtractionTubeInfo.size() == 0) {
                throw new ServletException("No active test found for the tube.");
            }

            for (int i = 0; i < dsExtractionTubeInfo.size(); i++) {
                String tubeid = dsExtractionTubeInfo.getValue(i, "s_sampleid", "");
                String tubeextractiontype = dsExtractionTubeInfo.getValue(i, "extractiontype", "");
                String cmmnts = "";
                if (arryCmmnts != null) {
                    cmmnts = arryCmmnts[i];
                }
                PropertyList inputProp = new PropertyList();
                inputProp.setProperty("exttube", tubeid);
                inputProp.setProperty("type", type);
                inputProp.setProperty("manualextraction", manualextraction);
                inputProp.setProperty("volume", "");
                inputProp.setProperty("units", "");
                inputProp.setProperty("comments", cmmnts);
                inputProp.setProperty("reagent", reagent);
                inputProp.setProperty("instrument", instrument);
                inputProp.setProperty("extractiontype", extractiontype);
                //inputProp.setProperty("extractiontype", tubeextractiontype);
                inputProp.setProperty("fromtramstop", fromtramstop);
                getActionProcessor().processAction("CreateNLoadElusionBatch", "1", inputProp);
                batchid += ";" + inputProp.getProperty("batchid");
                vempmsg += ";" + inputProp.getProperty("url");
            }
            if (batchid.startsWith(";"))
                batchid = batchid.substring(1);
            if (vempmsg.startsWith(";"))
                vempmsg = vempmsg.substring(1);*/
        } catch (Exception exp) {
            logger.debug(exp.getMessage());
            ajaxResponse.setError(exp.getMessage());
        } finally {
            if (ajaxResponse != null) {
                if (batchid.length() > 0) {
                    ajaxResponse.addCallbackArgument("batchid", batchid);
                    ajaxResponse.addCallbackArgument("url", vempmsg);
                } else {
                    ajaxResponse.addCallbackArgument("batchid", batchid);
                    ajaxResponse.addCallbackArgument("url", vempmsg);
                }
                ajaxResponse.print();
            }
        }
    }

    private PropertyList getActionProp(AjaxResponse ajaxResponse) throws SapphireException {
        String exttube = ajaxResponse.getRequestParameter("exttube", "");
        String type = ajaxResponse.getRequestParameter("type", "");// type added to find out from which page elution tube is creating.
        String manualextraction = ajaxResponse.getRequestParameter("manualextraction", "");
        String volume = ajaxResponse.getRequestParameter("volume", "");
        String units = ajaxResponse.getRequestParameter("units", "");
        String comments = ajaxResponse.getRequestParameter("comments", "");// TODO ask Lito where to update this comments
        String reagent = ajaxResponse.getRequestParameter("reagent", ""); // TODO Validate reagent lot existance
        String instrument = ajaxResponse.getRequestParameter("instrument", "");// TODO validate instrument id
        String extractiontype = ajaxResponse.getRequestParameter("extractiontype", "");
        String fromtramstop = ajaxResponse.getRequestParameter("fromtramstop", "");

        if (Util.isNull(exttube)) {
            String errMsg = "";
            if ("Extraction".equalsIgnoreCase(fromtramstop)) {
                errMsg = "Please scan some extraction tube(s) to create a batch.";
            } else {
                errMsg = "Please scan some elution tube(s) to create a batch.";
            }
            throw new SapphireException(errMsg);
        }

        if (Util.isNull(extractiontype)) {
            extractiontype = getExtractionType(exttube);
        }

        PropertyList inputProp = new PropertyList();
        inputProp.setProperty("exttube", exttube);
        inputProp.setProperty("type", type);
        inputProp.setProperty("manualextraction", manualextraction);
        inputProp.setProperty("volume", volume);
        inputProp.setProperty("units", units);
        inputProp.setProperty("comments", comments);
        inputProp.setProperty("reagent", reagent);
        inputProp.setProperty("instrument", instrument);
        inputProp.setProperty("extractiontype", extractiontype);
        inputProp.setProperty("fromtramstop", fromtramstop);

        return inputProp;

    }

    private String getExtractionType(String exttube) throws SapphireException {

        String sql = "select extractiontype from u_sampletestcodemap where s_sampleid in ('"
                + exttube.replaceAll(";", "','") + "')";
        DataSet dsext = getQueryProcessor().getSqlDataSet(sql);
        if (dsext == null || dsext.size() == 0) {
            throw new SapphireException("Extraction type not found for samples");
        }
        exttube = dsext.getColumnValues("extractiontype", ";");
        exttube = Util.getUniqueList(exttube, ";", true);

        return exttube;
    }
}