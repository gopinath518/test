package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CheckMicrotomySpecimen extends BaseAjaxRequest {

    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String scanblock = ajaxResponse.getRequestParameter("sampleid");
        DataSet dsSlides = hasSectionedCheckBlock(scanblock);
        ajaxResponse.addCallbackArgument("microtomyblock", scanblock);
        ajaxResponse.addCallbackArgument("dataset", dsSlides);
        ajaxResponse.print();
    }

    private DataSet hasSectionedCheckBlock(String sampleid) {
        String sql = "select destsampleid from s_samplemap where sourcesampleid='" + sampleid + "'";
        DataSet dsSlides = getQueryProcessor().getSqlDataSet(sql);
        if (dsSlides != null && dsSlides.size() > 0) {
            return dsSlides;
        }
        return dsSlides;
    }
}
