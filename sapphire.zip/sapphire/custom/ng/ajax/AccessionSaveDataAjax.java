package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DBAccess;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by SBaitalik on 1/5/2017.
 */
public class AccessionSaveDataAjax extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String tabletype = ajaxResponse.getRequestParameter("tabletype", "");
        String accessionid = ajaxResponse.getRequestParameter("accessionid", "");
        if ("clientinfotable".equalsIgnoreCase(tabletype)) {
            String clientid = ajaxResponse.getRequestParameter("clientid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("clientid", clientid);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("clearallselectsponsor".equalsIgnoreCase(tabletype)) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            //prop.setProperty("patientid", "(null)");
            prop.setProperty("bioprojectname", "(null)");
            prop.setProperty("biositeid", "(null)");
            prop.setProperty("biovisitname", "(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }

        } else if ("clinical_info_table".equalsIgnoreCase(tabletype)) {
            String icdcode_id = ajaxResponse.getRequestParameter("icdcode_id", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccessionICDCodeMap");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("icdcodeid", icdcode_id);

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("searchorderingphytab".equalsIgnoreCase(tabletype)) {
            String orderingphysician_id = ajaxResponse.getRequestParameter("orderingphysician_id", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccPhysicianMap");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("physicianid", orderingphysician_id);
            prop.setProperty("physiciantype", "orderingphysician");

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("search_treating_physician_table".equalsIgnoreCase(tabletype)) {
            String treating_physician_id = ajaxResponse.getRequestParameter("treatingphysicianid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccPhysicianMap");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("physicianid", treating_physician_id);
            prop.setProperty("physiciantype", "treatingphysician");

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("search_patient_info_tab".equalsIgnoreCase(tabletype)) {
            String patient_id = ajaxResponse.getRequestParameter("patient_id", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("patientid", patient_id);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("updateaccessionlab".equalsIgnoreCase(tabletype)) {
            String accessionlab = ajaxResponse.getRequestParameter("accessionlab", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("accessionlab", accessionlab);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("billingtypelab_tab".equalsIgnoreCase(tabletype)) {
            String billingtypelab = ajaxResponse.getRequestParameter("billingtypelab", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("billingtype", billingtypelab);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("secbillingtypelab_tab".equalsIgnoreCase(tabletype)) {
            String secbillingtypelab = ajaxResponse.getRequestParameter("secbillingtypelab", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("secbillingtype", secbillingtypelab);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("accession_comment_table".equalsIgnoreCase(tabletype)) {
            String accessioncomment = ajaxResponse.getRequestParameter("accessioncomment", "");
            String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
            String custodialdepartmentid = getConnectionProcessor().getConnectionInfo(getConnectionid())
                    .getDefaultDepartment();
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("commentby", currentuser);
            prop.setProperty("commentdt", "n");
            prop.setProperty("comments", accessioncomment);
            prop.setProperty("departmentid", custodialdepartmentid);

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("bodysite_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String bodysitevalue = ajaxResponse.getRequestParameter("bodysitevalue", "");
            String celids = ajaxResponse.getRequestParameter("celids", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_bodysite", bodysitevalue);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponseBodySite(ajaxResponse, "Valid body site", "Y", celids);
            } catch (Exception ex) {
                getResponseBodySite(ajaxResponse, "Invalid body site", "N", celids);
            }//
        } else if ("bodysite_nxt_part".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String bodysitevalue = ajaxResponse.getRequestParameter("bodysitevalue", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_additionalbodysite", bodysitevalue);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }//bodysite_nxt_part
        } else if ("sampleinfo_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_sampleinformation", value);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("collectiondt_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            Date date = new Date();
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            value = Util.getUniqueList(value, ";", true);
            if (Util.isNull(value)) {
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                prop.setProperty("collectiondt", value);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception e) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            } else {
                DataSet ds = new DataSet();
                ds.addColumn("sampleid", DataSet.STRING);
                ds.addColumn("collectiondt", DataSet.STRING);
                ds.addColumn("u_morethan72", DataSet.STRING);
                try {
                    value = ajaxResponse.getRequestParameter("value", "");
                    String arryVal[] = StringUtil.split(value, ";");
                    String arrySamplVal[] = StringUtil.split(sampleid, ";");
                    if (arryVal.length > 0) {

                        for (int i = 0; i < arryVal.length; i++) {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
                            Date varDate = dateFormat.parse(arryVal[i]);
                            dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                            value = dateFormat.format(varDate);

                            SimpleDateFormat inpuformat = new SimpleDateFormat("MM/dd/yyyy");
                            Date inputDatee = inpuformat.parse(value);
                            long diff = date.getTime() - inputDatee.getTime();
                            long diffDays = diff / (24 * 60 * 60 * 1000);
                            long diffHour = 0;
                            if (diffDays > 0) {
                                diffHour = (diff / (60 * 60 * 1000) % 24) + (diffDays * 24);
                            } else {
                                diffHour = (diff / (60 * 60 * 1000) % 24);
                            }
                            String totalHours = "";
                            if (diffHour > 72) {
                                totalHours = String.valueOf(diffHour);
                            }
                            int rowID = ds.addRow();
                            ds.setValue(rowID, "sampleid", arrySamplVal[i]);
                            ds.setValue(rowID, "collectiondt", value);
                            ds.setValue(rowID, "u_morethan72", totalHours);
                        }
                    }
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sampleid", ";"));
                    prop.setProperty("collectiondt", ds.getColumnValues("collectiondt", ";"));
                    prop.setProperty("u_morethan72", ds.getColumnValues("u_morethan72", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }
        } else if ("client_spec_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_clientspecimenid", value);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
            updateClientSpecimenIDInDataItemLevel(ajaxResponse);
            updateChildClientSpecimenId(ajaxResponse);
        } else if ("aliquot_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_aliquotinfo", value);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("slidetype_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_type", value);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("clinical_info_del".equalsIgnoreCase(tabletype)) {
            String primaryid = ajaxResponse.getRequestParameter("primaryvale", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "AccessionICDCodeMap");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, primaryid);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }

        } else if ("accession_comment_del".equalsIgnoreCase(tabletype)) {
            String primaryid = ajaxResponse.getRequestParameter("primaryvale", "");
            // AccessionComment
            PropertyList prop = new PropertyList();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "AccessionComment");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, primaryid);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }

        } else if ("ordering_physician_del".equalsIgnoreCase(tabletype)) {
            String primaryid = ajaxResponse.getRequestParameter("primaryvale", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "AccPhysicianMap");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, primaryid);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("treating_physician_del".equalsIgnoreCase(tabletype)) {
            String primaryid = ajaxResponse.getRequestParameter("primaryvale", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "AccPhysicianMap");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, primaryid);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }

        } else if ("sample_information_del".equalsIgnoreCase(tabletype)) {
            String primaryid = ajaxResponse.getRequestParameter("primaryvale", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, primaryid);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("project_name_protocol".equalsIgnoreCase(tabletype)) {
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("bioprojectname", bioprojectid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("bio_site_info".equalsIgnoreCase(tabletype)) {
            String site_id = ajaxResponse.getRequestParameter("site_id", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("biositeid", site_id);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("cro_number_id".equalsIgnoreCase(tabletype)) {
            String cronumberid = ajaxResponse.getRequestParameter("cronumberid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("croaccessionno", cronumberid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("protocol_cohort".equalsIgnoreCase(tabletype)) {
            String protocolcohort = ajaxResponse.getRequestParameter("protocolcohort", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("protocolcohort", protocolcohort);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("randomization_no".equalsIgnoreCase(tabletype)) {
            String randomizationno = ajaxResponse.getRequestParameter("randomizationno", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("randomizationno", randomizationno);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("dignosis".equalsIgnoreCase(tabletype)) {
            String dignosis = ajaxResponse.getRequestParameter("dignosis", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("biodiagnosis", dignosis);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("tissue_collection_method".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_tissuecollecmthd", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("slide_thickness".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_slidethickness", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("fixation_method".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_fixationmethod", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("sampleorigin".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_biosampleorigin", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("slide_scetioning_dt_id".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            value = Util.getUniqueList(value, ";", true);
            if (Util.isNull(value)) {
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                prop.setProperty("u_slidesectiondate", value);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
                    if (dsTestCodePolicy.size() > 0) {
                        enterDataForAmgen(accessionid, dsTestCodePolicy);
                    }
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception e) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }

            } else {
                DataSet ds = new DataSet();
                ds.addColumn("sampleid", DataSet.STRING);
                ds.addColumn("u_slidesectiondate", DataSet.STRING);
                try {
                    value = ajaxResponse.getRequestParameter("value", "");
                    String arryVal[] = StringUtil.split(value, ";");
                    String arrySamplVal[] = StringUtil.split(sampleid, ";");
                    if (arryVal.length > 0) {

                        for (int i = 0; i < arryVal.length; i++) {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
                            Date varDate = dateFormat.parse(arryVal[i]);
                            dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                            value = dateFormat.format(varDate);

                            int rowID = ds.addRow();
                            ds.setValue(rowID, "sampleid", arrySamplVal[i]);
                            ds.setValue(rowID, "u_slidesectiondate", value);

                        }
                    }
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sampleid", ";"));
                    prop.setProperty("u_slidesectiondate", ds.getColumnValues("u_slidesectiondate", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
                    if (dsTestCodePolicy.size() > 0) {
                        enterDataForAmgen(accessionid, dsTestCodePolicy);
                    }
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }

        } else if ("collectiondt_time".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_collectiontime", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("updatebiovisitname".equalsIgnoreCase(tabletype)) {
            String visitnamebio = ajaxResponse.getRequestParameter("visitnamebio", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("biovisitname", visitnamebio);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("rcvdt_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            if (Util.isNull(value)) {
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                prop.setProperty("receiveddt", value);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception e) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            } else {
                DataSet ds = new DataSet();
                ds.addColumn("sampleid", DataSet.STRING);
                ds.addColumn("receiveddt", DataSet.STRING);
                try {
                    String arryVal[] = StringUtil.split(value, ";");
                    String arrySamplVal[] = StringUtil.split(sampleid, ";");
                    if (arryVal.length > 0) {

                        for (int i = 0; i < arryVal.length; i++) {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
                            Date varDate = dateFormat.parse(arryVal[i]);
                            dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                            value = dateFormat.format(varDate);

                            int rowID = ds.addRow();
                            ds.setValue(rowID, "sampleid", arrySamplVal[i]);
                            ds.setValue(rowID, "receiveddt", value);

                        }
                    }
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sampleid", ";"));
                    prop.setProperty("receiveddt", ds.getColumnValues("receiveddt", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }

        } else if ("mapinvestigator".equalsIgnoreCase(tabletype)) {
            String investigatornamid = ajaxResponse.getRequestParameter("investigatornamid", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccessionBioInvsMap");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("investigatorid", investigatornamid);
            prop.setProperty("accessionid", accessionid);

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("deleinvestigator".equalsIgnoreCase(tabletype)) {
            String primaryvale = ajaxResponse.getRequestParameter("primaryvale", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "AccessionBioInvsMap");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, primaryvale);

            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("canceltest".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "").trim();
            String sampletestcodemap = ajaxResponse.getRequestParameter("sampletestcodemap", "").trim();
            String testcode = ajaxResponse.getRequestParameter("testcode", "").trim();
            String sql = "select u_sampletestcodemapid,methodology from u_sampletestcodemap where s_sampleid='" + sampleid
                    + "' and u_sampletestcodemapid='" + sampletestcodemap + "' and lvtestcodeid='" + testcode + "' " + "and (teststatus is null or teststatus='In Progress')";
            DataSet dsTest = getQueryProcessor().getSqlDataSet(sql);
            if (dsTest.size() == 0) {
                getResponse(ajaxResponse, "Failed.\nReason: Selected testcode is not eligible for cancel operation", tabletype, accessionid);
                return;
            }
            String u_sampletestcodemapid = dsTest.getValue(0, "u_sampletestcodemapid", "");
            String methodology = dsTest.getValue(0, "methodology", "");
            if ("Cytogenetics".equalsIgnoreCase(methodology)) {
                PropertyList prop = new PropertyList();
                prop.setProperty("orgsample", sampleid);
                prop.setProperty("option", "Discard");
                prop.setProperty("auditreason", "Cancelling Test");
                try {
                    getActionProcessor().processAction("CytoCancelTest", "1", prop);
                    getResponse(ajaxResponse, testcode + " has been successfully cancelled from " + sampleid, tabletype,
                            accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed. Reason : " + ex.getMessage(), tabletype, accessionid);
                }
            } else if ("Multiomyx".equalsIgnoreCase(methodology)) {
                try {
                    throw new SapphireException("Mutiomyx testcode(s) cannot be deleted");
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed.\nReason: " + ex.getMessage(), tabletype, accessionid);
                }
            } else {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, u_sampletestcodemapid);
                prop.setProperty("teststatus", "Cancelled");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, testcode + " has been successfully cancelled from " + sampleid, tabletype,
                            accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed. Reason: \n" + ex.getMessage(), tabletype, accessionid);
                }
            }

        } else if ("rcvtime_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_receivetime", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("reasonforreferal".equalsIgnoreCase(tabletype)) {
            String reasonforreferal = ajaxResponse.getRequestParameter("reasonforreferal", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("reasonforreferal", reasonforreferal);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("performing_site".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            String sql = Util.parseMessage(AccessionPageSql.GET_TRANSPORTTYPE_BY_SAMPLEID, sampleid);
            DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
            if (dsSql == null)
                getResponse(ajaxResponse, "Error : Unable to Fetch Details for the Specimen " + sampleid, tabletype, accessionid);
            else if (dsSql.size() > 0) {
                // logic to check and validate for one MO Req
                // Req : Only Unstained Slide can move to AV_MOWetLab directly(through Performing Site option) after accessioning.
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);

                String transportType = dsSql.getValue(0, "containertypeid", "");
                if ("AV-MOWetLab".equalsIgnoreCase(value) && !"Unstained Slide".equalsIgnoreCase(transportType)) {
                    try {
                        prop.setProperty("u_performingsite", "");
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ex) {
                        getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                    }
                    getResponse(ajaxResponse, "Only Unstained Slide(s) can route from Accession QC to Wet Lab directly.", tabletype, accessionid);
                } else {

                    try {
                        prop.setProperty("u_performingsite", value);
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                        getResponse(ajaxResponse, "Success", tabletype, accessionid);
                    } catch (Exception ex) {
                        getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                    }
                }

            }


        } else if ("courier_type".equalsIgnoreCase(tabletype)) {
            String couriertyp = ajaxResponse.getRequestParameter("couriertyp", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("couriertype", couriertyp);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("trackingnum".equalsIgnoreCase(tabletype)) {
            String trackingnumber = ajaxResponse.getRequestParameter("trackingnumber", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("trackingnumber", trackingnumber);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("accessionrcvdt_id".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            if (Util.isNull(value)) {
                prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
                prop.setProperty("receiveddate", value);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception e) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            } else {
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
                    Date varDate = dateFormat.parse(value);
                    dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    value = dateFormat.format(varDate);
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
                    prop.setProperty("receiveddate", value);
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }

        } else if ("accessionstausflag".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            String sql = "select status from u_accession where u_accessionid='" + accessionid + "'";
            DataSet dsStatus = getQueryProcessor().getSqlDataSet(sql);
            String accessionstatus = dsStatus.getValue(0, "status", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            //prop.setProperty("accessionqrystatus", value);
            if ("In Progress - Query".equalsIgnoreCase(value)) {
                prop.setProperty("status", "(null)");
                prop.setProperty("accessionqrystatus", value);
            } else if ("On Hold".equalsIgnoreCase(value)) {
                prop.setProperty("status", "On Hold");
                prop.setProperty("accessionqrystatus", "(null)");
            } else if (!"In Progress".equalsIgnoreCase(accessionstatus) && "In Progress".equalsIgnoreCase(value)) {
                prop.setProperty("status", "In Progress");
                prop.setProperty("accessionqrystatus", "(null)");
            } else if ("In Progress".equalsIgnoreCase(accessionstatus) && "In Progress".equalsIgnoreCase(value)) {
                prop.setProperty("status", "In Progress");
                prop.setProperty("accessionqrystatus", "(null)");
            }
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("accessionstausonholdflag".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("status", value);
            prop.setProperty("accessionqrystatus", "(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("recvfrom_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            Date date = new Date();
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            value = Util.getUniqueList(value, ";", true);
            if (Util.isNull(value)) {
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                prop.setProperty("u_receivedfromdate", value);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception e) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            } else {
                DataSet ds = new DataSet();
                ds.addColumn("sampleid", DataSet.STRING);
                ds.addColumn("u_receivedfromdate", DataSet.STRING);
                ds.addColumn("u_morethan72", DataSet.STRING);
                try {
                    value = ajaxResponse.getRequestParameter("value", "");
                    String arryVal[] = StringUtil.split(value, ";");
                    String arrySamplVal[] = StringUtil.split(sampleid, ";");
                    if (arryVal.length > 0) {

                        for (int i = 0; i < arryVal.length; i++) {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
                            Date varDate = dateFormat.parse(arryVal[i]);
                            dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                            value = dateFormat.format(varDate);

                            SimpleDateFormat inpuformat = new SimpleDateFormat("MM/dd/yyyy");
                            Date inputDatee = inpuformat.parse(value);
                            long diff = date.getTime() - inputDatee.getTime();
                            long diffDays = diff / (24 * 60 * 60 * 1000);
                            long diffHour = 0;
                            if (diffDays > 0) {
                                diffHour = (diff / (60 * 60 * 1000) % 24) + (diffDays * 24);
                            } else {
                                diffHour = (diff / (60 * 60 * 1000) % 24);
                            }
                            String totalHours = "";
                            if (diffHour > 72) {
                                totalHours = String.valueOf(diffHour);
                            }
                            int rowID = ds.addRow();
                            ds.setValue(rowID, "sampleid", arrySamplVal[i]);
                            ds.setValue(rowID, "u_receivedfromdate", value);
                            ds.setValue(rowID, "u_morethan72", totalHours);
                        }
                    }
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sampleid", ";"));
                    prop.setProperty("u_receivedfromdate", ds.getColumnValues("u_receivedfromdate", ";"));
                    // prop.setProperty("u_morethan72",
                    // ds.getColumnValues("u_morethan72", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }
        } else if ("transferto_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            Date date = new Date();
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            value = Util.getUniqueList(value, ";", true);
            if (Util.isNull(value)) {
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                prop.setProperty("u_transfertodate", value);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception e) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            } else {
                DataSet ds = new DataSet();
                ds.addColumn("sampleid", DataSet.STRING);
                ds.addColumn("u_transfertodate", DataSet.STRING);
                ds.addColumn("u_morethan72", DataSet.STRING);
                try {
                    value = ajaxResponse.getRequestParameter("value", "");
                    String arryVal[] = StringUtil.split(value, ";");
                    String arrySamplVal[] = StringUtil.split(sampleid, ";");
                    if (arryVal.length > 0) {

                        for (int i = 0; i < arryVal.length; i++) {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
                            Date varDate = dateFormat.parse(arryVal[i]);
                            dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                            value = dateFormat.format(varDate);

                            SimpleDateFormat inpuformat = new SimpleDateFormat("MM/dd/yyyy");
                            Date inputDatee = inpuformat.parse(value);
                            long diff = date.getTime() - inputDatee.getTime();
                            long diffDays = diff / (24 * 60 * 60 * 1000);
                            long diffHour = 0;
                            if (diffDays > 0) {
                                diffHour = (diff / (60 * 60 * 1000) % 24) + (diffDays * 24);
                            } else {
                                diffHour = (diff / (60 * 60 * 1000) % 24);
                            }
                            String totalHours = "";
                            if (diffHour > 72) {
                                totalHours = String.valueOf(diffHour);
                            }
                            int rowID = ds.addRow();
                            ds.setValue(rowID, "sampleid", arrySamplVal[i]);
                            ds.setValue(rowID, "u_transfertodate", value);
                            ds.setValue(rowID, "u_morethan72", totalHours);
                        }
                    }
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sampleid", ";"));
                    prop.setProperty("u_transfertodate", ds.getColumnValues("u_transfertodate", ";"));
                    // prop.setProperty("u_morethan72",
                    // ds.getColumnValues("u_morethan72", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }
        } else if ("addbatchflag".equalsIgnoreCase(tabletype)) {
            String value = ajaxResponse.getRequestParameter("value", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("molbatchflag", value);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("mol_batchid".equalsIgnoreCase(tabletype)) {
            String molbatchid = ajaxResponse.getRequestParameter("molbatchid", "");
            if (Util.isNull(molbatchid)) {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
                prop.setProperty("molbatchid", "(null)");
                prop.setProperty("molbatchflag", "N");

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            } else {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
                prop.setProperty("molbatchid", molbatchid);
                prop.setProperty("molbatchflag", "Y");

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    getResponse(ajaxResponse, "Success", tabletype, accessionid);
                } catch (Exception ex) {
                    getResponse(ajaxResponse, "Failed", tabletype, accessionid);
                }
            }
        } else if ("addtionalinfo_id".equalsIgnoreCase(tabletype)) {
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            String value = ajaxResponse.getRequestParameter("value", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_additionalinfo", value);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("saveslidesectndt".equalsIgnoreCase(tabletype)) {
            try {
                //DataSet dsTestCodePolicy = getTestCodePolicy();
                DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
                if (dsTestCodePolicy.size() > 0) {
                    enterDataForAmgen(accessionid, dsTestCodePolicy);
                }
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        }
        /*********RELEASE 1.6.1***********/
        else if ("accession_packageid".equalsIgnoreCase(tabletype)) {
            String packageid = ajaxResponse.getRequestParameter("packageid", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("clientpackageid", packageid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("client_package_id_spec".equalsIgnoreCase(tabletype)) {
            String packageid = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_clientpackageid", packageid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("specimen_visits".equalsIgnoreCase(tabletype)) {
            String specimenvisit = ajaxResponse.getRequestParameter("value", "");
            String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_specimenvisit", specimenvisit);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        }
    }

    private void enterDataForAmgen(String accessionid, DataSet dsTestCodePolicy) throws SapphireException {
        String testcodePolicy = dsTestCodePolicy.getColumnValues("testcode", "','");
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES, accessionid, testcodePolicy);
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES, accessionid, testcodePolicy);
        String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES_PORTAL, accessionid, testcodePolicy);
        DataSet dsTestAmgen = getQueryProcessor().getSqlDataSet(sampleTestAmgen);
        if (dsTestAmgen != null && dsTestAmgen.size() > 0) {
            String testname = StringUtil.replaceAll(dsTestAmgen.getColumnValues("testname", ";"), ";", "','");
            String slides = StringUtil.replaceAll(dsTestAmgen.getColumnValues("s_sampleid", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_PARAMIDS, slides, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                for (int i = 0; i < dsSqlEnterData.size(); i++) {
                    String slidesectiondt = dsSqlEnterData.getValue(i, "u_slidesectiondate", "");
                    if (!Util.isNull(slidesectiondt)) {
                        try {
                            //input date format
                            SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyyy");
                            //output date format
                            SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd-MMM-yyyy");
                            Date date = dFormat.parse(slidesectiondt);
                            String formtSlideSectndt = dFormatFinal.format(date);
                            dsSqlEnterData.setValue(i, "u_slidesectiondate", formtSlideSectndt.toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }

    public void getResponse(AjaxResponse ajaxResponse, String msg, String tableid, String accessionid) {
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("tableid", tableid);
        ajaxResponse.addCallbackArgument("accessionid", accessionid);
        ajaxResponse.print();
    }

    public void getResponseBodySite(AjaxResponse ajaxResponse, String msg, String msgtype, String ids) {
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("msgtype", msgtype);
        ajaxResponse.addCallbackArgument("ids", ids);
        ajaxResponse.print();
    }

    private void updateClientSpecimenIDInDataItemLevel(AjaxResponse ajaxResponse) {
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("keyid3", DataSet.STRING);
        dsFinal.addColumn("keyid2", DataSet.STRING);
        dsFinal.addColumn("keyid1", DataSet.STRING);
        dsFinal.addColumn("sdidataid", DataSet.STRING);
        dsFinal.addColumn("sdidataitemid", DataSet.STRING);

        String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
        sampleid = Util.getUniqueList(sampleid, ";", true);
        sampleid = StringUtil.replaceAll(sampleid, ";", "','");
        String sql = Util.parseMessage(AccessionPageSql.CHECK_PANEL, sampleid);
        DataSet dsChkPanel = getQueryProcessor().getSqlDataSet(sql);
        if (dsChkPanel == null || dsChkPanel.size() == 0)
            return;
        if (dsChkPanel.size() > 0) {
            String accessionid = dsChkPanel.getColumnValues("u_accessionid", ";");
            accessionid = Util.getUniqueList(accessionid, ";", true);
            accessionid = StringUtil.replaceAll(accessionid, ";", "','");
            sql = Util.parseMessage(AccessionPageSql.GET_SDIDATA_VALUE_BY_ACCESSION, accessionid);
            DataSet dsSDIData = getQueryProcessor().getSqlDataSet(sql);
            if (dsSDIData == null || dsSDIData.size() == 0)
                return;
            sql = Util.parseMessage(AccessionPageSql.GET_SDIDTAITEM_VALUE_BY_ACCESSION, accessionid);
            DataSet dsSDIDataItem = getQueryProcessor().getSqlDataSet(sql);
            if (dsSDIDataItem == null || dsSDIDataItem.size() == 0)
                return;
            HashMap hm = new HashMap();
            for (int i = 0; i < dsChkPanel.size(); i++) {
                String keyid1 = dsChkPanel.getValue(i, "u_accessionid", "");
                String keyid2 = dsChkPanel.getValue(i, "u_clientspecimenid", "");
                String keyid3 = dsChkPanel.getValue(i, "s_sampleid", "");
                String u_type = dsChkPanel.getValue(i, "u_type", "");

                if (Util.isNull(u_type) || "EB".equalsIgnoreCase(u_type)) {
                    int rowid = dsFinal.addRow();
                    dsFinal.setValue(rowid, "keyid1", keyid1);
                    dsFinal.setValue(rowid, "keyid2", keyid2);
                    dsFinal.setValue(rowid, "keyid3", keyid3);
                    hm.clear();
                    hm.put("keyid1", keyid1);
                    hm.put("keyid3", keyid3);
                    DataSet dsSDIDataFiletr = dsSDIData.getFilteredDataSet(hm);
                    if (dsSDIDataFiletr.size() > 0) {
                        dsFinal.setValue(rowid, "sdidataid", dsSDIDataFiletr.getColumnValues("sdidataid", ";"));
                    }
                    hm.clear();
                    hm.put("keyid1", keyid1);
                    hm.put("keyid3", keyid3);
                    DataSet dsSDIDataItemFiletr = dsSDIDataItem.getFilteredDataSet(hm);
                    if (dsSDIDataItemFiletr.size() > 0) {
                        dsFinal.setValue(rowid, "sdidataitemid", dsSDIDataItemFiletr.getColumnValues("sdidataitemid", ";"));
                    }
                    //UPDATE SDITATA AND SDIDATAITEM
                    PropertyList props = new PropertyList();
                    props.setProperty("keyid2", keyid2);
                    props.setProperty("sdidataid", dsSDIDataFiletr.getValue(0, "sdidataid", ""));
                    props.setProperty("sdidataitemid", dsSDIDataItemFiletr.getColumnValues("sdidataitemid", ";"));
                    try {
                        getActionProcessor().processAction("ExecuteUpdateAction", "1", props);
                    } catch (Exception ex) {
                        logger.info("client specimen id is failed to update into sdi data & sdi data item level.." + ex.getMessage());
                    }
                } else {
                    int rowid = dsFinal.addRow();
                    dsFinal.setValue(rowid, "keyid1", keyid1);
                    dsFinal.setValue(rowid, "keyid2", keyid2);
                    dsFinal.setValue(rowid, "keyid3", keyid3);
                    hm.clear();
                    hm.put("keyid1", keyid1);
                    hm.put("keyid3", "(null)");
                    DataSet dsSDIDataFiletr = dsSDIData.getFilteredDataSet(hm);
                    if (dsSDIDataFiletr.size() > 0) {
                        dsFinal.setValue(rowid, "sdidataid", dsSDIDataFiletr.getColumnValues("sdidataid", ";"));
                    }
                    hm.clear();
                    hm.put("keyid1", keyid1);
                    hm.put("keyid3", "(null)");
                    DataSet dsSDIDataItemFiletr = dsSDIDataItem.getFilteredDataSet(hm);
                    if (dsSDIDataItemFiletr.size() > 0) {
                        dsFinal.setValue(rowid, "sdidataitemid", dsSDIDataItemFiletr.getColumnValues("sdidataitemid", ";"));
                    }
                    //UPDATE SDITATA AND SDIDATAITEM
                    PropertyList props = new PropertyList();
                    props.setProperty("keyid2", keyid2);
                    props.setProperty("sdidataid", dsSDIDataFiletr.getValue(0, "sdidataid", ""));
                    props.setProperty("sdidataitemid", dsSDIDataItemFiletr.getColumnValues("sdidataitemid", ";"));
                    try {
                        getActionProcessor().processAction("ExecuteUpdateAction", "1", props);
                    } catch (Exception ex) {

                    }
                }
            }

        }
    }

    private void updateChildClientSpecimenId(AjaxResponse ajaxResponse) {
        String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
        sampleid = Util.getUniqueList(sampleid, ";", true);
        sampleid = StringUtil.replaceAll(sampleid, ";", "','");
        String sql = Util.parseMessage(AccessionPageSql.GET_CHILDS_INFO, sampleid);
        DataSet dsChildsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsChildsInfo == null || dsChildsInfo.size() == 0)
            return;
        sql = Util.parseMessage(AccessionPageSql.GET_SAMPLE_INFO, sampleid);
        DataSet dsRootSampleinfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsRootSampleinfo == null || dsRootSampleinfo.size() == 0)
            return;
        for (int i = 0; i < dsRootSampleinfo.size(); i++) {
            String parentsampleid = dsRootSampleinfo.getValue(i, "parentsampleid", "");
            String u_clientspecimenid = dsRootSampleinfo.getValue(i, "u_clientspecimenid", "");
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("parentsampleid", parentsampleid);
            DataSet dsChildFilter = dsChildsInfo.getFilteredDataSet(hm);
            if (dsChildFilter != null && dsChildFilter.size() > 0) {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsChildFilter.getColumnValues("childsampleid", ";"));
                prop.setProperty("u_clientspecimenid", StringUtil.repeat(u_clientspecimenid, dsChildFilter.size(), ";"));

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    logger.info("client specimen id is updated successfully for child(s).");
                } catch (Exception ex) {
                    logger.info("client specimen id is failed to update for child(s)." + ex.getMessage());
                }
            }
        }
    }
}
