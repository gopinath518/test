package sapphire.custom.ng.ajax;

import sapphire.action.EditSDI;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by smitra on 8/24/2017.
 */
public class ChangeBoxLocation extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request,
                               HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        try{
            String boxid = ajaxResponse.getRequestParameter("boxkeyid");
            String boxLocation = ajaxResponse.getRequestParameter("boxLocation");
            String boxSlideid = ajaxResponse.getRequestParameter("boxSlideid");
            String storagetype = ajaxResponse.getRequestParameter("storagetype");

            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "LV_Box");
            props.setProperty(EditSDI.PROPERTY_KEYID1, boxid);
            if(storagetype!="" && "Ambient Storage".equalsIgnoreCase(storagetype)) {
                if("No".equalsIgnoreCase(boxLocation)) {
                    props.setProperty("u_targetstoragetype", storagetype);
                    props.setProperty("u_slideboxid", "");
                    props.setProperty("u_boxlocation", boxLocation);
                }else{
                    props.setProperty("u_targetstoragetype", storagetype);
                    props.setProperty("u_slideboxid", boxSlideid);
                    props.setProperty("u_boxlocation", boxLocation);
                }
            }else{
                if(storagetype=="" && "No".equalsIgnoreCase(boxLocation)) {
                    props.setProperty("u_targetstoragetype", storagetype);
                    props.setProperty("u_slideboxid", "");
                    props.setProperty("u_boxlocation", boxLocation);
                }else{
                    props.setProperty("u_targetstoragetype", storagetype);
                    props.setProperty("u_slideboxid", "");
                    props.setProperty("u_boxlocation", "");
                }
            }
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

        }catch(Exception ex){
            ex.printStackTrace();
            String error = getTranslationProcessor().translate("error: ");
            error += ex.getMessage();
            ajaxResponse.addCallbackArgument("msg", error);

        }finally{
            ajaxResponse.print();
        }
    }
}
