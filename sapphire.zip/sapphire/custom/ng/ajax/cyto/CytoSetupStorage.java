package sapphire.custom.ng.ajax.cyto;

import sapphire.accessor.ActionException;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by subhashree.dash on 2/21/2018.
 */
public class CytoSetupStorage extends BaseAjaxRequest {
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String childsampleid = ajaxResponse.getRequestParameter("childsampleid");
        String storage = ajaxResponse.getRequestParameter("storagelocation");

        if (childsampleid==null) {
            ajaxResponse.addCallbackArgument("err", "No sampleid(s) Selected.");
        } else {
            String sql = Util.parseMessage(CytoSqls.GET_TRACKITEMID_SQL, StringUtil.replaceAll(childsampleid, ";", "','"));
            DataSet dsSCMInfo = getQueryProcessor().getSqlDataSet(sql);
            String trackitemid = "";
            if (dsSCMInfo != null && dsSCMInfo.size() > 0)

                trackitemid = dsSCMInfo.getColumnValues("trackitemid", ";");
            else{
                ajaxResponse.addCallbackArgument("err","Unable to perform query in DataBase");
            }

            if (!Util.isNull(trackitemid)) {
                String sqlStorage = Util.parseMessage(CytoSqls.GET_STORAGEUNITID, StringUtil.replaceAll(storage, ";", "','"));
                DataSet dsStorageInfo = getQueryProcessor().getSqlDataSet(sqlStorage);
                String storageunitid = "";
                if(dsStorageInfo==null){
                    ajaxResponse.addCallbackArgument("err","Unable to perform query in DataBase");
                }
                else{
                    storageunitid = dsStorageInfo.getColumnValues("storageunitid", ";");
                    PropertyList pl = new PropertyList();
                    try {
                        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                        pl.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, trackitemid);
                        pl.setProperty("currentstorageunitid", storageunitid);
                        pl.setProperty("custodialuserid", "(null)");
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        ajaxResponse.addCallbackArgument("msg","success");
                    }catch (ActionException ae){
                        ajaxResponse.addCallbackArgument("err","Unable to update Trackitem for following sample(s): "
                                +childsampleid +"\nReason: "+ae.getMessage());
                    }
                }
            }
        }
        ajaxResponse.print();
    }
}
