package sapphire.custom.ng.ajax.cyto;

import com.labvantage.opal.validation.misc.ConvertUnits;
import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CytoReagentUnitConversion extends BaseAjaxRequest {

    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String scannedAmount = ajaxResponse.getRequestParameter("scannedamount").trim();
        String scannedUnit = ajaxResponse.getRequestParameter("scannedunit").trim();
        String trackitemUnit = ajaxResponse.getRequestParameter("trackitemunit").trim();
        double totalVol = 0.0d;

        try {
            if (!Util.isNull(scannedAmount) && !Util.isNull(trackitemUnit) && !Util.isNull(scannedUnit))
                totalVol = Double.parseDouble(ConvertUnits.convertUnits(getQueryProcessor(), scannedUnit, trackitemUnit, String.valueOf(scannedAmount)));

                ajaxResponse.addCallbackArgument("finalamount", totalVol);
                ajaxResponse.addCallbackArgument("finalunit", trackitemUnit);


        } catch (SapphireException e) {
            ajaxResponse.setError(e.getMessage());
        } finally {
            ajaxResponse.print();
        }

    }
}
