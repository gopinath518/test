package sapphire.custom.ng.ajax.cyto;

import sapphire.SapphireException;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

public class BarcodeScanFormat extends BaseAjaxRequest {

    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String slideName = ajaxResponse.getRequestParameter("slidename");
        String from = ajaxResponse.getRequestParameter("from");
        DataSet ds = null;
        String sql = "";
        String fSampleId = "";
        String slideId = "";
        String cultureId = "";

        if (slideName == "") {
            ajaxResponse.addCallbackArgument("dataset", "No Data Found");
        } else {
           try {
               String tempSlideName = slideName;

               if("Harvest".equalsIgnoreCase(from) || "SlideDrop".equalsIgnoreCase(from) || "SlideDropEdit".equalsIgnoreCase(from) || "Setup".equalsIgnoreCase(from) ){
                   String tempFileName = cultureBarcodeParsing(slideName);
                   String[] tempArr = StringUtil.split(tempFileName, "@*@", true);
                   fSampleId = tempArr[0].trim();
                   cultureId = tempArr[1].trim();
               }

               if("SlideBanding".equalsIgnoreCase(from) || "Metafar".equalsIgnoreCase(from) ){
                   String tempFileName = slideBarcodeParsing(slideName);
                   String[] tempArr = StringUtil.split(tempFileName, "@*@", true);
                   fSampleId = tempArr[0].trim();
                   slideId = tempArr[1].trim();
               }

               if("SlideDrop".equalsIgnoreCase(from)){
                   sql = Util.parseMessage(CytoSqls.GET_CHILDSAMPLEID_BY_FPID_CULTURETYPEID, fSampleId, cultureId);
               }
               else if("SlideDropEdit".equalsIgnoreCase(from) || "Setup".equalsIgnoreCase(from) ){
                   sql = Util.parseMessage(CytoSqls.GET_CULTURE_INFO_BY_BARCODE, fSampleId, cultureId);
               }
               else if("Harvest".equalsIgnoreCase(from)){
                   sql = Util.parseMessage(CytoSqls.GET_SCAN_FEED_CULTURE,from, fSampleId, cultureId);
               }
               else if("SlideBanding".equalsIgnoreCase(from) || "Metafar".equalsIgnoreCase(from) ){
                   sql = Util.parseMessage(CytoSqls.GET_CHILDSAMPLEID_BY_FPID_SLIDEID,fSampleId, slideId);
               }

               ds = getQueryProcessor().getSqlDataSet(sql);

               if(ds == null)
                   throw new SapphireException("Unable to connect to database.");
               else if (ds.size() > 0){
                   ajaxResponse.addCallbackArgument("dataset", ds);
                   ajaxResponse.addCallbackArgument("rows", ds.size());
                   ajaxResponse.addCallbackArgument("columns", ds.getColumns().length);
               } else {
                   ajaxResponse.addCallbackArgument("dataset", "No Data Found");
               }


           }catch (SapphireException e){
               ajaxResponse.setError(e.getMessage());
           }
           finally{
               ajaxResponse.print();
           }

        }

    }

    private String cultureBarcodeParsing(String fileName) throws SapphireException {

        String tempFileName = fileName;
        List<String> delimeterList = new ArrayList<String>(); // to store probable delimeter list from Policy
        //List<String> extensionList = new ArrayList<String>(); // to store probable extension list from Policy
        Map<String,Integer> colIndexMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy

        PropertyList filePolicyProperties = getConfigurationProcessor().getPolicy("CytoBarcodePolicy", "CultureBarcodeFormat");
        PropertyList pl = filePolicyProperties.getPropertyList("filepattern");

        PropertyListCollection delimeterColl = pl.getCollection("filepatterncollection");
        PropertyListCollection columnIndexColl = pl.getCollection("ColumnIndex");
        //PropertyListCollection extensioncoll = pl.getCollection("extensioncoll");

        for (int i = 0; i < delimeterColl.size(); i++)
            delimeterList.add(delimeterColl.getPropertyList(i).getProperty("delimeter"));

        for (int i = 0; i < columnIndexColl.size(); i++)
            colIndexMap.put(columnIndexColl.getPropertyList(i).getProperty("column"),
                    Integer.parseInt(columnIndexColl.getPropertyList(i).getProperty("index")));

        try {
            tempFileName = fileName.substring(0, (fileName.lastIndexOf(".")));
        } catch (Exception se){
            Logger.logInfo("No Proper extension found for the scanned file.\n"+fileName);
        }

        for(String s:delimeterList){
            if(tempFileName.contains(s)) {
                tempFileName=StringUtil.replaceAll(tempFileName,s.trim(),"@*@");
            }
        }

        if(!tempFileName.contains("@*@"))
            Logger.logInfo("No Proper delimeter defined in the policy for the scanned file.\n"+fileName);

        try {
            String[] tempArr = StringUtil.split(tempFileName, "@*@");

            String fsampleId = "";
            String cltrId = "";
            //CYG17-000006;Doe, John;120IL4
            Set<String> set = colIndexMap.keySet();
            for (String str : set) {
                if ("freshprepid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    fsampleId = tempArr[index];
                } else if ("cultureid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    cltrId = tempArr[index];
                }
            }
            return (fsampleId + "@*@" + cltrId);
        } catch (Exception e){
            Logger.logInfo("Unable to find childsample due to : "+e);
            return "@*@";
        }
    }

    private String slideBarcodeParsing(String fileName) throws SapphireException {

        String tempFileName = fileName;
        List<String> delimeterList = new ArrayList<String>(); // to store probable delimeter list from Policy
        //List<String> extensionList = new ArrayList<String>(); // to store probable extension list from Policy
        Map<String,Integer> colIndexMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy
        Map<String,DataSet> colDelimeterMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy

        PropertyList filePolicyProperties = getConfigurationProcessor().getPolicy("CytoBarcodePolicy", "SlideBarcodeFormat");
        PropertyList pl = filePolicyProperties.getPropertyList("filepattern");

        PropertyListCollection delimeterColl = pl.getCollection("filepatterncollection");
        PropertyListCollection columnIndexColl = pl.getCollection("ColumnIndex");
        //PropertyListCollection extensioncoll = pl.getCollection("extensioncoll");

        for (int i = 0; i < delimeterColl.size(); i++)
            delimeterList.add(delimeterColl.getPropertyList(i).getProperty("delimeter"));

      /*  for (int i = 0; i < extensioncoll.size(); i++)
            extensionList.add(extensioncoll.getPropertyList(i).getProperty("extensiontype"));*/


        for (int i = 0; i < columnIndexColl.size(); i++) {

            PropertyList tempPl=columnIndexColl.getPropertyList(i);
            if(tempPl!=null && tempPl.size()>0){
                String column=tempPl.getProperty("column");
                String index=tempPl.getProperty("index");
                if(!Util.isNull(index))
                    colIndexMap.put(column,Integer.parseInt(index));
                PropertyListCollection subDelimetrsPlc=tempPl.getCollection("subdelimeter");
                if(subDelimetrsPlc!=null && subDelimetrsPlc.size()>0){
                    DataSet subDelimeterDs = new DataSet();
                    subDelimeterDs.addColumn("subdelimeterlist", DataSet.STRING);
                    for(int j=0;j<subDelimetrsPlc.size();j++){
                        PropertyList tempSubDelList=subDelimetrsPlc.getPropertyList(j);
                        if(tempSubDelList!=null && tempSubDelList.size()>0){
                            String tempDel=tempSubDelList.getProperty("subdelimeterid","");
                            if(!Util.isNull(tempDel)){
                                int rowIndx=subDelimeterDs.addRow();
                                subDelimeterDs.setValue(rowIndx,"subdelimeterlist",tempDel);
                            }
                        }
                    }
                    if(subDelimeterDs!=null && subDelimeterDs.size()>0)
                        colDelimeterMap.put(column,subDelimeterDs);
                }
            }
        }

        try {
            tempFileName = fileName.substring(0, (fileName.lastIndexOf(".")));
        } catch (Exception se){
            Logger.logInfo("No Proper extension found for the scanned file.\n"+fileName);
        }

        for(String s:delimeterList){
            if(tempFileName.contains(s)) {
                tempFileName=StringUtil.replaceAll(tempFileName,s.trim(),"@*@");
            }
        }

        if(!tempFileName.contains("@*@"))
            Logger.logInfo("No Proper delimeter defined in the policy for the scanned file.\n"+fileName);

        try {
            String[] tempArr = StringUtil.split(tempFileName, "@*@");

            String fsampleId = "";
            String cltrId = "";
            String slideid = "";
            String slideno = "";
            //CYG17-000006;Doe, John;120IL4;1 of 3
            Set<String> set = colIndexMap.keySet();
            Set<String> subDelimeterSet = colDelimeterMap.keySet();
            for (String str : set) {
                if ("freshprepid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    fsampleId = tempArr[index];
                } else if ("cultureid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    cltrId = tempArr[index];
                } else if ("slideid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    String slideSeq = tempArr[index]; //1 of 3
                    DataSet dsDlimtr = null;
                    try {
                        for (String str1 : subDelimeterSet) {
                            if ("slideid".equalsIgnoreCase(str1)) {
                                dsDlimtr = colDelimeterMap.get(str1);
                            }
                            String delimtrList = dsDlimtr.getColumnValues("subdelimeterlist", ";");
                            String[] delimtrListArr = StringUtil.split(delimtrList, ";", true);
                            for (String s : delimtrListArr) {
                                if (slideSeq.contains(s)) {
                                    slideSeq = StringUtil.replaceAll(slideSeq, s.trim(), "#*#");
                                }
                            }
                            String[] slideSeqArr = StringUtil.split(slideSeq, "#*#");

                            slideno = slideSeqArr[0];
                        }
                    } catch (Exception e) {
                        throw new SapphireException(e);
                    }
                }
            }
            slideid = cltrId.trim() + "-" + slideno.trim();
            return (fsampleId.trim() + "@*@" + slideid);
        } catch (Exception e){
            Logger.logInfo("Unable to find childsample due to : "+e);
            return "@*@";
        }
    }




}
