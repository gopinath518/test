package sapphire.custom.ng.ajax.cyto;

import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.M18NUtil;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Calendar;
import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by dkundu on 12/19/2016.
 */
public class ValidateReagentExpiryDate extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String lotids = ajaxResponse.getRequestParameter("lotids");
        ajaxResponse.addCallbackArgument("err","empty");
        ajaxResponse.addCallbackArgument("msg","empty");
        if(isNull(lotids))
            ajaxResponse.addCallbackArgument("err","No Reagent lotid found to validate");
        else{
            lotids = Util.getUniqueList(lotids,";",true);
            String []lots = lotids.split(";");
            String expSql = parseMessage(CytoSqls.GET_REAGENTLOT_EXPIRYDATE , StringUtil.replaceAll(lotids , ";" , "','"));
            DataSet dsExp = getQueryProcessor().getSqlDataSet(expSql);
            if(dsExp == null)
                ajaxResponse.addCallbackArgument("err","Error: Unable to perform query in Database");
            else if(0 == dsExp.size())
                ajaxResponse.addCallbackArgument("err","All reagent lots are invalid");
            else if(lots.length <= dsExp.size()){
                String invalidLots = "";
                HashMap<String,String> hmFilter = new HashMap();
                String expiredLots = "";
                Calendar currentdate = new M18NUtil().getNowCalendar();
                for(int i = 0 ; i < lots.length ; i++) {
                    hmFilter.clear();
                    hmFilter.put("reagentlotid", lots[i]);
                    DataSet dsFilter = dsExp.getFilteredDataSet(hmFilter);
                    if( dsFilter==null || 0 == dsFilter.size())
                        invalidLots = invalidLots + ";" + lots[i];
                    else{
                        if(dsFilter.size()>0){
                            String reagentstatus=dsFilter.getValue(0,"reagentstatus","");
                            if("Expired".equalsIgnoreCase(reagentstatus) || "Inactive".equalsIgnoreCase(reagentstatus) || "Depleted".equalsIgnoreCase(reagentstatus)){
                                expiredLots = expiredLots + ";" + lots[i];
                            }
                            else {
                                Calendar expDate = dsFilter.getCalendar(0, "expirydt");
                                if (expDate != null && expDate.compareTo(currentdate) < 0)
                                    expiredLots = expiredLots + ";" + lots[i];
                            }
                        }
                    }
                }
                if( !isNull(invalidLots) )
                    ajaxResponse.addCallbackArgument("err","Following reagent lots are invalid: "+ invalidLots.substring(1));
                else if( !isNull(expiredLots) )
                    ajaxResponse.addCallbackArgument("msg", expiredLots.substring(1));
            }
        }
        ajaxResponse.print();
    }

}
