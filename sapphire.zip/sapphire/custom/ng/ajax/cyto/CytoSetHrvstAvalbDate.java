package sapphire.custom.ng.ajax.cyto;

import sapphire.SapphireException;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CytoSetHrvstAvalbDate extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        //String input = ajaxResponse.getRequestParameter("input");
        DataSet dsSql = null;
        String sql = "";

        try {
            sql = Util.parseMessage(CytoSqls.POPULATE_DATE_FOR_ELIGIBLE_CULTURE);

            dsSql = getQueryProcessor().getSqlDataSet(sql);

            if (dsSql == null)
                Logger.logError("Unable to connect to database to execute SQL: " + sql);
            else if (dsSql.size() > 0) {
                String scmid = dsSql.getColumnValues("u_sampleculturemapid", ";");

                try {
                    if (!Util.isNull(scmid)) {
                        sapphire.xml.PropertyList pl = new sapphire.xml.PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, scmid);
                        pl.setProperty("hrvstavlabldt", "n");
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    }

                } catch (Exception e) {
                    Logger.logError("Error while updating movetohrvst column in SampleCultureMap. ");

                }
            }

        } catch (Exception e) {
            Logger.logError(e.getMessage());
        } finally {
            ajaxResponse.addCallbackArgument("msg", "success");
            ajaxResponse.print();
        }

    }
}
