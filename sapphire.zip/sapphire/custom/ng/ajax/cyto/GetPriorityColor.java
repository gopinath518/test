package sapphire.custom.ng.ajax.cyto;

import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.M18NUtil;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Calendar;
import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by Subhendu on 12/19/2016.
 */
public class GetPriorityColor extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String priorityId = ajaxResponse.getRequestParameter("priorityId");
        ajaxResponse.addCallbackArgument("err", "");
        try{
	        if(!Util.isNull(priorityId)){
		        String sql = parseMessage(CytoSqls.GET_PRIORITY_COLOR );
		        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		        //ajaxResponse.addCallbackArgument("msg", ds.getValue(0, "cytoprioritycolor"));
		        if(ds != null && ds.size()>0){
			        ajaxResponse.addCallbackArgument("dataset", ds);
			        ajaxResponse.addCallbackArgument("size", ds.size());
		        }else{
		        	ajaxResponse.addCallbackArgument("dataset", "No DataSet Found");
		        }
	        }
        }catch(Exception e){
        	ajaxResponse.addCallbackArgument("err", "Error getting color code");
        }
        ajaxResponse.print();
    }

}
