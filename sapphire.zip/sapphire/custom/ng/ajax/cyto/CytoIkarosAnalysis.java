package sapphire.custom.ng.ajax.cyto;

import sapphire.SapphireException;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.File;
import java.util.*;

import static sapphire.custom.ng.util.Util.isNull;

/**
 * This Ajax returns an array of file name by reading a file path in the server.
 * The said file path is used to store pending files for IKAROS analysis.
 */

public class CytoIkarosAnalysis  extends BaseAjaxRequest {

    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String fpsampleid = ajaxResponse.getRequestParameter("fpid");

        try {
            if (Util.isNull(fpsampleid)) {
                throw new SapphireException("FreshPrep Sample ID not found");
            }
            DataSet ds = new DataSet();
            ds.addColumn("fpsampleid", DataSet.STRING);
            ds.addColumn("slideid", DataSet.STRING);
            ds.addColumn("imgno", DataSet.STRING);
            ds.addColumn("filename", DataSet.STRING);

            String ikrosLabvantagePath = getLabvantageShareFolderPathIkros();
            if (Util.isNull(ikrosLabvantagePath)) {
                throw new SapphireException("ikros Labvantage Path not found");
            }
            String fileName = "";
            File folder = new File(ikrosLabvantagePath);
            File[] listOfFiles = folder.listFiles();

            if (listOfFiles.length > 0) {
                for (File file : listOfFiles) {
                    try {
                        if (file.isFile()) {
                            fileName = file.getName();
                            if(fileName.contains(fpsampleid)) {
                                String tempFileName = createFileNameForParsing(fileName);
                                String[] tempArr = StringUtil.split(tempFileName, "@*@");

                                String fpid = tempArr[0];
                                String slideId = tempArr[1];
                                String imgno = tempArr[2];
                                if(fpid.equalsIgnoreCase(fpsampleid)) {
                                    int rowId = ds.addRow();
                                    ds.setValue(rowId, "fpsampleid", fpid);
                                    ds.setValue(rowId, "slideid", slideId);
                                    ds.setValue(rowId, "imgno", imgno);
                                    ds.setValue(rowId, "filename", fileName);
                                }
                            }

                        }
                    } catch (Exception e) {
                        Logger.logInfo("Error in reading Ikaros folder: " + e.toString());
                        throw new SapphireException(e.getMessage());
                    }
                }
            }

            if (ds.size() > 0) {
                ajaxResponse.addCallbackArgument("dataset", ds);
            } else
                ajaxResponse.addCallbackArgument("dataset", "No Data Found");


        }catch (Exception exp){
            ajaxResponse.setError(exp.getMessage());
        }
        finally{
            ajaxResponse.print();
        }
    }

    /**
     * This method returns the File path for pending files for IKAROS analysis
     * @return file path
     * @throws SapphireException
     */

    private String getLabvantageShareFolderPathIkros() throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "ikros.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    /**
     * This method returns a file name in the format <FP sample id>@*@<Slide ID>@*@<File number>
     * @param fileName
     * @return file name in the above format
     * @throws SapphireException
     */

    private String createFileNameForParsing(String fileName) throws SapphireException {

        String tempFileName = "";
        List<String> delimeterList = new ArrayList<String>(); // to store probable delimeter list from Policy
        //List<String> extensionList = new ArrayList<String>(); // to store probable extension list from Policy
        Map<String,Integer> colIndexMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy

        PropertyList filePolicyProperties = getConfigurationProcessor().getPolicy("CytoMeteferFilePatternPolicy", "IkarosFileFormat");
        PropertyList pl = filePolicyProperties.getPropertyList("filepattern");

        PropertyListCollection delimeterColl = pl.getCollection("filepatterncollection");
        PropertyListCollection columnIndexColl = pl.getCollection("ColumnIndex");
        //PropertyListCollection extensioncoll = pl.getCollection("extensioncoll");

        for (int i = 0; i < delimeterColl.size(); i++)
            delimeterList.add(delimeterColl.getPropertyList(i).getProperty("delimeter"));

      /*  for (int i = 0; i < extensioncoll.size(); i++)
            extensionList.add(extensioncoll.getPropertyList(i).getProperty("extensiontype"));*/

        for (int i = 0; i < columnIndexColl.size(); i++)
            colIndexMap.put(columnIndexColl.getPropertyList(i).getProperty("column"),
                    Integer.parseInt(columnIndexColl.getPropertyList(i).getProperty("index")));

        try {
            tempFileName = fileName.substring(0, (fileName.lastIndexOf(".")));
        } catch (Exception se){
            throw new SapphireException("No Proper extension found for the scanned file.\n"+fileName);
        }

        for(String s:delimeterList){
            if(tempFileName.contains(s)) {
                tempFileName= StringUtil.replaceAll(tempFileName,s.trim(),"@*@");
            }
        }

        if(!tempFileName.contains("@*@"))
            throw new SapphireException("No Proper delimeter defined in the policy for the scanned file.\n"+fileName);

        String[] tempArr = StringUtil.split(tempFileName, "@*@");

        String fsampleId = "";
        String slideId = "";
        String noOfslideCopy = "";

        Set<String> set = colIndexMap.keySet();
        for(String str:set){
            if("freshprepid".equalsIgnoreCase(str)){
                int index = colIndexMap.get(str);
                fsampleId = tempArr[index];
            }
            else if("slideid".equalsIgnoreCase(str)){
                int index = colIndexMap.get(str);
                slideId = tempArr[index];
            }
            else if("copy".equalsIgnoreCase(str)){
                int index = colIndexMap.get(str);
                noOfslideCopy = tempArr[index];
            }

        }
        return (fsampleId+"@*@"+slideId+"@*@"+noOfslideCopy);
    }

}
