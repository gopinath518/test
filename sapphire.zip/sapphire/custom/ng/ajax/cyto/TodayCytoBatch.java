package sapphire.custom.ng.ajax.cyto;

import sapphire.SapphireException;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.M18NUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Calendar;
import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by dkundu on 1/26/2017.
 */
public class TodayCytoBatch extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        ajaxResponse.addCallbackArgument("err", "empty");
        ajaxResponse.addCallbackArgument("msg", "empty");
        try {
            String batchtype = ajaxResponse.getRequestParameter("batchtype");
            String returnType = ajaxResponse.getRequestParameter("returntype");
            String orgprocesstype = ajaxResponse.getRequestParameter("orgprocesstype");
            String forpndnglistquery = ajaxResponse.getRequestParameter("forpndnglistquery");
            ajaxResponse.addCallbackArgument("orgprocesstype", orgprocesstype);
            DataSet dsTodayBatch = null;
            if (isNull(batchtype))
                throw new Exception("No batch type found in input configuration");

            Calendar systemDate = new M18NUtil().getNowCalendar();
            if(Util.isNull(forpndnglistquery))
                dsTodayBatch = getQueryProcessor().getSqlDataSet(parseMessage(CytoSqls.GET_TODAY_BATCH_WITH_SCMID , batchtype , batchtype));
            else
                dsTodayBatch = getQueryProcessor().getSqlDataSet(parseMessage(CytoSqls.GET_PENDING_LIST_SCMID , batchtype , batchtype));
            if (dsTodayBatch == null)
                throw new Exception("Error: Unable to perform query in database");
            else if (dsTodayBatch.size() == 0)
                logger.info("No batch found");
            else {
                dsTodayBatch.addColumn("showbatch", DataSet.STRING);
                for (int i = 0; i < dsTodayBatch.size(); i++) {
                    String releaseTimeZone = dsTodayBatch.getValue(i, "releaselocale");
                    if (isNull(releaseTimeZone))
                        dsTodayBatch.setValue(i, "showbatch", "Y");
                    else {
                        String availableTime = dsTodayBatch.getValue(i, "hours");
                        if (isVisible(Util.convertToTimeZoneHrs(systemDate, releaseTimeZone), availableTime)) {
                            dsTodayBatch.setValue(i, "showbatch", "Y");
                        }
                    }
                }
                HashMap hmFilter = new HashMap();
                hmFilter.put("showbatch","Y");
                String returnValue = null;
                DataSet filtrDsTodayBatch=dsTodayBatch.getFilteredDataSet(hmFilter);

                if(filtrDsTodayBatch!=null && filtrDsTodayBatch.size()>0) {
                    if ("batch".equalsIgnoreCase(returnType))
                        returnValue = filtrDsTodayBatch.getColumnValues("u_cytobatchid", ";");
                    else
                        returnValue = filtrDsTodayBatch.getColumnValues("u_sampleculturemapid", ";");

                    DataSet result=new DataSet();
                    for(int i=0;i<filtrDsTodayBatch.size();i++){
                        Calendar hrvstavlabldt=filtrDsTodayBatch.getCalendar(i,"hrvstavlabldt",null);
                        if(hrvstavlabldt==null)
                            result.copyRow(filtrDsTodayBatch,i,1);
                    }

                    if(result!=null && result.size()>0) {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, result.getColumnValues("u_sampleculturemapid", ";"));
                        pl.setProperty("hrvstavlabldt", "n");
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    }
                }

                if(!isNull(returnValue))
                    ajaxResponse.addCallbackArgument("msg", returnValue);

            }
        } catch (Exception e) {
            ajaxResponse.addCallbackArgument("err", e.getMessage());
        } finally {
            ajaxResponse.print();
        }
    }

    private boolean isVisible(String systemTime, String availableTime) throws SapphireException {
        if(isNull(availableTime))
            return true;
        String[] arrSysTime = systemTime.split(":");
        String[] arrAvailTime = availableTime.split(":");
        Integer numSysTime = ( Integer.parseInt(arrSysTime[0]) * 60 ) + Integer.parseInt(arrSysTime[1]);
        Integer numAvailTime = ( Integer.parseInt(arrAvailTime[0]) * 60 ) + Integer.parseInt(arrAvailTime[1]);
        if(numSysTime >= numAvailTime)
            return true;
        else
            return false;
    }
}
