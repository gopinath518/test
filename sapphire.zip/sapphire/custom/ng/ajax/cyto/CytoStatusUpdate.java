package sapphire.custom.ng.ajax.cyto;

import sapphire.SapphireException;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by aritra.banerjee on 6/5/2017.
 * This AJAX updates the status of the samples before Editing.
 * This AJAX is called from Tech 1 or Tech 2 or Case Review tramstop while Edit button is clicked.
 */
public class CytoStatusUpdate extends BaseAjaxRequest {


    @Override
    @SuppressWarnings({"rawtypes"})
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String current_user = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String casenumber = ajaxResponse.getRequestParameter("casenumber");
        String currentmovementstep = ajaxResponse.getRequestParameter("currentmovementstep");
        String status = ajaxResponse.getRequestParameter("status");
        String sqlOne = "";
        boolean flag = true;
        String fpsamples = "";

        /*if(status.equalsIgnoreCase("ReturnToList")){
            if(!Util.isNull(casenumber)){
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, casenumber);
                props.setProperty("u_cytopagelockflag", "(null)");

                try{
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (Exception e) {
                    ajaxResponse.addCallbackArgument("msg", " Unable to remove page lock configuration.Please Contact your Administrator.");
                    ajaxResponse.print();
                    return;
                }
                ajaxResponse.addCallbackArgument("msg", "success");
                ajaxResponse.print();
                return;
            }
        }

        String query = Util.parseMessage(CytoSqls.GET_PAGE_LOCK_DETAIL_BY_KEYID1, StringUtil.replaceAll(casenumber, ";", "','"));
        DataSet dssql = getQueryProcessor().getSqlDataSet(query);
        //if (dssql.size() > 0) {  -- need to commment out to implement lock again
        if (dssql.size() < 0) {
            ajaxResponse.addCallbackArgument("msg", " Some of the selected case(s) are already being investigated currently by other users.");
            ajaxResponse.print();
            return;
        } else {
            if(!Util.isNull(casenumber)){
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, casenumber);
                props.setProperty("u_cytopagelockflag", "Y");

                try{
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (Exception e) {
                    ajaxResponse.addCallbackArgument("msg", " Unable to implement page lock configuration.Please Contact your Administrator.");
                    ajaxResponse.print();
                    return;
                }
            }*/

            if ("CytoTech1".equalsIgnoreCase(currentmovementstep) || "CytoTech2".equalsIgnoreCase(currentmovementstep)) {
                if ("CytoTech1".equalsIgnoreCase(currentmovementstep))
                    sqlOne = Util.parseMessage(CytoSqls.GET_IMGANALYSISPNDNGCOUNT_BY_PARENT_FOR_TECH1, StringUtil.replaceAll(casenumber, ";", "','"));
                if ("CytoTech2".equalsIgnoreCase(currentmovementstep))
                    sqlOne = Util.parseMessage(CytoSqls.GET_IMGANALYSISPNDNGCOUNT_BY_PARENT_FOR_TECH2, StringUtil.replaceAll(casenumber, ";", "','"));

                DataSet dssqlOne = getQueryProcessor().getSqlDataSet(sqlOne);
                if (dssqlOne == null) {
                    ajaxResponse.addCallbackArgument("msg", "Unable to execute query. " + sqlOne);
                    ajaxResponse.print();
                    return;
                }

                if (dssqlOne.size() != 0) {
                    flag = false;
                    fpsamples = dssqlOne.getColumnValues("org", ",");
                }

            }

            if (flag) {
                String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TAKE_CUSTODY, currentmovementstep, StringUtil.replaceAll(casenumber, ";", "','"));
                try {
                    DataSet ds = getQueryProcessor().getSqlDataSet(sql);
                    if ((ds != null) && (ds.size() > 0)) {
                        String childsamples = "";
                        for(int i=0;i<ds.size();i++){
                            String cytostatus = ds.getValue(i,"u_cytostatus","");
                            if(!"Reported".equalsIgnoreCase(cytostatus)){
                                childsamples += ";" + ds.getValue(i,"childsampleid","");
                            }
                        }
                        if(childsamples.startsWith(";"))
                            childsamples = childsamples.substring(1);

                        if (!Util.isNull(childsamples)) {

                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                            pl.setProperty(EditSDI.PROPERTY_KEYID1, childsamples);
                            pl.setProperty("u_cytostatus", status);
                            if (("CytoDirectorSignOut".equalsIgnoreCase(currentmovementstep)))
                                pl.setProperty("u_assignedcytodirector", current_user);

                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                            if (!"CytoDirectorSignOut".equalsIgnoreCase(currentmovementstep)) {
                                try {
                                    PropertyList autoCustodyProp = new PropertyList();
                                    autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsamples, ";", true));

                                    getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
                                } catch (SapphireException ex) {
                                    throw new SapphireException("Unable to take custody. Reason: " + ex.getMessage());
                                }
                            }

                        }
                        ajaxResponse.addCallbackArgument("msg", "success");
                    }

                } catch (Exception e) {
                    ajaxResponse.addCallbackArgument("msg", "Unable to update status of this sample...Please contact Admin.");
                } finally {
                    ajaxResponse.print();
                }
            } else {
                ajaxResponse.addCallbackArgument("msg", "IKAROS Software is accessing the images file for the sample(s) - \n" + fpsamples);
                ajaxResponse.print();
            }
        }

    }
