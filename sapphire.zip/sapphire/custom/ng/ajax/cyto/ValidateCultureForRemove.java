package sapphire.custom.ng.ajax.cyto;

import static sapphire.custom.ng.util.Util.parseMessage;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sapphire.SapphireException;
import sapphire.action.DeleteSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by Subhendu on 12/28/2016.
 */
public class ValidateCultureForRemove extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String keyid1 = StringUtil.replaceAll(ajaxResponse.getRequestParameter("keyid1"),"|",";");
        String culturetypeid = StringUtil.replaceAll(ajaxResponse.getRequestParameter("culturemapid"),"|",";");
        String parentSample = ajaxResponse.getRequestParameter("parentsampleid");

        try{

			String disputedCultureList = "";
			/*String sql = Util.parseMessage(CytoSqls.CULTURE_REMOVE_VALIDATION_SQL,parentSample,StringUtil.replaceAll(culturetypeid,";","','"));
			DataSet ds = getQueryProcessor().getSqlDataSet(sql);
			if(ds==null)
				throw new SapphireException("Culture info can not be obtained from database.");
			if(ds!=null && ds.size()>0){
				for(int i=0;i<ds.size();i++){
					String tempCutureId = ds.getValue(i,"culturetypeid","");
					String tempOrgCutureId = ds.getValue(i,"orgculturetype","");
					String tempOperation = ds.getValue(i,"operation","");
					String tempCnt = ds.getValue(i,"cnt","0");
					String tempOrgCnt = ds.getValue(i,"orgcnt","0");
					if(Util.isNull(tempOperation) && Integer.parseInt(tempOrgCnt)>0)
						disputedCultureList+=";"+tempCutureId;
					else if(!Util.isNull(tempOperation)){
						if("Reset".equalsIgnoreCase(tempOperation)){
							if(Integer.parseInt(tempCnt)>=2 && !(tempOrgCutureId+"-RS"+tempCnt).equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
							else if(Integer.parseInt(tempCnt)==1 && !(tempOrgCutureId+"-RS").equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
						}
						else if("reharvest".equalsIgnoreCase(tempOperation)){
							if(Integer.parseInt(tempCnt)>=2 && !(tempOrgCutureId+"-RH"+tempCnt).equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
							else if(Integer.parseInt(tempCnt)==1 && !(tempOrgCutureId+"-RH").equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
						}
						else if("redrop".equalsIgnoreCase(tempOperation)){
							if(Integer.parseInt(tempCnt)>=2 && !(tempOrgCutureId+"-RD"+tempCnt).equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
							else if(Integer.parseInt(tempCnt)==1 && !(tempOrgCutureId+"-RD").equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
						}
						else if("subculture".equalsIgnoreCase(tempOperation)){
							if(!(tempOrgCutureId+"-"+tempCnt).equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
						}
						else if("Duplicate".equalsIgnoreCase(tempOperation)){
							if(!(tempOrgCutureId+"-"+('A'+Integer.parseInt(tempCnt)-1)).equalsIgnoreCase(tempCutureId))
								disputedCultureList+=";"+tempCutureId;
						}
					}
				}
			}*/
	        if(!Util.isNull(disputedCultureList)) { // if the list is empty then user have selected the last culture or flask
				if(disputedCultureList.startsWith(";"))
					disputedCultureList=disputedCultureList.substring(1);
				ajaxResponse.addCallbackArgument("msg", "Below culture(s) can not be removed.\n"+disputedCultureList+"\nReason: Either the selected culture(s) " +
						"are having child cultures or it is not the last one that has been created due to any of the repeat operations.");
			}
	        else
	        	ajaxResponse.addCallbackArgument("msg", removeSelectedCulture(keyid1,parentSample));
	        	
        }catch(Exception e){
        	ajaxResponse.addCallbackArgument("msg", "Error obtained.\nReason: "+e.getMessage());
        }
        ajaxResponse.print();
    }
    
    private String removeSelectedCulture(String sampleIds, String parentSample){
    
		try {
			PropertyList props = new PropertyList();
			props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleCultureMap");
	        props.setProperty(DeleteSDI.PROPERTY_KEYID1, sampleIds);
	        props.setProperty("parentsampleid", parentSample);
	        getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
	        return "";
		} catch (SapphireException e) {
			return "Error occured while removing culture";
		}
    }

}
