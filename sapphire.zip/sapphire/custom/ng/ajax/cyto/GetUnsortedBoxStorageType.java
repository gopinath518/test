package sapphire.custom.ng.ajax.cyto;

import com.labvantage.sapphire.xml.Node;
import com.labvantage.sapphire.xml.NodeList;
import com.labvantage.sapphire.xml.PropertyTree;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;

public class GetUnsortedBoxStorageType extends BaseAjaxRequest {
    public GetUnsortedBoxStorageType() {
    }

    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        HashMap<String, JSONObject> map = new HashMap();
        String sql = Util.parseMessage(CytoSqls.GET_PROPERTY_BY_PROPERTY_TYPE);
        DataSet ds = this.getQueryProcessor().getSqlDataSet(sql, true);
        if (ds != null) {
            for(int i = 0; i < ds.size(); ++i) {
                String propertytreeid = ds.getString(i, "propertytreeid");

                try {
                    String valuetree = ds.getClob(i, "valuetree");
                    PropertyTree tree = new PropertyTree(propertytreeid);
                    tree.setValueXML(valuetree);
                    NodeList nodeList = tree.getNodeList();
                    ArrayList allNodes = new ArrayList();
                    nodeList.getAllNodes(allNodes);

                    for(int j = 0; j < allNodes.size(); ++j) {
                        Node node = (Node)allNodes.get(j);
                        String nodeid = node.getNodeId();
                        if("UnSorted Box".equalsIgnoreCase(nodeid)) {
                            PropertyList propertyList = node.getPropertyList();
                            if (propertyList != null) {
                                propertyList.setProperty("propertytreeid", propertytreeid);
                                map.put(nodeid, propertyList.toJSONObject());
                            }
                        }
                    }
                } catch (SapphireException var17) {
                    var17.printStackTrace();
                }
            }
        }

        ajaxResponse.addCallbackArgument("map", map);
        ajaxResponse.print();
    }
}

