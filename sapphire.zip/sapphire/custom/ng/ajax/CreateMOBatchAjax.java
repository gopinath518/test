package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by dgupta on 6/9/2016.
 */
public class CreateMOBatchAjax extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String sampleids = ajaxResponse.getRequestParameter("sampleid");
        ajaxResponse.addCallbackArgument("msg", "empty");
        ajaxResponse.addCallbackArgument("batch", "empty");
        ajaxResponse.addCallbackArgument("err", "empty");
        if (sampleids.startsWith(";")) sampleids = sampleids.substring(1);
        String[] sampleArr = StringUtil.split(sampleids, ";");
        String newbatch = "";
        logger.info("H&EBatching ", "samples and    " + sampleids);
        if (sampleids.length() == 0) {
            ajaxResponse.addCallbackArgument("err", "Please scan samples first");
        } else {
            try {

                DataSet dsSampleDb = getQueryProcessor().getSqlDataSet(Util.parseMessage(MultiomyxSql.MO_CREATEBATCH_VALIDATE_SAMPLE, StringUtil.replaceAll(sampleids, ";", "','")));

                if ((dsSampleDb.getRowCount() > 0) &&  (dsSampleDb.getRowCount() < 29)) {   //(dsSampleDb.getRowCount() == sampleArr.length) &&
                    String sample = dsSampleDb.getColumnValues("s_sampleid",";");
                    String uniqSample = Util.getUniqueList(sample,";",true);
                    String uniqSampleArr[] = uniqSample.split(";");
                    if (uniqSampleArr.length == sampleArr.length) {
                        String moqcpassed = dsSampleDb.getColumnValues("moqcpass",";");
                        String testcdCreatby = dsSampleDb.getColumnValues("crtbyrole",";");
                        if(!moqcpassed.contains("Y") && !testcdCreatby.contains("LabUser") ){
                            ajaxResponse.addCallbackArgument("err", "The panel is not QC passed.");
                        }
                        else {
                            newbatch = createNewBatch(""); // now new batch created with above batchtype
                            PropertyList plSempleStep = updateSampleStep(dsSampleDb, "");
                            createLastBatchDetail(sampleArr, StringUtil.split(newbatch, ";")[0], plSempleStep);
                            ajaxResponse.addCallbackArgument("msg", "New Batch created  '" + newbatch + "'");
                            ajaxResponse.addCallbackArgument("batch", newbatch);
                        }

                    } else
                        ajaxResponse.addCallbackArgument("err", "All or some samples are not Multiomyx sample OR Samples not found in system.");
                } else
                    ajaxResponse.addCallbackArgument("err", " Too many samples, maximum 28 samples allow in a batch.");
            } catch (Exception ex) {
                ex.printStackTrace();
                String error = getTranslationProcessor().translate("error while creating batch");
                error += ex.getMessage();
                ajaxResponse.addCallbackArgument("err", error);
            }
        }

        ajaxResponse.print();
    }

    private String createNewBatch(String batchType) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "MOBatch");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        return props.getProperty("newkeyid1", "");
    }


    private void createLastBatchDetail(String[] sampleArr, String newBatches, PropertyList plSempleStep) throws SapphireException {
        String detailBatch = "";
        String sampleids = "";
        String orderid = "";
        String sampleStatus = "";
        for (int j = 0; j < sampleArr.length; j++) {
            detailBatch = detailBatch + ";" + newBatches;
            sampleids = sampleids + ";" + sampleArr[j];
            orderid = orderid + ";" + (j + 1);
            sampleStatus = sampleStatus + ";" + "MOSlidePrep";
            ;
        }
        PropertyList plDetails = new PropertyList();
        plDetails.setProperty(AddSDI.PROPERTY_SDCID, "MODetailBatch");
        plDetails.setProperty("u_mobatchid", detailBatch.substring(1));
        plDetails.setProperty("mosampleid", sampleids.substring(1));  // no change for now
        plDetails.setProperty("usersequence", orderid.substring(1));  // no change for now
        plDetails.setProperty("status", sampleStatus.substring(1));  // no change for now
        plDetails.setProperty("copies", "" + sampleArr.length);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plDetails);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch Details" + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        return;
    }

    private PropertyList updateSampleStep(DataSet dsSampleTMap, String batchType) throws SapphireException {
        PropertyList plEditSample = new PropertyList();
        String sampleAll = Util.getUniqueList(dsSampleTMap.getColumnValues("s_sampleid",";"), ";", true);
        String sampleArr[] = sampleAll.split(";");
        String sampleStatus = "MOSlidePrep";
        String sampleStatusA = "";
        for (int i = 0; i < sampleArr.length; i++) {
            sampleStatusA += (";" + sampleStatus);
        }
        sampleStatusA = sampleStatusA.substring(1);
        plEditSample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        plEditSample.setProperty(EditSDI.PROPERTY_KEYID1, sampleAll);
        plEditSample.setProperty("u_currentmovementstep", sampleStatusA);

        //updateTrackItem( dsSampleTMap,sampleStatusA);
        return plEditSample;
    }

    /*private void updateTrackItem(DataSet dsSampleTMap, String sampleStatusA) throws SapphireException {
        String defaultdepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String dept = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));
        String custodialdept = dept + "-MultiOmyx";
        if (!Util.validateDepartment(custodialdept, getQueryProcessor(), getTranslationProcessor()))
            throw new SapphireException("Error: Department: " + custodialdept + " does not exist");

        PropertyList editTIProps = new PropertyList();

        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSampleTMap.getColumnValues("s_sampleid", ";"));
        editTIProps.setProperty("u_currenttramstop", sampleStatusA);
        editTIProps.setProperty("custodialdepartmentid", StringUtil.repeat(custodialdept, dsSampleTMap.size(), ";"));
       *//* try {
           // getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
*//*
    }*/


}
