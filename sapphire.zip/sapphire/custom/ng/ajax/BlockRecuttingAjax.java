package sapphire.custom.ng.ajax;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by SBaitalik on 9/23/2016.
 * Description: This class used for re-cutting the block, s_sample and RepeatOpsRequest SDCs are populated.
 */
public class BlockRecuttingAjax extends BaseAjaxRequest {

    AjaxResponse ajaxResponse;

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        //AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String inputdata = ajaxResponse.getRequestParameter("inputdata");
        initializeDataSet();
        if (Util.isNull(inputdata)) {
            try {
                jsonResponse.put(RESPONSE_PARAM_ISVALID, "n");
                jsonResponse.put(RESPONSE_PARAM_MESSAGE_TYPE, "blankInput");
                jsonResponse.put(RESPONSE_PARAM_MESSAGE, "You have entered blank input.");
                ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                ajaxResponse.print();
            } catch (JSONException es) {
                es.printStackTrace();
            }
            return;
        }
        validateInput(inputdata);

    }

    /**
     * Description: This method is used for validate input from page and parse the json data. JSONArray contains blockid,incidentrequestid, noofslide, fromdepartment.
     * Generate keyid1 and populate the data into s_sample and RepeatOpsRequest SDCs
     *
     * @param inputdata it contains input(blockid,incidentrequestid, noofslide, fromdepartment) into JSONArray.
     *
     */
    private void validateInput(String inputdata) {
        if (inputdata != "" || inputdata != null) {

            try {
                String newkeyid1 = "";
                String sampleidsr = "";
                String blockidd = "";
                JSONArray jsonArray = new JSONArray(inputdata);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jObj = (JSONObject) jsonArray.getJSONObject(i);
                    String blockid = jObj.getString("blockid");
                    blockidd = jObj.getString("blockid");
                    String incidentrequestid = jObj.getString("incidentrequestid");
                    String noofslide = jObj.getString("noofslide");
                    String fromdepartment = jObj.getString("fromdepartment");
                    if (Util.isNull(blockid)) {
                        return;
                    }
                    if (Util.isNull(incidentrequestid)) {
                        return;
                    }
                    if (Util.isNull(noofslide)) {
                        return;
                    }
                    PropertyList prop = new PropertyList();
                    prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, blockid);
                    prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, noofslide);//TODO number of slides is 0 into the RepeatOpsRequest SDC, (noofslide)
                    prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");
                    //prop.setProperty("u_type","U");
                    //prop.setProperty("sstudyid", "NeoClinical"); ///TODO Hadcoded need to remove later
                    //prop.setProperty("u_currentmovementstep", "Setup");
                    prop.setProperty("copydowncolumns", "sstudyid;u_currentmovementstep;");
                    //prop.setProperty("u_type", "U");


                    try {
                        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
                    } catch (SapphireException e) {
                        jsonResponse.put(RESPONSE_PARAM_ISVALID, "n");
                        jsonResponse.put(RESPONSE_PARAM_MESSAGE_TYPE, "childSampleSdc");
                        jsonResponse.put(RESPONSE_PARAM_MESSAGE, "Child Sample not Created.");
                        ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                        ajaxResponse.print();
                        return;
                    }
                    newkeyid1 = prop.getProperty("newkeyid1");
                    sampleidsr = sampleidsr + ";" + prop.getProperty("newkeyid1");
                    String sampleids[] = StringUtil.split(newkeyid1, ";");

                    PropertyList propSample = new PropertyList();
                    propSample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    propSample.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid1);
                    propSample.setProperty("u_type", StringUtil.repeat("U", sampleids.length, ";"));
                    propSample.setProperty("u_currentmovementstep", StringUtil.repeat("Microtomy", sampleids.length, ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propSample);

                    for (int s = 0; s < sampleids.length; s++) {
                        int rowId = dsInput.addRow();
                        dsInput.setValue(rowId, DATASET_PROPERTY_INCIDENT_REQUEST_ID, incidentrequestid);
                        //dsInput.setValue(rowId, DATASET_PROPERTY_NO_OF_SLIDE, String.valueOf(rowId+1));//TODO number of slides is 0 into the RepeatOpsRequest SDC, (noofslide)
                        dsInput.setValue(rowId, DATASET_PROPERTY_OPERATIONS, "Re-Extract");
                        dsInput.setValue(rowId, DATASET_PROPERTY_FROM_DEPARTMENT, fromdepartment);
                        dsInput.setValue(rowId, DATASET_PROPERTY_TO_DEPARTMENT, "FM-Histology");
                        dsInput.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID, sampleids[s]);
                    }
                }
                PropertyList propRecutting = new PropertyList();
                propRecutting.setProperty(AddSDI.PROPERTY_SDCID, "RepeatOpsRequest");
                propRecutting.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsInput.getRowCount())/*dsFinal.getColumnValues(DATASET_PROPERTY_NO_OF_SLIDE, ";")*/);
                propRecutting.setProperty(DATASET_PROPERTY_SAMPLE_ID, dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
                //propRepeat.setProperty(DATASET_PROPERTY_FROM_DEPARTMENT, dsFinal.getColumnValues(DATASET_PROPERTY_FROM_DEPARTMENT, ";"));
                propRecutting.setProperty(DATASET_PROPERTY_TO_DEPARTMENT, dsInput.getColumnValues(DATASET_PROPERTY_FROM_DEPARTMENT, ";"));
                propRecutting.setProperty(DATASET_PROPERTY_INCIDENT_REQUEST_ID, dsInput.getColumnValues(DATASET_PROPERTY_INCIDENT_REQUEST_ID, ";"));
                //propRepeat.setProperty(DATASET_PROPERTY_NO_OF_SLIDE, dsFinal.getColumnValues(DATASET_PROPERTY_NO_OF_SLIDE, ";"));
                propRecutting.setProperty(DATASET_PROPERTY_OPERATIONS, dsInput.getColumnValues(DATASET_PROPERTY_OPERATIONS, ";"));

                jsonResponse.put(RESPONSE_PARAM_ISVALID, "y");
                jsonResponse.put(RESPONSE_PARAM_KEYID1, sampleidsr.substring(1));
                jsonResponse.put(RESPONSE_PARAM_MESSAGE, "Re-cutting successful.");
                ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());

                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, propRecutting);
                } catch (ActionException ex) {
                    jsonResponse.put(RESPONSE_PARAM_ISVALID, "n");
                    jsonResponse.put(RESPONSE_PARAM_MESSAGE_TYPE, "recuttingFailed");
                    jsonResponse.put(RESPONSE_PARAM_MESSAGE, "Re-cutting failed.");
                    ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                    ajaxResponse.print();

                    return;
                }
                updateTrackItem(dsInput);//TODO NOT REQUIRED AS CONTAINER TYPE WILL COPYDOWN FROM PARENT
                updateRepeatOpsRequest(blockidd, dsInput);
                updateBlockCurrentMovStep(blockidd);

            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                ajaxResponse.print();
            }
        }

    }

    /**
     * Description: This method is used for update track item
     *
     * @param dsSampleFinal
     *
     */
    private void updateTrackItem(DataSet dsSampleFinal) {
        PropertyList editTIProps = new PropertyList();
        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
        editTIProps.setProperty("containertypeid", StringUtil.repeat("Block", dsInput.getRowCount(), ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ex) {

        }

    }

    /**
     * Description: This method is used for to update RepeatOpsRequest SDC by requestid
     *
     * @param blockidd It is the scanning block
     * @param dsInput  It is DataSet
     *
     */
    private void updateRepeatOpsRequest(String blockidd, DataSet dsInput) throws SapphireException {

        String sql = "select u_repeatopsrequestid from u_repeatopsrequest where sampleid ='" + blockidd + "' and incidentrequestid in ('" + StringUtil.replaceAll(dsInput.getColumnValues(DATASET_PROPERTY_INCIDENT_REQUEST_ID, ";"), ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String repeatopsrequestid = ds.getColumnValues("u_repeatopsrequestid", ";");
        String reqlength[] = StringUtil.split(repeatopsrequestid, ";");
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "RepeatOpsRequest");
        props.setProperty(EditSDI.PROPERTY_KEYID1, repeatopsrequestid);
        props.setProperty("isrecutpending", StringUtil.repeat("N", reqlength.length, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("Cutting not done");
        }
    }
    /**
     * Description: This method is used for to update RepeatOpsRequest SDC by requestid
     *
     * @param blockidd It is the scanning block
     * @throws  SapphireException
     *
     */
    private void updateBlockCurrentMovStep(String blockidd) throws SapphireException{
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, blockidd);
        props.setProperty("u_currentmovementstep", "BlockRoomCOC");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("Current Movement Step is not updated for Block.");
        }

    }


    private DataSet dsFinal = null;
    private DataSet dsInput = null;
    private JSONObject jsonResponse = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "sampleid";
    private static final String DATASET_PROPERTY_INCIDENT_REQUEST_ID = "incidentrequestid";
    private static final String DATASET_PROPERTY_NO_OF_SLIDE = "noofslide";
    private static final String DATASET_PROPERTY_FROM_DEPARTMENT = "fromdepartment";
    private static final String DATASET_PROPERTY_TO_DEPARTMENT = "todepartment";
    private static final String DATASET_PROPERTY_OPERATIONS = "operations";

    private static final String RESPONSE_PARAM_ISVALID = "isValid";
    private static final String RESPONSE_PARAM_MESSAGE = "message";
    private static final String RESPONSE_PARAM_KEYID1 = "keyid1";
    private static final String RESPONSE_PARAM_MESSAGE_TYPE = "msgType";

    /**
     * Description: This method is only used for initialing dataset and JSONObject
     */
    private void initializeDataSet() {

        if (dsFinal == null) {
            dsFinal = new DataSet();
            jsonResponse = new JSONObject();
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_INCIDENT_REQUEST_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_NO_OF_SLIDE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_FROM_DEPARTMENT, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_TO_DEPARTMENT, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_OPERATIONS, DataSet.STRING);


        }
        if (dsInput == null) {
            dsInput = new DataSet();
            dsInput.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_INCIDENT_REQUEST_ID, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_NO_OF_SLIDE, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_FROM_DEPARTMENT, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_TO_DEPARTMENT, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_OPERATIONS, DataSet.STRING);


        }
    }

}
