package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by kshahbaz on 6/8/2016.
 */
public class CreateBatch  extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        if(ajaxResponse!=null) {
            String reginfo = ajaxResponse.getRequestParameter("reginfo","");
            String sampinfo = ajaxResponse.getRequestParameter("sampinfo","");
            String ctrlinfo = ajaxResponse.getRequestParameter("ctrlinfo","");
            String batchname = ajaxResponse.getRequestParameter("batchname","");
            String batchtype = ajaxResponse.getRequestParameter("batchtype","");


            PropertyList pl = new PropertyList();
            pl.setProperty("reginfo", reginfo);
            pl.setProperty("sampinfo", sampinfo);
            pl.setProperty("ctrlinfo", ctrlinfo);
            pl.setProperty("batchname", batchname);
            pl.setProperty("batchtype", batchtype);

            boolean errFlg=false;
            String errMsg = "";
            if(!Util.isNull(batchname) && !Util.isNull(batchtype)) {
                try {
                    getActionProcessor().processAction("AddBatch", "1", pl);
                } catch (ActionException e) {
                    logger.debug(e.getMessage());
                    errFlg=true;
                    errMsg=e.getMessage();
                } finally {
                    if(!errFlg)
                        ajaxResponse.addCallbackArgument("msg", "Batch "+batchname+" has been created successfully.");
                    else{
                        ajaxResponse.addCallbackArgument("msg", "Batch cannot be created.\nReason: "+errMsg);
                    }
                    ajaxResponse.print();
                }
            }
            else{
                if(Util.isNull(batchname))
                    logger.debug("Batch name is not found");
                if(Util.isNull(batchtype))
                    logger.debug("Batch Type is not found");
            }
        }
    }
}
