package sapphire.custom.ng.ajax;

import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by mpandey on 5/16/2016.
 * * Action Name- CheckOutBasket
 * Description: This Action is created to checkout basket from retort
 * <p/>
 * Mandatory inputs
 * param1-basketid
 * throws SapphireException
 */
public class CheckOutBasket extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String basketid = ajaxResponse.getRequestParameter("basketid");
        String queBasket = StringUtil.replaceAll(basketid, ";", "','");
        String sql = "select trackitemid,CURRENTSTORAGEUNITID from TRACKITEM where linkkeyid1 in ('" + queBasket + "') and linksdcid= 'Basket'";
        DataSet dsBasket = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasket.getRowCount() == 0) {
            ajaxResponse.addCallbackArgument("msg", "TrackItem not define for Basket");
            ajaxResponse.print();
            return;
        }
        String trackitemid = dsBasket.getColumnValues("trackitemid", ";");

        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("CURRENTSTORAGEUNITID", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            ajaxResponse.addCallbackArgument("msg", "Baskets Checked out from Retort");
            //ajaxResponse.print();

        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move Basket out of Retort ");
            error += ae.getMessage();
            //ajaxResponse.setError(error);
            ajaxResponse.addCallbackArgument("msg", error);
        }
        finally {
            ajaxResponse.print();
        }
    }


}

