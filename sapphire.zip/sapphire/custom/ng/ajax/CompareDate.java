package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.QueryProcessor;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by kshahbaz on 5/1/2016.
 * This action is valiating collection date whether it is future or current or past date.
 * Mandatory input:
 * param1:collectiondt
 */
public class CompareDate extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String collectiondt = ajaxResponse.getRequestParameter("collectiondt");


        // Its check whether collection date is null or not.
        if (collectiondt == null || collectiondt == "") {
            String error = getTranslationProcessor().translate("Please select a collection date");
            ajaxResponse.addCallbackArgument("msg", error);
        }
        Date dt;
        Date dt1 = new Date();
        DataSet ds = new DataSet(getConnectionProcessor().getConnectionInfo(""));
        ds.addColumnValues("collectiondate", DataSet.DATE, collectiondt, ";");
        dt = ds.getCalendar(0, "collectiondate").getTime();
        try {
            if (dt.compareTo(dt1) > 0) {
                ajaxResponse.addCallbackArgument("msg", "After");
            } else if (dt.compareTo(dt1) < 0) {
                ajaxResponse.addCallbackArgument("msg", "Before");
            } else {
                ajaxResponse.addCallbackArgument("msg", "Equal");
            }
        } catch (Exception e) {
            String error = getTranslationProcessor().translate("Validation Error");
            error += e.getMessage();
            ajaxResponse.addCallbackArgument("msg", error);
        } finally {
            ajaxResponse.print();
        }
    }
}
