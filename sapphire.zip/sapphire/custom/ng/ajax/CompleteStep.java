package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Action Name- CompleteStep
 * Description: This Action is created to mark current step as complete.
 *
 * Mandatory inputs
 * param1-sampleid
 * param2-nextstep
 * param2-currentstep
 * param2-stepaction
 * throws SapphireException
 * Created by kshahbaz on 4/29/2016.
 * modified by mpandey
 */
public class CompleteStep extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        String nextstep = ajaxResponse.getRequestParameter("nextstep");
        String currentstep = ajaxResponse.getRequestParameter("currentstep");
        String stepaction = ajaxResponse.getRequestParameter("stepaction");

        PropertyList hsComplteStep = new PropertyList();
        hsComplteStep.clear();
        hsComplteStep.setProperty("sampleid",sampleid);
        hsComplteStep.setProperty("nextstep",nextstep);
        hsComplteStep.setProperty("currentstep",currentstep);
        hsComplteStep.setProperty("stepaction",stepaction);

        try {
            getActionProcessor().processAction("CompleteStep", "1", hsComplteStep);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed CompleteStep ");
            try {
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            } catch (SapphireException e1) {
                e1.printStackTrace();
            }
        }
       // PropertyList props = new PropertyList();

/*        try {
            getActionProcessor().processAction("CompleteStep","1", props);
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
            ajaxResponse.addCallbackArgument("msg",e.getMessage());
        } finally {
            ajaxResponse.addCallbackArgument("msg","Status Update Sucessfully.");
            ajaxResponse.print();
        }*/
      /*  try {
            props.setProperty(AddSDI.PROPERTY_SDCID, "SampleMovementSteps");
            props.setProperty(AddSDI.PROPERTY_COPIES, "1");

            props.setProperty("sampleid", sampleid);
            props.setProperty("completedstep", currentstep + "completed");
            props.setProperty("completedby", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
            props.setProperty("userdepartment", getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
            props.setProperty("completeddt","n");
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);

            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("u_currentmovementstep", nextstep);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);


        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move next step");
            error += ae.getMessage();
            ajaxResponse.setError(error);
            ajaxResponse.addCallbackArgument("msg",error);
        } finally {
            ajaxResponse.addCallbackArgument("msg","Status Update Sucessfully.");
            ajaxResponse.print();
        }*/
        }



}

