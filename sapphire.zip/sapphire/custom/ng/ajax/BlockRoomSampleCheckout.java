package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by akumar on 2/16/2017.
 */
public class BlockRoomSampleCheckout extends BaseAjaxRequest {
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        String departmentid = ajaxResponse.getRequestParameter("departmentid");
        String reason = ajaxResponse.getRequestParameter("reason");
        String currentmovementstep = ajaxResponse.getRequestParameter("currentmovementstep");
        PropertyList prop = new PropertyList();
        prop.setProperty("sampleid", sampleid);
        prop.setProperty("departmentid", departmentid);
        prop.setProperty("reason", reason);
        prop.setProperty("currentmovementstep", currentmovementstep);
        try {
            getActionProcessor().processAction("CheckOutBlockNRoute", "1", prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't checkout Samples from Block Room");
            error += ae.getMessage();
            ajaxResponse.addCallbackArgument("msg", error);
            ajaxResponse.print();
        }
        ajaxResponse.addCallbackArgument("msg", "Samples " + sampleid + " are successfully checked out.");
        ajaxResponse.print();
        
    }
}
