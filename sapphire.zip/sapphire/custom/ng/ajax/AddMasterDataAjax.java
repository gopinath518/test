package sapphire.custom.ng.ajax;

import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by SBaitalik on 1/4/2017.
 */
public class AddMasterDataAjax extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String tabletype = ajaxResponse.getRequestParameter("tabletype", "");
        String accessionid = ajaxResponse.getRequestParameter("accessionid", "");
        if ("add_patient_details".equalsIgnoreCase(tabletype)) {
            String add_mrn_id = ajaxResponse.getRequestParameter("add_mrn_id", "");
            String add_patient_gender = ajaxResponse.getRequestParameter("add_patient_gender", "");
            String add_biosubject_id = ajaxResponse.getRequestParameter("add_biosubject_id", "");
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectid", "");
            String biopharaddpat = ajaxResponse.getRequestParameter("biopharaddpat", "");
            String patientid = "";
            PropertyList prop = new PropertyList();
            String addpatientnameinitials = ajaxResponse.getRequestParameter("addpatientnameinitials", "");
            String patientmonth = ajaxResponse.getRequestParameter("patientmonth", "");
            String patienday = ajaxResponse.getRequestParameter("patienday", "");
            String patientyear = ajaxResponse.getRequestParameter("patientyear", "");
            String fi = "", mi = "", li = "";
            if (!Util.isNull(addpatientnameinitials)) {
                int charlng = addpatientnameinitials.length();
                if (charlng == 1) {
                    li = addpatientnameinitials;
                } else if (charlng == 2) {
                    li = String.valueOf(addpatientnameinitials.charAt(0));
                    fi = String.valueOf(addpatientnameinitials.charAt(1));
                } else if (charlng == 3) {
                    li = String.valueOf(addpatientnameinitials.charAt(0));
                    mi = String.valueOf(addpatientnameinitials.charAt(1));
                    fi = String.valueOf(addpatientnameinitials.charAt(2));
                }
            }
            prop.clear();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "LV_Subject");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            if (!Util.isNull(fi)) {
                prop.setProperty("u_firstname", fi);
            }
            if (!Util.isNull(mi)) {
                prop.setProperty("u_middlename", mi);
            }
            if (!Util.isNull(li)) {
                prop.setProperty("u_lastname", li);
            }

            prop.setProperty("u_mrn", add_mrn_id);
            String sql = Util.parseMessage(AccessionPageSql.GET_SUBJECT_MONTH_BY_NUMBER, patientmonth);
            DataSet dsSubjectMonth = getQueryProcessor().getSqlDataSet(sql);
            patientmonth = dsSubjectMonth.getValue(0, "refdisplayvalue", "");
            //String dob1 = patientmonth + "/" + patienday + "/" + patientyear;
            String dob1 = patienday + "/" + patientmonth + "/" + patientyear;
            if (Util.isNull(patientmonth) && Util.isNull(patienday) && Util.isNull(patientyear)) {
                prop.setProperty("u_birthdt", "(null)");
            } else {
                prop.setProperty("u_birthdt", dob1);
            }
            /****
             * TODO AS SUBJECT DOB IS A FREE TEXT
             */
            /*if (!Util.isNull(patientmonth) && !Util.isNull(patienday) && !Util.isNull(patientyear)) {
                String dob1 = patientmonth + "/" + patienday + "/" + patientyear;
                DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                Date dob = null;
                try {
                    dob = sdf.parse(dob1);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(dob);
                    DataSet ds = new DataSet();
                    ds.addColumn("birthdt", DataSet.DATE);
                    ds.setDate(0, "birthdt", calendar);
                    SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
                    String dobM = sdf1.format(dob).toUpperCase();
                    prop.setProperty("birthdt", String.valueOf(dobM));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }*/
            prop.setProperty("genderflag", add_patient_gender);
            prop.setProperty("u_biopharmasubjectid", add_biosubject_id);
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (Exception ex) {
                ajaxResponse.addCallbackArgument("msg", "Failed to mapped Subject with the Project/Protocol");
                ajaxResponse.addCallbackArgument("tableid", tabletype);
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.print();
            }
            patientid = prop.getProperty("newkeyid1");
            ajaxResponse.addCallbackArgument("msg", "Success");
            ajaxResponse.addCallbackArgument("tableid", patientid);
            ajaxResponse.addCallbackArgument("accessionid", accessionid);
            ajaxResponse.print();
            /*if (!Util.isNull(patientid)) {
                prop.clear();
                prop.setProperty(AddSDI.PROPERTY_SDCID, "ProjectSubjectMap");
                prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
                prop.setProperty("subjectid", patientid);
                prop.setProperty("projectid", bioprojectid);
                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                    String projkeyid1 = prop.getProperty("newkeyid1");
                    if (!Util.isNull(projkeyid1)) {
                        ajaxResponse.addCallbackArgument("msg", "Success");
                        ajaxResponse.addCallbackArgument("tableid", patientid);
                        ajaxResponse.addCallbackArgument("accessionid", accessionid);
                        ajaxResponse.print();
                    } else {
                        ajaxResponse.addCallbackArgument("msg", "Failed to mapped Subject with the Project/Protocol");
                        ajaxResponse.addCallbackArgument("tableid", tabletype);
                        ajaxResponse.addCallbackArgument("accessionid", accessionid);
                        ajaxResponse.print();
                    }

                } catch (Exception ex) {
                    ajaxResponse.addCallbackArgument("msg", "Failed");
                    ajaxResponse.addCallbackArgument("tableid", tabletype);
                    ajaxResponse.addCallbackArgument("accessionid", accessionid);
                    ajaxResponse.print();
                }
            } else {
                ajaxResponse.addCallbackArgument("msg", "Failed to create subject.");
                ajaxResponse.addCallbackArgument("tableid", tabletype);
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.print();
            }*/
        } else if ("add_oredering_physician_details".equalsIgnoreCase(tabletype)) {
            String order_physician_firstname = ajaxResponse.getRequestParameter("order_physician_firstname", "");
            String order_physician_lastname = ajaxResponse.getRequestParameter("order_physician_lastname", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "Physician");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("firstname", order_physician_firstname);
            prop.setProperty("lastname", order_physician_lastname);
            prop.setProperty("physiciantype", "orderingphysician");

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (Exception ex) {
            }
            String physicianid = prop.getProperty("newkeyid1");
            prop.clear();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccPhysicianMap");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("physicianid", physicianid);
            prop.setProperty("physiciantype", "orderingphysician");
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);

                ajaxResponse.addCallbackArgument("msg", "Success");
                ajaxResponse.addCallbackArgument("tableid", tabletype);
                ajaxResponse.addCallbackArgument("accessionid", accessionid);

                ajaxResponse.print();
            } catch (Exception ex) {
                ajaxResponse.addCallbackArgument("msg", "Failed");
                ajaxResponse.addCallbackArgument("tableid", tabletype);
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.print();
            }
        } else if ("add_treating_physician_details".equalsIgnoreCase(tabletype)) {
            String add_treating_physician_firstname = ajaxResponse.getRequestParameter("add_treating_physician_firstname", "");
            String add_treating_physician_lastname = ajaxResponse.getRequestParameter("add_treating_physician_lastname", "");

            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "Physician");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("firstname", add_treating_physician_firstname);
            prop.setProperty("lastname", add_treating_physician_lastname);
            prop.setProperty("physiciantype", "treatingphysician");

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (Exception ex) {
            }
            String physicianid = prop.getProperty("newkeyid1");
            prop.clear();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccPhysicianMap");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("physicianid", physicianid);
            prop.setProperty("physiciantype", "treatingphysician");
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                ajaxResponse.addCallbackArgument("msg", "Success");
                ajaxResponse.addCallbackArgument("tableid", tabletype);
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.print();
            } catch (Exception ex) {
                ajaxResponse.addCallbackArgument("msg", "Failed");
                ajaxResponse.addCallbackArgument("tableid", tabletype);
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.print();
            }
        } else if ("edit_subject_id".equalsIgnoreCase(tabletype)) {
            String keyid1 = ajaxResponse.getRequestParameter("keyid1", "");
            String subjectid = ajaxResponse.getRequestParameter("subjectid", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "LV_Subject");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            prop.setProperty("u_biopharmasubjectid", subjectid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("edit_patient_initials".equalsIgnoreCase(tabletype)) {
            String keyid1 = ajaxResponse.getRequestParameter("keyid1", "");
            String patient_initials = ajaxResponse.getRequestParameter("patient_initials", "");
            String fi = "", mi = "", li = "";
            if (!Util.isNull(patient_initials)) {
                int charlng = patient_initials.length();
                if (charlng == 1) {
                    li = patient_initials;
                    fi = "";
                    mi = "";
                } else if (charlng == 2) {
                    li = String.valueOf(patient_initials.charAt(0));
                    fi = String.valueOf(patient_initials.charAt(1));
                    mi = "";
                } else if (charlng == 3) {
                    li = String.valueOf(patient_initials.charAt(0));
                    mi = String.valueOf(patient_initials.charAt(1));
                    fi = String.valueOf(patient_initials.charAt(2));
                }
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "LV_Subject");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            if (!Util.isNull(fi)) {
                prop.setProperty("u_firstname", fi);
            } else {
                prop.setProperty("u_firstname", fi);
            }
            if (!Util.isNull(mi)) {
                prop.setProperty("u_middlename", mi);
            } else {
                prop.setProperty("u_middlename", mi);
            }
            if (!Util.isNull(li)) {
                prop.setProperty("u_lastname", li);
            } else {
                prop.setProperty("u_lastname", li);
            }
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("edit_patient_gender".equalsIgnoreCase(tabletype)) {
            String keyid1 = ajaxResponse.getRequestParameter("keyid1", "");
            String patient_gender = ajaxResponse.getRequestParameter("patient_gender", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "LV_Subject");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            prop.setProperty("genderflag", patient_gender);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        } else if ("edit_patient_dob".equalsIgnoreCase(tabletype)) {
            String keyid1 = ajaxResponse.getRequestParameter("keyid1", "");
            String patientmonth = ajaxResponse.getRequestParameter("patientmonth");
            String patienday = ajaxResponse.getRequestParameter("patienday");
            String patientyear = ajaxResponse.getRequestParameter("patientyear");
            String sql = Util.parseMessage(AccessionPageSql.GET_SUBJECT_MONTH_BY_NUMBER, patientmonth);
            DataSet dsSubjectMonth = getQueryProcessor().getSqlDataSet(sql);
            patientmonth = dsSubjectMonth.getValue(0, "refdisplayvalue", "");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "LV_Subject");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            //String dob1 = patientmonth + "/" + patienday + "/" + patientyear;
            String dob1 = patienday + "/" + patientmonth + "/" + patientyear;
            if (Util.isNull(patientmonth) && Util.isNull(patienday) && Util.isNull(patientyear)) {
                prop.setProperty("u_birthdt", "(null)");
            } else {
                prop.setProperty("u_birthdt", dob1);
            }
            /*if (!Util.isNull(patientmonth) && !Util.isNull(patienday) && !Util.isNull(patientyear)) {
                String dob1 = patientmonth + "/" + patienday + "/" + patientyear;
                DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                Date dob = null;
                try {
                    dob = sdf.parse(dob1);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(dob);
                    DataSet ds = new DataSet();
                    ds.addColumn("birthdt", DataSet.DATE);
                    ds.setDate(0, "birthdt", calendar);
                    SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
                    String dobM = sdf1.format(dob).toUpperCase();
                    prop.setProperty("birthdt", String.valueOf(dobM));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }*/
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                getResponse(ajaxResponse, "Success", tabletype, accessionid);
            } catch (Exception ex) {
                getResponse(ajaxResponse, "Failed", tabletype, accessionid);
            }
        }
    }

    public void getResponse(AjaxResponse ajaxResponse, String msg, String tableid, String accessionid) {
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("tableid", tableid);
        ajaxResponse.addCallbackArgument("accessionid", accessionid);
        ajaxResponse.print();
    }
}
