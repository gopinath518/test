package sapphire.custom.ng.ajax.extractiontube;

import ca.uhn.hl7v2.model.v21.datatype.ST;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * This CompleteExtractionTube ajax class is use to store slides
 * in respective boxes and mark it as scrapped .
 * Created by mpandey on 7/25/2016.
 */
public class CompleteExtractionTube extends BaseAjaxRequest {
    /**
     * Description : processRequest method processes the ajax request
     *
     * @param request        request object
     * @param response       response object
     * @param servletContext ServletContext object
     * @throws javax.servlet.ServletException javax.servlet.ServletException
     */
    public void processRequest(HttpServletRequest request,
                               HttpServletResponse response,
                               ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String scrappedslide = ajaxResponse.getRequestParameter("scrappedslide", "");
        String ubox = ajaxResponse.getRequestParameter("ubox", "");
        String sbox = ajaxResponse.getRequestParameter("sbox", "");
        String hnesample = ajaxResponse.getRequestParameter("hnesample", "");
        String ishnescanned = ajaxResponse.getRequestParameter("ishnescanned", "");
        String extractionid = ajaxResponse.getRequestParameter("extractionid", "");
        String extractioncomments = ajaxResponse.getRequestParameter("extractioncomments", "");
        String unscrappedslide = "";

        try {
            if (Util.isNull(ubox))
                ubox = "N";
            if (Util.isNull(sbox))
                sbox = "N";
            takeCustodyScannedSample(scrappedslide, ubox, sbox);
            validateScannedItem(scrappedslide);
            if (!"N".equalsIgnoreCase(ubox))
                validateScannedItem(ubox);
            if (!"N".equalsIgnoreCase(sbox))
                validateScannedItem(sbox);
            unscrappedslide = getUnscrappedSlide(scrappedslide);
            if ("Y".equalsIgnoreCase(ishnescanned)) {
                updateComments(extractionid, extractioncomments, hnesample);
            }
            isSacraped(scrappedslide);
            if (!"".equalsIgnoreCase(scrappedslide) && !"N".equalsIgnoreCase(sbox)) {
                storeInBox(ajaxResponse, scrappedslide, sbox);
            } else {
                //TODO WILL ADD FOR 1.6.1 DISCUSSION PENDING FROM LITO
                routeSpecimenForOptionalBox(scrappedslide);
            }
            if (!"".equalsIgnoreCase(unscrappedslide)) {
                // updateSampleMap(unscrappedslide);  //todo on Janifer's feedback dated 10-aug-16
                if (!"N".equalsIgnoreCase(ubox)) {
                    storeInSortedBox(ajaxResponse, unscrappedslide, ubox);
                } else {
                    //TODO WILL ADD FOR 1.6.1 DISCUSSION PENDING FROM LITO
                    routeSpecimenForOptionalBox(unscrappedslide);
                }
                moveUnscrappedToPreExtraction(unscrappedslide);
            }
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
        } finally {
            ajaxResponse.print();
        }
    }

    private Boolean checkForClientSlide(String uss) {
        String sql = "select distinct u_type from s_sample where s_sampleid  in('" + uss.replaceAll(";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.getValue(0, "u_type").equalsIgnoreCase("CU") || ds.getValue(0, "u_type").equalsIgnoreCase("CH"))
            return true;
        else
            return false;
    }

    /**
     * This fuction is use to mark a sample as scrapped .
     *
     * @param scrappedslide
     * @throws SapphireException
     */

    private void isSacraped(String scrappedslide) throws SapphireException {
        PropertyList propEditSDI = new PropertyList();
        propEditSDI.setProperty("sdcid", "Sample");
        propEditSDI.setProperty("keyid1", scrappedslide);
        propEditSDI.setProperty("u_isscrap", "Y");


        try {
            getActionProcessor().processAction("EditSDI", "1", propEditSDI);
        } catch (ActionException e) {
            String error = getTranslationProcessor().translate("Please select atleast a sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /**
     * This method is use to store sample in a sorted box.
     *
     * @param ajaxResponse
     * @param unscrappedslide
     * @param ubox
     */
    private void storeInSortedBox(AjaxResponse ajaxResponse, String unscrappedslide, String ubox) {
        if (!Util.isNull(ubox) && !Util.isNull(unscrappedslide)) {
            // String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid =(select storageunitid from storageunit where linkkeyid1='" + ubox + "') order by 3";
            //TODO NOW IT CHANGES AS PER LITO, UNSCRAPPED BOX WILL BE UNSORTED BOX
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where storageunitid =(select storageunitid from storageunit where linkkeyid1='" + ubox + "') order by 3";
            DataSet dsStorage = getQueryProcessor().getSqlDataSet(sql);
            String samplearr[] = StringUtil.split(unscrappedslide, ";");
            sql = "select trackitemid,linksdcid,linkkeyid1,currentstorageunitid  from trackitem where linksdcid='Sample' and linkkeyid1 in ('"
                    + StringUtil.replaceAll(unscrappedslide, ";", "','") + "') ";
            DataSet dsSampleTI = getQueryProcessor().getSqlDataSet(sql);
            int itcount = 0;
            if (dsSampleTI.getRowCount() > 0) {
                String sampleinbox = "";
                String icount = "select count(trackitem.linkkeyid1)ticount from trackitem where CURRENTSTORAGEUNITID in(select storageunitid from storageunit where parentid =(select storageunitid from storageunit where linkkeyid1='" + ubox + "'))";
                DataSet dsicount = getQueryProcessor().getSqlDataSet(icount);

                if (dsicount.size() > 0)
                    itcount = Integer.parseInt(dsicount.getValue(0, "ticount"));

                for (int i = 0; i < dsSampleTI.size(); i++) {
                    if (dsSampleTI.getValue(i, "currentstorageunitid").length() > 0) {
                        sampleinbox += ";" + dsSampleTI.getValue(i, "linkkeyid1");
                    }
                }
                if (sampleinbox.length() > 0) {
                    ajaxResponse.addCallbackArgument("msg", "SampleId(s) " + sampleinbox.substring(1) + " is/are already in Storage , Please checkout first");
                    return;
                }

            } else {

                ajaxResponse.addCallbackArgument("msg", "You have scanned a invalid SampleId" + unscrappedslide);
                ajaxResponse.print();
                return;
            }
            if (samplearr != null && samplearr.length > 0) {

                DataSet result = new DataSet();
                result.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
                result.addColumn("currentstorageunitid", DataSet.STRING);
                for (int i = 0; i < samplearr.length; i++) {
                    int rowIndex = result.addRow();
                    //String temStgId = dsStorage.getValue(itcount++, "storageunitid", "");
                    //TODO NOW IT CHANGES AS PER LITO, UNSCRAPPED BOX WILL BE UNSORTED BOX
                    String temStgId = dsStorage.getValue(0, "storageunitid", "");
                    if (!Util.isNull(temStgId)) {
                        result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, samplearr[i]);
                        result.setValue(rowIndex, "currentstorageunitid", temStgId);
                    }
                }

                if (result != null && result.size() > 0) {
                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    pl.setProperty(EditTrackItem.PROPERTY_KEYID1, result.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                    pl.setProperty("currentstorageunitid", result.getColumnValues("currentstorageunitid", ";"));
                    try {
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                    } catch (ActionException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /**
     * This method is use to update sample map.
     *
     * @param unscrappedslide
     * @throws SapphireException
     */
    private void updateSampleMap(String unscrappedslide) throws SapphireException {
        String deleteSql = "";
        deleteSql = "delete from s_samplemap where sourcesampleid in('" + unscrappedslide.replaceAll(";", "','") + "') ";
        //System.out.println("u_jobu_customer Delete SQL" + deleteSql);
        try {

            getQueryProcessor().execSQL(deleteSql);
            getQueryProcessor().execSQL("commit");

        } catch (Exception sqlex) {
            String error = getTranslationProcessor().translate("Can't delete record from sample map SDC");
            error += sqlex.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }

    }

    /**
     * This method is use to update comments.
     *
     * @param extractionid
     * @param extractioncomments
     * @throws SapphireException
     */
    private void updateComments(String extractionid, String extractioncomments, String hnesample) throws SapphireException {
        String selectSql = "";
        selectSql = "select s_sampleid from s_sample where u_extractionid in( '" + extractionid.replaceAll(";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(selectSql);
        if (ds == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + ds;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (ds.size() == 0) {
            String error = getTranslationProcessor().translate("Extraction type is not defined for Samples");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        String sampleid = ds.getColumnValues("s_sampleid", ";");
        //System.out.println("u_jobu_customer Delete SQL" + deleteSql);
        try {
            PropertyList pl = new PropertyList();
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            pl.setProperty("u_extractioncomments", extractioncomments);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, hnesample);
            pl.setProperty("u_pathologycomments", extractioncomments);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);


        } catch (Exception sqlex) {
            String error = getTranslationProcessor().translate("Can't edit comments from sample");
            error += sqlex.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }

    }

    /**
     * This method is use to store samples in box.
     *
     * @param ajaxResponse
     * @param sampleid
     * @param boxid
     */
    private void storeInBox(AjaxResponse ajaxResponse, String sampleid, String boxid) {
        PropertyList props = new PropertyList();
        try {
            String sql = "select storageunitid,linksdcid,linkkeyid1  from storageunit where linksdcid='LV_Box' and linkkeyid1='" + boxid + "' ";
            DataSet dsBox = getQueryProcessor().getSqlDataSet(sql);
            if (dsBox.getRowCount() == 0) {
                ajaxResponse.addCallbackArgument("msg", "You have scanned an invalid BoxId -" + boxid);
                return;
            }
            sql = "select trackitemid,linksdcid,linkkeyid1,currentstorageunitid  from trackitem where linksdcid='Sample' and linkkeyid1 in ('"
                    + StringUtil.replaceAll(sampleid, ";", "','") + "') ";
            DataSet dsSampleTI = getQueryProcessor().getSqlDataSet(sql);
            if (dsSampleTI.getRowCount() > 0) {
                String sampleinbox = "";

                for (int i = 0; i < dsSampleTI.size(); i++) {
                    if (dsSampleTI.getValue(i, "currentstorageunitid").length() > 0) {
                        sampleinbox += ";" + dsSampleTI.getValue(i, "linkkeyid1");
                    }
                }
                if (sampleinbox.length() > 0) {
                    ajaxResponse.addCallbackArgument("msg", "SampleId(s) " + sampleinbox.substring(1) + " is/are already in Storage , Please checkout first");
                    return;
                }

            } else {

                ajaxResponse.addCallbackArgument("msg", "You have scanned a invalid SampleId" + sampleid);
                ajaxResponse.print();
                return;
            }
            props.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, dsSampleTI.getColumnValues("trackitemid", ";"));
            props.setProperty("currentstorageunitid", dsBox.getValue(0, "storageunitid"));

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);


        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't store Samples in  Box");
            error += ae.getMessage();
            ajaxResponse.addCallbackArgument("msg", error);
        }
    }

    /**
     * This method is use to get all unscrapped slides under one block.
     *
     * @param scrappedslide
     * @return
     * @throws SapphireException
     */
    private String getUnscrappedSlide(String scrappedslide) throws SapphireException {
        Boolean isclientslide = checkForClientSlide(scrappedslide);
        String sql = "";
        if (isclientslide) {
            /*sql = "select s_sampleid from  s_sample   where  u_type='CU' and (u_isscrap='N' or u_isscrap is null)  and s_sampleid not in('" + scrappedslide.replaceAll(";", "','") + "')" +
                    " and   u_accessionid =  (select distinct u_accessionid from s_sample where s_sampleid in('" + scrappedslide.replaceAll(";", "','") + "') )  ";*/
            sql = "select s_sampleid from  s_sample   where  u_type='CU' and (u_isscrap='N' or u_isscrap is null)" +
                    " and s_sampleid not in('" + scrappedslide.replaceAll(";", "','") + "') and   u_sampleinformation in(select distinct U_SAMPLEINFORMATION from" +
                    " s_sample where s_sampleid in('" + scrappedslide.replaceAll(";", "','") + "'))" +
                    " and u_accessionid =  (select distinct u_accessionid from s_sample where s_sampleid in('" + scrappedslide.replaceAll(";", "','") + "') )";
        } else {
            sql = "select ssm.SOURCESAMPLEID,ss.s_sampleid from s_samplemap ssm, s_sample ss  where ssm.DESTSAMPLEID = ss.s_sampleid and ss.u_type='U' and (ss.u_isscrap='N' or ss.u_isscrap is null) " +
                    "and ss.s_sampleid not in('" + scrappedslide.replaceAll(";", "','") + "') and " +
                    " ssm.SOURCESAMPLEID = ( select sm.SOURCESAMPLEID from s_samplemap sm, s_sample s where sm.SOURCESAMPLEID = s.s_sampleid and sm.DESTSAMPLEID = '" + scrappedslide.split(";")[0] + "')";
        }


        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);


        if (dsSampleInfo == null) {
            String err = "Failed to query LabVantage database. Please contact Administrator. Query framed - \n" + sql;
            logger.error("Failed to query LabVantage System. Query returns a null dataset. Query framed- \n" + sql);
            //ajaxResponse.setError(err);
            //return;
            throw new SapphireException(err);
        }
        String unscrappedslide = dsSampleInfo.getColumnValues("s_sampleid", ";");
        return unscrappedslide;
    }

    /**
     * This function is use to find samples in LV system.
     *
     * @param ajaxResponse
     * @param searchedText
     * @throws ServletException
     */
    private void findSample(AjaxResponse ajaxResponse, String searchedText) throws ServletException {
        try {
            String sql = " select a.u_accessionid,s.s_sampleid,s.u_clientspecimenid, s.sampletypeid,t.containertypeid,a.patientid" +
                    " from u_accession a,s_sample s,trackitem t" +
                    " where a.u_accessionid = s.u_accessionid and s.s_sampleid = t.linkkeyid1" +
                    " and s.s_sampleid ='" + searchedText + "'";


            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);


            if (dsSampleInfo == null) {
                String err = "Failed to query LabVantage database. Please contact Administrator. Query framed - \n" + sql;
                logger.error("Failed to query LabVantage System. Query returns a null dataset. Query framed- \n" + sql);
                //ajaxResponse.setError(err);
                //return;
                throw new SapphireException(err);
            }
            if (dsSampleInfo.size() == 0) {
                String err = "Scanned item '" + searchedText + "' not found in LV System.\nReason: Scanned item is not a valid sample.";
                logger.debug(err);
                logger.error(err + " Query framed- \n" + sql);
                // ajaxResponse.setError(err);
                //return;
                throw new SapphireException(err);
            }
            //validate Others like must be heme sample, test code not attached

            if (dsSampleInfo.getRowCount() > 0) {  //sample found
                ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
                ajaxResponse.addCallbackArgument("rows", dsSampleInfo.size());
                ajaxResponse.addCallbackArgument("columns", dsSampleInfo.getColumns().length);
            }
        } catch (Exception e) {
            //ajaxResponse.setError(e.getMessage());
            throw new ServletException(e.getMessage());
        }
    }

    /**
     * This method is use to validate inputs.
     *
     * @param searchedText
     * @throws SapphireException
     */
    private void validateScannedItem(String searchedText) throws SapphireException {
        if (searchedText == null || "".equalsIgnoreCase(searchedText.trim())) {
            throw new SapphireException("Please select the scrapped slide(s).");
        }


    }

    private void takeCustodyScannedSample(String scannedsample, String sbox, String ubox) throws SapphireException {
        String sql = "select trackitemid from trackitem where linkkeyid1 in('" + StringUtil.replaceAll(scannedsample, ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String currentdepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
        props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("trackitemid", ";"));
        props.setProperty("custodytakendt", "n");
        props.setProperty("custodialuserid", StringUtil.repeat(currentuser, ds.size(), ";"));
        props.setProperty("custodialdepartmentid", StringUtil.repeat(currentdepartment, ds.size(), ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        if (!"N".equalsIgnoreCase(sbox)) {
            sql = "select trackitemid from trackitem where linkkeyid1 in('" + sbox + "')";
            DataSet dsSb = getQueryProcessor().getSqlDataSet(sql);
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsSb.getColumnValues("trackitemid", ";"));
            props.setProperty("custodytakendt", "n");
            props.setProperty("custodialuserid", StringUtil.repeat(currentuser, dsSb.size(), ";"));
            props.setProperty("custodialdepartmentid", StringUtil.repeat(currentdepartment, dsSb.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
        if (!"N".equalsIgnoreCase(ubox)) {
            sql = "select trackitemid from trackitem where linkkeyid1 in('" + ubox + "')";
            DataSet dsUb = getQueryProcessor().getSqlDataSet(sql);
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsUb.getColumnValues("trackitemid", ";"));
            props.setProperty("custodytakendt", "n");
            props.setProperty("custodialuserid", StringUtil.repeat(currentuser, dsUb.size(), ";"));
            props.setProperty("custodialdepartmentid", StringUtil.repeat(currentdepartment, dsUb.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
    }

    private void moveUnscrappedToPreExtraction(String unscrappedslide) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, unscrappedslide);
        prop.setProperty("u_currentmovementstep", "Pre-Extraction");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
    }

    /***
     *@Desc: Used to route specimen(s) which not into the box.
     */
    private void routeSpecimenForOptionalBox(String sampleids) throws SapphireException {
        String defaultdept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = StringUtil.split(defaultdept, "-")[0];
        DataSet dsMain = new DataSet();
        dsMain.addColumn("s_sampleid", DataSet.STRING);
        dsMain.addColumn("u_currentmovementstep", DataSet.STRING);
        dsMain.addColumn("currenttramstop", DataSet.STRING);
        dsMain.addColumn("currentdepartment", DataSet.STRING);
        DataSet dsPolicy = getPolicy();
        String sql = Util.parseMessage(MolecularSql.GET_MOL_SAMPLES_EXTRACTION, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsSamples = getQueryProcessor().getSqlDataSet(sql);
        if (dsSamples.size() > 0) {
            for (int i = 0; i < dsSamples.size(); i++) {
                String sampleid = dsSamples.getValue(i, "s_sampleid", "");
                String u_type = dsSamples.getValue(i, "u_type", "");
                String methodology = dsSamples.getValue(i, "methodology", "");
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("type", u_type);
                hm.put("methodology", methodology);
                DataSet dsCompFilter = dsPolicy.getFilteredDataSet(hm);
                if (dsCompFilter.size() > 0) {
                    int trowID = dsMain.addRow();
                    dsMain.setValue(trowID, "s_sampleid", sampleid);
                    dsMain.setValue(trowID, "u_currentmovementstep", dsCompFilter.getValue(0, "movementstep", ""));
                    dsMain.setValue(trowID, "currenttramstop", dsCompFilter.getValue(0, "currenttramstop", ""));
                    dsMain.setValue(trowID, "currentdepartment", site + "-" + dsCompFilter.getValue(0, "custodiandept", ""));
                }
            }
        }
        if (dsMain.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsMain.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currentmovementstep", dsMain.getColumnValues("u_currentmovementstep", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to route specimen." + ex.getMessage());
            }
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsMain.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currenttramstop", dsMain.getColumnValues("currenttramstop", ";"));
            props.setProperty("custodialdepartmentid", dsMain.getColumnValues("currentdepartment", ";"));
            props.setProperty("custodialuserid", StringUtil.repeat("(null)", dsMain.size(), ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to set department for specimen." + ex.getMessage());
            }
        }
    }

    /**
     * Description : This method will create a dataset with type,methodology and tramstop that is define in MicrotomyCompletePolicy.
     *
     * @return
     * @throws SapphireException
     */
    private DataSet getPolicy() throws SapphireException {
        DataSet dsPloicy = new DataSet();
        int incr = 0;
        dsPloicy.addColumn("type", DataSet.STRING);
        dsPloicy.addColumn("methodology", DataSet.STRING);
        dsPloicy.addColumn("movementstep", DataSet.STRING);
        dsPloicy.addColumn("currenttramstop", DataSet.STRING);
        dsPloicy.addColumn("custodiandept", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("MicrotomyCompletePolicy", "ExtractionComplete\n");
        PropertyListCollection plcRoutingrules = plMicroPolicy.getCollection("routingrules");
        for (int i = 0; i < plcRoutingrules.size(); i++) {
            incr = dsPloicy.addRow();
            PropertyListCollection plcConditions = plcRoutingrules.getPropertyList(i).getCollection("conditions");
            PropertyListCollection plcColumnvaluepair = plcConditions.getPropertyList(0).getCollection("columnvaluepair");
            for (int j = 0; j < plcColumnvaluepair.size(); j++) {
                String column = plcColumnvaluepair.getPropertyList(j).getProperty("column");
                String value = plcColumnvaluepair.getPropertyList(j).getProperty("value");
                if (column.equalsIgnoreCase("u_type")) {
                    dsPloicy.setValue(incr, "type", value);
                } else {
                    dsPloicy.setValue(incr, "methodology", value);
                }
            }
            String currentmovementstep = plcConditions.getPropertyList(0).getProperty("currentmovementstep");
            String currenttramstop = plcConditions.getPropertyList(0).getProperty("currenttram");
            String custodiandept = plcConditions.getPropertyList(0).getProperty("custodiandept");
            dsPloicy.setValue(incr, "movementstep", currentmovementstep);
            dsPloicy.setValue(incr, "currenttramstop", currenttramstop);
            dsPloicy.setValue(incr, "custodiandept", custodiandept);
        }
        return dsPloicy;
    }
}