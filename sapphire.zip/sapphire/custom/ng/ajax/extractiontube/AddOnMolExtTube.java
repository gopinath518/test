package sapphire.custom.ng.ajax.extractiontube;

import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;

/**
 * This AddOnMolExtTube ajax class is use to add additional sample in
 * a molecular batch.
 * Created by mpandey on 9/24/2016.
 */
public class AddOnMolExtTube extends BaseAjaxRequest {
    String boxId="";

    /**
     *
     * @param httpServletRequest
     * @param httpServletResponse
     * @param servletContext
     * @throws ServletException
     */
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String batchid = ajaxResponse.getRequestParameter("batchid", "");
        String addonsampleid = ajaxResponse.getRequestParameter("addonsampleid", "");
        String vempmsg = "";

        try {
            if (ajaxResponse == null) {
                throw new SapphireException("AjaxResponse is obtained as null");
            }

                molBatchAddSamp(batchid,addonsampleid);
                if (!(batchid ==null)) {
                    vempmsg = viewExtractionMap(batchid, boxId);//todo calling in loop for multiple batches.
            }


        } catch (Exception exp) {
            logger.debug(exp.getMessage());
            ajaxResponse.setError(exp.getMessage());
        } finally {
            if (ajaxResponse != null) {
                if (batchid.length() > 0) {
                    ajaxResponse.addCallbackArgument("batchid", batchid);
                    ajaxResponse.addCallbackArgument("url", vempmsg);
                } else {
                    ajaxResponse.addCallbackArgument("batchid", batchid);
                    ajaxResponse.addCallbackArgument("url", vempmsg);
                }
                ajaxResponse.print();
            }
        }

    }

    /**
     * This method is use to add sample in existing batch.
     * @param batchid
     * @param addonsampleid
     * @throws SapphireException
     */
    private void molBatchAddSamp(String batchid, String addonsampleid) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty("batchid", batchid);
        prop.setProperty("addonsampleid", addonsampleid);
        try {
           getActionProcessor().processAction("MolBatchSampleAddOn","1",prop);
            boxId=prop.getProperty("boxid");

        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed MolBatchSampleAddOn.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * This method is use to create extraction map for a batch.
     *
     * @param newBatch
     * @param boxId
     * @return
     * @throws SapphireException
     */
    private String viewExtractionMap(String newBatch, String boxId) throws SapphireException {


    /*    PropertyList prop = new PropertyList();
        prop.setProperty("batchid", newBatch);
        prop.setProperty("boxid", boxId);
        try {
            getActionProcessor().processAction("ViewExtractionMap", "1", prop,true);

        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed.ViewExtractionMap.");
           // throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            logger.debug(errMSG);
        }*/
        PropertyList prop = new PropertyList();
        prop.setProperty("batchid", newBatch);
        prop.setProperty("boxid", boxId);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "ViewExtractionMap");
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);


        return prop.getProperty("msg");
    }
}
