package sapphire.custom.ng.ajax.extractiontube;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * This GetSample4Extraction ajax class is use get slides to extract.
 * Created by mpandey on 7/19/2016.
 * Modified by surajit
 */
public class GetSample4Extraction extends BaseAjaxRequest {
    String requestid = "";
    String ishnescanned = "";
    Boolean isclienthne = false;
    String ffpeextractiontype = "";

    /**
     * Description : processRequest method processes the ajax request
     *
     * @param request        request object
     * @param response       response object
     * @param servletContext ServletContext object
     * @throws javax.servlet.ServletException javax.servlet.ServletException
     */
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        ffpeextractiontype = ajaxResponse.getRequestParameter("ffpeextractiontype", "");
        String hne = ajaxResponse.getRequestParameter("hne");
        String uss = ajaxResponse.getRequestParameter("uss");
        ishnescanned = ajaxResponse.getRequestParameter("ishnescanned");
        requestid = ajaxResponse.getRequestParameter("requestid", "");

        try {
            if ("Y".equalsIgnoreCase(ishnescanned)) {
                validateScannedItem(hne);
            }
            validateScannedItem(uss);
            isclienthne = checkForClienthne(uss);
            /*if ("Y".equalsIgnoreCase(ishnescanned)) {
                isclienthne = checkForClienthne(hne);
            }*/
            if ("Y".equalsIgnoreCase(ishnescanned)) {
                findSample(ajaxResponse, hne, uss);
            } else {
                findSampleWOHNEScanned(ajaxResponse, uss, ishnescanned);
            }
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
        } finally {
            ajaxResponse.print();
        }
    }

    private Boolean checkForClienthne(String hne) {
        String sql = "select u_type from s_sample where s_sampleid='" + hne + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.getValue(0, "u_type").equalsIgnoreCase("CH") || ds.getValue(0, "u_type").equalsIgnoreCase("CU"))
            return true;
        else
            return false;
    }

    /**
     * This function is use to get all other samples belongs to
     * same parent block with one child hne and a unstained slide as input .
     *
     * @param ajaxResponse
     * @param hne
     * @param uss
     * @throws ServletException
     */

    private void findSample(AjaxResponse ajaxResponse, String hne, String uss) throws ServletException {
        String sql = "";
        if (isclienthne) {
            sql = Util.parseMessage(MolecularSql.GET_NONFFPE_EXTRC_CLNT_SLD, hne, uss);
        } else {
            sql = Util.parseMessage(MolecularSql.GET_NONFFPE_BLK_SLD, hne, uss);
        }

        try {

            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            if (!dsSampleInfo.isValidColumn("testname")) {
                dsSampleInfo.addColumn("testname", DataSet.STRING);
            }
            if (!dsSampleInfo.isValidColumn("methodology")) {
                dsSampleInfo.addColumn("methodology", DataSet.STRING);
            }
            //validate Others like must be heme sample
            String samples = dsSampleInfo.getColumnValues("s_sampleid", ";");
            String samp = StringUtil.replaceAll(samples, ";", "','");
            String testsql = Util.parseMessage(MolecularSql.MOL_TESTNAME, samp);
            DataSet dsTestName = getQueryProcessor().getSqlDataSet(testsql);

            HashMap hm = new HashMap();
            for (int i = 0; i < dsTestName.getRowCount(); i++) {
                hm.clear();
                hm.put("s_sampleid", dsTestName.getValue(i, "s_sampleid"));
                int j = dsSampleInfo.findRow(hm);
                if (j >= 0) {
                    dsSampleInfo.setValue(j, "testname", dsTestName.getValue(i, "testname", ""));
                    dsSampleInfo.setValue(j, "methodology", "Molecular");
                }
            }

            hm.clear();
            hm.put("methodology", "Molecular");
            DataSet dsMolecularSampleInfo = dsSampleInfo.getFilteredDataSet(hm);
            String extrtype = getExtractionType(uss);
            hm.clear();
            hm.put("extractiontype", extrtype);
            DataSet dsMolFilteredByExtrtn = dsSampleInfo.getFilteredDataSet(hm);
            if (dsMolFilteredByExtrtn != null && dsMolFilteredByExtrtn.size() > 0) {
                hm.clear();
                hm.put("s_sampleid", hne);
                DataSet dsMolFilteredByHNE = dsSampleInfo.getFilteredDataSet(hm);
                if (dsMolFilteredByHNE != null && dsMolFilteredByHNE.size() > 0) {
                    dsMolecularSampleInfo.clear();// = new DataSet();
                    int rowID = dsMolecularSampleInfo.addRow();
                    dsMolecularSampleInfo.setValue(rowID, "extractiontype", dsMolFilteredByHNE.getValue(0, "extractiontype", ""));
                    dsMolecularSampleInfo.setValue(rowID, "u_accessionid", dsMolFilteredByHNE.getValue(0, "u_accessionid", ""));
                    dsMolecularSampleInfo.setValue(rowID, "u_sampleinformation", dsMolFilteredByHNE.getValue(0, "u_sampleinformation", ""));
                    dsMolecularSampleInfo.setValue(rowID, "s_sampleid", dsMolFilteredByHNE.getValue(0, "s_sampleid", ""));
                    dsMolecularSampleInfo.setValue(rowID, "u_type", dsMolFilteredByHNE.getValue(0, "u_type", ""));
                    dsMolecularSampleInfo.setValue(rowID, "u_clientspecimenid", dsMolFilteredByHNE.getValue(0, "u_clientspecimenid", ""));
                    dsMolecularSampleInfo.setValue(rowID, "sampletypeid", dsMolFilteredByHNE.getValue(0, "sampletypeid", ""));
                    dsMolecularSampleInfo.setValue(rowID, "containertypeid", dsMolFilteredByHNE.getValue(0, "containertypeid", ""));
                    dsMolecularSampleInfo.setValue(rowID, "patientid", dsMolFilteredByHNE.getValue(0, "patientid", ""));
                    dsMolecularSampleInfo.setValue(rowID, "methodology", "Molecular");
                    dsMolecularSampleInfo.setValue(rowID, "testname", dsMolFilteredByHNE.getValue(0, "testname", ""));
                    for (int i = 0; i < dsMolFilteredByExtrtn.size(); i++) {
                        int nxtrowID = dsMolecularSampleInfo.addRow();
                        dsMolecularSampleInfo.setValue(nxtrowID, "extractiontype", dsMolFilteredByExtrtn.getValue(i, "extractiontype", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "u_accessionid", dsMolFilteredByExtrtn.getValue(i, "u_accessionid", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "u_sampleinformation", dsMolFilteredByExtrtn.getValue(i, "u_sampleinformation", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "s_sampleid", dsMolFilteredByExtrtn.getValue(i, "s_sampleid", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "u_type", dsMolFilteredByExtrtn.getValue(i, "u_type", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "u_clientspecimenid", dsMolFilteredByExtrtn.getValue(i, "u_clientspecimenid", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "sampletypeid", dsMolFilteredByExtrtn.getValue(i, "sampletypeid", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "containertypeid", dsMolFilteredByExtrtn.getValue(i, "containertypeid", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "patientid", dsMolFilteredByExtrtn.getValue(i, "patientid", ""));
                        dsMolecularSampleInfo.setValue(nxtrowID, "methodology", "Molecular");
                        dsMolecularSampleInfo.setValue(nxtrowID, "testname", dsMolFilteredByExtrtn.getValue(i, "testname", ""));
                    }
                    //dsMolecularSampleInfo = dsMolFilteredByExtrtn;
                }

            }

            if (dsMolecularSampleInfo.size() > 0) {  //sample found
                String msg = "";
                if (!"TNA".equalsIgnoreCase(ffpeextractiontype)) {
                    PropertyList props = new PropertyList();
                    props.setProperty("ffpeextractiontype", ffpeextractiontype);
                    props.setProperty("hne", hne);
                    props.setProperty("uss", uss);
                    props.setProperty("ishnescanned", ishnescanned);
                    props.setProperty("requestid", requestid);
                    try {
                        getActionProcessor().processAction("CreateSolidExtractionTubeWrap", "1", props);
                    } catch (Exception ex) {
                        ajaxResponse.setError(ex.getMessage());
                    }
                    msg = props.getProperty("msg");
                } else if ("TNA".equalsIgnoreCase(ffpeextractiontype)) {
                    sql = Util.parseMessage(MolecularSql.GET_NON_FFPE_SAMPLES, StringUtil.replaceAll(uss, ";", "','"));
                    DataSet dsFFPE = getQueryProcessor().getSqlDataSet(sql);
                    if (dsFFPE.size() == 0) {
                        String error = "No active test code(s) found into the specimen " + uss + " for TNA workflow.";
                        //throw new ServletException(error);
                        ajaxResponse.setError(error);
                        ajaxResponse.print();
                        return;
                    }
                    hm.clear();
                    hm.put("tclblextractiontype", null);
                    DataSet dsTCLblExtr = dsFFPE.getFilteredDataSet(hm);
                    if (dsTCLblExtr.size() > 0) {
                        String error = dsFFPE.getColumnValues("lvtestcodeid", ",") + " test code(s) are not eligible for TNA workflow.";
                        //throw new ServletException(error);
                        ajaxResponse.setError(error);
                        ajaxResponse.print();
                        return;
                    }
                    String crtextractiontubetype = "DNA;RNA";
                    String extractionids = "";
                    String arryExtrcType[] = StringUtil.split(crtextractiontubetype, ";");
                    for (int i = 0; i < arryExtrcType.length; i++) {
                        String extrctype = arryExtrcType[i];
                        PropertyList props = new PropertyList();
                        props.setProperty("ffpeextractiontype", extrctype);
                        props.setProperty("hne", hne);
                        props.setProperty("uss", uss);
                        props.setProperty("ishnescanned", ishnescanned);
                        props.setProperty("requestid", requestid);
                        try {
                            getActionProcessor().processAction("CreateSolidExtractionTubeWrap", "1", props);
                        } catch (Exception ex) {
                            ajaxResponse.setError(ex.getMessage());
                        }
                        msg += ";" + props.getProperty("msg");
                        //CLRAER EXTRACTION TYPE FROM PARENT
                        PropertyList prop = new PropertyList();
                        prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFFPE.getColumnValues("u_sampletestcodemapid", ";"));
                        prop.setProperty("extractiontype", "");
                        try {
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                        } catch (ActionException e) {
                            ajaxResponse.setError(e.getMessage());
                            ajaxResponse.print();
                            return;
                        }
                    }

                    //CLRAER EXTRACTION TYPE FROM PARENT
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFFPE.getColumnValues("u_sampletestcodemapid", ";"));
                    prop.setProperty("extractiontype", StringUtil.repeat("TNA", dsFFPE.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (ActionException e) {
                        ajaxResponse.setError(e.getMessage());
                        ajaxResponse.print();
                        return;
                    }
                }
                if (msg.startsWith(";"))
                    msg = msg.substring(1);
                ajaxResponse.addCallbackArgument("dataset", dsMolecularSampleInfo);
                ajaxResponse.addCallbackArgument("rows", dsMolecularSampleInfo.size());
                ajaxResponse.addCallbackArgument("columns", dsMolecularSampleInfo.getColumns().length);
                ajaxResponse.addCallbackArgument("msg", msg);
            } else {
                String err = "Scanned H&E and Unstained slide not belongs to same Block/Accession.";
                logger.debug(err);
                logger.error(err + " Query framed- \n" + sql);
                ajaxResponse.setError(err);
                return;

            }
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
            throw new ServletException(e);
        }
    }

    private void findSampleWOHNEScanned(AjaxResponse ajaxResponse, String uss, String isHNEScanned) throws ServletException {
        String sql = "";
        sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_BY_SAMPLE, uss);
        try {

            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            if (!dsSampleInfo.isValidColumn("testname")) {
                dsSampleInfo.addColumn("testname", DataSet.STRING);
            }
            if (!dsSampleInfo.isValidColumn("methodology")) {
                dsSampleInfo.addColumn("methodology", DataSet.STRING);
            }
            //validate Others like must be heme sample
            String samples = dsSampleInfo.getColumnValues("s_sampleid", ";");
            String samp = StringUtil.replaceAll(samples, ";", "','");
            String testsql = "select s_sampleid, LISTAGG(testname, ',') WITHIN GROUP (ORDER BY testname) testname" +
                    " from U_SAMPLETESTCODEMAP where methodology ='Molecular' and s_sampleid in('" + samp + "') group by s_sampleid";
            DataSet dsTestName = getQueryProcessor().getSqlDataSet(testsql);

            HashMap hm = new HashMap();
            for (int i = 0; i < dsTestName.getRowCount(); i++) {
                hm.clear();
                hm.put("s_sampleid", dsTestName.getValue(i, "s_sampleid"));
                int j = dsSampleInfo.findRow(hm);
                if (j >= 0) {
                    dsSampleInfo.setValue(j, "testname", dsTestName.getValue(i, "testname", ""));
                    dsSampleInfo.setValue(j, "methodology", "Molecular");
                }
            }

            hm.clear();
            hm.put("methodology", "Molecular");
            DataSet dsMolecularSampleInfo = dsSampleInfo.getFilteredDataSet(hm);
            String extrtype = getExtractionType(uss);
            hm.clear();
            hm.put("extractiontype", extrtype);
            DataSet dsMolFilteredByExtrtn = dsSampleInfo.getFilteredDataSet(hm);
            if (dsMolFilteredByExtrtn != null && dsMolFilteredByExtrtn.size() > 0) {
                dsMolecularSampleInfo.clear();
                for (int i = 0; i < dsMolFilteredByExtrtn.size(); i++) {
                    int nxtrowID = dsMolecularSampleInfo.addRow();
                    dsMolecularSampleInfo.setValue(nxtrowID, "extractiontype", dsMolFilteredByExtrtn.getValue(i, "extractiontype", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_accessionid", dsMolFilteredByExtrtn.getValue(i, "u_accessionid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_sampleinformation", dsMolFilteredByExtrtn.getValue(i, "u_sampleinformation", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "s_sampleid", dsMolFilteredByExtrtn.getValue(i, "s_sampleid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_type", dsMolFilteredByExtrtn.getValue(i, "u_type", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_clientspecimenid", dsMolFilteredByExtrtn.getValue(i, "u_clientspecimenid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "sampletypeid", dsMolFilteredByExtrtn.getValue(i, "sampletypeid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "containertypeid", dsMolFilteredByExtrtn.getValue(i, "containertypeid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "patientid", dsMolFilteredByExtrtn.getValue(i, "patientid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "methodology", "Molecular");
                    dsMolecularSampleInfo.setValue(nxtrowID, "testname", dsMolFilteredByExtrtn.getValue(i, "testname", ""));
                }
            }

            if (dsMolecularSampleInfo.size() > 0) {  //sample found
                String msg = "";
                if (!"TNA".equalsIgnoreCase(ffpeextractiontype)) {
                    PropertyList props = new PropertyList();
                    props.setProperty("ffpeextractiontype", ffpeextractiontype);
                    props.setProperty("hne", "");
                    props.setProperty("uss", uss);
                    props.setProperty("ishnescanned", isHNEScanned);
                    props.setProperty("requestid", requestid);
                    try {
                        getActionProcessor().processAction("CreateSolidExtractionTubeWrap", "1", props);
                    } catch (Exception ex) {
                        ajaxResponse.setError(ex.getMessage());
                    }
                    msg = props.getProperty("msg");
                } else if ("TNA".equalsIgnoreCase(ffpeextractiontype)) {
                    sql = Util.parseMessage(MolecularSql.GET_NON_FFPE_SAMPLES, StringUtil.replaceAll(uss, ";", "','"));
                    DataSet dsFFPE = getQueryProcessor().getSqlDataSet(sql);
                    if (dsFFPE.size() == 0) {
                        String error = "No active test code(s) found into the specimen " + uss + " for TNA workflow.";
                        throw new ServletException(error);
                    }
                    String crtextractiontubetype = "DNA;RNA";
                    String arryExtrcType[] = StringUtil.split(crtextractiontubetype, ";");
                    for (int i = 0; i < arryExtrcType.length; i++) {
                        String extrctype = arryExtrcType[i];
                        PropertyList props = new PropertyList();
                        props.setProperty("ffpeextractiontype", extrctype);
                        props.setProperty("hne", "");
                        props.setProperty("uss", uss);
                        props.setProperty("ishnescanned", isHNEScanned);
                        props.setProperty("requestid", requestid);
                        try {
                            getActionProcessor().processAction("CreateSolidExtractionTubeWrap", "1", props);
                        } catch (Exception ex) {
                            ajaxResponse.setError(ex.getMessage());
                        }
                        msg += props.getProperty("msg");
                        //CLRAER EXTRACTION TYPE FROM PARENT
                        PropertyList prop = new PropertyList();
                        prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFFPE.getColumnValues("u_sampletestcodemapid", ";"));
                        prop.setProperty("extractiontype", "");
                        try {
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                        } catch (ActionException e) {
                            ajaxResponse.setError(e.getMessage());
                            ajaxResponse.print();
                            return;
                        }
                    }
                    //CLRAER EXTRACTION TYPE FROM PARENT
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFFPE.getColumnValues("u_sampletestcodemapid", ";"));
                    prop.setProperty("extractiontype", StringUtil.repeat("TNA", dsFFPE.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (ActionException e) {
                        ajaxResponse.setError(e.getMessage());
                        ajaxResponse.print();
                        return;
                    }
                }
                if (msg.startsWith(";"))
                    msg = msg.substring(1);
                if (msg.contains(";"))
                    msg = StringUtil.replaceAll(msg, ";", ", ");
                ajaxResponse.addCallbackArgument("dataset", dsMolecularSampleInfo);
                ajaxResponse.addCallbackArgument("rows", dsMolecularSampleInfo.size());
                ajaxResponse.addCallbackArgument("columns", dsMolecularSampleInfo.getColumns().length);
                ajaxResponse.addCallbackArgument("msg", msg);
            } else {
                String err = "Scanned H&E and Unstained slide not belongs to same Block/Accession.";
                logger.debug(err);
                logger.error(err + " Query framed- \n" + sql);
                ajaxResponse.setError(err);
                return;

            }
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
            throw new ServletException(e);
        }
    }

    /**
     * This function is use to check any blank or null inputs.
     *
     * @param searchedText
     * @throws SapphireException
     */
    private void validateScannedItem(String searchedText) throws SapphireException {
        if (searchedText == null || "".equalsIgnoreCase(searchedText.trim())) {
            throw new SapphireException("Scanned item is blank.");
        }
    }

    private String getExtractionType(String uss) throws SapphireException {
        String extractiontyep = "";
        String sql = "select u_sampletestcodemapid,extractiontype from u_sampletestcodemap where s_sampleid='" + uss + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        extractiontyep = Util.getUniqueList(ds.getColumnValues("extractiontype", ";"), ";", true);
        //if (Util.isNull(extractiontyep)) {//TODO IMPLEMENTING TNA WORKFLOW
        if (!"TNA".equalsIgnoreCase(extractiontyep)) {
            extractiontyep = ffpeextractiontype;
        }
        return extractiontyep;
    }

}
