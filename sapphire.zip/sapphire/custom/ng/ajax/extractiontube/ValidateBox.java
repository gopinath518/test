package sapphire.custom.ng.ajax.extractiontube;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This ValidateBox ajax class is use to Validate box.
 * Created by mpandey on 7/19/2016.
 */
public class ValidateBox extends BaseAjaxRequest {

    @Override
    @SuppressWarnings({"rawtypes"})
    public void processRequest(HttpServletRequest request,
                               HttpServletResponse response, ServletContext servletContext)
            throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String boxid = ajaxResponse.getRequestParameter("boxid");
        String sql_ti = "select trackitemid from trackitem where linkkeyid1='" + boxid + "'";
        DataSet ds_ti = getQueryProcessor().getSqlDataSet(sql_ti);
        String trackitemid = ds_ti.getValue(0, "trackitemid");
        String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String sql_dept = "select defaultdepartment from sysuser where sysuserid='" + currentuser + "'";
        DataSet ds_dept = getQueryProcessor().getSqlDataSet(sql_dept);
        String basedept = ds_dept.getValue(0, "defaultdepartment");

        String sql = "select s_boxid,boxstatus from s_Box where s_boxid='" + boxid + "'";
        try {

            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            if ((ds != null) && (ds.size() > 0)) {
                if (ds.getValue(0, "boxstatus").equalsIgnoreCase("Full"))
                    ajaxResponse.addCallbackArgument("msg", "Box is full , please scan different box.");

            } else if (ds == null || ds.size()==0) {
                ajaxResponse.addCallbackArgument("msg", "Please Scan a valid Box.");
            } else
                takeCustody(trackitemid, currentuser, basedept);

        } catch (Exception e) {
            ajaxResponse.setError((new StringBuilder()).append("Failed to process sql: ").append(sql).append(". Exception: ").append(e.getMessage()).toString(), e);
        } finally {
            ajaxResponse.print();
        }
    }

    /**
     * This method is use to take custody of a box.
     * @param trackitemid
     * @param currentuser
     * @param department
     * @throws SapphireException
     */
    private void takeCustody(String trackitemid, String currentuser, String department) throws SapphireException {


        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("custodytakendt", "n");
            props.setProperty("custodialuserid", currentuser);
            props.setProperty("custodialdepartmentid", department);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }

    }
}
