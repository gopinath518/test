package sapphire.custom.ng.ajax.extractiontube;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by smitra on 7/20/2016.
 */
public class ExtractionHeme extends BaseAjaxRequest {
    /**
     * Description : processRequest method processes the ajax request
     *
     * @param request        request object
     * @param response       response object
     * @param servletContext ServletContext object
     * @throws javax.servlet.ServletException javax.servlet.ServletException
     */
    public void processRequest(HttpServletRequest request,
                               HttpServletResponse response,
                               ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String searchedText = ajaxResponse.getRequestParameter("scansample");
        //String alreadyScannedSamples = ajaxResponse.getRequestParameter("alreadyscannedsample");
        String coldate = ajaxResponse.getRequestParameter("coldate");
        String extractiontype = ajaxResponse.getRequestParameter("extractiontype");
        String requestid = ajaxResponse.getRequestParameter("requestid", "");
        if (!"TNA".equalsIgnoreCase(extractiontype)) {
            PropertyList pl = new PropertyList();
            pl.clear();
            pl.setProperty("scansample", searchedText);
            pl.setProperty("coldate", coldate);
            pl.setProperty("extractiontype", extractiontype);
            pl.setProperty("requestid", requestid);
            try {
                getActionProcessor().processAction("CreateHemeExtractionWrap", "1", pl);
                String newsampleid = pl.getProperty("newsampleid");
                findSample(ajaxResponse, newsampleid);
            } catch (ActionException e) {
                ajaxResponse.setError(e.getMessage());
                ajaxResponse.print();
                return;
            }
        } else if ("TNA".equalsIgnoreCase(extractiontype)) {
            processTNAWorkflow(ajaxResponse, searchedText, coldate, requestid);
        }
    }


    private void findSample(AjaxResponse ajaxResponse, String searchedText) throws ServletException {
        try {
            String sql = Util.parseMessage(MolecularSql.GET_NONFFPE_FOR_EXTRC, StringUtil.replaceAll(searchedText, ";", "','"));
            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);


            if (dsSampleInfo == null) {
                String err = "Failed to query LabVantage database. Please contact Administrator. Query framed - \n" + sql;
                logger.error("Failed to query LabVantage System. Query returns a null dataset. Query framed- \n" + sql);
                ajaxResponse.setError(err);
                ajaxResponse.print();
                //return;
                //throw new SapphireException(err);
                //getResponseMsg(ajaxResponse, "N", err, null, "", "");
                return;
            }
            if (dsSampleInfo.size() == 0) {
                String err = "Scanned item '" + searchedText + "' not found in LV System.\nReason: Scanned item is not a valid sample.";
                logger.debug(err);
                logger.error(err + " Query framed- \n" + sql);
                ajaxResponse.setError(err);
                ajaxResponse.print();
                //return;
                //throw new SapphireException(err);
                //getResponseMsg(ajaxResponse, "N", err, null, "", "");
                return;
            }
            //validate Others like must be heme sample, test code not attached

            if (dsSampleInfo.getRowCount() > 0) {  //sample found
                ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
                ajaxResponse.addCallbackArgument("rows", dsSampleInfo.size());
                ajaxResponse.addCallbackArgument("columns", dsSampleInfo.getColumns().length);
                ajaxResponse.print();
                //getResponseMsg(ajaxResponse, "Y", "Found sample.", dsSampleInfo, String.valueOf(dsSampleInfo.size()), String.valueOf(dsSampleInfo.getColumns().length));
                return;
            }
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
            ajaxResponse.print();
            //throw new ServletException(e.getMessage());
            /*getResponseMsg(ajaxResponse, "N", e.getMessage(), null, "", "");*/
            return;
        }
    }

    private void getResponseMsg(AjaxResponse ajaxResponse, String msgtype, String msg, DataSet dataset, String rows, String columns) {
        ajaxResponse.addCallbackArgument("msgtype", msgtype);
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("dataset", dataset);
        ajaxResponse.addCallbackArgument("rows", rows);
        ajaxResponse.addCallbackArgument("columns", dataset.size());
        ajaxResponse.print();
    }

    private void processTNAWorkflow(AjaxResponse ajaxResponse, String sampleid, String coldate, String requestid) throws ServletException {
        String sql = Util.parseMessage(MolecularSql.GET_NON_FFPE_SAMPLES, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsNonFFPE = getQueryProcessor().getSqlDataSet(sql);
        if (dsNonFFPE.size() == 0) {
            String error = "No active test code(s) found into the specimen " + sampleid + " for TNA workflow.";
            //throw new ServletException(error);
            ajaxResponse.setError(error);
            ajaxResponse.print();
            return;
        }
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("tclblextractiontype", null);
        DataSet dsTCLblExtr = dsNonFFPE.getFilteredDataSet(hm);
        if (dsTCLblExtr.size() == 0) {
            String error = dsNonFFPE.getColumnValues("lvtestcodeid", ",") + " test code(s) are not eligible for TNA workflow.";
            //throw new ServletException(error);
            ajaxResponse.setError(error);
            ajaxResponse.print();
            return;
        }
        String crtextractiontubetype = "DNA;RNA";
        String extractiontubes = "";
        String arryExtrcType[] = StringUtil.split(crtextractiontubetype, ";");
        for (int i = 0; i < arryExtrcType.length; i++) {
            String extrctype = arryExtrcType[i];
            PropertyList pl = new PropertyList();
            pl.clear();
            pl.setProperty("scansample", sampleid);
            pl.setProperty("coldate", coldate);
            pl.setProperty("extractiontype", extrctype);
            pl.setProperty("requestid", requestid);
            pl.setProperty("tnaworkflow", "Y");
            try {
                getActionProcessor().processAction("CreateHemeExtractionWrap", "1", pl);
                String newsampleid = pl.getProperty("newsampleid");
                extractiontubes += ";" + newsampleid;
                //CLRAER EXTRACTION TYPE FROM PARENT
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsNonFFPE.getColumnValues("u_sampletestcodemapid", ";"));
                prop.setProperty("extractiontype", "");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (ActionException e) {
                    ajaxResponse.setError(e.getMessage());
                    ajaxResponse.print();
                    return;
                }
            } catch (ActionException e) {
                ajaxResponse.setError(e.getMessage());
                ajaxResponse.print();
                return;
            }
        }
        if (extractiontubes.startsWith(";"))
            extractiontubes = extractiontubes.substring(1);
        //CLRAER EXTRACTION TYPE FROM PARENT
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsNonFFPE.getColumnValues("u_sampletestcodemapid", ";"));
        prop.setProperty("extractiontype", StringUtil.repeat("TNA", dsNonFFPE.size(), ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            ajaxResponse.setError(e.getMessage());
            ajaxResponse.print();
            return;
        }
        findSample(ajaxResponse, extractiontubes);
        //throw new SapphireException("WIP TNA");
    }
   /*change it on 31st jan for Extraction
    private void labelPrint(String newsampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, newsampleid);
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Molecular");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, "ExtractionTube");
        props.setProperty(PrintLabel.TRAMLINE_PROP, "Extraction");
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }*/


}
