package sapphire.custom.ng.ajax.extractiontube;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by tsahoo on 7/28/2016.
 */
public class ExtractionTubeInfo extends BaseAjaxRequest {
    /**
     * Description : processRequest method processes the ajax request
     *
     * @param request        request object
     * @param response       response object
     * @param servletContext ServletContext object
     * @throws javax.servlet.ServletException javax.servlet.ServletException
     */
    public void processRequest(HttpServletRequest request,
                               HttpServletResponse response,
                               ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String searchedText = ajaxResponse.getRequestParameter("scansample", "");
        String hidetramstop = ajaxResponse.getRequestParameter("hidetramstop", "");
        try {
            findSample(ajaxResponse, searchedText, hidetramstop);
        } catch (Exception e) {
            ajaxResponse.setError(e.getMessage());
        } finally {
            ajaxResponse.print();
        }
    }

    private void findSample(AjaxResponse ajaxResponse, String searchedText, String hidetramstop) throws ServletException {
        try {
            String sql = "";
            if ("quantification".equalsIgnoreCase(hidetramstop)) {
                sql = "select distinct a.u_accessionid,s.s_sampleid,s.u_clientspecimenid,s.sampletypeid," +
                        " (case when t.containertypeid='Ellution Tube' then 'Elution Tube' else t.containertypeid end) as containertypeid," +
                        " a.patientid,s.u_extractionid,s.u_extractioncomments" +
                        " from u_accession a,s_sample s,trackitem t" +
                        " where a.u_accessionid = s.u_accessionid" +
                        " and s.s_sampleid = t.linkkeyid1" +
                        " and s.s_sampleid =(select s_sampleid from s_sample where u_extractionid='" + searchedText + "')";
            } else {
                sql = "SELECT DISTINCT a.u_accessionid," +
                        "  s.s_sampleid," +
                        "  s.u_clientspecimenid," +
                        "  s.sampletypeid," +
                        "  t.containertypeid," +
                        "  a.patientid," +
                        "  s.u_extractionid,s.u_extractioncomments" +
                        " FROM u_accession a," +
                        "  s_sample s," +
                        "  trackitem t" +
                        " WHERE a.u_accessionid = s.u_accessionid" +
                        " AND s.s_sampleid      = t.linkkeyid1" +
                        " AND s.s_sampleid      ='" + searchedText + "'";
            }

            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsSampleInfo == null) {
                String err = "Failed to query LabVantage database. Please contact Administrator. Query framed - \n" + sql;
                logger.error("Failed to query LabVantage System. Query returns a null dataset. Query framed- \n" + sql);
                //ajaxResponse.setError(err);
                //return;
                throw new SapphireException(err);
            }
            if (dsSampleInfo.size() == 0) {
                String err = "Scanned item '" + searchedText + "' not found in LV System.\nReason: Scanned item is not a valid sample.";
                logger.debug(err);
                logger.error(err + " Query framed- \n" + sql);
                throw new SapphireException(err);
            }
            if (dsSampleInfo.size() > 1 && "quantification".equalsIgnoreCase(hidetramstop)) {
                String err = "More the one elusion tube found for this Extraction ID " + searchedText;
                logger.debug(err);
                logger.error(err + " Query framed- \n" + sql);
                throw new SapphireException(err);
            }
            dsSampleInfo.addColumn("testname", DataSet.STRING);
            //validate Others like must be heme sample
            String samples = dsSampleInfo.getColumnValues("s_sampleid", ";");
            String samp = StringUtil.replaceAll(samples, ";", "','");
            String testsql = "select s_sampleid, LISTAGG(testname, ',') WITHIN GROUP (ORDER BY testname) testname from U_SAMPLETESTCODEMAP where s_sampleid in('" + samp + "') group by s_sampleid";
            DataSet testname = getQueryProcessor().getSqlDataSet(testsql);
            String patient = dsSampleInfo.getColumnValues("patientid", ";");
            String pat = StringUtil.replaceAll(patient, ";", "','");
            String patientname = "select s_subjectid as patientid, coalesce(u_lastname||',', '') || u_firstname as fullname from s_subject where s_subjectid in('" + pat + "')";
            DataSet ds = getQueryProcessor().getSqlDataSet(patientname);
            HashMap hm = new HashMap();
            for (int i = 0; i < testname.getRowCount(); i++) {
                hm.put("s_sampleid", testname.getValue(i, "s_sampleid"));
                int j = dsSampleInfo.findRow(hm);
                dsSampleInfo.setValue(j, "testname", testname.getValue(i, "testname"));

            }
            HashMap hm1 = new HashMap();
            for (int i = 0; i < dsSampleInfo.getRowCount(); i++) {
                hm1.put("patientid", ds.getValue(0, "patientid"));
                int k = dsSampleInfo.findRow(hm1);
                dsSampleInfo.setValue(k, "patientid", ds.getValue(0, "fullname"));
            }

            String minimalflag = checkForMinimalFlag(searchedText);

            if (dsSampleInfo.getRowCount() > 0) {  //sample found
                ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
                ajaxResponse.addCallbackArgument("minimalflag", minimalflag);
                ajaxResponse.addCallbackArgument("rows", dsSampleInfo.size());
                ajaxResponse.addCallbackArgument("columns", dsSampleInfo.getColumns().length);
            }
        } catch (Exception e) {
            throw new ServletException(e.getMessage());
        }
    }

    private String checkForMinimalFlag(String searchedText) throws SapphireException {
        String minimalflag = "N";
        String sql = "select u_markminimal from s_sample where s_sampleid =(select distinct sourcesampleid from s_samplemap where destsampleid in(select sourcesampleid " +
                "from s_samplemap where destsampleid='" + searchedText + "'))";
        DataSet dsminimal = getQueryProcessor().getSqlDataSet(sql);

        if (dsminimal == null) {
            String err = "Failed to query LabVantage database. Please contact Administrator. Query framed - \n" + sql;
            logger.error("Failed to query LabVantage System. Query returns a null dataset. Query framed- \n" + sql);
            throw new SapphireException(err);
        }
        minimalflag = dsminimal.getValue(0, "u_markminimal", "N");
        return minimalflag;
    }
}