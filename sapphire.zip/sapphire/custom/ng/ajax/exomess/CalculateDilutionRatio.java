package sapphire.custom.ng.ajax.exomess;

import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;

public class CalculateDilutionRatio extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String inputamtofsample = ajaxResponse.getRequestParameter("dilutionval", "0.0");
        String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
        String tramstopname = ajaxResponse.getRequestParameter("tramstopname", "");
        String indx = ajaxResponse.getRequestParameter("indx", "");
        String id = ajaxResponse.getRequestParameter("id", "");
        String sql = Util.parseMessage(MolecularSql.GET_ALL_CAL_BY_DILUTION_TUBE, sampleid);
        DataSet dsDilutionTube = getQueryProcessor().getSqlDataSet(sql);
        if (dsDilutionTube != null && dsDilutionTube.size() > 0) {
            String projectids = Util.getUniqueList(dsDilutionTube.getColumnValues("projectid", ";"), ";", true);
            DataSet dsExomeVals = null;
            try {
                dsExomeVals = Util.getExomeSSTramstopValues(getQueryProcessor(), projectids);
            } catch (Exception ex) {
                logger.info("Unable to retreive.");
            }
            DataSet dsDilutionCal = new DataSet();
            dsDilutionCal.addColumn("concentration", DataSet.STRING);
            dsDilutionCal.addColumn("amntofsample", DataSet.STRING);
            dsDilutionCal.addColumn("amntofwater", DataSet.STRING);
            dsDilutionCal.addColumn("inputvol", DataSet.STRING);
            dsDilutionCal.addColumn("sampledilution", DataSet.STRING);
            double dilutionratio = 0.0;
            double amntofwater = 0.0;
            double inputvol = 0.0;
            double fxdval = 0.0;
            double fxdstaticval = 0.0;
            String elutionvol = dsDilutionTube.getValue(0, "elutionvol", "0.0");
            /*HashMap hm = new HashMap();
            hm.clear();
            hm.put("projectid", projectids);
            hm.put("tramstopname", tramstopname);
            DataSet dsExomeSSValFilter = dsExomeVals.getFilteredDataSet(hm);
            if (dsExomeSSValFilter == null || dsExomeSSValFilter.size() == 0) {
                fxdval = 200.0;
                fxdstaticval = 51.0;
            } else {
                String inputngval = dsExomeSSValFilter.getValue(0, "inputngval", "0.0");
                String fixedvalue = dsExomeSSValFilter.getValue(0, "fixedvalue", "0.0");
                fxdval = Double.parseDouble(inputngval);
                fxdstaticval = Double.parseDouble(fixedvalue);
            }*/
            if ("LibraryPrep".equalsIgnoreCase(tramstopname) || "LibraryPrepQuant".equalsIgnoreCase(tramstopname)) {
                fxdval = 250.0;
                fxdstaticval = 51.0;
            } else if ("CaptureBatch".equalsIgnoreCase(tramstopname) || "CaptureBatchQuant".equalsIgnoreCase(tramstopname)
                    || "Molarity".equalsIgnoreCase(tramstopname) || "Sequencing".equalsIgnoreCase(tramstopname)) {
                fxdval = 750.0;
                fxdstaticval = 51.0;
            } else {
                fxdval = 200.0;
                fxdstaticval = 51.0;
            }
            double amntofsample = Double.parseDouble(inputamtofsample);
            double concentration = Double.parseDouble(dsDilutionTube.getValue(0, "concentration", "0.0"));
            double amtSampleRatio = fxdval / concentration;
            if (concentration > 0 && amtSampleRatio < 2) {
                dilutionratio = concentration / 10;
                dilutionratio = Util.roundAvoid(dilutionratio);
                //amntofsample = roundAvoid(200 / dilutionratio, 1);//TODO NO NEED FOR MANUAL CALCULATION
                //amntofsample = fxdval / dilutionratio;
                amntofsample = Util.roundAvoid(amntofsample);

                amntofwater = fxdstaticval - amntofsample;
                amntofwater = Util.roundAvoid(amntofwater);

                inputvol = dilutionratio * amntofsample;
                inputvol = Util.roundAvoid(inputvol);
            } else {
                amntofwater = fxdstaticval - amntofsample;
                amntofwater = Util.roundAvoid(amntofwater);
                inputvol = dilutionratio * amntofsample;
                inputvol = Util.roundAvoid(inputvol);
            }
            if (amntofsample > Double.parseDouble(elutionvol)) {
                amntofsample = Double.parseDouble(elutionvol);

                amntofwater = fxdstaticval - amntofsample;
                amntofwater = Util.roundAvoid(amntofwater);

                inputvol = dilutionratio * amntofsample;
                inputvol = Util.roundAvoid(inputvol);
            }
            if (dilutionratio < 0) {
                dilutionratio = 0.0;
            } else if (amntofwater < 0) {
                amntofwater = 0.0;
            } else if (inputvol < 0) {
                inputvol = 0.0;
            } else if (concentration < 0) {
                concentration = 0.0;
            } else if (amntofsample < 0) {
                amntofsample = 0.0;
            }
            if (Double.isInfinite(dilutionratio))
                dilutionratio = 0.0;
            if (Double.isInfinite(amntofwater))
                amntofwater = 0.0;
            if (Double.isInfinite(inputvol))
                inputvol = 0.0;
            if (Double.isInfinite(amntofwater))
                amntofwater = 0.0;
            if (Double.isInfinite(inputvol))
                inputvol = 0.0;
            int rowID = dsDilutionCal.addRow();
            dsDilutionCal.setValue(rowID, "concentration", String.valueOf(concentration));
            dsDilutionCal.setValue(rowID, "amntofsample", String.valueOf(amntofsample));
            dsDilutionCal.setValue(rowID, "amntofwater", String.valueOf(amntofwater));
            dsDilutionCal.setValue(rowID, "inputvol", String.valueOf(inputvol));
            dsDilutionCal.setValue(rowID, "sampledilution", String.valueOf(dilutionratio));

            getResponse(ajaxResponse, "Calculated", String.valueOf(amntofsample), String.valueOf(amntofwater), String.valueOf(inputvol),
                    String.valueOf(dilutionratio), indx);
        }
    }

    public void getResponse(AjaxResponse ajaxResponse, String msg, String amntofsample, String amntofwater, String inputvol, String dilutionratio, String indx) {
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("amntofsample", amntofsample);
        ajaxResponse.addCallbackArgument("amntofwater", amntofwater);
        ajaxResponse.addCallbackArgument("inputvol", inputvol);
        ajaxResponse.addCallbackArgument("dilutionratio", dilutionratio);
        ajaxResponse.addCallbackArgument("indx", indx);
        ajaxResponse.print();
    }
}
