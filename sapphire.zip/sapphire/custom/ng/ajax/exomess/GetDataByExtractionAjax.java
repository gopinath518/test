package sapphire.custom.ng.ajax.exomess;

import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetDataByExtractionAjax extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String scanvalue = ajaxResponse.getRequestParameter("scanvalue");
        String sql = Util.parseMessage(MolecularSql.GET_DATA_BY_SM_EXT, StringUtil.replaceAll(scanvalue, ";", "','"),
                StringUtil.replaceAll(scanvalue, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
            showResponse(ajaxResponse, "Success", "Y", dsSampleInfo);
        } else {
            showResponse(ajaxResponse, "Please scan valid Elution Tube.", "N", dsSampleInfo);
        }
    }

    private void showResponse(AjaxResponse ajaxResponse, String msg, String isStatus, DataSet dsInfo) {
        ajaxResponse.addCallbackArgument("isstatus", isStatus);
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("dataset", dsInfo);
        ajaxResponse.print();
    }
}
