package sapphire.custom.ng.ajax.exomess;

import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * @Desc: Created to replicate the workflow for NanoString for 1.6.1 Release
 * createdby: surajit.baitalik
 */

public class ScanExtExomeForReplicate extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String scannedtube = ajaxResponse.getRequestParameter("scannedtube", "");
        if (Util.isNull(scannedtube)) {
            getResponse(ajaxResponse, "NA", "<b>Elution tube can't be blank.</b>", null);
            return;
        }
        String sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_TUBE_BY_EXTID_EXOME, scannedtube);
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo == null || dsInfo.size() == 0) {
            getResponse(ajaxResponse, "NF", "<b>Please scan valid extraction id for NanoString only.</b>", dsInfo);
            return;
        }
        HashMap hm = new HashMap();
        if (dsInfo.size() > 0) {
            hm.clear();
            hm.put("specimentype", "Ellution Tube");
            DataSet dsExtrctFilter = dsInfo.getFilteredDataSet(hm);
            if (dsExtrctFilter.size() == 0) {
                getResponse(ajaxResponse, "NF", "<b>Replicate workflow is not allow for " + scannedtube + "</b>", dsInfo);
                return;
            }
            String extmetrlchk = dsExtrctFilter.getColumnValues("u_type", ";");
            if (dsExtrctFilter.size() > 0 && !extmetrlchk.contains("EU")) {
                hm.clear();
                hm.put("specimentype", "Extraction Tube");
                DataSet dsExtrcFilter = dsInfo.getFilteredDataSet(hm);
                getResponse(ajaxResponse, "Y", "<b>Data found.</b>", dsExtrcFilter);
                return;
            }
            if (dsExtrctFilter.size() > 0 && extmetrlchk.contains("EU")) {
                hm.clear();
                hm.put("u_type", "EU");
                DataSet dsExtrcFilter = dsInfo.getFilteredDataSet(hm);
                getResponse(ajaxResponse, "Y", "<b>Data found.</b>", dsExtrcFilter);
                return;
            }
        }
    }

    private void getResponse(AjaxResponse ajaxResponse, String msgtype, String msg, DataSet dsResult) {
        ajaxResponse.addCallbackArgument("msgtype", msgtype);
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("dataset", dsResult);
        ajaxResponse.print();
    }
}
