package sapphire.custom.ng.ajax.exomess;

import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class MolarityCalculation extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String inputval = ajaxResponse.getRequestParameter("inputval", "0.0");
        String sampleid = ajaxResponse.getRequestParameter("sampleid", "");
        String indx = ajaxResponse.getRequestParameter("indx", "");
        String id = ajaxResponse.getRequestParameter("id", "");
        String tagid = ajaxResponse.getRequestParameter("tagid", "");
        String sql = Util.parseMessage(MolecularSql.GET_MOLARITY_CAL_BY_DILUTION_TUBE, sampleid);
        DataSet dsDilutionTube = getQueryProcessor().getSqlDataSet(sql);
        if (dsDilutionTube != null && dsDilutionTube.size() > 0) {
            DataSet dsDilutionCal = new DataSet();
            dsDilutionCal.addColumn("concentration", DataSet.STRING);
            dsDilutionCal.addColumn("amntofsample", DataSet.STRING);
            dsDilutionCal.addColumn("amntofwater", DataSet.STRING);
            dsDilutionCal.addColumn("inputvol", DataSet.STRING);
            dsDilutionCal.addColumn("sampledilution", DataSet.STRING);
            double averagesize = Double.parseDouble(dsDilutionTube.getValue(0, "averagesize", ""));
            double bioanalizerconc = Double.parseDouble(dsDilutionTube.getValue(0, "bioanalizerconc", ""));
            double bioanalizerconc1 = Double.parseDouble(dsDilutionTube.getValue(0, "bioanalizerconc1", ""));
            double concentration = Double.parseDouble(dsDilutionTube.getValue(0, "concentration", ""));
            double conacquantid = Double.parseDouble(dsDilutionTube.getValue(0, "conacquantid", ""));
            double stocktodilute = Double.parseDouble(dsDilutionTube.getValue(0, "stocktodilute", ""));
            double concdesired = Double.parseDouble(dsDilutionTube.getValue(0, "concdesired", ""));
            double tetodilute = Double.parseDouble(dsDilutionTube.getValue(0, "tetodilute", ""));
            if ("stocktodilute".equalsIgnoreCase(tagid)) {
                stocktodilute = Double.parseDouble(inputval);
            } else if ("concdesired".equalsIgnoreCase(tagid)) {
                concdesired = Double.parseDouble(inputval);
            }
            if (averagesize > 0) {
                bioanalizerconc = bioanalizerconc1 / (660 * averagesize) * Math.pow(10.0, 6.0);
                bioanalizerconc = Util.roundAvoid(bioanalizerconc);
                if (Double.isInfinite(bioanalizerconc))
                    bioanalizerconc = 0.0;
                conacquantid = concentration / (660 * averagesize) * Math.pow(10.0, 6.0);
                conacquantid = Util.roundAvoid(conacquantid);
                if (Double.isInfinite(conacquantid))
                    conacquantid = 0.0;
            }
            if (conacquantid > 0) {
                tetodilute = (stocktodilute * conacquantid) / concdesired - stocktodilute;
                tetodilute = Util.roundAvoid(tetodilute);
                if (Double.isInfinite(tetodilute))
                    tetodilute = 0.0;
            }
            getResponse(ajaxResponse, "Calculated", String.valueOf(tetodilute), indx);
        }
    }

    public void getResponse(AjaxResponse ajaxResponse, String msg, String tetodialute, String indx) {
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("tetodialute", tetodialute);
        ajaxResponse.addCallbackArgument("indx", indx);
        ajaxResponse.print();
    }

}
