package sapphire.custom.ng.ajax;

import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by msubhra on 6/10/2016.
 */
public class AddTestDilutionTube extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        String newsampleid = sampleid.replaceAll(";",",");
        String sql ="select u_testcodeid from u_testcode where u_testcodeid in (select  distinct lvtestcodeid from u_sampletestcodemap where s_sampleid in ('"+newsampleid+"'))";
        DataSet ds=getQueryProcessor().getSqlDataSet(sql);

        String testcode = ds.getColumnValues("u_testcodeid",";");
        ajaxResponse.addCallbackArgument("testcode",testcode);
        ajaxResponse.print();

    }
}
