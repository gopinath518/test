package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by SBaitalik on 1/3/2017.
 */
public class AccessionAssignTestAjax extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String testcodeid = ajaxResponse.getRequestParameter("testcodeid", "");
        String sampleids = ajaxResponse.getRequestParameter("sampleids", "");
        String accessionid = ajaxResponse.getRequestParameter("accessionid", "");

        DataSet ds = new DataSet();
        ds.addColumn("sampleid", DataSet.STRING);
        ds.addColumn("lvtestcodeid", DataSet.STRING);
        String sampleIdArry[] = StringUtil.split(sampleids, ";");
        for (int i = 0; i < sampleIdArry.length; i++) {
            int rowID = ds.addRow();
            ds.setValue(rowID, "sampleid", sampleIdArry[i]);
            ds.setValue(rowID, "lvtestcodeid", testcodeid);
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, ds.getColumnValues("sampleid", ";"));
        prop.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, ds.getColumnValues("lvtestcodeid", ";"));
        try {
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, prop);
            DataSet dsSampleInfo = getSmapleInfo(accessionid);
            ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
            ajaxResponse.print();
        } catch (Exception e) {

        }

    }

    private DataSet getSmapleInfo(String accessionid) throws SapphireException {
        DataSet dsInfo = null;
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("s_sampleid", DataSet.STRING);
        dsFinal.addColumn("u_clientspecimenid", DataSet.STRING);
        dsFinal.addColumn("testcode", DataSet.STRING);
        dsFinal.addColumn("testname", DataSet.STRING);
        dsFinal.addColumn("sampletypeid", DataSet.STRING);
        dsFinal.addColumn("u_bodysite", DataSet.STRING);
        dsFinal.addColumn("u_sampleinformation", DataSet.STRING);
        dsFinal.addColumn("collectiondt", DataSet.STRING);
        dsFinal.addColumn("containertypeid", DataSet.STRING);
        dsFinal.addColumn("u_type", DataSet.STRING);
        dsFinal.addColumn("u_accessioningcomplete", DataSet.STRING);
        String sql = "select distinct u_type,t.containertypeid,s.s_sampleid,s.sampletypeid,s.u_accessioningcomplete,s.u_clientspecimenid," +
                " s.u_bodysite,s.u_sampleinformation,s.collectiondt,s.u_type" +
                " from s_sample s, u_sampletestcodemap stp, trackitem t where" +
                " s.s_sampleid=t.linkkeyid1" +
                " and" +
                " s.u_accessionid='" + accessionid + "'";
        dsInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsInfo != null && dsInfo.size() > 0) {
            for (int i = 0; i < dsInfo.size(); i++) {
                int rowID = dsFinal.addRow();
                dsFinal.setValue(rowID, "s_sampleid", dsInfo.getValue(i, "s_sampleid", ""));
                dsFinal.setValue(rowID, "u_clientspecimenid", dsInfo.getValue(i, "u_clientspecimenid", ""));
                dsFinal.setValue(rowID, "sampletypeid", dsInfo.getValue(i, "sampletypeid", ""));
                dsFinal.setValue(rowID, "u_bodysite", dsInfo.getValue(i, "u_bodysite", ""));
                dsFinal.setValue(rowID, "u_sampleinformation", dsInfo.getValue(i, "u_sampleinformation", ""));
                dsFinal.setValue(rowID, "collectiondt", dsInfo.getValue(i, "collectiondt", ""));
                dsFinal.setValue(rowID, "containertypeid", dsInfo.getValue(i, "containertypeid", ""));
                dsFinal.setValue(rowID, "u_type", dsInfo.getValue(i, "u_type", ""));
                dsFinal.setValue(rowID, "u_accessioningcomplete", dsInfo.getValue(i, "u_accessioningcomplete", ""));
            }
        }

        sql = "select distinct stp.lvtestcodeid,stp.testname,s.u_type,t.containertypeid,s.s_sampleid,s.sampletypeid,s.u_accessioningcomplete,s.u_clientspecimenid," +
                " s.u_bodysite,s.u_sampleinformation,s.collectiondt,s.u_type" +
                " from s_sample s, u_sampletestcodemap stp, trackitem t where" +
                " s.s_sampleid=t.linkkeyid1" +
                " and stp.s_sampleid=s.s_sampleid" +
                " and s.u_accessionid='" + accessionid + "'";
        DataSet dsSampInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampInfo != null && dsSampInfo.size() > 0) {
            for (int i = 0; i < dsFinal.size(); i++) {
                HashMap hm = new HashMap();
                hm.put("s_sampleid", dsFinal.getValue(i, "s_sampleid", ""));
                DataSet dsFilter = dsSampInfo.getFilteredDataSet(hm);
                if (dsFilter != null && dsFilter.size() > 0) {
                    dsFinal.setValue(i, "testcode", dsFilter.getColumnValues("lvtestcodeid", ", "));
                    dsFinal.setValue(i, "testname", dsFilter.getColumnValues("testname", ", "));
                } else {
                    dsFinal.setValue(i, "testcode", "");
                    dsFinal.setValue(i, "testname", "");
                }
            }
        }

        return dsFinal;
    }
}
