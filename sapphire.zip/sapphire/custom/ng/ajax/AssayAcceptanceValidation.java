package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.IsNull;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;

import sapphire.action.AddSDI;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 3/30/2017.
 */
public class AssayAcceptanceValidation extends BaseAjaxRequest {


    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);

        String batchid = "", reagentFail = "", reagentlotFail = "";

        try {
            if (ajaxResponse == null)
                throw new SapphireException("Ajaxresponse object is obatined as null.");
            DataSet dsFail = new DataSet();
            dsFail.addColumn("samp", DataSet.STRING);
            //dsFail.addColumn("spec", DataSet.STRING);
            dsFail.addColumn("comment", DataSet.STRING);


            batchid = ajaxResponse.getRequestParameter("selectedbatch", "");
            String sampleids = ajaxResponse.getRequestParameter("sampleids", "");
            /*if (sampleid.indexOf(";") == 0 )
                sampleid = sampleid.substring(1);*/
            String sql = "";
            String sqlacceptancecomment = "";

            if (!Util.isNull(batchid)) {

                sql = "select a.KEYID1, splt.CONDITION, spl.SPECID, spl.PARAMID, spl.PARAMLISTID," +
                        "spl.OPERATOR1, spl.VALUE1, spl.OPERATOR2, spl.VALUE2, a.ENTEREDVALUE, ss.U_ASSAYACCEPTABLECOMMENT, rt.reagentlotid, rt.reagenttypeid " +
                        "from SDIDATAITEM a " +
                        "INNER JOIN SDISPEC b ON a.KEYID1=b.KEYID1 " +
                        "INNER JOIN speclimittype splt ON b.SPECID=splt.SPECID and b.SPECVERSIONID=splt.SPECVERSIONID " +
                        "INNER JOIN specparamlimits spl ON a.PARAMLISTID=spl.PARAMLISTID and a.PARAMLISTVERSIONID=spl.PARAMLISTVERSIONID and a.PARAMID=spl.PARAMID " +
                        "INNER JOIN s_sample ss ON a.KEYID1=ss.S_SAMPLEID " +
                        "INNER JOIN reagentlot rt ON ss.REAGENTLOTID=rt.REAGENTLOTID " +
                        "where a.KEYID1 in (select sampleid from U_NGBATCH_CONTROL where u_ngbatchid in ('" + StringUtil.replaceAll(batchid, ";", "','") + "')) " +
                        "and a.ENTEREDVALUE is not null";
                //"('" + StringUtil.replaceAll(batchid, ";", "','") + "'))";

                DataSet dsconditioninfo = getQueryProcessor().getSqlDataSet(sql);
                HashMap specMap = new HashMap();
                if (dsconditioninfo == null) {
                    throw new SapphireException("Error : Query does not return anything !!! ... ");
                }

                dsconditioninfo.sort("keyid1");
                ArrayList<DataSet> dsconditioninfoArr = dsconditioninfo.getGroupedDataSets("keyid1");

                if (dsconditioninfoArr == null)
                    throw new SapphireException("ArrayList object dsconditioninfoArr is obtained as null");

                for (int i = 0; i < dsconditioninfoArr.size(); i++) {

                    DataSet dsEach = (DataSet) dsconditioninfoArr.get(i);

                    String operator1 = "";
                    String operator2 = "";
                    String value1 = "";
                    String value2 = "";
                    String enteredvalue = "";
                    String assayacceptancecomment = "";
                    String specid = "";
                    String specversionid = "";
                    String condition = "";
                    String reagenttype = "";
                    String reagentlot = "";

                    if (dsEach != null && dsEach.size() > 0) {
                        for (int j = 0; j < dsEach.size(); j++) {
                            operator1 = dsEach.getValue(j, "operator1");
                            operator2 = dsEach.getValue(j, "operator2");
                            value1 = dsEach.getValue(j, "value1");
                            value2 = dsEach.getValue(j, "value2");
                            enteredvalue = dsEach.getValue(j, "enteredvalue");
                            assayacceptancecomment = dsEach.getValue(j, "assayacceptancecomment");
                            specid = dsEach.getValue(j, "specid");
                            specversionid = dsEach.getValue(j, "specversionid");
                            condition = dsEach.getValue(j, "condition");
                            reagenttype = dsEach.getValue(j, "reagenttypeid");
                            reagentlot = dsEach.getValue(j, "reagentlotid");

                            specMap.put("operator1", operator1);
                            specMap.put("operator2", operator2);
                            specMap.put("value1", value1);
                            specMap.put("value2", value2);
                            specMap.put("enteredvalue", enteredvalue);
                            specMap.put("u_assayacceptablecomment", assayacceptancecomment);
                            specMap.put("specid", specid);
                            specMap.put("SPECVERSIONID", specversionid);
                            specMap.put("reagenttypeid", reagenttype);
                            specMap.put("reagentlotid", reagentlot);

                            String specResult = validateSpec(getSpecType(specMap), specMap, condition);
                            if ("Fail".equalsIgnoreCase(specResult) && Util.isNull(dsEach.getValue(j, "u_assayacceptablecomment", ""))) {
                                //sampleFail += ";" + dsEach.getValue(j, "keyid1");
                                reagentFail += ";" + reagenttype;
                                reagentlotFail += ";" + reagentlot;
                            }
                        }
                    }
                }
            }
            //ajaxResponse.addCallbackArgument("sampleids", sampleFail.substring(1));
            String uniqueReagentFail = "";
            String uniqueReagentLotFail = "";
            if (!Util.isNull(reagentFail)) {
                uniqueReagentFail = Util.getUniqueList(reagentFail.substring(1), ";", true);
                uniqueReagentLotFail = Util.getUniqueList(reagentlotFail.substring(1), ";", true);
            }
            //TODO CHECK REPORT IS GENERATED OR NOT ALREADY
            sql = Util.parseMessage(MolecularSql.GET_REPORT_VERSION_FOR_MOL, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsReportDetails = getQueryProcessor().getSqlDataSet(sql);
            ajaxResponse.addCallbackArgument("reagenttype", uniqueReagentFail);
            ajaxResponse.addCallbackArgument("reagentlotid", uniqueReagentLotFail);
            ajaxResponse.addCallbackArgument("dataset", dsReportDetails);

        } catch (Exception exp) {
            ajaxResponse.setError(exp.getMessage());

        } finally {
            ajaxResponse.print();
        }
    }

    private String validateSpec(String specType, HashMap<String, String> specMap, String condition) throws SapphireException {
        String specVal = "";
        switch (specType) {
            case "GREATERTHAN":
                if ("Pass".equalsIgnoreCase(condition) && (Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value1"))))
                    specVal = "Pass";
                break;
            case "LESSTHAN":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;
            case "GREATERTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value1")))
                    specVal = "Pass";
                break;
            case "LESSTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;

            case "GREATER":
                if (Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value1")))
                    specVal = "Pass";
                break;
            case "LESS":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;
            case "GREATEREQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value1")))
                    specVal = "Pass";
                break;
            case "LESSEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;

            case "BETWEENGREATERTHANLESSTHAN":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value2")))
                    specVal = "Fail";
                else
                    specVal = "Pass";
                break;
            case "BETWEENGREATERTHANEQUALLESSTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value2")))
                    specVal = "Fail";
                else
                    specVal = "Pass";
                break;
            case "BETWEENGREATERTHANEQUALLESSTHAN":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value2"))) {
                    specVal = "Fail";
                } else {
                    specVal = "Pass";
                }
                break;
            case "BETWEENGREATERTHANLESSTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value2")))
                    specVal = "Fail";
                else
                    specVal = "Pass";
                break;
            default:
                specVal = "";
                break;
        }
        return specVal;

    }

    private String getSpecType(HashMap<String, String> specMap) throws SapphireException {
        if (specMap != null && specMap.size() > 0) {
            if (">".equalsIgnoreCase(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "GREATERTHAN";
            else if ("<".equalsIgnoreCase(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "LESSTHAN";
            else if (">=".equalsIgnoreCase(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "GREATERTHANEQUAL";
            else if ("<=".equals(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "LESSTHANEQUAL";

            if (">".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "GREATER";
            else if ("<".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "LESS";
            else if (">=".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "GREATEREQUAL";
            else if ("<=".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "LESSEQUAL";

            else if (">".equalsIgnoreCase(specMap.get("operator1")) && "<".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANLESSTHAN";
            else if (">=".equalsIgnoreCase(specMap.get("operator1")) && "<=".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANEQUALLESSTHANEQUAL";
            else if (">=".equalsIgnoreCase(specMap.get("operator1")) && "<".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANEQUALLESSTHAN";
            else if (">".equalsIgnoreCase(specMap.get("operator1")) && "<=".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANLESSTHANEQUAL";
        }
        return "";
    }
}
