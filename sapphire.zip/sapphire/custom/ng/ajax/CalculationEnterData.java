package sapphire.custom.ng.ajax;

import com.labvantage.sapphire.gwt.shared.error.ErrorDetail;
import org.json.JSONArray;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.BaseAjaxRequest;
import groovy.lang.GroovyShell;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by achakraborty on 10/25/2016.
 */
public class CalculationEnterData extends BaseAjaxRequest {
    AjaxResponse ajaxResponse;
    String autobatch = "";

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        ajaxResponse = new AjaxResponse(request, response);
        String arryData = ajaxResponse.getRequestParameter("arryData");
        autobatch = ajaxResponse.getRequestParameter("autobatch", "");
        if (arryData != null) {
            try {
                DataSet dsInput = new DataSet();
                dsInput.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
                dsInput.addColumn(DATASET_PROPERTY_PARAMLISTID, DataSet.STRING);
                dsInput.addColumn(DATASET_PROPERTY_PARAMID, DataSet.STRING);
                dsInput.addColumn(DATASET_PROPERTY_PARAM_VALUE, DataSet.STRING);
                dsInput.addColumn(DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, DataSet.STRING);
                dsInput.addColumn(DATASET_PROPERTY_RESULTS, DataSet.STRING);

                DataSet dsFinalInput = new DataSet();
                dsFinalInput.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
                dsFinalInput.addColumn(DATASET_PROPERTY_PARAMLISTID, DataSet.STRING);
                dsFinalInput.addColumn(DATASET_PROPERTY_PARAMID, DataSet.STRING);
                dsFinalInput.addColumn(DATASET_PROPERTY_PARAM_VALUE, DataSet.STRING);
                dsFinalInput.addColumn(DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, DataSet.STRING);
                dsFinalInput.addColumn(DATASET_PROPERTY_RESULTS, DataSet.STRING);
                JSONArray jarr = new JSONArray(arryData);
                for (int i = 0; i < jarr.length(); i++) {
                    int rowId = dsInput.addRow();
                    JSONObject obj = jarr.getJSONObject(i);
                    String sampleid = obj.getString("sampleid");
                    String paramlistid = obj.getString("testcode");
                    String isInputParam = obj.getString("isInputParam");
                    String results = obj.getString("results");
                    String orgParamId = obj.getString("orgParamId");
                    String value = obj.getString("value");

                    dsInput.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID, sampleid);
                    dsInput.setValue(rowId, DATASET_PROPERTY_PARAMLISTID, paramlistid);
                    dsInput.setValue(rowId, DATASET_PROPERTY_PARAMID, orgParamId);
                    dsInput.setValue(rowId, DATASET_PROPERTY_PARAM_VALUE, value);
                    dsInput.setValue(rowId, DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, isInputParam);
                    dsInput.setValue(rowId, DATASET_PROPERTY_RESULTS, results);

                    /*if (!Util.isNull(results)) {
                        int newRowId = dsInput.addRow();
                        dsInput.setValue(newRowId, DATASET_PROPERTY_SAMPLE_ID, sampleid);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_PARAMLISTID, paramlistid);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_PARAMID, "RESULT");
                        dsInput.setValue(newRowId, DATASET_PROPERTY_PARAM_VALUE, results);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, isInputParam);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_RESULTS, results);
                    } else {
                        int newRowId = dsInput.addRow();
                        dsInput.setValue(newRowId, DATASET_PROPERTY_SAMPLE_ID, sampleid);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_PARAMLISTID, paramlistid);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_PARAMID, "RESULT");
                        dsInput.setValue(newRowId, DATASET_PROPERTY_PARAM_VALUE, results);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, isInputParam);
                        dsInput.setValue(newRowId, DATASET_PROPERTY_RESULTS, results);
                    }*/
                }

                String uniqueSampleIds[] = StringUtil.split(Util.getUniqueList(dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true), ";");
                String uniqueParamlistIds = Util.getUniqueList(dsInput.getColumnValues(DATASET_PROPERTY_PARAMLISTID, ";"), ";", true);
                HashMap hm = new HashMap();
                for (int i = 0; i < uniqueSampleIds.length; i++) {
                    hm.clear();
                    hm.put(DATASET_PROPERTY_SAMPLE_ID, uniqueSampleIds[i]);
                    DataSet dsFilter = dsInput.getFilteredDataSet(hm);
                    if (dsFilter != null && dsFilter.size() != 0) {
                        int rowID = dsFinalInput.addRow();
                        dsFinalInput.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID, uniqueSampleIds[i]);
                       /* dsFinalInput.setValue(rowID, DATASET_PROPERTY_PARAMLISTID, dsFilter.getColumnValues(DATASET_PROPERTY_PARAMLISTID, ";"));
                        dsFinalInput.setValue(rowID, DATASET_PROPERTY_PARAMID, dsFilter.getColumnValues(DATASET_PROPERTY_PARAMID, ";"));
                        dsFinalInput.setValue(rowID, DATASET_PROPERTY_PARAM_VALUE, dsFilter.getColumnValues(DATASET_PROPERTY_PARAM_VALUE, ";"));
                        dsFinalInput.setValue(rowID, DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, dsFilter.getColumnValues(DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE, ";"));
                        dsFinalInput.setValue(rowID, DATASET_PROPERTY_RESULTS, dsFilter.getColumnValues(DATASET_PROPERTY_RESULTS, ";"));*/
                    }
                }
                if (!dsInput.isValidColumn(DATASET_PROPERTY_PARAMLISTVERSIONID)) {
                    dsInput.addColumn(DATASET_PROPERTY_PARAMLISTVERSIONID, DataSet.STRING);
                }
                if (!dsInput.isValidColumn(DATASET_PROPERTY_VARIENTID)) {
                    dsInput.addColumn(DATASET_PROPERTY_VARIENTID, DataSet.STRING);
                }
                if (!dsInput.isValidColumn(DATASET_PROPERTY_PARAMTYPE)) {
                    dsInput.addColumn(DATASET_PROPERTY_PARAMTYPE, DataSet.STRING);
                }
                if (!dsInput.isValidColumn(DATASET_PROPERTY_REPLICATEID)) {
                    dsInput.addColumn(DATASET_PROPERTY_REPLICATEID, DataSet.STRING);
                }
                if (!dsInput.isValidColumn(DATASET_PROPERTY_DATASET)) {
                    dsInput.addColumn(DATASET_PROPERTY_DATASET, DataSet.STRING);
                }
                DataSet dsQuery = getSqlDataset(dsFinalInput, uniqueParamlistIds);
                for (int i = 0; i < dsInput.getRowCount(); i++) {
                    hm.clear();
                    hm.put("parentsampleid", dsInput.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
                    hm.put("paramlistid", dsInput.getValue(i, DATASET_PROPERTY_PARAMLISTID, ""));
                    hm.put("paramid", dsInput.getValue(i, DATASET_PROPERTY_PARAMID, ""));
                    DataSet dsFinalFilter = dsQuery.getFilteredDataSet(hm);
                    if (dsFinalFilter.size() != 0 && dsFinalFilter != null) {
                        dsInput.setValue(i, DATASET_PROPERTY_PARAMLISTVERSIONID, dsQuery.getValue(i, DATASET_PROPERTY_PARAMLISTVERSIONID, ""));
                        dsInput.setValue(i, DATASET_PROPERTY_VARIENTID, dsQuery.getValue(i, DATASET_PROPERTY_VARIENTID, ""));
                        dsInput.setValue(i, DATASET_PROPERTY_PARAMTYPE, dsQuery.getValue(i, DATASET_PROPERTY_PARAMTYPE, ""));
                        dsInput.setValue(i, DATASET_PROPERTY_REPLICATEID, dsQuery.getValue(i, DATASET_PROPERTY_REPLICATEID, ""));
                        dsInput.setValue(i, DATASET_PROPERTY_DATASET, dsQuery.getValue(i, DATASET_PROPERTY_DATASET, ""));
                    }
                }
                enteredData(dsInput);
                //TODO VISE VARSA, REFLECT DATA FROM CUSTOM DATA ENTRY PAGE TO OOB DATA ENTRY PAGE
                manualBatchEnterData(dsInput, autobatch);

                ajaxResponse.addCallbackArgument("msg", "Data Saved Successfully.");
                ajaxResponse.addCallbackArgument("isStatus", "1");
                ajaxResponse.print();
            } catch (Exception e) {
            }

        }
    }

    private DataSet getSqlDataset(DataSet dsFinalInput, String uniqueParamlistIds) {
        String sampleids = StringUtil.replaceAll(dsFinalInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", "','");
        String unqParamlistIds = StringUtil.replaceAll(uniqueParamlistIds, ";", "','");
        String sql = "select sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                " sd.dataset = sdi.dataset and sd.paramlistid in('" + unqParamlistIds + "') and  sd.keyid1 in ('" + sampleids + "')";
        DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql);
        return dsQuery;
    }

    private void enteredData(DataSet dsInput) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsInput.getColumnValues(DATASET_PROPERTY_PARAMLISTID, ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsInput.getColumnValues(DATASET_PROPERTY_PARAMLISTVERSIONID, ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsInput.getColumnValues(DATASET_PROPERTY_PARAMID, ";"));
        props.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsInput.getColumnValues(DATASET_PROPERTY_PARAM_VALUE, ";"));

        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsInput.getColumnValues(DATASET_PROPERTY_VARIENTID, ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsInput.getColumnValues(DATASET_PROPERTY_PARAMTYPE, ";"));
        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsInput.getColumnValues(DATASET_PROPERTY_REPLICATEID, ";"));
        props.setProperty(EnterDataItem.PROPERTY_DATASET, dsInput.getColumnValues(DATASET_PROPERTY_DATASET, ";"));
        props.setProperty("bypass", "Y");
        //props.setProperty("isFrom", "C");

        try {
            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
        } catch (SapphireException e) {
            ajaxResponse.addCallbackArgument("msg", "Data Saved Failed.");
            ajaxResponse.addCallbackArgument("isStatus", "2");
            ajaxResponse.print();
        }
        /*ajaxResponse.addCallbackArgument("msg", "Data Saved Successfully.");
        ajaxResponse.addCallbackArgument("isStatus", "1");
        ajaxResponse.print();*/
    }

    private void manualBatchEnterData(DataSet dsInput, String autobatchid) throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn("parentsampleid", DataSet.STRING);
        ds.addColumn("paramlistid", DataSet.STRING);
        ds.addColumn("paramlistversionid", DataSet.STRING);
        ds.addColumn("paramid", DataSet.STRING);
        ds.addColumn("enteredtext", DataSet.STRING);
        ds.addColumn("variantid", DataSet.STRING);
        ds.addColumn("paramtype", DataSet.STRING);
        ds.addColumn("replicateid", DataSet.STRING);
        ds.addColumn("dataset", DataSet.STRING);

        String sampleid = Util.getUniqueList(dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        String paramlistid = Util.getUniqueList(dsInput.getColumnValues(DATASET_PROPERTY_PARAMLISTID, ";"), ";", true);
        String sql = "select temp.s_sampleid,temp.u_accessionid,temp.u_extractionid,temp.patientname,temp.testcode,temp.testname from" +
                " (select d.s_sampleid,d.u_accessionid,d.u_extractionid,(f.u_lastname||','||f.u_firstname) patientname,d.u_concentrationratio," +
                " d.concentration,(select LISTAGG(tc.u_testcodeid, ', ') WITHIN GROUP (ORDER BY tc.u_testcodeid) AS testcode" +
                " from u_testcode tc  ,U_SAMPLETESTCODEMAP stp where tc.u_testcodeid=stp.lvtestcodeid and tc.testname=stp.testname and d.s_sampleid=stp.s_sampleid) testcode," +
                " (select LISTAGG(tc.testname, ', ') WITHIN GROUP (ORDER BY tc.u_testcodeid) AS testname" +
                " from u_testcode tc  ,U_SAMPLETESTCODEMAP stp" +
                " where tc.u_testcodeid=stp.lvtestcodeid and tc.testname=stp.testname and d.s_sampleid=stp.s_sampleid) testname," +
                " (select LISTAGG(stp.lvtestpanelid, ',') WITHIN GROUP (ORDER BY stp.lvtestpanelid) from u_sampletestcodemap stp, s_samplemap sm" +
                " where stp.s_sampleid=sm.sourcesampleid and d.s_sampleid=sm.DESTSAMPLEID)lvpanelid," +
                " (select a.ypos from arrayitem a,arrayitemcontent b where a.arrayitemid=b.arrayitemid and b.contentsdcid='Sample' and b.contentkeyid1=d.s_sampleid and rownum=1) ypos,\n" +
                " (select a.xpos from arrayitem a,arrayitemcontent b where a.arrayitemid=b.arrayitemid and b.contentsdcid='Sample' and b.contentkeyid1=d.s_sampleid and rownum=1) xpos\n" +
                " from s_sample d,u_accession e,s_subject f" +
                " where d.u_accessionid=e.u_accessionid and e.patientid=f.s_subjectid" +
                " and d.s_sampleid in(select c.sampleid from u_batch_sample_detail c" +
                " where c.u_ngbatchid in (select u_ngbatchid from u_ngbatch where mmerbatchid='" + autobatchid + "'))" +
                " ) temp order by temp.ypos,temp.xpos,temp.u_accessionid";
        DataSet dsManualSample = getQueryProcessor().getSqlDataSet(sql);
        sql = "select u_extractionid from s_sample where s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
        DataSet dsExtractionDetail = getQueryProcessor().getSqlDataSet(sql);
        String extractionid = Util.getUniqueList(dsExtractionDetail.getColumnValues("u_extractionid", ";"), ";", true);
        String arryExtrc[] = StringUtil.split(extractionid, ";");
        String manusamples = "";
        for (int i = 0; i < arryExtrc.length; i++) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("u_extractionid", arryExtrc[i]);
            DataSet dsFilter = dsManualSample.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                manusamples += ";" + dsFilter.getColumnValues("s_sampleid", ";");
            }
        }
        if (!Util.isNull(manusamples)) {
            manusamples = manusamples.substring(1);
            manusamples = Util.getUniqueList(manusamples, ";", true);
        }
        sql = "select sdi.enteredtext,sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                " sd.dataset = sdi.dataset and sd.paramlistid in('" + StringUtil.replaceAll(paramlistid, ";", "','") + "')" +
                " and  sd.keyid1 in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
        DataSet dsAutoMatchSampleDetails = getQueryProcessor().getSqlDataSet(sql);
        sql = "select sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                " sd.dataset = sdi.dataset and sd.paramlistid in('" + StringUtil.replaceAll(paramlistid, ";", "','") + "')" +
                " and  sd.keyid1 in ('" + StringUtil.replaceAll(manusamples, ";", "','") + "')";
        DataSet dsManualSampleData = getQueryProcessor().getSqlDataSet(sql);
        String paramlistidArry[] = StringUtil.split(paramlistid, ";");
        for (int i = 0; i < paramlistidArry.length; i++) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("paramlistid", paramlistidArry[i]);
            DataSet dsAutoBatchFilter = dsAutoMatchSampleDetails.getFilteredDataSet(hm);
            for (int j = 0; j < dsAutoBatchFilter.size(); j++) {
                hm.clear();
                //hm.put("paramlistversionid", dsAutoBatchFilter.getValue(j, "paramlistversionid", ""));
                hm.put("paramlistid", dsAutoBatchFilter.getValue(j, "paramlistid", ""));
                //hm.put("variantid", dsAutoBatchFilter.getValue(j, "variantid", ""));
                hm.put("paramid", dsAutoBatchFilter.getValue(j, "paramid", ""));
                //hm.put("dataset", dsAutoBatchFilter.getValue(j, "dataset", ""));
                //hm.put("replicateid", dsAutoBatchFilter.getValue(j, "replicateid", ""));
                DataSet dsManualDataFilter = dsManualSampleData.getFilteredDataSet(hm);
                if (dsManualDataFilter != null && dsManualDataFilter.size() > 0) {
                    int rowID = ds.addRow();
                    ds.setValue(rowID, "parentsampleid", dsManualDataFilter.getValue(0, "parentsampleid", ""));
                    ds.setValue(rowID, "paramlistid", dsAutoBatchFilter.getValue(j, "paramlistid", ""));
                    ds.setValue(rowID, "paramlistversionid", dsAutoBatchFilter.getValue(j, "paramlistversionid", ""));
                    ds.setValue(rowID, "paramid", dsAutoBatchFilter.getValue(j, "paramid", ""));
                    ds.setValue(rowID, "enteredtext", dsAutoBatchFilter.getValue(j, "enteredtext", ""));
                    ds.setValue(rowID, "variantid", dsAutoBatchFilter.getValue(j, "variantid", ""));
                    ds.setValue(rowID, "paramtype", dsAutoBatchFilter.getValue(j, "paramtype", ""));
                    ds.setValue(rowID, "replicateid", dsAutoBatchFilter.getValue(j, "replicateid", ""));
                    ds.setValue(rowID, "dataset", dsAutoBatchFilter.getValue(j, "dataset", ""));
                }
            }
        }
        PropertyList props = new PropertyList();
        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataItem.PROPERTY_KEYID1, ds.getColumnValues("parentsampleid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, ds.getColumnValues("paramlistid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, ds.getColumnValues("paramlistversionid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMID, ds.getColumnValues("paramid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, ds.getColumnValues("enteredtext", ";"));

        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, ds.getColumnValues("variantid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, ds.getColumnValues("paramtype", ";"));
        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, ds.getColumnValues("replicateid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_DATASET, ds.getColumnValues("dataset", ";"));
        props.setProperty("bypass", "Y");

        try {
            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
        } catch (SapphireException e) {
            throw new SapphireException("EnterDataItem not performed." + e.getMessage());
        }

    }

    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "sampleid";
    private static final String DATASET_PROPERTY_PARAMLISTID = "paramlistid";
    private static final String DATASET_PROPERTY_PARAMID = "paramid";
    private static final String DATASET_PROPERTY_PARAM_VALUE = "value";
    private static final String DATASET_PROPERTY_IS_CALCULATION_RULE_DEFINE = "isInputParam";
    private static final String DATASET_PROPERTY_RESULTS = "results";

    private static final String DATASET_PROPERTY_PARAMLISTVERSIONID = "paramlistversionid";
    private static final String DATASET_PROPERTY_VARIENTID = "variantid";
    private static final String DATASET_PROPERTY_PARAMTYPE = "paramtype";
    private static final String DATASET_PROPERTY_REPLICATEID = "replicateid";
    private static final String DATASET_PROPERTY_DATASET = "dataset";
    private static final String DATASET_PROPERTY_ENTEREDTEXT = "eneteredtext";

    public void initializeDataSet() {
        if (dsFinal != null) {
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PARAMLISTID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PARAMID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PARAM_VALUE, DataSet.STRING);
        }
    }
}
