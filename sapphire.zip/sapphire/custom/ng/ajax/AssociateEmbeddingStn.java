package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Created by mpandey on 5/6/2016.
 * * Action Name- AssociateEmbeddingStn
 * Description: This Action is created to checkout cassette and assosite sample with embeding station
 * <p/>
 * Mandatory inputs
 * param1-cassetteid
 * param2-embeddingstation
 * throws SapphireException
 */

public class AssociateEmbeddingStn extends BaseAjaxRequest {
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        ajaxResponse.addCallbackArgument("err", "empty");
        ajaxResponse.addCallbackArgument("msg", "empty");
        String cassetteid = ajaxResponse.getRequestParameter("cassette");
        String embeddingstation = ajaxResponse.getRequestParameter("embeddingstation");
        try {
            updateCassette(cassetteid, embeddingstation);
            ajaxResponse.addCallbackArgument("msg", "Scanned Cassettes into Embedding station sucessfully.");
        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Error in update Cassette:- ");
            error += e.getMessage();
            ajaxResponse.addCallbackArgument("err", error);
        } finally {
            ajaxResponse.print();
        }

    }

    /**
     * This method is use to update cassette property in trackitem.
     *
     * @param cassette
     * @param embeddingStn
     */
    private void updateCassette(String cassette, String embeddingStn) throws SapphireException {

        String sql = "select * from trackitem where currentstorageunitid in (" +
                "select storageunitid from storageunit where linkkeyid1 in('" + StringUtil.replaceAll(cassette, ";", "','") + "'))";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String sampleid = ds.getColumnValues("linkkeyid1", ";");
        String samplearr[] = sampleid.split(";");
        String cassettearr[] = cassette.split(";");
        if (samplearr.length != cassettearr.length || ("".equals(sampleid) && !"".equals(cassette)) || (!"".equals(sampleid) && "".equals(cassette)))
            throw new SapphireException("Please enter valid cassette ID");
        else {
            //Edit trackitem ocassette.
            PropertyList props = new PropertyList();
            try {
                props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
                props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("trackitemid", ";"));
                props.setProperty("currentstorageunitid", "");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Can't update track item SDC");
                error += ae.getMessage();
                // throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

            }

            try {
                PropertyList plCompleteStep = new PropertyList();
                plCompleteStep.setProperty("sdcid", "Sample");
                plCompleteStep.setProperty("keyid1", sampleid);
                plCompleteStep.setProperty("u_embeddingstation", embeddingStn);
                getActionProcessor().processAction("EditSDI", "1", plCompleteStep);

                // PropertyList plCompleteStep = new PropertyList();
                plCompleteStep.clear();
                plCompleteStep.setProperty("currentstep", "Processing");
                plCompleteStep.setProperty("nextstep", "Embedding");
                plCompleteStep.setProperty("sampleid", sampleid);
                getActionProcessor().processAction("CompleteStep", "1", plCompleteStep);
            } catch (ActionException e) {
                e.printStackTrace();
            }


        }


    }

}



