package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by rrmandal on 2/28/2017.
 */
public class AddMutation extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String resultMutations="";
        String resultDesc="";
        String addNewMutation="N";
        String successfulAdd="N";
        String mutations="";
        String desc="";
        String type="";
        String paramid="";
        try{
            mutations= ajaxResponse.getRequestParameter("mutation","");
            desc= ajaxResponse.getRequestParameter("desc","");
            type= ajaxResponse.getRequestParameter("type","");
            paramid= ajaxResponse.getRequestParameter("paramid","");
            if(Util.isNull(mutations))
                throw new SapphireException("No mutation is obtained");
            String sql = "";
            if("Global".equalsIgnoreCase(type))
                sql = "select mutationname from u_mutation where mutationname in('"+ StringUtil.replaceAll(mutations,";","','")+"')";
            else if ("Local".equalsIgnoreCase(type))
                sql= "select mutationname from u_parammutationmap where mutationname in('"+ StringUtil.replaceAll(mutations,";","','")+"')";
            DataSet dsMutationInfo =  getQueryProcessor().getSqlDataSet(sql);
            if(dsMutationInfo==null)
                throw new SapphireException("Dataset is obtained as null. Please check the database connection.");

            if(dsMutationInfo.size()==0) {
                resultMutations = mutations;
                String mutationArr[]=StringUtil.split(mutations,";");
                String descArr[]=null;
                if(!Util.isNull(desc))
                    descArr=StringUtil.split(desc,";");
                if(mutationArr!=null && descArr!=null && mutationArr.length==descArr.length)
                    resultDesc=desc;
                else{
                    for(int i=0;i<mutationArr.length;i++){
                        if(descArr!=null && descArr.length>i)
                            resultDesc+=";"+descArr[i];
                        else
                            resultDesc+=";";
                    }
                }
            }
            else{
                String mutationArr[]=StringUtil.split(mutations,";");
                String descArr[]=null;
                if(!Util.isNull(desc))
                    descArr=StringUtil.split(desc,";");
                if(mutationArr==null || mutationArr.length==0)
                    throw new SapphireException("Mutation Array object is obtained as null");
                HashMap<String,String> hmap = new HashMap<String,String>();
                for(int i=0;i<mutationArr.length;i++){
                    hmap.clear();
                    hmap.put("mutationname",mutationArr[i]);
                    DataSet dsFiltr=dsMutationInfo.getFilteredDataSet(hmap);
                    if(dsFiltr==null || dsFiltr.size()==0) {
                        resultMutations += ";" + mutationArr[i];
                        if(descArr!=null && descArr.length>i)
                            resultDesc+=";"+descArr[i];
                        else
                            resultDesc+=";";
                    }
                }
            }
            if(!Util.isNull(resultMutations)) {
                addNewMutation="Y";
                if(resultMutations.startsWith(";"))
                    resultMutations = resultMutations.substring(1);
                if(!Util.isNull(resultDesc) && resultDesc.startsWith(";"))
                    resultDesc=resultDesc.substring(1);
                String resultMutationsArr[]=StringUtil.split(resultMutations,";");
                if(resultMutationsArr!=null && resultMutationsArr.length>0) {
                    PropertyList prop = new PropertyList();
                    if("Global".equalsIgnoreCase(type))
                        prop.setProperty(AddSDI.PROPERTY_SDCID, "Mutation");
                    else if("Local".equalsIgnoreCase(type)) {
                        prop.setProperty(AddSDI.PROPERTY_SDCID, "ParamMutationMap");
                        prop.setProperty("paramid", paramid);
                    }
                    prop.setProperty("mutationname", resultMutations);
                    if(!Util.isNull(resultDesc))
                        prop.setProperty("description", resultDesc);
                    prop.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(resultMutationsArr.length));
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                    successfulAdd = "Y";
                }
            }
        }
        catch (Exception exp){
            ajaxResponse.setError(exp.getMessage());
        }
        finally {
            ajaxResponse.addCallbackArgument("mutation", mutations);
            ajaxResponse.addCallbackArgument("addnewmutation", addNewMutation);
            ajaxResponse.addCallbackArgument("successfuladd", successfulAdd);
            ajaxResponse.print();
        }
    }
}
