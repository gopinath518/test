package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by DMondal on 10/18/2016.
 * Description: This ajax will call CreateAndFileCassatt action.
 */
public class CreateAndFileCassatteAjax extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                               ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String containerid = ajaxResponse.getRequestParameter("containerid");
        String cassetteid = ajaxResponse.getRequestParameter("cassetteid");
        String cassettecount = ajaxResponse.getRequestParameter("cassettecount");

        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty("sampleid", containerid);
        pl.setProperty("cassettecount", cassettecount);
        try {
           /*This is old Logic change
           if (!Util.isNull(cassetteid)) {
                checkContainer(containerid);
                containerCassetteValidation(containerid, cassetteid);
                getActionProcessor().processAction("CreateAndFileCassatt", "1", pl);
                String newsample = pl.getProperty("newsampleid");
                ajaxResponse.addCallbackArgument("newsample", newsample);
            } else {
                String destsampleid = checkAlreadyCassette(containerid);
                if (!Util.isNull(destsampleid)) {
                    ajaxResponse.addCallbackArgument("newsample", "#"+destsampleid);
                } else {
                    checkContainer(containerid);
                    getActionProcessor().processAction("CreateAndFileCassatt", "1", pl);
                    String newsample = pl.getProperty("newsampleid");
                    ajaxResponse.addCallbackArgument("newsample", newsample);
                }
            }*/
            ///checkContainer(containerid);   // - do not check its root sample or not because daughter tube may come from Fresh Frep
            String destsampleid = checkAlreadyCassette(containerid);
            if(!Util.isNull(cassetteid)){
                containerCassetteValidation(containerid, cassetteid);
                if(!Util.isNull(destsampleid)) {
                    ajaxResponse.addCallbackArgument("newsample", destsampleid);
                }
            }
            else if (!Util.isNull(destsampleid)) {
                ajaxResponse.addCallbackArgument("newsample", "#" + destsampleid);
            } else {
                getActionProcessor().processAction("CreateAndFileCassatt", "1", pl);
                String newsample = pl.getProperty("newsampleid");
                ajaxResponse.addCallbackArgument("newsample", newsample);
            }
        } catch (Exception e) {
            ajaxResponse.addCallbackArgument("newsample", e.getMessage());
            e.printStackTrace();
        } finally {
            ajaxResponse.print();
        }

    }

    /**
     * Description : This method will call after first cassette created.It will check that two given inputs are coming from same sample.
     *
     * @param containerid
     * @param cassetteid
     * @throws SapphireException
     */
    private void containerCassetteValidation(String containerid, String cassetteid) throws SapphireException {
        String sqlCassette = "select mp.sourcesampleid,  s.s_sampleid  from s_Sample  s, s_samplemap mp where " +
                " s_sampleid=mp.destsampleid and mp.sourcesampleid='" + containerid + "' and " +
                " (s.u_clientspecimenid='" + cassetteid + "'  or mp.destsampleid = '" + cassetteid + "')";
        DataSet dsCassette = getQueryProcessor().getSqlDataSet(sqlCassette);
        if (dsCassette == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlCassette;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsCassette.size() == 0) {
            String errStr = getTranslationProcessor().translate("This is not right combination of container and cassette.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
    }

    /**
     * Description : This method will check scan sample must be container id.
     *
     * @param containerid
     * @throws SapphireException
     */
    private void checkContainer(String containerid) throws SapphireException {
        String sqlCassette = "select mp.sourcesampleid,  s.s_sampleid  from s_Sample  s, s_samplemap mp where " +
                " s_sampleid=mp.sourcesampleid and mp.destsampleid='" + containerid + "'  ";
        DataSet dsCassette = getQueryProcessor().getSqlDataSet(sqlCassette);
        if (dsCassette == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlCassette;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsCassette.size() > 0) {
            String errStr = getTranslationProcessor().translate("This is not a container.Please scan container id only");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
    }

    /**
     * Description : This method will check container id already have cassette.Then it will open directly maintpage.
     *
     * @param containerid
     * @throws SapphireException
     */
    private String checkAlreadyCassette(String containerid) throws SapphireException {
        String destsampleid = "";
        String sqlCassette = "select mp.destsampleid,  s.s_sampleid  from s_Sample  s, s_samplemap mp where " +
                " s_sampleid=mp.sourcesampleid and mp.sourcesampleid='" + containerid + "'  ";
        DataSet dsCassette = getQueryProcessor().getSqlDataSet(sqlCassette);
        if (dsCassette == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlCassette;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsCassette.size() > 0) {
            destsampleid = dsCassette.getString(0, "destsampleid");
        }
        return destsampleid;
    }
}

