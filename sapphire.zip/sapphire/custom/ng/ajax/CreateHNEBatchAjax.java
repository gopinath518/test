package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.QueryProcessor;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by dgupta on 6/9/2016.
 */
public class CreateHNEBatchAjax extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String sampleids = ajaxResponse.getRequestParameter("sampleid");
        if (sampleids.startsWith(";")) sampleids = sampleids.substring(1);
        String[] sampleArr = StringUtil.split(sampleids, ";");
        String newbatch = "";
        if (sampleids.startsWith(";")) sampleids = sampleids.substring(1);
        logger.info("H&EBatching ", "samples and    " + sampleids);
        if (sampleids.length() == 0) {
            ajaxResponse.addCallbackArgument("msg", "Please scan samples first");
        } else if (sampleArr.length > 20) {
            ajaxResponse.addCallbackArgument("msg", "Maximum 20 samples allowed in batch you have " + sampleArr.length);
        } else {
            try {
                //H =H&E Slide, SH = Shared H&E slide,  CH = Client H&E slide
                String strSTMap = "select s_sampleid  from s_sample where  u_type in ('H', 'SH', 'CH') and  s_sampleid in ('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";
                DataSet dsSampleDb = getQueryProcessor().getSqlDataSet(strSTMap);
                if ((dsSampleDb.getRowCount() > 0) && (dsSampleDb.getRowCount() == sampleArr.length)) {
                    String sql = "select distinct los, methodology, testname from u_sampletestcodemap where s_sampleid in ('"
                            + dsSampleDb.getColumnValues("s_sampleid", "','") + "') and teststatus !='Cancelled'";
                    DataSet dsValidate = getQueryProcessor().getSqlDataSet(sql);
                    validateSamples(dsValidate);
                    //synchronized (this) {
                    String batchType = getBatchType(dsValidate, sampleids);  // you will get batch type here
                    newbatch = createNewBatch(batchType); // now new batch created with above batchtype
                    PropertyList plSempleStep = updateSampleStep(dsSampleDb, batchType);
                    createLastBatchDetail(sampleArr, StringUtil.split(newbatch, ";")[0], plSempleStep);
                    // }
                    ajaxResponse.addCallbackArgument("msg", "New Batch created  '" + newbatch + "'");
                    //ajaxResponse.print();
                    // return;
                } else
                    ajaxResponse.addCallbackArgument("msg", "All or some samples are not found in system.");
            } catch (Exception ex) {
                ex.printStackTrace();
                String error = getTranslationProcessor().translate("error while creating batch");
                error += ex.getMessage();
                ajaxResponse.addCallbackArgument("msg", error);
            }
        }
        ajaxResponse.print();
    }

    private String getBatchType(DataSet dsValidate, String sampleids) throws Exception {
        String batchType = "";
        String los = dsValidate.getString(0, "los");
        QueryProcessor qp = getQueryProcessor();
        String methodology = dsValidate.getString(0, "methodology");
        String testname = dsValidate.getString(0, "testname", "");
        String findlossql = "select  t.u_testcodeid, t.istechnicalreview, tm.s_sampleid  from u_sampletestcodemap tm,u_testcode t where tm.lvtestcodeid=t.u_testcodeid and" +
                " t.istechnicalreview='Y' and tm.teststatus !='Cancelled' and  tm.s_sampleid in (select sourcesampleid from s_samplemap where destsampleid in ('" + StringUtil.replaceAll(sampleids, ";", "','") + "')) ";
        DataSet dssql = qp.getSqlDataSet(findlossql);
        if (dssql != null && dssql.getRowCount() > 0) {
            los = "Technical";
        }
        String strBatchtypeSql = "select distinct methodology,los, batchtype, fishtype  from u_methlosbatch  where los= '" + los
                + "' and methodology = '" + methodology + "'  ";
        if (methodology.equalsIgnoreCase("FISH")) {
            if (testname.startsWith("HER")) {
                strBatchtypeSql = strBatchtypeSql + " and  upper(fishtype) like 'HER%' ";
            } else {
                strBatchtypeSql = strBatchtypeSql + " and upper(fishtype) like 'NON%' ";
            }

        }
        DataSet dsSampleTMap = qp.getSqlDataSet(strBatchtypeSql);
        if ((dsSampleTMap != null) && dsSampleTMap.getRowCount() > 0) {
            batchType = dsSampleTMap.getString(0, "batchtype", "");
        } else
            throw new SapphireException(getTranslationProcessor().translate("Batch type not found for methodology '" + methodology + "'  and LOS '"
                    + dsValidate.getString(0, "los") + "' and testname '" + testname + "'."));
        return batchType;

    }

    private String createNewBatch(String batchType) throws SapphireException {
        String batchId = "";
        String newBatchIds = "";
        SimpleDateFormat sdf = new SimpleDateFormat("MMddyyy");
        String today = sdf.format(new Date());
        String tempBatchId = batchType + "_" + today + "_";
        String batchSuffix = "" + (char) 64;
        String sql = "select max(u_hnebatchid)  u_hnebatchid from u_hnebatch  where u_hnebatchid like '%" + today +
                "%' and  hnebatchtype ='" + batchType + "' ";
        DataSet dsBatch = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatch.getString(0, "u_hnebatchid") != null) {
            batchId = dsBatch.getString(0, "u_hnebatchid");
            if (batchId.lastIndexOf('_') <= batchId.length()) {
                tempBatchId = batchId.substring(0, (batchId.lastIndexOf('_') + 1));
                batchSuffix = batchId.substring((batchId.lastIndexOf('_') + 1), batchId.length());
            } else {
                tempBatchId = batchId + "_";
                batchSuffix = "A";
            }
        }
        if (batchSuffix.equalsIgnoreCase("Z")) {
            tempBatchId = tempBatchId + batchSuffix;
            batchSuffix = "" + (char) 64;
        }
        batchSuffix = "" + (char) (batchSuffix.charAt(0) + 1);
        newBatchIds = tempBatchId + batchSuffix;
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "HNEBatch");
        props.setProperty(AddSDI.PROPERTY_KEYID1, newBatchIds);
        props.setProperty("hnebatchtype", batchType);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        return props.getProperty("newkeyid1", "");
    }


    private void createLastBatchDetail(String[] sampleArr, String newBatches, PropertyList plSempleStep) throws SapphireException {
        String detailBatch = "";
        String sampleids = "";
        String orderid = "";
        for (int j = 0; j < sampleArr.length; j++) {
            detailBatch = detailBatch + ";" + newBatches;
            sampleids = sampleids + ";" + sampleArr[j];
            orderid = orderid + ";" + (j + 1);
        }
        PropertyList plDetails = new PropertyList();
        plDetails.setProperty(AddSDI.PROPERTY_SDCID, "HNEBatchDetail");
        plDetails.setProperty("batchid", detailBatch.substring(1));
        plDetails.setProperty("sampleid", sampleids.substring(1));  // no change for now
        plDetails.setProperty("usersequence", orderid.substring(1));  // no change for now
        plDetails.setProperty("copies", "" + sampleArr.length);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plDetails);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plSempleStep);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch Details" + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        return;
    }

    private PropertyList updateSampleStep(DataSet dsSampleTMap, String batchType) throws SapphireException {
        entryBatchCreator(dsSampleTMap);
        PropertyList plEditSample = new PropertyList();
        String sampleStatus = "";
        String sampleStatusA = "";
        if (batchType.equalsIgnoreCase("Molecular Medical Review") || batchType.equalsIgnoreCase("FISH Global HER2") || batchType.equalsIgnoreCase("FISH Global Non HER2") || batchType.equalsIgnoreCase("FISH Global") ||batchType.equalsIgnoreCase("FISH Tech")) {
            sampleStatus = "PathologyBatch";
        } else if (batchType.equalsIgnoreCase("Molecular Technical Review")) {
            sampleStatus = "Setup";
        } else if (batchType.equalsIgnoreCase("FISH Tech HER2") || batchType.equalsIgnoreCase("FISH Tech Non HER2")) {
            sampleStatus = "Fish";
        }
        for (int i = 0; i < dsSampleTMap.getRowCount(); i++) {
            sampleStatusA += (";" + sampleStatus);
        }
        sampleStatusA = sampleStatusA.substring(1);
        plEditSample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        plEditSample.setProperty(EditSDI.PROPERTY_KEYID1, dsSampleTMap.getColumnValues("s_sampleid", ";"));
        plEditSample.setProperty("u_currentmovementstep", sampleStatusA);
        plEditSample.setProperty("u_hnebatchreview", "N");
        updateTrackItem(dsSampleTMap, sampleStatusA);
        return plEditSample;
    }

    private void updateTrackItem(DataSet dsSampleTMap, String sampleStatusA) throws SapphireException {
        String defaultdepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String dept = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));
        String custodialdept = dept + "-Pathology";
        if (!Util.validateDepartment(custodialdept, getQueryProcessor(), getTranslationProcessor()))
            throw new SapphireException("Error: Department: " + custodialdept + " does not exist");

        PropertyList editTIProps = new PropertyList();

        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSampleTMap.getColumnValues("s_sampleid", ";"));
        editTIProps.setProperty("u_currenttramstop", sampleStatusA);
        editTIProps.setProperty("custodialuserid", StringUtil.repeat("(null)", dsSampleTMap.size(), ";"));
        editTIProps.setProperty("custodialdepartmentid", StringUtil.repeat(custodialdept, dsSampleTMap.size(), ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

    }

    private void validateSamples(DataSet dsValidate) throws Exception {
        if (dsValidate == null)
            throw new SapphireException(getTranslationProcessor().translate("Select Samples with test code "));
        if (dsValidate.getRowCount() > 1)
            throw new SapphireException(getTranslationProcessor().translate("Select Samples with same methodology and/or level of service"));
        if (dsValidate.getString(0, "los") == null || dsValidate.getString(0, "methodology") == null || dsValidate.getString(0, "testname") == null)
            throw new SapphireException(getTranslationProcessor().translate(" Samples without testname or level of service or methodology "));
    }

    /**
     * This methods captures the user details who creates the H&E Batch
     *
     * @param dsUpdate
     * @throws SapphireException
     */
    private void entryBatchCreator(DataSet dsUpdate) throws SapphireException {
        try {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsUpdate.getColumnValues("s_sampleid", ";"));
            prop.setProperty("custodialuserid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
            prop.setProperty("custodialdepartmentid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
            prop.setProperty("u_currenttramstop", "Microtomy");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (SapphireException e) {
            throw new SapphireException("Unable to update sample status");
        }
    }

}
