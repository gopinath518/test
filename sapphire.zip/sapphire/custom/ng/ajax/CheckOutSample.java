package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by mpandey on 6/21/2016.
 * CheckOutSample Action checks out sample from storage , also make it visible in certain page (current movement step).
 * Mandatory input - Sampleid.
 * Additional input - currentmovementstep
 */
public class CheckOutSample extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        String currentmovementstep = ajaxResponse.getRequestParameter("currentmovementstep","");
        String quesample = StringUtil.replaceAll(sampleid, ";", "','");
        String sql = "select trackitemid,currentstorageunitid from trackitem where linkkeyid1 in ('" + quesample + "') and linksdcid= 'Sample'";
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample.getRowCount() == 0) {
            ajaxResponse.addCallbackArgument("msg", "You have scanned an invalid Sample(s)");
            ajaxResponse.print();
            return;
        }
        String trackitemid = dsSample.getColumnValues("trackitemid", ";");
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("CURRENTSTORAGEUNITID", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            if(currentmovementstep.length()>0){
                try {
                    updatecurrentmovementstep(sampleid,currentmovementstep);
                } catch (SapphireException e) {
                    String error = getTranslationProcessor().translate("Can't move Sample out of Box ");
                    error += e.getMessage();
                    ajaxResponse.addCallbackArgument("msg", error);
                }
                }
            ajaxResponse.addCallbackArgument("msg", "Sample is successfully checked out from Box");
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move Sample out of Box ");
            error += ae.getMessage();
            ajaxResponse.addCallbackArgument("msg", error);
        }
        ajaxResponse.print();
    }

    /**
     * This method is use for updating current movement step of a sample.
     * @param sampleid
     * @param currentmovementstep
     * @throws SapphireException
     */
    private void updatecurrentmovementstep(String sampleid, String currentmovementstep)throws SapphireException {
        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("u_currentmovementstep", currentmovementstep);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
    }


