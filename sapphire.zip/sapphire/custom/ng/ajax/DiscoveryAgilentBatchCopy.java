package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by akumar on 6/15/2016.
 */
public class DiscoveryAgilentBatchCopy extends BaseAjaxRequest {
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String sampleid = ajaxResponse.getRequestParameter("sample");
        String reagent = ajaxResponse.getRequestParameter("reagent");
        String batchid = ajaxResponse.getRequestParameter("ngbatch");
        String str="select batchname from u_ngbatch where u_ngbatchid='"+batchid+"'";
        DataSet dsbatch=getQueryProcessor().getSqlDataSet(str);

        String batch=dsbatch.getColumnValues("batchname",";");
        // String origin=dsbatch.getColumnValues("origin",";");

        PropertyList prop = new PropertyList();
        try {

            prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("batchname", batch);
            prop.setProperty("parentbatchid", batchid);
            prop.setProperty("origin", "DiscoveryAgilentDay2");

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);

        } catch (SapphireException e) {
            String er = getTranslationProcessor().translate("Batch is not created");
            //throw new ServletException(ErrorDetail.TYPE_FAILURE, er);
        } finally {
            ajaxResponse.addCallbackArgument("msg", "Copy of Batch "+batch +" Created Successfully");
        }


        String ngbatchid = prop.getProperty("newkeyid1");
        associateSample(ngbatchid, sampleid);
        associateReagent(ngbatchid, reagent);
        ajaxResponse.print();
    }


    private void associateSample(String ngbatchid, String sampleid) {
        PropertyList sampleprop = new PropertyList();
        sampleprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        sampleprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        sampleprop.setProperty("sampleid", sampleid);
        sampleprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleprop);
        } catch (SapphireException se) {

            String er1 = getTranslationProcessor().translate("Sample not created");
            //ajaxResponse.addCallbackArgument("msg", er1);
        }
    }

    private void associateReagent(String ngbatchid, String reagent) {
        PropertyList reagentprop = new PropertyList();
        reagentprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        reagentprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        reagentprop.setProperty("reagentid", reagent);
        reagentprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, reagentprop);
        } catch (SapphireException se) {

            String er2 = getTranslationProcessor().translate("Reagent not associated");
            // ajaxResponse.addCallbackArgument("msg", er2);
        }


    }
}

