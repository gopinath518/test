package sapphire.custom.ng.ajax;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sapphire.accessor.ActionException;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

/**
 * Description : Used for open maint page.
 * @author debasis.mondal
 *
 */

public class EditQubitValue extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
       // try {
	        String sampleid = ajaxResponse.getRequestParameter("sampleid");
			String sam = StringUtil.replaceAll(sampleid, "|", ";");
	        String sampleData = Util.getUniqueList(sam,";",true);
	        String quesample = StringUtil.replaceAll(sampleData, ";", "','");
	        String sqlIns = Util.parseMessage(MolecularSql.EDITQUBITVALUE_INS, quesample);
	        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlIns);
	        if (dsSample.getRowCount() == 0) {
	            ajaxResponse.addCallbackArgument("msg", "");
	            ajaxResponse.print();
	           // return;
	        }else{
	        	String keyidval=dsSample.getColumnValues("u_instrumentquantificid", ";");
	        	ajaxResponse.addCallbackArgument("msg", keyidval);
	        	ajaxResponse.print();
	        }
    
	    /*} catch (ActionException ae) {
	        String error = getTranslationProcessor().translate("Can't move Sample out of Box ");
	        error += ae.getMessage();
	        ajaxResponse.addCallbackArgument("msg", error);
	    }finally{*/
	    	//ajaxResponse.print();
	   // }
    }
}
