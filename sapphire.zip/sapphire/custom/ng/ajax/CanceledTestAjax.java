package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by SBaitalik on 3/20/2017.
 */
public class CanceledTestAjax extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String sampleids = ajaxResponse.getRequestParameter("sampleids", "");
        String frmWhere = ajaxResponse.getRequestParameter("frmWhere", "");
        try {
            if (Util.isNull(frmWhere)) {
                String testcodes = getTestCodesFromSample(sampleids);
                ajaxResponse.addCallbackArgument("testcode", testcodes);
            } else {
                String testcodes = ajaxResponse.getRequestParameter("testcodes", "");
                canceledTestcode(sampleids, testcodes);
            }
        } catch (Exception e) {
        } finally {
            ajaxResponse.print();
        }
    }

    private String getTestCodesFromSample(String sampleids) throws SapphireException {
        String testcodes = "";
        String sql = "select s_sampleid,lvtestcodeid from u_sampletestcodemap where s_sampleid in('" + sampleids + "') and (teststatus is null or teststatus='In Progress')";
        DataSet dsTestcodes = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestcodes != null && dsTestcodes.size() > 0) {
            testcodes = dsTestcodes.getColumnValues("lvtestcodeid", ";");
        }
        return testcodes;
    }

    private void canceledTestcode(String sampleids, String testcodes) throws SapphireException {
        String sql = "select u_sampletestcodemapid from u_sampletestcodemap where s_sampleid in('" + sampleids + "')" +
                " and lvtestcodeid in('" + StringUtil.replaceAll(testcodes, ";", "','") + "')" +
                " and (teststatus is null or teststatus='In Progress')";
        DataSet dsTestcodes = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestcodes != null && dsTestcodes.size() > 0) {
            String u_sampletestcodemapid = dsTestcodes.getColumnValues("u_sampletestcodemapid", ";");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, u_sampletestcodemapid);
            prop.setProperty("teststatus", StringUtil.repeat("Cancelled", StringUtil.split(u_sampletestcodemapid, ";").length, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception e) {
            }
        }

    }
}
