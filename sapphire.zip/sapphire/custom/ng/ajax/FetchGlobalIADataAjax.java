package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by SBaitalik on 8/10/2017.
 */
public class FetchGlobalIADataAjax extends BaseAjaxRequest {

    private static final String HOMOGENEOUSLOSPOLICYID = "HomogeneousLOSPolicy";
    private static final String PARENTNODEID = "LOS";
    private static final String NODEID = "IHCLOS";
    private static final String POLICY_MAPPING = "losmapping";
    private static final String POLICY_PARENT_LOS = "parentlos";
    private static final String POLICY_CHILD_LOS = "childlos";
    private static final String POLICY_CHILD_LOS_ID = "childlosid";
    PropertyList homogeneousLOS = null;
    PropertyList homogeneousParentLOS = null;
    String methodology = "";
    private static String CURRENT_TRMSTOP = "";//hiddentramstop
    private static String CURRENT_USER = "";

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String tableindex = ajaxResponse.getRequestParameter("tableindex", "");
        methodology = ajaxResponse.getRequestParameter("methodology", "");
        String subgroupindx = ajaxResponse.getRequestParameter("subgroupindx", "");
        String los = ajaxResponse.getRequestParameter("los", "");
        String rowcount = ajaxResponse.getRequestParameter("rowcount", "");
        String pagecount = ajaxResponse.getRequestParameter("pagecount", "");
        CURRENT_TRMSTOP = ajaxResponse.getRequestParameter("hiddentramstop", "PathSupport");
        String sql = "";
        initializeDataSet();
        //if (!"IHC".equalsIgnoreCase(methodology)) {// TODO WORK LATER IF REQUIREDMENT CHANGES
        if ("IHC".equalsIgnoreCase(methodology)) {
            try {
                getLOS();
                los = synkHomogeneousLOS(los);
                los = StringUtil.replaceAll(los, ";", "','");

            } catch (Exception ex) {
            }
        }
        CURRENT_USER = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        sql = Util.parseMessage(ApSql.GET_ACCESSION_BY_LOS, methodology, los);
        DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

        dsFinal.sort("u_accessionid");
        ArrayList arrayAccession = dsFinal.getGroupedDataSets("u_accessionid");
        for (int i = 0; i < arrayAccession.size(); i++) {
            DataSet dsEach = (DataSet) arrayAccession.get(i);
            String subparentlos = Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_PARENTLOS, ";"), ";", true);
            String subparntlosArry[] = StringUtil.split(subparentlos, ";");
            for (int j = 0; j < subparntlosArry.length; j++) {
                HashMap hm = new HashMap();
                hm.put(DATASET_COL_PROPERTY_PARENTLOS, subparntlosArry[j]);
                DataSet dsFinalFilter = dsEach.getFilteredDataSet(hm);
                HashMap hmsubp = new HashMap();
                hmsubp.put(DATASET_PROPERTY_CHILD_LOS, subparntlosArry[j]);
                DataSet dsChildLosFilter = dsLOS.getFilteredDataSet(hmsubp);
                String subparentlosUnq = Util.getUniqueList(dsChildLosFilter.getColumnValues(DATASET_PROPERTY_PARENT_LOS, ";"), ";", true);
                if (dsFinalFilter != null && dsFinalFilter.size() > 0) {
                    int rowId = dsFinalResult.addRow();
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_ASSIGNDOCTOR, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_ASSIGNDOCTOR, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_PARENTLOS, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_PARENTLOS, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_SAMPLEID, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_SAMPLEID, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_TESTCODE, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_TESTCODE, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_FIRSTNAME, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_FIRSTNAME, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_BIOSUBJECTID, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_BIOSUBJECTID, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_LASTNAME, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_LASTNAME, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_CLIENTID, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_CLIENTID, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_METHODOLOGY, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_METHODOLOGY, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP, ", "), ", ", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_SUBPARENTLOS, subparentlosUnq);
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_ACCESSIONID, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_ACCESSIONID, ";"), ";", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_TESTNAME, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_TESTNAME, ", "), ", ", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_STATUS, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_STATUS, ", "), ", ", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_SITE, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_SITE, ", "), ", ", true));
                    dsFinalResult.setValue(rowId, DATASET_COL_PROPERTY_RECEIVED_DATE, Util.getUniqueList(dsFinalFilter.getColumnValues(DATASET_COL_PROPERTY_RECEIVED_DATE, ", "), ", ", true));
                }
            }

        }
        dsFinalResult.sort("u_accessionid");
        ArrayList arraySubParentLos = dsFinalResult.getGroupedDataSets("u_accessionid");
        for (int j = 0; j < arraySubParentLos.size(); j++) {
            DataSet dsEach = (DataSet) arraySubParentLos.get(j);
            if (dsEach.size() > 0) {
                int rowId = dsFinall.addRow();
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_ASSIGNDOCTOR, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_ASSIGNDOCTOR, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_PARENTLOS, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_PARENTLOS, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_SAMPLEID, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_SAMPLEID, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_TESTCODE, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_TESTCODE, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_FIRSTNAME, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_FIRSTNAME, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_LASTNAME, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_LASTNAME, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_BIOSUBJECTID, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_BIOSUBJECTID, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_CLIENTID, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_CLIENTID, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_METHODOLOGY, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_METHODOLOGY, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP, ","), ",", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_SUBPARENTLOS, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_SUBPARENTLOS, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_ACCESSIONID, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_ACCESSIONID, ";"), ";", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_TESTNAME, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_TESTNAME, ","), ",", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_STATUS, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_STATUS, ","), ",", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_SITE, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_SITE, ","), ",", true));
                dsFinall.setValue(rowId, DATASET_COL_PROPERTY_RECEIVED_DATE, Util.getUniqueList(dsEach.getColumnValues(DATASET_COL_PROPERTY_RECEIVED_DATE, ","), ",", true));
            }
        }
        ajaxResponse.addCallbackArgument("tableindex", tableindex);
        ajaxResponse.addCallbackArgument("dataset", dsFinall);
        ajaxResponse.addCallbackArgument("fethchdatarow", dsFinall.getRowCount());
        ajaxResponse.addCallbackArgument("subgroupindx", subgroupindx);
        ajaxResponse.print();
    }

    private void getLOS() throws SapphireException {
        if (homogeneousLOS == null) {
            homogeneousLOS = new PropertyList();
            PropertyList plHomogeneousPolicy = getConfigurationProcessor().getPolicy(HOMOGENEOUSLOSPOLICYID, NODEID);
            if (plHomogeneousPolicy == null)
                throw new SapphireException("Homogeneous LOS policy is not define in System Admin-> Policy.");
            PropertyListCollection plclosmap = plHomogeneousPolicy.getCollection(POLICY_MAPPING);
            if (plclosmap != null) {
                for (int j = 0; j < plclosmap.size(); j++) {
                    String propParentLOS = plclosmap.getPropertyList(j).getProperty(POLICY_PARENT_LOS);
                    PropertyListCollection plChildLOS = plclosmap.getPropertyList(j).getCollection(POLICY_CHILD_LOS);
                    if (plChildLOS != null) {
                        for (int k = 0; k < plChildLOS.size(); k++) {
                            String childlodis = plChildLOS.getPropertyList(k).getProperty(POLICY_CHILD_LOS_ID);
                            homogeneousLOS.setProperty(childlodis, propParentLOS);
                            int rowID = dsLOS.addRow();
                            dsLOS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, methodology);
                            dsLOS.setValue(rowID, DATASET_PROPERTY_PARENT_LOS, propParentLOS);
                            dsLOS.setValue(rowID, DATASET_PROPERTY_CHILD_LOS, childlodis);
                        }
                    }
                }

            }
        }
    }

    private String synkHomogeneousLOS(String los) throws SapphireException {

        HashMap hm = new HashMap();
        hm.put(DATASET_PROPERTY_METHODOLOGY, methodology);
        /**************
         AS PER LITO'S REQUIREMENT, Global Manual Quantitative,Global Manual Qualitative will be in same row.
         **************/
        hm.put(DATASET_PROPERTY_PARENT_LOS, los);
        DataSet dsFilter = dsLOS.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() != 0) {
            los = dsFilter.getColumnValues(DATASET_PROPERTY_CHILD_LOS, ";");
        }

        return los;
    }

    private DataSet dsLOS = null;
    private DataSet dsParentLOS = null;
    private DataSet dsFinalLOS = null;
    private DataSet dsFinalResult = null;
    private DataSet dsFinall = null;
    private static final String DATASET_PROPERTY_METHODOLOGY = "methodology";
    private static final String DATASET_PROPERTY_PARENT_LOS = "parentlos";
    private static final String DATASET_PROPERTY_CHILD_LOS = "childlos";
    private static final String DATASET_PROPERTY_SUBPARENT_LOS = "subparentlos";

    //FINAL DATASET RESULT
    private static final String DATASET_COL_PROPERTY_TESTNAME = "testname";
    private static final String DATASET_COL_PROPERTY_ASSIGNDOCTOR = "u_assignedtodoctor";
    private static final String DATASET_COL_PROPERTY_PARENTLOS = "los";
    private static final String DATASET_COL_PROPERTY_SAMPLEID = "s_sampleid";
    private static final String DATASET_COL_PROPERTY_TESTCODE = "u_testcodeid";
    private static final String DATASET_COL_PROPERTY_FIRSTNAME = "u_firstname";
    private static final String DATASET_COL_PROPERTY_LASTNAME = "u_lastname";
    private static final String DATASET_COL_PROPERTY_ACCESSIONID = "u_accessionid";
    private static final String DATASET_COL_PROPERTY_CLIENTID = "clientid";
    private static final String DATASET_COL_PROPERTY_METHODOLOGY = "methodology";
    private static final String DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP = "status";
    private static final String DATASET_COL_PROPERTY_SUBPARENTLOS = "subparentlos";
    private static final String DATASET_COL_PROPERTY_BIOSUBJECTID = "u_biopharmasubjectid";
    private static final String DATASET_COL_PROPERTY_STATUS = "status";
    private static final String DATASET_COL_PROPERTY_SITE = "performinglocation";
    private static final String DATASET_COL_PROPERTY_RECEIVED_DATE = "receiveddate";

    private void initializeDataSet() {
        if (dsLOS == null) {
            dsLOS = new DataSet();
            dsLOS.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsLOS.addColumn(DATASET_PROPERTY_PARENT_LOS, DataSet.STRING);
            dsLOS.addColumn(DATASET_PROPERTY_CHILD_LOS, DataSet.STRING);
        }
        if (dsParentLOS == null) {
            dsParentLOS = new DataSet();
            dsParentLOS.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsParentLOS.addColumn(DATASET_PROPERTY_PARENT_LOS, DataSet.STRING);
            dsParentLOS.addColumn(DATASET_PROPERTY_CHILD_LOS, DataSet.STRING);
        }
        if (dsFinalLOS == null) {
            dsFinalLOS = new DataSet();
            dsFinalLOS.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsFinalLOS.addColumn(DATASET_PROPERTY_PARENT_LOS, DataSet.STRING);
            dsFinalLOS.addColumn(DATASET_PROPERTY_SUBPARENT_LOS, DataSet.STRING);
            dsFinalLOS.addColumn(DATASET_PROPERTY_CHILD_LOS, DataSet.STRING);
        }
        if (dsFinalResult == null) {
            dsFinalResult = new DataSet();
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_TESTNAME, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_PARENTLOS, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_SAMPLEID, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_TESTCODE, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_FIRSTNAME, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_LASTNAME, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_ACCESSIONID, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_CLIENTID, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_SUBPARENTLOS, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_ASSIGNDOCTOR, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_BIOSUBJECTID, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_STATUS, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_SITE, DataSet.STRING);
            dsFinalResult.addColumn(DATASET_COL_PROPERTY_RECEIVED_DATE, DataSet.STRING);
        }
        if (dsFinall == null) {
            dsFinall = new DataSet();
            dsFinall.addColumn(DATASET_COL_PROPERTY_TESTNAME, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_PARENTLOS, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_SAMPLEID, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_TESTCODE, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_FIRSTNAME, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_LASTNAME, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_ACCESSIONID, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_CLIENTID, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_CURRENTMOVEMENTSTEP, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_SUBPARENTLOS, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_ASSIGNDOCTOR, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_BIOSUBJECTID, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_STATUS, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_SITE, DataSet.STRING);
            dsFinall.addColumn(DATASET_COL_PROPERTY_RECEIVED_DATE, DataSet.STRING);
        }
    }
}

