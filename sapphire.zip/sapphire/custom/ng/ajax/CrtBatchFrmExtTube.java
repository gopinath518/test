package sapphire.custom.ng.ajax;

import com.labvantage.sapphire.actions.sms.CreateStorageUnit;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by rrmandal on 6/9/2016.
 */
public class CrtBatchFrmExtTube extends BaseAjaxRequest {
    private static final String CREATESTORAGEUNIT_MAXTIALLOWED_PROP = "maxtiallowed";
    private static final String CREATESTORAGEUNIT_PROPERTYTREEID_PROP = "propertytreeid";
    private static final String CREATESTORAGEUNIT_MOVEABLEFLAG_PROP = "moveableflag";
    private static final String CREATESTORAGEUNIT_NEWKEYID1_PROP = "newkeyid1";
    private static final String CREATESTORAGEUNIT_NODEID_PROP = "nodeid";
    private static final String CREATESTORAGEUNIT_SIZE_PROP = "size";
    private static final String CREATESTORAGEUNIT_RETURN_PROP = "storageunitid";
    private static final String LV_BOX_SDC = "LV_Box";
    private static final String BOXTYPE_PROP = "boxtype";
    private static final String BOXSTATUS_PROP = "boxstatus";


    private static final String COLS_TO_COPY = "u_extractionid;sampletypeid;u_sampleinformation;u_accessionid";

    private String boxId = "";

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String batchid = "";
        try{
            if(ajaxResponse==null)
                throw new SapphireException("AjaxResponse is obtained as null");
        String extTube = ajaxResponse.getRequestParameter("exttube","");
        String batchName = ajaxResponse.getRequestParameter("batchname","");
            if(!Util.isNull(extTube)){
                PropertyList pl = new PropertyList();
                pl.setProperty("exttubeid",extTube);
                getActionProcessor().processAction("CrtElutionTube","1",pl,false,false);
                String elTube = pl.getProperty("elTube","");

                //String elTube = crtElutionTube(extTube);
                if(!Util.isNull(elTube)){
                    String boxStgid = crtBox();
                    if(!Util.isNull(boxStgid)){
                        elTubeChkIntoBox(boxStgid,elTube);
                        batchid = crtBatchAndAttchDtls(elTube,batchName);
                    }
                }
            }
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("batchid",batchid);
                ajaxResponse.print();
            }
        }
    }


    private String crtBox() throws SapphireException{
        PropertyList prop = new PropertyList();
        prop.setProperty( AddSDI.PROPERTY_SDCID, LV_BOX_SDC );
        prop.setProperty( AddSDI.PROPERTY_COPIES, "1" );
        prop.setProperty( BOXTYPE_PROP, "Unsorted" );
        prop.setProperty( BOXSTATUS_PROP, "Empty" );
        getActionProcessor().processAction( AddSDI.ID, AddSDI.VERSIONID, prop );
        String newBoxId = prop.getProperty( AddSDI.RETURN_NEWKEYID1, "" );
        boxId=newBoxId;
        prop.clear();

        DataSet trackItemDS = getQueryProcessor().getPreparedSqlDataSet( "select trackitemid from trackitem where linkkeyid1 = ?", new String[]{newBoxId} );
        if ( trackItemDS != null ) {
            String tiIdBox = trackItemDS.getValue( 0, "trackitemid", "" );
            prop.clear();
            prop.setProperty( CreateStorageUnit.PROPERTY_LINKPROPNODEID, "Grid|Box-6x2" );
            prop.setProperty( CreateStorageUnit.PROPERTY_CREATESU, "Y" );
            prop.setProperty( CreateStorageUnit.PROPERTY_LINKSDCID, LV_BOX_SDC );
            prop.setProperty( CREATESTORAGEUNIT_MAXTIALLOWED_PROP, "undefined;1" );
            prop.setProperty( CREATESTORAGEUNIT_PROPERTYTREEID_PROP, "Grid;No Layout" );
            prop.setProperty( CREATESTORAGEUNIT_MOVEABLEFLAG_PROP, "Y;N" );
            prop.setProperty( CREATESTORAGEUNIT_NEWKEYID1_PROP, newBoxId );
            prop.setProperty( CREATESTORAGEUNIT_NODEID_PROP, "Box-6x2;BoxPos" );
            prop.setProperty( CREATESTORAGEUNIT_SIZE_PROP, "1;12" );
            getActionProcessor().processAction( CreateStorageUnit.ID, CreateStorageUnit.VERSIONID, prop );

            String stgUnitIdPlt = StringUtil.split( prop.getProperty( CREATESTORAGEUNIT_RETURN_PROP, "" ), ";" )[0];
            prop.clear();

            prop.setProperty( EditSDI.PROPERTY_SDCID, "TrackItemSDC" );
            prop.setProperty( EditSDI.PROPERTY_KEYID1, tiIdBox );
            prop.setProperty( "custodialdepartmentid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment() );
            getActionProcessor().processAction( EditSDI.ID, EditSDI.VERSIONID, prop );

            return stgUnitIdPlt;
        }
        return "";
    }

    private void elTubeChkIntoBox(String boxStgId,String elutionTube)throws SapphireException{
        if(!Util.isNull(boxStgId) && !Util.isNull(elutionTube)) {
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid = ?";
            DataSet dsStorage = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{boxStgId});
            if (dsStorage != null && dsStorage.size() > 0) {
                PropertyList plElLdPolicy = getConfigurationProcessor().getPolicy("EllutionTubeLoadingPolicy", "custom");
                if (plElLdPolicy == null)
                    throw new SapphireException("Ellution tube loading policy is  not found in the system");
                PropertyListCollection plc = plElLdPolicy.getCollection("comb");
                if (plc == null || plc.size()==0)
                    throw new SapphireException("EllutionTubeLoadingPolicy policy is not configured properly.");
                String elTubeArr[]=StringUtil.split(elutionTube,";");
                if(elTubeArr!=null && elTubeArr.length>0){
                    String boxPosToLd = getBoxPosToLd(plc,Integer.toString(elTubeArr.length));
                    if(!Util.isNull(boxPosToLd)){
                        String boxPosArr[] = StringUtil.split(boxPosToLd,";");
                        if(boxPosArr.length!=elTubeArr.length)
                            throw new SapphireException("Number of box positions to be loaded for "+elTubeArr.length+" " +
                                    "ellution tube is not configured properly in the EllutionTubeLoadingPolicy policy");

                        DataSet result = new DataSet();
                        result.addColumn(EditTrackItem.PROPERTY_KEYID1,DataSet.STRING);
                        result.addColumn("currentstorageunitid",DataSet.STRING);
                        HashMap<String,String> hmap = new HashMap<String,String>();
                        for(int i=0;i<boxPosArr.length;i++){
                            hmap.clear();
                            hmap.put("storageunitlabel",boxPosArr[i]);
                            DataSet dsStgFiltr = dsStorage.getFilteredDataSet(hmap);
                            if(dsStgFiltr!=null && dsStgFiltr.size()>0){
                                int rowIndex = result.addRow();
                                String temStgId = dsStgFiltr.getValue(0,"storageunitid","");
                                if(!Util.isNull(temStgId)) {
                                    result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, elTubeArr[i]);
                                    result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                }
                            }
                        }
                        if(result!=null && result.size()>0){
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1,result.getColumnValues(EditTrackItem.PROPERTY_KEYID1,";"));
                            pl.setProperty("currentstorageunitid",result.getColumnValues("currentstorageunitid",";"));
                            getActionProcessor().processAction(EditTrackItem.ID,EditTrackItem.VERSIONID,pl);
                        }
                    }
                }
            }
        }
    }

    private String getBoxPosToLd(PropertyListCollection plc,String elTubeNo)throws SapphireException{
        if(plc!=null && plc.size()>0){
            for(int i=0;i<plc.size();i++){
                PropertyList tempPl = plc.getPropertyList(i);
                if(tempPl!=null && tempPl.size()>0){
                    String sampleNo = tempPl.getProperty("noofsamples","");
                    if(elTubeNo.equalsIgnoreCase(sampleNo))
                        return tempPl.getProperty("boxpos","");
                }
            }
        }
        return "";
    }

    private String crtBatchAndAttchDtls(String elTubes,String batchname)throws SapphireException{
        String batchId = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID,"NGBatch");
        pl.setProperty(AddSDI.PROPERTY_COPIES,"1");
        pl.setProperty("origin","Molecular");
        pl.setProperty("batchname",batchname);
        getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID,pl);

        batchId = pl.getProperty(AddSDI.RETURN_NEWKEYID1,"");

        if(!Util.isNull(batchId) && !Util.isNull(elTubes)){
            pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_sample_link");
            pl.setProperty("sampleid",elTubes);
            getActionProcessor().processAction(AddSDIDetail.ID,AddSDIDetail.VERSIONID,pl);

            pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_plate_link");
            pl.setProperty("plateid",boxId);
            getActionProcessor().processAction(AddSDIDetail.ID,AddSDIDetail.VERSIONID,pl);

        }
        return batchId;
    }

}
