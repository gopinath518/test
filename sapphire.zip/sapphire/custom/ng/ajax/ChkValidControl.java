package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 6/28/2016.
 */
public class ChkValidControl extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        String controlid="";
        String analyte = "";
        String position = "";
        DataSet dsSampleInfo = null;
        DataSet dsReagentLotInfo = null;
        String isControl = "N";
        String isValidAnalyte = "Y";
        String ctrlType = "";
        String sql1 = "select s_sampleid from s_sample where s_sampleid = ?";
        String sql2 = "select reagentlotid from reagentlot where reagentlotid = ?";
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        try{
            if(ajaxResponse==null)
                throw  new SapphireException("AjaxResponse is getting as null");
            controlid=ajaxResponse.getRequestParameter("controlid","");
            analyte=ajaxResponse.getRequestParameter("analyte","");
            position=ajaxResponse.getRequestParameter("position","");
            if(!Util.isNull(controlid)) {
                dsSampleInfo = getQueryProcessor().getPreparedSqlDataSet(sql1, new Object[]{controlid});
                if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
                    String s_sampleid = dsSampleInfo.getValue(0, "s_sampleid", "");
                    if (!Util.isNull(s_sampleid)) {
                        isControl = "Y";
                        ctrlType="Sample";
                    }
                } else {
                    logger.debug("Sample Info is not found from database.");
                    dsReagentLotInfo = getQueryProcessor().getPreparedSqlDataSet(sql2, new Object[]{controlid});
                    if (dsReagentLotInfo != null && dsReagentLotInfo.size() > 0) {
                        String reagentlotid = dsReagentLotInfo.getValue(0, "reagentlotid", "");
                        if (!Util.isNull(reagentlotid)) {
                            isControl = "Y";
                            ctrlType="Reagent";
                        }
                    }
                    else{
                        logger.debug("Reagent Lot info is not found from databse");
                    }
                }
                if ("Y".equalsIgnoreCase(isControl)) {
                    if(!Util.isNull(analyte)){
                        String sql = "select count(1) paramcount from param where paramid=? ";
                        DataSet dsParamInfo = getQueryProcessor().getPreparedSqlDataSet(sql,new Object[]{analyte});
                        if(dsParamInfo!=null && dsParamInfo.size()>0){
                            int paramcount = dsParamInfo.getInt(0,"paramcount",0);
                            if(paramcount>0)
                                isValidAnalyte="Y";
                        }
                    }
                }
            }
            else {
                logger.debug("Control id is not found");
            }
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("isvalidcontrol",isControl);
                ajaxResponse.addCallbackArgument("isvalidanalyte",isValidAnalyte);
                ajaxResponse.addCallbackArgument("controlid",controlid);
                ajaxResponse.addCallbackArgument("analyte",analyte);
                ajaxResponse.addCallbackArgument("position",position);
                ajaxResponse.addCallbackArgument("controltype",ctrlType);
                ajaxResponse.print();
            }
        }
    }
}
