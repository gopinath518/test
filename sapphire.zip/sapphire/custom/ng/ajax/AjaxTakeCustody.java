package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by SBaitalik on 4/23/2017.
 */
public class AjaxTakeCustody extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String keyid1 = ajaxResponse.getRequestParameter("keyid1", "");
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String completedby = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        int repeat = keyid1.split(";").length;
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, keyid1);
        //props.setProperty("u_currenttramstop", StringUtil.repeat(stepaction, repeat, ";"));
        props.setProperty("custodialuserid", StringUtil.repeat(completedby, repeat, ";"));
        props.setProperty("custodialdepartmentid", StringUtil.repeat(department, repeat, ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            ajaxResponse.addCallbackArgument("isValid", "Y");
            ajaxResponse.addCallbackArgument("msg", "Success");
            ajaxResponse.addCallbackArgument("keyid1", keyid1);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't move next step");
            error += ae.getMessage();
            //throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
            ajaxResponse.addCallbackArgument("isValid", "N");
            ajaxResponse.addCallbackArgument("msg", error);
            ajaxResponse.addCallbackArgument("keyid1", "");

        } finally {
            ajaxResponse.print();
        }
    }
}
