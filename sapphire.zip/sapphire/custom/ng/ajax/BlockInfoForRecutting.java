package sapphire.custom.ng.ajax;

import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by SBaitalik on 9/22/2016.
 * This Class is for getting scanning block information like how many numbers need to cut and what is the notes for the block.
 */
public class BlockInfoForRecutting extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        if (sampleid == "" || sampleid == null) {
            try {
                jsonResponse.put(RESPONSE_PARAM_ISVALID, "n");
                jsonResponse.put(RESPONSE_PARAM_MESSAGE, "Please scan one block for re-cutting.");
                ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                ajaxResponse.print();
            } catch (JSONException je) {
                je.printStackTrace();
            }
            return;
        }
        initializeData();
        String isSlide = validateSlide(sampleid);
        if ("Y".equalsIgnoreCase(isSlide)) {
            try {
                jsonResponse.put(RESPONSE_PARAM_ISVALID, "n");
                jsonResponse.put(RESPONSE_PARAM_MESSAGE, "Re-cutting cannot be performed on Slide(s).");
                ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                ajaxResponse.print();
            } catch (JSONException je) {
                je.printStackTrace();
            }
            return;
        }
        try {
            DataSet dsBlockInfo = validateInputData(sampleid);
            if (dsBlockInfo == null || dsBlockInfo.getRowCount() == 0) {
                jsonResponse.put(RESPONSE_PARAM_ISVALID, "n");
                jsonResponse.put(RESPONSE_PARAM_MESSAGE, "No data found.");
                ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
                ajaxResponse.print();
                return;
            }
            String notes = dsBlockInfo.getColumnValues(RESPONSE_PARAM_NOTES, ";");
            String noofslide = dsBlockInfo.getColumnValues(RESPONSE_PARAM_NO_OF_SLIDES, ";");
            String incidentrequestid = dsBlockInfo.getColumnValues(RESPONSE_PARAM_INCIDENT_REQ_ID, ";");
            String fromdepartment = dsBlockInfo.getColumnValues(RESPONSE_PARAM_FROM_DEPARTMENT, ";");
            jsonResponse.put(RESPONSE_PARAM_ISVALID, "y");
            jsonResponse.put(RESPONSE_PARAM_MESSAGE, "Data found");
            jsonResponse.put(RESPONSE_PARAM_NOTES, notes);
            jsonResponse.put(RESPONSE_PARAM_NO_OF_SLIDES, noofslide);
            jsonResponse.put(RESPONSE_PARAM_INCIDENT_REQ_ID, incidentrequestid);
            jsonResponse.put(RESPONSE_PARAM_FROM_DEPARTMENT, fromdepartment);
            ajaxResponse.addCallbackArgument("msg", jsonResponse.toString());
            ajaxResponse.print();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private JSONObject jsonResponse = null;
    private static final String RESPONSE_PARAM_MESSAGE = "message";
    private static final String RESPONSE_PARAM_ISVALID = "isValid";
    private static final String RESPONSE_PARAM_NOTES = "notes";
    private static final String RESPONSE_PARAM_NO_OF_SLIDES = "noofslide";
    private static final String RESPONSE_PARAM_INCIDENT_REQ_ID = "incidentrequestid";
    private static final String RESPONSE_PARAM_FROM_DEPARTMENT = "fromdepartment";

    /**
     * Description: This method is only used for initializing data
     *
     * @throws SapphireException
     */
    private void initializeData() {
        if (jsonResponse == null) {
            jsonResponse = new JSONObject();
        }
    }

    /**
     * Description: This method is used for to validate input and get notes, no of slide, incidentrequestid, fromdepartment
     * of given input block.
     *
     * @param sampleid This is input scan block.
     * @throws null
     */
    private DataSet validateInputData(String sampleid) {
        DataSet dsBlockInfo = null;
        String sql = "select incd.notes, rptop.noofslide, rptop.incidentrequestid, rptop.fromdepartment" +
                " from incident incd, u_repeatopsrequest rptop" +
                " where incd.incidentid = rptop.incidentrequestid and" +
                " rptop.sampleid=? and rptop.isrecutpending='Y'";
        dsBlockInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{sampleid});
        return dsBlockInfo;
    }

    private String validateSlide(String sampleid) {
        String isSlide = "";
        String sql = "select s_sampleid,u_type from s_sample where s_sampleid='" + sampleid + "' and u_type='U'";
        DataSet dsSlide = getQueryProcessor().getSqlDataSet(sql);
        if (dsSlide != null && dsSlide.size() > 0) {
            isSlide = "Y";
            return isSlide;
        } else {
            isSlide = "N";
            return isSlide;
        }
    }
}
