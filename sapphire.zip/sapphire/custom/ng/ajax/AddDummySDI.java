package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 3/10/2017.
 */
public class AddDummySDI extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String result="";
        String keyid1="";
        String value="";
        String column="";
        try {
            if(ajaxResponse==null)
                throw new SapphireException("Ajaxresponse object is obtained as null");
            keyid1=ajaxResponse.getRequestParameter("keyid1","");
            value=ajaxResponse.getRequestParameter("value","");
            column=ajaxResponse.getRequestParameter("column","");
            if(Util.isNull(keyid1))
                throw new SapphireException("Keyid1 is obtained as null");
            String sql="select u_dummyid from u_dummy where u_dummyid='"+keyid1+"'";
            DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsInfo==null)
                throw new SapphireException("Dataset object is obtained as null. Please check the datbase connection");
            if(dsInfo.size()==0){
                PropertyList prop = new PropertyList();
                prop.setProperty(AddSDI.PROPERTY_SDCID,"Dummy");
                prop.setProperty(AddSDI.PROPERTY_KEYID1,keyid1);
                prop.setProperty(column,value);
                prop.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY,"Y");
                getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID,prop);
                result="Add";
            }
            else if(dsInfo.size()>0){
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID,"Dummy");
                prop.setProperty(EditSDI.PROPERTY_KEYID1,keyid1);
                prop.setProperty(column,value);
                getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,prop);
                result="Edit";
            }

        }
        catch (Exception exp){
            ajaxResponse.setError(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null) {
                ajaxResponse.addCallbackArgument("msg", result);
                ajaxResponse.print();
            }
        }
    }
}
