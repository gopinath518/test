package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by achakraborty on 4/12/2017.
 */
public class AssayCommentValidation extends BaseAjaxRequest {

    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);

        String selectedKeyId = "";
        String keyid1Fail= "";
        String selectedParamid = "";

        try{

            if (ajaxResponse == null)
                throw new SapphireException("Ajaxresponse object is obatined as null.");
            DataSet dsFail = new DataSet();
            dsFail.addColumn("samp", DataSet.STRING);
            dsFail.addColumn("comment", DataSet.STRING);


            selectedKeyId = ajaxResponse.getRequestParameter("selectedKeyId", "");
            selectedParamid = ajaxResponse.getRequestParameter("selectedParamid", "");
            String sql = "";

            if (!Util.isNull(selectedKeyId)) {

                sql = "select a.KEYID1, splt.CONDITION, spl.SPECID, spl.PARAMID, spl.PARAMLISTID," +
                        "spl.OPERATOR1, spl.VALUE1, spl.OPERATOR2, spl.VALUE2, a.ENTEREDVALUE, ss.U_ASSAYACCEPTABLECOMMENT, rt.reagentlotid, rt.reagenttypeid " +
                        "from SDIDATAITEM a " +
                        "INNER JOIN SDISPEC b ON a.KEYID1=b.KEYID1 " +
                        "INNER JOIN speclimittype splt ON b.SPECID=splt.SPECID and b.SPECVERSIONID=splt.SPECVERSIONID " +
                        "INNER JOIN specparamlimits spl ON a.PARAMLISTID=spl.PARAMLISTID and a.PARAMLISTVERSIONID=spl.PARAMLISTVERSIONID and a.PARAMID=spl.PARAMID " +
                        "INNER JOIN s_sample ss ON a.KEYID1=ss.S_SAMPLEID " +
                        "INNER JOIN reagentlot rt ON ss.REAGENTLOTID=rt.REAGENTLOTID " +
                        "where a.KEYID1 in ('" + StringUtil.replaceAll(selectedKeyId, ";", "','") + "')";

                DataSet dsconditioninfo = getQueryProcessor().getSqlDataSet(sql);

                HashMap specMap = new HashMap();
                if (dsconditioninfo == null) {
                    throw new SapphireException("Error : Query does not return anything !!! ... ");
                }

                sql="select s_sampleid,reagentlot.reagentlotid,reagentlot.reagenttypeid " +
                        "from s_sample,reagentlot where s_sample.reagentlotid=reagentlot.reagentlotid " +
                        "and s_sample.s_sampleid in('"+ StringUtil.replaceAll(selectedKeyId,";","','")+"')";

                DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

                if (dsconditioninfo.size() == 0) {
                    ajaxResponse.addCallbackArgument("sample", "No DataSet Found");

                } else {

                    String selectedSampleArr[]= StringUtil.split(selectedKeyId,";");
                    String selectedParamArr[]= StringUtil.split(selectedParamid,";");

                    String reglotHavingNoSpec="";
                    String regtypeHavingNoSpec="";

                    if(selectedSampleArr!=null && selectedSampleArr.length>0){
                        HashMap<String,String> hmap = new HashMap<String,String>();
                        for(int i=0;i<selectedSampleArr.length;i++){
                            hmap.clear();
                            if(!Util.isNull(selectedSampleArr[i]) && i <selectedParamArr.length && !Util.isNull(selectedParamArr[i])){
                                hmap.put("keyid1",selectedSampleArr[i]);
                                hmap.put("paramid",selectedParamArr[i]);
                                DataSet dsFiltr=dsconditioninfo.getFilteredDataSet(hmap);
                                if(dsFiltr==null || dsFiltr.size()==0) {
                                    hmap.clear();
                                    hmap.put("s_sampleid",selectedSampleArr[i]);
                                    dsFiltr=dsSampleInfo.getFilteredDataSet(hmap);
                                    if(dsFiltr!=null && dsFiltr.size()>0) {
                                        reglotHavingNoSpec += ";" + dsFiltr.getValue(0,"reagentlotid","");
                                        regtypeHavingNoSpec += ";" + dsFiltr.getValue(0,"reagenttypeid","");
                                    }
                                }
                            }
                        }
                    }

                    if(!Util.isNull(reglotHavingNoSpec)){
                        if(reglotHavingNoSpec.startsWith(";")) {
                            reglotHavingNoSpec = reglotHavingNoSpec.substring(1);
                            regtypeHavingNoSpec = regtypeHavingNoSpec.substring(1);
                        }
                        ajaxResponse.addCallbackArgument("sample", "Below are the controls having no limit defined:\n"+Util.getUniqueList(reglotHavingNoSpec,";",true));
                    }

                    else {
                        dsconditioninfo.sort("keyid1");
                        ArrayList<DataSet> dsconditioninfoArr = dsconditioninfo.getGroupedDataSets("keyid1");

                        if (dsconditioninfoArr == null)
                            throw new SapphireException("ArrayList object dsconditioninfoArr is obtained as null");

                        for (int i = 0; i < dsconditioninfoArr.size(); i++) {

                            DataSet dsEach = (DataSet) dsconditioninfoArr.get(i);

                            String operator1 = "";
                            String operator2 = "";
                            String value1 = "";
                            String value2 = "";
                            String enteredvalue = "";
                            String assayacceptancecomment = "";
                            String specid = "";
                            String specversionid = "";
                            String condition = "";
                            String reagenttype = "";
                            String reagentlot = "";
                            String keyid1 = "";
                            String paramid = "";

                            if (dsEach != null && dsEach.size() > 0) {
                                for (int j = 0; j < dsEach.size(); j++) {

                                    keyid1 = dsEach.getValue(j, "keyid1");
                                    operator1 = dsEach.getValue(j, "operator1");
                                    operator2 = dsEach.getValue(j, "operator2");
                                    value1 = dsEach.getValue(j, "value1");
                                    value2 = dsEach.getValue(j, "value2");
                                    enteredvalue = dsEach.getValue(j, "enteredvalue");
                                    assayacceptancecomment = dsEach.getValue(j, "assayacceptancecomment");
                                    specid = dsEach.getValue(j, "specid");
                                    specversionid = dsEach.getValue(j, "specversionid");
                                    condition = dsEach.getValue(j, "condition");
                                    //paramid = dsEach.getValue(j, "paramid");

                                    specMap.put("keyid1", keyid1);
                                    specMap.put("operator1", operator1);
                                    specMap.put("operator2", operator2);
                                    specMap.put("value1", value1);
                                    specMap.put("value2", value2);
                                    specMap.put("enteredvalue", enteredvalue);
                                    specMap.put("u_assayacceptablecomment", assayacceptancecomment);
                                    specMap.put("specid", specid);
                                    specMap.put("SPECVERSIONID", specversionid);
                                    //specMap.put("paramid", paramid);

                                    String specResult = validateSpec(getSpecType(specMap), specMap, condition);
                                    if ("Fail".equalsIgnoreCase(specResult)) {
                                        keyid1Fail += ";" + keyid1;
                                    }
                                }

                            }
                        }

                        String uniquekeyid1Fail = "";


                        if (!Util.isNull(keyid1Fail)) {
                            uniquekeyid1Fail = Util.getUniqueList(keyid1Fail.substring(1), ";", true);
                            //uniqueReagentLotFail = Util.getUniqueList(reagentlotFail.substring(1), ";", true);
                        }

                        //ajaxResponse.addCallbackArgument("reagenttype", uniqueReagentFail);
                        //ajaxResponse.addCallbackArgument("reagentlotid", uniqueReagentLotFail);
                        ajaxResponse.addCallbackArgument("sample", uniquekeyid1Fail);
                    }
                }
            }
        } catch (Exception exp) {
            ajaxResponse.setError(exp.getMessage());

        } finally {
            ajaxResponse.print();
        }

    }

    private String validateSpec(String specType, HashMap<String, String> specMap, String condition) throws SapphireException {
        String specVal = "";
        switch (specType) {
            case "GREATERTHAN":
                if ("Pass".equalsIgnoreCase(condition) && (Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value1"))))
                    specVal = "Pass";
                break;
            case "LESSTHAN":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;
            case "GREATERTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value1")))
                    specVal = "Pass";
                break;
            case "LESSTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;

            case "GREATER":
                if (Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value1")))
                    specVal = "Pass";
                break;
            case "LESS":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;
            case "GREATEREQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value1")))
                    specVal = "Pass";
                break;
            case "LESSEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")))
                    specVal = "Fail";
                break;

            case "BETWEENGREATERTHANLESSTHAN":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value2")))
                    specVal = "Fail";
                else
                    specVal = "Pass";
                break;
            case "BETWEENGREATERTHANEQUALLESSTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value2")))
                    specVal = "Fail";
                else
                    specVal = "Pass";
                break;
            case "BETWEENGREATERTHANEQUALLESSTHAN":
                if (Float.valueOf(specMap.get("enteredvalue")) < Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) >= Float.valueOf(specMap.get("value2"))) {
                    specVal = "Fail";
                } else {
                    specVal = "Pass";
                }
                break;
            case "BETWEENGREATERTHANLESSTHANEQUAL":
                if (Float.valueOf(specMap.get("enteredvalue")) <= Float.valueOf(specMap.get("value1")) || Float.valueOf(specMap.get("enteredvalue")) > Float.valueOf(specMap.get("value2")))
                    specVal = "Fail";
                else
                    specVal = "Pass";
                break;
            default:
                specVal = "";
                break;
        }
        return specVal;

    }

    private String getSpecType(HashMap<String, String> specMap) throws SapphireException {
        if (specMap != null && specMap.size() > 0) {
            if (">".equalsIgnoreCase(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "GREATERTHAN";
            else if ("<".equalsIgnoreCase(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "LESSTHAN";
            else if (">=".equalsIgnoreCase(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "GREATERTHANEQUAL";
            else if ("<=".equals(specMap.get("operator1")) && specMap.get("operator2") == null)
                return "LESSTHANEQUAL";

            if (">".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "GREATER";
            else if ("<".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "LESS";
            else if (">=".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "GREATEREQUAL";
            else if ("<=".equalsIgnoreCase(specMap.get("operator2")) && specMap.get("operator1") == null)
                return "LESSEQUAL";

            else if (">".equalsIgnoreCase(specMap.get("operator1")) && "<".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANLESSTHAN";
            else if (">=".equalsIgnoreCase(specMap.get("operator1")) && "<=".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANEQUALLESSTHANEQUAL";
            else if (">=".equalsIgnoreCase(specMap.get("operator1")) && "<".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANEQUALLESSTHAN";
            else if (">".equalsIgnoreCase(specMap.get("operator1")) && "<=".equals(specMap.get("operator2")))
                return "BETWEENGREATERTHANLESSTHANEQUAL";
        }
        return "";
    }
}
