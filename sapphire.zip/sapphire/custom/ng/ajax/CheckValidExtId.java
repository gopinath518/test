package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 11/10/2016.
 */
public class CheckValidExtId extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        String sql = "select count(1) noofsample from s_sample where u_extractionid = ?";
        DataSet dsSampleInfo = null;
        String isValid = "N";
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        try{
            if(ajaxResponse==null)
                throw  new SapphireException("AjaxResponse is getting as null");
            String extId = ajaxResponse.getRequestParameter("extid","");
            if(!Util.isNull(extId)) {
                dsSampleInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{extId});
                if(dsSampleInfo!=null && dsSampleInfo.size()>0){
                    int count = dsSampleInfo.getInt(0,"noofsample",0);
                    if(count>0)
                        isValid="Y";
                }
                else if(dsSampleInfo==null)
                    throw new SapphireException("Database Error. Query is returning null");
            }
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("isvalid",isValid);
                ajaxResponse.print();
            }
        }
    }
}
