package sapphire.custom.ng.ajax;

import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by SBaitalik on 12/8/2016.
 */
public class AddAccessionComments extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String comments = ajaxResponse.getRequestParameter("comments");
        String accessionid = ajaxResponse.getRequestParameter("accessionid");
        String isupdate = ajaxResponse.getRequestParameter("isupdate");
        if ("".equalsIgnoreCase(isupdate)) {
            if (Util.isNull(comments) || Util.isNull(accessionid)) {
                ajaxResponse.addCallbackArgument("isValid", "N");
                //ajaxResponse.addCallbackArgument("dataset", "");
                ajaxResponse.addCallbackArgument("msg", "Please write your comment.");
                ajaxResponse.print();
            }
            String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
            String custodialdepartmentid = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("commentby", currentuser);
            prop.setProperty("commentdt", "n");
            prop.setProperty("comments", comments);
            prop.setProperty("departmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (ActionException e) {
                ajaxResponse.addCallbackArgument("isValid", "N");
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.addCallbackArgument("msg", "Unable to save your comment.");
                ajaxResponse.print();
            }
            String sql = "select commentdt,commentby,comments,sampleid from u_accessioncomment where accessionid='" + accessionid + "'";
            DataSet dsResult = getQueryProcessor().getSqlDataSet(sql);
            ajaxResponse.addCallbackArgument("isValid", "Y");
            ajaxResponse.addCallbackArgument("accessionid", accessionid);
            ajaxResponse.addCallbackArgument("msg", "Saved Successfully");
            ajaxResponse.print();
        } else {
            String idval = ajaxResponse.getRequestParameter("idval");
            String keyid1c = ajaxResponse.getRequestParameter("keyid1c");
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "AccessionComment");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, keyid1c);
            prop.setProperty("topic", idval);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                ajaxResponse.addCallbackArgument("isValid", "Y");
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.addCallbackArgument("msg", "Saved");
                ajaxResponse.print();
            } catch (ActionException e) {
                ajaxResponse.addCallbackArgument("isValid", "N");
                ajaxResponse.addCallbackArgument("accessionid", accessionid);
                ajaxResponse.addCallbackArgument("msg", "Unable to save your comment.");
                ajaxResponse.print();
            }
        }
    }
}
