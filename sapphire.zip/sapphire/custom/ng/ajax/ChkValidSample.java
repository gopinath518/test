package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.crypto.Data;

/**
 * Created by rrmandal on 6/27/2016.
 */
public class ChkValidSample extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        String sampleid="";
        String cntnrType = "";
        String testcode="";
        double optimalconcentration = 0;
        String concRatio = "";
        String sql = "select a.s_sampleid,a.u_accessionid,a.u_extractionid,a.u_concentrationratio,a.concentration,(d.u_firstname||' '||d.u_middlename||' '||d.u_lastname) patientname " +
                "from s_sample a, trackitem b,u_accession c,s_subject d " +
                "where b.linksdcid='Sample' and b.linkkeyid1=a.s_sampleid and a.u_accessionid=c.u_accessionid and c.patientid=d.s_subjectid " +
                "and a.s_sampleid=? and b.containertypeid=?";

        DataSet dsSampleInfo = null;
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        try{
            if(ajaxResponse==null)
                throw  new SapphireException("AjaxResponse is getting as null");
            sampleid = ajaxResponse.getRequestParameter("sampleid","");
            cntnrType = ajaxResponse.getRequestParameter("containertype","");
            testcode=ajaxResponse.getRequestParameter("testcode","");
            if(!Util.isNull(sampleid) && !Util.isNull(cntnrType)){
                Object[] obj = {sampleid, cntnrType};
                dsSampleInfo = getQueryProcessor().getPreparedSqlDataSet(sql,obj);
                if(dsSampleInfo!=null && dsSampleInfo.size()>0){
                    if(!Util.isNull(testcode)){
                        sql="select optimalconcentration from u_testcode where u_testcodeid = ?";
                        DataSet dsTestCodeInfo = getQueryProcessor().getPreparedSqlDataSet(sql,new Object[]{testcode});
                        if(dsTestCodeInfo!=null && dsTestCodeInfo.size()>0)
                            optimalconcentration = dsTestCodeInfo.getDouble(0,"optimalconcentration",0);
                        Double sampleConc = dsSampleInfo.getDouble(0,"concentration",0);
                        if(sampleConc>0 && optimalconcentration>0)
                            concRatio= Util.calculateConcentrationRatio(sampleConc, optimalconcentration);
                        if(!Util.isNull(concRatio))
                            dsSampleInfo.setValue(0,"u_concentrationratio",concRatio);
                        dsSampleInfo.addColumn("testcode",DataSet.STRING);
                        dsSampleInfo.setValue(0,"testcode",testcode);
                    }
                    ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
                }
                else{
                    ajaxResponse.addCallbackArgument("dataset", "No data found");
                }
            }
            else {
                if(Util.isNull(sampleid))
                    logger.debug("Sample Id is not found");
                if(!Util.isNull(cntnrType))
                    logger.debug("Container Type is not found");
                ajaxResponse.addCallbackArgument("dataset", "No data found");
            }
        }
        catch (Exception exp){
            ajaxResponse.setError((new StringBuilder()).append("Failed to process sql: ").append(sql).append(". Exception: ").append(exp.getMessage()).toString(), exp);
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                String columnsArr[]=null;
                if(dsSampleInfo!=null && dsSampleInfo.size()>0)
                    columnsArr=dsSampleInfo.getColumns();
                String columns = "";
                if(columnsArr!=null && columnsArr.length>0)
                    columns= StringUtil.arrayToString(columnsArr,";");
                ajaxResponse.addCallbackArgument("columns",columns);
                ajaxResponse.addCallbackArgument("tableid","sample_detail");
                ajaxResponse.addCallbackArgument("hasDelButton","Y");
                ajaxResponse.addCallbackArgument("validscanmsg","Invalid Elusion Tube. Please scan a valid one");
                ajaxResponse.addCallbackArgument("fieldid","pr0_sampleid");
                ajaxResponse.addCallbackArgument("entity","elution");
                ajaxResponse.addCallbackArgument("inputcols","u_concentrationratio");
                ajaxResponse.addCallbackArgument("hiddencols","s_sampleid");
                ajaxResponse.print();
            }
        }
    }
}
