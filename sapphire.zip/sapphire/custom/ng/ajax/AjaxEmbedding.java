package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by mpandey on 5/6/2016.
 * * Action Name- AjaxEmbedding
 * Description: This Action is created to checkout cassette and assosite sample with embeding station
 *
 * Mandatory inputs
 * param1-cassetteid
 * param2-embeddingid
 * throws SapphireException

 */
public class AjaxEmbedding  extends BaseAjaxRequest {
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String cassetteid = ajaxResponse.getRequestParameter("cassetteid");
        String embeddingid = ajaxResponse.getRequestParameter("embeddingid");

        try {
            callingCheckOutCassette(cassetteid);
        } catch (SapphireException e) {
            e.printStackTrace();
        }

    }
    private void callingCheckOutCassette(String cassetteid)throws SapphireException{
        ActionProcessor ap = getActionProcessor();
        PropertyList actionProp = new PropertyList();
        actionProp.clear();

        actionProp.setProperty("cassetteid", cassetteid);

        try {
            ap.processAction("CheckOutCassette", "1", actionProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }


}




