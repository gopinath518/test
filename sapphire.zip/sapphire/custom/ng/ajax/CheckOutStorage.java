package sapphire.custom.ng.ajax;

import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by dmondal on 2/6/2017.
 * Description : This ajax is for check out of all samples from box.
 */
public class CheckOutStorage extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String currentuser=getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String department=getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String storageid = ajaxResponse.getRequestParameter("storageid").trim();
        String sqlBoxType = "select  boxtype from s_box where s_boxid='"+storageid+"' ";
        DataSet dsBoxType = getQueryProcessor().getSqlDataSet(sqlBoxType);
        if (dsBoxType.getRowCount() == 0) {
            ajaxResponse.addCallbackArgument("msg", "Please scan a valid box.");
            ajaxResponse.print();
            return;
        }
        String sql="";
        if("Unsorted".equalsIgnoreCase(dsBoxType.getColumnValues("boxtype",";"))) {
            sql = "select t.linkkeyid1,t.trackitemid from trackitem t,storageunit su where t.currentstorageunitid  = su.storageunitid " +
                    "and su.linkkeyid1= ('" + storageid + "') ";

        }else if("Sorted".equalsIgnoreCase(dsBoxType.getColumnValues("boxtype",";"))) {
            sql = "select ti.linkkeyid1,ti.trackitemid from trackitem ti,storageunit su1,storageunit su2 where " +
                    "ti.currentstorageunitid =su1.storageunitid and su1.parentid= su2.storageunitid and su2.linkkeyid1='" + storageid + "' ";

        }
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample.getRowCount() == 0) {
            ajaxResponse.addCallbackArgument("msg", "You have scanned an invalid Box/Box is empty.");
            ajaxResponse.print();
            return;
        }
        String trackitemid = dsSample.getColumnValues("trackitemid", ";");
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("custodialuserid", currentuser);
            props.setProperty("custodialdepartmentid",department);
            props.setProperty("currentstorageunitid", "(null)");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            ajaxResponse.addCallbackArgument("msg", "Sample is successfully checked out from Storage");
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move Sample out of Storage ");
            error += ae.getMessage();
            ajaxResponse.addCallbackArgument("msg", error);
        }
        ajaxResponse.print();
    }
}
