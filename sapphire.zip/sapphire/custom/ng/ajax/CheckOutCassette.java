package sapphire.custom.ng.ajax;

import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by mpandey on 5/16/2016.
 * * Action Name- CheckOutCassette
 * Description: This Action is created to check out cassette from basket
 *
 * Mandatory inputs
 * param1-cassetteid
 * throws SapphireException

 */
public class CheckOutCassette  extends BaseAjaxRequest {
    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String cassetteid = ajaxResponse.getRequestParameter("cassetteid");
        String queCassette = StringUtil.replaceAll(cassetteid, ";", "','");
        String sql = "select trackitemid,CURRENTSTORAGEUNITID from TRACKITEM where linkkeyid1 in ('" + queCassette + "') and linksdcid= 'Cassette'";
        DataSet dsCassette = getQueryProcessor().getSqlDataSet(sql);
        if (dsCassette.getRowCount() == 0) {
            ajaxResponse.addCallbackArgument("msg", "Storage not define for some Cassettes or Invalid Cassette ID"  );
            ajaxResponse.print();
            return;
        }

        String trackitemid = dsCassette.getColumnValues("trackitemid", ";");

        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("CURRENTSTORAGEUNITID", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            ajaxResponse.addCallbackArgument("msg", "Cassettes Checked out from Basket");
            // ajaxResponse.print();

        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move cassettes out of basket ");
            error += ae.getMessage();
            //ajaxResponse.setError(error);
            ajaxResponse.addCallbackArgument("msg", error);
        }
        finally {
            ajaxResponse.print();
        }
    }


}

