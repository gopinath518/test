package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 6/8/2016.
 */
public class CheckValidExtTube extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        String sql = "select u_extractionid from s_sample where s_sampleid = ?";
        DataSet dsSampleInfo = null;
        String isExtTube = "N";
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        try{
            if(ajaxResponse==null)
                throw  new SapphireException("AjaxResponse is getting as null");
            String extTube = ajaxResponse.getRequestParameter("exttubeid","");
            if(!Util.isNull(extTube)) {
                dsSampleInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{extTube});
                if(dsSampleInfo!=null && dsSampleInfo.size()>0){
                    String extId = dsSampleInfo.getValue(0,"u_extractionid","");
                    if(!Util.isNull(extId))
                        isExtTube="Y";
                }
            }
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("isexttube",isExtTube);
                ajaxResponse.print();
            }
        }
    }

}
