package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 7/7/2016.
 */
public class ChkValidBox extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
//        String sql = "select linkkeyid1,storageunitid from storageunit where linksdcid='LV_Box' and linkkeyid1=? and storageunittype=?";
        String sql = "select s.linkkeyid1,s.storageunitid,(select ti.custodialuserid from trackitem ti where ti.linksdcid='LV_Box' and ti.linkkeyid1=s.linkkeyid1) custodialuserid " +
                "from storageunit s where s.linksdcid='LV_Box' and s.linkkeyid1=? and s.storageunittype=?";
        DataSet dsBoxStgInfo = null;
        String boxId = "";
        String boxType = "";
        String checkin = "";
        String keyid1 = "";
        String sdcid = "";
        String isValiBox = "N";
        String msg = "";

        try{
            if(ajaxResponse==null){
                throw  new SapphireException("AjaxResponse is getting as null");
            }
            boxId = ajaxResponse.getRequestParameter("boxid","");
            boxType = ajaxResponse.getRequestParameter("boxtype","");
            sdcid = ajaxResponse.getRequestParameter("sdcid","");
            keyid1 = ajaxResponse.getRequestParameter("keyid1","");
            checkin = ajaxResponse.getRequestParameter("checkin","");
            if(!Util.isNull(boxId)){
                Object[] obj = {boxId,boxType};
                dsBoxStgInfo = getQueryProcessor().getPreparedSqlDataSet(sql,obj);
                if(dsBoxStgInfo!=null && dsBoxStgInfo.size()>0){
                    String linkkeyid1 = dsBoxStgInfo.getValue(0,"linkkeyid1","");
                    String custodialuserid = dsBoxStgInfo.getValue(0,"custodialuserid","");
                    String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
                    if(!Util.isNull(currentuser) && !currentuser.equalsIgnoreCase(custodialuserid))
                        throw new SapphireException("Scanned box is not in your custody");
                    if(!Util.isNull(linkkeyid1)) {
                        isValiBox = "Y";
                        if("Y".equalsIgnoreCase(checkin) && !Util.isNull(sdcid) && !Util.isNull(keyid1)){
                            try {
                                checkIntoBox(boxId, "LV_ReagentLot", keyid1);
                                msg="Scanned lot(s) have been checked in successfully." +
                                        "\nPlease note only those containers not having any prior storage are checked into the the box "+boxId;
                            }
                            catch (SapphireException exp){
                                msg = "Scanned lot(s) can not be checked in.\nReason: "+exp.getMessage();
                            }
                        }
                    }
                }
            }
            else{
                if(Util.isNull(boxId))
                    logger.debug("Box is not found");
            }
        }
        catch (SapphireException exp){
            msg = "Validation: "+exp.getMessage();
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
            msg = "Error: "+exp.getMessage();
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("isvalidbox",isValiBox);
                ajaxResponse.addCallbackArgument("box",boxId);
                ajaxResponse.addCallbackArgument("msg",msg);
                ajaxResponse.print();
            }
        }
    }


    private void checkIntoBox(String boxid,String sdcid,String rls) throws SapphireException{
        if(!Util.isNull(boxid) && !Util.isNull(sdcid) && !Util.isNull(rls)){
            String sql = "select s.storageunitid,s.storageunittype,s.storageunitindex,t.linksdcid,t.linkkeyid1 " +
                    "from storageunit s left outer join trackitem t on s.storageunitid=t.currentstorageunitid " +
                    "where s.parentid=(select stg.storageunitid from storageunit stg where stg.linksdcid='LV_Box' and stg.linkkeyid1=?) and t.linkkeyid1 is null " +
                    "order by s.storageunitindex";

            DataSet dsBoxEmptyPosInfo = getQueryProcessor().getPreparedSqlDataSet(sql,new Object[]{boxid});

            sql = "select trackitemid,currentstorageunitid,custodialuserid,custodialdepartmentid from trackitem " +
                    "where linksdcid='LV_ReagentLot' and linkkeyid1 in('"+StringUtil.replaceAll(rls,";","','")+"') and currentstorageunitid is null";

            DataSet dsRLTIInfo = getQueryProcessor().getSqlDataSet(sql);

            if(dsBoxEmptyPosInfo!=null && dsRLTIInfo!=null && dsBoxEmptyPosInfo.size()>0 && dsRLTIInfo.size()>0){
                if(dsBoxEmptyPosInfo.size()<dsRLTIInfo.size())
                    throw new SapphireException("Chekin Process failed.\nReason: Total number of containers for the scanned lot(s)is "+dsRLTIInfo.size()+". But the scanned box " +
                            ""+boxid+" is having "+dsBoxEmptyPosInfo.size()+" vacant places.");
                for(int i=0;i<dsRLTIInfo.size();i++){
                    if(i<dsBoxEmptyPosInfo.size()) {
                        String emptyStgId = dsBoxEmptyPosInfo.getValue(i, "storageunitid", "");
                        if (!Util.isNull(emptyStgId)) {
                            dsRLTIInfo.setValue(i, "currentstorageunitid", emptyStgId);
                            dsRLTIInfo.setValue(i, "custodialuserid", "(null)");
                            dsRLTIInfo.setValue(i, "custodialdepartmentid", "(null)");
                        }
                    }
                }
                PropertyList plEditTi = new PropertyList();
                plEditTi.setProperty(EditTrackItem.PROPERTY_TRACKITEMID,dsRLTIInfo.getColumnValues("trackitemid",";"));
                plEditTi.setProperty("currentstorageunitid",dsRLTIInfo.getColumnValues("currentstorageunitid",";"));
                plEditTi.setProperty("custodialuserid",dsRLTIInfo.getColumnValues("custodialuserid",";"));
                plEditTi.setProperty("custodialdepartmentid",dsRLTIInfo.getColumnValues("custodialdepartmentid",";"));
                getActionProcessor().processAction(EditTrackItem.ID,EditTrackItem.VERSIONID,plEditTi);
            }
        }
    }
}
