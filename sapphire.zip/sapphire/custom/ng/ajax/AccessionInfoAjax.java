package sapphire.custom.ng.ajax;

/**
 * Created by SBaitalik on 12/29/2016.
 */

import sapphire.SapphireException;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class AccessionInfoAjax extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext)
            throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);

        String id = ajaxResponse.getRequestParameter("id", "");
        String value = ajaxResponse.getRequestParameter("idval", "");
        if ("sponsornumber".equalsIgnoreCase(id)) {
            String sql = "";
            // sql = "select u_clientid,clientname,nyflag from u_client where
            // u_clientid like '" + value + "%'";
            // sql = "select u_clientid,clientname,nyflag from u_client where
            // UPPER(u_clientid) like UPPER('" + value + "%')";
            sql = "select u_sponsorid as u_clientid,sponsorname as clientname,activeflag as nyflag,sponsornumber"
                    + " from u_sponsor where UPPER(sponsornumber) like UPPER('" + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("clientname".equalsIgnoreCase(id)) {
            String sql = "";
            // sql = "select u_clientid,clientname,nyflag from u_client where
            // clientname like '" + value + "%'";
            // sql = "select u_clientid,clientname,nyflag from u_client where
            // UPPER(clientname) like UPPER('" + value + "%')";
            sql = "select u_sponsorid as u_clientid,sponsorname as clientname,activeflag as nyflag,sponsornumber from u_sponsor where UPPER(sponsorname) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("icdcode_id".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_icdcodeid,icdcodedesc,type from u_icdcode where UPPER(u_icdcodeid) like UPPER('" + value
                    + "%') offset 1 rows fetch next 20 rows only";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("patient_id".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select s_subjectid,u_firstname,u_lastname,u_middlename,genderflag,birthdt,u_mrn,u_biopharmasubjectid from s_subject where s_subjectid like '"
                    + value + "%'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);
            setAgeFlag(dsFinal);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("mrn_id".equalsIgnoreCase(id)) {
            /*
             * DataSet ds = new DataSet(); ds.addColumn("s_subjectid",
			 * DataSet.STRING); ds.addColumn("u_firstname", DataSet.STRING);
			 * ds.addColumn("u_lastname", DataSet.STRING);
			 * ds.addColumn("u_middlename", DataSet.STRING);
			 * ds.addColumn("genderflag", DataSet.STRING);
			 * ds.addColumn("birthdt", DataSet.STRING); ds.addColumn("u_mrn",
			 * DataSet.STRING); ds.addColumn("u_biopharmasubjectid",
			 * DataSet.STRING);
			 */

            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectid", "");
            String sql = "";
            sql = "select s.s_subjectid,s.u_firstname,s.u_lastname,s.u_middlename,s.genderflag,s.birthdt,s.u_mrn,s.u_biopharmasubjectid"
                    + " from s_subject s,u_projectsubjectmap prm" + " where" + " s.s_subjectid=prm.subjectid"
                    + " and prm.projectid='" + bioprojectid + "'";
            // sql = "select
            // s_subjectid,u_firstname,u_lastname,u_middlename,genderflag,birthdt,u_mrn,u_biopharmasubjectid
            // from s_subject where u_biopharmasubjectid like '" + value + "%'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);
            if (!dsFinal.isValidColumn("nbirthdt")) {
                dsFinal.addColumn("nbirthdt", DataSet.STRING);
            }
            for (int i = 0; i < dsFinal.size(); i++) {
                String brthdt = dsFinal.getValue(i, "birthdt", "");
                String pbirth = "";
                if (!Util.isNull(brthdt)) {
                    Date dob1 = dsFinal.getCalendar(i, "birthdt").getTime();
                    SimpleDateFormat sdff = new SimpleDateFormat("MM/dd/yyyy");
                    pbirth = sdff.format(dob1).toUpperCase();
                    dsFinal.setValue(i, "nbirthdt", pbirth);
                } else {
                    dsFinal.setValue(i, "nbirthdt", pbirth);
                }

            }
            // setAgeFlag(dsFinal);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("patient_firstname".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select s_subjectid,u_firstname,u_lastname,u_middlename,genderflag,birthdt,u_mrn,u_biopharmasubjectid from s_subject where UPPER(u_firstname) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);
            setAgeFlag(dsFinal);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("patient_middlename".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select s_subjectid,u_firstname,u_lastname,u_middlename,genderflag,birthdt,u_mrn,u_biopharmasubjectid from s_subject where UPPER(u_middlename) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);
            setAgeFlag(dsFinal);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("patient_lastname".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select s_subjectid,u_firstname,u_lastname,u_middlename,genderflag,birthdt,u_mrn,u_biopharmasubjectid from s_subject where UPPER(u_lastname) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);
            setAgeFlag(dsFinal);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("orderingphysician_id".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_physicianid,firstname,lastname from u_physician where u_physicianid like '" + value
                    + "%' and physiciantype='orderingphysician'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("ordering_physician_first_name".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_physicianid,firstname,lastname from u_physician where UPPER(firstname) like UPPER('" + value
                    + "%') and physiciantype='orderingphysician'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("ordering_physician_last_name".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_physicianid,firstname,lastname from u_physician where UPPER(lastname) like UPPER('" + value
                    + "%') and physiciantype='orderingphysician'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("treating_physician_id".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_physicianid,firstname,lastname from u_physician where u_physicianid like '" + value
                    + "%' and physiciantype='treatingphysician'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("treating_physician_firstname".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_physicianid,firstname,lastname from u_physician where UPPER(firstname) like UPPER('" + value
                    + "%') and physiciantype='treatingphysician'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("treating_physician_lastname".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select u_physicianid,firstname,lastname from u_physician where UPPER(lastname) like UPPER('" + value
                    + "%') and physiciantype='treatingphysician'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("sampletype_id".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select s_sampletypeid,containertypeid from s_sampletypecontainertype where UPPER(s_sampletypeid) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("containertype_id".equalsIgnoreCase(id)) {
            String sampletypeidinput = ajaxResponse.getRequestParameter("sampletypeidinput");
            String sql = "";
            sql = "select s_sampletypeid,containertypeid from s_sampletypecontainertype where s_sampletypeid='"
                    + sampletypeidinput + "'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("testcode_id".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select clienttestcodeid,nvl(u_testcodeid,'N')u_testcodeid,nvl(testname,'N')testname,nvl(methodology,'N')methodology,nvl(los,'N')los from u_testcode where UPPER(clienttestcodeid) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("testname".equalsIgnoreCase(id)) {
            String sql = "";
            sql = "select clienttestcodeid,nvl(u_testcodeid,'N')u_testcodeid,nvl(testname,'N')testname,nvl(methodology,'N')methodology,nvl(los,'N')los from u_testcode where UPPER(testname) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("bill_type".equalsIgnoreCase(id)) {

            String sql = "";
            sql = "select refvalueid from refvalue where reftypeid='BillingType' and UPPER(refvalueid) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("sec_bill_type".equalsIgnoreCase(id)) {

            String sql = "";
            sql = "select refvalueid from refvalue where reftypeid='BillingType' and UPPER(refvalueid) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("sel_site".equalsIgnoreCase(id)) {

            String sql = "";

            sql = "select departmentid from department where u_site='" + value + "'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("containerid".equalsIgnoreCase(id)) {

            String sql = "";

            sql = "select containertypeid from containertype where UPPER(containertypeid) like UPPER('" + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.print();
        } else if ("bodysite_id".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String sql = "";

            sql = "select u_bodysiteid from u_bodysite where UPPER(u_bodysiteid) like UPPER('" + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("sampleinfo_id".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String sql = "";

            sql = "select refvalueid from refvalue where reftypeid='Donor' and UPPER(refvalueid) like UPPER('" + value
                    + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("neoproject_id".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String clientid = ajaxResponse.getRequestParameter("clientidname", "");
            String sql = "";

            // sql = "select protocolnumber,visitname,clientid,u_bioprojectsid
            // from u_bioprojects where clientid='" + clientid + "' and
            // protocolnumber like '" + value + "%'";
            // sql = "select
            // protocolnumber,visitname,clientid,u_bioprojectsid,neoprojectid
            // from u_bioprojects where clientid='" + clientid + "' and
            // UPPER(protocolnumber) like UPPER('" + value + "%')";
            sql = "select u_bioprojectsid,visitname,clientid,projectprotocolid as protocolnumber,neoprojectid"
                    + " from u_bioprojects where clientid='" + clientid + "' and UPPER(projectprotocolid) like UPPER('"
                    + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("sitenumber".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String bioprojectid = ajaxResponse.getRequestParameter("bbioprojectid", "");
            String sql = "";

            sql = "select u_biositeid as siteid,sitename,projectid,invesitagtorname,sitenumber from u_biosite where projectid='"
                    + bioprojectid + "' and" + " UPPER(sitenumber) like UPPER('" + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("site_name".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectidnam", "");
            String sql = "";

            sql = "select u_biositeid as siteid,sitename,invesitagtorname,sitenumber from u_biosite where projectid='"
                    + bioprojectid + "' and UPPER(sitename) like UPPER('" + value + "%')";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("visit_name".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectidnam", "");
            String sql = "";
            // select visitid from u_projectvisitmap where
            // projectid='"+bioprojectid+"';
            sql = "select u_projectvisitmapid,visitid from u_projectvisitmap where projectid='" + bioprojectid + "'";
            // sql = "select visitid from u_projectvisitmap where projectid='" +
            // bioprojectid + "'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("invstsiteinfo".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectidnam", "");
            String sql = "";
            // select visitid from u_projectvisitmap where
            // projectid='"+bioprojectid+"';
            sql = "select u_biositeid from u_biosite where projectid='" + bioprojectid + "'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("search_investigator_name".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String biositeid = ajaxResponse.getRequestParameter("biositeid", "");
            String sql = "";
            // select visitid from u_projectvisitmap where
            // projectid='"+bioprojectid+"';
            sql = "select u_siteinvestigatormapid,investigatorname from u_siteinvestigatormap where siteid='"
                    + biositeid + "'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("fromquant".equalsIgnoreCase(id)) {
            String sampleids = ajaxResponse.getRequestParameter("selsamples", "");
            String sql = "select s_sampleid,sampletypeid,specimentype as transporttype,nvl(u_type,'N') u_type"
                    + " from s_sample where s_sampleid in ('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";
            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
            ajaxResponse.print();
        } else if ("checksubjectid".equalsIgnoreCase(id)) {
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectid", "");
            String biosubjectid = ajaxResponse.getRequestParameter("biosubjectid", "");
            String sql = "select u_biopharmasubjectid from s_subject where UPPER(u_biopharmasubjectid)=UPPER('"
                    + biosubjectid + "')";
            DataSet dsSubject = getQueryProcessor().getSqlDataSet(sql);
            ajaxResponse.addCallbackArgument("dataset", dsSubject);
            ajaxResponse.print();
        } else if ("mandatoryfields".equalsIgnoreCase(id)) {
            String rowindx = ajaxResponse.getRequestParameter("rowindx", "");
            String bioprojectid = ajaxResponse.getRequestParameter("bioprojectidnam", "");
            String sql = "";
            // select visitid from u_projectvisitmap where
            // projectid='"+bioprojectid+"';
            sql = "select u_projectfiledsmapid,projectid,fieldname,ismandatoryflag from u_projectfiledsmap where projectid='"
                    + bioprojectid + "'";
            DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

            ajaxResponse.addCallbackArgument("dataset", dsFinal);
            ajaxResponse.addCallbackArgument("id", id);
            ajaxResponse.addCallbackArgument("rowindx", rowindx);
            ajaxResponse.print();
        } else if ("validatetestcodeproject".equalsIgnoreCase(id)) {
            try {
                String existingprojectid = ajaxResponse.getRequestParameter("existingprojectid");
                String sql = Util.parseMessage(AccessionPageSql.GET_EXISTING_PROJECT, existingprojectid);
                DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
                String projectname = dsProject.getValue(0, "projectprotocolid", "");
                String selectaccessionid = ajaxResponse.getRequestParameter("accessionid");
                String selectproject = ajaxResponse.getRequestParameter("selectproject");
                String neoprojectid = ajaxResponse.getRequestParameter("neoprojectid");

                String sqlInfo = Util.parseMessage(AccessionPageSql.GET_ACCESSION_STATUS_OTHER_SQL, selectaccessionid);
                DataSet dsAccessinInfo = getQueryProcessor().getSqlDataSet(sqlInfo);
                String status = dsAccessinInfo.getValue(0, "status", "");
                String orgstatus = dsAccessinInfo.getValue(0, "orgstatus", "");
                if ("Completed".equalsIgnoreCase(status)) {
                    setResponse(ajaxResponse, "N", "Unable to modify as accession is already completed.", "", "", projectname);
                    return;
                }
                if (Util.isNull(status)) {
                    setResponse(ajaxResponse, "Y", "You are allow to change project.", selectproject, neoprojectid, "");
                    return;
                }
                if ("In Progress- QC Failed".equalsIgnoreCase(status)) {
                    setResponse(ajaxResponse, "Y", "You are allow to change project.", selectproject, neoprojectid, "");
                    return;
                }
                if (Util.isNull(orgstatus) && "In Progress - Query".equalsIgnoreCase(status)) {
                    setResponse(ajaxResponse, "Y", "You are allow to change project.", selectproject, neoprojectid, "");
                    return;
                }
                validateProjectTestcode(ajaxResponse, selectproject, selectaccessionid, neoprojectid, projectname);
            } catch (Exception ex) {

            }
        }

    }

    private void setResponse(AjaxResponse ajaxResponse, String msgtype, String msg, String u_bioprojectsid, String neoprojectid, String projectname) {
        ajaxResponse.addCallbackArgument("msgtype", msgtype);
        ajaxResponse.addCallbackArgument("msg", msg);
        ajaxResponse.addCallbackArgument("bioprojectsid", u_bioprojectsid);
        ajaxResponse.addCallbackArgument("neoprojectid", neoprojectid);
        ajaxResponse.addCallbackArgument("projectname", projectname);
        ajaxResponse.print();
    }

    private void validateProjectTestcode(AjaxResponse ajaxResponse, String projectid, String accessionid, String neoprojectid, String projectname) throws SapphireException {
        if (Util.isNull(projectid)) {
            setResponse(ajaxResponse, "N", "Project/Protocol can't be blank.", "", "", projectname);
            return;
        }
        String sql = Util.parseMessage(AccessionPageSql.GET_TESTCODE_BYACCESSIONID, accessionid);
        DataSet dsTestcodes = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestcodes == null || dsTestcodes.size() == 0) {
            setResponse(ajaxResponse, "Y", "You are alow to change project.", projectid, neoprojectid, "");
            return;
        }
        String projectstestcode = StringUtil.replaceAll(dsTestcodes.getColumnValues("lvtestcodeid", ";"), ";", "','");
        sql = Util.parseMessage(AccessionPageSql.GET_TESTCODES_BY_PROJECTID, projectid, projectstestcode, projectstestcode);
        DataSet dsProjectsTestcode = getQueryProcessor().getSqlDataSet(sql);
        if (dsProjectsTestcode == null || dsProjectsTestcode.size() == 0) {
            setResponse(ajaxResponse, "N", "Project and testcode(s) combination does not matched. You can't proceed.", projectid, neoprojectid, projectname);
            return;
            //throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Project and testcode(s) combination does not matched. You can't proceed.");
        }
        if (dsTestcodes != null && dsTestcodes.size() > 0) {
            DataSet dsTestCodeVal = new DataSet();
            dsTestCodeVal.addColumn("project_id", DataSet.STRING);
            dsTestCodeVal.addColumn("specimen_id", DataSet.STRING);
            dsTestCodeVal.addColumn("testcode_id", DataSet.STRING);
            for (int i = 0; i < dsTestcodes.size(); i++) {
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("u_testcodeid", dsTestcodes.getValue(i, "lvtestcodeid", ""));
                DataSet dsTestFilter = dsProjectsTestcode.getFilteredDataSet(hm);
                if (dsTestFilter.size() == 0) {
                    int rowId = dsTestCodeVal.addRow();
                    dsTestCodeVal.setValue(rowId, "project_id", dsTestcodes.getValue(i, "projectprotocolid", ""));
                    dsTestCodeVal.setValue(rowId, "specimen_id", dsTestcodes.getValue(i, "s_sampleid", ""));
                    dsTestCodeVal.setValue(rowId, "testcode_id", dsTestcodes.getValue(i, "lvtestcodeid", ""));

                }
            }
            if (dsTestCodeVal.size() > 0) {
                String errCodes = "Unable to proceed because below testcode(s) does not matches with project label. Please select correct testcode(s).";
                errCodes += Util.getDisplayMessage(dsTestCodeVal);
                //throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errCodes);
                setResponse(ajaxResponse, "N", "Project and testcode(s) combination does not matched. You can't proceed." + errCodes, projectid, neoprojectid, projectname);
                return;
            }
        }
    }

    private void setAgeFlag(DataSet dsFinal) {
        dsFinal.addColumn("age", DataSet.STRING);
        for (int i = 0; i < dsFinal.size(); i++) {
            dsFinal.setValue(i, "age", getYear(dsFinal.getValue(i, "birthdt")));
        }
    }

    private String getYear(String dob) {
        String dobreturn = "";
        try {
            Date date = new Date();
            SimpleDateFormat format = new SimpleDateFormat();

            Date d1 = null;
            d1 = format.parse(dob);

            long diff = date.getTime() - d1.getTime();

            long diffSeconds = diff / 1000 % 60;
            long diffMinutes = diff / (60 * 1000) % 60;
            long diffHours = diff / (60 * 60 * 1000);

            long days = diff / 1000 / 60 / 60 / 24;

            long years = (days / 365);
            if (years < 10 && years == 0) {
                dobreturn = "Y";
            }

        } catch (Exception e) {
        }
        return dobreturn;
    }
}
