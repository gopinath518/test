package sapphire.custom.ng.ajax;

import sapphire.accessor.ActionException;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This is used for checkout sample from storage.
 * 
 * @author debasis.mondal
 *
 */
public class CheckOutSpecimenFromStorage extends BaseAjaxRequest {
	@Override
	public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext)
			throws ServletException {
		AjaxResponse ajaxResponse = new AjaxResponse(request, response);

		String sampleid = ajaxResponse.getRequestParameter("sampleid");
		String samples = StringUtil.replaceAll(sampleid, ";", "','");
		String salTrack = Util.parseMessage(FishSqls.GET_TRACKITEM, samples);
		DataSet dsTrack = getQueryProcessor().getSqlDataSet(salTrack);
		if (dsTrack.getRowCount() == 0) {
			ajaxResponse.addCallbackArgument("msg", "You have scanned an invalid Sample(s)");
			ajaxResponse.print();
			return;
		}
		String trackitemid = dsTrack.getColumnValues("trackitemid", ";");
		PropertyList props = new PropertyList();
		try {
			props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
			props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
			props.setProperty("currentstorageunitid", "(null)");
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
			ajaxResponse.addCallbackArgument("msg", "Sample is successfully checked out from Storage");
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Can't move Sample out of Box ");
			error += ae.getMessage();
			ajaxResponse.addCallbackArgument("msg", error);
		}finally {
			ajaxResponse.print();
		}
	}
}
