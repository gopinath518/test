package sapphire.custom.ng.ajax;

import sapphire.accessor.ActionException;
import sapphire.custom.ng.action.cyto.UpdateCytoStatus;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by dkundu on 12/12/2016.
 */
public class CytoSampleScan extends BaseAjaxRequest{
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        ajaxResponse.addCallbackArgument("err","empty");
        ajaxResponse.addCallbackArgument("msg","empty");
        if(isNull(sampleid)){
            ajaxResponse.addCallbackArgument("err","No sampleid(s) received");
        }
        else{
            String sql = parseMessage(CytoSqls.GET_SAMPLES_WITH_ORIG_OR_DUMMYID, "orgsampleid" ,"orgsampleid", StringUtil.replaceAll(sampleid, ";" , "','") );
            DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
            if(dsSql == null){
                ajaxResponse.addCallbackArgument("err","Unable to perform query in DataBase");
            }
            else if(dsSql.size() == 0){
                ajaxResponse.addCallbackArgument("err","Scanned sample does not belong to Cytogenetics");
            }
            else{
                String nonCytoId = "";
                String cytoSampleIds = "";
                String arrSample[] = sampleid.split(";");
                HashMap<String, String> hmFilter = new HashMap<>();
                for(String samp : arrSample){
                    hmFilter.clear();
                    hmFilter.put("orgsampleid",samp);
                    DataSet dsFilter = dsSql.getFilteredDataSet(hmFilter);
                    if( dsFilter.size() == 0)
                        nonCytoId = nonCytoId + ";" + samp;
                    else
                        cytoSampleIds = cytoSampleIds + ";" + dsFilter.getValue(0,"cytodummysampleid","");
                }
                if( ! isNull(nonCytoId)){
                    ajaxResponse.addCallbackArgument("err","Following samples do not belong to Cytogenetics: "+nonCytoId.substring(1));
                }
                else if(isNull(cytoSampleIds)){
                    ajaxResponse.addCallbackArgument("err","No Cytogenetics sample is found");
                }
                else{
                    PropertyList propupdate = new PropertyList();
                    try {
                        propupdate.setProperty("s_sampleid", sampleid);
                        propupdate.setProperty("custodytakendt", "n");
                        propupdate.setProperty("orgsampleid", "Y");
                        getActionProcessor().processAction("UpdateCytoStatus", "1" , propupdate);
                        ajaxResponse.addCallbackArgument("msg",cytoSampleIds.substring(1));
                    }catch (ActionException ae){
                        ajaxResponse.addCallbackArgument("err","Unable to update Trackitem for following sample(s): "
                                +sampleid +"\nReason: "+ae.getMessage());
                    }
                }
            }
        }
        ajaxResponse.print();
    }
}
