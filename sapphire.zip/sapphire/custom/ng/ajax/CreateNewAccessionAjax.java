package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.AddMultiSample;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by SBaitalik on 1/1/2017.
 */
public class CreateNewAccessionAjax extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                               ServletContext servletContext) throws ServletException {
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        String samplecount = ajaxResponse.getRequestParameter("samplecount", "");
        String sampletypeid = ajaxResponse.getRequestParameter("sampletypeid", "");
        String containertypeid = ajaxResponse.getRequestParameter("containertypeid", "");
        String accessionid = ajaxResponse.getRequestParameter("accessionid", "");
        String sampleids = "";
        if (Util.isNull(samplecount) && Util.isNull(sampletypeid) && Util.isNull(containertypeid)) {
            // throw new SapphireException("Please filled required filled.");
            return;
        }
        try {
            sampleids = createFileSamples(sampletypeid, containertypeid, samplecount, accessionid);
            editReceivedDate(sampleids);
            DataSet dsSampleInfo = getSmapleInfo(accessionid);
            ajaxResponse.addCallbackArgument("dataset", dsSampleInfo);
            ajaxResponse.print();
            // throw new SapphireException("asdas");
        } catch (Exception e) {
            ajaxResponse.addCallbackArgument("dataset", "");
            ajaxResponse.print();
        }

    }

    private String createFileSamples(String sampletypeid, String containertypeid, String samplecount,
                                     String accessionid) throws SapphireException {
        String newsampleid = "";
        String sql = Util.parseMessage(MolecularSql.GET_EXTRACTIONTYPE_BY_SPECIMENTYPE, sampletypeid);
        DataSet dataExtractionType = getQueryProcessor().getSqlDataSet(sql);
        String extractiontype = dataExtractionType.getValue(0, "u_extractiontype", "");

        PropertyList prop = new PropertyList();
        prop.setProperty("sampletype", sampletypeid);
        /*
         * if (!Util.isNull(extractiontype)) { prop.setProperty("transporttype",
		 * "Ellution Tube"); } else { prop.setProperty("transporttype",
		 * containertypeid); }
		 */
        if (containertypeid.contains("Elution Tube")) {
            prop.setProperty("transporttype", "Ellution Tube");
        } else {
            prop.setProperty("transporttype", containertypeid);
        }
        prop.setProperty("copies", samplecount);
        prop.setProperty("accession", accessionid);
        try {
            getActionProcessor().processAction(AddMultiSample.ID, AddMultiSample.VERSIONID, prop);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        newsampleid = prop.getProperty("newsample");
        if (!Util.isNull(extractiontype)) {
            String sampledisArry[] = StringUtil.split(newsampleid, ";");
            for (int i = 0; i < sampledisArry.length; i++) {
                String extractionid = createExtractionID(sampledisArry[i], extractiontype, "");
                updateExtractionIdSpecimen(sampledisArry[i], extractionid, containertypeid);
            }
            return newsampleid;
        } else {
            return newsampleid;
        }
        // A-00002536
        // return newsampleid;
    }

    private DataSet getSmapleInfo(String accessionid) throws SapphireException {
        DataSet dsInfo = null;
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("s_sampleid", DataSet.STRING);
        dsFinal.addColumn("u_clientspecimenid", DataSet.STRING);
        dsFinal.addColumn("testcode", DataSet.STRING);
        dsFinal.addColumn("testname", DataSet.STRING);
        dsFinal.addColumn("sampletypeid", DataSet.STRING);
        dsFinal.addColumn("u_bodysite", DataSet.STRING);
        dsFinal.addColumn("u_sampleinformation", DataSet.STRING);
        dsFinal.addColumn("collectiondt", DataSet.STRING);
        dsFinal.addColumn("containertypeid", DataSet.STRING);
        dsFinal.addColumn("u_type", DataSet.STRING);
        dsFinal.addColumn("u_accessioningcomplete", DataSet.STRING);
        String sql = AccessionPageSql.GET_SAMPLEINFO_BY_ACCESSIONID;
        dsInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{accessionid});

        if (dsInfo != null && dsInfo.size() > 0) {
            for (int i = 0; i < dsInfo.size(); i++) {
                int rowID = dsFinal.addRow();
                dsFinal.setValue(rowID, "s_sampleid", dsInfo.getValue(i, "s_sampleid", ""));
                dsFinal.setValue(rowID, "u_clientspecimenid", dsInfo.getValue(i, "u_clientspecimenid", ""));
                dsFinal.setValue(rowID, "sampletypeid", dsInfo.getValue(i, "sampletypeid", ""));
                dsFinal.setValue(rowID, "u_bodysite", dsInfo.getValue(i, "u_bodysite", ""));
                dsFinal.setValue(rowID, "u_sampleinformation", dsInfo.getValue(i, "u_sampleinformation", ""));
                dsFinal.setValue(rowID, "collectiondt", dsInfo.getValue(i, "collectiondt", ""));
                dsFinal.setValue(rowID, "containertypeid", dsInfo.getValue(i, "containertypeid", ""));
                dsFinal.setValue(rowID, "u_type", dsInfo.getValue(i, "u_type", ""));
                dsFinal.setValue(rowID, "u_accessioningcomplete", dsInfo.getValue(i, "u_accessioningcomplete", ""));
            }
        }

        sql = AccessionPageSql.GET_SAMPLEINFO_INCLD_TESTS_BY_ACCESSION;
        DataSet dsSampInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{accessionid});
        if (dsSampInfo != null && dsSampInfo.size() > 0) {
            for (int i = 0; i < dsFinal.size(); i++) {
                HashMap hm = new HashMap();
                hm.put("s_sampleid", dsFinal.getValue(i, "s_sampleid", ""));
                DataSet dsFilter = dsSampInfo.getFilteredDataSet(hm);
                if (dsFilter != null && dsFilter.size() > 0) {
                    dsFinal.setValue(i, "testcode", dsFilter.getColumnValues("lvtestcodeid", ", "));
                    dsFinal.setValue(i, "testname", dsFilter.getColumnValues("testname", ", "));
                } else {
                    dsFinal.setValue(i, "testcode", "");
                    dsFinal.setValue(i, "testname", "");
                }
            }
        }

        return dsFinal;
    }

    private void editReceivedDate(String sampleids) throws SapphireException {
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("HH:mm");
        String crrntTime = format.format(date);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
        prop.setProperty("receiveddt", StringUtil.repeat("n", StringUtil.split(sampleids, ";").length, ";"));
        prop.setProperty("u_receivetime", StringUtil.repeat(crrntTime, StringUtil.split(sampleids, ";").length, ";"));
        prop.setProperty("u_rootsample", sampleids);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    private void updateExtractionIdSpecimen(String sampleids, String extractionid, String containertypeid)
            throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
        props.setProperty("u_extractionid", extractionid);
        if ("Ellution Tube".equalsIgnoreCase(containertypeid) || "Elution Tube".equalsIgnoreCase(containertypeid)) {
            props.setProperty("u_type", "EU");
        }
        // props.setProperty("specimentype", "Ellution Tube");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

		/*
         * props.clear(); props.setProperty(EditTrackItem.PROPERTY_SDCID,
		 * "Sample"); props.setProperty(EditTrackItem.PROPERTY_KEYID1,
		 * sampleids); props.setProperty("containertypeid", "Ellution Tube");
		 * getActionProcessor().processAction(EditTrackItem.ID,
		 * EditTrackItem.VERSIONID, props);
		 */
    }

    private String createExtractionID(String newsampleid, String extractionType, String sampleInfo)
            throws SapphireException {

        PropertyList hsCreateExtractionID = new PropertyList();
        hsCreateExtractionID.clear();
        hsCreateExtractionID.setProperty("sampleid", newsampleid);
        hsCreateExtractionID.setProperty("extractiontype", extractionType);
        hsCreateExtractionID.setProperty("suffix", sampleInfo);

        try {
            getActionProcessor().processAction("CreateExtractionID", "1", hsCreateExtractionID);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed CreateExtractionID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        return hsCreateExtractionID.getProperty("extractionid", "");
    }
}
