package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 7/7/2016.
 */
public class ChkReagentlotExistance extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        String sql = "select count(1) reglotno from reagentlot where reagentlotid=?";
        DataSet dsRegLotInfo = null;
        String regLotId = "";
        String isValiLot = "N";
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        try{
            if(ajaxResponse==null)
                throw  new SapphireException("AjaxResponse is getting as null");
            regLotId = ajaxResponse.getRequestParameter("reglotid","");
            if(!Util.isNull(regLotId) ){
                Object[] obj = {regLotId};
                dsRegLotInfo = getQueryProcessor().getPreparedSqlDataSet(sql,obj);
                if(dsRegLotInfo!=null && dsRegLotInfo.size()>0){
                    int reglotno = dsRegLotInfo.getInt(0,"reglotno",0);
                    if(reglotno>0)
                        isValiLot = "Y";
                }
            }
            else{
                if(Util.isNull(regLotId))
                    logger.debug("ReagentLot Id is not found");
            }
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("isvalidlot",isValiLot);
                ajaxResponse.addCallbackArgument("reglotid",regLotId);
                ajaxResponse.print();
            }
        }
    }
}
