package sapphire.custom.ng.ajax;

import groovy.lang.GroovyShell;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Created by SBaitalik on 10/24/2016.
 */
public class CalculationRuleImplement extends BaseAjaxRequest {

    String datatableindex = "", rowIndex = "", colIndex = "", inputParamSeq = "", paramDataTypes = "", inputParamName = "";

    @Override
    public void processRequest(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException {

        AjaxResponse ajaxResponse = new AjaxResponse(request, response);
        String sampleid = ajaxResponse.getRequestParameter("sampleid");
        String testcode = ajaxResponse.getRequestParameter("testcode");
        datatableindex = ajaxResponse.getRequestParameter("datatableindex");
        rowIndex = ajaxResponse.getRequestParameter("rowIndex");
        colIndex = ajaxResponse.getRequestParameter("colIndex");
        String isInputParam = ajaxResponse.getRequestParameter("isInputParam");
        inputParamName = ajaxResponse.getRequestParameter("inputParamName");
        String value = ajaxResponse.getRequestParameter("value");
        String orgParamId = ajaxResponse.getRequestParameter("orgParamId");
        String inputParamIdsSet = ajaxResponse.getRequestParameter("inputParamIdsSet");
        String allParamIds = ajaxResponse.getRequestParameter("allParamIds");
        paramDataTypes = ajaxResponse.getRequestParameter("paramDataTypes");

        /*if ("COMMENT".equalsIgnoreCase(inputParamName)) {
            return;
        }*/

        initializeDataSet();
        try {
            if ("y".equalsIgnoreCase(isInputParam)) {
                String status = "";
                if (!Util.isNull(value)) {
                    status = calculateSpecification(testcode, orgParamId, value);
                }
                DataSet calcrule = getCalculationRule(testcode);
                DataSet finalInputParameters = parseParameters(calcrule, allParamIds);
                //Object results = callGroovy(inputParamName, value, finalInputParameters, calcrule, allParamIds);
                Object results = callGroovy(value, finalInputParameters, allParamIds);
                ajaxResponse.addCallbackArgument("sampleid", sampleid);
                ajaxResponse.addCallbackArgument("testcode", testcode);
                ajaxResponse.addCallbackArgument("datatableindex", datatableindex);
                ajaxResponse.addCallbackArgument("rowIndex", rowIndex);
                ajaxResponse.addCallbackArgument("colIndex", colIndex);
                ajaxResponse.addCallbackArgument("isInputParam", isInputParam);
                ajaxResponse.addCallbackArgument("inputParamName", inputParamName);
                ajaxResponse.addCallbackArgument("value", value);
                ajaxResponse.addCallbackArgument("results", results);
                ajaxResponse.addCallbackArgument("outputPosition", inputParamSeq);
                ajaxResponse.addCallbackArgument("orgParamId", inputParamName);
                //ajaxResponse.addCallbackArgument("orgParamId", orgParamId);
                ajaxResponse.addCallbackArgument("status", status);
                ajaxResponse.print();
            } else if ("n".equalsIgnoreCase(isInputParam)) {
                String status = "";
                if (!Util.isNull(value)) {
                    status = calculateSpecification(testcode, orgParamId, value);
                }
                DataSet calcrule = getCalculationRule(testcode);
                DataSet finalInputParameters = parseParameters(calcrule, allParamIds);
                Object results = callGroovy(value, finalInputParameters, allParamIds);
                ajaxResponse.addCallbackArgument("sampleid", sampleid);
                ajaxResponse.addCallbackArgument("testcode", testcode);
                ajaxResponse.addCallbackArgument("datatableindex", datatableindex);
                ajaxResponse.addCallbackArgument("rowIndex", rowIndex);
                ajaxResponse.addCallbackArgument("colIndex", colIndex);
                ajaxResponse.addCallbackArgument("isInputParam", isInputParam);
                ajaxResponse.addCallbackArgument("inputParamName", inputParamName);
                ajaxResponse.addCallbackArgument("value", value);
                ajaxResponse.addCallbackArgument("results", results);
                ajaxResponse.addCallbackArgument("outputPosition", inputParamSeq);
                ajaxResponse.addCallbackArgument("orgParamId", inputParamName);
                //ajaxResponse.addCallbackArgument("orgParamId", orgParamId);
                ajaxResponse.addCallbackArgument("status", status);
                ajaxResponse.print();
            }
        } catch (Exception ex) {
            ajaxResponse.addCallbackArgument("sampleid", sampleid);
            ajaxResponse.addCallbackArgument("testcode", testcode);
            ajaxResponse.addCallbackArgument("datatableindex", datatableindex);
            ajaxResponse.addCallbackArgument("rowIndex", rowIndex);
            ajaxResponse.addCallbackArgument("colIndex", colIndex);
            ajaxResponse.addCallbackArgument("isInputParam", isInputParam);
            ajaxResponse.addCallbackArgument("inputParamName", inputParamName);
            ajaxResponse.addCallbackArgument("value", value);
            ajaxResponse.addCallbackArgument("results", "");
            ajaxResponse.addCallbackArgument("outputPosition", inputParamSeq);
            ajaxResponse.addCallbackArgument("orgParamId", inputParamName);
            //ajaxResponse.addCallbackArgument("orgParamId", orgParamId);
            ajaxResponse.addCallbackArgument("status", "");
            ajaxResponse.print();
        }
        /*String finalInputParameters = parseParameters(inputParamIdsSet);
        Object results = callGroovy(inputParamName, value, finalInputParameters);

        ajaxResponse.addCallbackArgument("sampleid", sampleid);
        ajaxResponse.addCallbackArgument("testcode", testcode);
        ajaxResponse.addCallbackArgument("datatableindex", datatableindex);
        ajaxResponse.addCallbackArgument("rowIndex", rowIndex);
        ajaxResponse.addCallbackArgument("colIndex", colIndex);
        ajaxResponse.addCallbackArgument("isInputParam", isInputParam);
        ajaxResponse.addCallbackArgument("inputParamName", inputParamName);
        ajaxResponse.addCallbackArgument("value", value);
        ajaxResponse.addCallbackArgument("results", results);
        ajaxResponse.addCallbackArgument("outputPosition", "4");
        ajaxResponse.addCallbackArgument("orgParamId", orgParamId);
        ajaxResponse.print();*/

    }

    private Object callGroovy(String value, DataSet finalInputParameters, String allParamIds) {
        String inputParmsStr = "", sValue = "";
        Object obj = null;
        try {
            String inputParamType = finalInputParameters.getValue(0, DATASET_PROPERTY_PARAM_TYPE, "");
            inputParamSeq = finalInputParameters.getValue(0, DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, "");
            int modInptSeq = Integer.parseInt(inputParamSeq) - 1;
            inputParamSeq = Integer.toString(modInptSeq);
            String finalcalcrule = finalInputParameters.getValue(0, DATASET_PROPERTY_CALCULATION_RULE, "");
            //NEW IMPLEMENTATION AFTER NEW DATA LOAD
            allParamIds = allParamIds.replaceAll("\\s+", "");
            String allParamIdsArry[] = StringUtil.split(allParamIds, ";");
            String paramDataTypesArray[] = StringUtil.split(paramDataTypes, ";");
            for (int i = 0; i < allParamIdsArry.length; i++) {
                String modfParameters = "$" + allParamIdsArry[i] + "" + inputParamType;
                if (finalcalcrule.contains(modfParameters)) {
                    if (colIndex.equalsIgnoreCase(Integer.toString(i))) {
                        if ("N".equalsIgnoreCase(paramDataTypesArray[i])) {
                            inputParmsStr += "$" + allParamIdsArry[i] + "" + inputParamType + "=" + value + ";";
                        } else if ("NC".equalsIgnoreCase(paramDataTypesArray[i])) {
                            inputParmsStr += "$" + allParamIdsArry[i] + "" + inputParamType + "=" + value + ";";
                        } else {
                            inputParmsStr += "$" + allParamIdsArry[i] + "" + inputParamType + "='" + value + "';";
                        }
                    } else {
                        inputParmsStr += "$" + allParamIdsArry[i] + "" + inputParamType + "='" + sValue + "';";
                    }
                } else {
                    inputParmsStr += "";
                }
            }
            if (!"COMMENT".equalsIgnoreCase(inputParamName)) {
                String processingCode = "def demo_groovy() { " + inputParmsStr + " " + finalcalcrule + " }; demo_groovy();";
                GroovyShell shell = new GroovyShell();
                obj = shell.evaluate(processingCode);
            } else {
                obj = "";
            }
        } catch (Exception ex) {
            obj = "";
        }

        /*String inputParmsStr = "";
        String finalInputParametersArry[] = StringUtil.split(finalInputParameters, ";");
        for (int i = 0; i < finalInputParametersArry.length; i++) {
            if (finalInputParametersArry[i].equalsIgnoreCase(inputParamName)) {
                inputParmsStr += "$" + finalInputParametersArry[i] + "='" + value + "';";
            } else {
                inputParmsStr += "$" + finalInputParametersArry[i] + "='';";
            }
        }

        Object obj = null;
        String processingCode = "def demo_groovy() { " + inputParmsStr + " " + calcRule + " }; demo_groovy();";
        try {
            GroovyShell shell = new GroovyShell();
            obj = shell.evaluate(processingCode);
        } catch (Exception ex) {
            obj = null;
        }*/
        return obj;
    }

    private DataSet parseParameters(DataSet calcrule, String allParamIds) {
        DataSet dsInput = new DataSet();
        dsInput.addColumn(DATASET_PROPERTY_CALCULATION_RULE, DataSet.STRING);
        dsInput.addColumn(DATASET_PROPERTY_PARAM_ID, DataSet.STRING);
        dsInput.addColumn(DATASET_PROPERTY_PARAM_TYPE, DataSet.STRING);
        dsInput.addColumn(DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, DataSet.STRING);
        String finalParStr = "", finalCalcRule = "", paramid = "", paramtype = "", usersequence = "";
        HashMap hm = new HashMap();
        hm.clear();
        hm.put(DATASET_PROPERTY_CALCULATION_TYPE, "G");
        DataSet dsFilter = dsFinal.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            String calculationrule = dsFilter.getValue(0, DATASET_PROPERTY_CALCULATION_RULE, "");
            String rmvG = StringUtil.replaceAll(calculationrule, "$G", "");
            String rmvB = StringUtil.replaceAll(rmvG, "{", "");
            String rmvC = StringUtil.replaceAll(rmvB, "}", "");
            finalCalcRule = StringUtil.replaceAll(rmvC, ";", "");
            if (finalCalcRule.contains("else")) {
                finalCalcRule = finalCalcRule.replaceAll("else", ";else;");
                finalCalcRule = finalCalcRule.replaceAll("\\s+", "");
                finalCalcRule = finalCalcRule.replaceAll(";else;", " else ");
            } else {
                finalCalcRule = finalCalcRule.replaceAll("\\s+", "");
            }
            paramtype = dsFilter.getValue(0, DATASET_PROPERTY_PARAM_TYPE, "");
            paramid = dsFilter.getValue(0, DATASET_PROPERTY_PARAM_ID, "");
            usersequence = dsFilter.getValue(0, DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, "");
        } else {
            finalCalcRule = "";
            paramtype = "";
            paramid = "";
            usersequence = "";
        }
        int rowId = dsInput.addRow();
        dsInput.setValue(rowId, DATASET_PROPERTY_CALCULATION_RULE, finalCalcRule);
        dsInput.setValue(rowId, DATASET_PROPERTY_PARAM_ID, paramid);
        dsInput.setValue(rowId, DATASET_PROPERTY_PARAM_TYPE, paramtype);
        dsInput.setValue(rowId, DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, usersequence);
        /*String finalParStr = "";
        String inputParamIds[] = StringUtil.split(inputParamIdsSet, ";");
        for (int i = 0; i < inputParamIds.length; i++) {
            if (!"0".equalsIgnoreCase(inputParamIds[i])) {
                finalParStr += ";" + inputParamIds[i];
            }
        }
        finalParStr = finalParStr.substring(1);
        return finalParStr;*/
        return dsInput;
    }

    private DataSet getCalculationRule(String testName) {
        String sqlParamDetls = "select calcrule,paramid,paramtype,usersequence from paramlistitem where paramlistid = '" + testName + "' and calcrule is not null";
        DataSet dsCalc = getQueryProcessor().getSqlDataSet(sqlParamDetls);
        if (dsCalc != null && dsCalc.size() > 0) {
            for (int i = 0; i < dsCalc.size(); i++) {
                String calculationrule = dsCalc.getValue(i, "calcrule", "");
                if (calculationrule.contains("$")) {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, DATASET_PROPERTY_CALCULATION_TYPE, "G");
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAMLISTID, testName);
                    dsFinal.setValue(rowID, DATASET_PROPERTY_CALCULATION_RULE, calculationrule);
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAM_TYPE, dsCalc.getValue(i, "paramtype", ""));
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAM_ID, dsCalc.getValue(i, "paramid", ""));//DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, dsCalc.getValue(i, "usersequence", ""));
                } else {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, DATASET_PROPERTY_CALCULATION_TYPE, "S");
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAMLISTID, testName);
                    dsFinal.setValue(rowID, DATASET_PROPERTY_CALCULATION_RULE, calculationrule);
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAM_TYPE, dsCalc.getValue(i, "paramtype", ""));
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAM_ID, dsCalc.getValue(i, "paramid", ""));
                    dsFinal.setValue(rowID, DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, dsCalc.getValue(i, "paramid", ""));
                }
            }
            //calcrule = dsCalc.getValue(0, "calcrule", "");
            //paramtype = dsCalc.getValue(0, "paramtype", "");
        }
        /*String calcrule = null, paramtype = null;
        if (dsCalc != null && dsCalc.size() > 0) {
            calcrule = dsCalc.getValue(0, "calcrule", "");
            paramtype = dsCalc.getValue(0, "paramtype", "");
        }
        String finalCalcRule = "";
        if (calcrule.contains("$")) {
            String rmvG = StringUtil.replaceAll(calcrule, "$G", "");
            String rmvB = StringUtil.replaceAll(rmvG, "{", "");
            String rmvC = StringUtil.replaceAll(rmvB, "}", "");
            finalCalcRule = StringUtil.replaceAll(rmvC, ";", "");
        } else {
            finalCalcRule = "";
        }*/
        //return finalCalcRule;
        return dsFinal;
    }

    private String calculateSpecification(String testcode, String orgParamId, String value) {
        String results = "";
        String sql = "select" +
                " specltyp.limittypeid, specltyp.condition,specltyp.specid,spcl.paramid,spcl.paramtype,spcl.limittypesequence,spcl.operator1," +
                " spcl.operator2,spcl.value1,spcl.value2" +
                " from specparamlimits spcl, speclimittype specltyp where" +
                " spcl.specid = specltyp.specid" +
                " and spcl.limittypesequence = specltyp.limittypesequence" +
                " and spcl.specid='" + testcode + "'";

        DataSet dsSpec = getQueryProcessor().getSqlDataSet(sql);
        if (dsSpec.size() != 0 && dsSpec != null) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("specid", testcode);
            hm.put("paramid", orgParamId);
            DataSet dsFilter = dsSpec.getFilteredDataSet(hm);
            if (dsFilter.size() != 0 && dsFilter != null) {
                String outputParamId = orgParamId.replaceAll("\\s+", "");
                for (int i = 0; i < dsFilter.getRowCount(); i++) {
                    String operator1 = dsFilter.getValue(i, "operator1", "");
                    String value1 = dsFilter.getValue(i, "value1", "");
                    String condition = dsFilter.getValue(i, "condition", "");
                    if ("=".equalsIgnoreCase(operator1)) {
                        operator1 = "==";
                    }

                    String rule = "def demo_groovy() { " + outputParamId + "=" + value + ";";
                    rule += " if(" + outputParamId + " " + operator1 + " " + value1 + ") return '" + condition + "'";
                    rule += " }; demo_groovy();";
                    GroovyShell shell = new GroovyShell();
                    Object objj = shell.evaluate(rule);
                    if (objj != null) {
                        results += ";" + objj;
                    }
                }
                //String operators = dsFilter.getColumnValues();
            }
            results = results.substring(1);
            results = Util.getUniqueList(results, ";", true);
        }

        return results;
    }


    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_PARAMLISTID = "paramlistid";
    private static final String DATASET_PROPERTY_CALCULATION_RULE = "calcrule";
    private static final String DATASET_PROPERTY_PARAM_TYPE = "paramtype";
    private static final String DATASET_PROPERTY_PARAM_ID = "paramid";
    private static final String DATASET_PROPERTY_CALCULATION_TYPE = "calculationtype";
    private static final String DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE = "usersequence";

    private void initializeDataSet() {
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn(DATASET_PROPERTY_PARAMLISTID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CALCULATION_RULE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PARAM_TYPE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PARAM_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CALCULATION_TYPE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PARAM_ID_USER_SEQUENCE, DataSet.STRING);
        }
    }
}
