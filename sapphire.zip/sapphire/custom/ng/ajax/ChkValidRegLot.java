package sapphire.custom.ng.ajax;

import sapphire.SapphireException;
import sapphire.custom.ng.util.Util;
import sapphire.servlet.AjaxResponse;
import sapphire.servlet.BaseAjaxRequest;
import sapphire.util.DataSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by rrmandal on 6/27/2016.
 */
public class ChkValidRegLot extends BaseAjaxRequest {

    @Override
    public void processRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ServletContext servletContext) throws ServletException {
        String sql = "select count(1) reglotno from reagentlot where reagentlotid=? and reagenttypeid=? and reagenttypeversionid=?";
        DataSet dsRegLotInfo = null;
        String regLotId = "";
        String regTypeId = "";
        String regTypeVerId = "";
        String isValiLot = "N";
        String colid = "";
        AjaxResponse ajaxResponse = new AjaxResponse(httpServletRequest, httpServletResponse);
        try{
            if(ajaxResponse==null)
                throw  new SapphireException("AjaxResponse is getting as null");
            regLotId = ajaxResponse.getRequestParameter("reglotid","");
            regTypeId = ajaxResponse.getRequestParameter("regtypeid","");
            regTypeVerId = ajaxResponse.getRequestParameter("regtypever","");
            colid = ajaxResponse.getRequestParameter("colid","");
            if(!Util.isNull(regLotId) && !Util.isNull(regTypeId) && !Util.isNull(regTypeVerId)){
                Object[] obj = {regLotId, regTypeId,regTypeVerId};
                dsRegLotInfo = getQueryProcessor().getPreparedSqlDataSet(sql,obj);
                if(dsRegLotInfo!=null && dsRegLotInfo.size()>0){
                    int reglotno = dsRegLotInfo.getInt(0,"reglotno",0);
                    if(reglotno>0)
                        isValiLot = "Y";
                }
            }
            else{
                if(Util.isNull(regLotId))
                    logger.debug("ReagentLot Id is not found");
                if(Util.isNull(regTypeId))
                    logger.debug("ReagentType Id Id is not found");
                if(Util.isNull(regTypeVerId))
                    logger.debug("ReagentTypeVersion is not found");
            }
        }
        catch (Exception exp){
            logger.debug(exp.getMessage());
        }
        finally {
            if(ajaxResponse!=null){
                ajaxResponse.addCallbackArgument("isvalidlot",isValiLot);
                ajaxResponse.addCallbackArgument("reglotid",regLotId);
                ajaxResponse.addCallbackArgument("regtypeid",regTypeId);
                ajaxResponse.addCallbackArgument("regtypever",regTypeVerId);
                ajaxResponse.addCallbackArgument("colid",colid);
                ajaxResponse.print();
            }
        }
    }
}
