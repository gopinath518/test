package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;
import sapphire.custom.ng.action.util.NGSendMail;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;
import sapphire.action.AddToDoListEntry;
import com.labvantage.sapphire.actions.report.GenerateReport;

/**
 * Created by ssen on 2/20/2017.
 */
public class ReportCorrection extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {

        String flag = properties.getProperty("flag", "");
        String sampleid = ""; String amendSampleid = "";  String batchid = "";

        if(flag.equalsIgnoreCase("amend")){
            sampleid = properties.getProperty("reportsam", ";");
            amendSampleid = properties.getProperty("promptsam", ";");
            batchid = properties.getProperty("batchid", ";");

        } else {
            sampleid = properties.getProperty("s_sampleid", ";");
            //String amendSampleid = properties.getProperty("promptsam", ";");
            batchid = properties.getProperty("u_ngbatchid", ";");

        }

        String correctionvalue = properties.getProperty("u_correctionvalue", "");
        String correctioncomment = properties.getProperty("u_correctioncomments", "");


        if (Util.isNull(sampleid))
            throw new SapphireException("No Sampleid(s) found");
        else if (Util.isNull(batchid))
            throw new SapphireException("No Batchid found");
        else {
            if(flag.equalsIgnoreCase("amend")){
                if (amendSampleid.indexOf(";") == 0 )
                    amendSampleid = amendSampleid.substring(1);
                reportCorrectionOnSample(amendSampleid, correctionvalue, correctioncomment);

            } else {
                if (sampleid.indexOf(";") == 0 )
                    sampleid = sampleid.substring(1);
                reportCorrectionOnSample(sampleid, correctionvalue, correctioncomment);
                sampleid = ";" + sampleid;

            }

            //sendEmailNotification(sampleid, batchid);


            if (flag.equalsIgnoreCase("amend")) {

                PropertyList props = new PropertyList();
                props.clear();
                props.setProperty("s_sampleid", sampleid);
                props.setProperty("u_ngbatchid", batchid);
                try {
                    getActionProcessor().processAction("MolecularGenetics", "1", props);
                } catch (Exception ae) {
                    String error = ae.getMessage();
                    throw new SapphireException("Action failed." + error);
                }

            }
        }
    }

    public void reportCorrectionOnSample(String sampleid, String corrval, String corrcomment) throws SapphireException{
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        props.setProperty("u_correctionvalue", corrval);
        props.setProperty("u_correctioncomments", corrcomment);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

    }

    public void sendEmailNotification(String sampleid, String batchid) throws SapphireException {
        if (!Util.isNull(sampleid)) {
            String sql = "select s.s_sampleid as sampleid,a.u_accessionid as accessionid,a.bioprojectname,sim.investigatorname,sim.siteid,b.projectid,s.u_rootsample as rootsample" +
                    " from s_sample s,u_accession a,u_biosite b,u_accessionbioinvsmap aim,u_siteinvestigatormap sim" +
                    " where s.s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "')and s.u_accessionid = a.u_accessionid" +
                    " and b.siteid = a.biositeid" +
                    " and a.u_accessionid = aim.accessionid" +
                    " and aim.investigatorid = sim.u_siteinvestigatormapid";
            DataSet sqlval = getQueryProcessor().getSqlDataSet(sql);
            if (sqlval != null || sqlval.size() > 0) {
                PropertyList propmail = new PropertyList();
                propmail.clear();
                propmail.setProperty(NGSendMail.NODE_ID, "Report");
                propmail.setProperty(NGSendMail.KEYID1, sqlval.getColumnValues("accessionid", ";"));
                propmail.setProperty(NGSendMail.ACCESSIONID, sqlval.getColumnValues("accessionid", "','"));
                //propmail.setProperty(NGSendMail.SUBJECTID, sqlval.getColumnValues("sampleid", ""));
                propmail.setProperty(NGSendMail.PROJECTID, sqlval.getColumnValues("projectid", ";"));
                propmail.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, sqlval.getColumnValues("siteid", ";"));
                propmail.setProperty(NGSendMail.INVESTIGATOR_NAME, sqlval.getColumnValues("invesitagtorname", ";"));
                propmail.setProperty(NGSendMail.REPORTID, GenerateReport.ID);
                propmail.setProperty(NGSendMail.REPORTVERSIONIDID, GenerateReport.VERSIONID);
                propmail.setProperty(NGSendMail.SAMPLEID, sqlval.getColumnValues("rootsample", ";"));
                propmail.setProperty(NGSendMail.BATCHID, batchid);
                propmail.setProperty(NGSendMail.MODE, "AttachReport");
                propmail.setProperty(NGSendMail.PARAM1_NAME, "sampleid");
                propmail.setProperty(NGSendMail.PARAM1_VAL, sqlval.getColumnValues("sampleid", ";"));
                propmail.setProperty(NGSendMail.PARAM2_NAME, "batchid");
                propmail.setProperty(NGSendMail.PARAM2_VAL, batchid);
                propmail.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
                propmail.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
                propmail.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
                propmail.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
                getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, propmail);
            }
        }

    }


}