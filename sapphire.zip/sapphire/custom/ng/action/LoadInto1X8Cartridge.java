package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateStorageUnit;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

/**Action Name- CreateHemeExtractionTube
 * Description: This Action is use to create 1x8 box/cartidge and load sample on it.
 * input :-
 * param1-sampleid
 * throws SapphireException
 * Created by mpandey on 6/16/2016.
 */
public class LoadInto1X8Cartridge extends BaseAction {
    private static final String CREATESTORAGEUNIT_MAXTIALLOWED_PROP = "maxtiallowed";
    private static final String CREATESTORAGEUNIT_PROPERTYTREEID_PROP = "propertytreeid";
    private static final String CREATESTORAGEUNIT_MOVEABLEFLAG_PROP = "moveableflag";
    private static final String CREATESTORAGEUNIT_NEWKEYID1_PROP = "newkeyid1";
    private static final String CREATESTORAGEUNIT_NODEID_PROP = "nodeid";
    private static final String CREATESTORAGEUNIT_SIZE_PROP = "size";
    private static final String CREATESTORAGEUNIT_RETURN_PROP = "storageunitid";
    private static final String LV_BOX_SDC = "LV_Box";
    private static final String BOXTYPE_PROP = "boxtype";
    private static final String BOXSTATUS_PROP = "boxstatus";
    String newBoxId="";


    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1", "");

        if (batchid.length() == 0)
            throw new SapphireException("properties is obtained as null");
        String sampleid = getSamplesFromBatch(batchid);
        if (!Util.isNull(sampleid)) {
            String boxStgid = crtBox();
            if (!Util.isNull(boxStgid)) {
                checkInSampleinBox(boxStgid, sampleid);
                linkBatchNBox(batchid,newBoxId);
            }
        }


    }

    /**
     * This method is use to establish a relation b/w batch and box
     * by populating batch detail table.
     * @param batchid
     * @param newBoxId
     */
    private void linkBatchNBox(String batchid, String newBoxId) {
        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
        pl.setProperty("plateid", newBoxId);
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
        } catch (ActionException e) {
            e.printStackTrace();
        }
    }

    /**
     * This function is use to get samples associated with a batch .
     * @param batchid
     * @return
     * @throws SapphireException
     */
    private String getSamplesFromBatch(String batchid) throws SapphireException {
        String testmap_sql = "select sampleid from U_NGBATCH_SAMPLE where u_ngbatchid='" + batchid + "'";
        DataSet dsSample = getQueryProcessor().getSqlDataSet(testmap_sql);

        if (dsSample == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += testmap_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsSample.size() == 0) {
            String error = getTranslationProcessor().translate("There is not any sample in this batch");
            error += testmap_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String sampleid = dsSample.getColumnValues("sampleid", ";");
        return sampleid;
    }

    /**
     * This method is use to create new unsorted empty box.
     * @return Storage unit id of box.
     * @throws SapphireException
     */
    private String crtBox() throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, LV_BOX_SDC);
        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
        prop.setProperty(BOXTYPE_PROP, "Unsorted");
        prop.setProperty(BOXSTATUS_PROP, "Empty");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
         newBoxId = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
        prop.clear();

        DataSet trackItemDS = getQueryProcessor().getPreparedSqlDataSet("select trackitemid from trackitem where linkkeyid1 = ?", new String[]{newBoxId});
        if (trackItemDS != null) {
            String tiIdBox = trackItemDS.getValue(0, "trackitemid", "");
            prop.clear();
            prop.setProperty(CreateStorageUnit.PROPERTY_LINKPROPNODEID, "Grid|Cartridge-1X8");
            prop.setProperty(CreateStorageUnit.PROPERTY_CREATESU, "Y");
            prop.setProperty(CreateStorageUnit.PROPERTY_LINKSDCID, LV_BOX_SDC);
            prop.setProperty(CREATESTORAGEUNIT_MAXTIALLOWED_PROP, "undefined;1");
            prop.setProperty(CREATESTORAGEUNIT_PROPERTYTREEID_PROP, "Grid;No Layout");
            prop.setProperty(CREATESTORAGEUNIT_MOVEABLEFLAG_PROP, "Y;N");
            prop.setProperty(CREATESTORAGEUNIT_NEWKEYID1_PROP, newBoxId);
            prop.setProperty(CREATESTORAGEUNIT_NODEID_PROP, "Cartridge-1X8;BoxPos");
            prop.setProperty(CREATESTORAGEUNIT_SIZE_PROP, "1;8");
            getActionProcessor().processAction(CreateStorageUnit.ID, CreateStorageUnit.VERSIONID, prop);

            String stgUnitIdPlt = StringUtil.split(prop.getProperty(CREATESTORAGEUNIT_RETURN_PROP, ""), ";")[0];
            prop.clear();

            prop.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, tiIdBox);
            prop.setProperty("custodialdepartmentid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            return stgUnitIdPlt;
        }
        return "";
    }

    /**
     * This method is use to check in samples in a box.
     * @param boxStgId
     * @param sampleid
     * @throws SapphireException
     */
    private void checkInSampleinBox(String boxStgId, String sampleid) throws SapphireException {
        if (!Util.isNull(boxStgId) && !Util.isNull(sampleid)) {
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid = ?";
            DataSet dsStorage = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{boxStgId});
            if (dsStorage != null && dsStorage.size() > 0) {
                String samplearr[] = StringUtil.split(sampleid, ";");
                if (samplearr != null && samplearr.length > 0) {
                    String[] boxPosArr =getBoxPosArr(sampleid);
                        DataSet result = new DataSet();
                        result.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
                        result.addColumn("currentstorageunitid", DataSet.STRING);
                        for (int i = 0; i < samplearr.length; i++) {
                            if (dsStorage != null && dsStorage.size() > 0) {
                                int rowIndex = result.addRow();
                                String temStgId =  dsStorage.getValue(Integer.parseInt(boxPosArr[i]) - 1, "storageunitid", "");
                                if (!Util.isNull(temStgId)) {
                                    result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, samplearr[i]);
                                    result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                }
                            }
                       }
                        if (result != null && result.size() > 0) {
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, result.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                            pl.setProperty("currentstorageunitid", result.getColumnValues("currentstorageunitid", ";"));
                            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        }
                    }
                }
            }
        }

    /**
     * This method is use to get array of position.
     * @param sampleid
     * @return
     */
    private String[] getBoxPosArr(String sampleid) {
        String sql="select sampledesc from s_sample where s_sampleid in('"+StringUtil.replaceAll(sampleid,";","','")+"')";
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        String[] boxpos = new String[dsSample.size()];
        if(dsSample.size()>0){
            for(int i=0;i<dsSample.size();i++){
               String curdesc=dsSample.getValue(i,"sampledesc");
                boxpos[i]= String.valueOf(curdesc.charAt(curdesc.length()-1));
            }
        }

            return boxpos;
    }

    /**
     * This method is use to get positions in box
     * @param plc
     * @param elTubeNo
     * @return
     * @throws SapphireException
     */
    private String getBoxPosToLd(PropertyListCollection plc, String elTubeNo) throws SapphireException {
        if (plc != null && plc.size() > 0) {
            for (int i = 0; i < plc.size(); i++) {
                PropertyList tempPl = plc.getPropertyList(i);
                if (tempPl != null && tempPl.size() > 0) {
                    String sampleNo = tempPl.getProperty("noofsamples", "");
                    if (elTubeNo.equalsIgnoreCase(sampleNo))
                        return tempPl.getProperty("boxpos", "");
                }
            }
        }
        return "";
    }

}

