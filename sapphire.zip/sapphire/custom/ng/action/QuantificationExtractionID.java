package sapphire.custom.ng.action;

import sapphire.SapphireException;

import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 6/7/2016.
 * @desc :From Quantification whenever re-extraction is required the sample
 * needs to move to the Extraction tramstop for re-extraction by appending the
 * selected sample's extractionid as'-RX' for first time and if it is demanded to
 * re-extract again then extractionid should be appended as '-RX2' and moved back
 * to Extraction tramstop.
 */
public class QuantificationExtractionID extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException{
        String sampleid=properties.getProperty("s_sampleid","");
        String extractionid=properties.getProperty("u_extractionid","");
        String currentmovementstep=properties.getProperty("currentmovementstep","");
        if(!Util.isNull(currentmovementstep))
            currentmovementstep="MolecularExtraction";
        if(sampleid.equalsIgnoreCase("") || extractionid.equalsIgnoreCase("")){
            throw new SapphireException("Sampleid or Extractionid is blank");
        }
        if(extractionid.endsWith("-RX") || extractionid.endsWith("-RX2") || extractionid.endsWith("-RX-R")) {
            if (extractionid.endsWith("-RX")) {
                String secextractionid = extractionid.replaceAll("-RX", "-RX2");
                updatequantSample(sampleid, secextractionid,currentmovementstep);
            }
            if (extractionid.endsWith("-RX2")) {
                String reextractionid = extractionid.replaceAll("-RX2", "-RX-R");
                updatequantSample(sampleid, reextractionid,currentmovementstep);
            }/*
            if (extractionid.endsWith("-RX-R")) {
                String e = getTranslationProcessor().translate("Sample can not extracted further");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, e);
            }*/
        }else{
           String nextractionid=extractionid +"-RX";
           updatequantSample(sampleid,nextractionid,currentmovementstep);
       }


    }

    /**
     * @desc :Updates the new appended extraction id according to the requirement.
     * @param sampleid :Sampleid whose extractionid needs to be changed
     * @param newextractionid: New Extractionid
     * @throws SapphireException
     */
    private void updatequantSample(String sampleid,String newextractionid,String currentmovementstep) throws SapphireException {
        try {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_extractionid", newextractionid);
            prop.setProperty("u_currentmovementstep", currentmovementstep);

            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,prop);

            prop.clear();

            prop.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1,sampleid);
            prop.setProperty("custodialdepartmentid",connectionInfo.getDefaultDepartment());
            prop.setProperty("custodialuserid","(null)");
            prop.setProperty("u_currenttramstop",currentmovementstep);

            getActionProcessor().processAction(EditTrackItem.ID,EditTrackItem.VERSIONID,prop);
        }catch(SapphireException e){

            String error= getTranslationProcessor().translate("Extraction ID not created");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,error);
        }
    }
}
