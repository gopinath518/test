package sapphire.custom.ng.action;

import org.tempuri.vms.startvmsws.StartVMSws;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.action.vms.*;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.EncryptDecrypt;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

/**
 * Created by dgupta on 7/18/2016.
 */
public class OpenVMSForQC extends BaseAction {

    private final String HOMOGENEOUSLOSPOLICYID = "HomogeneousLOSPolicy";
    private final String NODEID = "IHCLOS";
    private final String POLICY_MAPPING = "losmapping";
    private final String POLICY_PARENT_LOS = "parentlos";
    private final String POLICY_CHILD_LOS = "childlos";
    private final String POLICY_CHILD_LOS_ID = "childlosid";
    String filenames = "";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String tramstop = properties.getProperty("tramstop", "");
        if (sampleid.contains("#semicolon#")) {
            sampleid = StringUtil.replaceAll(sampleid, "#semicolon#", ";");
        }

        sampleid = StringUtil.replaceAll(sampleid, ";", "','");
        String userid = connectionInfo.getSysuserId();

        DataSet dsAccess = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.OPENVMSFORQC_ACCESSION_SQL, sampleid));

        // validate samples are from same accession and has same los
        validateSamples(dsAccess);

        // randomly selevct a file from the given list to show againts the sample
        //File[] f = new File("\\\\ir1-isilon.neogen.local\\IHCIMG-Test\\QA\\Images\\").listFiles();
        /*String folderpath = "\\\\usavhnas2\\IT_Developement\\QA\\Aperio\\Images";
        String[] f = StringUtil.split(filenames, ";");
        int x = (int) (Math.random() * 20);
        while (f.length < x) {  //|| (!f[x].endsWith("tif"))
            x = (int) (Math.random() * 20);
        }
        String randomImageFile = folderpath + "\\" + f[x];*/

// query are transferred to separate file But just to provide complete information its mention here, its only in your copy of code
        DataSet dsuser = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.OPENVMSFORQC_USER, userid));
        DataSet dsSample = null;
        if (Util.isNull(tramstop))
            dsSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.OPENVMSFORQC_SAMPLE_SQL, sampleid));
        else
            dsSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.FLOW_OPENVMSFORQC_SAMPLE_SQL, sampleid));

        String xmlString = "";
        try {
            StartVMSws.setVMSUrl(getVmsUrl()); ///"http://av1qvm-imgvw01.neogen.local/VMS/Internal/StartVMSws.asmx?WSDL");
        } catch (Exception ex) {
        }
// start creating vms session xml
        VMSSession vmsSession = new VMSSession();
        vmsSession.setVersion("1.0");
        vmsSession.setAccessor("{226D4CB8-C5FD-4f68-A8B8-B7E4756F7B0A}");
        vmsSession.setUserID(userid);
        vmsSession.setUserDisplayName(dsuser.getString(0, "sysuserdesc"));

        List<ImageType> imageList = getMenuImageTypes(dsAccess, userid, dsuser, vmsSession);

        // populate data for each sample and corresponding image
        for (int i = 0; i < dsSample.getRowCount(); i++) {
            ImageType imageType = new ImageType();
            setImageData(dsSample.getString(i, "aperioqcstatus", ""), dsSample.getString(i, "filepath", "") + File.separator + dsSample.getString(i, "filename", ""), dsSample, i, imageType);
            imageList.add(imageType);
        }

//  create xml from the vms session object
        try {
            StringWriter sw = new StringWriter();
            JAXBContext jaxbContext = JAXBContext.newInstance(VMSSession.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            jaxbMarshaller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);
            jaxbMarshaller.marshal(vmsSession, sw);
            xmlString = sw.toString();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new SapphireException(ex.getMessage());
        }
// set xml to property and call the action to open vms
        properties.setProperty("inputXml", xmlString);
        getActionProcessor().processAction("CallVMSWebService", "1", properties);
    }

    /**
     * this method  validate samples belongs to one accession
     * and has same level of service
     *
     * @param dsAccess Accession dataset for input sample
     * @return void
     * @throws Exception if condition fails
     */
    private void validateSamples(DataSet dsAccess) throws SapphireException {
        if (dsAccess == null) throw new SapphireException("Problem - may be test code not assigned to Sample ");
        if (dsAccess.getRowCount() > 0) {
            /*String los = dsAccess.getString(0, "los", "");
            PropertyList homogeneousLOS = setHomogeneousLOS();
            los = homogeneousLOS.getProperty(los);
            for (int i = 0; i < dsAccess.getRowCount(); i++) {
                if (los.equalsIgnoreCase(homogeneousLOS.getProperty(dsAccess.getString(i, "los")))) {
                    los = homogeneousLOS.getProperty(dsAccess.getString(i, "los"));
                } else {
                    throw new SapphireException("samples are not from same LOS " + dsAccess.getColumnValues("los", " and  ") + " or " +
                            " in different status " + dsAccess.getColumnValues("u_currentmovementstep", " and "));
                }
            }*/
            String accessionid = Util.getUniqueList(dsAccess.getColumnValues("u_accessionid", ";"), ";", true);
            String arrAccession[] = StringUtil.split(accessionid, ";");
            if (arrAccession.length > 1) {
                throw new SapphireException("Multiple accession(s) can not allowed to proceed at a time.");
            }
        }
    }

    /**
     * This priavte  method used to set image data, image menu items, QC status sub menu items
     * and image meta data and image details
     *
     * @param randomImageFile complete image file name with folder location.
     * @param dsSample        dataset for all input samples
     * @param i               loop count
     * @param imageType       Image type object to populate data
     * @return void
     */
    private void setImageData(String aperiostatus, String randomImageFile, DataSet dsSample, int i, ImageType imageType) {
        setImageAttribute(aperiostatus, dsSample, i, imageType);

        MenuItemsType menuItemsType1 = new MenuItemsType();
        List<MenuItemType> menuItemListLoop = menuItemsType1.getMenuItem();
        MenuItemType menuItemType1 = new MenuItemType();

        setImageMenuAttribute(menuItemType1);
        setQCStatusSubMenu(menuItemType1);

        menuItemListLoop.add(menuItemType1);
        imageType.setMenuItems(menuItemsType1);

        MetaDataType metaDataType1 = new MetaDataType();
        setImageMetaData(dsSample, i, metaDataType1);
        imageType.setMetaData(metaDataType1);

        ImageDetailsType imageDetailsType = new ImageDetailsType();
        setImageDetails(aperiostatus, randomImageFile, dsSample, i, imageDetailsType);
        imageType.setImageDetails(imageDetailsType);

        logger.info("AperioStatusDATA>>>>", aperiostatus);
    }

    /**
     * This method is used to menu items and meta data for the session xml header
     * this information appears at header level of xml
     *
     * @param dsAccess   accession data set for input samples
     * @param userid     user id for logged in user
     * @param dsuser     dataset information of logged in user
     * @param vmsSession VMS session object to creaet session
     * @return List<ImageType>  returns list of image type object
     */
    private List<ImageType> getMenuImageTypes(DataSet dsAccess, String userid, DataSet dsuser, VMSSession vmsSession) {
        MenuItemsType menuItemsType = new MenuItemsType();
        createHeaderMenu(menuItemsType.getMenuItem());
        vmsSession.setMenuItems(menuItemsType);

        MetaDataType metaDataType = new MetaDataType();
        createHeaderMetaData(dsAccess, userid, dsuser, metaDataType);
        vmsSession.setMetaData(metaDataType);

        ImagesType imagesType = new ImagesType();
        vmsSession.setImages(imagesType);
        return imagesType.getImage();
    }

    /**
     * This method sets header level menu item in vms session xml
     *
     * @param menuItemType1 menu item type object at header level
     */
    private void setImageMenuAttribute(MenuItemType menuItemType1) {
        menuItemType1.setId("mnuQCStatusUpdate");
        menuItemType1.setOnClick("");
        menuItemType1.setType("Parent");
        menuItemType1.setImg("images/GreenBall_Over.gif");
        menuItemType1.setImgOver("images/GreenBall_Over.gif");
        menuItemType1.setText("QC Status Update");
    }

    /**
     * This method populate file name with path and othe image detail informations
     *
     * @param randomImageFile  file to shown for QC
     * @param dsSample         sample dataset of input samples
     * @param i                index in sample dataset
     * @param imageDetailsType image detail object of vms session xml
     */
    private void setImageDetails(String aperiostatus, String randomImageFile, DataSet dsSample, int i, ImageDetailsType imageDetailsType) {
        List<DataItemType> dataItemTypeImages = imageDetailsType.getImageDetail();

        DataItemType dataItemType5 = new DataItemType();
        dataItemType5.setName("FilePath");
        dataItemType5.setValue(randomImageFile);
        dataItemTypeImages.add(dataItemType5);
        DataItemType dataItemType6 = new DataItemType();
        dataItemType6.setName("PerformAnalysis");
        dataItemType6.setValue("0");
        /*if ("QCFail".equalsIgnoreCase(aperiostatus)) {
            dataItemType6.setValue("0");
        } else {
            dataItemType6.setValue("1");
        }*/
        dataItemTypeImages.add(dataItemType6);
        DataItemType dataItemType7 = new DataItemType();
        dataItemType7.setName("TestCode");
        dataItemType7.setValue(dsSample.getString(i, "testname"));
        dataItemTypeImages.add(dataItemType7);
        logger.info("AperioStatusDetail>>>>", aperiostatus);
    }

    /**
     * This method set image metat data for vms qc session
     *
     * @param dsSample      sample dataset for input samples
     * @param i             index in sample dataset
     * @param metaDataType1 metadata object of image object
     */
    private void setImageMetaData(DataSet dsSample, int i, MetaDataType metaDataType1) {
        List<DataItemType> dataItemTypeList = metaDataType1.getDataItem();
        Calendar slideRunCal = dsSample.getCalendar(i, "scanendtime");

        DataItemType dataItemType = new DataItemType();
        dataItemType.setName("Date Slide Run");
        dataItemType.setValue(slideRunCal.get(Calendar.MONTH) + "-" + slideRunCal.get(Calendar.DAY_OF_MONTH) + "-" + slideRunCal.get(Calendar.YEAR) + "-" + slideRunCal.get(Calendar.HOUR_OF_DAY)
                + "-" + slideRunCal.get(Calendar.MINUTE) + "-" + slideRunCal.get(Calendar.AM_PM));
        dataItemTypeList.add(dataItemType);

        DataItemType dataItemType1 = new DataItemType();
        dataItemType1.setName("Test Name");
        dataItemType1.setValue(dsSample.getString(i, "testname"));
        dataItemTypeList.add(dataItemType1);

        DataItemType dataItemType2 = new DataItemType();
        dataItemType2.setName("Specimen Barcode");
        dataItemType2.setValue(dsSample.getString(i, "s_sampleid"));
        dataItemTypeList.add(dataItemType2);
        DataItemType dataItemType3 = new DataItemType();
        dataItemType3.setName("Parent Specimen");
        dataItemType3.setValue("S16-TEST2");
        dataItemTypeList.add(dataItemType3);
        DataItemType dataItemType4 = new DataItemType();
        dataItemType4.setName("Patient Name");
        dataItemType4.setValue(dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname"));
        dataItemTypeList.add(dataItemType4);
    }

    /**
     * This method sets menu for QC status for individual sample images
     *
     * @param menuItemType1 menu itme type object of images
     */
    private void setQCStatusSubMenu(MenuItemType menuItemType1) {
        List<SubItemType> subItemTypesList = menuItemType1.getSubItem();
        SubItemType subItemType = new SubItemType();
        subItemType.setId("mnuQCStatusUpdate1");
        subItemType.setOnClick("QCStatusUpdate('pass',true);");
        subItemType.setType("Button");
        subItemType.setImg("images/GreenBall_Over.gif");
        subItemType.setImgOver("images/GreenBall_Over.gif");
        subItemType.setText("Pass");
        subItemTypesList.add(subItemType);
        SubItemType subItemType1 = new SubItemType();
        subItemType1.setId("mnuQCStatusUpdate2");
        subItemType1.setOnClick("QCStatusUpdate('fail',true);");
        subItemType1.setType("Button");
        subItemType1.setImg("images/QCFail.gif");
        subItemType1.setImgOver("images/QCFail.gif");
        subItemType1.setText("Fail");
        subItemTypesList.add(subItemType1);
        SubItemType subItemType2 = new SubItemType();
        subItemType2.setId("mnuQCStatusUpdate3");
        subItemType2.setOnClick("QCStatusUpdate('suboptimal',true);");
        subItemType2.setType("Button");
        subItemType2.setImg("images/Delete_Over.gif");
        subItemType2.setImgOver("images/Delete_Over.gif");
        subItemType2.setText("Suboptimal");
        subItemTypesList.add(subItemType2);
    }

    /**
     * this method sets attribute likesample id first name last name etc at image/sample level
     *
     * @param dsSample  sample data set for input samples
     * @param i         index in sample dataset
     * @param imageType image type object of vms session
     */
    private void setImageAttribute(String aperiostatus, DataSet dsSample, int i, ImageType imageType) {
        imageType.setExternalIdentifier(dsSample.getString(i, "s_sampleid") + ";" + dsSample.getString(i, "u_aperiostatusid"));
        imageType.setImageSource("APERIO");//TODO APERIO IS NOW HARD CODED HERE
        //imageType.setImageSource(dsSample.getString(i, "scanner", "APERIO"));//TODO AS DYNAMIC DATA IS NOT NECESSARY
        imageType.setDefaultImage(0 == i ? "true" : "false");
        imageType.setAllowEdit("false");
        /*if ("QCFail".equalsIgnoreCase(aperiostatus)) {
            imageType.setAllowEdit("false");
        } else {
            imageType.setAllowEdit("true");
        }*/
        imageType.setTitleBar(dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname") + " - " + dsSample.getString(i, "testname") +
                " - " + dsSample.getString(i, "s_sampleid") + " - Accession# " + dsSample.getString(i, "u_accessionid"));
        imageType.setDescription(dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname") + " - " + dsSample.getString(i, "testname"));
    }

    /**
     * this method populate header meta data
     *
     * @param dsAccess     accession dataset for input samples
     * @param userid       user id of logged in user
     * @param dsuser       data set of logged in used
     * @param metaDataType meta data type object of session
     */
    // made new changes to include lvs details, VMS user/password,url etc in request xml it self
    private void createHeaderMetaData(DataSet dsAccess, String userid, DataSet dsuser, MetaDataType metaDataType) {
        DataSet dsVMSDetail = getQueryProcessor().getSqlDataSet(IHCSql.OPENVMSFORQC_VMSDETAIL_SQL);

        List<DataItemType> nameValueTypeList = metaDataType.getDataItem();
        DataItemType nameValueType = new DataItemType();
        nameValueType.setName("LISPlugIn");
        nameValueType.setValue("LabVantage");
        nameValueTypeList.add(nameValueType);
        nameValueType = new DataItemType();
        nameValueType.setName("SSN");
        nameValueType.setValue("000-00-0000");
        nameValueTypeList.add(nameValueType);

        if (dsVMSDetail != null && dsVMSDetail.getRowCount() > 0) {
            HashMap hmVms = new HashMap();
            hmVms.put("u_environmentalpropid", "vms.lvuserid");
            DataSet dsFilter = dsVMSDetail.getFilteredDataSet(hmVms);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                nameValueType = new DataItemType();
                nameValueType.setName("LISUser");
                nameValueType.setValue(dsFilter.getString(0, "propvalue"));
                nameValueTypeList.add(nameValueType);
            } else {
                nameValueType = new DataItemType();
                nameValueType.setName("LISUser");
                nameValueType.setValue("Not Found");
                nameValueTypeList.add(nameValueType);
            }
            hmVms.clear();
            hmVms.put("u_environmentalpropid", "vms.lvuserpassword");
            dsFilter = dsVMSDetail.getFilteredDataSet(hmVms);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                nameValueType = new DataItemType();
                nameValueType.setName("LISPassword");
                nameValueType.setValue(EncryptDecrypt.decrypt(dsFilter.getString(0, "propvalue")));
                nameValueTypeList.add(nameValueType);
            } else {
                nameValueType = new DataItemType();
                nameValueType.setName("LISPassword");
                nameValueType.setValue("Not Found");
                nameValueTypeList.add(nameValueType);
            }
            hmVms.clear();
            hmVms.put("u_environmentalpropid", "lvdatabaseid");
            dsFilter = dsVMSDetail.getFilteredDataSet(hmVms);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                nameValueType = new DataItemType();
                nameValueType.setName("LISDatabaseId");
                nameValueType.setValue(dsFilter.getString(0, "propvalue"));
                nameValueTypeList.add(nameValueType);
            } else {
                nameValueType = new DataItemType();
                nameValueType.setName("LISDatabaseId");
                nameValueType.setValue("Not Found");
                nameValueTypeList.add(nameValueType);
            }
            hmVms.clear();
            hmVms.put("u_environmentalpropid", "labvantaget.url");
            dsFilter = dsVMSDetail.getFilteredDataSet(hmVms);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                nameValueType = new DataItemType();
                nameValueType.setName("LISEndpoint");
                nameValueType.setValue(dsFilter.getString(0, "propvalue"));
                nameValueTypeList.add(nameValueType);
            } else {
                nameValueType = new DataItemType();
                nameValueType.setName("LISEndpoint");
                nameValueType.setValue("Not Found");
                nameValueTypeList.add(nameValueType);
            }
        } else {
            nameValueType = new DataItemType();
            nameValueType.setName("LISEndpoint");
            nameValueType.setValue("Not Found");
            nameValueTypeList.add(nameValueType);
            nameValueType = new DataItemType();
            nameValueType.setName("LISDatabaseId");
            nameValueType.setValue("Not Found");
            nameValueTypeList.add(nameValueType);
            nameValueType = new DataItemType();
            nameValueType.setName("LISPassword");
            nameValueType.setValue("Not Found");
            nameValueTypeList.add(nameValueType);
            nameValueType = new DataItemType();
            nameValueType.setName("LISUser");
            nameValueType.setValue("Not Found");
            nameValueTypeList.add(nameValueType);
        }

        nameValueType = new DataItemType();
        nameValueType.setName("User");
        if (null == dsuser)
            nameValueType.setValue(userid);
        else
            nameValueType.setValue(dsuser.getString(0, "sysuserdesc"));
        nameValueTypeList.add(nameValueType);
        nameValueType = new DataItemType();
        nameValueType.setName("Level of Service");
        nameValueType.setValue(dsAccess.getString(0, "los"));
        nameValueTypeList.add(nameValueType);
    }

    /**
     * This method populate header menu for the sesion
     *
     * @param menuItemList menu item list object to populate
     */
    private void createHeaderMenu(List<MenuItemType> menuItemList) {
        MenuItemType menuItemType = new MenuItemType();
        menuItemType.setId("mnuPrevious");
        menuItemType.setType("Button");
        menuItemType.setOnClick("PreviousImage();");
        menuItemType.setImg("images/Previous.jpg");
        menuItemType.setImgOver("images/Previous.jpg");
        menuItemType.setText("Previous");
        menuItemType.setText("Previous");
        menuItemList.add(menuItemType);
        MenuItemType menuItemTypeNext = new MenuItemType();
        menuItemTypeNext.setId("mnuNext");
        menuItemTypeNext.setType("Button");
        menuItemTypeNext.setOnClick("NextImage();");
        menuItemTypeNext.setImg("images/Next.jpg");
        menuItemTypeNext.setImgOver("images/Next.jpg");
        menuItemTypeNext.setText("Next");
        menuItemList.add(menuItemTypeNext);
    }

    private String getVmsUrl() throws SapphireException {
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(defaultdepartment, "-")[0];
        DataSet dsVMS = getQueryProcessor().getSqlDataSet("select u_vmsconfigid, url from u_vmsconfig");
        if (dsVMS == null || dsVMS.getRowCount() == 0)
            throw new SapphireException("VMS web serice url is not define in Lab Admin -> VMS Config -> VMSWebService.");
        String vmsURL = dsVMS.getString(0, "url");
        if (vmsURL == null) {
            throw new SapphireException("VMS web serice url is not define in System Admin-> Policy -> VMSWebServiceURL.");
        }
        return vmsURL;
    }

    /**
     * Description: This method is used for to set Homogeneous LOS
     *
     * @throws SapphireException
     */
    private PropertyList setHomogeneousLOS() throws SapphireException {
        PropertyList homogeneousLOS = new PropertyList();
        PropertyList plHomogeneousPolicy = getConfigurationProcessor().getPolicy(HOMOGENEOUSLOSPOLICYID, NODEID);
        String allChilds = "";
        if (plHomogeneousPolicy == null)
            throw new SapphireException("Homogeneous LOS policy is not define in System Admin-> Policy.");
        PropertyListCollection plclosmap = plHomogeneousPolicy.getCollection(POLICY_MAPPING);
        if (plclosmap != null) {
            for (int j = 0; j < plclosmap.size(); j++) {
                String propParentLOS = plclosmap.getPropertyList(j).getProperty(POLICY_PARENT_LOS);
                PropertyListCollection plChildLOS = plclosmap.getPropertyList(j).getCollection(POLICY_CHILD_LOS);
                if (plChildLOS != null) {
                    allChilds = propParentLOS;
                    for (int k = 0; k < plChildLOS.size(); k++) {
                        String childlodis = plChildLOS.getPropertyList(k).getProperty(POLICY_CHILD_LOS_ID);
                        allChilds = allChilds + ";" + childlodis;  // collect all child against one parent
                    }
                    for (int k = 0; k < plChildLOS.size(); k++) {
                        String childlodis = plChildLOS.getPropertyList(k).getProperty(POLICY_CHILD_LOS_ID);
                        homogeneousLOS.setProperty(childlodis, allChilds);  // put child los and ; separated all los of same level fall under same parent
                    }
                    homogeneousLOS.setProperty(propParentLOS, allChilds);  // put all ; separated child los with parent too

                }
            }

        }
        return homogeneousLOS;
    }
}
