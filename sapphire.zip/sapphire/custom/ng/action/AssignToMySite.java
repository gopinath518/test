package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by DMondal on 4/17/2017.
 * This action will route sample to required department of same site.
 */
public class AssignToMySite extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleid");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid");
        if (Util.isNull(sampleids)) {
            throw new SapphireException("Error:Specimen(s) can't be null.Please contact your admin.");
        }
        if (Util.isNull(u_currentmovementstep)) {
            throw new SapphireException("Error:u_currentmovementstep can't be null.Please contact your admin.");
        }
        if (Util.isNull(custodialdepartmentid)) {
            throw new SapphireException("Error:custodialdepartmentid can't be null.Please contact your admin.");
        }
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleids);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        DataSet ds = new DataSet();
        ds.addColumn("sample", DataSet.STRING);
        ds.addColumn("currentmovementstep", DataSet.STRING);
        ds.addColumn("destination", DataSet.STRING);
        String[] sampleArr = StringUtil.split(sampleids, ";");
        int incr = 0;
        for (int i = 0; i < sampleArr.length; i++) {
            incr = ds.addRow();
            ds.setValue(incr, "sample", sampleArr[i]);
            ds.setValue(incr, "currentmovementstep", u_currentmovementstep);
            ds.setValue(incr, "destination", custodialdepartmentid);
        }
        updateTrackItemSdc(ds);

        updateMvmntStep(sampleids); // added by aritra.banerjee to update SampleTestStep Mapping
    }

    /**
     * This method is used to update SampleTestStep Mapping
     *
     * @param sampleids
     */

    private void updateMvmntStep(String sampleids) throws SapphireException {

        if (!Util.isNull(sampleids)) {

            String uniqueSample = Util.getUniqueList(sampleids, ";", true);
            String replacedSamples = StringUtil.replaceAll(uniqueSample, ";", "','");
            String sql = Util.parseMessage(MultiomyxSql.GET_STPDETAILS_MOSTAINEDSLIDE, replacedSamples);
            DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);

            if (dsSql == null) {
                logger.info("Unable to execute query : "+sql);
                throw new SapphireException("Unable to execute query.");
            }

            if (dsSql.size() > 0) {
                String keyid1 = dsSql.getColumnValues("u_sampletestcodestpmapid", ";");

                if (!Util.isNull(keyid1)) {

                    if (keyid1.startsWith(";")) {
                        keyid1 = keyid1.substring(1);
                    }
                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
                    pl.setProperty("status", "Pending");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    } catch (SapphireException se) {
                        throw new SapphireException("Unable to Update SampleTestcodeStpMap status. Reason : " + se.getMessage());
                    }
                }

            }
        }

    }

    /**
     * Description : This is for update track item
     *
     * @param ds
     * @throws SapphireException
     */
    private void updateTrackItemSdc(DataSet ds) throws SapphireException {

        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        for (int i = 0; i < ds.size(); i++) {
            String tramstop = ds.getValue(i, "destination", "");
            String destination = site + "-" + tramstop;
            if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor()))
                throw new SapphireException("Error: Unable to route specimen. Department: " + destination + " does not exist");
            ds.setValue(i, "destination", destination);
        }

        try {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
            props.setProperty("u_currentmovementstep", ds.getColumnValues("currentmovementstep", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
            props.setProperty("u_currenttramstop", ds.getColumnValues("currentmovementstep", ";"));
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("custodialdepartmentid", ds.getColumnValues("destination", ";"));
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Can't update movement step in specimen");
            error += e.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
