package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.xml.crypto.Data;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by SBaitalik on 12/5/2016.
 * Description: This is used to follow microdissection rule for molecular
 */
public class CompletePreExtraction extends BaseAction {

    public static String ID = "CompletePreExtraction";
    public static String VERSIONID = "1";

    public void processAction(PropertyList properties) throws SapphireException {
        String samples = properties.getProperty("keyid1");
        String reextractbypass = properties.getProperty("reextractbypass", "N");
        String msgTemplete = "<b>Operation successful.</b>";
        DataSet dsFinalMsg = new DataSet();
        dsFinalMsg.addColumn("specimen_id", DataSet.STRING);
        dsFinalMsg.addColumn("client_specimen_id", DataSet.STRING);
        dsFinalMsg.addColumn("tramstop", DataSet.STRING);
        dsFinalMsg.addColumn("department", DataSet.STRING);
        List<String> sampleList = this.getGroupedHUSlide(samples);

        /*if (sampleList != null && !sampleList.isEmpty()) {
            for (String sampleids : sampleList) {*/
        //checkSite(sampleids);//TODO NOT REQUIRED AS MOLECULAR LAB HAS FOR ALL SITE
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), samples);
        if (storageStaus != null && storageStaus.size() > 0 && "N".equalsIgnoreCase(reextractbypass)) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        checkTumorIsNotNull(samples);
        DataSet dsAllSamples = dsHNESamples(samples);
        populateTumorCercledValueOnUSS(dsAllSamples);
        DataSet dsHNEReviewPolicy = getPreExtractionPolicy();
        DataSet dsSql = getSelectedSampelInfo(samples, dsHNEReviewPolicy);
        //DataSet dsSql = getAllHNENUnstainedSlides(sampleids);TODO NOT REQUIRED AS WE ARE ONLY COMPLETING MOLECULAR COC FOR SELECTED SAMPLE
        //CHECK ALL USS ARE IN STORAGE OR NOT
               /* storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), dsSql.getColumnValues("sampleid", ";"));
                if (storageStaus != null && storageStaus.size() > 0 && "N".equalsIgnoreCase(reextractbypass)) {
                    DataSet dsDisplayMsg = new DataSet();
                    dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
                    dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
                    for (int i = 0; i < storageStaus.size(); i++) {
                        int rowID = dsDisplayMsg.addRow();
                        dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                        dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
                    }
                    String errCodes = Util.getDisplayMessage(dsDisplayMsg);
                    throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
                }*/
                /*String sql = Util.parseMessage(MolecularSql.GET_ACCESSIONID_BY_SAMPLEID,
                        StringUtil.replaceAll(dsSql.getColumnValues("sampleid", ";"), ";", "','"));
                DataSet dsAccession = getQueryProcessor().getSqlDataSet(sql);
                if (dsAccession != null && dsAccession.size() > 1) {
                    throw new SapphireException("Unable to perform action on multiple accessions.");
                }
                String accessionid = dsAccession.getValue(0, "u_accessionid", "");
                sql = Util.parseMessage(MolecularSql.GET_MACRODISSECTION_RULE_BY_PROJECT, accessionid);
                DataSet dsMacrodissctn = getQueryProcessor().getSqlDataSet(sql);
                String macrodissctionrule = dsMacrodissctn.getValue(0, "macrodissectionrule", "0.0");*/
        //TODO SUCCESS MESSAGE PRINT
        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
        dsDisplayMsg.addColumn("client_specimen_id", DataSet.STRING);
        dsDisplayMsg.addColumn("tramstop", DataSet.STRING);
        dsDisplayMsg.addColumn("department", DataSet.STRING);
        //TODO ADDED FOR CLIENT SLIDES
                /*HashMap hm = new HashMap();
                hm.clear();
                hm.put("isclientslide", "Y");
                DataSet dsFinal = dsSql.getFilteredDataSet(hm);
                if (dsFinal != null && dsFinal.size() > 0) {
                    DataSet dsClientSlidesFinal = createClientSlideDataSet(dsFinal, dsHNEReviewPolicy, macrodissctionrule, properties);
                    updateSpecimensMovement(dsClientSlidesFinal);
                    for (int i = 0; i < dsClientSlidesFinal.size(); i++) {
                        int rowID = dsDisplayMsg.addRow();
                        dsDisplayMsg.setValue(rowID, "specimen_id", dsClientSlidesFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, ""));
                        dsDisplayMsg.setValue(rowID, "client_specimen_id", dsClientSlidesFinal.getValue(i, "clientspecimenid", ""));
                        String movetrmstop = dsClientSlidesFinal.getValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, "");
                        if (movetrmstop.contains("Molecular Extraction")) {
                            dsDisplayMsg.setValue(rowID, "tramstop", "Extraction");
                        } else {
                            dsDisplayMsg.setValue(rowID, "tramstop", movetrmstop);
                        }
                        dsDisplayMsg.setValue(rowID, "department", dsClientSlidesFinal.getValue(i, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, ""));
                    }
                }*/
                /*hm.clear();
                hm.put("isclientslide", "N");
                dsFinal = dsSql.getFilteredDataSet(hm);
                if (dsFinal != null && dsFinal.size() > 0) {
                    DataSet dsBlocksFinal = createMainDataSet(dsFinal, dsHNEReviewPolicy, macrodissctionrule, properties);
                    updateSpecimensMovement(dsBlocksFinal);
                    for (int i = 0; i < dsBlocksFinal.size(); i++) {
                        int rowID = dsDisplayMsg.addRow();
                        dsDisplayMsg.setValue(rowID, "specimen_id", dsBlocksFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, ""));
                        dsDisplayMsg.setValue(rowID, "client_specimen_id", dsBlocksFinal.getValue(i, "clientspecimenid", ""));
                        String movetrmstop = dsBlocksFinal.getValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, "");
                        if (movetrmstop.contains("Molecular Extraction")) {
                            dsDisplayMsg.setValue(rowID, "tramstop", "Extraction");
                        } else {
                            dsDisplayMsg.setValue(rowID, "tramstop", movetrmstop);
                        }
                        dsDisplayMsg.setValue(rowID, "department", dsBlocksFinal.getValue(i, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, ""));
                    }
                }
                //msgTemplete += "</table>";
                dsFinalMsg.copyRow(dsDisplayMsg, -1, 1);*/
        //TODO RELEASE 1.7.1 ONLY SLECTED SAMPLE(S) WILL BE ROUTING TO NEXT TRAMSTOP
        if (dsSql.size() > 0) {
            updateSpecimensMovement(dsSql);
            if (dsSql != null && dsSql.size() > 0) {
                for (int i = 0; i < dsSql.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsSql.getValue(i, "sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "client_specimen_id", dsSql.getValue(i, "u_clientspecimenid", ""));
                    String movetrmstop = dsSql.getValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, "");
                    if (movetrmstop.contains("Molecular Extraction")) {
                        dsDisplayMsg.setValue(rowID, "tramstop", "Extraction");
                    } else {
                        dsDisplayMsg.setValue(rowID, "tramstop", movetrmstop);
                    }
                    dsDisplayMsg.setValue(rowID, "department", dsSql.getValue(i, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, ""));
                }
            }
        }
        /*    }
        }*/
        if (dsDisplayMsg.size() > 0) {
            msgTemplete += Util.getDisplayMessage(dsDisplayMsg);
        }
        properties.setProperty("msg", msgTemplete);
        //throw new SapphireException("Work In-Progress");

    }

    /**
     * Description: This is to get Exraction type details from the policy
     *
     * @return dsPolicy
     * @throws SapphireException
     */
    private DataSet getPreExtractionPolicy() throws SapphireException {
        DataSet dsPloicy = new DataSet();
        int incr = 0;
        dsPloicy.addColumn("type", DataSet.STRING);
        dsPloicy.addColumn("methodology", DataSet.STRING);
        dsPloicy.addColumn("currentmovementstep", DataSet.STRING);
        dsPloicy.addColumn("currenttramstop", DataSet.STRING);
        dsPloicy.addColumn("nextmovementstep", DataSet.STRING);
        dsPloicy.addColumn("nexttramstop", DataSet.STRING);
        dsPloicy.addColumn("custodialdept", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("HNEReviewCompletePolicy",
                "PreExtractionComplete");
        PropertyListCollection plcRoutingrules = plMicroPolicy.getCollection("routingrules");
        for (int i = 0; i < plcRoutingrules.size(); i++) {
            incr = dsPloicy.addRow();
            PropertyListCollection plcConditions = plcRoutingrules.getPropertyList(i).getCollection("conditions");
            PropertyListCollection plcColumnvaluepair = plcConditions.getPropertyList(0)
                    .getCollection("columnvaluepair");
            for (int j = 0; j < plcColumnvaluepair.size(); j++) {
                String column = plcColumnvaluepair.getPropertyList(j).getProperty("column");
                String value = plcColumnvaluepair.getPropertyList(j).getProperty("value");
                if (column.equalsIgnoreCase("u_type")) {
                    dsPloicy.setValue(incr, "type", value);
                } else {
                    dsPloicy.setValue(incr, "methodology", value);
                }
            }
            String currentmovementstep = plcConditions.getPropertyList(0).getProperty("currentmovementstep");
            String currenttramstop = plcConditions.getPropertyList(0).getProperty("currenttram");
            String nextmovementstep = plcConditions.getPropertyList(0).getProperty("nextmovementstep");
            String nexttramstop = plcConditions.getPropertyList(0).getProperty("nexttramstop");
            String custodiandept = plcConditions.getPropertyList(0).getProperty("custodiandept");

            dsPloicy.setValue(incr, "currentmovementstep", currentmovementstep);
            dsPloicy.setValue(incr, "currenttramstop", currenttramstop);
            dsPloicy.setValue(incr, "nextmovementstep", nextmovementstep);
            dsPloicy.setValue(incr, "nexttramstop", nexttramstop);
            dsPloicy.setValue(incr, "custodialdept", custodiandept);
        }
        return dsPloicy;
    }

    /**
     * Description: This is to get all H&E and Unstained slieds for a accession
     *
     * @param sampleids
     * @return dsReturn
     * @throws SapphireException
     */
    private DataSet getAllHNENUnstainedSlides(String sampleids) throws SapphireException {
        if (Util.isNull(sampleids))
            throw new SapphireException("No sampleids found");
        DataSet dsReturn = null;
        //String inputSamples[] = sampleids.split(";");
        String sqll = Util.parseMessage(MolecularSql.MOL_DEST_SAMPLE_ONLY, StringUtil.replaceAll(sampleids, ";", "','"));
        /*StringBuilder sqlHNEWithParent = new StringBuilder();
        sqlHNEWithParent.append("select destsampleid from s_samplemap where destsampleid in('");
        sqlHNEWithParent.append(StringUtil.replaceAll(sampleids, ";", "','"));
        sqlHNEWithParent.append("')");
        DataSet dsHNEWithParent = getQueryProcessor().getSqlDataSet(sqlHNEWithParent.toString());*/
        DataSet dsHNEWithParent = getQueryProcessor().getSqlDataSet(sqll);
        if (dsHNEWithParent == null)
            throw new SapphireException("Error: Unable to perform query in database\n" + sqll.toString());
        if (dsHNEWithParent.size() > 0) {
            String sb = Util.parseMessage(MolecularSql.GET_USS_FROM_BLOCK,
                    StringUtil.replaceAll(dsHNEWithParent.getColumnValues("destsampleid", ";"), ";", "','"));
            dsReturn = getQueryProcessor().getSqlDataSet(sb.toString());
            if (dsReturn == null)
                throw new SapphireException("Error: Unable to perform query in database\n" + sb);
            //TODO MAY BE THERE COULD BE CHANCE TO SELECT BLOCK SAMPLE AND CLIENT SLIDE AS WELL
            /*if (dsReturn.size() == 0)
                throw new SapphireException("No parent found for H&E samples\nSQL: " + sb);*/

            // Find HNE samples that does not have entry in samplemap and add
            // them to the DataSet
            if (!dsReturn.isValidColumn("isclientslide")) {
                dsReturn.addColumnValues("isclientslide", DataSet.STRING, StringUtil.repeat("N", dsReturn.size(), ";"), ";");
            }

        }
        String sqlCslides = Util.parseMessage(MolecularSql.GET_USS_FOR_CLIENTSLIDE, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsClientSlides = getQueryProcessor().getSqlDataSet(sqlCslides);
        if (dsClientSlides.size() > 0) {
            if (dsReturn == null) {
                //TODO ADDED FOR CLIENT SLIDES
                dsReturn = new DataSet();
                dsReturn.addColumn("sampleid", DataSet.STRING);
                dsReturn.addColumn("u_type", DataSet.STRING);
                dsReturn.addColumn("u_currentmovementstep", DataSet.STRING);
                dsReturn.addColumn("parentsampleid", DataSet.STRING);
                dsReturn.addColumn("u_accessionid", DataSet.STRING);
                dsReturn.addColumn("u_clientspecimenid", DataSet.STRING);
                dsReturn.addColumn("collectiondt", DataSet.STRING);
                dsReturn.addColumn("u_tumorcircled", DataSet.STRING);
                dsReturn.addColumn("isclientslide", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("sampleid")) {
                dsReturn.addColumn("sampleid", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("u_type")) {
                dsReturn.addColumn("u_type", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("u_currentmovementstep")) {
                dsReturn.addColumn("u_currentmovementstep", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("parentsampleid")) {
                dsReturn.addColumn("parentsampleid", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("u_accessionid")) {
                dsReturn.addColumn("u_accessionid", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("u_clientspecimenid")) {
                dsReturn.addColumn("u_clientspecimenid", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("collectiondt")) {
                dsReturn.addColumn("collectiondt", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("u_tumorcircled")) {
                dsReturn.addColumn("u_tumorcircled", DataSet.STRING);
            }
            if (!dsReturn.isValidColumn("isclientslide")) {
                dsReturn.addColumn("isclientslide", DataSet.STRING);
            }
            String sqlHNE = Util.parseMessage(MolecularSql.GET_HNE_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsHneInfo = getQueryProcessor().getSqlDataSet(sqlHNE);

            String sql = Util.parseMessage(MolecularSql.GET_ALL_HNE_BY_ACCESSIONID, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsAllClntSlide = getQueryProcessor().getSqlDataSet(sql);
            for (int i = 0; i < dsHneInfo.size(); i++) {
                String accessionid = dsHneInfo.getValue(i, "u_accessionid", "");
                String u_clientspecimenid = dsHneInfo.getValue(i, "u_clientspecimenid", "");
                String collectiondt = dsHneInfo.getValue(i, "collectiondt", "");
                String u_tumorcircled = dsHneInfo.getValue(i, "u_tumorcircled", "");
                String u_type = dsHneInfo.getValue(i, "u_type", "");
                if (Util.isNull(u_tumorcircled) && ("CH".equalsIgnoreCase(u_type) || "H".equalsIgnoreCase(u_type) || "SH".equalsIgnoreCase(u_type))) {
                    throw new SapphireException("Please review H&E Batch first.");
                }
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("u_accessionid", accessionid);
                hm.put("u_clientspecimenid", u_clientspecimenid);
                //hm.put("collectiondt", collectiondt);
                DataSet dsFilter = dsAllClntSlide.getFilteredDataSet(hm);
                if (dsFilter != null && dsFilter.size() > 0) {
                    for (int j = 0; j < dsFilter.size(); j++) {
                        int rowID = dsReturn.addRow();
                        dsReturn.setValue(rowID, "sampleid", dsFilter.getValue(j, "sampleid", ""));
                        dsReturn.setValue(rowID, "u_type", dsFilter.getValue(j, "u_type", ""));
                        dsReturn.setValue(rowID, "u_currentmovementstep", dsFilter.getValue(j, "u_currentmovementstep", ""));
                        dsReturn.setValue(rowID, "parentsampleid", dsFilter.getValue(j, "parentsampleid", ""));
                        dsReturn.setValue(rowID, "u_accessionid", dsFilter.getValue(j, "u_accessionid", ""));
                        dsReturn.setValue(rowID, "u_clientspecimenid", dsFilter.getValue(j, "u_clientspecimenid", ""));
                        dsReturn.setValue(rowID, "collectiondt", dsFilter.getValue(j, "collectiondt", ""));
                        dsReturn.setValue(rowID, "u_tumorcircled", u_tumorcircled);
                        dsReturn.setValue(rowID, "isclientslide", "Y");
                    }
                }

            }

        }
        return dsReturn;
    }

    private DataSet getSelectedSampelInfo(String sampleids, DataSet dsPolicy) throws SapphireException {
        if (Util.isNull(sampleids))
            throw new SapphireException("No specimen(s) found");
        DataSet dsReturn = null;
        String sb = Util.parseMessage(MolecularSql.GET_ALL_SAMPLE, StringUtil.replaceAll(sampleids, ";", "','"));
        dsReturn = getQueryProcessor().getSqlDataSet(sb.toString());
        if (!dsReturn.isValidColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP))
            dsReturn.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
        if (!dsReturn.isValidColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP))
            dsReturn.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
        if (!dsReturn.isValidColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT))
            dsReturn.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);

        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));
        if (dsReturn.size() > 0) {
            for (int i = 0; i < dsReturn.size(); i++) {
                String u_tumorcircled = dsReturn.getValue(i, "u_tumorcircled", "");
                String macrodissectionrule = dsReturn.getValue(i, "macrodissectionrule", "0.0");
                String u_sampleinformation = dsReturn.getValue(i, "u_sampleinformation", "");
                String u_type = dsReturn.getValue(i, "u_type", "");
                String methodology = dsReturn.getValue(i, "methodology", "");
                double tumorcircled = Double.parseDouble(u_tumorcircled);
                double macrodisecrule = Double.parseDouble(macrodissectionrule);
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("type", u_type);
                hm.put("methodology", methodology);
                DataSet dsfilter = dsPolicy.getFilteredDataSet(hm);
                if (dsfilter.size() == 0)
                    throw new SapphireException("No movement step found into PreExtractionComplete policy.");
                String nextmovementstep = dsfilter.getValue(0, "nextmovementstep", "");
                String nexttramstop = dsfilter.getValue(0, "nexttramstop", "");
                String currenttramstop = dsfilter.getValue(0, "currenttramstop", "");
                String currentmovementstep = dsfilter.getValue(0, "currentmovementstep", "");
                String custodialdept = dsfilter.getValue(0, "custodialdept", "");
                if ("Tumor/Normal".equalsIgnoreCase(u_sampleinformation)) {
                    dsReturn.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP, nextmovementstep);
                    dsReturn.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, nexttramstop);
                    dsReturn.setValue(i, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, deptValidate(departmentSite + "-" + custodialdept));
                } else if (tumorcircled < macrodisecrule) {
                    dsReturn.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP, nextmovementstep);
                    dsReturn.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, nexttramstop);
                    dsReturn.setValue(i, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, deptValidate(departmentSite + "-" + custodialdept));
                } else {
                    dsReturn.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP, currentmovementstep);
                    dsReturn.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, currenttramstop);
                    dsReturn.setValue(i, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, deptValidate(departmentSite + "-" + custodialdept));
                }
            }
        }
        return dsReturn;
    }

    /**
     * Description: This is used to build a dataset to manupulate rule for scanned specimens.
     *
     * @param dsInput
     * @param dsPolicy
     * @param macrodissectionrule
     * @param properties
     * @return dsFinal
     * @throws SapphireException
     */

    private DataSet createMainDataSet(DataSet dsInput, DataSet dsPolicy, String macrodissectionrule, PropertyList properties) throws SapphireException {
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_TYPE, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_CURRENTTRAMSTOP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_CURRENTMOVEMENTSTEP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_NEXT_MOVEMENTSTEP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_NEXT_TRAMSTOP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_HNE_REV, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_REV_BY, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_REV_DT, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_PARENTSAMPLE, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
        dsFinal.addColumn("clientspecimenid", DataSet.STRING);

        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));

        String sqlType = Util.parseMessage(MolecularSql.GET_METHODOLOGY_BY_SAMPLEIDS_MOL,
                StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "','"));
        DataSet dsSlidesInfo = getQueryProcessor().getSqlDataSet(sqlType);
        if (dsSlidesInfo == null || dsSlidesInfo.size() == 0) {
            throw new SapphireException("No Testcode(s) are associated with the sample(s): "
                    + StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "', '"));
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsSlidesInfo.size(); i++) {
            String s_sampleid = dsSlidesInfo.getValue(i, "s_sampleid", "");
            String methodology = dsSlidesInfo.getValue(i, "methodology", "");
            String u_type = dsSlidesInfo.getValue(i, "u_type", "");
            String u_tumorcircled = dsSlidesInfo.getValue(i, "u_tumorcircled", "");
            String parentsampleid = dsSlidesInfo.getValue(i, "parentsampleid", "");
            String lvtestcodeid = dsSlidesInfo.getValue(i, "lvtestcodeid", "");
            String clientspecimenid = dsSlidesInfo.getValue(i, "u_clientspecimenid", "");
            hm.clear();
            hm.put("type", u_type);
            hm.put("methodology", methodology);
            DataSet dsfilter = dsPolicy.getFilteredDataSet(hm);
            if (dsfilter != null && dsfilter.size() > 0) {
                int rowID = dsFinal.addRow();
                dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, s_sampleid);
                dsFinal.setValue(rowID, DATASET_PROPERTY_TYPE, u_type);
                dsFinal.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsfilter.getValue(0, "methodology", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTTRAMSTOP, dsfilter.getValue(0, "currenttramstop", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT,
                        deptValidate(departmentSite + "-" + dsfilter.getValue(0, "custodialdept", "")));
                dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTMOVEMENTSTEP,
                        dsfilter.getValue(0, "currentmovementstep", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_MOVEMENTSTEP,
                        dsfilter.getValue(0, "nextmovementstep", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_TRAMSTOP, dsfilter.getValue(0, "nexttramstop", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_HNE_REV, "");
                dsFinal.setValue(rowID, DATASET_PROPERTY_REV_DT, "");
                dsFinal.setValue(rowID, DATASET_PROPERTY_REV_BY, "");
                dsFinal.setValue(rowID, DATASET_PROPERTY_TUMORCIRCLED, u_tumorcircled);
                dsFinal.setValue(rowID, DATASET_PROPERTY_PARENTSAMPLE, parentsampleid);
                dsFinal.setValue(rowID, DATASET_PROPERTY_LVTESTCODEID, lvtestcodeid);
                dsFinal.setValue(rowID, "clientspecimenid", clientspecimenid);
            }
        }
        //SORT BY PARENT SAMPLE
        DataSet dsFinalFinal = new DataSet();
        dsFinalFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
        dsFinalFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
        dsFinalFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
        if (dsFinal != null && dsFinal.size() > 0) {
            String parentsampls = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_PARENTSAMPLE, ";"), ";",
                    true);
            String arryParent[] = StringUtil.split(parentsampls, ";");
            for (int i = 0; i < arryParent.length; i++) {
                double dmacrodissectionrule = 0.0, u_tumorcircled = 0.0;
                String tumorcircledval = "";
                HashMap hmp = new HashMap();
                //NORMAL H&E
                hmp.clear();
                hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
                hmp.put(DATASET_PROPERTY_TYPE, "H");
                // hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
                DataSet dsHNEFilter = dsFinal.getFilteredDataSet(hmp);
                if (dsHNEFilter != null && dsHNEFilter.size() > 0) {
                    for (int j = 0; j < dsHNEFilter.size(); j++) {
                        // int rowId = dsFinal.g
                        int RowID = dsFinalFinal.addRow();
                        tumorcircledval = dsHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "N");
                        if (!"N".equalsIgnoreCase(tumorcircledval)) {
                            u_tumorcircled = Double
                                    .parseDouble(dsHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
                            dmacrodissectionrule = Double.parseDouble(macrodissectionrule);
                            if (u_tumorcircled < dmacrodissectionrule) {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                            } else {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                            }
                        } else {
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                    dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                    dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                    dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                        }
                    }
                } else {
                    for (int j = 0; j < dsHNEFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                    }
                }
                //SHARE H&E
                //SHARE H&E
                hmp.clear();
                hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
                hmp.put(DATASET_PROPERTY_TYPE, "SH");
                // hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
                DataSet dsShareHNEFilter = dsFinal.getFilteredDataSet(hmp);
                if (dsShareHNEFilter != null && dsShareHNEFilter.size() > 0) {
                    for (int j = 0; j < dsShareHNEFilter.size(); j++) {
                        // int rowId = dsFinal.g
                        int RowID = dsFinalFinal.addRow();
                        tumorcircledval = dsShareHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "N");
                        if (!"N".equalsIgnoreCase(tumorcircledval)) {
                            u_tumorcircled = Double
                                    .parseDouble(dsShareHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
                            dmacrodissectionrule = Double.parseDouble(macrodissectionrule);
                            if (u_tumorcircled < dmacrodissectionrule) {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsShareHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsShareHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsShareHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                            } else {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsShareHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsShareHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsShareHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                            }
                        } else {
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                    dsShareHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                    dsShareHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                    dsShareHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                        }
                    }
                } else {
                    for (int j = 0; j < dsShareHNEFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                dsShareHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                dsShareHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                dsShareHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                    }
                }
                //UNSTAINED
                hmp.clear();
                hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
                hmp.put(DATASET_PROPERTY_TYPE, "U");
                // hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
                DataSet dsUnstainedFilter = dsFinal.getFilteredDataSet(hmp);
                if (dsUnstainedFilter != null && dsUnstainedFilter.size() > 0) {
                    for (int j = 0; j < dsUnstainedFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        if (!"N".equalsIgnoreCase(tumorcircledval)) {
                            if (u_tumorcircled < dmacrodissectionrule) {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_TRAMSTOP, ""));
                            } else {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                            }
                        } else {
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                    dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                    dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                    dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                        }
                    }
                } else {
                    for (int j = 0; j < dsUnstainedFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                    }
                }
                //CLIENT HNE
                hmp.clear();
                hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
                hmp.put(DATASET_PROPERTY_TYPE, "CH");
                // hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
                DataSet dsCHNEFilter = dsFinal.getFilteredDataSet(hmp);
                if (dsCHNEFilter != null && dsCHNEFilter.size() > 0) {
                    for (int j = 0; j < dsCHNEFilter.size(); j++) {
                        // int rowId = dsFinal.g
                        int RowID = dsFinalFinal.addRow();
                        tumorcircledval = dsCHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "N");
                        if (!"N".equalsIgnoreCase(tumorcircledval)) {
                            u_tumorcircled = Double
                                    .parseDouble(dsCHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
                            dmacrodissectionrule = Double.parseDouble(macrodissectionrule);
                            if (u_tumorcircled < dmacrodissectionrule) {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsCHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsCHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                            } else {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                            }
                        } else {
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                    dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                    dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                    dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                        }
                    }
                } else {
                    for (int j = 0; j < dsCHNEFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                    }
                }

                //CLIENT UNSTAINED
                hmp.clear();
                hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
                hmp.put(DATASET_PROPERTY_TYPE, "CU");
                // hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
                DataSet dsCUnstainedFilter = dsFinal.getFilteredDataSet(hmp);
                if (dsCUnstainedFilter != null && dsCUnstainedFilter.size() > 0) {
                    for (int j = 0; j < dsCUnstainedFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        if (!"N".equalsIgnoreCase(tumorcircledval)) {
                            if (u_tumorcircled < dmacrodissectionrule) {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_TRAMSTOP, ""));
                            } else {
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                        dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                        dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                                dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                        dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                            }
                        } else {
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                    dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                    dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                            dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                    dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                        }
                    }
                } else {
                    for (int j = 0; j < dsCUnstainedFilter.size(); j++) {
                        int RowID = dsFinalFinal.addRow();
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
                                dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                                dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                        dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                                dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                    }
                }

                hmp.clear();
                hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
                hmp.put(DATASET_PROPERTY_TYPE, "");
                DataSet dsLiquidFilter = dsFinal.getFilteredDataSet(hmp);
                if (dsLiquidFilter != null && dsLiquidFilter.size() > 0) {
                    dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                            dsLiquidFilter.getValue(0, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                    dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                            dsLiquidFilter.getValue(0, DATASET_PROPERTY_NEXT_TRAMSTOP, ""));
                }
            }
        }
        if (dsFinal.size() == dsFinalFinal.size()) {
            for (int i = 0; i < dsFinal.size(); i++) {
                String sampleid = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
                HashMap hmo = new HashMap();
                hmo.clear();
                hmo.put(DATASET_PROPERTY_SAMPLEID, sampleid);
                DataSet dsFilter = dsFinalFinal.getFilteredDataSet(hmo);

                dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                        dsFilter.getValue(0, DATASET_PROPERTY_FINAL_MOMENTSTEP, ""));
                dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                        dsFilter.getValue(0, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, ""));
            }
        } else {
            for (int i = 0; i < dsFinal.size(); i++) {
                dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP,
                        dsFinal.getValue(i, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
                        dsFinal.getValue(i, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
            }
        }
        return dsFinal;
    }

    /**
     * Description: This is used to takeing care for client slides
     *
     * @param dsInput
     * @param dsPolicy
     * @param microdissectionrule
     * @param properties
     * @return dsFinal
     * @throws SapphireException
     */
    private DataSet createClientSlideDataSet(DataSet dsInput, DataSet dsPolicy, String microdissectionrule, PropertyList properties) throws SapphireException {
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_TYPE, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_CURRENTTRAMSTOP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_CURRENTMOVEMENTSTEP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_NEXT_MOVEMENTSTEP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_NEXT_TRAMSTOP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_HNE_REV, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_REV_BY, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_REV_DT, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_PARENTSAMPLE, DataSet.STRING);
        dsFinal.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
        dsFinal.addColumn("accessionid", DataSet.STRING);
        dsFinal.addColumn("clientspecimenid", DataSet.STRING);


        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));

        String sqlType = Util.parseMessage(MolecularSql.GET_METHODOLOGY_BY_SAMPLEIDS_MOL,
                StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "','"));
        DataSet dsSlidesInfo = getQueryProcessor().getSqlDataSet(sqlType);
        if (dsSlidesInfo == null || dsSlidesInfo.size() == 0) {
            throw new SapphireException("No Testcode(s) are associated with the sample(s): "
                    + StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "', '"));
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsSlidesInfo.size(); i++) {
            String s_sampleid = dsSlidesInfo.getValue(i, "s_sampleid", "");
            String methodology = dsSlidesInfo.getValue(i, "methodology", "");
            String u_type = dsSlidesInfo.getValue(i, "u_type", "");
            String u_tumorcircled = dsSlidesInfo.getValue(i, "u_tumorcircled", "");
            String parentsampleid = dsSlidesInfo.getValue(i, "parentsampleid", "");
            String lvtestcodeid = dsSlidesInfo.getValue(i, "lvtestcodeid", "");
            String u_accessionid = dsSlidesInfo.getValue(i, "u_accessionid", "");
            String u_clientspecimenid = dsSlidesInfo.getValue(i, "u_clientspecimenid", "");
            hm.clear();
            hm.put("type", u_type);
            hm.put("methodology", methodology);
            DataSet dsfilter = dsPolicy.getFilteredDataSet(hm);
            if (dsfilter != null && dsfilter.size() > 0) {
                int rowID = dsFinal.addRow();
                dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, s_sampleid);
                dsFinal.setValue(rowID, DATASET_PROPERTY_TYPE, u_type);
                dsFinal.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsfilter.getValue(0, "methodology", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTTRAMSTOP, dsfilter.getValue(0, "currenttramstop", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, deptValidate(departmentSite + "-" + dsfilter.getValue(0, "custodialdept", "")));
                dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, dsfilter.getValue(0, "currentmovementstep", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, dsfilter.getValue(0, "nextmovementstep", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_TRAMSTOP, dsfilter.getValue(0, "nexttramstop", ""));
                dsFinal.setValue(rowID, DATASET_PROPERTY_HNE_REV, "");
                dsFinal.setValue(rowID, DATASET_PROPERTY_REV_DT, "");
                dsFinal.setValue(rowID, DATASET_PROPERTY_REV_BY, "");
                dsFinal.setValue(rowID, DATASET_PROPERTY_TUMORCIRCLED, u_tumorcircled);
                dsFinal.setValue(rowID, DATASET_PROPERTY_PARENTSAMPLE, parentsampleid);
                dsFinal.setValue(rowID, DATASET_PROPERTY_LVTESTCODEID, lvtestcodeid);
                dsFinal.setValue(rowID, "accessionid", u_accessionid);
                dsFinal.setValue(rowID, "clientspecimenid", u_clientspecimenid);
                //dsFinal.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTSTEP, dsfilter.getValue(0, "currentmovementstep", ""));
                //dsFinal.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, dsfilter.getValue(0, "currenttramstop", ""));
            }

        }
        if (dsFinal != null && dsFinal.size() > 0) {
            hm.clear();
            hm.put(DATASET_PROPERTY_TYPE, "CH");
            DataSet dsFilter = dsFinal.getFilteredDataSet(hm);
            if (dsFilter.size() > 0) {
                hm.clear();
                hm.put(DATASET_PROPERTY_TUMORCIRCLED, null);
                DataSet dsTumorFilter = dsFilter.getFilteredDataSet(hm);
                if (dsTumorFilter.size() > 0) {
                    throw new SapphireException("Tumor Circled can not be blank. Please complete H&E review for specimen(s): "
                            + dsTumorFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ","));
                }
                //String tumorcircled = dsFilter.getValue(0, DATASET_PROPERTY_TUMORCIRCLED, "");
                //dsFinal.addColumnValues(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING, StringUtil.repeat(tumorcircled, dsFinal.size(), ";"), ";");
            }
            DataSet dsFinalMov = new DataSet();
            dsFinalMov.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsFinalMov.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
            dsFinalMov.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
            dsFinal.sort("accessionid,clientspecimenid");
            ArrayList<DataSet> dsFinalArr = dsFinal.getGroupedDataSets("accessionid,clientspecimenid");
            for (int i = 0; i < dsFinalArr.size(); i++) {
                DataSet dsEach = dsFinalArr.get(i);
                hm.clear();
                hm.put(DATASET_PROPERTY_TYPE, "CH");
                DataSet dsHNEFilter = dsEach.getFilteredDataSet(hm);
                if (dsHNEFilter.size() > 0) {
                    hm.clear();
                    hm.put(DATASET_PROPERTY_TUMORCIRCLED, null);
                    DataSet dsTumorFilter = dsHNEFilter.getFilteredDataSet(hm);
                    if (dsTumorFilter.size() > 0) {
                        throw new SapphireException("Tumor Circled can not be blank. Please complete H&E review for specimen(s): "
                                + dsTumorFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ","));
                    }
                    String tumorcircled = dsHNEFilter.getValue(0, DATASET_PROPERTY_TUMORCIRCLED, "");
                    dsEach.addColumnValues(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING, StringUtil.repeat(tumorcircled, dsEach.size(), ";"), ";");
                }
                for (int j = 0; j < dsEach.size(); j++) {
                    double u_tumorcircled = Double.parseDouble(dsEach.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
                    double u_microdissectionrule = Double.parseDouble(microdissectionrule);
                    int rowID = dsFinalMov.addRow();
                    if (u_tumorcircled < u_microdissectionrule) {

                        dsFinalMov.setValue(rowID, DATASET_PROPERTY_SAMPLEID, dsEach.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTSTEP, dsEach.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                        dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, dsEach.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
                    } else {
                        dsFinalMov.setValue(rowID, DATASET_PROPERTY_SAMPLEID, dsEach.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
                        dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTSTEP, dsEach.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
                        dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, dsEach.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
                    }
                }
            }
            if (dsFinal.size() == dsFinalMov.size()) {
                for (int i = 0; i < dsFinal.size(); i++) {
                    String sampleid = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
                    hm.clear();
                    hm.put(DATASET_PROPERTY_SAMPLEID, sampleid);
                    DataSet dsFil = dsFinalMov.getFilteredDataSet(hm);
                    if (dsFil.size() > 0) {
                        String finalmovementtramstop = dsFil.getValue(0, DATASET_PROPERTY_FINAL_MOMENTSTEP, "");
                        String finalmovestep = dsFil.getValue(0, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, "");

                        dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP, finalmovementtramstop);
                        dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, finalmovestep);
                    }
                }
            }

        }

        return dsFinal;
    }

    /**
     * Description: This is used to validate department
     *
     * @param siteDept
     * @return department
     * @throws SapphireException
     */
    private String deptValidate(String siteDept) throws SapphireException {
        String site = siteDept.substring(0, siteDept.indexOf("-"));
        String targetDept = siteDept.substring(siteDept.indexOf("-") + 1, siteDept.length());
        String department = "";
        String dept = "select departmentid from department where departmentid='" + siteDept + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor().translate(targetDept + " Department not found in site " + site);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
        }
        return department;
    }

    /**
     * Description: This is to validate Tumor circled for H&E specimen
     *
     * @param sampleid
     * @return null
     * @throws SapphireException
     */
    private void checkTumorIsNotNull(String sampleid) throws SapphireException {
        DataSet dsError = new DataSet();
        dsError.addColumn("s_sampleid", DataSet.STRING);
        dsError.addColumn("tumorcircled", DataSet.STRING);
        //String sql = Util.parseMessage(MolecularSql.GET_TUMOR_CIRCLE_VALUE_BY_SAMPLEID,
        String sql = Util.parseMessage(MolecularSql.GET_TUMOR_CIRCLE_VAL_BY_CHILD,
                StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsTumorDetails = getQueryProcessor().getSqlDataSet(sql);

        HashMap hm = new HashMap();
        hm.clear();
        hm.put("u_tumorcircled", null);
        DataSet dsFilter = dsTumorDetails.getFilteredDataSet(hm);
        /*String parentsampleid = dsFilter.getColumnValues("u_rootsample", ";");
        sql = Util.parseMessage(MolecularSql.GET_TESTCODE_BY_SAMPLEID,
                StringUtil.replaceAll(parentsampleid, ";", "','"));
        DataSet dsTestcodes = getQueryProcessor().getSqlDataSet(sql);*/
        if (dsFilter != null && dsFilter.size() > 0 /*&& dsTestcodes.size() > 0*/) {//TODO CHNAGED FOR ALL MOLECULAR TESTCODES
            for (int i = 0; i < dsFilter.size(); i++) {
                String u_type = dsFilter.getValue(i, "u_type", "");
                //if (!"SH".equalsIgnoreCase(u_type)) {
                int rowId = dsError.addRow();
                dsError.setValue(rowId, "s_sampleid", dsFilter.getValue(i, "s_sampleid", ""));
                dsError.setValue(rowId, "u_tumorcircled", dsFilter.getValue(i, "s_sampleid", ""));
                //}
                //TODO CHNAGED FOR ALL MOLECULAR TESTCODES
            }
        }
        if (dsError != null && dsError.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("u_tumorcircled", DataSet.STRING);
            for (int i = 0; i < dsError.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", dsError.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "u_tumorcircled", dsError.getValue(i, "u_tumorcircled", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Total Tumor Percentage is not entered.Please complete H&E Review batch." + errCodes);
        }
    }

    /**
     * Description: This is to validate site
     *
     * @param sampleids
     * @return null
     * @throws SapphireException
     */
    private void checkSite(String sampleids) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_MOLSUBMETHODOLOGY_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsMethodology = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        hm.put("methodology", "Molecular");
        DataSet dsFiletrMethodology = dsMethodology.getFilteredDataSet(hm);
        String methodology = Util.getUniqueList(dsFiletrMethodology.getColumnValues("methodology", ";"), ";", true);
        String currentDepartment = connectionInfo.getDefaultDepartment();
        String site = currentDepartment.substring(0, currentDepartment.indexOf("-"));
        DataSet dsLab = getLabPolicy();
        hm.clear();
        hm.put("methodology", methodology);
        hm.put("siteinitials", site);
        DataSet dsLabFilter = dsLab.getFilteredDataSet(hm);
        if (dsLabFilter == null || dsLabFilter.size() == 0) {
            throw new SapphireException("<b>There is No Molecular Lab in Aliso Viejo, you can't proceed.\nPlease route the specimen(s) via Logistics.</b>");
        }
    }

    /**
     * Description: This is to take lab details from policy
     *
     * @return null
     * @throws SapphireException
     */
    private DataSet getLabPolicy() throws SapphireException {
        DataSet dsLab = new DataSet();
        dsLab.addColumn("methodology", DataSet.STRING);
        dsLab.addColumn("department", DataSet.STRING);
        dsLab.addColumn("fullsitename", DataSet.STRING);
        dsLab.addColumn("siteinitials", DataSet.STRING);
        PropertyList plLabPolicy = getConfigurationProcessor().getPolicy("LabLocationPolicy", "LabDetails");
        if (plLabPolicy == null) {
            throw new SapphireException("Performing Lab is not created into Policy: LabLocationPolicy > LabDetails");
        }
        PropertyListCollection plcLabDetailsCollection = plLabPolicy.getCollection("labdetails");
        if (plcLabDetailsCollection == null || plcLabDetailsCollection.size() == 0) {
            throw new SapphireException("Performing Lab is not defined into Policy: LabLocationPolicy > LabDetails");
        }
        if (plcLabDetailsCollection.size() > 0) {
            for (int i = 0; i < plcLabDetailsCollection.size(); i++) {
                String methodology = plcLabDetailsCollection.getPropertyList(i).getProperty("methodology");
                String department = plcLabDetailsCollection.getPropertyList(i).getProperty("department");
                String fullsitename = plcLabDetailsCollection.getPropertyList(i).getProperty("fullsitename");
                String siteinitials = plcLabDetailsCollection.getPropertyList(i).getProperty("siteinitials");
                int rowID = dsLab.addRow();
                dsLab.setValue(rowID, "methodology", methodology);
                dsLab.setValue(rowID, "department", department);
                dsLab.setValue(rowID, "fullsitename", fullsitename);
                dsLab.setValue(rowID, "siteinitials", siteinitials);
            }
        }
        return dsLab;
    }

    /**
     * Description: This is used to update movement step for the specimens
     *
     * @param dsFinal
     * @return null
     * @throws SapphireException
     */
    private void updateSpecimensMovement(DataSet dsFinal) throws SapphireException {
        this.modifyDSForUSSOnly(dsFinal);
        this.sendToAssayForBiocartis(dsFinal);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currentmovementstep", dsFinal.getColumnValues(DATASET_PROPERTY_FINAL_MOMENTSTEP, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit sample");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        prop.clear();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
        prop.setProperty("u_currenttramstop", dsFinal.getColumnValues(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, ";"));
        prop.setProperty("custodialuserid", StringUtil.repeat("(null)", dsFinal.size(), ";"));
        prop.setProperty("custodytakendt", StringUtil.repeat("n", dsFinal.size(), ";"));
        prop.setProperty("custodialdepartmentid", dsFinal.getColumnValues(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    private void sendToAssayForBiocartis(DataSet dsFinal) {
        // TODO Auto-generated method stub
        String parentSampleId = Util.getUniqueList(dsFinal.getColumnValues("parentsampleid", ";"), ";", true);
        String query = Util.parseMessage(MolecularSql.GET_MOLSUBMETHODOLOGY_BY_SAMPLEID, StringUtil.replaceAll(parentSampleId, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(query);
        if (ds != null && ds.getRowCount() > 0 && "Biocartis".equalsIgnoreCase(ds.getValue(0, "molecularsubmethodology", ""))) {
            for (int i = 0; i < dsFinal.getRowCount(); i++) {
                dsFinal.setValue(i, "finalmovementtramstop", "BioAssaySetup");
                dsFinal.setValue(i, "finalmovementstep", "BioAssaySetup");
            }
        }
    }

    /***********************************************
     * Method to modify dataset for only unstained slide
     * @param dsFinal
     ***********************************************/
    private void modifyDSForUSSOnly(DataSet dsFinal) {
        // TODO Auto-generated method stub
        HashMap<String, Object> hm = new HashMap<>();
        HashMap<String, Object> chm = new HashMap<>();
        if (dsFinal != null && dsFinal.getRowCount() > 0) {
            hm.put("u_type", "H");
            chm.put("u_type", "CH");
            DataSet chkHEDS = dsFinal.getFilteredDataSet(hm);
            DataSet chkCHEDS = dsFinal.getFilteredDataSet(chm);
            hm.clear();
            chm.clear();
            if (chkHEDS != null && chkHEDS.getRowCount() == 0
                    && chkCHEDS != null && chkCHEDS.getRowCount() == 0) {
                String sql = Util.parseMessage(MolecularSql.GET_TCIRCLED_DATA, dsFinal.getValue(0, "sampleid", ""), dsFinal.getValue(0, "clientspecimenid", ""));
                DataSet ds = getQueryProcessor().getSqlDataSet(sql);
                if (ds != null && ds.getRowCount() > 0) {
                    String query = Util.parseMessage(MolecularSql.GET_MACRODISSECTION_RULE_BY_PROJECT, ds.getValue(0, "u_accessionid", ""));
                    DataSet rs = getQueryProcessor().getSqlDataSet(query);
                    if (rs != null && rs.getRowCount() > 0) {
                        double macroDissectRule = rs.getDouble(0, "macrodissectionrule", 0.0d);
                        double tCircled = ds.getDouble(0, "u_tumorcircled", 0.0d);
                        if (tCircled < macroDissectRule) {
                            for (int i = 0; i < dsFinal.getRowCount(); i++) {
                                dsFinal.setValue(i, "finalmovementtramstop", "Macrodissection");
                                dsFinal.setValue(i, "finalmovementstep", "Macrodissection");
                            }
                        }
                    }
                }
            }
        }
    }

    private DataSet dsHNESamples(String sampleids) throws SapphireException {
        DataSet dsHNESamples = null;
        String sql = Util.parseMessage(MolecularSql.GET_HNE_SAMPLE_FR_PATHOLOGY_REV, StringUtil.replaceAll(sampleids, ";", "','"));
        /*String sql = "select s.s_sampleid as sampleid,st.methodology as methodology,s.u_qns from s_sample s, u_sampletestcodemap st where s.s_sampleid=st.s_sampleid" +
                " and st.methodology in('Molecular','FISH') and s.s_sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";*/
        dsHNESamples = getQueryProcessor().getSqlDataSet(sql);
        return dsHNESamples;
    }
    private void populateTumorCercledValueOnUSS(DataSet dsSql) throws SapphireException {
        DataSet dsAllSlides = null;
        if (dsSql.size() > 0) {
            String accessionid = Util.getUniqueList(dsSql.getColumnValues("u_accessionid", ";"), ";", true);
            String sql = Util.parseMessage(MolecularSql.GET_ALL_SAMPLE_FR_PATHOLOGY_REV_ACCESSION, StringUtil.replaceAll(accessionid, ";", "','"));
            dsAllSlides = getQueryProcessor().getSqlDataSet(sql);
        }
        for (int i = 0; i < dsSql.size(); i++) {
            String u_type = dsSql.getValue(i, "u_type", "");
            String u_rootsample = dsSql.getValue(i, "u_rootsample", "");
            String u_clientspecimenid = dsSql.getValue(i, "u_clientspecimenid", "");
            String u_tumorcircled = dsSql.getValue(i, "u_tumorcircled", "");
            String u_accessionid = dsSql.getValue(i, "u_accessionid", "");
            HashMap hm = new HashMap();
            if ("H".equalsIgnoreCase(u_type) || "SH".equalsIgnoreCase(u_type)) {

                hm.clear();
                hm.put("u_rootsample", u_rootsample);
                hm.put("u_accessionid", u_accessionid);
                hm.put("u_type", "U");
                DataSet dsUSSFilter = dsAllSlides.getFilteredDataSet(hm);
                if (dsUSSFilter.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsUSSFilter.getColumnValues("sampleid", ";"));
                    props.setProperty("u_tumorcircled", StringUtil.repeat(u_tumorcircled, dsUSSFilter.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to complete H&E review." + ex.getMessage());
                    }
                }
            } else if ("CH".equalsIgnoreCase(u_type)/* || "SH".equalsIgnoreCase(u_type)*/) {
                hm.clear();
                hm.put("u_accessionid", u_accessionid);
                hm.put("u_type", "CU");
                DataSet dsClientUSSFilter = dsAllSlides.getFilteredDataSet(hm);
                if (dsClientUSSFilter.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsClientUSSFilter.getColumnValues("sampleid", ";"));
                    props.setProperty("u_tumorcircled", StringUtil.repeat(u_tumorcircled, dsClientUSSFilter.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to complete H&E review." + ex.getMessage());
                    }
                }
            }
        }

    }

    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_TYPE = "type";
    private static final String DATASET_PROPERTY_METHODOLOGY = "methodology";
    private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";
    private static final String DATASET_PROPERTY_CURRENTTRAMSTOP = "currenttramstop";
    private static final String DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT = "custodialdepartmentid";
    private static final String DATASET_PROPERTY_CURRENTMOVEMENTSTEP = "currentmovementstep";
    private static final String DATASET_PROPERTY_NEXT_MOVEMENTSTEP = "nextmovementstep";
    private static final String DATASET_PROPERTY_NEXT_TRAMSTOP = "nexttramstop";
    private static final String DATASET_PROPERTY_FINAL_MOMENTSTEP = "finalmovementtramstop";
    private static final String DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP = "finalmovementstep";
    private static final String DATASET_PROPERTY_HNE_REV = "hnebatchreview";
    private static final String DATASET_PROPERTY_REV_BY = "pathreviewedby";
    private static final String DATASET_PROPERTY_REV_DT = "pathreviewdts";
    private static final String DATASET_PROPERTY_TUMORCIRCLED = "u_tumorcircled";
    private static final String DATASET_PROPERTY_PARENTSAMPLE = "parentsampleid";

    /************************************
     * Method to group multiple samples from 
     * different accessions
     * @param samples
     * @return
     ************************************/
    private List<String> getGroupedHUSlide(String samples) {
        String query = Util.parseMessage(MolecularSql.GET_CS_SAMPLE_DATA, StringUtil.replaceAll(samples, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(query);
        List<String> dataList = new ArrayList<>();
        if (ds != null && ds.getRowCount() > 0) {
            ArrayList<?> groupDS = ds.getGroupedDataSets("u_clientspecimenid,u_accessionid");
            if (groupDS != null && !groupDS.isEmpty()) {
                for (Object obj : groupDS) {
                    DataSet rs = (DataSet) obj;
                    dataList.add(rs.getColumnValues("s_sampleid", ";"));
                }
            }
        }
        return dataList;
    }

}
