package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.GenerateReport;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by msubhra on 6/7/2016.
 */
public class GenerateReportIhcQc extends BaseAction {



    public void processAction(PropertyList properties) throws SapphireException {

        String accessionid = properties.getProperty("u_accessionid");
        String los = properties.getProperty("los");
        String url = "rc?command=ViewReport&reportid=IHCQC&reportversionid=1&accessionid="+accessionid+"&los="+los+"&mode=submitarg&displaytype=pdf";
        /*String text = "<script> var oform = document.createElement('FORM');" +
                "document.body.appendChild(oform);" +
                "oform.method='POST';" +
                "oform.action='"+url+"';" +
                "oform.target='_blank';" +
                "oform.Submit();" +
                "document.body.removeChild(oform);</script>";*/
        String text = "<script>" +
                "var form = document.createElement(\"form\");" +
                "document.body.appendChild(form);" +
                "form.method = \"POST\";" +
                "form.action= \""+url+"\";" +
                "form.target=\"_blank\";" +
                "form.submit();" +
                "document.body.removeChild(form);" +
                "</script>";


        properties.setProperty("msg",text);
       // properties.setProperty("<script>alert(1)</script>",text);

        //stainingSummary(accessionid,los);

    }

    /*private void stainingSummary(String accessonid,String los) throws SapphireException
    {
        PropertyList props = new PropertyList();

        props.setProperty(GenerateReport.PROPERTY_REPORTID,"IHCQC");
        props.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID,"1");
        props.setProperty(GenerateReport.PROPERTY_PARAM1,accessonid);
        props.setProperty(GenerateReport.PROPERTY_PARAM2,los);
        props.setProperty(GenerateReport.PROPERTY_FILETYPE,"PDF");
        props.setProperty(GenerateReport.PROPERTY_EMAILTOLIST,"subhra_m@hcl.com");

        try {
            getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create report.");
            errMsg+= "\nError Detail:"+e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,errMsg);
        }

    }*/
}
