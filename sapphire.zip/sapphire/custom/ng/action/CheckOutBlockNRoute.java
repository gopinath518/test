package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * This action is use to check out block or sample
 * from storage
 * Created by mpandey on 6/22/2016.
 */
public class CheckOutBlockNRoute extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String departmentid = properties.getProperty("departmentid");
        String currentmovementstep = properties.getProperty("currentmovementstep");
        String blockroutingreason = properties.getProperty("reason");

        updateTrackItem(sampleid, departmentid, currentmovementstep);
        updateMovementStepNReason(sampleid, currentmovementstep, blockroutingreason);

    }

    /**
     * This method is use to update the movement step of sample
     * to route it to respective departments.
     *
     * @param sampleid
     * @param currentmovementstep
     * @param blockroutingreason
     * @throws SapphireException
     */
    private void updateMovementStepNReason(String sampleid, String currentmovementstep, String blockroutingreason) throws SapphireException {
        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("u_currentmovementstep", currentmovementstep);
            prop.setProperty("u_blockroutingreason", blockroutingreason);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    /**
     * This method is use to update currentstorageunitid of sample
     * in order to check out from storage.
     *
     * @param sampleid
     * @param departmentid
     * @throws SapphireException
     */
    private void updateTrackItem(String sampleid, String departmentid, String currentmovementstep) throws SapphireException {
        String quesample = StringUtil.replaceAll(sampleid, ";", "','");
        String sql = "select trackitemid,currentstorageunitid,custodialdepartmentid from TRACKITEM where linkkeyid1 in ('" + quesample + "') ";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String trackitemid = ds.getColumnValues("trackitemid", ";");
        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("currentstorageunitid", "");
            props.setProperty("custodialdepartmentid", departmentid);
            props.setProperty("u_currenttramstop", currentmovementstep);
            props.setProperty("custodialuserid", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            props.setProperty("u_temporarylocation", currentmovementstep);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }
}
