package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 6/28/2016.
 */
public class SignOutMolBatch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("ngbatchid");
        String[] batches = StringUtil.split(batchid, ";");
        String nypending = properties.getProperty("nypending");
        String[] nybatch = StringUtil.split(nypending, ";");
        String currentuser = connectionInfo.getSysuserId();
        String sql = "select nyflag from u_physician where userid='" + currentuser + "'";
        DataSet nyflagds = getQueryProcessor().getSqlDataSet(sql);
        String nyflag = nyflagds.getColumnValues("nyflag", ";");
        //String[] nyflags = StringUtil.split(nyflag, ";");
        for (int i = 0; i < batches.length; i++) {
            if (!nybatch[i].equalsIgnoreCase("")) {
                if (!nyflag.equalsIgnoreCase("Y")) {
                    String error = getTranslationProcessor().translate("You need to  have a New York License before signing out the samples from New York Batch " + batches[i]);
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
            }
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        prop.setProperty("batchmovestatus", "BatchCompleted");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }catch(SapphireException s){
            String err=getTranslationProcessor().translate("Batch is not completed");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,err);
        }
    }
}
