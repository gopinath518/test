package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by kshahbaz on 7/4/2016.
 * @desc : Create an additional extraction tube for sample.
 * Mandatory input:
 * param1:sample id
 * @throws SapphireException
 */
public class AdditionalExTube extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("keyid1");

        String sql_sourcesample = "select distinct sourcesampleid from s_samplemap where destsampleid='" + sampleid + "'";
        DataSet sourcesample = getQueryProcessor().getSqlDataSet(sql_sourcesample);
        if (sourcesample == null) {
            String errMSG = getTranslationProcessor().translate("Contact you Administrator. SQL failed:");
            errMSG += sql_sourcesample;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        if (sourcesample.size() == 0) {
            String errMSG = getTranslationProcessor().translate("Sample is not selected. SQL failed:");
            errMSG += sql_sourcesample;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMSG);
        }

         additionalTube(sourcesample,sampleid);
    }
    /**
     * @desc :This method creates an additional extraction tube for a sample.
     * @param: sampleid and DataSet.
     * @throws SapphireException
     */
    private void additionalTube(DataSet ds,String sampleid) throws SapphireException {

        PropertyList pl=new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID,"Sample");
        pl.setProperty(AddSDI.PROPERTY_TEMPLATEID,sampleid);
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        String destsampleId=pl.getProperty("newkeyid1");
        try {
          PreparedStatement ps = database.prepareStatement("insert into s_samplemap(sourcesampleid,destsampleid) values(?,?)");
          for(int i=0;i<ds.size();i++){
           ps.setString(1, ds.getValue(i,"sourcesampleid"));
           ps.setString(2,destsampleId);
           ps.addBatch();
          }
           ps.executeBatch();
        }
        catch(SQLException e){
          String error = getTranslationProcessor().translate("Failed to create additional extraction tube ");
          throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

    }

}
