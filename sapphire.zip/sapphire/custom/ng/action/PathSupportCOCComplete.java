package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by sbaitalik on 9/2/2017.
 */
public class PathSupportCOCComplete extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");
        String custodialuserid = properties.getProperty("custodialuserid");
        String u_currenttramstop = properties.getProperty("u_currenttramstop");
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid");

        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String newsampleids = StringUtil.replaceAll(sampleid, ";", "','");
        String losdetail = Util.parseMessage(ApSql.GET_LOS_BY_SPECIMEN, newsampleids);
        DataSet dsLosDetail = getQueryProcessor().getSqlDataSet(losdetail);

        if (dsLosDetail == null) {
            String error = getTranslationProcessor().translate("Query failed");
            error += losdetail;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsLosDetail.size() == 0) {
            String e = getTranslationProcessor().translate("No Test is assigned with the slide(s).");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, e);
        }

        if (!dsLosDetail.isValidColumn("specialvalueflag")) {
            dsLosDetail.addColumn("specialvalueflag", DataSet.STRING);
        }
        for (int j = 0; j < dsLosDetail.getRowCount(); j++) {
            String losDetail = dsLosDetail.getValue(j, "los");
            if ("Stain Only".equalsIgnoreCase(losDetail)) {
                dsLosDetail.setValue(j, "specialvalueflag", "N");
            } else {
                dsLosDetail.setValue(j, "specialvalueflag", "N");
            }
        }
        HashMap hm = new HashMap();
        hm.put("specialvalueflag", "Y");
        DataSet dsFilterY = dsLosDetail.getFilteredDataSet(hm);
        hm.clear();
        hm.put("specialvalueflag", "N");
        DataSet dsFilterN = dsLosDetail.getFilteredDataSet(hm);
        if (dsFilterY.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFilterY.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_currentmovementstep", StringUtil.repeat("LogisticCOC", dsFilterY.size(), ";"));
            //prop.setProperty("u_imagingdts", "n");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            prop.clear();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilterY.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_currenttramstop", StringUtil.repeat("LogisticCOC", dsFilterY.size(), ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
            } catch (Exception e) {
                throw new SapphireException("EditTrackItem Action failed" + e.getMessage());
            }
        }
        if (dsFilterN.size() > 0) {
            String samples = Util.getUniqueList(dsFilterN.getColumnValues("s_sampleid", ";"), ";", true);
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, samples);
            props.setProperty("u_currentmovementstep", StringUtil.repeat(u_currentmovementstep, StringUtil.split(samples,";").length, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("EditSDI on Sample failed" + e.getMessage());
            }
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, samples);
            props.setProperty("u_currenttramstop", StringUtil.repeat(u_currenttramstop, StringUtil.split(samples,";").length, ";"));
            //props.setProperty("custodialuserid", StringUtil.repeat(custodialuserid, dsFilterN.size(), ";"));
            //props.setProperty("custodialdepartmentid", StringUtil.repeat(custodialdepartmentid, dsFilterN.size(), ";"));//added
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("EditTrackItem Action failed" + e.getMessage());
            }
        }


        //throw new SapphireException("WIP");
    }
}
