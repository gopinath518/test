package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by SBaitalik on 12/5/2016.
 * Description: This is used to marked specimen as best
 *
 */
public class ChooseBestHNEComplete extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");//IHCFlowCompleteStep
        String bsthnevalibypass = properties.getProperty("bsthnevalibypass", "N");//IHCFlowCompleteStep
        String comment = properties.getProperty("comment", "");//IHCFlowCompleteStep
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Please select atleast one specimen.");
        }
        String sql = Util.parseMessage(ApSql.GET_SPECIMEN_INFO, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        if (dsInfo.size() > 0) {
            dsInfo.sort("u_accessionid");
            ArrayList groupByAccessionArray = dsInfo.getGroupedDataSets("u_accessionid");
            for (int i = 0; i < groupByAccessionArray.size(); i++) {
                DataSet dsEach = (DataSet) groupByAccessionArray.get(i);
                hm.clear();
                hm.put("u_isbesthne", "Y");
                DataSet dsBestHNEFiletr = dsEach.getFilteredDataSet(hm);
                if (dsBestHNEFiletr.size() == 0 && "N".equalsIgnoreCase(bsthnevalibypass)) {
                    throw new SapphireException("<b>Please choose one Best H&E.</b>");
                }
                if (dsBestHNEFiletr.size() > 0) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsBestHNEFiletr.getColumnValues("s_sampleid", ";"));
                    prop.setProperty("u_isbesthne", "Y");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                }
                hm.clear();
                hm.put("u_isbesthne", null);
                DataSet dsNtBestHNEFiletr = dsEach.getFilteredDataSet(hm);
                if (dsNtBestHNEFiletr.size() > 0) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsNtBestHNEFiletr.getColumnValues("s_sampleid", ";"));
                    prop.setProperty("u_isbesthne", "N");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                }
                hm.clear();
                hm.put("u_isbesthne", "N");
                DataSet dsNttBestHNEFiletr = dsEach.getFilteredDataSet(hm);
                if (dsNttBestHNEFiletr.size() > 0) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsNttBestHNEFiletr.getColumnValues("s_sampleid", ";"));
                    prop.setProperty("u_isbesthne", "N");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                }
            }
            sql = Util.parseMessage(ApSql.GET_HNE_SPECIMEN_INFO, StringUtil.replaceAll(sampleid, ";", "','"));
            dsInfo = getQueryProcessor().getSqlDataSet(sql);
            sampleid = dsInfo.getColumnValues("s_sampleid", ";");
            PropertyList prop = new PropertyList();
            prop.setProperty("sampleid", sampleid);
            try {
                getActionProcessor().processAction("IHCFlowCompleteStep", "1", prop);
            } catch (Exception ec) {
                throw new SapphireException("<b>" + ec.getMessage() + "</b>");
            }
            if ("Y".equalsIgnoreCase(bsthnevalibypass)) {
                String accessionid = Util.getUniqueList(dsInfo.getColumnValues("u_accessionid", ";"), ";", true);
                String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
                String custodialdepartmentid = connectionInfo.getDefaultDepartment();
                PropertyList procomnt = new PropertyList();
                procomnt.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
                procomnt.setProperty(AddSDI.PROPERTY_COPIES, "1");
                procomnt.setProperty("accessionid", accessionid);
                procomnt.setProperty("commentby", currentuser);
                procomnt.setProperty("commentdt", "n");
                procomnt.setProperty("comments", comment);
                procomnt.setProperty("departmentid", custodialdepartmentid);

                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, procomnt);
                } catch (Exception ex) {
                    throw new SapphireException("<b>Failed to update comments.</b>");
                }
                //properties.setProperty("msg", prop.getProperty("msg"));
            } /*else {
                throw new SapphireException("<b>Please provide best H&E complete.</b>");
            }*/
            properties.setProperty("msg", prop.getProperty("msg"));
        }
        //throw new SapphireException("test");
    }
}
