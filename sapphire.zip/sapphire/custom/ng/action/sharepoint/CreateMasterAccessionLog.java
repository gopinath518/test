package sapphire.custom.ng.action.sharepoint;

import ca.uhn.hl7v2.model.v21.datatype.ST;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CreateMasterAccessionLog extends BaseAction {
    String SHAREPOINT_PATH = "sharepoint.path";
    String INTERVAL_TIME = "sharepoint.interval";
    static final long ONE_MINUTE_IN_MILLIS = 60000;//millisecs

    public void processAction(PropertyList properties) throws SapphireException {

        String sql = Util.parseMessage(AccessionPageSql.GET_ENVPROPS_BY_ID, SHAREPOINT_PATH);
        DataSet dsSharePointPath = getQueryProcessor().getSqlDataSet(sql);
        if (dsSharePointPath == null || dsSharePointPath.size() == 0) {
            logger.error("No path defined for the sharepoint.");
            return;
        }
        String path = dsSharePointPath.getValue(0, "propvalue", "");
        sql = Util.parseMessage(AccessionPageSql.GET_ENVPROPS_BY_ID, INTERVAL_TIME);
        DataSet dsIntervalTime = getQueryProcessor().getSqlDataSet(sql);
        if (dsIntervalTime == null || dsIntervalTime.size() == 0) {
            logger.error("Please set interval time");
            return;
        }
        String intervaltime = dsIntervalTime.getValue(0, "propvalue", "");
        //GET INTERVAL TIMES RANGE
        Calendar crrntDate = Calendar.getInstance();
        long currentTimeInMili = crrntDate.getTimeInMillis();
        Date afterAddingTenMins = new Date(currentTimeInMili - (Integer.parseInt(intervaltime) * ONE_MINUTE_IN_MILLIS));

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss aa");
        String strDate = sdf.format(cal.getTime());
        logger.info("Current date in String Format: " + strDate);
        String befrDate = sdf.format(afterAddingTenMins.getTime());
        logger.info("Before date in String Format: " + befrDate);

        sql = Util.parseMessage(AccessionPageSql.GET_ACCESSIONS_BY_DATERANGE, "FFPE%", befrDate, strDate, "FFPE%", befrDate, strDate);
        DataSet dsAccessionInfos = getQueryProcessor().getSqlDataSet(sql);
        if (dsAccessionInfos == null || dsAccessionInfos.size() == 0) {
            logger.info("No record found.");
            return;
        }
        if (dsAccessionInfos.size() > 0) {
            for (int i = 0; i < dsAccessionInfos.size(); i++) {
                String collectiondt = dsAccessionInfos.getValue(i, "COLLECTION_DATE");
                collectiondt = Util.getUniqueList(collectiondt, ";", true);
                collectiondt = StringUtil.replaceAll(collectiondt, ";", ",");
                if (StringUtil.split(collectiondt, ",").length > 1) {
                    String latestdt = getMaxDate(collectiondt);
                    try {
                        SimpleDateFormat scoldf = new SimpleDateFormat("dd-MMM-yy");
                        Date date = scoldf.parse(latestdt);
                        scoldf = new SimpleDateFormat("MM/dd/yyyy");
                        latestdt = scoldf.format(date);
                        dsAccessionInfos.setValue(i, "collection_date", latestdt.toUpperCase());
                    } catch (Exception e) {
                        logger.info("Unable to parse date format.");
                    }
                } else {
                    if (!Util.isNull(collectiondt)) {
                        try {
                            SimpleDateFormat scoldf = new SimpleDateFormat("dd-MMM-yy");
                            Date date = scoldf.parse(collectiondt);
                            scoldf = new SimpleDateFormat("MM/dd/yyyy");
                            collectiondt = scoldf.format(date);
                            dsAccessionInfos.setValue(i, "collection_date", collectiondt);
                        } catch (Exception e) {
                            logger.info("Unable to parse date format.");
                        }
                    } else {
                        dsAccessionInfos.setValue(i, "collection_date", collectiondt);
                    }
                }
                //MANUPULATE SAMPLE RETURN
                String samplereturn = dsAccessionInfos.getValue(i, "SAMPLES_RETURNED");
                if (samplereturn.contains(";")) {
                    samplereturn = "\"" + StringUtil.replaceAll(samplereturn, ";", ",") + "\"";
                    dsAccessionInfos.setValue(i, "SAMPLES_RETURNED", samplereturn);
                } else {
                    dsAccessionInfos.setValue(i, "SAMPLES_RETURNED", samplereturn);
                }
                //MANUPULATE COMMENTS
                String comments = dsAccessionInfos.getValue(i, "COMMENTS_", "");
                if (!Util.isNull(comments)) {
                    comments = comments.replaceAll("\\r\\n|\\r|\\n", " ");
                    dsAccessionInfos.setValue(i, "COMMENTS_", comments);
                }
                //RELEASE 1.6.1 (UNIQUE CLIENT SPECIMEN ID)
                String specimenid = Util.getUniqueList(dsAccessionInfos.getValue(i, "SPECIMEN_I_D", ""), ";", true);
                dsAccessionInfos.setValue(i, "SPECIMEN_I_D", specimenid);

            }
        }
        //GET CURRENT DATE AND TIME
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String datetxt = StringUtil.replaceAll(dateFormat.format(date), "-", "");
        System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
        dateFormat = new SimpleDateFormat("HH:mm:ss");
        String timetxt = StringUtil.replaceAll(dateFormat.format(date.getTime()), ":", "");
        //path = "C:\\Temp\\";//TODO TO BE REMOVED
        File existingDir = new File(path);
        if (!existingDir.isDirectory()) {
            logger.info("MasterAccessionLog>>>", path + " This is not valid directory.You can't proceed further.");
            return;
        }

        String filelocationpath = path + "MasterAccessionLog-LV-" + datetxt + "-" + timetxt + ".csv";
        generateCsvFile(dsAccessionInfos, filelocationpath);
        logger.info("MasterAccessionLog:::Exit", "CSV has been generated at " + filelocationpath);
    }

    public static void generateCsvFile(DataSet dsAccessionInfos, String filelocationpath) {
        String columns = "";
        for (int i = 0; i < dsAccessionInfos.getColumns().length; i++) {
            //columns += "," + dsAccessionInfos.getColumns()[i].toUpperCase();
            columns += "," + toCamelCase(dsAccessionInfos.getColumns()[i]);
        }
        columns = columns.substring(1);
        FileWriter writer = null;
        try {
            writer = new FileWriter(filelocationpath);
            writer.append(columns);
            writer.append('\n');
            for (int i = 0; i < dsAccessionInfos.size(); i++) {
                for (int c = 0; c < dsAccessionInfos.getColumns().length; c++) {
                    String col = dsAccessionInfos.getColumns()[c];
                    String colval = dsAccessionInfos.getValue(i, col, "");
                    writer.append(colval);
                    writer.append(",");
                }
                writer.append('\n');
            }
            System.out.println("CSV file is created...");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    static String toCamelCase(String s) {
        String[] parts = s.split("_");
        String camelCaseString = "";
        for (String part : parts) {
            camelCaseString = camelCaseString + toProperCase(part);
        }
        return camelCaseString;
    }

    static String toProperCase(String s) {
        return s.substring(0, 1).toUpperCase() +
                s.substring(1).toLowerCase();
    }

    private String getMaxDate(String inputdt) throws SapphireException {
        String latestdt = "";
        String dateArry[] = StringUtil.split(inputdt, ",");
        List<Date> dates = new ArrayList<Date>();
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yy");
        try {
            for (int i = 0; i < dateArry.length; i++) {
                Date date = null;

                date = fmt.parse(dateArry[i]);
                dates.add(date);
            }
            latestdt = fmt.format(Collections.max(dates));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return latestdt;
    }
}
