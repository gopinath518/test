package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.action.ihc.IHCSlideRouting;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by SBaitalik on 9/1/2017.
 */
public class SetUpCompleteStepWrapper extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String completestepbypass = properties.getProperty("completestepbypass", "N");
        String currentstep = properties.getProperty("currentstep");
        String nextstep = properties.getProperty("nextstep");
        String sampleid = properties.getProperty("sampleid");
        String stepaction = properties.getProperty("stepaction");
        String sendMessage = properties.getProperty("sendMessage");

        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }

        PropertyList inputprops = new PropertyList();
        inputprops.setProperty("currentstep", currentstep);
        inputprops.setProperty("nextstep", nextstep);
        inputprops.setProperty("sampleid", sampleid);
        inputprops.setProperty("stepaction", stepaction);
        inputprops.setProperty("completestepbypass", completestepbypass);
        try {
            getActionProcessor().processAction("CompleteStep", "1", inputprops);
        } catch (Exception e) {
            throw new SapphireException("SetUp complete Action Failed." + e.getMessage());
        }
        inputprops.clear();
        inputprops.setProperty("sampleid", sampleid);
        try {
            getActionProcessor().processAction(IHCSlideRouting.ACTION_ID, IHCSlideRouting.ACTION_VERSION_ID, inputprops);
        } catch (Exception e) {
            throw new SapphireException("IHCSlideRouting Action Failed." + e.getMessage());
        }
        //TODO BELOW WILL OBSOLUTE AS WE DONT HAVE HL7Message as of now.
        /*inputprops.setProperty("sampleid", sampleid);
        inputprops.setProperty("sendMessage", sendMessage);
        try {
            getActionProcessor().processAction("ForHL7Message", "1", inputprops);
        } catch (Exception e) {
            throw new SapphireException("HL7Message Action Failed." + e.getMessage());
        }*/

        //throw new SapphireException("test");
    }
}
