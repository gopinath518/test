package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class SetPerformingSite extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String performingsite = properties.getProperty("u_performingsite");
        String currentmovementstep = properties.getProperty("u_currentmovementstep");
        String currenttramstop = properties.getProperty("u_currenttramstop");
        String sampleid = properties.getProperty("keyid1");
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Specimen(s) can't be blank.");
        }
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String sql = Util.parseMessage(CommonSql.GET_SAMPLE_MOVE, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        String defaultdepartment = connectionInfo.getDefaultDepartment();//AV-Molecular
        String site = StringUtil.split(defaultdepartment, "-")[0];
        String destination = site + "-Accessioning";
        if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor())) {
            throw new SapphireException("Error: Unable to route specimen. Department: " + destination + " does not exist");
        }
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        props.setProperty("u_performingsite", performingsite);
        props.setProperty("u_currentmovementstep", currentmovementstep);
        props.setProperty("u_previousmovementstep", dsSampleInfo.getColumnValues("u_currentmovementstep", ";"));
        props.setProperty("u_previouscustodialdept", dsSampleInfo.getColumnValues("custodialdepartmentid", ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update Performing Site for the specimen." + ex.getMessage());
        }

        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        props.setProperty("custodialuserid", "(null)");
        props.setProperty("custodialdepartmentid", destination);
        props.setProperty("u_currenttramstop", currenttramstop);
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update department for the specimen." + ex.getMessage());
        }
        String msg = "";
        if (sampleid.contains(";")) {
            sampleid = sampleid.replaceAll(";", ", ");
        }
        msg = sampleid + " has/have been moved to Logistics COC.";
        properties.setProperty("msg", msg);
    }
}
