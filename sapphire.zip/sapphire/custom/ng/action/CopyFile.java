package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by DMondal on 3/31/2017.
 * Modified by surajit.baitalik on 04/03/2018.
 * Description : This action will copy file from one location to another location.Currently this is using from MolecularGenetics
 * and GeneratePortalReport action.
 */
public class CopyFile extends BaseAction {
    public static final String ID = "CopyFile";
    public static final String VERSIONID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sourcefile = properties.getProperty("sourcefile", "");
        String sampleid = properties.getProperty("sampleid", "");
        String rptopsid = properties.getProperty("rptopsid", "");
        File source = new File(sourcefile);


        String sqlDestPath = "", sqlProjLevel = "";
        if (!Util.isNull(sampleid)) {
            sqlDestPath = Util.parseMessage(CommonSql.GET_SFTP_FROM_SITE_LEVEL_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));

            sqlProjLevel = Util.parseMessage(CommonSql.GET_SFTP_FROM_PROJECT_LEVEL_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));

        } else if (!Util.isNull(rptopsid)) {
            sqlDestPath = Util.parseMessage(CommonSql.GET_SFTP_PATH_FROM_SITE_LEVEL_BY_REPORTOPTIONID, StringUtil.replaceAll(rptopsid, ";", "','"));

            sqlProjLevel = Util.parseMessage(CommonSql.GET_SFTP_PATH_FROM_PROJECT_LEVEL_BY_REPORTOPTIONID, StringUtil.replaceAll(rptopsid, ";", "','"));
        }
        DataSet dsDestPath = getQueryProcessor().getSqlDataSet(sqlDestPath);
        DataSet dsDestProjPath = getQueryProcessor().getSqlDataSet(sqlProjLevel);
        if (dsDestProjPath != null && dsDestProjPath.size() > 0) {
            dsDestPath.copyRow(dsDestProjPath, -1, 1);
        }
        if (dsDestPath == null)
            throw new SapphireException("Error: Unable to perform query in database");
        if (dsDestPath.size() == 0)
            throw new SapphireException("The Query:\n" + sqlDestPath + "\n is returning no row.");


        String sql = "select windowspath,mounteddrive from u_windwsmountdpathmap where u_windwsmountdpathmapid='Template'";
        DataSet dsPathInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsPathInfo == null)
            throw new SapphireException("Network path and mounted drive mapping info cannot be obtained from database.");
        if (dsPathInfo.size() == 0)
            throw new SapphireException("The Query:\n" + sql + "\n is returning no row.");

        if (dsDestPath.size() > 0) {
            HashMap<String, String> hmap = new HashMap<String, String>();

            CopyOption[] options = new CopyOption[]{
                    StandardCopyOption.REPLACE_EXISTING
            };

            if (!Util.isNull(sampleid)) {

                for (int i = 0; i < dsDestPath.size(); i++) {

                    String sendto = dsDestPath.getValue(i, "path", "");
                    String accessionId = dsDestPath.getValue(i, "u_accessionid", "");
                    String subjectId = dsDestPath.getValue(i, "u_biopharmasubjectid", "");
                    String sampleId = dsDestPath.getValue(i, "s_sampleid", "");
                    String bioSiteId = dsDestPath.getValue(i, "u_biositeid", "");

                    if (Util.isNull(sendto))
                        throw new SapphireException("SFTP path is not defined for the BioSite " + bioSiteId + ".");
                    if (Util.isNull(accessionId))
                        throw new SapphireException("Accesssion Id is obtained as null.");
                    if (Util.isNull(subjectId))
                        throw new SapphireException("Subject ID is obtained as null.");
                    if (Util.isNull(sampleId))
                        throw new SapphireException("Reporting sampleid is obtained as null.");

                    String filename = accessionId + "_" + subjectId + "_" + sampleId + ".pdf";

                    String toPath = StringUtil.replaceAll(sendto, "/", "\\");

                    hmap.clear();
                    hmap.put("windowspath", toPath);
                    DataSet dsPathInfoFiltr = dsPathInfo.getFilteredDataSet(hmap);

                    if (dsPathInfoFiltr == null || dsPathInfoFiltr.size() == 0)
                        throw new SapphireException("Mounted drive info is not obtained for the network path " + toPath + ".");

                    String mountedPath = dsPathInfoFiltr.getValue(0, "mounteddrive", "");
                    if (Util.isNull(mountedPath))
                        throw new SapphireException("Mounted drive info is not obtained for the network path " + toPath + ".");

                    File dest = null;
                    if (mountedPath.endsWith("/")) {
                        dest = new File(mountedPath + filename);
                    } else {
                        dest = new File(mountedPath + "/" + filename);
                    }
                    try {
                        Files.copy(source.toPath(), dest.toPath(), options);
                    } catch (Exception e) {
                        throw new SapphireException(e.getMessage());
                    }
                }
            } else if (!Util.isNull(rptopsid)) {

                dsDestPath.sort("u_accessionid");
                ArrayList<DataSet> dsDestPathArr = dsDestPath.getGroupedDataSets("u_accessionid");
                if (dsDestPathArr != null && dsDestPathArr.size() > 0) {
                    for (int i = 0; i < dsDestPathArr.size(); i++) {
                        DataSet tempDs = dsDestPathArr.get(i);
                        if (tempDs != null && tempDs.size() > 0) {

                            String sendto = tempDs.getColumnValues("path", ";");
                            String accessionId = tempDs.getValue(0, "u_accessionid", "");
                            String subjectId = tempDs.getValue(0, "u_biopharmasubjectid", "");
                            String bioSiteId = tempDs.getValue(0, "u_biositeid", "");

                            if (Util.isNull(sendto))
                                throw new SapphireException("SFTP path is not defined for the BioSite " + bioSiteId + ".");
                            if (Util.isNull(accessionId))
                                throw new SapphireException("Accesssion Id is obtained as null.");
                            if (Util.isNull(subjectId))
                                throw new SapphireException("Subject ID is obtained as null.");

                            String filename = accessionId + "_" + subjectId + "_" + ".pdf";

                            if (!Util.isNull(sendto)) {
                                String sendtoArr[] = StringUtil.split(sendto, ";");
                                if (sendtoArr != null && sendtoArr.length > 0) {

                                    for (int j = 0; j < sendtoArr.length; j++) {

                                        if (!Util.isNull(sendtoArr[j])) {

                                            String toPath = StringUtil.replaceAll(sendtoArr[j], "/", "\\");

                                            hmap.clear();
                                            hmap.put("windowspath", toPath);
                                            DataSet dsPathInfoFiltr = dsPathInfo.getFilteredDataSet(hmap);

                                            if (dsPathInfoFiltr == null || dsPathInfoFiltr.size() == 0)
                                                throw new SapphireException("Mounted drive info is not obtained for the network path " + toPath + ".");

                                            String mountedPath = dsPathInfoFiltr.getValue(0, "mounteddrive", "");
                                            if (Util.isNull(mountedPath))
                                                throw new SapphireException("Mounted drive info is not obtained for the network path " + toPath + ".");

                                            File dest = null;
                                            if (mountedPath.endsWith("/")) {
                                                dest = new File(mountedPath + filename);
                                            } else {
                                                dest = new File(mountedPath + "/" + filename);
                                            }
                                            try {
                                                Files.copy(source.toPath(), dest.toPath(), options);
                                            } catch (Exception e) {
                                                throw new SapphireException(e.getMessage());
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}
