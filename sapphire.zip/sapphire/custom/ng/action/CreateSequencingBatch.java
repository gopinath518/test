package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.io.File;

/**
 * Created by rrmandal on 8/11/2016.
 */
public class CreateSequencingBatch extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        if(Util.isNull(batchid)){
            throw new SapphireException("Complete process cannot be performed.\nReason: Batchid is not found");
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID,"NGBatch");
        prop.setProperty(AddSDI.PROPERTY_TEMPLATEID,batchid);
        prop.setProperty("batchmovestatus","PrecipitationComplete");
        prop.setProperty("origin","Sequencing");
        getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID,prop);
        String newBatch = prop.getProperty(AddSDI.RETURN_NEWKEYID1,"");

        if(!Util.isNull(newBatch)) {
            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
            prop.setProperty("batchmovestatus", "Complete");
            prop.setProperty("batchcompletedts", "n");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            String sql = "select filename from sdiattachment where keyid1='" + batchid + "'";
            DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
            if (dsAttachment != null && dsAttachment.size() > 0) {
                String filename = dsAttachment.getValue(0, "filename", "");
                if (!Util.isNull(filename)) {
                    prop.clear();
                    prop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                    prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newBatch);
                    prop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                    prop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                    prop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, prop);
                }
            }
        }
        else {
            throw new SapphireException("EGEL batch cannot be created.");
        }
    }
}
