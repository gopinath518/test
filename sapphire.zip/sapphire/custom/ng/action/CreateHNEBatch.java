package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.QueryProcessor;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by dgupta on 5/5/2016.
 */
public class CreateHNEBatch extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {
// Extracting values from propertylist(Coming from front end)
        String sampleids = properties.getProperty("sampleid123");
        String[] sampleArr = StringUtil.split(sampleids, ";");
        String sampleLos = properties.getProperty("los");
        String methodology = properties.getProperty("methodology");
        String hneBatchtype = properties.getProperty("batchtype");
        String newbatch = "";

        logger.info("H&EBatching ", "samples and batchtype   " + sampleids + "   " + hneBatchtype);
        logger.info("H&EBatching ", "samples sampleLos   " + sampleLos + " methodology  " + methodology);

//validating empty sampleid and testcode field
        if ((sampleids.length() == 0) || (hneBatchtype.length() == 0)) {
            properties.setProperty("msg", "Please select samples and Batch type");
            return;
        } else {
            newbatch = createBatch(sampleArr.length, sampleids, hneBatchtype);
        }
        properties.setProperty("msg", "New Batch created '" + newbatch + "'");
        return;
    }

    /*
    *   This method creates batch of all the valide H&E samples provided as input of given batch type.
    *
    *   @param sampArr      length of input string array
    *   @param strSampleids String of input samples
    *   @param batchType    Batch type of which batch is to be created
    * */
    private String createBatch(int sampArr, String strSampleids, String batchType) throws SapphireException {
        int batchSize = 20;
        int round = 0;
        String strNewBatches = "";
        QueryProcessor qp = getQueryProcessor();
        DataSet dsSampleTMap = qp.getSqlDataSet(MolecularSql.HNE_SAMPLES_FOR_BATCH, StringUtil.replaceAll(strSampleids, ";", "','") );

        if (dsSampleTMap.getRowCount() > 0) {
            round = (int) Math.ceil((sampArr / (double) batchSize));
            strNewBatches = createNewBatch(batchType, round);
            String[] newBatches = StringUtil.split(strNewBatches, ";");
            String detailBatch;
            for (int i = 0; i < round; i++) {
                detailBatch = "";
                if (i == round - 1) {
                    createLastBatchDetail(batchSize, dsSampleTMap, newBatches,  i, batchType);
                } else {
                    createBatchDetail(batchSize, dsSampleTMap, newBatches,  i);
                }
            }
        }
        return strNewBatches;
    }


    /*
    *   Populate the batch detail item with samples
    *
    *   @param  batchsize        size of batch
    *   @pparam dsSampleTMap    Data Set of input samples
    *   @param  newBatches      String array of new batch id
     *   @param
    * */
    private void createLastBatchDetail(int batchsize, DataSet dsSampleTMap, String[] newBatches,  int i, String batchType) throws SapphireException {
        String detailBatch = "";
        for (int j = 0; j < (dsSampleTMap.getRowCount() - i * batchsize); j++) {
            detailBatch = detailBatch + ";" + newBatches[0];
        }
        PropertyList plDetails = new PropertyList();
        plDetails.setProperty(AddSDI.PROPERTY_SDCID, "HNEBatchDetail");
        plDetails.setProperty("batchid", detailBatch.substring(1));
        plDetails.setProperty("sampleid", dsSampleTMap.getColumnValues("s_sampleid", i * batchsize, dsSampleTMap.getRowCount(), ";"));  // no change for now
        plDetails.setProperty("copies", "" + (dsSampleTMap.getRowCount() - i * batchsize));

// set sample movement step with respect to batch type
        PropertyList plSempleStep = updateSampleStep(dsSampleTMap, batchType);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plDetails);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plSempleStep);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch Details" + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        return;
    }

    /*
    *   This method updates sample steps based on batch type
    *
    *   @param  dsSampleTMap    Dataset of samples
    *   @param  batchType       Batch type of batch of which samples belong to.
    * */
    private PropertyList updateSampleStep(DataSet dsSampleTMap, String batchType) {
        PropertyList plEditSample = new PropertyList();
        String sampleStatus = "";
        String sampleStatusA = "";
        if (batchType.equalsIgnoreCase("Molecular Medical Review") || batchType.equalsIgnoreCase("FISH Global HER2") || batchType.equalsIgnoreCase("FISH Global Non HER2")) {
            sampleStatus = "PathologyBatch";
        } else if (batchType.equalsIgnoreCase("Molecular Technical Review")) {
            sampleStatus = "Setup";
        } else if (batchType.equalsIgnoreCase("FISH Tech HER2") || batchType.equalsIgnoreCase("FISH Tech Non HER2")) {
            sampleStatus = "Fish";
        }
        for (int i = 0; i < dsSampleTMap.getRowCount(); i++) {
            sampleStatusA += (";" + sampleStatus);
        }
        sampleStatusA = sampleStatusA.substring(1);
        plEditSample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        plEditSample.setProperty(EditSDI.PROPERTY_KEYID1, dsSampleTMap.getColumnValues("s_sampleid", ";"));
        plEditSample.setProperty("u_currentmovementstep", sampleStatusA);
        plEditSample.setProperty("u_hnebatchreview", "N");
        return plEditSample;
    }

    /*
    *   This method creates detail item of the batch which contains samples
    *
    *   @param  batchsize       size of batch
    *   @param  dsSampleTMap    Data Ste of samples
    *   @param  newBatches      String array of batch ids capcity is same as no of items in batch detail
    *   @param  i               integer value
    * */

    private void createBatchDetail(int batchsize, DataSet dsSampleTMap, String[] newBatches,  int i) throws SapphireException {
        String detailBatch = "";
        for (int j = 0; j < batchsize; j++) {
            detailBatch = detailBatch + ";" + newBatches[0];
        }
        PropertyList plDetails = new PropertyList();
        plDetails.setProperty(AddSDI.PROPERTY_SDCID, "HNEBatchDetail");
        ;
        plDetails.setProperty("batchid", detailBatch.substring(1));
        plDetails.setProperty("sampleid", dsSampleTMap.getColumnValues("s_sampleid", i * batchsize, (i + 1) * batchsize - 1, ";"));
        plDetails.setProperty("copies", "20");
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plDetails);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch details " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        return;
    }

    /*
    *   This method creates new batch of given batch type
    *
    *   @param  batchType       Type of batch to be created
    *   @param  noofBatch       No of batch
    *   @return NewbatchId      returns new batch id
    * */
    private String createNewBatch(String batchType, int noofBatch) throws SapphireException {
        SimpleDateFormat sdf = new SimpleDateFormat("MMddyyy");
        String today = sdf.format(new Date());
        String tempBatchId = batchType + "_" + today + "_";
        String batchSuffix = "" + (char) 64;
        String batchId = "";
        String newBatchIds = "";
        String batchTypeAll = "";

        DataSet dsBatch = getQueryProcessor().getSqlDataSet(Util.parseMessage(MolecularSql.HNE_TODAYS_BATCH, today, batchType));
        if (dsBatch.getString(0, "u_hnebatchid") != null) {
            batchId = dsBatch.getString(0, "u_hnebatchid");
            if (batchId.lastIndexOf('_') < batchId.length()) {
                tempBatchId = batchId.substring(0, (batchId.lastIndexOf('_') + 1));
                batchSuffix = batchId.substring((batchId.lastIndexOf('_') + 1), batchId.length());
            }
        }
        for (int i = 0; i < noofBatch; i++) {
            if (batchSuffix.equalsIgnoreCase("Z")) {
                tempBatchId = tempBatchId + batchSuffix;
                batchSuffix = "" + (char) 64;
            }
            batchSuffix = "" + (char) (batchSuffix.charAt(0) + 1);
            newBatchIds = newBatchIds + ";" + tempBatchId + batchSuffix;
            batchTypeAll += ";" + batchType;
        }

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "HNEBatch");
        props.setProperty(AddSDI.PROPERTY_KEYID1, newBatchIds.substring(1));
        props.setProperty("hnebatchtype", batchTypeAll.substring(1));

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception e) {
            e.printStackTrace();
            String error = getTranslationProcessor().translate("Could not create new Batch " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

        return props.getProperty("newkeyid1", "");
    }

}
