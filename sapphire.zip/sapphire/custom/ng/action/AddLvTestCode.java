package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.xml.crypto.Data;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * MARK FOR DELETION
 * Created by Mayank Pandey on 6/14/2016.
 * This Action is adding multiple test and testpanel to multiple samples simultaneously  .
 * Updated tables are u_sample_testcode_map and u_sample_testcode_steps_map
 */
public class AddLvTestCode extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {
       /* String sampleids = properties.getProperty("s_sampleid");
        String lvtestcodes = properties.getProperty("lvtestcode");
        String ispanels = properties.getProperty("ispanel", "");
        String workitemflag = properties.getProperty("workitemflag");
        String[] samparr = StringUtil.split(sampleids, ";");
        String sampid = StringUtil.replaceAll(sampleids, ";", "','");
        String[] lvtestarr = StringUtil.split(lvtestcodes, ";");
        String t_code = StringUtil.replaceAll(lvtestcodes, ";", "','");
        String[] ispaneltarr = StringUtil.split(ispanels, ";");

        if (sampleids.length() == 0 || lvtestcodes.length() == 0) {
            String error = getTranslationProcessor().translate("Please select aleast a  Sample or TestCode");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (samparr.length != lvtestarr.length) {
            String error = getTranslationProcessor().translate("Matched PropertyList Expected !");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        DataSet dsProperties = new DataSet();
        dsProperties.addColumn("sampleids", DataSet.STRING);
        dsProperties.addColumn("lvtestcodes", DataSet.STRING);
        dsProperties.addColumn("ispanels", DataSet.STRING);
        int rowIncrement = 0;
        for (int i = 0; i < samparr.length; i++) {
            rowIncrement = dsProperties.addRow();
            dsProperties.setValue(rowIncrement, "sampleids", samparr[i]);
            dsProperties.setValue(rowIncrement, "lvtestcodes", lvtestarr[i]);
            dsProperties.setValue(rowIncrement, "ispanels", ispaneltarr[i]);
        }

// Extracting values from propertylist(Coming from front end)

        String sql_nyflag = "select distinct cl.nyflag from u_client cl,u_accession ac,s_sample s where s.u_accessionid =ac.u_accessionid" +
                " and ac.clientid=cl.u_clientid and s.s_sampleid  in('" + sampid + "')";
        String sql_nyapproval = "select nyapproval from u_testcode where u_testcodeid in ('" + t_code + "')";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql_nyflag);
        String nyflag = ds.getValue(0, "nyflag");
        DataSet ds1 = getQueryProcessor().getSqlDataSet(sql_nyapproval);
        String nyapproval = ds1.getValue(0, "nyapproval");
        if ((nyflag == "Y" && nyapproval != "Y")) {
            throw new SapphireException("NY Client can only add test codes whcih have NY Approval");
        }


        //Validation
        //  containerTypeValidation(dsProperties);
        //Calling methods
        DataSet sampleFiltered = new DataSet();
        HashMap hmFilter = new HashMap();
        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("ispanels", "Y");
        sampleFiltered = dsProperties.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            //  String[] tpsamparr = StringUtil.split(sampleFiltered.getColumnValues("sampleids", ";"), ";");
            addSampleTestPanelMap(sampleFiltered);
        }

        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("ispanels", "N");
        sampleFiltered = dsProperties.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            // String[] tpsamparr = StringUtil.split(sampleFiltered.getColumnValues("sampleids", ";"), ";");
            addSampleTestCodesMap(sampleFiltered);
            addSampleStepsMap(sampleFiltered);
        }
        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("ispanels", "");
        sampleFiltered = dsProperties.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            //  String[] tpsamparr = StringUtil.split(sampleFiltered.getColumnValues("sampleids", ";"), ";");
            addSampleTestCodesMap(sampleFiltered);
            addSampleStepsMap(sampleFiltered);
        }
*/
    }


    /*private void containerTypeValidation(DataSet hmSample) throws SapphireException {
        QueryProcessor qp = getQueryProcessor();
        for (int i = 0; i < hmSample.size(); i++) {


            String testmap_sql = "select * from trackitem where containertypeid=" +
                    "(select transporttype from u_testcode where u_testcodeid='" + hmSample.getValue(i, "lvtestcodes") + "') and linkkeyid1='" + hmSample.getValue(i, "sampleids") + "'";
            DataSet dsTestMap = qp.getSqlDataSet(testmap_sql);

            if (dsTestMap.size() == 0) {
                String error = getTranslationProcessor().translate("TestcodeID " + hmSample.getValue(i, "lvtestcodes") + " Containertype and SampleID " + hmSample.getValue(i, "sampleids") + " Containertype mismatch ! ");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }


    private void addSampleTestPanelMap(DataSet hmSample) throws SapphireException {
        String testpanel = hmSample.getColumnValues("lvtestcodes", ";");
        String tcode = StringUtil.replaceAll(testpanel, ";", "','");
        ActionProcessor ap = getActionProcessor();
        QueryProcessor qp = getQueryProcessor();
        String sampid = hmSample.getColumnValues("sampleids", ";");
        sampid = StringUtil.replaceAll(sampid, ";", "','");
        String sample_sql = "select  distinct ti.containertypeid,ti.custodialdepartmentid,s.sampletypeid " +
                "from trackitem ti,s_sample s where ti.linkkeyid1=s.s_sampleid and ti.linkkeyid1 in ('" + sampid + "')";
        DataSet dsSamp = qp.getSqlDataSet(sample_sql);
        if (dsSamp.size() > 1) {
            String error = getTranslationProcessor().translate("Recieving Location must be same for all sampleis.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsSamp == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += sample_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String transporttype = dsSamp.getValue(0, "containertypeid", "");
        String receivingloc = dsSamp.getValue(0, "custodialdepartmentid", "");
        String specimentypeid = dsSamp.getValue(0, "sampletypeid", "");
        //Fetching values from database
        String testmap_sql = "select tp.indtestcodeid,tp.u_testcodeid,tl.transporttype,tl.receivingloc,tl.performingloc, " +
                "(select testname from u_testcode where u_testcodeid=tp.indtestcodeid) testname,  " +
                "(select methodology from u_testcode where u_testcodeid=tp.indtestcodeid) methodology,  " +
                " (select los from u_testcode where u_testcodeid=tp.indtestcodeid) los,  " +
                " (select specimentype from u_testcode where u_testcodeid=tp.indtestcodeid) specimentype,  " +
                " (select extractiontype from u_testcode where u_testcodeid=tp.indtestcodeid) extractiontype,  " +
                " (select isnormal from u_testcode where u_testcodeid=tp.indtestcodeid) isnormal,  " +
                " (select molecularsubmethodology from u_testcode where u_testcodeid=tp.indtestcodeid) molecularsubmethodology,  " +
                "(select nyapproval from u_testcode where u_testcodeid=tp.indtestcodeid) nyapproval,  " +
                "(select heslides from u_testcode where u_testcodeid=tp.indtestcodeid) heslides,  " +
                "(select unstainedslides from u_testcode where u_testcodeid=tp.indtestcodeid) unstainedslides,  " +
                "(select backupslides from u_testcode where u_testcodeid=tp.indtestcodeid) backupslides,  " +
                "                 tc.ispanel " +
                " from u_testcode tc,u_testcode_location tl,u_testcodepanelmap tp " +
                "where   tp.indtestcodeid=tc.u_testcodeid and tc.u_testcodeid=tl.u_testcodeid " +
                "and tp.u_testcodeid in('" + tcode + "') and tl.receivingloc='" + receivingloc + "' and tl.transporttype='" + transporttype + "' and tc.specimentype='" + specimentypeid + "'";
        DataSet dsTestMap = qp.getSqlDataSet(testmap_sql);


        if (dsTestMap == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += testmap_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsTestMap.size() == 0) {
            String error = getTranslationProcessor().translate("TestCode Container Type and Receiving Location is not same as Samples or There isn't any Test in  panelid:  " + testpanel);
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsTestMap.size() > 0) {
            int rowIncrement = 0;
            DataSet dsPreAddDetail = new DataSet();
            dsPreAddDetail.addColumn("sampleid", DataSet.STRING);
            dsPreAddDetail.addColumn("lvtestcodeid", DataSet.STRING);
            dsPreAddDetail.addColumn("lvtestpanelid", DataSet.STRING);
            dsPreAddDetail.addColumn("testname", DataSet.STRING);
            dsPreAddDetail.addColumn("methodology", DataSet.STRING);
            dsPreAddDetail.addColumn("ispanel", DataSet.STRING);
            dsPreAddDetail.addColumn("los", DataSet.STRING);
            dsPreAddDetail.addColumn("specimentype", DataSet.STRING);
            dsPreAddDetail.addColumn("extractiontype", DataSet.STRING);
            dsPreAddDetail.addColumn("isnormal", DataSet.STRING);
            dsPreAddDetail.addColumn("molecularsubmethodology", DataSet.STRING);
            dsPreAddDetail.addColumn("transporttype", DataSet.STRING);
            dsPreAddDetail.addColumn("receivinglocation", DataSet.STRING);
            dsPreAddDetail.addColumn("performinglocation", DataSet.STRING);
            dsPreAddDetail.addColumn("nyapproval", DataSet.STRING);
            dsPreAddDetail.addColumn("heslides", DataSet.STRING);
            dsPreAddDetail.addColumn("unstainedslides", DataSet.STRING);
            dsPreAddDetail.addColumn("backupslides", DataSet.STRING);
            dsPreAddDetail.addColumn("testversion", DataSet.STRING);
            dsPreAddDetail.addColumn("clienttestcodeid", DataSet.STRING);

            DataSet testcodeFiltered = new DataSet();
            HashMap hmFilter = new HashMap();

            for (int y = 0; y < hmSample.size(); y++) {

                hmFilter.clear();
                testcodeFiltered.clear();
                hmFilter.put("u_testcodeid", hmSample.getValue(y, "lvtestcodes"));
                testcodeFiltered = dsTestMap.getFilteredDataSet(hmFilter);

                testcodeFiltered.sort("los");
                DataSet alDS = new DataSet();
                ArrayList alTestcode = testcodeFiltered.getGroupedDataSets("los");
                for (int i = 0; i < alTestcode.size(); i++) {
                    alDS.clear();
                    alDS = (DataSet) alTestcode.get(i);
                    String uniqueindtc = Util.getUniqueList(alDS.getColumnValues("indtestcodeid", ";"), ";", true);
                    if (uniqueindtc.split(";").length > 1) {
// Calling AddSDIDetail action to update sample_testcode_map with multiple sample and multiple testcode


                        for (int x = 0; x < alDS.getRowCount(); x++) {
                            rowIncrement = dsPreAddDetail.addRow();
                            dsPreAddDetail.setValue(rowIncrement, "sampleid", hmSample.getValue(y, "sampleids"));
                            dsPreAddDetail.setValue(rowIncrement, "lvtestcodeid", alDS.getValue(x, "indtestcodeid"));
                            dsPreAddDetail.setValue(rowIncrement, "lvtestpanelid", alDS.getValue(x, "u_testcodeid"));
                            dsPreAddDetail.setValue(rowIncrement, "testname", alDS.getValue(x, "testname"));
                            dsPreAddDetail.setValue(rowIncrement, "methodology", alDS.getValue(x, "methodology"));
                            dsPreAddDetail.setValue(rowIncrement, "ispanel", alDS.getValue(x, "ispanel"));
                            dsPreAddDetail.setValue(rowIncrement, "los", alDS.getValue(x, "los"));
                            dsPreAddDetail.setValue(rowIncrement, "specimentype", alDS.getValue(x, "specimentype"));
                            dsPreAddDetail.setValue(rowIncrement, "extractiontype", alDS.getValue(x, "extractiontype"));
                            dsPreAddDetail.setValue(rowIncrement, "isnormal", alDS.getValue(x, "isnormal"));
                            dsPreAddDetail.setValue(rowIncrement, "molecularsubmethodology", alDS.getValue(x, "molecularsubmethodology"));
                            dsPreAddDetail.setValue(rowIncrement, "transporttype", alDS.getValue(x, "transporttype"));
                            dsPreAddDetail.setValue(rowIncrement, "receivinglocation", alDS.getValue(x, "receivingloc"));
                            dsPreAddDetail.setValue(rowIncrement, "performinglocation", alDS.getValue(x, "performingloc"));
                            dsPreAddDetail.setValue(rowIncrement, "nyapproval", alDS.getValue(x, "nyapproval"));
                            dsPreAddDetail.setValue(rowIncrement, "heslides", alDS.getValue(x, "heslides"));
                            dsPreAddDetail.setValue(rowIncrement, "unstainedslides", alDS.getValue(x, "unstainedslides"));
                            dsPreAddDetail.setValue(rowIncrement, "backupslides", alDS.getValue(x, "backupslides"));
                            dsPreAddDetail.setValue(rowIncrement, "testversion", alDS.getValue(x, "testversion"));
                            dsPreAddDetail.setValue(rowIncrement, "clienttestcodeid", alDS.getValue(x, "clienttestcodeid"));
                            dsPreAddDetail.showData();
                        }
                    }
                }
            }
            if (dsPreAddDetail.size() > 0) {
                PropertyList addDetailprop = new PropertyList();
                addDetailprop.clear();

                addDetailprop.setProperty(AddSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                addDetailprop.setProperty(AddSDI.PROPERTY_COPIES, "" + dsPreAddDetail.size());
                addDetailprop.setProperty("s_sampleid", dsPreAddDetail.getColumnValues("sampleid", ";"));
                addDetailprop.setProperty("lvtestcodeid", dsPreAddDetail.getColumnValues("lvtestcodeid", ";"));
                addDetailprop.setProperty("testname", dsPreAddDetail.getColumnValues("testname", ";"));
                addDetailprop.setProperty("lvtestpanelid", dsPreAddDetail.getColumnValues("lvtestpanelid", ";"));
                addDetailprop.setProperty("methodology", dsPreAddDetail.getColumnValues("methodology", ";"));
                addDetailprop.setProperty("ispanel", "Y");
                addDetailprop.setProperty("los", dsPreAddDetail.getColumnValues("los", ";"));
                addDetailprop.setProperty("specimentypeid", dsPreAddDetail.getColumnValues("specimentype", ";"));
                addDetailprop.setProperty("extractiontype", dsPreAddDetail.getColumnValues("extractiontype", ";"));
                addDetailprop.setProperty("isnormal", dsPreAddDetail.getColumnValues("isnormal", ";"));
                addDetailprop.setProperty("molecularsubmethodology", dsPreAddDetail.getColumnValues("molecularsubmethodology", ";"));
                addDetailprop.setProperty("transporttypeid", dsPreAddDetail.getColumnValues("transporttype", ";"));
                addDetailprop.setProperty("receivinglocation", dsPreAddDetail.getColumnValues("receivinglocation", ";"));
                addDetailprop.setProperty("performinglocation", dsPreAddDetail.getColumnValues("performinglocation", ";"));
                addDetailprop.setProperty("nyapproval", dsPreAddDetail.getColumnValues("nyapproval", ";"));
                addDetailprop.setProperty("heslides", dsPreAddDetail.getColumnValues("heslides", ";"));
                addDetailprop.setProperty("unstainedslides", dsPreAddDetail.getColumnValues("unstainedslides", ";"));
                addDetailprop.setProperty("backupslides", dsPreAddDetail.getColumnValues("backupslides", ";"));


                try {
                    ap.processAction(AddSDI.ID, AddSDI.VERSIONID, addDetailprop);

                } catch (ActionException ex) {
                    String error = getTranslationProcessor().translate("TestPanel is already assigned !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

                }

            } else {
                String error = getTranslationProcessor().translate("No matching TestCode found");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }

    private void addSampleTestCodesMap(DataSet hmSample) throws SapphireException {
        ActionProcessor ap = getActionProcessor();
        QueryProcessor qp = getQueryProcessor();
        String sampid = hmSample.getColumnValues("sampleids", ";");
        sampid = StringUtil.replaceAll(sampid, ";", "','");
        String sample_sql = "select  distinct ti.containertypeid,ti.custodialdepartmentid,s.sampletypeid " +
                "from trackitem ti,s_sample s where ti.linkkeyid1=s.s_sampleid and ti.linkkeyid1 in ('" + sampid + "')";
        DataSet dsSamp = qp.getSqlDataSet(sample_sql);
        if (dsSamp.size() > 1) {
            String error = getTranslationProcessor().translate("Recieving Location must be same for all sampleis.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsSamp == null) {
            String error = getTranslationProcessor().translate("There isn't any trackitem for selected Samples");
            error += sample_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String containertypeid = dsSamp.getValue(0, "containertypeid", "");
        String custodialdepartmentid = dsSamp.getValue(0, "custodialdepartmentid", "");
        String sampletypeid = dsSamp.getValue(0, "sampletypeid", "");

        String testcode = hmSample.getColumnValues("lvtestcodes", ";");
        String tcode = StringUtil.replaceAll(testcode, ";", "','");
        //Fetching values from database
        String testmap_sql = "select tc.u_testcodeid,tc.testname,tc.methodology,tc.ispanel,tc.los,tc.extractiontype,tc.isnormal,tc.molecularsubmethodology,tc.specimentype," +
                "tl.transporttype,tl.receivingloc,tl.performingloc," +
                " tc.nyapproval,tc.heslides,tc.unstainedslides,tc.backupslides,tc.testversion" +
                " ,clienttestcodeid from u_testcode tc ,u_testcode_location tl where tc.u_testcodeid=tl.u_testcodeid and " +
                " tc.u_testcodeid in ('" + tcode + "')" +
                " and tl.transporttype='" + containertypeid + "' and tl.receivingloc='" + custodialdepartmentid + "' and tc.SPECIMENTYPE='" + sampletypeid + "'";
        DataSet dsTestMap = qp.getSqlDataSet(testmap_sql);

        if (dsTestMap == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += testmap_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsTestMap.size() == 0) {
            String error = getTranslationProcessor().translate("TestCode Container Type and Receiving Location must be same as Samples.");
            error += testmap_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

// Calling AddSDIDetail action to update sample_testcode_map with multiple sample and multiple testcode
        if (dsTestMap.size() > 0) {
            int rowIncrement = 0;
            DataSet dsPreAddDetail = new DataSet();
            dsPreAddDetail.addColumn("sampleid", DataSet.STRING);
            dsPreAddDetail.addColumn("lvtestcodeid", DataSet.STRING);
            dsPreAddDetail.addColumn("testname", DataSet.STRING);
            dsPreAddDetail.addColumn("methodology", DataSet.STRING);
            dsPreAddDetail.addColumn("ispanel", DataSet.STRING);
            dsPreAddDetail.addColumn("los", DataSet.STRING);
            dsPreAddDetail.addColumn("specimentype", DataSet.STRING);
            dsPreAddDetail.addColumn("extractiontype", DataSet.STRING);
            dsPreAddDetail.addColumn("isnormal", DataSet.STRING);
            dsPreAddDetail.addColumn("molecularsubmethodology", DataSet.STRING);
            dsPreAddDetail.addColumn("transporttype", DataSet.STRING);
            dsPreAddDetail.addColumn("receivinglocation", DataSet.STRING);
            dsPreAddDetail.addColumn("performinglocation", DataSet.STRING);
            dsPreAddDetail.addColumn("nyapproval", DataSet.STRING);
            dsPreAddDetail.addColumn("heslides", DataSet.STRING);
            dsPreAddDetail.addColumn("unstainedslides", DataSet.STRING);
            dsPreAddDetail.addColumn("backupslides", DataSet.STRING);
            dsPreAddDetail.addColumn("testversion", DataSet.STRING);
            dsPreAddDetail.addColumn("clienttestcodeid", DataSet.STRING);

            DataSet testcodeFiltered = new DataSet();
            HashMap hmFilter = new HashMap();

            for (int y = 0; y < hmSample.size(); y++) {

                hmFilter.clear();
                testcodeFiltered.clear();
                hmFilter.put("u_testcodeid", hmSample.getValue(y, "lvtestcodes"));
                testcodeFiltered = dsTestMap.getFilteredDataSet(hmFilter);

                rowIncrement = dsPreAddDetail.addRow();
                dsPreAddDetail.setValue(rowIncrement, "sampleid", hmSample.getValue(y, "sampleids"));
                dsPreAddDetail.setValue(rowIncrement, "lvtestcodeid", testcodeFiltered.getValue(0, "u_testcodeid"));
                dsPreAddDetail.setValue(rowIncrement, "testname", testcodeFiltered.getValue(0, "testname"));
                dsPreAddDetail.setValue(rowIncrement, "methodology", testcodeFiltered.getValue(0, "methodology"));
                dsPreAddDetail.setValue(rowIncrement, "ispanel", testcodeFiltered.getValue(0, "ispanel"));
                dsPreAddDetail.setValue(rowIncrement, "los", testcodeFiltered.getValue(0, "los"));
                dsPreAddDetail.setValue(rowIncrement, "specimentype", testcodeFiltered.getValue(0, "specimentype"));
                dsPreAddDetail.setValue(rowIncrement, "extractiontype", testcodeFiltered.getValue(0, "extractiontype"));
                dsPreAddDetail.setValue(rowIncrement, "isnormal", testcodeFiltered.getValue(0, "isnormal"));
                dsPreAddDetail.setValue(rowIncrement, "molecularsubmethodology", testcodeFiltered.getValue(0, "molecularsubmethodology"));
                dsPreAddDetail.setValue(rowIncrement, "transporttype", dsTestMap.getValue(0, "transporttype"));
                dsPreAddDetail.setValue(rowIncrement, "receivinglocation", dsTestMap.getValue(0, "receivingloc"));
                dsPreAddDetail.setValue(rowIncrement, "performinglocation", dsTestMap.getValue(0, "performingloc"));
                dsPreAddDetail.setValue(rowIncrement, "nyapproval", testcodeFiltered.getValue(0, "nyapproval"));
                dsPreAddDetail.setValue(rowIncrement, "heslides", testcodeFiltered.getValue(0, "heslides"));
                dsPreAddDetail.setValue(rowIncrement, "unstainedslides", testcodeFiltered.getValue(0, "unstainedslides"));
                dsPreAddDetail.setValue(rowIncrement, "backupslides", testcodeFiltered.getValue(0, "backupslides"));
                dsPreAddDetail.setValue(rowIncrement, "testversion", testcodeFiltered.getValue(0, "testversion"));
                dsPreAddDetail.setValue(rowIncrement, "clienttestcodeid", testcodeFiltered.getValue(0, "clienttestcodeid"));
                dsPreAddDetail.showData();

            }
            dsPreAddDetail.showData();
            PropertyList addDetailprop = new PropertyList();
            addDetailprop.clear();


            addDetailprop.setProperty(AddSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            addDetailprop.setProperty(AddSDI.PROPERTY_COPIES, "" + dsPreAddDetail.size());
            addDetailprop.setProperty("s_sampleid", dsPreAddDetail.getColumnValues("sampleid", ";"));
            addDetailprop.setProperty("lvtestcodeid", dsPreAddDetail.getColumnValues("lvtestcodeid", ";"));
            addDetailprop.setProperty("testname", dsPreAddDetail.getColumnValues("testname", ";"));
            addDetailprop.setProperty("methodology", dsPreAddDetail.getColumnValues("methodology", ";"));
            addDetailprop.setProperty("ispanel", dsPreAddDetail.getColumnValues("ispanel", ";"));
            addDetailprop.setProperty("los", dsPreAddDetail.getColumnValues("los", ";"));
            addDetailprop.setProperty("specimentypeid", dsPreAddDetail.getColumnValues("specimentype", ";"));
            addDetailprop.setProperty("extractiontype", dsPreAddDetail.getColumnValues("extractiontype", ";"));
            addDetailprop.setProperty("isnormal", dsPreAddDetail.getColumnValues("isnormal", ";"));
            addDetailprop.setProperty("molecularsubmethodology", dsPreAddDetail.getColumnValues("molecularsubmethodology", ";"));
            addDetailprop.setProperty("transporttypeid", dsPreAddDetail.getColumnValues("transporttype", ";"));
            addDetailprop.setProperty("receivinglocation", dsPreAddDetail.getColumnValues("receivinglocation", ";"));
            addDetailprop.setProperty("performinglocation", dsPreAddDetail.getColumnValues("performinglocation", ";"));
            addDetailprop.setProperty("nyapproval", dsPreAddDetail.getColumnValues("nyapproval", ";"));
            addDetailprop.setProperty("heslides", dsPreAddDetail.getColumnValues("heslides", ";"));
            addDetailprop.setProperty("unstainedslides", dsPreAddDetail.getColumnValues("unstainedslides", ";"));
            addDetailprop.setProperty("backupslides", dsPreAddDetail.getColumnValues("backupslides", ";"));

            try {
                ap.processAction(AddSDI.ID, AddSDI.VERSIONID, addDetailprop);

            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Testcode is already assigned !");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

            }

        }
    }

    private void addSampleStepsMap(DataSet hmSample) throws SapphireException {
        String testcode = hmSample.getColumnValues("lvtestcodes", ";");
        String tcode = StringUtil.replaceAll(testcode, ";", "','");
        ActionProcessor ap = getActionProcessor();
        QueryProcessor qp = getQueryProcessor();
        //Fetching values from database
        String stepmap_sql = "select u_testcodeid,stepno,stepname from u_testcode_steps where u_testcodeid in ('" + tcode + "')";
        DataSet dsStepMap = qp.getSqlDataSet(stepmap_sql);

        if (dsStepMap == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += stepmap_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
//Calling AddSDIDetail action to update sample_testcode_step_map with multiple sample and multiple testcode
        if (dsStepMap.size() > 0) {
            int rowIncrement = 0;
            DataSet preAddDetail = new DataSet();
            preAddDetail.addColumn("sampleid", DataSet.STRING);
            preAddDetail.addColumn("lvtestcode", DataSet.STRING);
            preAddDetail.addColumn("stepname", DataSet.STRING);
            preAddDetail.addColumn("stepno", DataSet.STRING);

            DataSet teststepFiltered = new DataSet();
            HashMap hmFilter = new HashMap();

            for (int y = 0; y < hmSample.size(); y++) {
                hmFilter.clear();
                teststepFiltered.clear();
                hmFilter.put("u_testcodeid", hmSample.getValue(y, "lvtestcodes"));
                teststepFiltered = dsStepMap.getFilteredDataSet(hmFilter);

                for (int x = 0; x < teststepFiltered.getRowCount(); x++) {
                    rowIncrement = preAddDetail.addRow();
                    preAddDetail.setValue(rowIncrement, "sampleid", hmSample.getValue(y, "sampleids"));
                    preAddDetail.setValue(rowIncrement, "lvtestcode", teststepFiltered.getValue(x, "u_testcodeid"));
                    preAddDetail.setValue(rowIncrement, "stepname", teststepFiltered.getValue(x, "stepname"));
                    preAddDetail.setValue(rowIncrement, "stepno", teststepFiltered.getValue(x, "stepno"));
                    preAddDetail.showData();

                }
            }
            PropertyList addDetailprop = new PropertyList();
            addDetailprop.clear();

            *//*addDetailprop.setProperty("sdcid", "Sample");
            addDetailprop.setProperty("keyid1", "s_sampleid");
            addDetailprop.setProperty("keyid2", "lvtestcode");
            addDetailprop.setProperty("s_sampleid", preAddDetail.getColumnValues("sampleid", ";"));
            addDetailprop.setProperty("lvtestcode", preAddDetail.getColumnValues("lvtestcode", ";"));
            addDetailprop.setProperty("linkid", "u_sample_tcode_stp_map_link");
            addDetailprop.setProperty("stepname", preAddDetail.getColumnValues("stepname", ";"));
            addDetailprop.setProperty("stepno", preAddDetail.getColumnValues("stepno", ";"));*//*//TODO CHANGED IT TO NEW SDC
            addDetailprop.setProperty("sdcid", "SampleTestcodeStpMap");
            addDetailprop.setProperty("s_sampleid", preAddDetail.getColumnValues("sampleid", ";"));
            addDetailprop.setProperty("lvtestcode", preAddDetail.getColumnValues("lvtestcode", ";"));
            addDetailprop.setProperty("stepname", preAddDetail.getColumnValues("stepname", ";"));
            addDetailprop.setProperty("stepno", preAddDetail.getColumnValues("stepno", ";"));


            try {

                ap.processAction("AddSDI", "1", addDetailprop);

            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("May be Testcode or Steps are already assigned");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

            }

        }
    }*/
}
