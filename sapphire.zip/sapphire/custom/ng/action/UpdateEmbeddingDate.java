package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by SBaitalik on 8/17/2017.
 */
public class UpdateEmbeddingDate extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleid");
        String inputdate = properties.getProperty("inputdate");
        String updatetype = properties.getProperty("updatetype");//U_TRANSFERTODATE
        if ("TransferTo".equalsIgnoreCase(updatetype)) {
            String sql = Util.parseMessage(ApSql.GET_RECEIVED_FROM_DATE_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsReceivdFrm = getQueryProcessor().getSqlDataSet(sql);
            if (dsReceivdFrm != null && dsReceivdFrm.size() > 0) {
                SimpleDateFormat sdfr = new SimpleDateFormat("MM/dd/yy");
                Date date = new Date();
                try {
                    Date crrntDt = sdfr.parse(sdfr.format(date));
                    Date validateinputdt = sdfr.parse(inputdate);
                    if (validateinputdt.after(crrntDt)) {
                        throw new SapphireException("<b>Transfer To date</b> cannot be a future date.It can be same date or past date.");
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                /*for (int i = 0; i < dsReceivdFrm.size(); i++) {
                    if (!Util.isNull(dsReceivdFrm.getValue(i, "u_receivedfromdate", ""))) {
                        String recvdFrmDt = dsReceivdFrm.getValue(i, "u_receivedfromdate", "").substring(0, 7).trim();
                        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
                        try {

                            Date dateRecvtFrmDt = sdf.parse(recvdFrmDt);
                            Date dateTransferDtTo = sdf.parse(inputdate);
                            if (dateRecvtFrmDt.before(dateTransferDtTo)) {
                                throw new SapphireException("<b>Transfer To date</b> should always be before the <b>Received date</b>.");
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }*/

            }
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
            props.setProperty("u_transfertodate", StringUtil.repeat(inputdate, (StringUtil.split(sampleids, ";")).length, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception se) {
                throw new SapphireException("EditSDI failed.");
            }
        } else {
            String sql = Util.parseMessage(ApSql.GET_RECEIVED_FROM_DATE_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsTransferedToDt = getQueryProcessor().getSqlDataSet(sql);
            if (dsTransferedToDt != null && dsTransferedToDt.size() > 0) {
                SimpleDateFormat sdfr = new SimpleDateFormat("MM/dd/yy");
                Date date = new Date();
                try {
                    Date crrntDt = sdfr.parse(sdfr.format(date));
                    Date validateinputdt = sdfr.parse(inputdate);
                    /*if (validateinputdt.before(crrntDt)) {
                        throw new SapphireException("<b>Received From date</b> cannot be a past date .It can be same date or future date.");
                    }*/
                  //added validation
                	for(int i=0;i<dsTransferedToDt.size();i++){
                		String transferdate=dsTransferedToDt.getValue(i, "u_transfertodate");
                		Date trdt=sdfr.parse(transferdate);
                		if (validateinputdt.before(trdt) ||  validateinputdt.after(crrntDt)) {
                            throw new SapphireException("<b>Received From date</b> can be the same as <b>Transfer To date</b>, greater than <b>Transfer To date</b>, or today's date.");
                        }
                	}
                	//
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                /*for (int i = 0; i < dsTransferedToDt.size(); i++) {
                    if (!Util.isNull(dsTransferedToDt.getValue(i, "u_transfertodate", ""))) {
                        String transferToDt = dsTransferedToDt.getValue(i, "u_transfertodate", "").substring(0, 7).trim();
                        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
                        try {
                            Date dateTransferdToDt = sdf.parse(transferToDt);
                            Date dateRcvdFrmDt = sdf.parse(inputdate);

                            if (dateRcvdFrmDt.before(dateTransferdToDt)) {
                                throw new SapphireException("<b>Received From date</b> should always be after the <b>Transfer To date</b>.");
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    } else {
                        throw new SapphireException("You need to provide <b>Transfer To Date</b> first.");
                    }
                }*/

            }
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
            props.setProperty("u_receivedfromdate", StringUtil.repeat(inputdate, (StringUtil.split(sampleids, ";")).length, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception se) {
                throw new SapphireException("EditSDI failed.");
            }
        }
    }
}
