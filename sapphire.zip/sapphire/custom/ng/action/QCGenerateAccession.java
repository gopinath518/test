package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by SBaitalik on 5/8/2017.
 * This action is used to QC and Generate Acction for Bio-Phrama.
 */
public class QCGenerateAccession extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid", "");
        //CHECK IF THERE HAVE ANY PENDING SAMPLE
        validatePendingSample(accessionid);
        String sql = Util.parseMessage(ApSql.GET_ACCESSION_INFO_BY_ACCESSIONID, accessionid);
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        String checkstoragesamplesql = Util.parseMessage(AccessionPageSql.GET_STORAGE_SAMPLE_BY_ACCESSION_SQL, accessionid);
        DataSet dsCheckStorageSample = getQueryProcessor().getSqlDataSet(checkstoragesamplesql);
        if (dsCheckStorageSample != null && dsCheckStorageSample.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < dsCheckStorageSample.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", dsCheckStorageSample.getValue(i, "linkkeyid1", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", dsCheckStorageSample.getValue(i, "labelpath", ""));
            }
            String errCodes = "Unable to proceed because below specimens(s) are in storage. Please check-out first.";
            errCodes += Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errCodes);

        }
        if (dsInfo == null || dsInfo.size() == 0) {
            throw new SapphireException("Invalid accession");
        }
        String status = dsInfo.getValue(0, "status", "");
        if ("In Progress- QC Failed".equalsIgnoreCase(status)) {
            throw new SapphireException("Accession is in QC Failed state, you can't proceed further.");
        }

        //CALL BREAST FIXATION ACTION
        PropertyList prop = new PropertyList();
        prop.setProperty("accessionid", accessionid);
        try {
            getActionProcessor().processAction(BreastFixation.ID, BreastFixation.VERSION_ID, prop);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("error >>  Something went wrong while doing Breast Fixation.");
            error += ex.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        prop.clear();
        prop.setProperty("accessionid", accessionid);
        try {
            getActionProcessor().processAction(SampleMovement.ID, SampleMovement.VERSION_ID, prop);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("error >> Something went wrong while doing Sample Movement.");
            error += ex.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        clearPageLocking(properties);
        properties.setProperty("msg", prop.getProperty("msg", ""));

        //populate the test ordered for FISH.
        freezeOrderedTests(accessionid);

    }

    private void clearPageLocking(PropertyList props) throws SapphireException {
        String accessionid = props.getProperty("accessionid", "");
        PropertyList prop = new PropertyList();
        prop.setProperty("keyid1", accessionid);
        prop.setProperty("typeaction", "CL");
        try {
            getActionProcessor().processAction("CreateAccessionRSet", "1", prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to clear locking.");
        }
    }

    /**
     * This function is specific to FISH
     *
     * @param accessionID
     * @throws SapphireException
     */
    private void freezeOrderedTests(String accessionID) throws SapphireException {

        String sql = Util.parseMessage(ApSql.GET_TEST_INFO_BY_ACCESSIONID, accessionID);

        DataSet dsSampleTestCodes = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleTestCodes == null && dsSampleTestCodes.size() == 0) {
            //if the test code is not belong to FISH then it will not execute rest of the code.
            return;
        }
        dsSampleTestCodes.addColumn("addsdiflag", DataSet.STRING);

        String allLVTestCode = Util.getUniqueList(dsSampleTestCodes.getColumnValues("lvtestcodeid", ";"), ";", true);
        String[] allLVTestCodeArr = StringUtil.split(allLVTestCode, ";");

        HashMap hm = new HashMap();

        for (String str : allLVTestCodeArr) {
            hm.clear();
            hm.put("lvtestcodeid", str);

            DataSet dsFilter = dsSampleTestCodes.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                dsFilter.setValue(0, "addsdiflag", "Y");
            }
        }

        hm.clear();
        hm.put("addsdiflag", "Y");
        DataSet dsFilterTests = dsSampleTestCodes.getFilteredDataSet(hm);
        if (dsFilterTests == null || dsFilterTests.size() == 0) {
            return;
        }
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "TestOrdered");
        pl.setProperty("accessionid", dsFilterTests.getColumnValues("u_accessionid", ";"));
        pl.setProperty("lvtestcodeid", dsFilterTests.getColumnValues("lvtestcodeid", ";"));
        pl.setProperty("lvpanelcodeid", dsFilterTests.getColumnValues("lvtestpanelid", ";"));
        //pl.setProperty("sampleid", dsFilterTests.getColumnValues("s_sampleid", ";"));
        pl.setProperty("copies", "" + dsFilterTests.size());

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        //if the samples are stained slide /unstaineed slide then blankout the lvtest and populate U_FISHSLIDETEST

        tagChildSlideWithTest(dsSampleTestCodes);


    }

    private void tagChildSlideWithTest(DataSet dsSampleTestCodes) throws SapphireException {


        //1. find the samples which are slide.
        dsSampleTestCodes.addColumn("isslide", DataSet.STRING);
        for (int i = 0; i < dsSampleTestCodes.getRowCount(); i++) {
            String u_type = dsSampleTestCodes.getValue(i, "u_type", "");
            if (u_type.equalsIgnoreCase("CU") || u_type.equalsIgnoreCase("CST")) {
                dsSampleTestCodes.setValue(i, "isslide", "Y");
            }
        }

        HashMap hm = new HashMap();
        hm.clear();
        hm.put("isslide", "Y");
        DataSet dsFilterSlides = dsSampleTestCodes.getFilteredDataSet(hm);
        if (dsFilterSlides == null || dsFilterSlides.size() == 0) {
            return;
        }

        PropertyList p = new PropertyList();
        p.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        p.setProperty("keyid1", dsFilterSlides.getColumnValues("u_sampletestcodemapid", ";"));
        p.setProperty("lvtestcodeid", StringUtil.repeat("", dsFilterSlides.getRowCount(), ";"));
        p.setProperty("testcode", StringUtil.repeat("", dsFilterSlides.getRowCount(), ";"));
        p.setProperty("testname", StringUtil.repeat("", dsFilterSlides.getRowCount(), ";"));
        getActionProcessor().processAction(com.labvantage.sapphire.actions.sdi.EditSDI.ID, com.labvantage.sapphire.actions.sdi.EditSDI.VERSIONID, p);

        DataSet dsSample = new DataSet();
        dsSample.addColumn("sampleid", DataSet.STRING);
        dsSample.addColumn("teststring", DataSet.STRING);
        ArrayList dsGroupBySlideArray = dsFilterSlides.getGroupedDataSets("s_sampleid");
        for (int i = 0; i < dsGroupBySlideArray.size(); i++) {

            DataSet dsIndividualSlideGroup = (DataSet) dsGroupBySlideArray.get(i);
            if (dsIndividualSlideGroup == null || dsIndividualSlideGroup.size() == 0) {
                continue;
            }

            String panelCode = Util.getUniqueList(dsIndividualSlideGroup.getColumnValues("lvtestpanelid", ";"), ";", true);
            String testCode = Util.getUniqueList(dsIndividualSlideGroup.getColumnValues("lvtestcodeid", ";"), ";", true);
            String sampleID = Util.getUniqueList(dsIndividualSlideGroup.getColumnValues("s_sampleid", ";"), ";", true);

            String panelCodeWithoutSemicolon = StringUtil.replaceAll(panelCode, ";", "");


            String updateStr = "";
            if ("".equalsIgnoreCase(panelCodeWithoutSemicolon)) {
                if (testCode.contains(";")) {
                    updateStr = "Multiple Tests";
                } else {
                    updateStr = "Single Test";
                }

            } else {
                if (panelCode.contains(";")) {
                    updateStr = "Multiple Panel";
                } else {
                    updateStr = "Single Panel";

                }
            }

            if (!"".equals(updateStr)) {
                int rowID = dsSample.addRow();
                dsSample.setValue(rowID, "sampleid", sampleID);
                dsSample.setValue(rowID, "teststring", updateStr);
            }
        }


        if (dsSample != null && dsSample.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty("keyid1", dsSample.getColumnValues("sampleid", ";"));
            pl.setProperty("u_fishslidetest", dsSample.getColumnValues("teststring", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

    }

    private void validatePendingSample(String accessionid) throws SapphireException {
        String sqlVal = Util.parseMessage(ApSql.GET_SAMPLE_BY_ACCESSIONID, accessionid);
        DataSet dsVal = getQueryProcessor().getSqlDataSet(sqlVal);
        if (dsVal != null && dsVal.size() == 0) {
            throw new SapphireException("<b>Accession does not have any specimen(s) or Specimen(s) is/are cancelled for an accession..</b>");
        }
        HashMap hmv = new HashMap();
        hmv.put("u_accessioningcomplete", "N");
        DataSet dsFilV = dsVal.getFilteredDataSet(hmv);
        if (dsFilV != null && dsFilV.size() == 0) {
            //throw new SapphireException("<b>There is no specimen(s) pending to QCed the accession.</b>");
            return;
        }
    }
}
