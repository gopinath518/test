package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;
import sapphire.custom.ng.sql.ap.ApSql;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by DMondal on 10/26/2016.
 * Modified by mghosh
 * Description : This action used for microtomy complete.It will fetch record from policy and create dataset with selected samples
 * and it will update Currentmovementstep with .
 */
public class MicrotomyComplete extends BaseAction {
    @Override

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("keyid1");
        DataSet dsCheckTests = checkTestcodeHas(sampleids);
        if (dsCheckTests == null) {
            throw new SapphireException("SQL failed. Please contact your administrator.");
        }
        if (dsCheckTests.size() == 0) {
            throw new SapphireException("No Test Code(s) associated with the selected sample(s). Please assign Test Code(s) with below sample(s).\n" + StringUtil.replaceAll(sampleids, ";", ", "));
        }
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleids);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        updateMicrotomyComment(properties, sampleids);
        initializeDataSet();
        DataSet dsPloicy = getPolicy();
        creatMainDs(sampleids, dsPloicy);
        checkSlideThickness();
        //routeShareHNEToTheDept();
        /**
         * POPULATE SLIDE SECTIONED DATE FOR SPECIAL TESTCODE(S) ON SLIDE(S)
         */
        //DataSet dsTestCodePolicy = getTestCodePolicy();//TODO WILL REMOVED AS THIS WILL TAKEN CARE FROM SDC AnalyteTcValidation
        DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
        if (dsTestCodePolicy.size() > 0) {
            checkSlideTestCode(dsTestCodePolicy, dsMain);
        }

        noMicrotomyCompleteForAV();
        String sql = "select s_sampleid from s_sample where s_sampleid in ('" + StringUtil.replaceAll(sampleids, ";", "','") + "') and u_iscut='N'";
        DataSet notPerform = getQueryProcessor().getSqlDataSet(sql);
        updateuCurrentmovementstep(notPerform);
        updateCustodian();
        //throw new SapphireException("test");
    }

    private void routeShareHNEToTheDept() throws SapphireException {
        HashMap hm = new HashMap();
        hm.clear();
        hm.put(DATASET_PROPERTY_TYPE, "SH");
        hm.put(DATASET_PROPERTY_METHODOLOGY, "Generic");
        DataSet dsShareHNEFilter = dsMain.getFilteredDataSet(hm);
        if (dsShareHNEFilter.size() > 0) {
            String sampleids = dsShareHNEFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";");
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty("sampleid", sampleids);
            try {
                getActionProcessor().processAction("IHCFlowCompleteStep", "1", props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to route sahre H&E." + ex.getMessage());
            }
        }
    }

    /**
     * This method is used for checking slide thickness. release 1.7.1
     *
     * @throws SapphireException
     */
    private void checkSlideThickness() throws SapphireException {
        String sample = StringUtil.replaceAll(dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"), ";", "','");
        //String sqlInfo = Util.parseMessage(CommonSql.GET_ALLSPECIMEN_FOR_SLIDETHICKNESS, sample, "");
        String sqlInfo = Util.parseMessage(CommonSql.GET_SPECIMEN_FOR_SLIDETHICKNESS, sample);
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sqlInfo);
        if (dsInfo == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlInfo;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsInfo.size() > 0) {
            String noThicknessSpecimen = "";
            for (int i = 0; i < dsInfo.size(); i++) {
                String sampleid = dsInfo.getValue(i, "s_sampleid", "");
                String thicknessval = dsInfo.getValue(i, "u_slidethickness", "");
                if ("".equalsIgnoreCase(thicknessval)) {
                    noThicknessSpecimen = noThicknessSpecimen + ";" + sampleid;
                }
            }
            if (noThicknessSpecimen.length() > 1) {
                if (noThicknessSpecimen.startsWith(";")) {
                    noThicknessSpecimen = noThicknessSpecimen.substring(1);
                }
                String errStr = getTranslationProcessor().translate("Please enter slide thickness before microtomy complete for the specimen:" + noThicknessSpecimen);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
    }

    private void checkSlideTestCode(DataSet dsTestCodePolicy, DataSet dsMain) throws SapphireException {
        DataSet dsSlideTestCode = new DataSet();
        dsSlideTestCode.addColumn("sampleid", DataSet.STRING);
        dsSlideTestCode.addColumn("slidetestcode", DataSet.STRING);
        dsSlideTestCode.addColumn("slidesctiondate", DataSet.STRING);
        dsSlideTestCode.addColumn("rootsampleid", DataSet.STRING);
        dsSlideTestCode.addColumn("testname", DataSet.STRING);
        for (int i = 0; i < dsMain.size(); i++) {
            String lvtestcode = dsMain.getValue(i, DATASET_PROPERTY_LVTESTCODEID, "");
            String sampleid = dsMain.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
            String rootsampleid = dsMain.getValue(i, DATASET_PROPERTY_ROOTSAMPLEID, "");
            String testname = dsMain.getValue(i, DATASET_PROPERTY_LVTESTNAME, "");
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("testcode", lvtestcode);
            DataSet dsFilter = dsTestCodePolicy.getFilteredDataSet(hm);

            if (dsFilter.size() > 0) {
                int incr = dsSlideTestCode.addRow();
                dsSlideTestCode.setValue(incr, "slidetestcode", lvtestcode);
                dsSlideTestCode.setValue(incr, "sampleid", sampleid);
                dsSlideTestCode.setValue(incr, "rootsampleid", rootsampleid);
                dsSlideTestCode.setValue(incr, "testname", testname);
            }

        }
        if (dsSlideTestCode.size() > 0) {

            String childslide = StringUtil.replaceAll(dsSlideTestCode.getColumnValues("sampleid", ";"), ";", "','");
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
            Date date = new Date();
            String crrntdt = formatter.format(date);
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsSlideTestCode.getColumnValues("sampleid", ";"));
            prop.setProperty("u_slidesectiondate", StringUtil.repeat("n", dsSlideTestCode.size(), ";"));
            //prop.setProperty("u_slidesectiondate", StringUtil.repeat(crrntdt.toUpperCase(), dsSlideTestCode.size(), ";"));

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ae) {
                String error = getTranslationProcessor().translate("Can't update date in child sample");
                error += ae.getMessage();
                throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
            }

            String testname = StringUtil.replaceAll(dsSlideTestCode.getColumnValues("testname", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_SDI_DATA_ITEM, childslide, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                props.setProperty("enteredtext", StringUtil.repeat(crrntdt.toUpperCase(), dsSqlEnterData.size(), ";"));
                props.setProperty("displayvalue", StringUtil.repeat(crrntdt.toUpperCase(), dsSqlEnterData.size(), ";"));

                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        }


    }

    /**
     * Description: Microtomy comment is incorporated if the no of slide does not matches in actual no of child completed.
     *
     * @param properties
     * @param selectedSamples
     * @throws SapphireException
     */
    private void updateMicrotomyComment(PropertyList properties, String selectedSamples) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_DISTINCT_PARENT_SAMPLE, StringUtil.replaceAll(selectedSamples, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        String blockId = Util.getUniqueList(dsSampleInfo.getColumnValues("parentsampleid", ";"), ";", true);
        if (Util.isNull(blockId)) {
            return;
        }

        String newComment = properties.getProperty("comment");
        String previouscommentSQL = Util.parseMessage(ApSql.PREVIOUS_COMMENT, StringUtil.replaceAll(blockId, ";", "','"));
        DataSet dsPreviousComment = getQueryProcessor().getSqlDataSet(previouscommentSQL);
        String previousCommentFromDB = dsPreviousComment.getValue(0, "u_microtomycomment", "");
        String finalComment = "";
        if (!newComment.equals("")) {
            finalComment = newComment + " --" + previousCommentFromDB;
        }

        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, blockId);
            props.setProperty("u_microtomycomment", finalComment);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    /**
     * Description : This method is used for update Currentmovementstep for selected samples.
     *
     * @throws SapphireException
     */
    private void updateuCurrentmovementstep(DataSet notPerform1) throws SapphireException {


        try {

            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
            props.setProperty("u_currentmovementstep", dsMain.getColumnValues(DATASET_PROPERTY_TRAMSTOP, ";"));
            props.setProperty("u_microtomycompleteflag", StringUtil.repeat("Y", dsMain.size(), ";"));
            props.setProperty("u_microtomycompletedt", StringUtil.repeat("n", dsMain.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            //---- All samples other than FISH --------
            // ------ For FISH Samples the physical samples will not move to fish but the labels alone will move FISH QC
            // --- For other methodologies sample will not move any where else
            // ---- FOR FISH methodology ISCut='N' is similar to QNS='Y'

            if (notPerform1.size() > 0) {

                notPerform1.addColumn("isfish", DataSet.STRING);
                notPerform1.addColumn("u_currentmovementstep", DataSet.STRING);
                notPerform1.addColumn("u_qns", DataSet.STRING);

                HashMap hmFilter = new HashMap();

                for (int i = 0; i < notPerform1.getRowCount(); i++) {
                    hmFilter.clear();
                    hmFilter.put("sampleid", notPerform1.getValue(i, "s_sampleid", ""));
                    hmFilter.put(DATASET_PROPERTY_METHODOLOGY, "FISH");

                    DataSet dsFishSample = dsMain.getFilteredDataSet(hmFilter);
                    if (dsFishSample != null && dsFishSample.getRowCount() > 0) {
                        notPerform1.setValue(i, "isfish", "Y");
                        notPerform1.setValue(i, "u_currentmovementstep", "Not Performed");
                        //notPerform1.setValue(i,"u_qns", "Y");

                    } else {
                        notPerform1.setValue(i, "isfish", "N");
                        notPerform1.setValue(i, "u_currentmovementstep", "Not Performed");
                        // notPerform1.setValue(i,"u_qns", "");

                    }
                }

                PropertyList props1 = new PropertyList();
                props1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props1.setProperty(EditSDI.PROPERTY_KEYID1, notPerform1.getColumnValues("s_sampleid", ";"));
                props1.setProperty("u_currentmovementstep", notPerform1.getColumnValues("u_currentmovementstep", ";"));
                // props1.setProperty("u_qns", notPerform1.getColumnValues("u_qns", ";"));

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props1);
            }
            //FFPE SCROLLS ROUTING
            /*HashMap hm = new HashMap();
            hm.clear();
            hm.put(DATASET_PROPERTY_SAMPLETYPE, "FFPE scrolls");
            DataSet dsFFPEScrollsFilter = dsMain.getFilteredDataSet(hm);
            if (dsFFPEScrollsFilter.size() > 0) {
                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsFFPEScrollsFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
                props.setProperty("u_currentmovementstep", StringUtil.repeat("PathSupport", dsFFPEScrollsFilter.size(), ";"));
                props.setProperty("u_microtomycompleteflag", StringUtil.repeat("Y", dsFFPEScrollsFilter.size(), ";"));
                props.setProperty("u_microtomycompletedt", StringUtil.repeat("n", dsFFPEScrollsFilter.size(), ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (Exception ex) {
                    throw new SapphireException("Unable to route FFPE Scrolls." + ex.getMessage());
                }
            }*/

        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    private void updateCustodian() throws SapphireException {

        HashMap hm = new HashMap();
        hm.put(DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
        DataSet dsFilter = dsMain.getFilteredDataSet(hm);
        if (dsFilter == null || dsFilter.getRowCount() == 0) {
            return;
        }
        PropertyList props = new PropertyList();
        dsFilter.sort("sampleid,custodialdepartmentid,u_currenttramstop");
        ArrayList dsGroupByMethArray = dsFilter.getGroupedDataSets("sampleid,custodialdepartmentid,u_currenttramstop");
        if (dsGroupByMethArray.size() > 0) {
            DataSet dsTrackitem = new DataSet();
            dsTrackitem.addColumn("sampleid", DataSet.STRING);
            dsTrackitem.addColumn("custodialdepartmentid", DataSet.STRING);
            dsTrackitem.addColumn("tramstop", DataSet.STRING);
            for (int i = 0; i < dsGroupByMethArray.size(); i++) {
                DataSet dsEach = (DataSet) dsGroupByMethArray.get(i);
                String sampleid = dsEach.getValue(0, DATASET_PROPERTY_SAMPLEID, "");
                String custodialdepartmentid = dsEach.getValue(0, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, "");
                String u_currenttramstop = dsEach.getValue(0, "tramstop", "");
                int rowID = dsTrackitem.addRow();
                dsTrackitem.setValue(rowID, "sampleid", sampleid);
                dsTrackitem.setValue(rowID, "custodialdepartmentid", custodialdepartmentid);
                dsTrackitem.setValue(rowID, "tramstop", u_currenttramstop);
            }
            if (dsTrackitem.size() > 0) {
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsTrackitem.getColumnValues("sampleid", ";"));
                props.setProperty("custodialdepartmentid", dsTrackitem.getColumnValues("custodialdepartmentid", ";"));
                props.setProperty("custodialuserid", StringUtil.repeat("", dsTrackitem.getRowCount(), ";"));
                props.setProperty("u_currenttramstop", dsTrackitem.getColumnValues("tramstop", ";"));
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }
        }

        /**
         * CHANGED FOR 1.2.2 RELEASE AS Histo Archieve will be access by PATHSUPPORT ONLY
         */
        //TODO WILL REMOVE AS ITS CREATING EXTRA ROW INTO ACCESSION STATUS PAGE (1.6.1 RELEASE)
        /*String defaultdepartment = connectionInfo.getDefaultDepartment();//AV-Molecular
        String site = StringUtil.split(defaultdepartment, "-")[0]; //AV
        hm.clear();
        hm.put(DATASET_PROPERTY_TRAMSTOP, "HistologyArchive");
        DataSet dsDepartmentFilter = dsFilter.getFilteredDataSet(hm);
        if (dsDepartmentFilter != null && dsDepartmentFilter.size() > 0) {
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsDepartmentFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
            props.setProperty("custodialdepartmentid", StringUtil.repeat(site + "-Accessioning", dsDepartmentFilter.size(), ";"));
//            props.setProperty("custodialdepartmentid", StringUtil.repeat(site + "-PathSupport", dsDepartmentFilter.size(), ";"));
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }*/
    }

    private void moveBlockToBlockRoom(String sampleids) throws SapphireException {
        String sql = "select s_sampleid,specimentype from s_sample where s_sampleid in (" +
                " select distinct sourcesampleid from s_samplemap where destsampleid in" +
                " ('" + StringUtil.replaceAll(sampleids, ";", "','") + "'))";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String sampletype = ds.getValue(0, "specimentype", "");
        String s_sampleid = ds.getValue(0, "s_sampleid", "");
        if ("Block".equalsIgnoreCase(sampletype)) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, s_sampleid);
            prop.setProperty("u_currentmovementstep", "BlockRoomCOC");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }

    }

    /**
     * Description : This method used for EditTrackItem SDC .
     *
     * @throws SapphireException
     */
    private void updateTrackItem() throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();

        PropertyList editTIProps = new PropertyList();
        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
        editTIProps.setProperty("u_currenttramstop", dsMain.getColumnValues(DATASET_PROPERTY_TRAMSTOP, ";"));
        editTIProps.setProperty("custodialuserid", StringUtil.repeat(currentuser, dsMain.size(), ";"));
        editTIProps.setProperty("custodialdepartmentid", StringUtil.repeat(defaultdepartment, dsMain.size(), ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

    }

    /**
     * Description : This method will search methodology and type of selected samples.Next it will find totramstop name based
     * on methodology and type and it will create a main DataSet for updating tramstop.
     *
     * @param sampleid1
     * @param dsPloicy
     * @throws SapphireException
     */
    private void creatMainDs(String sampleid1, DataSet dsPloicy) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sampleid1, ";", "','");

        String sqlType = "select s.s_sampleid,stm.methodology,s.u_type,stm.lvtestcodeid,s.u_rootsample,stm.testname,s.sampletypeid from s_sample s,u_sampletestcodemap stm " +
                " where s.s_sampleid=stm.s_sampleid and s.s_sampleid in ('" + sampleid + "') and stm.teststatus != 'Cancelled'";
        DataSet dsType = getQueryProcessor().getSqlDataSet(sqlType);
        if (dsType == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlType;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        /*if (dsType.size() == 0) {
            String errStr = getTranslationProcessor().translate("No test code is associated with the sample. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }*/
        if (dsType.size() > 0) {
            HashMap hm = new HashMap();
            int rowCnt = 0;
            for (int i = 0; i < dsType.size(); i++) {
                String sample = dsType.getValue(i, "s_sampleid", "");
                String type = dsType.getValue(i, "u_type", ""); // null will be work for Block to move HistoBlockRoom
                String methodology = dsType.getValue(i, "methodology", "");
                String lvtestcodeid = dsType.getValue(i, "lvtestcodeid", "");
                String rootsample = dsType.getValue(i, "u_rootsample", "");
                String testname = dsType.getValue(i, "testname", "");
                String sampletypeid = dsType.getValue(i, "sampletypeid", "");
                if (Util.isNull(methodology)) {
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Methodology not found for sample :" + sample);
                }

                hm.clear();
                hm.put("type", type);
                hm.put("methodology", methodology);
                DataSet dsfilter = dsPloicy.getFilteredDataSet(hm);
                if (dsfilter != null && dsfilter.size() > 0) {
                    rowCnt = dsMain.addRow();
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_SAMPLEID, sample);
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_TYPE, dsfilter.getValue(0, "type", ""));
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_METHODOLOGY, dsfilter.getValue(0, "methodology", ""));
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_LVTESTCODEID, lvtestcodeid);
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_ROOTSAMPLEID, rootsample);
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_LVTESTNAME, testname);
                    //If any step is not defined in microtomycompletePolicy then let them stay in Microtomy
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_TRAMSTOP, dsfilter.getValue(0, "tramstop", "Microtomy"));
                    dsMain.setValue(rowCnt, "currenttramstop", dsfilter.getValue(0, "currenttramstop", "Microtomy"));
                    dsMain.setValue(rowCnt, DATASET_PROPERTY_SAMPLETYPE, sampletypeid);
                }

                //TODO Dharam is not handling
                // 1. IHC-Morphology Label1 H&E

                //For block which will have multiple methodology testcode be moved to BlockRoom. Here we can't filter with methodlogy
//                if (dsfilter == null || dsfilter.size() > 0) {
                if (dsfilter == null || dsfilter.size() == 0) {
                    hm.clear();
                    hm.put("type", null); // block don't have type
                    //hm.put("methodology", methodology);
                    DataSet dsfilterBlock = dsPloicy.getFilteredDataSet(hm);
                    if (dsfilterBlock != null && dsfilterBlock.size() > 0) {
                        rowCnt = dsMain.addRow();
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_SAMPLEID, sample);
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_TYPE, "");
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_SAMPLETYPE, sampletypeid);
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_TRAMSTOP, dsfilterBlock.getValue(0, "tramstop", "BlockRoomCOC"));
                        dsMain.setValue(rowCnt, "currenttramstop", dsfilterBlock.getValue(0, "currenttramstop", "Block COC"));
                    }
                }

                //define the custodian department of the samples.
                //get default department of the user
                String currentuser = connectionInfo.getSysuserId();
                String defaultdepartment = connectionInfo.getDefaultDepartment();//AV-Molecular
                String site = StringUtil.split(defaultdepartment, "-")[0]; //AV

                //if block then move to blockroom custody else move on either IHC , or molecular dependening on methodology ( if FISH,CYTO then Ignore)
                for (int l = 0; l < dsMain.getRowCount(); l++) {
                    String typeOfSample = dsMain.getValue(l, DATASET_PROPERTY_TYPE, "");
                    String meth = dsMain.getValue(l, DATASET_PROPERTY_METHODOLOGY, "");
                    String sampletype = dsMain.getValue(l, DATASET_PROPERTY_SAMPLETYPE, "");
                    if ("".equals(typeOfSample) && !"FFPE scrolls".equalsIgnoreCase(sampletype)) {
                        dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "BlockRoom");
                        dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                    } else if ("Molecular".equalsIgnoreCase(meth)) {
                        /*** CHANGED BY SURAJIT AS H & CH WILL GO TO H&E BATCHING INTO AP STARTS **/
                        if ("H".equalsIgnoreCase(typeOfSample) || "CH".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "AP");
                        } else if ("FB".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        } else {
                            //dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Molecular");
                            //TODO CHANGES AS FROM RELEASE 1.6.1 USS WILL BE ROUTED TO PATH SUPPORT CALLED AS PROJECT SUPPORT
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        }
                        /*** CHANGED BY SURAJIT AS H & CH WILL GO TO H&E BATCHING INTO AP ENDS ***/
                        dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                    } else if ("IHC".equalsIgnoreCase(meth)) {
                        //TODO ADDED FOR ACCESSION STATUS PAGE (1.6.1 RELEASE)
                        if ("B".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                            dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                        } else {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "AP");
                            dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                        }
                    } else if ("Multiomyx".equalsIgnoreCase(meth)) {
                        if ("H".equalsIgnoreCase(typeOfSample) || "CH".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "AP");
                        } else if ("B".equalsIgnoreCase(typeOfSample)) {
//                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "PathSupport");
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        } else {
                            //dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "MOWetLab");
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        }
                        dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");

                    } else if ("FISH".equalsIgnoreCase(meth)) {
                        if ("H".equalsIgnoreCase(typeOfSample) || "CH".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "AP");
                        } else if ("U".equalsIgnoreCase(typeOfSample) || "CU".equalsIgnoreCase(typeOfSample) || "CSS".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        }

                        dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                    } else if ("Generic".equalsIgnoreCase(meth)) {
                        if ("SH".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "AP");
                        }

                        dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                    }

                }
            }

        }
    }

    /**
     * Description : This method will create a dataset with type,methodology and tramstop that is define in MicrotomyCompletePolicy.
     *
     * @return
     * @throws SapphireException
     */
    private DataSet getPolicy() throws SapphireException {
        DataSet dsPloicy = new DataSet();
        int incr = 0;
        dsPloicy.addColumn("type", DataSet.STRING);
        dsPloicy.addColumn("methodology", DataSet.STRING);
        dsPloicy.addColumn("tramstop", DataSet.STRING);
        dsPloicy.addColumn("currenttramstop", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("MicrotomyCompletePolicy", "MicrotomyComplete");
        PropertyListCollection plcRoutingrules = plMicroPolicy.getCollection("routingrules");
        for (int i = 0; i < plcRoutingrules.size(); i++) {
            incr = dsPloicy.addRow();
            PropertyListCollection plcConditions = plcRoutingrules.getPropertyList(i).getCollection("conditions");
            PropertyListCollection plcColumnvaluepair = plcConditions.getPropertyList(0).getCollection("columnvaluepair");
            for (int j = 0; j < plcColumnvaluepair.size(); j++) {
                String column = plcColumnvaluepair.getPropertyList(j).getProperty("column");
                String value = plcColumnvaluepair.getPropertyList(j).getProperty("value");
                if (column.equalsIgnoreCase("u_type")) {
                    dsPloicy.setValue(incr, "type", value);
                } else {
                    dsPloicy.setValue(incr, "methodology", value);
                }
            }
            String currentmovementstep = plcConditions.getPropertyList(0).getProperty("currentmovementstep");
            String currenttramstop = plcConditions.getPropertyList(0).getProperty("currenttram");
            dsPloicy.setValue(incr, "tramstop", currentmovementstep);
            dsPloicy.setValue(incr, "currenttramstop", currenttramstop);
        }
        return dsPloicy;
    }

    private DataSet checkTestcodeHas(String sampleids) throws SapphireException {
        String sql = Util.parseMessage(ApSql.CHECK_TESTCODES_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsResult = getQueryProcessor().getSqlDataSet(sql);
        if (dsResult != null && dsResult.size() > 0) {
            return dsResult;
        } else {
            return dsResult;
        }
    }

    /**
     * Description: This is to take lab details from policy
     *
     * @return null
     * @throws SapphireException
     */
    private DataSet getLabPolicy() throws SapphireException {
        DataSet dsLab = new DataSet();
        dsLab.addColumn("methodology", DataSet.STRING);
        dsLab.addColumn("department", DataSet.STRING);
        dsLab.addColumn("fullsitename", DataSet.STRING);
        dsLab.addColumn("siteinitials", DataSet.STRING);
        PropertyList plLabPolicy = getConfigurationProcessor().getPolicy("LabLocationPolicy", "LabDetails");
        if (plLabPolicy == null) {
            throw new SapphireException("Performing Lab is not created into Policy: LabLocationPolicy > LabDetails");
        }
        PropertyListCollection plcLabDetailsCollection = plLabPolicy.getCollection("labdetails");
        if (plcLabDetailsCollection == null || plcLabDetailsCollection.size() == 0) {
            throw new SapphireException("Performing Lab is not defined into Policy: LabLocationPolicy > LabDetails");
        }
        if (plcLabDetailsCollection.size() > 0) {
            for (int i = 0; i < plcLabDetailsCollection.size(); i++) {
                String methodology = plcLabDetailsCollection.getPropertyList(i).getProperty("methodology");
                String department = plcLabDetailsCollection.getPropertyList(i).getProperty("department");
                String fullsitename = plcLabDetailsCollection.getPropertyList(i).getProperty("fullsitename");
                String siteinitials = plcLabDetailsCollection.getPropertyList(i).getProperty("siteinitials");
                int rowID = dsLab.addRow();
                dsLab.setValue(rowID, "methodology", methodology);
                dsLab.setValue(rowID, "department", department);
                dsLab.setValue(rowID, "fullsitename", fullsitename);
                dsLab.setValue(rowID, "siteinitials", siteinitials);
            }
        }
        return dsLab;
    }

    private void noMicrotomyCompleteForAV() throws SapphireException {
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        DataSet dsLab = getLabPolicy();
        HashMap hm = new HashMap();
        String samples = "";
        for (int i = 0; i < dsMain.size(); i++) {
            String sample = dsMain.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
            String type = dsMain.getValue(i, DATASET_PROPERTY_TYPE, "");
            String methodlgy = dsMain.getValue(i, DATASET_PROPERTY_METHODOLOGY, "");
            //RELEASE 1.6.1
            hm.clear();
            hm.put("methodology", methodlgy);
            hm.put("siteinitials", site);
            DataSet dsLabFilter = dsLab.getFilteredDataSet(hm);
            if ((dsLabFilter == null || dsLabFilter.size() == 0) && "U".equalsIgnoreCase(type) && "Molecular".equalsIgnoreCase(methodlgy)) {
                //samples = samples + "," + sample;
                throw new SapphireException("<b>There is No Molecular Lab in " + site + ", you can't proceed.\nPlease route the specimen(s) via Logistics.</b>");
            }

            /*if (samples.length() > 0) {
                samples = samples.substring(1);
                throw new SapphireException("You can't complete microtomy for unstained slide(s) as you belongs to AV site.Please send slide " + samples + " to HO site.");
            }*/
        }
        /*if (samples.length() > 0) {
            samples = samples.substring(1);
            throw new SapphireException("You can't send unstained slide(s) to AV-Molecular. Please send " + samples + " to Houston.");
        }*/
    }

    private DataSet dsMain = null;
    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_TYPE = "type";
    private static final String DATASET_PROPERTY_METHODOLOGY = "methodology";
    private static final String DATASET_PROPERTY_TRAMSTOP = "tramstop";
    private static final String DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT = "custodialdepartmentid";
    private static final String DATASET_PROPERTY_IS_CUSTODIAN_CHANGED = "custodianchangeflag";
    private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";
    private static final String DATASET_PROPERTY_ROOTSAMPLEID = "rootsampleid";
    private static final String DATASET_PROPERTY_LVTESTNAME = "testname";
    private static final String DATASET_PROPERTY_SAMPLETYPE = "sampletype";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TYPE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TRAMSTOP, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_ROOTSAMPLEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTNAME, DataSet.STRING);
            dsMain.addColumn("currenttramstop", DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_SAMPLETYPE, DataSet.STRING);
        }
    }
}
