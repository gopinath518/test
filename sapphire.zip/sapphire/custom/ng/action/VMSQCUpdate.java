package sapphire.custom.ng.action;


import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 7/18/2016.
 */
public class VMSQCUpdate extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("VMSQCUpdate Input Invoked>>>>>>", properties.toJSONString());
        String aperioStatusID = "";
        String externalid = properties.getProperty("ExternalImageIdentifier");
        String sampleid = "";
        if (externalid.contains(";")) {
            sampleid = externalid.substring(0, externalid.indexOf(";"));
            aperioStatusID = externalid.substring(externalid.indexOf(";") + 1, externalid.length());
            logger.info("VMSQCUpdate", "Aperio Status ID found: " + aperioStatusID + ",Sample ID: " + sampleid);
        } else {
            logger.info("VMSQCUpdate", "Aperio Status ID not found: " + aperioStatusID + ",Sample ID: " + sampleid);
            throw new SapphireException("Aperio status id not found ");
        }

        String qcStatus = properties.getProperty("QCStatus");
        String qcReason = properties.getProperty("QCStatusReason");
        String comments = properties.getProperty("Comments");
        String imageId = properties.getProperty("imageId");
        if (null == sampleid || 0 == sampleid.length()) {
            logger.info("VMSQCUpdate", "Aperio sample id not found");
            throw new SapphireException(getTranslationProcessor().translate("Extrenal identifier that is sample id not provided"));
        }
        logger.info("VMSQCUpdate", "Aperio sample id found " + sampleid);
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        props.setProperty("u_vmsqcstatus", qcStatus);
        props.setProperty("u_vmsqcreason", qcReason);
        props.setProperty("u_vmsqccomment", comments);
        //props.setProperty("u_currentmovementstep", qcStatus.equalsIgnoreCase("pass") ? "QCPass" :qcStatus.equalsIgnoreCase("suboptimal") ? "QCSuboptimal" : "QCFail"  );
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            logger.info("VMSQCUpdate", "Unable to perform update in Sample sdc for sample id" + sampleid);
        }
        logger.info("VMSQCUpdate After QC Update in Sample SDC>>>>>>", props.toJSONString());

/*      not required as of not should be manual action
        PropertyList plStep = new PropertyList();
        plStep.setProperty("sampleid", sampleid);
        getActionProcessor().processAction("CompleteIhcStep", "1", plStep);
*/

        // as per new requirement update the corresponding aperiostatus sdi also to track status of each image scanned
        DataSet dsAperio = null;
        PropertyList propsAperio = null;
        if (qcStatus.equalsIgnoreCase("pass") || qcStatus.equalsIgnoreCase("suboptimal")) {  // if its qc pass make input as pass but fail all other entry for the same sample (where barcode='" + sampleid + "')
            dsAperio = getQueryProcessor().getSqlDataSet("select u_aperiostatusid, qcstatus, CASE WHEN u_aperiostatusid='" + aperioStatusID + "' THEN 'QCPass' ELSE 'QCFail' END status,  " +
                    " CASE WHEN u_aperiostatusid='" + aperioStatusID + "' THEN '" + qcReason + "' ELSE qcreason END  reason,  " +
                    " CASE WHEN u_aperiostatusid='" + aperioStatusID + "' THEN '" + comments + "' ELSE qccomment END  cmt  " +
                    "   from u_aperiostatus  where barcode='" + sampleid + "'");

            propsAperio = new PropertyList();
            propsAperio.setProperty(EditSDI.PROPERTY_SDCID, "AperioStatus");
            propsAperio.setProperty(EditSDI.PROPERTY_KEYID1, dsAperio.getColumnValues("u_aperiostatusid", ";"));
            propsAperio.setProperty("qcreason", dsAperio.getColumnValues("reason", ";"));
            propsAperio.setProperty("qccomment", dsAperio.getColumnValues("cmt", ";"));
            propsAperio.setProperty("qcstatus", dsAperio.getColumnValues("status", ";"));
            //propsAperio.setProperty("qceddate", "n");
            //propsAperio.setProperty("qcedby", connectionInfo.getSysuserId());
        } else {
            propsAperio = new PropertyList();
            propsAperio.setProperty(EditSDI.PROPERTY_SDCID, "AperioStatus");
            propsAperio.setProperty(EditSDI.PROPERTY_KEYID1, aperioStatusID);
            propsAperio.setProperty("qcreason", qcReason);
            propsAperio.setProperty("qccomment", comments);
            //propsAperio.setProperty("qceddate", "n");
            //propsAperio.setProperty("qcedby", connectionInfo.getSysuserId());
            propsAperio.setProperty("qcstatus", qcStatus.equalsIgnoreCase("pass") ? "QCPass" : qcStatus.equalsIgnoreCase("suboptimal") ? "QCSuboptimal" : "QCFail");
        }
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propsAperio);
        } catch (Exception ex) {
            logger.info("VMSQCUpdate", "Sample information updatd after qc in AperioStatus SDC for sampleid: " + sampleid);
        }
        updateOthersAperioEntry(aperioStatusID, sampleid);
        logger.info("VMSQCUpdate After QC Update in Aperio SDC>>>>>>Exit", propsAperio.toJSONString());
        //throw new SapphireException("test");
    }

    private void updateOthersAperioEntry(String aperioID, String barcode) throws SapphireException {
        String sql = Util.parseMessage(IHCSql.GET_OTHERS_APERIO_BYID, aperioID, barcode);
        DataSet dsOtherAperio = getQueryProcessor().getSqlDataSet(sql);
        if (dsOtherAperio != null && dsOtherAperio.size() > 0) {
            PropertyList propsAperio = new PropertyList();
            propsAperio.setProperty(EditSDI.PROPERTY_SDCID, "AperioStatus");
            propsAperio.setProperty(EditSDI.PROPERTY_KEYID1, dsOtherAperio.getColumnValues("u_aperiostatusid", ";"));
            propsAperio.setProperty("qcstatus", StringUtil.repeat("QCFail", dsOtherAperio.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propsAperio);
            } catch (Exception ex) {
                logger.info("VMSQCUpdate", "Unable to update status of other images if any of sample id: " + barcode);
            }
        }
    }

}
