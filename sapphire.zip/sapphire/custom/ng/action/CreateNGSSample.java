package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**Action Name- CreateNGSSample
 * Description: This Action is use to create aliquot sample for NGS workflow
 * input :-
 * param1-parentsample
 * param1-copies
 * param1-volume
 * throws SapphireException
 * Created by mpandey on 6/11/2016.
 */
public class CreateNGSSample extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String parentsample = properties.getProperty("parentsample");
        String copies = properties.getProperty("copies");
        String childvolume = properties.getProperty("volume");
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();


        String sql = "select containertypeid,qtycurrent,qtyunits from trackitem where linksdcid='Sample' and linkkeyid1='" + parentsample + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String containertype = ds.getColumnValues("containertypeid", ";");
        String parentvol = ds.getColumnValues("qtycurrent", ";");
        String parentunit = ds.getColumnValues("qtyunits", ";");
        String childsampleid = createDaughterTube(parentsample, copies, childvolume, parentunit, parentvol);

        updateSample(childsampleid);
        updateTrackitem(childsampleid, currentuser, childvolume, parentunit, containertype, defaultdepartment);
        addTestCode(childsampleid, parentsample);

        properties.setProperty("newkeyid1", childsampleid);


    }

    /**
     * This method is use to add testcode in sample.
     * @param childsampleid
     * @param parentsample
     * @throws SapphireException
     */
    private void addTestCode(String childsampleid, String parentsample) throws SapphireException {
        //to do
        String tc_sql = "select lvtestcodeid,ispanel from u_sampletestcodemap where  s_sampleid='" + parentsample + "' and isneotypepanel='Y'";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        String[] samparr = StringUtil.split(childsampleid, ";");
        if (dstestcode == null) {
            String error = getTranslationProcessor().translate("Query Faild ");
            error += tc_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dstestcode.size() > 0) {
            DataSet dsSamplefinal = new DataSet();
            dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
            dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
            dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

            for (String currentsamp : samparr) {
                for (int j = 0; j < dstestcode.getRowCount(); j++) {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                    dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                    dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));

                }
            }


            PropertyList hsAddTestCode = new PropertyList();
            hsAddTestCode.clear();
            hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
            hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
            hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
            try {
                getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }

    /**
     * This method is use to create daughter tube of any sample.
     * @param parentsample
     * @param copies
     * @param childvolume
     * @param parentunit
     * @param parentvol
     * @return
     * @throws SapphireException
     */
    private String createDaughterTube(String parentsample, String copies, String childvolume, String parentunit, String parentvol) throws SapphireException {

        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentsample);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, copies);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY, childvolume);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT, parentunit);
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_QUANTITY, parentvol);
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_markminimal;u_sampleinformation;u_accessionid;u_currentmovementstep");

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create child sample.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

    /**
     * This method is use to update different values in trackitem sdc.
     * @param childsampleid
     * @param currentuser
     * @param volume
     * @param units
     * @param containertype
     * @param defaultdepartment
     * @throws SapphireException
     */
    private void updateTrackitem(String childsampleid, String currentuser, String volume, String units, String containertype, String defaultdepartment) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", containertype);
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", defaultdepartment);
        props.setProperty("custodytakendt", "n");
        props.setProperty("qtycurrent", volume);
        props.setProperty("qtyunits", units);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * This method is use to update storage status in sample sdc for a sdi.
     * @param childsampleid
     * @throws SapphireException
     */
    private void updateSample(String childsampleid) throws SapphireException {
        PropertyList prop1 = new PropertyList();
        prop1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop1.setProperty(EditSDI.PROPERTY_KEYID1, childsampleid);
        prop1.setProperty("storagestatus", "In Circulation");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop1);

    }
}


