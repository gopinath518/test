package sapphire.custom.ng.action;


import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;
import com.labvantage.sapphire.actions.report.GenerateReport;

import java.io.File;
import java.util.Date;

/**
 * Created by msubhra on 6/7/2016.
 */

/**
 * @desc This action is for generate IHC manifest report and update the status for the sample.
 * IHC manifest should be generated on the samples which are belongs to same accession and LOS
 * and the Manifest should be attached with the Accession ID
 */
public class GenerateIHCManifest extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {


        String accessionid = properties.getProperty("u_accessionid");
        String los = properties.getProperty("los");
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String timestamp = new java.text.SimpleDateFormat("MMddyyyyhmmssa").format(new Date());

        String location = getFileLocation(accessionid);
        String filename = generateReport(accessionid, los, timestamp, location);
        addAttachment(accessionid, location, los, filename);
        updateSampleInfo(accessionid, los, currentUser);

        String url = "rc?command=ViewReport&reportid=IHCQCManifest&reportversionid=1&accessionid=" + accessionid + "&los=" + los + "&mode=submitarg&displaytype=pdf";


        properties.setProperty("msg", url);


    }

    /**
     * @return fileLocation
     * @throws SapphireException
     * @desc this method is used for getting the location where the report is being created
     */

    private String getFileLocation(String accessionid) throws SapphireException {
        /*String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "Manifest");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }*/
        String fileLocation = "";
        String sql = Util.parseMessage(CommonSql.GET_ACCESSION_INFO_BY_ACCESSION, StringUtil.replaceAll(accessionid, ";", "','"));
        DataSet dsAccessionIfo = getQueryProcessor().getSqlDataSet(sql);
        String sponsornumber = "", projectprotocolid = "";
        if (dsAccessionIfo.size() > 0) {
            sponsornumber = dsAccessionIfo.getValue(0, "sponsornumber");
            projectprotocolid = dsAccessionIfo.getValue(0, "projectprotocolid");
        }
        sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        fileLocation = Util.generateIHCLocPath(baseloc, sponsornumber, projectprotocolid, "IHC", "Manifest");

        return fileLocation;
    }

    /**
     * @param accessionid
     * @param los
     * @param location
     * @throws SapphireException
     * @desc This method is used for generate the report by calling GenerateReport action and store the report in the location which
     * is obtained from getFileLocation() method.
     */

    public String generateReport(String accessionid, String los, String time, String location) throws SapphireException {

        String filename = "";


        if (!Util.isNull(accessionid)) {
            if (!Util.isNull(los)) {
                if (location.endsWith("/") || location.endsWith("\\"))
                    filename = location + accessionid + los + time + ".pdf";
                else
                    filename = location + File.separator + accessionid + los + time + ".pdf";

                PropertyList prop = new PropertyList();
                prop.clear();
                prop.setProperty(GenerateReport.PROPERTY_REPORTID, "IHCQCManifest");
                prop.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID, "1");
                prop.setProperty("accessionid", accessionid);
                prop.setProperty("los", los);
                prop.setProperty(GenerateReport.PROPERTY_DESTINATION, "file");
                prop.setProperty(GenerateReport.PROPERTY_DEBUGLOG, "N");
                prop.setProperty(GenerateReport.PROPERTY_FILENAME, filename);
                prop.setProperty(GenerateReport.PROPERTY_FILETYPE, "pdf");

                try {
                    getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. ManifestID not created. " + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }

            }
        }
        return filename;


    }

    /**
     * @param accessionid
     * @param location
     * @param los
     * @throws SapphireException
     * @desc This method is used for attach the report with the accession for which the report is generated by calling
     * AddSDIAttachment action.
     */
    public void addAttachment(String accessionid, String location, String los, String filename) throws SapphireException {
        if (!Util.isNull(accessionid)) {
            if (!Util.isNull(los)) {

                //String fileName = location+File.separator+accessionid+los+time+".pdf";
                String description = accessionid + los + ".pdf";

                PropertyList attachprop = new PropertyList();
                attachprop.clear();
                attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, accessionid);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, los);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "IHC Manifest");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, description);
                attachprop.setProperty("ATTACHMENTCLASS", "SOP");


                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
                } catch (SapphireException ex) {
                    String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + accessionid + "Accession" + ex.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                }

            }
        }

    }

    /**
     * Description : updatesampleinfo() is for update sample information based on the accession id forr which the report is generated.
     *
     * @param accessionid
     * @param los
     * @param currentUser
     * @throws SapphireException
     */

    public void updateSampleInfo(String accessionid, String los, String currentUser) throws SapphireException {
        DataSet ds = new DataSet();
        /*String dsSample1 = "select distinct s.s_sampleid from s_sample s,s_samplemap sm,u_sampletestcodemap stcm, " +
                "u_accession a where a.u_accessionid = s.u_accessionid " +
                "and s.s_sampleid = sm.destsampleid " +
                "and s.s_sampleid = stcm.s_sampleid " +
                "and stcm.methodology = 'IHC' " +
                "and a.u_accessionid = '" + accessionid + "' and stcm.los = '" + los + "'";*/

        String dsSample = "SELECT s.s_sampleid " +
                " FROM labvantage.u_sampletestcodemap t,labvantage.s_sample s " +
                " WHERE  " +
                "   s.s_sampleid = t.s_sampleid " +
                " and  s.sstudyid                       IS NOT NULL " +
                " AND s.samplestatus                     != 'Disposed' " +
                " AND s.u_type                           IN ('U','CH','H', 'CU','PC','NC') " +
                " AND s.submitterid                      IS NULL " +
                " AND s.submitteddt                      IS NULL " +
                " and s.u_accessionid = '" + accessionid + "' and t.los = '" + los + "'";

       /* if(getQueryProcessor().getSqlDataSet(dsSample1).size() > 0) {
            ds = getQueryProcessor().getSqlDataSet(dsSample1);
        }
        else{
            ds = getQueryProcessor().getSqlDataSet(dsSample2);
        }*/
        ds = getQueryProcessor().getSqlDataSet(dsSample);
        DataSet dsAddManifest = new DataSet();
        dsAddManifest.addColumn("s_sampleid", DataSet.STRING);
        dsAddManifest.addColumn("submitterid", DataSet.STRING);
        dsAddManifest.addColumn("submitteddt", DataSet.STRING);

        if (ds == null) {
            String errMSG = getTranslationProcessor().translate("Contact your administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);

        }

        if (ds.size() == 0) {
            String errMSG = getTranslationProcessor().translate("Please select correct accession id and los.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }

        if (ds != null && ds.size() > 0) {

            for (int i = 0; i < ds.getRowCount(); i++) {
                int rowID = dsAddManifest.addRow();
                dsAddManifest.setValue(rowID, "s_sampleid", ds.getValue(i, "s_sampleid"));
                dsAddManifest.setValue(rowID, "submitterid", currentUser);
                dsAddManifest.setValue(rowID, "submitteddt", "n");
            }

            PropertyList hsAddmanifestId = new PropertyList();
            hsAddmanifestId.clear();
            hsAddmanifestId.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            hsAddmanifestId.setProperty(EditSDI.PROPERTY_KEYID1, dsAddManifest.getColumnValues("s_sampleid", ";"));
            //hsAddmanifestId.setProperty("u_manifestid",dsAddManifest.getColumnValues("u_manifestid",";"));
            hsAddmanifestId.setProperty("submitterid", dsAddManifest.getColumnValues("submitterid", ";"));
            hsAddmanifestId.setProperty("submitteddt", dsAddManifest.getColumnValues("submitteddt", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, hsAddmanifestId);
            } catch (SapphireException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. ManifestID not updated." + e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }
}
