package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ReturnToFreshPrepCOC extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("keyid1", "");//[s_sampleid]
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep", "");//ReturnToCOC
        String custodialuserid = properties.getProperty("custodialuserid", "");//(null)
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid", "");//AV-Fresh Prep

        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleids);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String currentdepartment = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(currentdepartment, "-")[0];
        custodialdepartmentid = site + "-" + custodialdepartmentid;
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
        props.setProperty("u_currentmovementstep", u_currentmovementstep);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("Fail to update current movement step.");
        }
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleids);
        props.setProperty("custodialuserid", custodialuserid);
        props.setProperty("custodialdepartmentid", custodialdepartmentid);
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("Fail to update trackitem.");
        }
    }
}
