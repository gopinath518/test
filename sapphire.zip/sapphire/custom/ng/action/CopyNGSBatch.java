package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;

/**
 * Created by akumar on 3/18/2017.
 */
public class CopyNGSBatch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String origin = properties.getProperty("origin");
        String pageid = properties.getProperty("pageid");
        String returntolist = properties.getProperty("returntolist");

        if (batchid == null || batchid.equalsIgnoreCase("")) {
            throw new SapphireException("Batch id is not selected.");
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(AddSDI.PROPERTY_TEMPLATEKEYID1, batchid);
        prop.setProperty("batchtype", "NGS");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (SapphireException s) {
            throw new SapphireException("Something went wrong.Batch can not be copied");
        }
        String newkeyid = prop.getProperty("newkeyid1");
        updateBatch(batchid, newkeyid, origin);
        //removeReagent(newkeyid);
        if (origin.equalsIgnoreCase("DiscoveryAgilentDay2")) {
            updateBatchDetail(newkeyid);
        }
        attachPlateMap(batchid, newkeyid);
        String url = "<script>sapphire.page.navigate('rc?command=page&page=" + pageid + "&sdcid=NGBatch&mode=Edit&keyid1=" + newkeyid + "&returntolistpage=" + returntolist + "', 'Y', '_top')</script>";
        properties.setProperty("msg", url);


    }

    private void updateBatch(String parentbatch, String batch, String origin) throws SapphireException {
        PropertyList editbatch = new PropertyList();
        editbatch.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        editbatch.setProperty(EditSDI.PROPERTY_KEYID1, batch);
        editbatch.setProperty("origin", origin);
        editbatch.setProperty("parentbatchid", parentbatch);
        editbatch.setProperty("batchcompletedts", "");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editbatch);
        } catch (SapphireException se) {
            throw new SapphireException("Can not update Batch");
        }
    }

    private void updateBatchDetail(String newbatch) throws SapphireException {
        String removetag = "select sampleid from u_ngbatch_sample where u_ngbatchid='" + newbatch + "'";
        DataSet dsremovetag = getQueryProcessor().getSqlDataSet(removetag);
        PropertyList proptag = new PropertyList();
        proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
        proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, newbatch);
        proptag.setProperty("sampleid", dsremovetag.getColumnValues("sampleid", ";"));
        proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        //proptag.setProperty("tagid", StringUtil.repeat("(null)",dsremovetag.size(),";"));
        proptag.setProperty("tagid", "(null)");


        try {
            getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail");
        }
    }

    /**
     * Removes the reagent
     *
     * @param batchid-Parent Batchid
     * @throws SapphireException
     */
    private void removeReagent(String batchid) throws SapphireException {
        PropertyList reagent = new PropertyList();
        reagent.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        reagent.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        reagent.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");
        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, reagent);
        } catch (SapphireException se) {
            throw new SapphireException("Can not remove reagents");
        }
    }

    /**
     * @param batchid    :Parent batchid
     * @param newbatchid :New batchid created by copying the parent batchid
     * @throws SapphireException
     * @desc : Attaches the platemap excel to the newly created Batch
     */
    private void attachPlateMap(String batchid, String newbatchid) throws SapphireException {


        String sql = "select filename from sdiattachment where keyid1='" + batchid + "'";
        DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
        PropertyList platemap = new PropertyList();
        if (dsAttachment != null && dsAttachment.size() > 0) {
            String filename = dsAttachment.getValue(0, "filename", "");
            if (!Util.isNull(filename)) {
                platemap.clear();
                platemap.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                platemap.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newbatchid);
                platemap.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                platemap.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                platemap.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, platemap);
            }
        }
    }
}
