package sapphire.custom.ng.action;


import com.labvantage.sapphire.actions.report.GenerateReport;
import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.util.Date;


/**
 * Action Name- ViewExtractionMap
 * Description: This action is use to create extraction map for a batch.
 * input :-
 * param1-batchid
 * param2-boxid
 * throws SapphireException
 * Created by kshahbaz on 7/26/2016.
 * Modified by Mpandey on 8/16/2016.
 */
public class ViewExtractionMap extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {


        String batchid = properties.getProperty("batchid");
        String boxid = properties.getProperty("boxid");
        String batchtypename = properties.getProperty("batchtypename");
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String timestamp = new java.text.SimpleDateFormat("MMddyyyyhmmssa").format(new Date());

        String location = getFileLocation();
        //String filename = location + File.separator + batchid + boxid + timestamp + ".xls";
        String filename = location + batchid + boxid + timestamp + ".xls";
        generatereport(batchid, boxid, filename, batchtypename);

        addAttachment(batchid, boxid, filename);
        String url = "";
        //GET ATTACHMENT DETAILS BY BATCHID AND BOXID
        //TODO WILL OPEN IF NOT CALL THURU TODOLIST
        /*String sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_BY_BATCHID_BOX_EXTRACTIONMAP, batchid, boxid);
        DataSet dsAttachmntDtls = getQueryProcessor().getSqlDataSet(sql);
        if (dsAttachmntDtls.size() > 0) {
            String attahmntno = dsAttachmntDtls.getValue(0, "attachmentnum", "");
            String keyid1 = dsAttachmntDtls.getValue(0, "keyid1", "");
            String keyid2 = dsAttachmntDtls.getValue(0, "keyid2", "");
            url = "rc?command=ViewAttachment&sdcid=NGBatch&keyid1=" + keyid1 + "&keyid2=" + keyid2 + "&attachmentnum=" + attahmntno + "&download=Y";
        }*/
        properties.setProperty("msg", url);


        // properties.setProperty("msg", text);


    }

    /**
     * @return
     * @throws SapphireException
     */

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        /*String sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        fileLocation = Util.generateMolLocPath(baseloc, "Molecular", "ExtractionMap");*/
        //fileLocation = "C:\\Temp";
        if (fileLocation.endsWith("/") || fileLocation.endsWith("\\")) {
            fileLocation = fileLocation + "ExtractionMap";
        } else {
            fileLocation = fileLocation + File.separator + "ExtractionMap";
        }
        File existingDir = new File(fileLocation);
        if (!existingDir.isDirectory()) {
            if (!existingDir.exists()) {
                boolean successful = existingDir.mkdir();
                if (!successful) {
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Unable to create directory");
                }
            }
        }
        fileLocation = fileLocation + File.separator;
        return fileLocation;
    }

    /**
     * @param batchid
     * @param boxid
     * @throws SapphireException
     */

    public void generatereport(String batchid, String boxid, String filename, String batchtypename) throws SapphireException {


        if (!Util.isNull(batchid)) {
            if (!Util.isNull(boxid)) {

                PropertyList prop = new PropertyList();
                prop.clear();
                prop.setProperty(GenerateReport.PROPERTY_REPORTID, "ViewExtractionMap");
                prop.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID, "1");
                prop.setProperty("batchid", batchid);
                prop.setProperty("boxid", boxid);
                prop.setProperty("batchtypename", batchtypename);
                prop.setProperty(GenerateReport.PROPERTY_DESTINATION, "file");
                prop.setProperty(GenerateReport.PROPERTY_DEBUGLOG, "N");
                prop.setProperty(GenerateReport.PROPERTY_FILENAME, filename);
                prop.setProperty(GenerateReport.PROPERTY_FILETYPE, "xls");

                try {
                    getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. ViewExtractionMap not created. " + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }

            }
        }


    }

    /**
     * This method is use to add attachment for NGBatch SDC.
     *
     * @param batchid
     * @param fileName
     * @param boxid
     * @throws SapphireException
     */
    public void addAttachment(String batchid, String boxid, String fileName) throws SapphireException {
        if (!Util.isNull(batchid)) {
            if (!Util.isNull(boxid)) {


                PropertyList attachprop = new PropertyList();
                attachprop.clear();
                attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, boxid);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, fileName);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(fileName).getName());
                attachprop.setProperty("ATTACHMENTCLASS", "SOP");


                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
                } catch (SapphireException ex) {
                    String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + batchid + "NGBatch" + ex.getMessage());
                    //ex.printStackTrace();
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                }

            }
        }

    }


}
