package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.GenerateLabel;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.*;

/**
 * Created by DMondal on 11/18/2016.
 * Description : This action will manually print extractiontube and Ellution tube.
 */
public class ManualPrintForExtraction extends BaseAction {
    private static final String SAMPLE_TYPE = "Tissue";
    private static final String SAMPLE_CONTAINER_TYPE = "Ellution Tube;Extraction Tube";
    private DataSet dsEllution = new DataSet();
    private DataSet dsExtraction = new DataSet();
    private HashMap hm = new HashMap();

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sample = properties.getProperty("sdcid", "");
        String sampleids = properties.getProperty("sampleid", "");
        String pcrlabel = properties.getProperty("pcrlabel");
        if (Util.isNull(sampleids)) {
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Please select sample(s) to print.");
        }
        if ("PCR".equalsIgnoreCase(pcrlabel)) {
            HashSet<String> hs = new HashSet<String>(Arrays.asList(sampleids.split(";")));
            //String samp=String.join(";",hs);
            String sample1 = "";
            for (String s : hs) {
                sample1 = sample1 + ";" + s;
            }
            String samp = sample1.substring(1);

            String printer = getPrinterId();
            if (Util.isNull(printer)) {
                throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                        " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                        "Or the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
            }
            printlabelForPCR(samp, printer);
        } else {
            getEllutionExtractionDs(sampleids);
            labelPrint();
        }
    }

    /**
     * Description : This method will search containertypeid for selected samples.It will check containertypeid must be
     * Elution Tube or Extraction Tube.Next it will search extraction tube for selected Elution Tube for label print by different labelMethod.
     *
     * @param sampleids
     * @throws SapphireException
     */
    private void getEllutionExtractionDs(String sampleids) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sampleids, ";", "','");
        // String sqlType="select s.s_sampleid,t.containertypeid,s.sampletypeid from s_sample s,trackitem t where s.s_Sampleid=t.linkkeyid1 " +
        //        "and s.s_sampleid in ('"+sampleid+"')";
        String sqlType = "select distinct s.s_sampleid,t.containertypeid,s.sampletypeid,stm.extractiontype " +
                "from s_sample s,trackitem t,u_sampletestcodemap stm " +
                "where s.s_Sampleid=t.linkkeyid1 and s.s_sampleid=stm.s_sampleid and s.s_sampleid in ('" + sampleid + "')";
        DataSet dsType = getQueryProcessor().getSqlDataSet(sqlType);
        if (dsType == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlType;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsType.size() == 0) {
            String errStr = getTranslationProcessor().translate("You can only print Extraction Tube or Elution Tube from here. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        for (int i = 0; i < dsType.size(); i++) {
            String sample = dsType.getValue(i, "s_sampleid");
            String containertypeid = dsType.getValue(i, "containertypeid");
            if (!SAMPLE_CONTAINER_TYPE.contains(containertypeid)) {
                String errStr = getTranslationProcessor().translate("You can only print Extraction Tube or Elution Tube from here.");
                errStr += "\n Selected sample:" + sample + "Container Type:" + containertypeid;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
        String UniqueExtractionType = Util.getUniqueList(dsType.getColumnValues("extractiontype", ";"), ";", true);

        if (UniqueExtractionType.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Please select same extraction type at a time.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        hm.clear();
        hm.put("containertypeid", "Ellution Tube");
        DataSet dsEllu = dsType.getFilteredDataSet(hm);
        hm.clear();
        hm.put("containertypeid", "Extraction Tube");
        dsExtraction = dsType.getFilteredDataSet(hm);
        if (dsEllu.size() > 0) {
            //String sqlElu = "select s.s_sampleid,t.containertypeid,s.sampletypeid from s_sample s,trackitem t,s_Sample s1 where s.s_Sampleid=t.linkkeyid1 and " +
            //       "t.containertypeid='Extraction Tube' and s.u_extractionid =s1.u_extractionid and s1.s_Sampleid in ('" + StringUtil.replaceAll(dsEllu.getColumnValues("s_sampleid", ";"), ";", "','") + "')";
            /*String sqlElu = "select distinct s.s_sampleid,t.containertypeid,s.sampletypeid,stm.extractiontype from s_sample s,trackitem t,s_Sample s1,u_sampletestcodemap stm " +
                    "where s.s_Sampleid=t.linkkeyid1 and s.s_sampleid=stm.s_sampleid and " +
                    "t.containertypeid='Extraction Tube' and s.u_extractionid =s1.u_extractionid " +
                    "and s1.s_Sampleid in ('" + StringUtil.replaceAll(dsEllu.getColumnValues("s_sampleid", ";"), ";", "','") + "')";*/
            String sqlElu = "select distinct sm.sourcesampleid s_sampleid,t.containertypeid,sm.destsampleid eluTube,stm.extractiontype,s.sampletypeid " +
                    "from s_samplemap sm,u_sampletestcodemap stm,trackitem t,s_sample s " +
                    "where s.s_sampleid=sm.sourcesampleid and stm.s_sampleid=sm.sourcesampleid and t.linkkeyid1=stm.s_sampleid and sm.destsampleid in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
            dsEllution = getQueryProcessor().getSqlDataSet(sqlElu);
            if (dsEllution == null) {
                String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
                errStr += "\n Query failed: " + sqlType;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            if (dsEllution.size() == 0) {
                String errStr = getTranslationProcessor().translate("Extraction Tube not found for the selected Elution tube.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            String UniqueEluExtractionType = Util.getUniqueList(dsType.getColumnValues("extractiontype", ";"), ";", true);
            if (UniqueEluExtractionType.split(";").length > 1) {
                String error = getTranslationProcessor().translate("Please select same extraction type at a time.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            for (int i = 0; i < dsEllution.size(); i++) {
                String eluTube = dsEllution.getValue(i, "s_sampleid", "");
                String contype = dsEllution.getValue(i, "containertypeid", "");
                if (!"Extraction Tube".equalsIgnoreCase(contype)) {
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Extraction tube not found for selected Elution tube :" + eluTube);
                }
            }

        }
    }

    /**
     * Description : This method will call PrintLabel action for Extraction tube and Elution tube by different conditions.For Elution
     * tube if sample type is Tissue it will make 1 copy and other than tissue it will make 3 copies.
     *
     * @throws SapphireException
     */
    private void labelPrint() throws SapphireException {
        if (dsExtraction.size() > 0) {
            printCall(dsExtraction, "ExtractionTube", "1");
        }
        if (dsEllution.size() > 0) {
            DataSet dstype = new DataSet();
            dstype.addColumn("s_sampleid", DataSet.STRING);
            dstype.addColumn("copies", DataSet.STRING);
            dstype.addColumn("sampletypeid", DataSet.STRING);
            dstype.addColumn("extractiontype", DataSet.STRING);

            int incr = 0;
            for (int i = 0; i < dsEllution.size(); i++) {
                incr = dstype.addRow();
                String sample = dsEllution.getValue(i, "s_sampleid", "");
                if (Util.isNull(sample)) {
                    String errMsg = getTranslationProcessor().translate("Selected Elution Tube not found.");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }
                String sampletypeid = dsEllution.getValue(i, "sampletypeid", "");
                if (Util.isNull(sampletypeid)) {
                    String errMsg = getTranslationProcessor().translate("Sample type not found for sample:" + sample);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }
                dstype.setValue(incr, "s_sampleid", sample);
                dstype.setValue(incr, "sampletypeid", sampletypeid);

                if (SAMPLE_TYPE.equalsIgnoreCase(sampletypeid)) {
                    dstype.setValue(incr, "copies", "1");
                } else {
                    dstype.setValue(incr, "copies", "3");
                }
                String extractiontype = dsEllution.getValue(i, "extractiontype", "");
                dstype.setValue(incr, "extractiontype", extractiontype);
            }
            hm.clear();
            hm.put("copies", "1");
            DataSet dsCopy1 = dstype.getFilteredDataSet(hm);
            hm.clear();
            hm.put("copies", "3");
            DataSet dsCopy3 = dstype.getFilteredDataSet(hm);
            if (dsCopy1.size() > 0) {
                printCall(dsCopy1, "ExtractionBatch", "1");
            }
            if (dsCopy3.size() > 0) {
                printCall(dsCopy3, "ExtractionBatch", "3");
            }

        }
    }

    /**
     * For calling PrintLabel action.
     *
     * @param ds
     * @param copy
     * @throws SapphireException
     */
    private void printCall(DataSet ds, String tramStop, String copy) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, ds.getColumnValues("s_sampleid", ";"));
        props.setProperty(PrintLabel.EXTRACTION_TYPE, Util.getUniqueList(ds.getColumnValues("extractiontype", ";"), ";", true));
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Molecular");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, tramStop);
        props.setProperty(PrintLabel.TRAMLINE_PROP, "Extraction");
        props.setProperty(PrintLabel.COPIES, copy);
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    private void printlabelForPCR(String sampleid, String printerid) throws SapphireException {
        String sqlCheckElution = "select distinct t.containertypeid,t.linkkeyid1 from trackitem t where  t.linkkeyid1 in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
        DataSet dsCheckElution = getQueryProcessor().getSqlDataSet(sqlCheckElution);
        if (dsCheckElution == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlCheckElution;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsCheckElution.size() == 0) {
            String errStr = getTranslationProcessor().translate("Containertypeid not found for selected sample.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        for (int i = 0; i < dsCheckElution.size(); i++) {
            String contype = dsCheckElution.getValue(i, "containertypeid", "");
            if (!"Ellution Tube".equalsIgnoreCase(contype)) {
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Please select only Elution Tube for label print.");
            }
        }
        String sql = "select s_sampleid from s_sample a, u_repeatops b " +
                "where a.u_extractionid=b.extractionid and b.ispending='Y' and a.s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";

        DataSet dsRptOpsInfo = getQueryProcessor().getSqlDataSet(sql);
        String rptOpsSamples = "";
        String rptOpsSampleArr[] = null;
        HashSet<String> rptOpsSampleArrSet = null;
        if (dsRptOpsInfo != null && dsRptOpsInfo.size() > 0)
            rptOpsSamples = dsRptOpsInfo.getColumnValues("s_sampleid", ";");
        if (!Util.isNull(rptOpsSamples)) {
            rptOpsSampleArr = StringUtil.split(rptOpsSamples, ";");
            if (rptOpsSampleArr != null && rptOpsSampleArr.length > 0)
                rptOpsSampleArrSet = new HashSet<String>(Arrays.asList(rptOpsSampleArr));
        }

        String nonRptSamples = "";
        if (rptOpsSampleArrSet != null && rptOpsSampleArrSet.size() > 0) {
            String sampleidArr[] = StringUtil.split(sampleid, ";");
            if (sampleidArr != null && sampleidArr.length > 0) {
                for (int i = 0; i < sampleidArr.length; i++) {
                    if (!rptOpsSampleArrSet.contains(sampleidArr[i]))
                        nonRptSamples += ";" + sampleidArr[i];
                }
            }
        }

        if (!Util.isNull(nonRptSamples) || !Util.isNull(rptOpsSamples))
            sampleid = nonRptSamples;

        if (!Util.isNull(rptOpsSamples)) {
//            sql = "select (select e.s_sampleid from s_sample e,trackitem f " +
//                    "where e.s_sampleid=f.linkkeyid1 and f.containertypeid='Extraction Tube' and e.u_extractionid=b.orgextractionid and rownum=1) sampleid,stm.extractiontype " +
//                    "from s_sample a, u_repeatops b,u_sampletestcodemap stm " +
//                    "where a.u_extractionid=b.extractionid and a.s_sampleid=stm.s_sampleid and b.ispending='Y' and " +
//                    "a.s_sampleid in ('" + StringUtil.replaceAll(rptOpsSamples, ";", "','") + "')";

            sql = "select a.s_sampleid as sampleid,stm.extractiontype " +
                    "from s_sample a,u_sampletestcodemap stm " +
                    "where a.s_sampleid=stm.s_sampleid and " +
                    "a.s_sampleid in ('" + StringUtil.replaceAll(rptOpsSamples, ";", "','") + "')";

            DataSet dsExtInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsExtInfo != null && dsExtInfo.size() > 0) {
                DataSet result = new DataSet();
                result.addColumn("sampleid", DataSet.STRING);
                result.addColumn("printerid", DataSet.STRING);
                for (int i = 0; i < dsExtInfo.size(); i++) {
                    String tempSampleid = dsExtInfo.getValue(i, "sampleid", "");
                    int rowFoundIndex = result.findRow("sampleid", tempSampleid);
                    if (rowFoundIndex < 0 && !Util.isNull(tempSampleid)) {
                        String extType = dsExtInfo.getValue(i, "extractiontype", "");
                        if (!Util.isNull(extType)) {
                            String tempPrinter = getColorPrinterIdForExtraction(extType);
                            if (!Util.isNull(tempPrinter)) {
                                int rowIndex = result.addRow();
                                result.setValue(rowIndex, "sampleid", tempSampleid);
                                result.setValue(rowIndex, "printerid", tempPrinter);
                            }
                        }
                    }
                }
                if (result != null && result.size() > 0) {
                    PropertyList pcrprop = new PropertyList();
                    pcrprop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, "Sample");
                    pcrprop.setProperty(GenerateLabel.PROPERTY_KEYID1, result.getColumnValues("sampleid", ";"));
                    pcrprop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, "MolElutionTubeRptOps");
                    pcrprop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
                    pcrprop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, result.getColumnValues("printerid", ";"));
                    pcrprop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                    //pcrprop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
                    getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, pcrprop);
                }
            }
        }


        if (!Util.isNull(sampleid)) {
            /*String sqlElu = "select s.s_sampleid,t.containertypeid,s.sampletypeid,stm.extractiontype from s_sample s,trackitem t,s_Sample s1,u_sampletestcodemap stm " +
                    "where s.s_Sampleid=t.linkkeyid1 and s.s_sampleid=stm.s_sampleid and " +
                    "t.containertypeid='Extraction Tube' and s.u_extractionid =s1.u_extractionid " +
                    "and s1.s_Sampleid in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";*/
            String sqlElu = "select distinct sm.sourcesampleid extTube,sm.destsampleid eluTube,stm.extractiontype,t.containertypeid from s_samplemap sm,u_sampletestcodemap stm,trackitem t " +
                    "where stm.s_sampleid=sm.sourcesampleid and t.linkkeyid1=stm.s_sampleid and sm.destsampleid in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
            DataSet dsForExtraction = getQueryProcessor().getSqlDataSet(sqlElu);
            if (dsForExtraction == null) {
                String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
                errStr += "\n Query failed: " + sqlElu;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            if (dsForExtraction.size() == 0) {
                String errStr = getTranslationProcessor().translate("Extraction Tube not found for the selected Elution tube.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            String allExtractionTube = dsForExtraction.getColumnValues("extTube", ";");
            String UniqueEluExtractionType = Util.getUniqueList(dsForExtraction.getColumnValues("extractiontype", ";"), ";", true);
            if (UniqueEluExtractionType.split(";").length > 1) {
                String error = getTranslationProcessor().translate("Please select same extraction type at a time.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            for (int i = 0; i < dsForExtraction.size(); i++) {
                String eluTube = dsForExtraction.getValue(i, "eluTube", "");
                String contype = dsForExtraction.getValue(i, "containertypeid", "");
                if (!"Extraction Tube".equalsIgnoreCase(contype)) {
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Extraction tube not found for selected Elution tube :" + eluTube);
                }
            }

           /* DataSet result = new DataSet();
            result.addColumn("sampleid", DataSet.STRING);
            result.addColumn("printerid", DataSet.STRING);

            for (int i = 0; i < dsForExtraction.size(); i++) {
                String tempSampleid = dsForExtraction.getValue(i, "s_sampleid", "");
                int rowFoundIndex = result.findRow("s_sampleid", tempSampleid);
                if (rowFoundIndex < 0 && !Util.isNull(tempSampleid)) {
                    String extType = dsForExtraction.getValue(i, "extractiontype", "");
                    if (!Util.isNull(extType)) {
                        String tempPrinter = getColorPrinterIdForExtraction(extType);
                        if (!Util.isNull(tempPrinter)) {
                            int rowIndex = result.addRow();
                            result.setValue(rowIndex, "sampleid", tempSampleid);
                            result.setValue(rowIndex, "printerid", tempPrinter);
                        }
                    }
                }
            }*/

            String tempPrinter = getColorPrinterIdForExtraction(UniqueEluExtractionType);
            // if (result != null && result.size() > 0) {
            if (allExtractionTube != null) {
                PropertyList pcrprop = new PropertyList();
                pcrprop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, "Sample");
                pcrprop.setProperty(GenerateLabel.PROPERTY_KEYID1, allExtractionTube);
                pcrprop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, "MolecularElutionTube");
                pcrprop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
                pcrprop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, tempPrinter);
                pcrprop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                //pcrprop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
                getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, pcrprop);
            }
        }

    }

    private String getPrinterId() throws SapphireException {
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
       /* String sql = "select a.printerid userprinter," +
                "(select printerid from u_departmentprinters where u_departmentprinters.departmentid = a.departmentid and nvl(isdefault,'N')='Y' and rownum=1) deptprinter " +
                "from u_userdefaultprinter a " +
                "where " +
                "a.sysuserid='"+userId+"' and a.departmentid='"+depratmentId+"'";*/
        /*String sql = "select " +
                "  (select a.printerid from u_userdefaultprinter a " +
                "  where a.sysuserid='" + userId + "' and a.departmentid='" + depratmentId + "') as userprinter, " +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '" + depratmentId + "' " +
                " and nvl(isdefault,'N')='Y' and rownum=1) as deptprinter " +
                " from dual ";*/
        String sql = "select " +
                " (select a.printerid from u_userdefaultprinter a " +
                " where a.sysuserid='" + userId + "' and a.departmentid= '" + depratmentId + "' and a.extractiontype is null) as userprinter," +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '" + depratmentId + "' " +
                "  and nvl(isdefault,'N')='Y' and extractiontype is null) as deptprinter " +
                "  from dual";
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo != null && dsInfo.size() > 0) {
            String userprinter = dsInfo.getValue(0, "userprinter", "");
            String deptprinter = dsInfo.getValue(0, "deptprinter", "");
            if (!Util.isNull(userprinter)) {
                printerId = userprinter;
            } else if (!Util.isNull(deptprinter)) {
                printerId = deptprinter;
                // assignDeptDefaultPrinterToUser(userId, depratmentId, printerId);
            }
        }
        return printerId;
    }

    private void assignDeptDefaultPrinterToUser(String user, String userDepartment, String printerid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "User");
        props.setProperty("sysuserid", user);
        props.setProperty("departmentid", userDepartment);
        props.setProperty("printerid", printerid);
        props.setProperty("printertype", "Device");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "userdefaultprinter_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in change printer.Error:" + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /* private String getColorPrinterIdForExtraction(String extractiontype) throws SapphireException {
         String printerId = "";
         String depratmentId = connectionInfo.getDefaultDepartment();
         String sql = "select a.addressid from address a,u_departmentprinters u " +
                 " where a.addresstype = 'Device' and a.U_EXTRACTIONTYPE = '" + extractiontype + "' and a.addressid=u.printerid and " +
                 "u.departmentid='" + depratmentId + "' and  rownum=1";
         DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
         if (dsInfo == null) {
             throw new SapphireException("Please contact your admin.Query failed.Sql:" + sql);
         }
         if (dsInfo.size() > 0) {
             String deptprinter = dsInfo.getValue(0, "addressid", "");
             if (Util.isNull(deptprinter)) {
                 throw new SapphireException("Printer is not defined for extractiontype " + extractiontype + " in " + depratmentId + " department.");
             } else {
                 printerId = deptprinter;
             }
         } else {
             throw new SapphireException("Printer is not defined for extractiontype " + extractiontype + " in " + depratmentId + " department.");
         }
         return printerId;
     }old logic*/
    private String getColorPrinterIdForExtraction(String extractiontype) throws SapphireException {
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
        /*String sql = "select a.addressid from address a,u_departmentprinters u " +
                " where a.addresstype = 'Device' and a.U_EXTRACTIONTYPE = '"+extractiontype+"' and a.addressid=u.printerid and " +
                "u.departmentid='"+depratmentId+"' and  rownum=1";*/
        String sql = "select " +
                " (select a.printerid from u_userdefaultprinter a " +
                " where a.sysuserid='" + userId + "' and a.departmentid='" + depratmentId + "' and a.extractiontype ='" + extractiontype + "') as userprinter, " +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '" + depratmentId + "' " +
                " and nvl(isdefault,'N')='Y' and extractiontype ='" + extractiontype + "') as deptprinter from dual";
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo == null) {
            throw new SapphireException("Please contact your admin.Query failed.Sql:" + sql);
        }
        if (dsInfo.size() > 0) {
            //String deptprinter = dsInfo.getValue(0,"addressid",""); old
            String userprinter = dsInfo.getValue(0, "userprinter", "");
            String deptprinter = dsInfo.getValue(0, "deptprinter", "");
            if (!Util.isNull(userprinter)) {
                printerId = userprinter;
            } else if (!Util.isNull(deptprinter)) {
                printerId = deptprinter;
            } else {
                throw new SapphireException(extractiontype + " Printer is not defined for " + userId + " user in " + depratmentId + " department.");
            }
        } else {
            throw new SapphireException(extractiontype + " Printer is not defined for " + userId + " user in " + depratmentId + " department.");
        }
        return printerId;
    }
}