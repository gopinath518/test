package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by mpandey on 6/9/2016.
 * Purpose - 1.Create extractiontube/pooled sample on basis of sampletype and extraction type
 * 2. Also can able to change ectractiontype and create extractiontube
 * 1.mandatory input- parentsampleid
 * 2.mandatory input- parentsampleid,extractiontype
 */
public class CreateExtractionTube extends BaseAction {


    String EXTRACTIONTYPE = "";
    String SUFFIX = "";
    String REQUESTID = "";

    public void processAction(PropertyList properties) throws SapphireException {
        //TODO validate property list have atleast one H&E and one Unstained slide. hnesample, testslide, ExtractionTubePrompt

        String hneSampleID = properties.getProperty("hnesample", "");
        REQUESTID = properties.getProperty("requestid", "");
        if (!Util.isNull(hneSampleID)) {

            String testSlide = properties.getProperty("testslide", "");
            String selectedSampleIDs = getAllTestSlides(hneSampleID, testSlide);


            properties.setProperty("keyid1", selectedSampleIDs);

            if (Util.isNull(selectedSampleIDs)) {
                String error = getTranslationProcessor().translate("Please select atleast one specimen to create extraction tube.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
        }
        //String hneSampleID = getHnESampleID(selectedSampleIDs);
        //for sample Tissue/Block there must be a H&E.
        String newsampleid = "";
        //Checking Conditions to route flow
        newsampleid = routingFlow(properties);
        updateTrackitem(newsampleid);
        properties.put("newkeyid1", newsampleid);
        if (!Util.isNull(hneSampleID)) {
            copyDownPathologyProperty(newsampleid, hneSampleID);
        }
    }

    /**
     * This function is use to validate that  provided hne and unstained slides
     * must belongs to same parent.
     *
     * @param hneSampleID
     * @param testSlide
     * @throws SapphireException
     */
    private void validateScanSamples(String hneSampleID, String testSlide) throws SapphireException {
        if (Util.isNull(hneSampleID)) {
            throw new SapphireException("H&E Sample cannot be blank.");
        }
        if (Util.isNull(testSlide)) {
            throw new SapphireException("Test Sample cannot be blank.");
        }

        String sql = "select distinct(sm.sourcesampleid) from s_sample s,s_samplemap sm where sm.destsampleid in ('" + hneSampleID + "','" + testSlide + "') and" +
                " s.s_sampleid = sm.destsampleid and exists(select s_sampleid from s_sample where u_type='H' and s_sampleid = '" + hneSampleID + "')" +
                " and exists(select s_sampleid from s_sample where u_type='U' and s_sampleid = '" + testSlide + "')";


        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = " Something wrong happened. Contact your Administrator.";
            err += "\n Sql Failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.getRowCount() == 0) {
            String err = "Either " + hneSampleID + " is not a valid H&E Sample or " + testSlide + " is not a valid Test Slide.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.getRowCount() > 1) {
            String err = "H&E Sample:'" + hneSampleID + "', and Test Slide: '" + testSlide + "' belong to different block.";
            err += "\n Cannot create extraction tube.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
    }

    /**
     * This function is use to get all siblings test slides of
     * provided hne and a unstained slides
     *
     * @param hneSampleID
     * @param testSlide
     * @return
     * @throws SapphireException
     */
    private String getAllTestSlides(String hneSampleID, String testSlide) throws SapphireException {
        validateScanSamples(hneSampleID, testSlide);
        String sql =
                "select ss.s_sampleid from s_samplemap ssm, s_sample ss  where ssm.DESTSAMPLEID = ss.s_sampleid and ss.u_type='U' and\n" +
                        " ssm.SOURCESAMPLEID = (" +
                        " select sm.SOURCESAMPLEID from s_samplemap sm, s_sample s" +
                        " where sm.SOURCESAMPLEID = s.s_sampleid" +
                        " and sm.DESTSAMPLEID = '" + hneSampleID + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = " Something wrong happened. Contact your Administrator.";
            err += "\n Sql Failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.getRowCount() == 0) {
            String err = "Either " + hneSampleID + " is not a valid H&E Sample or " + testSlide + " is not a valid Test Slide.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        String allTestSlides = ds.getColumnValues("s_sampleid", ";");
        return allTestSlides;
    }

    /**
     * This function is use to route the flow between heme , block and other .
     * as per extraction type and samp letype
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String routingFlow(PropertyList properties) throws SapphireException {
        String newsampleid = "";
        String parentsampleid = properties.getProperty("keyid1");
        String changeextraction = properties.getProperty("changeextractiontype", "");
        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String s_sql = "SELECT distinct sm.extractiontype,s.u_sampleinformation,s.sampletypeid" +
                " FROM U_SAMPLETESTCODEMAP sm,s_sample s" +
                " WHERE s.s_sampleid=sm.s_sampleid and sm.s_sampleid  IN ('" + psample + "') and sm.extractiontype is not null";
        DataSet dsextrac = getQueryProcessor().getSqlDataSet(s_sql);
        if (dsextrac == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + s_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsextrac.size() == 0 || dsextrac.getValue(0, "extractiontype", "").length() == 0) {
            String error = getTranslationProcessor().translate("Extraction type is not defined for Samples");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        EXTRACTIONTYPE = dsextrac.getColumnValues("extractiontype", ";");
        EXTRACTIONTYPE = Util.getUniqueList(EXTRACTIONTYPE, ";", true);
        String sampletype = dsextrac.getColumnValues("sampletypeid", ";");
        sampletype = Util.getUniqueList(sampletype, ";", true);
        if (sampletype.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Sample have more then one sample type ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (changeextraction.length() > 0) {
            if (EXTRACTIONTYPE.split(";").length > 1) {
                String error = getTranslationProcessor().translate("Sample have more then one extraction type ");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            EXTRACTIONTYPE = changeextraction;
        }
        String[] extractarr = StringUtil.split(EXTRACTIONTYPE, ";");
        String[] samptype = StringUtil.split(sampletype, ";");

        SUFFIX = dsextrac.getValue(0, "u_sampleinformation", "");
        if (!samptype[0].equalsIgnoreCase("Tissue")) {        // logic for HemeSample modified by Subhra

            //if (extractarr.length >1 && !SUFFIX.equalsIgnoreCase("Tumor/Normal")) {//todo check logic

            newsampleid = hemeextractiontube(properties, extractarr);
        } else {
            if (extractarr.length == 1 && SUFFIX.equalsIgnoreCase("Tumor/Normal")) {
                newsampleid = tissueextractiontube(properties);
            } else
                newsampleid = normalextractiontube(properties);
        }
        return newsampleid;
    }

    /**
     * This function is use to create pool sample,
     * copy down test codes from parent sample to child sample .
     * mark samples as scrapped , create unique extraction id
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String normalextractiontube(PropertyList properties) throws SapphireException {
        String newsampleid = "";
        String parentsampleid = properties.getProperty("keyid1");
        String changeextraction = properties.getProperty("changeextractiontype", "");
        String prevextractionds = "select sm.destsampleid,(select u_extractionid from s_sample where s_sample.s_sampleid = sm.destsampleid) extractionid,s.u_accessionid, s.collectiondt from s_sample s, s_samplemap sm where \n" +
                "s.u_accessionid = (select u_accessionid from s_sample where s_sampleid = '" + parentsampleid + "')\n" +
                "and s.collectiondt = (select collectiondt from s_sample where s_sampleid = '" + parentsampleid + "')\n" +
                "and s.s_sampleid = sm.sourcesampleid AND (SELECT u_extractionid\n" +
                "  FROM s_sample\n" +
                "  WHERE s_sample.s_sampleid = sm.destsampleid ) IS NOT NULL";

        DataSet dsprevextractionid = getQueryProcessor().getSqlDataSet(prevextractionds);
        if (dsprevextractionid == null) {

        }

        if (dsprevextractionid.size() > 0) {
            int poolcopies = 1;
            newsampleid = createPoolSample(parentsampleid, poolcopies);
            editSampleSDI(newsampleid, parentsampleid, SUFFIX);
            addTestCode(newsampleid, parentsampleid); //todo for testing 22/7
            isSacraped(parentsampleid);
            String exsql = "select u_extractionid from s_sample where s_sampleid = '" + dsprevextractionid.getValue(0, "destsampleid") + "'";
            DataSet extraxtds = getQueryProcessor().getSqlDataSet(exsql);
            String extractionid = "";
            if (REQUESTID.length() > 0)
                extractionid = getReExtractExtractionId(REQUESTID);
            else
                extractionid = extraxtds.getColumnValues("u_extractionid", ";");
            if (extractionid.length() > 0)
                updateExtractionID(newsampleid, extractionid);

            if (changeextraction.length() > 0)
                updateExtractionType(newsampleid, EXTRACTIONTYPE);

        } else {
            int poolcopies = 1;
            newsampleid = createPoolSample(parentsampleid, poolcopies);
            editSampleSDI(newsampleid, parentsampleid, SUFFIX);
            addTestCode(newsampleid, parentsampleid); //todo for testing 22/7
            isSacraped(parentsampleid);
            String extractionid = "";
            if (REQUESTID.length() > 0) {
                extractionid = getReExtractExtractionId(REQUESTID);
                if (extractionid.length() > 0)
                    updateExtractionID(newsampleid, extractionid);
            } else {
                SUFFIX = getSuffixOnCond(newsampleid, SUFFIX);
                createExtractionID(newsampleid, EXTRACTIONTYPE, SUFFIX);
            }
            if (changeextraction.length() > 0)
                updateExtractionType(newsampleid, EXTRACTIONTYPE);
        }

        return newsampleid;
    }

    /**
     * This function is use mark a sample as re Extracted
     * by updating its extractionid
     *
     * @param requestid
     * @return
     */
    private String getReExtractExtractionId(String requestid) {
        String ExtractionId = "";
        String rxSuffix = "RX";
        String reExtractCount = "";
        String sql = "select ro.orgextractionid,rod.operation from u_repeatops ro,u_repeatopsdetail rod where ro.u_repeatopsid=rod.u_repeatopsid and ro.orgextractionid=(select orgextractionid from u_repeatops where requestid='" + requestid + "' )and rod.operation='RX'";
        DataSet dsRepeat = getQueryProcessor().getSqlDataSet(sql);
        if (dsRepeat.size() > 0 && dsRepeat != null) {
            ExtractionId = dsRepeat.getValue(0, "orgextractionid");
            reExtractCount = String.valueOf(dsRepeat.getRowCount());
            if (dsRepeat.size() == 1)
                ExtractionId = ExtractionId + "-" + rxSuffix;
            else
                ExtractionId = ExtractionId + "-" + reExtractCount + rxSuffix;
        }
        return ExtractionId;
    }

    /**
     * This function is use to create pool sample,
     * copy down test codes from parent sample to child sample .
     * mark samples as scrapped , create unique extraction id
     *
     * @param properties
     * @param extractarr
     * @return
     * @throws SapphireException
     */
    private String hemeextractiontube(PropertyList properties, String[] extractarr) throws SapphireException {
        String newsampleid = "";
        if (extractarr.length == 1) {
            String parentsampleid = properties.getProperty("keyid1");

            String exttypestring = "";
            int poolcopies = extractarr.length;

            newsampleid = createPoolSample(parentsampleid, poolcopies);
            editSampleSDI(newsampleid, parentsampleid, SUFFIX);

            String prevextractionds = "select sm.destsampleid,(select u_extractionid from s_sample where s_sample.s_sampleid = sm.destsampleid) extractionid,s.u_accessionid, s.collectiondt from s_sample s, s_samplemap sm where \n" +
                    "s.u_accessionid = (select u_accessionid from s_sample where s_sampleid = '" + parentsampleid + "')\n" +
                    "and s.collectiondt = (select collectiondt from s_sample where s_sampleid = '" + parentsampleid + "')\n" +
                    "and s.s_sampleid = sm.sourcesampleid AND (SELECT u_extractionid\n" +
                    "  FROM s_sample\n" +
                    "  WHERE s_sample.s_sampleid = sm.destsampleid ) IS NOT NULL";

            DataSet dsprevextractionid = getQueryProcessor().getSqlDataSet(prevextractionds);

            if (dsprevextractionid == null) {
                String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
                errmsg += "\nQuery failed:\n" + prevextractionds;
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }


            if (dsprevextractionid.size() > 0) {

                String exsql = "select u_extractionid from s_sample where s_sampleid = '" + dsprevextractionid.getValue(0, "destsampleid") + "'";
                DataSet extraxtds = getQueryProcessor().getSqlDataSet(exsql);
                String extractionid = "";
                if (REQUESTID.length() > 0)
                    extractionid = getReExtractExtractionId(REQUESTID);
                else
                    extractionid = extraxtds.getColumnValues("u_extractionid", ";");
                updateExtractionID(newsampleid, extractionid);
                addHEMETestCode(newsampleid, parentsampleid, extractarr);


            } else {

                for (int i = 0; i < extractarr.length; i++) {

                    if (REQUESTID.length() > 0) {
                        String extractionid = getReExtractExtractionId(REQUESTID);
                        if (extractionid.length() > 0)
                            updateExtractionID(newsampleid, extractionid);
                    } else {
                        SUFFIX = getSuffixOnCond(newsampleid, SUFFIX);
                        createExtractionID(newsampleid, extractarr[i], SUFFIX);
                    }
                    exttypestring = exttypestring + ";" + extractarr[i];
                }

                addHEMETestCode(newsampleid, parentsampleid, extractarr);

            }
        }

        return newsampleid;

    }

    /**
     * This function is use to get suffix for extraction id  on certain conditions .
     *
     * @param newsampleid
     * @param sampleinfo
     * @return
     */
    private String getSuffixOnCond(String newsampleid, String sampleinfo) {
        if (sampleinfo.equalsIgnoreCase("Donor")) {
            String s_sql = "select s_sampleid from s_sample where s_sampleid='" + newsampleid + "' and u_chimerismflag='Y'";
            DataSet dssample = getQueryProcessor().getSqlDataSet(s_sql);
            if (dssample.size() > 0)
                return "D";
        } else if (sampleinfo.equalsIgnoreCase("Recipient")) {
            String s_sql = "select s_sampleid from s_sample where s_sampleid='" + newsampleid + "' and u_chimerismflag='Y'";
            DataSet dssample = getQueryProcessor().getSqlDataSet(s_sql);
            if (dssample.size() > 0)
                return "RC";
        } else if (sampleinfo.equalsIgnoreCase("Normal")) {
            String s_sql = "select s_sampleid from u_sampletestcodemap where s_sampleid ='" + newsampleid + "' and testname='msi'";
            DataSet dssample = getQueryProcessor().getSqlDataSet(s_sql);
            if (dssample.size() > 0)
                return "N";
        } else if (sampleinfo.equalsIgnoreCase("Tumor")) {
            String s_sql = "select s_sampleid from u_sampletestcodemap where s_sampleid ='" + newsampleid + "' and testname='msi'";
            DataSet dssample = getQueryProcessor().getSqlDataSet(s_sql);
            if (dssample.size() > 0)
                return "T";
        } else {
            String s_sql = "select s.s_sampleid from s_sample s,U_SAMPLETESTCODEMAP st where s.s_sampleid=st.s_sampleid and s.sampletypeid='Urine' " +
                    "and st.testname='Prostate' and s.s_sampleid ='" + newsampleid + "'";
            DataSet dssample = getQueryProcessor().getSqlDataSet(s_sql);
            if (dssample.size() > 0)
                return "U";
        }
        return "";
    }

    /**
     * This function is use to create pool sample,
     * copy down test codes from parent sample to child sample .
     * mark samples as scrapped , create unique extraction id
     *
     * @param newsampleid
     * @param parentsampleid
     * @param extractiontype
     * @throws SapphireException
     */

    private void addHEMETestCode(String newsampleid, String parentsampleid, String[] extractiontype) throws SapphireException {

        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");

        String tc_sql = "select distinct lvtestcodeid,extractiontype,ispanel  from u_sampletestcodemap where s_sampleid in('" + psample + "')";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);

        if (dstestcode == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + tc_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dstestcode.size() == 0) {
            String error = getTranslationProcessor().translate("SampleID " + psample + " doesn't have any Test !");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dstestcode.size() > 0) {

            DataSet dsSamplefinal = new DataSet();
            dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
            dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
            dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

            DataSet sampleFiltered = new DataSet();
            HashMap hmFilter = new HashMap();
            for (int i = 0; i < extractiontype.length; i++) {
                hmFilter.clear();
                sampleFiltered.clear();
                hmFilter.put("extractiontype", extractiontype[i]);
                sampleFiltered = dstestcode.getFilteredDataSet(hmFilter);
                for (int j = 0; j < sampleFiltered.size(); j++) {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", newsampleid);
                    dsSamplefinal.setValue(rowID, "lvtestcode", sampleFiltered.getValue(j, "lvtestcodeid"));
                    dsSamplefinal.setValue(rowID, "ispanel", sampleFiltered.getValue(j, "ispanel", ""));
                }
            }


            PropertyList hsAddTestCode = new PropertyList();
            hsAddTestCode.clear();
            hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
            hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
            hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
            hsAddTestCode.setProperty("workitemflag", "N");//todo
            hsAddTestCode.setProperty("bypassvalidation", "Y");

            try {
                getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch. ");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }

    /**
     * This function is use to create pool sample,
     * copy down test codes from parent sample to child sample .
     * mark samples as scrapped , create unique extraction id
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String tissueextractiontube(PropertyList properties) throws SapphireException {
        String parentsampleid = properties.getProperty("keyid1");
        String changeextraction = properties.getProperty("changeextractiontype", "");
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sampinfoarr = SUFFIX.replaceAll("/", ";");
        int poolcopies = 2;
        String newsampleid = createPoolSample(parentsampleid, poolcopies);
        editSampleSDI(newsampleid, parentsampleid, sampinfoarr);
        String[] newsamparr = newsampleid.split(";");
        createExtractionID(newsamparr[0], EXTRACTIONTYPE, "T");
        String s_sql = "select u_extractionid  from s_sample where s_sampleid = '" + newsamparr[0] + "'";
        DataSet extract = getQueryProcessor().getSqlDataSet(s_sql);
        NormalExtractionID(newsamparr[1], extract.getValue(0, "u_extractionid", ""), "N");
        addTestCode(newsamparr[0], parentsampleid);
        addNormalTestCode(newsamparr[1], parentsampleid);
        isSacraped(parentsampleid);
        if (changeextraction.length() > 0)
            updateExtractionType(newsampleid, EXTRACTIONTYPE);

        return newsampleid;
    }

    /**
     * This function is use to create extraction id for sample type "Normal".
     *
     * @param newsampleid
     * @param u_extractionid
     * @param normal
     * @throws SapphireException
     */
    private void NormalExtractionID(String newsampleid, String u_extractionid, String normal) throws SapphireException {
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();

        String[] newExtractionID = u_extractionid.split("-");
        editProp.setProperty("sdcid", "Sample");
        editProp.setProperty("keyid1", newsampleid);
        editProp.setProperty("u_extractionid", newExtractionID[0] + "-" + newExtractionID[1] + "-" + normal);

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This function is use to copy down test from parent to child if test code with isnormal
     * flag "Y".
     *
     * @param parentsampleid
     * @param newsampleid
     * @throws SapphireException
     */
    private void addNormalTestCode(String parentsampleid, String newsampleid) throws SapphireException {
        String psample = parentsampleid.replaceAll(";", "','");

        String tc_sql = "select lvtestcodeid,extractiontype,isnormal  from u_sampletestcodemap where isnormal='Y'and s_sampleid in('" + psample + "')";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        if (dstestcode == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + tc_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        if (dstestcode.size() == 0) {
            String msg = getTranslationProcessor().translate(psample + "Samples don't have any testcode.");
            msg += "\nPlease scan correct samples:\n" + tc_sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, msg);
        }
        if (dstestcode.size() > 0) {

            DataSet dsSamplefinal = new DataSet();
            dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
            dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
            dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

            for (int j = 0; j < dsSamplefinal.size(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", newsampleid);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));
            }


            PropertyList hsAddTestCode = new PropertyList();
            hsAddTestCode.clear();
            hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
            hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
            hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
            hsAddTestCode.setProperty("bypassvalidation", "Y");//added for ngs
            hsAddTestCode.setProperty("workitemflag", "N");//todo
            try {
                getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch ");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }

    /**
     * This function is use to update information of newly created sample.
     *
     * @param newsampleid
     * @param parentsampleid
     * @param sampleinfo
     * @throws SapphireException
     */
    private void editSampleSDI(String newsampleid, String parentsampleid, String sampleinfo) throws SapphireException {
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "select DISTINCT u_accessionid,u_sampleinformation,u_clientspecimenid,u_currentmovementstep  from s_sample where s_sampleid " +
                " in('" + qrsample + "')";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sql);

        if (dsSamp.size() == 0) {
            String error = getTranslationProcessor().translate("Sample must belongs to same accesion ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, newsampleid);
        editProp.setProperty("u_accessionid", StringUtil.repeat(dsSamp.getValue(0, "u_accessionid", ""), newsampleid.split(";").length, ";"));
        editProp.setProperty("u_sampleinformation", sampleinfo);
        editProp.setProperty("u_clientspecimenid", StringUtil.repeat(dsSamp.getValue(0, "u_clientspecimenid", ""), newsampleid.split(";").length, ";"));
        editProp.setProperty("u_currentmovementstep", StringUtil.repeat(dsSamp.getValue(0, "u_currentmovementstep", ""), newsampleid.split(";").length, ";"));

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This function is used to update extraction type if change extractiontype
     * have same value.
     *
     * @param newsampleid
     * @param extractiontype
     * @throws SapphireException
     */

    private void updateExtractionType(String newsampleid, String extractiontype) throws SapphireException {
        String sampleqr = newsampleid.replaceAll(";", "','");
        String sample_sql = "select u_sampletestcodemapid,extractiontype from U_SAMPLETESTCODEMAP where s_sampleid in ('" + sampleqr + "')";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sample_sql);

        if (dsSamp == null) {
            String error = getTranslationProcessor().translate("Query Failed");
            error += sample_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, dsSamp.getColumnValues("u_sampletestcodemapid", ";"));
        // editProp.setProperty("extractiontype", StringUtil.repeat(extractiontype, dsSamp.getRowCount()));
        editProp.setProperty("extractiontype", StringUtil.repeat(extractiontype, dsSamp.size(), ";"));
        // editProp.setProperty("propsmatch", "Y");

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This function is use to copy down test from parent to child .
     *
     * @param newsampleid
     * @param parentsampleid
     * @throws SapphireException
     */

    private void addTestCode(String newsampleid, String parentsampleid) throws SapphireException {

        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");

        String tc_sql = "select distinct lvtestcodeid,ispanel from u_sampletestcodemap where lvtestpanelid is null and lvtestcodeid is not null and  s_sampleid in('" + psample + "')";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        String tp_sql = "select distinct lvtestpanelid,ispanel from u_sampletestcodemap where lvtestpanelid is not null and s_sampleid in('" + psample + "')";
        DataSet dstespanel = getQueryProcessor().getSqlDataSet(tp_sql);
        String[] samparr = StringUtil.split(newsampleid, ";");

        if (dstestcode.size() == 0 && dstespanel.size() == 0) {
            String error = getTranslationProcessor().translate("SampleID " + psample + " doesn't have any Test !");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

        for (String currentsamp : samparr) {
            for (int j = 0; j < dstestcode.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));

            }
        }

        for (String currentsamp : samparr) {
            for (int j = 0; j < dstespanel.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstespanel.getValue(j, "lvtestpanelid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstespanel.getValue(j, "ispanel", ""));

            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        hsAddTestCode.setProperty("bypassvalidation", "Y");
        hsAddTestCode.setProperty("workitemflag", "N");//todo
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * @param parentsampleid
     * @throws SapphireException
     */

    private void isparent(String parentsampleid) throws SapphireException {

        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String s_sql = "SELECT   s.s_sampleid,a.SOURCESAMPLEID" +
                "  FROM labvantage.s_samplemap a," +
                "    labvantage.s_sample s" +
                "  WHERE s.s_sampleid IN ('" + psample + "')" +
                "  AND s.s_sampleid=a.destsampleid (+)" +
                "  AND s.POOLEDFLAG   IS NULL";
        DataSet dsChild = getQueryProcessor().getSqlDataSet(s_sql);
        if (dsChild.size() == 0 || dsChild == null) {
            String error = getTranslationProcessor().translate("Please select some Sample");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        for (int i = 0; i < dsChild.size(); i++) {
            if (dsChild.getValue(i, "SOURCESAMPLEID", "").length() == 0) {
                String error = getTranslationProcessor().translate("Samples: " + dsChild.getValue(i, "s_sampleid", "") + " is a Parent Sample");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }

        }
        String uniqueParent = Util.getUniqueList(dsChild.getColumnValues("SOURCESAMPLEID", ";"), ";", true);
        if (uniqueParent.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Samples must belongs to same Parent");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * This fuction is use to mark a sample as scrapped .
     *
     * @param parentsampleid
     * @throws SapphireException
     */


    private void isSacraped(String parentsampleid) throws SapphireException {
        PropertyList propEditSDI = new PropertyList();
        propEditSDI.setProperty("sdcid", "Sample");
        propEditSDI.setProperty("keyid1", parentsampleid);
        propEditSDI.setProperty("u_isscrap", "Y");


        try {
            getActionProcessor().processAction("EditSDI", "1", propEditSDI);
        } catch (ActionException e) {
            String error = getTranslationProcessor().translate("Please select atleast a sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /**
     * This function is use to create extraction id .
     *
     * @param newsampleid
     * @param EXTRACTIONTYPE
     * @param SUFFIX
     * @throws SapphireException
     */

    private void createExtractionID(String newsampleid, String EXTRACTIONTYPE, String SUFFIX) throws SapphireException {
        PropertyList hsCreateExtractionID = new PropertyList();
        hsCreateExtractionID.clear();
        hsCreateExtractionID.setProperty("sampleid", newsampleid);
        hsCreateExtractionID.setProperty("EXTRACTIONTYPE", EXTRACTIONTYPE);
        hsCreateExtractionID.setProperty("SUFFIX", SUFFIX);

        try {
            getActionProcessor().processAction("CreateExtractionID", "1", hsCreateExtractionID);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed CreateExtractionID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * This function is use to create pool sample
     *
     * @param parentsampleid
     * @param poolcopies
     * @return
     * @throws SapphireException
     */

    private String createPoolSample(String parentsampleid, int poolcopies) throws SapphireException {

        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "SELECT distinct t.qtycurrent,t.containertypeid,t.custodialdepartmentid," +
                "  t.qtyunits,s.u_sampleinformation" +
                " FROM trackitem t," +
                "  s_sample s" +
                " WHERE t.linksdcid = 'Sample'" +
                " AND t.linkkeyid1  = s.s_sampleid" +
                " AND s.s_sampleid " +
                " in('" + qrsample + "')";
        DataSet dstrack = getQueryProcessor().getSqlDataSet(sql);

        if (dstrack.size() == 0) {
            String error = getTranslationProcessor().translate("Trackitem is not defined for sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        PropertyList props = new PropertyList();
        String newkeyid1;
        props.setProperty("sampleid", parentsampleid);
        props.setProperty("quantity", "10");
        props.setProperty("poolquantity", "10");
        props.setProperty("poolcopies", String.valueOf(poolcopies));
        // props.setProperty("poolcontainertypeid", "Extraction Tube");//Added to see in ngssamplelistpage
        props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        props.setProperty("poolcustodialdepartmentid", connectionInfo.getDefaultDepartment()); //todo
        //   props.setProperty("sstudyid", "NeoClinical"); ///TODO Hadcoded need to remove later
        //   props.setProperty("u_currentmovementstep", currentmovementstep);
        //  props.setProperty("u_accessionid", accessionid);
        //  props.setProperty("copydowncolumns", "sstudyid;u_currentmovementstep;u_accessionid;sampletypeid");

        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        newkeyid1 = props.getProperty("newkeyid1", "");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        Util.setRootForPoolSample(newkeyid1, parentsampleid,getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        return newkeyid1;
    }

    /**
     * This function is use to update container type of
     * child sample as "Extraction Tube".
     *
     * @param childsampleid
     * @throws SapphireException
     */

    private void updateTrackitem(String childsampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", "Extraction Tube");
        // props.setProperty("custodialuserid", currentuser);
        // props.setProperty("custodialdepartmentid", defaultdepartment);
        // props.setProperty("custodytakendt", "n");
        // props.setProperty("qtycurrent", volume);
        // props.setProperty("qtyunits", units);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * @param selectedSampleIDs
     * @return
     * @throws SapphireException
     */

    private String getHnESampleID(String selectedSampleIDs) throws SapphireException {
        String sql = "select s_sampleid from s_sample where u_type='H' and s_sampleid in ('" + StringUtil.replaceAll(selectedSampleIDs, ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null) {
            String error = "Something error occured. Please contact your Administrator.";
            error += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        if (ds.getRowCount() == 0) {
            return "";
        }
        // TODO This applicable for Tissue & Block
        return ds.getValue(0, "s_sampleid", "");

    }

    /**
     * This function is use to update the pathology property of hne to extraction tube .
     *
     * @param extractionTubeSampleID
     * @param hneSampleID
     * @throws SapphireException
     */

    private void copyDownPathologyProperty(String extractionTubeSampleID, String hneSampleID) throws SapphireException {
        String sql = "select u_tumorcircled,u_totaltumor,u_pathologycomments from s_sample where s_sampleid ='" + hneSampleID + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null) {
            String error = "Something error occured. Please contact your Administrator.";
            error += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        if (ds.getRowCount() == 0) {
            return;
        }

        PropertyList props = new PropertyList();
        props.setProperty("sdcid", "Sample");
        props.setProperty("keyid1", extractionTubeSampleID);
        props.setProperty("u_tumorcircled", ds.getValue(0, "u_tumorcircled", ""));
        props.setProperty("u_totaltumor", ds.getValue(0, "u_totaltumor", ""));
        props.setProperty("u_pathologycomments", ds.getValue(0, "u_pathologycomments", ""));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException e) {
            String error = getTranslationProcessor().translate("Cannot update %tumor circled ");
            error += "\n" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

    }

    /**
     * This Function is use to update Extraction id in sample sdi.
     *
     * @param sample
     * @param extractionid
     * @throws SapphireException
     */
    private void updateExtractionID(String sample, String extractionid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sample);
        pl.setProperty("u_extractionid", extractionid);

        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Extraction id not updated for " + sample);
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

    }
}
