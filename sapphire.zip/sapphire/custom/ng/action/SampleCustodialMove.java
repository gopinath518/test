package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by ajha on 5/26/2016.
 * This action is used to Assign department
 * Mandatory Input:
 * @param1 : Department
 * @param2 : Sampleid
 * @throws : SapphireException
 */

public class SampleCustodialMove extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String dept=properties.getProperty("department");
        String sampleid=properties.getProperty("sampleid");
        String movementStep=properties.getProperty("movementstep");
        String newTramstop=properties.getProperty("newtramstop");
        String sample= StringUtil.replaceAll(sampleid,";","','");
        String defaultDeprtment = connectionInfo.getDefaultDepartment();

        if(Util.isNull(dept)){
            PropertyList p1=new PropertyList();
            p1.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
            p1.setProperty(EditSDI.PROPERTY_KEYID1,sampleid);
            p1.setProperty("u_currentmovementstep",movementStep);
            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,p1);


            PropertyList prop=new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1,sampleid);
            prop.setProperty("custodialdepartmentid",defaultDeprtment);
            prop.setProperty("custodialuserid","");
            if(Util.isNull(newTramstop)){}else {
                prop.setProperty("u_currenttramstop", newTramstop);
            }
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);

        }else {
            String site = defaultDeprtment.substring(0,defaultDeprtment.indexOf("-")+1);
            dept = dept.contains("-") ? dept.substring(dept.indexOf("-") + 1) :  dept ;
            dept = site + dept ;

            PropertyList p1=new PropertyList();
            p1.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
            p1.setProperty(EditSDI.PROPERTY_KEYID1,sampleid);
            p1.setProperty("u_currentmovementstep",movementStep);
            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,p1);


            PropertyList prop=new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1,sampleid);
            prop.setProperty("custodialdepartmentid",dept);
            prop.setProperty("custodialuserid","");
            if(Util.isNull(newTramstop)){}else {
                prop.setProperty("u_currenttramstop", newTramstop);
            }
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);

        }

    }

}
