package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 6/18/2016.
 */
public class NGPoolSample extends BaseAction {


    /*
    *   OOB method override for creaeting pool sample and adding to batch
    * */
    public void processAction(PropertyList properties) throws SapphireException {
        super.processAction(properties);
        String batchid = properties.getProperty("batchid", "");

        String newSampleid = createPoolSample(properties);
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        Util.setRootForPoolSample(newSampleid, properties.getProperty("sampleid"), getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        properties.setProperty("newkeyid1", newSampleid);
        addToBatch(batchid, newSampleid);
    }

    /**
     *  Add pool sample to batch
     * @param batchid
     * @param sampleid
     * @throws SapphireException
     */
    private void addToBatch(String batchid, String sampleid) throws SapphireException {
        PropertyList sampleprop = new PropertyList();
        sampleprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        sampleprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        sampleprop.setProperty("sampleid", sampleid);
        sampleprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleprop);
        } catch (SapphireException se) {
            throw se;
        }
    }

    /*
    *   Create pool sample from the given input samples
    *
    *   @param pl  property list
    * */
    private String createPoolSample(PropertyList pl) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty("sampleid", pl.getProperty("sampleid"));
        props.setProperty("quantity", "10");
        props.setProperty("poolquantity", "10");

        props.setProperty("copydowncolumns", "sstudyid;u_accessionid;sampletypeid,u_bodysite;u_sampleinformation;u_clientspecimenid;u_extractionid;u_currentmovementstep");

        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        return props.getProperty("newkeyid1", "");
    }
}
