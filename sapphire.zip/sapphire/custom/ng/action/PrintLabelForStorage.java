package sapphire.custom.ng.action;

import sapphire.accessor.ActionException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.GenerateLabel;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.error.ErrorDetail;

/**
 * Created by achakraborty on 11/10/2016.
 */
public class PrintLabelForStorage extends BaseAction {
    public static final String KEYID1_PROP="keyid1";
    public static final String SDCID_PROP="sdcid";
    public static final String LABELMETHOD_PROP="labelmethodid";
    public static final String COPIES="copies";

    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty(KEYID1_PROP, "");
        String sdcid = properties.getProperty(SDCID_PROP, "");
        String labelmethod = properties.getProperty(LABELMETHOD_PROP, "");
        String copies = properties.getProperty(COPIES,"1");
        try {
            if ("LV_Box".equalsIgnoreCase(sdcid) || "Instrument".equalsIgnoreCase(sdcid)
                    || "StorageUnitSDC".equalsIgnoreCase(sdcid)) {
                String printer=getPrinterId();
                if (Util.isNull(printer)) {
                    throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                            " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                            "Also the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
                } else {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
                    prop.setProperty(GenerateLabel.PROPERTY_KEYID1, keyid1);
                    prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, labelmethod);
                    prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
                    prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID,printer );
                    prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                    prop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);

                    getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, prop);

                }
            }
        } catch(SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    private String getPrinterId()throws SapphireException{
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
       // String sql = "select a.printerid userprinter," +
        //        "(select printerid from u_departmentprinters where u_departmentprinters.departmentid = a.departmentid and nvl(isdefault,'N')='Y' and rownum=1) deptprinter " +
         //       "from u_userdefaultprinter a " +
          //      "where " +
           //     "a.sysuserid='"+userId+"' and a.departmentid='"+depratmentId+"'";
       /* String sql = "select " +
                "  (select a.printerid from u_userdefaultprinter a " +
                "  where a.sysuserid='"+userId+"' and a.departmentid='"+depratmentId+"') as userprinter, " +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '"+depratmentId+"' " +
                " and nvl(isdefault,'N')='Y' and rownum=1) as deptprinter " +
                " from dual ";*/
        String sql = "select " +
                " (select a.printerid from u_userdefaultprinter a " +
                " where a.sysuserid='"+userId+"' and a.departmentid= '"+depratmentId+"' and a.extractiontype is null) as userprinter," +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '"+depratmentId+"' " +
                "  and nvl(isdefault,'N')='Y' and extractiontype is null) as deptprinter " +
                "  from dual";
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if(dsInfo!=null && dsInfo.size()>0){
            String userprinter = dsInfo.getValue(0,"userprinter","");
            String deptprinter = dsInfo.getValue(0,"deptprinter","");
            if(!Util.isNull(userprinter) ) {
                printerId = userprinter;
            }
            else if(!Util.isNull(deptprinter)) {
                printerId = deptprinter;
                //assignDeptDefaultPrinterToUser(userId, depratmentId, printerId);
            }
        }
        return printerId;
    }
    /**
     * Description : If user printer not found it will set department printer to user.
     * @param user
     * @param userDepartment
     * @param printerid
     * @throws SapphireException
     */
    private void assignDeptDefaultPrinterToUser(String user,String userDepartment,String printerid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "User");
        props.setProperty("sysuserid", user);
        props.setProperty("departmentid", userDepartment);
        props.setProperty("printerid", printerid);
        props.setProperty("printertype", "Device");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "userdefaultprinter_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in change printer.Error:"+ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

}
