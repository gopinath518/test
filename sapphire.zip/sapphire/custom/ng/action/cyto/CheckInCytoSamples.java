package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 5/15/2017.
 * This action has been created to check-in childsamples to perticular selected storage under trackitem table.
 * Input Props = Childsampleid & Storage ID.
 * Output Props (Calling editTrackitem out of box action)
 * custodialuserid = null
 * custodialdepartmentid = null
 * currentstorageunitid = storageunitid (Coming from Query)
 * Output Props for u_sampleculturemapid(Coming from GET_SAMPLECULTUREMAPID_BY_CHILDSAMPLEID query)
 * (Calling editSDI out of box action)
 * incubator=null
 * hanabi=null
 * thermotron=null
 */
public class CheckInCytoSamples extends BaseAction {

    private static final String CHILDSAMPLE_PROP = "childsampleids";
    private static final String STORAGE_PROP = "storage";

    public void processAction(PropertyList properties) throws SapphireException {

        String childsample = properties.getProperty(CHILDSAMPLE_PROP);
        String storage = properties.getProperty(STORAGE_PROP);
        if(Util.isNull(childsample))
            throw new SapphireException("Sample Id cannot be obtained");
        if(Util.isNull(storage))
            throw new SapphireException("Storage Id is obtained as null");

        String sql = Util.parseMessage(CytoSqls.GET_STORAGEUNITID, StringUtil.replaceAll(storage, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds==null)
            throw new SapphireException("The below query cannot be executed.");
        if(ds.size()==0)
            throw new SapphireException("The storageunitid "+storage+" is not valid");

        if (ds != null && ds.size() > 0){
            String storageunitid = ds.getColumnValues("storageunitid", ";");

            if(!Util.isNull(storageunitid)){
                PropertyList props = new PropertyList();

                if(!Util.isNull(childsample)){
                    sql = Util.parseMessage(CytoSqls.GET_SAMPLECULTUREMAPID_BY_CHILDSAMPLEID, StringUtil.replaceAll(childsample, ";", "','"));
                    DataSet dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);
                    if(dsCultureInfo!=null && dsCultureInfo.size()>0){
                        props.setProperty(EditSDI.PROPERTY_SDCID,"SampleCultureMap");
                        props.setProperty(EditSDI.PROPERTY_KEYID1,dsCultureInfo.getColumnValues("u_sampleculturemapid",";"));
                        props.setProperty("incubator","(null)");
                        props.setProperty("hanabi","(null)");
                        props.setProperty("thermotron","(null)");

                        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,props);
                    }
                }

                props.clear();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
                props.setProperty("custodialuserid", "(null)");
                props.setProperty("custodialdepartmentid", "(null)");
                props.setProperty("currentstorageunitid", storageunitid);

                try{
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

                } catch(ActionException e){
                    throw new SapphireException("Error: Unable to update storage unit ID for selected = "+childsample);
                }
            }
        }
    }
}
