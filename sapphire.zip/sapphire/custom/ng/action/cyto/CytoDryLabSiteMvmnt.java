package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * This Action helps in different site movement in CytoGenetics Dry Lab.
 * Called from Tech 1 , Tech 2 and Case Review.
 */
public class CytoDryLabSiteMvmnt extends BaseAction {

    private static final String FRESHPREP_PROP = "freshprepsampleid";
    private static final String DUMMYSAMPLE_PROP = "keyid1";
    private static final String FROM_TRAMSTOP_PROP = "from";
    private static final String DIFF_SITENAME_PROP = "sitename";

    public void processAction(PropertyList properties) throws SapphireException {

        String fpsample = properties.getProperty(FRESHPREP_PROP);
        String dummysample = properties.getProperty(DUMMYSAMPLE_PROP);
        String frmTrmStp = properties.getProperty(FROM_TRAMSTOP_PROP);
        String siteName = properties.getProperty(DIFF_SITENAME_PROP);

        if (!Util.isNull(fpsample) && !Util.isNull(dummysample)) {
            siteMovement(fpsample, dummysample, frmTrmStp, siteName);
        } else
            throw new SapphireException("Fresh Prep sample Id not found in CytoDryLabSiteMvmnt.");

        String moveTo ="";
        if("Tech1".equalsIgnoreCase(frmTrmStp))
            moveTo = "Tech2 Analysis";
        else if("Tech2".equalsIgnoreCase(frmTrmStp))
            moveTo = "Case Review Analysis";
        else if("CaseReview".equalsIgnoreCase(frmTrmStp))
            moveTo = "Director Sign Out";

        properties.setProperty("msg", "Selected Samples " + Util.getUniqueList(fpsample, ";", true) + " have been moved to "+moveTo);

    }

    private void siteMovement(String fpsample, String dummysample, String frmTrmStp, String siteName) throws SapphireException {

        String queryCurMvStp = "Cyto"+frmTrmStp;

        String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TAKE_CUSTODY,
                queryCurMvStp,StringUtil.replaceAll(dummysample, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if(ds == null)
            throw new SapphireException("Unable to connect to Database.");
        else if(ds.size() == 0)
            throw new SapphireException("No slide(s) are available in "+frmTrmStp+" for case "+fpsample);
        else if (ds.size() > 0) {

            String childsample = ds.getColumnValues("childsampleid", ";");
            if (!Util.isNull(childsample)) {

                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
                props.setProperty("u_currentmovementstep", getNextCurMvmntStep(frmTrmStp));
                props.setProperty("u_cytostatus", getNextCytoStatus(frmTrmStp));

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (Exception e) {
                    throw new SapphireException("Error: Unable to update the Movement Step for selected samples");
                }

                updateTrackitemForSamples(childsample, frmTrmStp, siteName);
                String fpid = Util.getUniqueList(fpsample, ";", true);
                updateReviewCmpltInfo(fpid, frmTrmStp);
            }
        }
    }

    /**
     * Updating 'u_currenttramstop' and custodial department in trackitem table.
     * @param childsample
     * @param siteName
     * @throws SapphireException
     */
    private void updateTrackitemForSamples(String childsample, String frmTrmStp, String siteName) throws SapphireException{

        if(!Util.isNull(childsample)){

            PropertyList props = new PropertyList();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
            props.setProperty("custodialdepartmentid", siteName);
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("u_currenttramstop", getNextCurMvmntStep(frmTrmStp));

            try{
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Unable to update Department for the selected Slide(s)."+childsample);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }

    /**
     * @desc Updating Review info for Tech 1 / Tech 2 / Case review
     * @param fpid -Freshprep id
     * @throws SapphireException
     */
    private void updateReviewCmpltInfo(String fpid, String frmTrmStp) throws SapphireException{

        String rvwDtColName = "";
        String rvwdByColName = "";

        if("Tech1".equalsIgnoreCase(frmTrmStp)){
            rvwDtColName = "tech1rvwdt";
            rvwdByColName = "tech1rvwedby";
        }
        else if("Tech2".equalsIgnoreCase(frmTrmStp)){
            rvwDtColName = "tech2rvwdt";
            rvwdByColName = "tech2rvwedby";
        }
        else if("CaseReview".equalsIgnoreCase(frmTrmStp)){
            rvwDtColName = "csrvwreviewdt";
            rvwdByColName = "csrvwreviewedby";
        }

        if(!Util.isNull(fpid)){
            try {
                PropertyList props = new PropertyList();
                props.setProperty(AddSDI.PROPERTY_SDCID, "CytoCaseReviewDtl");
                props.setProperty(AddSDI.PROPERTY_COPIES, ""+fpid.split(";").length);
                props.setProperty(rvwDtColName, "n");
                props.setProperty(rvwdByColName, connectionInfo.getSysuserId());
                props.setProperty("sampleid", fpid);

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);

            }catch(SapphireException ex){
                throw new SapphireException("Unable to Add. Reason: "+ex.getMessage());
            }
        }
    }

    /**
     *  Returns next current movement step
     * @param frmTrmStp
     * @return
     */
    private String getNextCurMvmntStep(String frmTrmStp){

        String nextCurMvmntStep = "";

        if("Tech1".equalsIgnoreCase(frmTrmStp))
            nextCurMvmntStep = "CytoTech2";
        else if("Tech2".equalsIgnoreCase(frmTrmStp))
            nextCurMvmntStep = "CytoCaseReview";
        else if("CaseReview".equalsIgnoreCase(frmTrmStp))
            nextCurMvmntStep = "CytoDirectorSignOut";


        return nextCurMvmntStep;

    }

    /**
     * Returns next cyto status
     * @param frmTrmStp
     * @return
     */
    private String getNextCytoStatus(String frmTrmStp){

        String nextCytoStatus = "";

        if("Tech1".equalsIgnoreCase(frmTrmStp))
            nextCytoStatus = "Ready for 2nd Analysis";
        else if("Tech2".equalsIgnoreCase(frmTrmStp))
            nextCytoStatus = "Ready For Case Review";
        else if("CaseReview".equalsIgnoreCase(frmTrmStp))
            nextCytoStatus = "Pre-review Complete";


        return nextCytoStatus;

    }

}
