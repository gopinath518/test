package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by aritra.banerjee on 5/7/2017.
 * The below Action Cancels the cancelled Cultures and Slides with Accession Sample
 * The Below Action is called  either from Cyto-Setup or Cyto-Feed or Cyto- Harvest Page Cancel Test Button
 */
public class CytoCancelTest extends BaseAction {

    String cancelledSTMapIds="";

    public void processAction(PropertyList properties) throws SapphireException {

        String orgsample = properties.getProperty("orgsample", "");
        String dummysampleid = properties.getProperty("dummysampleid", "");
        String option = properties.getProperty("option", "");
        String childsampleid = properties.getProperty("childsampleid", "");
        String storage = properties.getProperty("storage", "");
        String nextpage = properties.getProperty("nextpage", "");
        String keyid1 = properties.getProperty("pagekey", "");
        String sdcid = properties.getProperty("pagesdcid", "");
        String auditreason = properties.getProperty("auditreason");
        String frmTrmStp = properties.getProperty("frmtrmstp");
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String currentmovementstep = "";
        if ("Tech1".equalsIgnoreCase(frmTrmStp))
            currentmovementstep = "CytoTech1";
        else if ("Tech2".equalsIgnoreCase(frmTrmStp))
            currentmovementstep = "CytoTech2";
        else if ("CaseReview".equalsIgnoreCase(frmTrmStp))
            currentmovementstep = "CytoCaseReview";
        else if ("DirectorSignOut".equalsIgnoreCase(frmTrmStp))
            currentmovementstep = "CytoDirectorSignOut";

        String childsamples = "";
        if ((!Util.isNull(orgsample))) {

            String sql = Util.parseMessage(CytoSqls.GET_REPORT_DETAILS_BY_ORGSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
            DataSet dsReportedInfo = getQueryProcessor().getSqlDataSet(sql);

            if(dsReportedInfo == null)
                throw new SapphireException("Unable to connect to DataBase. Please Contact Admin.");
            else if(dsReportedInfo.size() > 0)
                throw new SapphireException("Unable to perform Cancel operation. \nReason : " +
                        "Report has already been generated for the below specimen(s)-\n"+dsReportedInfo.getColumnValues("s_sampleid",", "));

            sql = Util.parseMessage(CytoSqls.TIINFO_BY_ORGSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
            DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsInfo != null && dsInfo.size() > 0) {
                //loop
                for (int i = 0; i < dsInfo.size(); i++) {
                    String custodialdepartmentid = dsInfo.getValue(i, "custodialdepartmentid", "");
                    String linkkeyid = dsInfo.getValue(i, "linkkeyid1", "");
                    if (department.equalsIgnoreCase(custodialdepartmentid)) {
                        childsamples = childsamples + ";" + linkkeyid;
                    }
                }
            }
        }

        if (!Util.isNull(currentmovementstep)) {
            String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TAKE_CUSTODY, currentmovementstep, StringUtil.replaceAll(dummysampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            if (ds != null && ds.size() > 0) {

                childsamples += ";"+ds.getColumnValues("childsampleid", ";");
            }
        }

        if (!Util.isNull(childsamples) && childsamples.startsWith(";"))
            childsamples = childsamples.substring(1);

        if (!Util.isNull(childsamples) && Util.isNull(storage)) {
            try {
                PropertyList autoCustodyProp = new PropertyList();
                autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsamples, ";", true));

                getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
            } catch (SapphireException ex) {
                throw new SapphireException("Unable to take custody. Reason: " + ex.getMessage());
            }
        }
        if ((!Util.isNull(orgsample)) && (!Util.isNull(option))) {
            String sql = "";
            DataSet dsCultureInfo = null;
            DataSet dsSlidesInfo = null;

            if ((Util.isNull(dummysampleid))) {
                sql = Util.parseMessage(CytoSqls.GET_CULTURES_BY_FRESHPREPSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
                dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);

                sql = Util.parseMessage(CytoSqls.GET_SLIDES_BY_FRESHPREPSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
                dsSlidesInfo = getQueryProcessor().getSqlDataSet(sql);
            } else {
                sql = Util.parseMessage(CytoSqls.GET_CULTURES_BY_DUMMYSAMPLEID, StringUtil.replaceAll(dummysampleid, ";", "','"));
                dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);

                sql = Util.parseMessage(CytoSqls.GET_SLIDES_BY_PARENTSAMPLEID, StringUtil.replaceAll(dummysampleid, ";", "','"));
                dsSlidesInfo = getQueryProcessor().getSqlDataSet(sql);
            }

            if ("ReturnToClient".equalsIgnoreCase(option)) {

                try {
                    PropertyList props = new PropertyList();
                    props.setProperty("s_sampleid", orgsample);
                    getActionProcessor().processAction("MoveSampleToFreshPrep", "1", props);

                    cancelCulturesandSlides(dsCultureInfo, dsSlidesInfo, childsampleid, option, auditreason);

                    if (dsCultureInfo != null && dsCultureInfo.size() > 0)
                        childsampleid = dsCultureInfo.getColumnValues("childsampleid", ";");

                    statusUpdateForAccessionSamples(orgsample, "cancelled", childsampleid, option, auditreason);

                } catch (ActionException e) {
                    throw new SapphireException("Unable to cancel specimen.\nReason: " + e.getMessage());
                }

            } else if ("HarvestandSendtoFreshPrep".equalsIgnoreCase(option)) {

                PropertyList props = new PropertyList();
                props.setProperty("s_sampleid", orgsample);
                getActionProcessor().processAction("MoveSampleToFreshPrep", "1", props);

                if (!Util.isNull(keyid1) && !Util.isNull(childsampleid)) {
                    props.clear();
                    props.setProperty("type", "D");
                    props.setProperty("childsampleid", childsampleid);
                    props.setProperty("cytostatus", "Ready for Slide Drop");
                    props.setProperty("tramstop", "SlideDrop");
                    props.setProperty("keyid1", keyid1);

                    getActionProcessor().processAction("HarvestNow", "1", props);
                }

            } else if ("DropandSendtoFreshPrep".equalsIgnoreCase(option)) {

                PropertyList props = new PropertyList();
                props.setProperty("s_sampleid", orgsample);
                getActionProcessor().processAction("MoveSampleToFreshPrep", "1", props);

                //Need to implement the logic of drop for the cancelled cultures...

            } else if ("Discard".equalsIgnoreCase(option)) {
                discardCulturesandSlides(dsCultureInfo, dsSlidesInfo, childsampleid, option, auditreason);

                if (dsCultureInfo != null && dsCultureInfo.size() > 0)
                    childsampleid = dsCultureInfo.getColumnValues("childsampleid", ";");

                statusUpdateForAccessionSamples(orgsample, "unused", childsampleid, option, auditreason);
                cancelDummySample(orgsample);
                updateOrgTestCodeCombinSTM(orgsample,option,auditreason);
                cancelSDIWorkItemInfo();

            } else if ("ContinueThroughHarvest".equalsIgnoreCase(option) || "Cancel".equalsIgnoreCase(option)) {
                cancelCulturesandSlides(dsCultureInfo, dsSlidesInfo, childsampleid, option, auditreason);

                if (dsCultureInfo != null && dsCultureInfo.size() > 0)
                    childsampleid = dsCultureInfo.getColumnValues("childsampleid", ";");

                statusUpdateForAccessionSamples(orgsample, "cancelled", childsampleid, option, auditreason);

            } else if ("HarvestandStore".equalsIgnoreCase(option)) {
                harvestingCanceledCulturesByHarvestNowButton(orgsample, storage, option, childsampleid);

                if (!Util.isNull(keyid1) && !Util.isNull(childsampleid)) {
                    PropertyList props = new PropertyList();
                    props.setProperty("type", "D");
                    props.setProperty("childsampleid", childsampleid);
                    props.setProperty("cytostatus", "Ready for Slide Drop");
                    props.setProperty("tramstop", "SlideDrop");
                    props.setProperty("keyid1", keyid1);
                    props.setProperty("storeflag", "Y");

                    getActionProcessor().processAction("HarvestNow", "1", props);
                }
            } else if ("DropandStore".equalsIgnoreCase(option)) {
                harvestingCanceledCulturesByHarvestNowButton(orgsample, storage, option, childsampleid);

                //Need to implement the drop logic for the cancelled cultures...

            }
            deleteAnalysisFile(orgsample);
            deleteIkarosImages(orgsample);
            deleteActualAttachment(orgsample);

        }
        if (!Util.isNull(nextpage)) {
            String outScript = "<script>top.sapphire.page.navigate('rc?command=page&page=" + nextpage + "&sdcid=" + sdcid + "&keyid1=" + keyid1 + "')</script>";
            properties.setProperty("outscript", outScript);
        }
    }

    private void updateOrgTestCodeCombinSTM(String orgsample, String option, String auditreason) throws SapphireException {

        String sql = Util.parseMessage(CytoSqls.GET_ORGTESTCOMB_DETAIL_BY_ORG, StringUtil.replaceAll(orgsample, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if(ds == null)
            throw new SapphireException("Unable to connect to DataBase.");

        if(ds.size() > 0){
            String sampletestcodemapid = ds.getColumnValues("u_sampletestcodemapid",";");
            if (!Util.isNull(sampletestcodemapid)) {

                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
                pl.setProperty("unused", "Y");
                pl.setProperty("cancelopp", option);
                pl.setProperty("teststatus", "Cancelled");
                pl.setProperty("prestatus", "In Progress");
                if (!Util.isNull(auditreason)) {
                    pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                cancelledSTMapIds+=";"+sampletestcodemapid;
            }
        }

    }

    /**
     * @param dsCultureInfo
     * @param dsSlidesInfo
     * @param childsamples
     * @throws SapphireException
     * @desc Update Unused column as 'Y' for Sample Culture Map and Sample Test Code Map.
     */
    private void discardCulturesandSlides(DataSet dsCultureInfo, DataSet dsSlidesInfo, String childsamples, String option, String auditreason) throws SapphireException {

        if (dsCultureInfo != null && dsCultureInfo.size() > 0) {
            childsamples = dsCultureInfo.getColumnValues("childsampleid", ";");

            String sampleculturemapid = dsCultureInfo.getColumnValues("u_sampleculturemapid", ";");
            PropertyList pl = new PropertyList();

            if (!Util.isNull(sampleculturemapid)) {

                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleculturemapid);
                pl.setProperty("unused", "Y");
                pl.setProperty("cancelopp", option);
                if (!Util.isNull(auditreason)) {
                    pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }

        if (dsSlidesInfo != null && dsSlidesInfo.size() > 0) {
            childsamples = childsamples + ";" + dsSlidesInfo.getColumnValues("childsampleid", ";");

            String cytoslidesid = dsSlidesInfo.getColumnValues("u_cytoslidesid", ";");
            PropertyList pl = new PropertyList();

            if (!Util.isNull(cytoslidesid)) {

                pl.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, cytoslidesid);
                pl.setProperty("unused", "Y");
                pl.setProperty("cancelopp", option);
                if (!Util.isNull(auditreason)) {
                    pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            }
        }


        if (!Util.isNull(childsamples)) {

            if (childsamples.startsWith(";"))
                childsamples = childsamples.substring(1);

            if (childsamples.endsWith(";"))
                childsamples = childsamples.substring(0, (childsamples.length() - 1));

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, childsamples);
            pl.setProperty("u_cytostatus", "Unused");
            if (!Util.isNull(auditreason)) {
                pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
            }
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            String sql = Util.parseMessage(CytoSqls.GET_STMID_BY_CHILDSAMPLEID, StringUtil.replaceAll(childsamples, ";", "','"));
            DataSet dsTestCodeMapInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsTestCodeMapInfo != null && dsTestCodeMapInfo.size() > 0) {
                String sampletestcodemapid = dsTestCodeMapInfo.getColumnValues("u_sampletestcodemapid", ";");
                pl.clear();

                if (!Util.isNull(sampletestcodemapid)) {

                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
                    pl.setProperty("unused", "Y");
                    pl.setProperty("cancelopp", option);
                    pl.setProperty("teststatus", "Cancelled");
                    pl.setProperty("prestatus", "In Progress");
                    if (!Util.isNull(auditreason)) {
                        pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                    }
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    cancelledSTMapIds+=";"+sampletestcodemapid;
                }
            }
        }
    }

    /**
     * @param dsCultureInfo
     * @param dsSlidesInfo
     * @param childsamples
     * @throws SapphireException
     * @desc Update cancel column as 'Y' for Sample Culture Map and Sample Test Code Map.
     */
    private void cancelCulturesandSlides(DataSet dsCultureInfo, DataSet dsSlidesInfo, String childsamples, String option, String auditreason) throws SapphireException {

        if (dsCultureInfo != null && dsCultureInfo.size() > 0) {
            String sampleculturemapid = dsCultureInfo.getColumnValues("u_sampleculturemapid", ";");
            childsamples = dsCultureInfo.getColumnValues("childsampleid", ";");
            PropertyList pl = new PropertyList();

            if (!Util.isNull(sampleculturemapid)) {

                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleculturemapid);
                pl.setProperty("cancelled", "Y");
                pl.setProperty("cancelopp", option);
                if (!Util.isNull(auditreason)) {
                    pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }

        if (dsSlidesInfo != null && dsSlidesInfo.size() > 0) {
            String cytoslidesid = dsSlidesInfo.getColumnValues("u_cytoslidesid", ";");
            childsamples = childsamples + ";" + dsSlidesInfo.getColumnValues("childsampleid", ";");
            PropertyList pl = new PropertyList();

            if (!Util.isNull(cytoslidesid)) {

                pl.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, cytoslidesid);
                pl.setProperty("cancelled", "Y");
                pl.setProperty("cancelopp", option);
                if (!Util.isNull(auditreason)) {
                    pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            }
        }


        if (!Util.isNull(childsamples)) {

            if (childsamples.startsWith(";"))
                childsamples = childsamples.substring(1);

            if (childsamples.endsWith(";"))
                childsamples = childsamples.substring(0, (childsamples.length() - 1));

            String sql = Util.parseMessage(CytoSqls.GET_STMID_BY_CHILDSAMPLEID, StringUtil.replaceAll(childsamples, ";", "','"));
            DataSet dsTestCodeMapInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsTestCodeMapInfo != null && dsTestCodeMapInfo.size() > 0) {
                String sampletestcodemapid = dsTestCodeMapInfo.getColumnValues("u_sampletestcodemapid", ";");
                PropertyList pl = new PropertyList();

                if (!Util.isNull(sampletestcodemapid)) {

                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
                    pl.setProperty("cancelled", "Y");
                    pl.setProperty("cancelopp", option);
                    pl.setProperty("teststatus", "Cancelled");
                    pl.setProperty("prestatus", "In Progress");
                    if (!Util.isNull(auditreason)) {
                        pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                    }
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    cancelledSTMapIds+=";"+sampletestcodemapid;
                }
            }
        }

    }

    /**
     * @param freshprepsampleid
     * @param storage
     * @param option
     * @param childsampleid
     * @throws SapphireException
     * @desc Selected childsample will be stored in the selected storage.
     */
    private void harvestingCanceledCulturesByHarvestNowButton(String freshprepsampleid, String storage, String option, String childsampleid) throws SapphireException {

        if (Util.isNull(childsampleid)) {
            throw new SapphireException("Childsampleid(s) are not found for the selected culture(s)");
        }
        if (Util.isNull(freshprepsampleid))
            throw new SapphireException("Patient sampleid(s) are not found for the selected culture(s)");
        if (Util.isNull(option))
            throw new SapphireException("Option canot be null");
        if ("HarvestandStore".equalsIgnoreCase(option) || "DropandStore".equalsIgnoreCase(option)) {

            String sql = Util.parseMessage(CytoSqls.GET_TRACKITEMID_SQL, StringUtil.replaceAll(childsampleid, ";", "','"));
            DataSet dsSCMInfo = getQueryProcessor().getSqlDataSet(sql);
            String trackitemid = "";
            if (dsSCMInfo != null && dsSCMInfo.size() > 0)
                trackitemid = dsSCMInfo.getColumnValues("trackitemid", ";");

            if (!Util.isNull(trackitemid)) {
                String sqlStorage = Util.parseMessage(CytoSqls.GET_STORAGEUNITID, StringUtil.replaceAll(storage, ";", "','"));
                DataSet dsStorageInfo = getQueryProcessor().getSqlDataSet(sqlStorage);
                String storageunitid = "";
                if (dsStorageInfo != null && dsStorageInfo.size() > 0)
                    storageunitid = dsStorageInfo.getColumnValues("storageunitid", ";");
                if (!Util.isNull(storageunitid)) {

                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    pl.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, trackitemid);
                    pl.setProperty("currentstorageunitid", storageunitid);
                    pl.setProperty("custodialuserid", "(null)");
                    pl.setProperty("custodialdepartmentid", "(null)");
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                }
            }
        }
       /* else if("HarvestandSendtoFreshPrep".equalsIgnoreCase(option)){

        }*/
    }

    /**
     * @param orgsample
     * @param columnToUpdate
     * @param childsampleid
     * @throws SapphireException
     * @desc Update unused or cancel column as 'Y' for Sample Test Code Map.
     */
    private void statusUpdateForAccessionSamples(String orgsample, String columnToUpdate, String childsampleid, String option, String auditreason) throws SapphireException {

        if (Util.isNull(childsampleid)) {
            String sql = Util.parseMessage(CytoSqls.GET_STMID_BY_CHILDSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
            DataSet dsStmInfo = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(CytoSqls.GET_SOURCESAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
            DataSet dsSourceSampleidInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsStmInfo == null)
                throw new SapphireException("Sample info cannot be obtained from database.");

            String orgsampleArr[] = StringUtil.split(orgsample, ";");
            String orgPrnSmplTestcodeInfo = "";
            if (orgsampleArr != null && orgsampleArr.length > 0) {
                HashMap<String, String> hmap = new HashMap<>();
                for (int i = 0; i < orgsampleArr.length; i++) {
                    hmap.clear();
                    hmap.put("destsampleid", orgsampleArr[i]);
                    DataSet dsSourceSampleInfoFilter = dsSourceSampleidInfo.getFilteredDataSet(hmap);
                    String parentsample = "";

                    if (dsSourceSampleInfoFilter != null && dsSourceSampleInfoFilter.size() > 0) {
                        if (dsSourceSampleInfoFilter.size() == 1) {
                            parentsample = dsSourceSampleInfoFilter.getValue(0, "sourcesampleid");

                            hmap.clear();
                            hmap.put("s_sampleid", orgsampleArr[i]);
                            DataSet dsStmInfoFilter = dsStmInfo.getFilteredDataSet(hmap);
                            if (dsStmInfoFilter != null && dsStmInfoFilter.size() > 0) {
                                for (int k = 0; k < dsStmInfoFilter.size(); k++)
                                    orgPrnSmplTestcodeInfo += ";" + dsStmInfoFilter.getValue(k, "lvtestcodeid", "") + "#" + parentsample;
                            }
                        }
                    }
                }
            }

            String sampleTcodeMapid = dsStmInfo.getColumnValues("u_sampletestcodemapid", ";");

            if (!Util.isNull(orgPrnSmplTestcodeInfo)) {
                if (orgPrnSmplTestcodeInfo.startsWith(";")) {
                    orgPrnSmplTestcodeInfo = orgPrnSmplTestcodeInfo.substring(1);
                    sql = Util.parseMessage(CytoSqls.GET_SAMPLETESTCODEMAPID_BY_LVTESTCODEAMPLEIDCOMB, StringUtil.replaceAll(orgPrnSmplTestcodeInfo, ";", "','"));
                    DataSet dsorgParentTestCodeMapInfo = getQueryProcessor().getSqlDataSet(sql);
                    if (dsorgParentTestCodeMapInfo != null && dsorgParentTestCodeMapInfo.size() > 0)
                        sampleTcodeMapid += ";" + dsorgParentTestCodeMapInfo.getColumnValues("u_sampletestcodemapid", ";");
                }
            }

            if (!Util.isNull(sampleTcodeMapid)) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleTcodeMapid);
                pl.setProperty(columnToUpdate, "Y");
                pl.setProperty("cancelopp", option);
                pl.setProperty("teststatus", "Cancelled");
                pl.setProperty("prestatus", "In Progress");
                if (!Util.isNull(auditreason)) {
                    pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                cancelledSTMapIds+=";"+sampleTcodeMapid;
            }
            return;
        }

        String sql = Util.parseMessage(CytoSqls.GET_SOURCESAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
        DataSet dsSourceSampleidInfo = getQueryProcessor().getSqlDataSet(sql);

        sql = Util.parseMessage(CytoSqls.GET_CHILDTESTCODE_AND_PARENTSAMPLE, StringUtil.replaceAll(childsampleid, ";", "','"));
        DataSet dsChildTestcodeInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsSourceSampleidInfo == null || dsChildTestcodeInfo == null)
            throw new SapphireException("Sample info cannot be obtained from database.");
        /*if (dsChildTestcodeInfo.size() == 0)
            throw new SapphireException("Culture info not available in database.");*/

        DataSet dsFinal = new DataSet();
        DataSet dsFinalResult = new DataSet();

        dsFinalResult.addColumn("testcodeid#sampleid", DataSet.STRING);
        dsFinalResult.addColumn("orgsampleid", DataSet.STRING);
        dsFinalResult.addColumn("lvtestcodeid", DataSet.STRING);

        dsFinal.copyRow(dsChildTestcodeInfo, -1, 1);

//        if(dsSourceSampleidInfo.size() > 0) {
        String[] orgsampleArr = StringUtil.split(orgsample, ";");
        for (int j = 0; j < orgsampleArr.length; j++) {
            HashMap hm = new HashMap();
            hm.put("destsampleid", orgsampleArr[j]);
            DataSet dsSourceSampleInfoFilter = dsSourceSampleidInfo.getFilteredDataSet(hm);
            String parentsample = "";

            if (dsSourceSampleInfoFilter != null && dsSourceSampleInfoFilter.size() > 0) {
                if (dsSourceSampleInfoFilter.size() == 1)
                    parentsample = dsSourceSampleInfoFilter.getValue(0, "sourcesampleid");
            }

            hm.clear();
            hm.put("orgsampleid", orgsampleArr[j]);
            DataSet dsChildTestcodeInfoFilter = dsChildTestcodeInfo.getFilteredDataSet(hm);

            if (dsChildTestcodeInfoFilter.size() > 0) {
                for (int i = 0; i < dsChildTestcodeInfoFilter.size(); i++) {
                    if (!Util.isNull(parentsample)) {
                        int rowId = dsFinalResult.addRow();
                        dsFinalResult.setValue(rowId, "orgsampleid", parentsample);
                        dsFinalResult.setValue(rowId, "lvtestcodeid", dsChildTestcodeInfoFilter.getValue(i, "lvtestcodeid"));
                    }
                    if (!Util.isNull(orgsampleArr[j])) {
                        int rowId = dsFinalResult.addRow();
                        dsFinalResult.setValue(rowId, "orgsampleid", orgsampleArr[j]);
                        dsFinalResult.setValue(rowId, "lvtestcodeid", dsChildTestcodeInfoFilter.getValue(i, "lvtestcodeid"));
                    }
                }
            }
        }
//        }

        for (int i = 0; i < dsFinalResult.size(); i++) {
            String combination = dsFinalResult.getValue(i, "lvtestcodeid") + "#" + dsFinalResult.getValue(i, "orgsampleid");
            dsFinalResult.setValue(i, "testcodeid#sampleid", combination);
        }

        String lvtestcodeSampleCombination = dsFinalResult.getColumnValues("testcodeid#sampleid", ";");

        if (!Util.isNull(lvtestcodeSampleCombination)) {

            sql = Util.parseMessage(CytoSqls.GET_SAMPLETESTCODEMAPID_BY_LVTESTCODEAMPLEIDCOMB, StringUtil.replaceAll(lvtestcodeSampleCombination, ";", "','"));
            DataSet dsTestCodeMapInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsTestCodeMapInfo != null && dsTestCodeMapInfo.size() > 0) {
                String sampletestcodemapid = dsTestCodeMapInfo.getColumnValues("u_sampletestcodemapid", ";");
                PropertyList pl = new PropertyList();

                if (!Util.isNull(sampletestcodemapid)) {

                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
                    pl.setProperty(columnToUpdate, "Y");
                    pl.setProperty("cancelopp", option);
                    pl.setProperty("teststatus", "Cancelled");
                    pl.setProperty("prestatus", "In Progress");
                    if (!Util.isNull(auditreason)) {
                        pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
                    }
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    cancelledSTMapIds+=";"+sampletestcodemapid;
                }
            }
        }

    }

    private void cancelDummySample(String orgsampleid) throws SapphireException{
        if(!Util.isNull(orgsampleid)){
            String sql=Util.parseMessage(CytoSqls.CYTO_DUMMYSAMPLE_TEST_INFO_BY_ORGSAMPLEID,StringUtil.replaceAll(orgsampleid,";","','"));
            DataSet dsDummySampleTest=getQueryProcessor().getSqlDataSet(sql);
            if(dsDummySampleTest!=null && dsDummySampleTest.size()>0){
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, dsDummySampleTest.getColumnValues("u_sampletestcodemapid",";"));
                pl.setProperty("unused", "Y");
                pl.setProperty("teststatus", "Cancelled");
                pl.setProperty("prestatus", "In Progress");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                cancelledSTMapIds+=";"+dsDummySampleTest.getColumnValues("u_sampletestcodemapid",";");
            }
        }
    }

    private void cancelSDIWorkItemInfo() throws SapphireException{
        if(!Util.isNull(cancelledSTMapIds)){
            if(cancelledSTMapIds.startsWith(";"))
                cancelledSTMapIds=cancelledSTMapIds.substring(1);
            String sql=Util.parseMessage(CytoSqls.ACTIVE_SDIWORKITEMINFO_BY_SAMPLETESTCODEMAPID,StringUtil.replaceAll(cancelledSTMapIds,";","','"));
            DataSet dsSDIWIInfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsSDIWIInfo!=null && dsSDIWIInfo.size()>0){
                PropertyList prop=new PropertyList();
                prop.setProperty(CancelSDIWorkItem.PROPERTY_SDCID,"Sample");
                prop.setProperty(CancelSDIWorkItem.PROPERTY_KEYID1,dsSDIWIInfo.getColumnValues("keyid1",";"));
                prop.setProperty(CancelSDIWorkItem.PROPERTY_WORKITEMID,dsSDIWIInfo.getColumnValues("workitemid",";"));
                prop.setProperty(CancelSDIWorkItem.PROPERTY_WORKITEMINSTANCE,dsSDIWIInfo.getColumnValues("workiteminstance",";"));
                prop.setProperty(CancelSDIWorkItem.PROPERTY_SYNCSDISTATUS,StringUtil.repeat("Y",dsSDIWIInfo.size(),";"));
                prop.setProperty(CancelSDIWorkItem.PROPERTY_SYNCSDIWORKITEMGROUPSTATUS,StringUtil.repeat("Y",dsSDIWIInfo.size(),";"));
                prop.setProperty(CancelSDIWorkItem.PROPERTY_PROPSMATCH,"Y");
                getActionProcessor().processAction(CancelSDIWorkItem.ID,CancelSDIWorkItem.VERSIONID,prop);
            }
        }
    }

    private void deleteIkarosImages(String orgsample) throws SapphireException{
        if(!Util.isNull(orgsample)){
            if(orgsample.startsWith(";")){
                orgsample=orgsample.substring(1);
            }
            String sql=Util.parseMessage(CytoSqls.CYTO_IKAROS_IMAGE_DETAIL,StringUtil.replaceAll(orgsample,";","','"));
            DataSet dsImgInfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsImgInfo!=null && dsImgInfo.size()>0){
                PropertyList prop=new PropertyList();
                prop.setProperty(DeleteSDI.PROPERTY_SDCID,"CytoIkarosImages");
                prop.setProperty(DeleteSDI.PROPERTY_KEYID1,dsImgInfo.getColumnValues("imgid",";"));
                getActionProcessor().processAction(DeleteSDI.ID,DeleteSDI.VERSIONID,prop);
            }
        }
    }

    private void deleteAnalysisFile(String orgsample) throws SapphireException{
        if(!Util.isNull(orgsample)){
            if(orgsample.startsWith(";")){
                orgsample=orgsample.substring(1);
            }
            String sql=Util.parseMessage(CytoSqls.IKAROS_ANALYSIS_AUDIT_BY_FPSAMPLEID,StringUtil.replaceAll(orgsample,";","','"));
            DataSet dsAnalysisAuditfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsAnalysisAuditfo!=null && dsAnalysisAuditfo.size()>0){
                PropertyList prop=new PropertyList();
                prop.setProperty(DeleteSDI.PROPERTY_SDCID,"CytoIkrsAnalysisAudt");
                prop.setProperty(DeleteSDI.PROPERTY_KEYID1,dsAnalysisAuditfo.getColumnValues("auditid",";"));
                getActionProcessor().processAction(DeleteSDI.ID,DeleteSDI.VERSIONID,prop);
            }
        }
    }

    private void deleteActualAttachment(String orgsample) throws SapphireException{
        if(!Util.isNull(orgsample)){
            if(orgsample.startsWith(";")){
                orgsample=orgsample.substring(1);
            }
            String sql=Util.parseMessage(CytoSqls.IKAROS_IMAGE_ANALYSIS_ATTACHMENT_INFO_BY_SAMPLE,StringUtil.replaceAll(orgsample,";","','"));
            DataSet dsAttachmentfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsAttachmentfo!=null && dsAttachmentfo.size()>0){
                PropertyList prop=new PropertyList();
                prop.setProperty(DeleteSDIAttachment.PROPERTY_SDCID,"Sample");
                prop.setProperty(DeleteSDIAttachment.PROPERTY_KEYID1,dsAttachmentfo.getColumnValues("keyid1",";"));
                prop.setProperty(DeleteSDIAttachment.PROPERTY_ATTACHMENTNUM,dsAttachmentfo.getColumnValues("attachmentnum",";"));
                getActionProcessor().processAction(DeleteSDIAttachment.ID,DeleteSDIAttachment.VERSIONID,prop);
            }
        }
    }

}
