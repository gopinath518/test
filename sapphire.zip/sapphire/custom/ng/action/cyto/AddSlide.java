package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by subhendu on 3/02/2017
 * This action will be called when creating new slides. It will be called from sampleculturemap rule file
 */
public class AddSlide extends BaseAction {

    private String SLIDEID_FOR_LABEL = "";

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleCultureMapId = properties.getProperty("sampleculturemapid");
        String temperature = properties.getProperty("temperature", "");
        String duration = properties.getProperty("duration", "");
        String storageLocation = properties.getProperty("storagelocation", "");
        String oven = properties.getProperty("oven", "");
        String mitoticindex = properties.getProperty("mitoticindex", "");
        String slidequality = properties.getProperty("slidequality", "");

        DataSet ds = getCultureDetail(sampleCultureMapId, temperature, duration, storageLocation, oven, mitoticindex, slidequality);
        if ("".equals(temperature) || "".equals(duration) || "".equals(storageLocation) || "".equals(oven))
            throw new SapphireException("Please enter value in Temperature/Duration/Oven/Storage Location fields");

    	/*ds.addColumnValues("temperature", DataSet.STRING, StringUtil.repeat(temperature, ds.size(),";"), ";", "");
    	ds.addColumnValues("duration", DataSet.STRING, StringUtil.repeat(duration, ds.size(),";"), ";", "");
    	ds.addColumnValues("storagelocation", DataSet.STRING, StringUtil.repeat(storageLocation, ds.size(),";"), ";", "");
        ds.addColumnValues("oven", DataSet.STRING, StringUtil.repeat(oven, ds.size(),";"), ";", "");*/

        if (ds.size() > 0) {
            createSlideNames(ds);
            ds.addColumnValues("batchid", DataSet.STRING, StringUtil.repeat(createBatchId(), ds.size(), ";"), ";", "");
            updateCustody(ds.getColumnValues("childsampleid", ";"));    // update trackitem table for childsampleid(cultures) which was selected first.
            createChildSlide(ds);
            updateSampleCultureMap(sampleCultureMapId); // update thermotron and batchid to null for selected cultures in SampleCultureMap
            //autoCustodyTransfer(sampleCultureMapId);
            if (!Util.isNull(SLIDEID_FOR_LABEL)) {
                PropertyList props = new PropertyList();
                props.setProperty(PrintLabel.SDCID_PROP, "CytoSlides");
                props.setProperty(PrintLabel.KEYID1_PROP, SLIDEID_FOR_LABEL);
                props.setProperty("labelmethodid", "CytoSlideLbl");
                try {
                    getActionProcessor().processAction("PrintLabel", "1", props);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. Unbale to Print Label for Slides While dropping cultures. ");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }
            }
        } else
            throw new SapphireException("No Culture Record Found!!");

    }

    private DataSet getCultureDetail(String sampleCultureMapId, String temperature, String duration, String storageLocation, String oven, String mitoticindex, String slidequality) throws SapphireException {
        String sql = Util.parseMessage(CytoSqls.GET_CULTURE_DETAIL, StringUtil.replaceAll(sampleCultureMapId, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null)
            throw new SapphireException("No valid database connection found. Contact administrator.");
        else if (ds.size() == 0)
            return ds;

        String[] cultureMapidArr = StringUtil.split(sampleCultureMapId, ";");
        String[] temperatureArr = StringUtil.split(temperature, ";");
        String[] durationArr = StringUtil.split(duration, ";");
        String[] storageLocationArr = StringUtil.split(storageLocation, ";");
        String[] ovenArr = StringUtil.split(oven, ";");
        String[] mitoticindexArr = StringUtil.split(mitoticindex, ";");
        String[] slidequalityArr = StringUtil.split(slidequality, ";");

        ds.addColumn("temperature", DataSet.STRING);
        ds.addColumn("duration", DataSet.STRING);
        ds.addColumn("storagelocation", DataSet.STRING);
        ds.addColumn("oven", DataSet.STRING);
        ds.addColumn("mitoticindex", DataSet.STRING);
        ds.addColumn("slidequality", DataSet.STRING);

        for (int i = 0; i < cultureMapidArr.length; i++) {
            String sampleCultureMapIdValue = cultureMapidArr[i];
            String temperatureValue = temperatureArr[i];
            String durationValue = durationArr[i];
            String storageValue = storageLocationArr[i];
            String ovenValue = ovenArr[i];
            String mitoticindexValue = mitoticindexArr[i];
            String slidequalityValue = slidequalityArr[i];

            HashMap<String, String> hm = new HashMap<>();
            hm.put("u_sampleculturemapid", sampleCultureMapIdValue);

            int rowNum = ds.findRow(hm);

            ds.setValue(rowNum, "temperature", temperatureValue);
            ds.setValue(rowNum, "duration", durationValue);
            ds.setValue(rowNum, "storagelocation", storageValue);
            ds.setValue(rowNum, "oven", ovenValue);
            ds.setValue(rowNum, "mitoticindex", mitoticindexValue);
            ds.setValue(rowNum, "slidequality", slidequalityValue);
        }

        return ds;
    }

    private String createBatchId() {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "CytoBatch");
        props.setProperty("type", "SB");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        String batchId = "";
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            batchId = props.getProperty("newkeyid1", "");
        } catch (ActionException e) {
            e.printStackTrace();
        }
        return batchId;
    }

    /**
     * This method (createChildSample) creates child samples with selected culture type.
     * Here we are using the OOB child sample creation action MultiSampleChild with the select culture type manually.
     *
     * @throws SapphireException
     */

    public void createChildSlide(DataSet ds) throws SapphireException {

        PropertyList props = new PropertyList();

        for (int i = 0; i < ds.size(); i++) {
            props.clear();
            props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, ds.getValue(i, "parentsampleid"));
            props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "" + ds.getInt(i, "slideno"));
            props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_cytoid");
            try {
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Cannot create child specimen.");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            String childsample = props.getProperty("newkeyid1", "");
            if (Util.isNull(childsample)) {
                throw new SapphireException("Child Specimen not found");
            }
            DataSet finalDS = new DataSet();
            finalDS.copyRow(ds, i, 1);

            addChildSlide(childsample, finalDS);

            //updateTrackitem(ds);
            updateTrackitem(finalDS);

            String oven = finalDS.getValue(0, "oven");
            updateTrackitemForSlides(childsample, oven);

        }
    }

    /**
     * This method addSDI for the child sample means creating data for sample culture map.
     * Here we are using the OOB addSDI action because we need to insert the detailment and also insert the data into u_sampleculturemap table.
     *
     * @throws SapphireException
     */

    public void addChildSlide(String childsample, DataSet ds) throws SapphireException {


        if (ds != null && ds.size() > 0) {

            PropertyList props = new PropertyList();
            props.setProperty(AddSDI.PROPERTY_SDCID, "CytoSlides");
            props.setProperty(AddSDI.PROPERTY_COPIES, "" + (StringUtil.split(childsample, ";").length));
            props.setProperty("parentsampleid", ds.getValue(0, "parentsampleid"));
            props.setProperty("childsampleid", childsample);
            props.setProperty("slideid", ds.getValue(0, "slidename"));
            props.setProperty("psampleculturemapid", ds.getValue(0, "u_sampleculturemapid"));
            props.setProperty("temperature", ds.getValue(0, "temperature"));
            props.setProperty("availableduration", ds.getValue(0, "duration"));
            props.setProperty("storagelocation", ds.getValue(0, "storagelocation"));
            props.setProperty("batchid", ds.getValue(0, "batchid"));
            props.setProperty("freshprepsampleid", ds.getValue(0, "freshsampleid"));
            props.setProperty("slideno", ds.getValue(0, "imgno"));
            props.setProperty("oven", ds.getValue(0, "oven"));
            props.setProperty("mitoticindex", ds.getValue(0, "mitoticindex"));
            props.setProperty("slidequality", ds.getValue(0, "slidequality"));


            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                SLIDEID_FOR_LABEL = props.getProperty(AddSDI.RETURN_NEWKEYID1, "");
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Something went wrong. Please contact to administrator");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            // copyparentsampletestcode(ds.getValue(0, "parentsampleid"), childsample , getQueryProcessor() , getActionProcessor());
            Util.copyTestCodeFromParent(childsample, getQueryProcessor(), getActionProcessor(), "Cytogenetics");
        }
    }

    /**
     * This method copyparentsampletestcode, to copy the LV test code id from the parent sample to child sample.
     * Here we are not using the OOB action to copy the lvtestcode.
     *
     * @throws SapphireException
     */
    public void copyparentsampletestcode(String parentsample, String childsample, Object... externalProps) throws SapphireException {
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent Sample not found for copyparentsampletestcode method");
        }
        if (Util.isNull(childsample)) {
            throw new SapphireException("Child Samples not found for copyparentsampletestcode method");
        }

        QueryProcessor qp = null;
        ActionProcessor ap = null;
        if (externalProps.length > 0 && externalProps.length > 2) {
            throw new SapphireException("Error: Too many aguments received in copyparentsampletestcode");
        } else if (externalProps.length == 2) {
            try {
                qp = (QueryProcessor) externalProps[0];
                ap = (ActionProcessor) externalProps[1];
            } catch (Exception e) {
                throw new SapphireException("Error: Illeagal argement data type found in.\n" + e.getMessage());
            }
        }
        String sql = Util.parseMessage(CytoSqls.TESTCODE_FOR_CHILDSAMPLE_SQL, StringUtil.replaceAll(childsample, ";", "','"));
        DataSet dsTestCode = null;
        if (qp == null)
            dsTestCode = getQueryProcessor().getSqlDataSet(sql);
        else
            dsTestCode = qp.getSqlDataSet(sql);
        if (dsTestCode == null)
            throw new SapphireException("Error: Unable to perform query in datatbase");

        if (dsTestCode.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsTestCode.getColumnValues("destsampleid", ";"));
            props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsTestCode.getColumnValues("lvtestcodeid", ";"));
            props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
            try {
                if (ap == null)
                    getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
                else
                    ap.processAction("AddTestCode", "1", props);
            } catch (SapphireException e) {
                throw new SapphireException("Something went wrong. Please contact to administrator: " + e.getMessage());
            }
        }
    }

    /**
     * This method updateTrackitem, to calculate the remine volume of parent sample.
     * value will be deducted after creating a each child sample with the perticular inoculated amount.
     * Here we are not using the OOB action editTrackitem to calculate the proper amount.
     *
     * @throws SapphireException
     */


    public void updateTrackitem(DataSet ds) throws SapphireException {
        String sql = Util.parseMessage(CytoSqls.GET_STORAGE_CAPACITY, ds.getValue(0, "storagelocation"));
        DataSet storageDS = getQueryProcessor().getSqlDataSet(sql);
        PropertyList props = new PropertyList();
        if (storageDS.size() > 0) {
            int storageCount = Integer.parseInt(storageDS.getValue(0, "samplecnt")) + ds.size();
            int maxtAllowed = Integer.parseInt(storageDS.getValue(0, "maxtiallowed"));
            if (storageCount < maxtAllowed || maxtAllowed == -1) {
                try {
                    props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("childsampleid", ";"));
                    props.setProperty("currentstorageunitid", storageDS.getValue(0, "storageunitid"));

                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("childsampleid", ";"));
                    props.setProperty("u_cytostatus", "Dropped");

                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

                } catch (ActionException e) {
                    throw new SapphireException("Error occured during CheckIn inside Storage Location");
                }
            } else {
                throw new SapphireException("Default Storage capacity is full. Please select any other storage.");
            }

        }
    }

    public void updateTrackitemForSlides(String childsample, String Oven) throws SapphireException {

        String sql = parseMessage(CytoSqls.GET_STORAGEUNITID, Oven);
        DataSet dsStorage = getQueryProcessor().getSqlDataSet(sql);
        if (dsStorage == null)
            throw new SapphireException("Error: Unable to perform query in database");
        else if (dsStorage.size() == 0)
            throw new SapphireException("Error: Invalid box id. Query returned zero rows\nSQL: " + sql);

        PropertyList autoCustodyProp = new PropertyList();
        autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsample, ";", true));

        getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);

        /*String sql1 = parseMessage(CytoSqls.TIINFO_BY_ORGSAMPLEID,StringUtil.replaceAll(childsample,";","','"));
        DataSet dsStorage1 = getQueryProcessor().getSqlDataSet(sql1);*/

        PropertyList props = new PropertyList();
        try {

            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
            props.setProperty("u_currenttramstop", "CytoSlideBanding");
            props.setProperty("currentstorageunitid", dsStorage.getValue(0, "storageunitid"));
            props.setProperty("custodialuserid", "(null)");

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
            props.setProperty("u_currentmovementstep", "CytoSlideBanding");
            props.setProperty("u_cytostatus", "Ready for Banding");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("can not update updateTrackitemForSlides::" + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    public DataSet createSlideNames(DataSet ds) {
        ds.addColumn("slidename", DataSet.STRING);
        ds.addColumn("imgno", DataSet.STRING);
        for (int i = 0; i < ds.size(); i++) {
            String cultureName = "";
            String cultureId = ds.getValue(i, "culturetypeid");
            for (int j = 0; j < ds.getInt(i, "slideno"); j++) {
                cultureName += cultureId + "-" + (ds.getInt(i, "cnt") + j + 1) + ";";
            }
            ds.setValue(i, "slidename", cultureName.substring(0, cultureName.length() - 1));

            String val = "";
            String[] tempStr = StringUtil.split(ds.getValue(i, "slidename"), ";", true);
            for (String s : tempStr) {
                if (s.contains("-")) {
                    String[] tempArr = StringUtil.split(s, "-", true);
                    if (tempArr != null) {
                        val += ";" + tempArr[tempArr.length - 1].trim();
                    }
                }
            }

            ds.setValue(i, "imgno", val.substring(1));
        }

        return ds;
    }

    public void updateCustody(String childsample) throws SapphireException {

        String currentuser = connectionInfo.getSysuserId();
        String currentUserDepartment = connectionInfo.getDefaultDepartment();

        if (!Util.isNull(childsample)) {
            try {
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
                props.setProperty("custodialuserid", currentuser);
                props.setProperty("custodialdepartmentid", currentUserDepartment);
                props.setProperty("currentstorageunitid", "(null)");

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            } catch (ActionException e) {
                throw new SapphireException("Error: Caught exception while updating the custody of = " + childsample);
            }
        } else {
            throw new SapphireException("Error: Childsample not found to update custody...");
        }
    }

    public void updateSampleCultureMap(String sampleCultureMapId) throws SapphireException {

        if (!Util.isNull(sampleCultureMapId)) {
            try {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleCultureMapId);
                pl.setProperty("batchid", "(null)");
                pl.setProperty("thermotron", "(null)");
                pl.setProperty("dropdt", "n");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            } catch (ActionException e) {
                throw new SapphireException("Error: Caught exception while updating Batchid and Thermotron in SampleCultureMap.");
            }
        }
    }

    public void autoCustodyTransfer(String sampleCultureMapId) throws SapphireException {

        String slidesql = Util.parseMessage(CytoSqls.GET_SLIDE_CHILDSAMPLE_ID, StringUtil.replaceAll(sampleCultureMapId, ";", "','"));
        DataSet dsslidechildsample = getQueryProcessor().getSqlDataSet(slidesql);
        String parentsampleid = "";
        String childslidesample = "";
        if (dsslidechildsample != null && dsslidechildsample.size() > 0) {
            parentsampleid = dsslidechildsample.getColumnValues("parentsampleid", ";");
            childslidesample = dsslidechildsample.getColumnValues("childsampleid", ";");
        }
        String sampleids = parentsampleid + ";" + childslidesample;
        try {
            PropertyList autoCustodyProp = new PropertyList();
            autoCustodyProp.setProperty("sampleid", Util.getUniqueList(sampleids, ";", true));

            getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
        } catch (SapphireException ex) {
            throw new SapphireException("Unable to take custody. Reason: " + ex.getMessage());
        }
    }


}

