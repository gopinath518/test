package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;

import java.util.HashMap;

/**
 * Created by aritra.banerjee on 5/11/2017.
 */
public class CytoUncancelSample extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String orgsample = properties.getProperty("sampleid", "");
        String testcodeid = properties.getProperty("testcodeid", "");

        DataSet dsSTMInfo = checkForDaughterTube(orgsample, testcodeid);

        if(dsSTMInfo != null && dsSTMInfo.size() > 0){
            orgsample  = dsSTMInfo.getColumnValues("s_sampleid", ";");
            testcodeid = dsSTMInfo.getColumnValues("lvtestcodeid", ";");
        }

        if (!Util.isNull(orgsample) && !Util.isNull(testcodeid)) {
            String orgsampleArr[] = StringUtil.split(orgsample, ";");
            String testcodeidArr[] = StringUtil.split(testcodeid, ";");

            DataSet dsMain = new DataSet();
            dsMain.addColumn("orgsample", DataSet.STRING);
            dsMain.addColumn("testcodeid", DataSet.STRING);

            for (int i = 0; i < orgsampleArr.length; i++) {
                int row = dsMain.addRow();
                dsMain.setValue(row, "orgsample", orgsampleArr[i]);
                dsMain.setValue(row, "testcodeid", testcodeidArr[i]);
            }

            String sql = Util.parseMessage(CytoSqls.GET_CULTURES_BY_FRESHPREPSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
            DataSet dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(CytoSqls.GET_SLIDES_BY_FRESHPREPSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
            DataSet dsSlidesInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsCultureInfo != null && dsSlidesInfo != null) {
                DataSet dsFinal = createFinalQueryDataset(dsCultureInfo, dsSlidesInfo, dsMain);
                updateSampleTestCodeMap(dsFinal);
                updateSampleCultureMap(dsFinal);
            }
        }

    }

    /**
     * @desc checking for daughter tubes.
     * @param orgsample
     * @param testcodeid
     * @return
     * @throws SapphireException
     */
    private DataSet checkForDaughterTube(String orgsample, String testcodeid) throws SapphireException {

        String sql = Util.parseMessage(CytoSqls.GET_DAUGHTERSAMPLEID_BY_ACCESSIONSAMPLEID, StringUtil.replaceAll(orgsample, ";", "','"));
        DataSet dsDaughterInfo = getQueryProcessor().getSqlDataSet(sql);


        if (dsDaughterInfo == null)
            throw new SapphireException("Daughter tube info cannot be obtained from database");
        if (dsDaughterInfo.size() > 0) {
            String orgsampleArr[] = StringUtil.split(orgsample, ";");
            String testcodeidArr[] = StringUtil.split(testcodeid, ";");

            DataSet dsAccessionInfo = new DataSet();
            dsAccessionInfo.addColumn("sampleid", DataSet.STRING);
            dsAccessionInfo.addColumn("testcodeid", DataSet.STRING);
            dsAccessionInfo.addColumn("testcodeid#sampleid", DataSet.STRING);

            for (int i = 0; i < orgsampleArr.length; i++) {
                int row = dsAccessionInfo.addRow();
                dsAccessionInfo.setValue(row, "sampleid", orgsampleArr[i]);
                dsAccessionInfo.setValue(row, "testcodeid", testcodeidArr[i]);
                String combination = testcodeidArr[i] + "#" + orgsampleArr[i];
                dsAccessionInfo.setValue(row, "testcodeid#sampleid", combination);

                HashMap hm = new HashMap();
                hm.clear();
                hm.put("sourcesampleid", orgsampleArr[i]);
                DataSet dsDaughterFilter = dsDaughterInfo.getFilteredDataSet(hm);

                if (dsDaughterFilter.size() > 0) {
                    for (int j = 0; j < dsDaughterFilter.size(); j++) {
                        String daughterSample = dsDaughterFilter.getValue(j, "destsampleid", "");
                        int rowId = dsAccessionInfo.addRow();
                        dsAccessionInfo.setValue(rowId, "sampleid", daughterSample);
                        dsAccessionInfo.setValue(rowId, "testcodeid", testcodeidArr[i]);
                        combination = testcodeidArr[i] + "#" + daughterSample;
                        dsAccessionInfo.setValue(rowId, "testcodeid#sampleid", combination);
                    }
                }
            }

            if(dsAccessionInfo!=null && dsAccessionInfo.size()>0) {

                String lvtestcodeSampleCombination = dsAccessionInfo.getColumnValues("testcodeid#sampleid", ";");
                sql = Util.parseMessage(CytoSqls.GET_SAMPLETESTCODEMAPID_BY_LVTESTCODEAMPLEIDCOMB, StringUtil.replaceAll(lvtestcodeSampleCombination, ";", "','"));
                DataSet dsSTMInfo = getQueryProcessor().getSqlDataSet(sql);

                if (dsSTMInfo == null)
                    throw new SapphireException("SampleTestCodeMap info cannot be obtained from database");

                if (dsSTMInfo.size() > 0)
                    return dsSTMInfo;
            }
        }
        return null;

    }

    /**
     * @desc creating final query dataset
     * @param dsCultureInfo
     * @param dsSlidesInfo
     * @param dsMain
     * @return dsTemp (containing final sample test code combination to be updated)
     */
    private DataSet createFinalQueryDataset(DataSet dsCultureInfo, DataSet dsSlidesInfo, DataSet dsMain) {

        DataSet dsTemp = new DataSet();
        dsTemp.addColumn("childsampleid", DataSet.STRING);
        dsTemp.addColumn("testcodeid", DataSet.STRING);
        dsTemp.addColumn("testcodeid#childsampleid", DataSet.STRING);

            for (int i = 0; i < dsMain.size(); i++) {
                String fpsampleid = dsMain.getValue(i, "orgsample");
                String fptestcode = dsMain.getValue(i, "testcodeid");
                int row = dsTemp.addRow();
                String combination = fptestcode + "#" + fpsampleid;
                dsTemp.setValue(row, "testcodeid#childsampleid", combination);

                if (dsCultureInfo.size() > 0) {
                HashMap hm = new HashMap();
                hm.put("orgsampleid", fpsampleid);
                DataSet dsFilter = dsCultureInfo.getFilteredDataSet(hm);

                if(dsFilter!=null && dsFilter.size()>0) {

                    for (int j = 0; j < dsFilter.size(); j++) {
                        String childsample = dsFilter.getValue(j, "childsampleid");
                        row = dsTemp.addRow();
                        dsTemp.setValue(row, "childsampleid", childsample);
                        dsTemp.setValue(row, "testcodeid", fptestcode);
                        combination = fptestcode + "#" + childsample;
                        dsTemp.setValue(row, "testcodeid#childsampleid", combination);

                    }
                }
            }
        }

        if (dsSlidesInfo.size() > 0) {
            for (int i = 0; i < dsMain.size(); i++) {
                String fpsampleid = dsMain.getValue(i, "orgsample");
                String fptestcode = dsMain.getValue(i, "testcodeid");

                HashMap hm = new HashMap();
                hm.put("orgsampleid", fpsampleid);
                DataSet dsFilter = dsSlidesInfo.getFilteredDataSet(hm);

                if(dsFilter!=null && dsFilter.size()>0) {

                    for (int j = 0; j < dsFilter.size(); j++) {
                        String childsample = dsFilter.getValue(j, "childsampleid");
                        int row = dsTemp.addRow();
                        dsTemp.setValue(row, "childsampleid", childsample);
                        dsTemp.setValue(row, "testcodeid", fptestcode);
                        String combination = fptestcode + "#" + childsample;
                        dsTemp.setValue(row, "testcodeid#childsampleid", combination);

                    }
                }
            }
        }

        return dsTemp;
    }

    /**
     * @desc updating unuse & cancel as null in SampleTestCodeMap.
     * @param dsFinal
     * @throws SapphireException
     */
    private void updateSampleTestCodeMap(DataSet dsFinal) throws SapphireException {

        String lvtestcodeSampleCombination = dsFinal.getColumnValues("testcodeid#childsampleid", ";");
        String sql = Util.parseMessage(CytoSqls.GET_SAMPLETESTCODEMAPID_BY_LVTESTCODEAMPLEIDCOMB, StringUtil.replaceAll(lvtestcodeSampleCombination, ";", "','"));
        DataSet dsSTMInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsSTMInfo != null && dsSTMInfo.size() > 0) {
            String sampletestcodemapid = dsSTMInfo.getColumnValues("u_sampletestcodemapid", ";");

            if (!Util.isNull(sampletestcodemapid)) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
                pl.setProperty("unused", "(null)");
                pl.setProperty("cancelled", "(null)");
                pl.setProperty("cancelopp", "(null)");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }

    }

    /**
     * @desc updating unuse & cancel as null for SampleCultureMap.
     * @param dsFinal
     * @throws SapphireException
     */
    private void updateSampleCultureMap(DataSet dsFinal) throws SapphireException {

        String childsampleid = dsFinal.getColumnValues("childsampleid", ";");

        // update in sampleculturemap
        String sql = Util.parseMessage(CytoSqls.GET_SAMPLECULTUREMAPID_BY_CHILDSAMPLEID, StringUtil.replaceAll(childsampleid, ";", "','"));
        DataSet dsSCMInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsSCMInfo != null && dsSCMInfo.size() > 0) {
            String sampleculturemapid = dsSCMInfo.getColumnValues("u_sampleculturemapid", ";");

            if (!Util.isNull(sampleculturemapid)) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleculturemapid);
                pl.setProperty("unused", "(null)");
                pl.setProperty("cancelled", "(null)");
                pl.setProperty("cancelopp", "(null)");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }

        // update in slides

        sql = Util.parseMessage(CytoSqls.GET_CYTOSLIDE_ID, StringUtil.replaceAll(childsampleid, ";", "','"));
        DataSet dsSLIDESInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsSLIDESInfo != null && dsSLIDESInfo.size() > 0) {
            String cytoslidesid = dsSLIDESInfo.getColumnValues("u_cytoslidesid", ";");

            if (!Util.isNull(cytoslidesid)) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, cytoslidesid);
                pl.setProperty("unused", "(null)");
                pl.setProperty("cancelled", "(null)");
                pl.setProperty("cancelopp", "(null)");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }

        // update in cyto status

        sql = Util.parseMessage(CytoSqls.GET_PREVCYTOSTATUS_BY_SAMPLEID, StringUtil.replaceAll(childsampleid, ";", "','"));
        DataSet dsChildCytoStatusInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsChildCytoStatusInfo != null && dsChildCytoStatusInfo.size() > 0) {
            HashMap<String,String> hmap=new HashMap<String,String>();
            hmap.put("u_cytostatus","Unused");

            DataSet result=dsChildCytoStatusInfo.getFilteredDataSet(hmap);
            if(result!=null && result.size()>0) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, result.getColumnValues("s_sampleid", ";"));
                pl.setProperty("u_cytostatus", result.getColumnValues("u_prevcytostatus", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }
    }


}
