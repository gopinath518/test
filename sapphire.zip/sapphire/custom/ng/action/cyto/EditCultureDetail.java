package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class EditCultureDetail extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        //String thermotron = properties.getProperty("thermotron","");
        String slideno = properties.getProperty("slideno","");
        String mitoticindex = properties.getProperty("mitoticindex","");
        String slidequality = properties.getProperty("slidequality","");
        String palletleft = properties.getProperty("palletleft","");
        String keyid1 = properties.getProperty("keyid1","");
        String childsampleid = properties.getProperty("childsampleid","");

        String slidetemp = properties.getProperty("slidetemp","");
        String sldageingtime = properties.getProperty("sldageingtime","");
        String sldoven = properties.getProperty("sldoven","");
        String cltrstorage = properties.getProperty("cltrstorage","");


        if(!Util.isNull(childsampleid)){
            try {
                PropertyList autoCustodyProp = new PropertyList();
                autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsampleid, ";", true));

                getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
            }catch(SapphireException ex){
                throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
            }

        }

        if(!Util.isNull(keyid1)){
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID,"SampleCultureMap");
            pl.setProperty(EditSDI.PROPERTY_KEYID1,keyid1);
            pl.setProperty("slideno",slideno);
            pl.setProperty("palletleft",palletleft);
            pl.setProperty("thermotron","(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (Exception e){
                throw new SapphireException("Unable to Edit culture details.");
            }

            pl.clear();
            pl.setProperty("sampleculturemapid", keyid1);
            pl.setProperty("temperature", slidetemp);
            pl.setProperty("duration", sldageingtime);
            pl.setProperty("storagelocation", cltrstorage);
            pl.setProperty("oven", sldoven);
            pl.setProperty("mitoticindex",mitoticindex);
            pl.setProperty("slidequality",slidequality);
            getActionProcessor().processAction("AddSlide", "1", pl);

        }
    }
}
