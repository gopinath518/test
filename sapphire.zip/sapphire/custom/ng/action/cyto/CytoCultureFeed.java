package sapphire.custom.ng.action.cyto;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 1/16/2017.
 */
public class CytoCultureFeed extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String keyid1 = properties.getProperty("keyid1");
        String childsampleid = properties.getProperty("childsampleid", "");
        if(Util.isNull(keyid1)){
            throw new SapphireException("Error: Sample id not found... Please select atlest one sample...");
        }
        String ngcomment = properties.getProperty("ngcomment");
        if(Util.isNull(ngcomment)){
            throw new SapphireException("Error: Feed Comment can not be blank...");
        }
        try {
            PropertyList autoCustodyProp = new PropertyList();
            autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsampleid, ";", true));

            getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
        }catch(SapphireException ex){
            throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
        }

        sampleComments(keyid1,ngcomment);
        sampleFeedDetails(keyid1);
        DataSet dsFinal = feednow(keyid1);

        try {
            PropertyList prop1 = new PropertyList();
            prop1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop1.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("s_sampleid", ";"));
            prop1.setProperty("u_cytostatus", dsFinal.getColumnValues("updated_culturestatus", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop1);
            
            HashMap<String, String> paramValMap = new HashMap<String, String>();
            paramValMap.put("param1", StringUtil.replaceAll(properties.getProperty("freshprepsampleid", ""), ";", "\\',\\'"));
            
            properties.setProperty("msg", Util.setReturnURL("CytoFeedCultureList", "CulturesBySampleIdForFeed", paramValMap));
            
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Error: Unable to perform FeedNow process ... ");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        

    }

    /**
     *
     * @param keyid1
     * @param ngcomment
     * @throws SapphireException
     */
    public void sampleComments(String keyid1, String ngcomment) throws SapphireException {

        PropertyList props1 = new PropertyList();
        props1.setProperty(AddSDI.PROPERTY_SDCID, "ngcomment");
        props1.setProperty(AddSDI.PROPERTY_COPIES, ""+keyid1.length());
        props1.setProperty("linkkeyid1", keyid1);
        props1.setProperty("linksdcid", StringUtil.repeat("SampleCultureMap", keyid1.length(), ";"));
        props1.setProperty("notes",StringUtil.repeat(ngcomment,keyid1.length(), ";"));
        props1.setProperty("operation", StringUtil.repeat("Feed Now", keyid1.length(), ";"));

        getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID, props1);

    }

    /**
     * Updating sample feed details for sample cukture map.
     * @param keyid1
     * @throws SapphireException
     */
    public void sampleFeedDetails(String keyid1) throws SapphireException{

        String currentuser = connectionInfo.getSysuserId();
        PropertyList props1 = new PropertyList();
        props1.setProperty(EditSDI.PROPERTY_SDCID, "SampleCulturemap");
        props1.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
        props1.setProperty("feeddt", "n");
        props1.setProperty("feeduser",currentuser);
        props1.setProperty("batchid","(null)");

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID, props1);
    }

    /**
     *
     * @param keyid1
     * @return ds
     * @throws SapphireException
     */
    private DataSet feednow(String keyid1) throws SapphireException {

        String sql = Util.parseMessage(CytoSqls.CULTURE_STATUS, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null) {
            ds.addColumn("updated_culturestatus", DataSet.STRING);
            for (int i = 0; i < ds.size(); i++) {
                String cytostatus = ds.getValue(i, "u_cytostatus");
                String updatedstatus = "";
                if (Util.isNull(cytostatus) || cytostatus.equalsIgnoreCase("Ready for Feed") || cytostatus.equalsIgnoreCase("Ready for Slide Drop") || cytostatus.equalsIgnoreCase("Unused")) {
                    updatedstatus = "Eval 1 Complete";
                } else {
                    String arr[] = cytostatus.split(" ");
                    if (Integer.parseInt(arr[1]) + 1 > 12) {
                        throw new SapphireException("Error: Eval 12 times already completed...");
                    } else {
                        updatedstatus = arr[0] + " " + (Integer.parseInt(arr[1]) + 1) + " " + arr[2];
                    }
                }
                ds.setValue(i, "updated_culturestatus", updatedstatus);
            }
        }

        return ds;
    }
}
