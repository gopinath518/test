package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import static sapphire.custom.ng.util.Util.parseMessage;

public class CytoAssignMetaferInstrument extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String metafarinstrumntid = properties.getProperty("metafarinstrumntid", "");
        String keyid1 = properties.getProperty("keyid1", "");
        String sdcid = properties.getProperty("sdcid", "");

        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();


        if (!Util.isNull(keyid1)) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
            pl.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            pl.setProperty("metafarinstrumntid", metafarinstrumntid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (Exception e) {
                throw new SapphireException("Unable to Assign Instrument. Reason : " + e.getMessage());
            }
        }

        String sql = parseMessage(CytoSqls.GET_CHILDSAMPLEID_FROM_CYTOSLIDES_BY_KEYID1 , StringUtil.replaceAll(keyid1 , ";" , "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        if(dsSql == null) {
            throw new SapphireException("Unable to execute query.");
            //Logger.logInfo("Unable to execute query." + sql);
        }

        if(dsSql.size() > 0){
            String childsampleid = dsSql.getColumnValues("childsampleid",";");

            if (!Util.isNull(childsampleid)) {
                PropertyList propupdate = new PropertyList();
                propupdate.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                propupdate.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
                propupdate.setProperty("custodialuserid", currentuser);
                propupdate.setProperty("custodialdepartmentid", defaultdepartment);
                try {
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, propupdate);
                } catch (Exception e) {
                    throw new SapphireException("Unable to take into current user custody. Reason : " + e.getMessage());
                }
            }

        } else
            throw new SapphireException("Unable to find records of scanned slide(s). Please contact administrator.");

    }
}
