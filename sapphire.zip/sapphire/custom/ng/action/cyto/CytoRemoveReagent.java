package sapphire.custom.ng.action.cyto;

import com.labvantage.opal.validation.misc.ConvertUnits;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class CytoRemoveReagent extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String keyid1 = properties.getProperty("keyid1", "");
        String reagentlotid = properties.getProperty("reagentlotid", "");
        String amount = properties.getProperty("amount", "");
        String assignedunit = properties.getProperty("unit", "");
        String trackitemid = properties.getProperty("trackitemid", "");
        String trackitemamount = properties.getProperty("trackitemamount", "");
        String trackitemunit = properties.getProperty("trackitemunit", "");

        DataSet dsFinal = new DataSet();
        dsFinal.addColumnValues("keyid1", DataSet.STRING, properties.getProperty("keyid1"), ";", "");

        if (!Util.isNull(dsFinal.getColumnValues("keyid1", ";"))) {
            PropertyList prop = new PropertyList();
            try {
                prop.setProperty(DeleteSDI.PROPERTY_SDCID, "CytoSampleReagentMap");
                prop.setProperty(DeleteSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("keyid1", ";"));

                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Error occurred: Can't delete from CytoSampleReagentMap.");
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
        }

    }
}
