package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.action.RecordIncident;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Constants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.ConnectionInfo;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.*;

/**
 * Created by achakraborty on 11/22/2016.
 */
public class AddCulture extends BaseAction implements Constants {
    private static final String PARENTSAMPLE_PROP = "sampleid";
    private static final String CULTURETYPE_PROP = "culturetypeid";
    private static final String COPIES_PROP = "copies";
    private String CULTUREMAPID_FOR_LABEL = "";

    public void processAction(PropertyList properties) throws SapphireException {

        addCultureOrFlask(properties); // logic for culture addition for cyto

        if(!Util.isNull(CULTUREMAPID_FOR_LABEL)){
            PropertyList props = new PropertyList();
            props.setProperty(PrintLabel.SDCID_PROP, "SampleCultureMap");
            props.setProperty(PrintLabel.KEYID1_PROP, CULTUREMAPID_FOR_LABEL);
            props.setProperty("labelmethodid", "CytoCultureLbl");
            try {
                getActionProcessor().processAction("PrintLabel", "1", props);
            } catch (SapphireException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Unbale to Print Label for Cultures from Cyto-Setup. ");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }

        /*String parentsample = properties.getProperty(PARENTSAMPLE_PROP);
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent Sample not found");
        }
        validateCusttodyofFPSample(parentsample);
        String culturetype = "";
        String isFlask = properties.getProperty("isflask");
        if ("Y".equals(isFlask)) {
            int flaskCount = Integer.parseInt(properties.getProperty("flaskcount"));
            culturetype = createFlaskCultureName(culturetype, flaskCount, parentsample);

        } else {
            culturetype = properties.getProperty(CULTURETYPE_PROP);
            if (Util.isNull(culturetype)) {
                throw new SapphireException("Culture type not found");
            }
        }

        createChildSample(parentsample, culturetype, isFlask);
        properties.setAttribute("msg", createIncidentRequest(parentsample));*/
    }

    /**
     * Adds Culture or Flask to a cyto sample.
     *
     * @param properties
     * @throws SapphireException
     */

    private void addCultureOrFlask(PropertyList properties) throws SapphireException {

        String parentsample = properties.getProperty(PARENTSAMPLE_PROP);
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent Sample not found");
        }
        String culturetype = properties.getProperty(CULTURETYPE_PROP);
        if (Util.isNull(culturetype)) {
            throw new SapphireException("Culture type not found");
        }
        validateCusttodyofFPSample(parentsample);

        String isFlask = "";
        if (culturetype.toLowerCase().contains("flask"))
            isFlask = "Y";

        String notFlaskCulturetype = "";

        String[] cultureArr = StringUtil.split(culturetype, ";");
        if (cultureArr != null && cultureArr.length > 0) {
            for (String str : cultureArr) {
                if (!str.equalsIgnoreCase("flask"))
                    notFlaskCulturetype += ";" + str;
            }
        }
        if (notFlaskCulturetype.startsWith(";"))
            notFlaskCulturetype = notFlaskCulturetype.substring(1);

        if ("Y".equals(isFlask)) {
            int flaskCount = 1;
            String flaskCulturetype = createFlaskCultureName("", flaskCount, parentsample);
            createChildSample(parentsample, flaskCulturetype, isFlask);

        }
        if (!Util.isNull(notFlaskCulturetype)) {
            createChildSample(parentsample, notFlaskCulturetype, "");
        }
        properties.setAttribute("msg", createIncidentRequest(parentsample));
    }


    private void validateCusttodyofFPSample(String dumysampleid) throws SapphireException {
        if (!Util.isNull(dumysampleid)) {
            String sql = Util.parseMessage(CytoSqls.TI_INFO_OF_FPSAMPLE_BY_DUMMYSAMPLEID, StringUtil.replaceAll(dumysampleid, ";", "','"));
            DataSet dsTIInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTIInfo == null)
                throw new SapphireException("The below query cannot be executed.\n" + sql);
            if (dsTIInfo.size() == 0)
                throw new SapphireException("Trackitem info cannot be obtained for the selected sample");
            String currentUser = connectionInfo.getSysuserId();
            String disputedSample = "";
            if (!Util.isNull(currentUser)) {
                for (int i = 0; i < dsTIInfo.size(); i++) {
                    String tempCurrUser = dsTIInfo.getValue(i, "custodialuserid", "");
                    String tempFPSampleId = dsTIInfo.getValue(i, "linkkeyid1", "");
                    if (!currentUser.equalsIgnoreCase(tempCurrUser))
                        disputedSample += ";" + tempFPSampleId;
                }
                if (!Util.isNull(disputedSample)) {
                    if (disputedSample.startsWith(";"))
                        disputedSample = disputedSample.substring(1);
                    throw new SapphireException("Below sample(s) are not in current user custody.\n" + disputedSample);
                }
            }
        }
    }

    /**
     * This method (createChildSample) creates child samples with selected culture type.
     * Here we are using the OOB child sample creation action MultiSampleChild with the select culture type manualy.
     *
     * @param parentsample
     * @param culturetype
     * @param isFlask
     * @throws SapphireException
     */
    public void createChildSample(String parentsample, String culturetype, String isFlask) throws SapphireException {
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent sample not found to create child sample");
        }
        if (Util.isNull(culturetype)) {
            throw new SapphireException("Culture type not found to create child sample");
        }
        String[] culturetypeArr = StringUtil.split(culturetype, ";");
        if (culturetypeArr != null && culturetypeArr.length > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentsample);
            props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "" + culturetypeArr.length);
            //props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_cytoid;u_cytostatus");
            props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;concentration;u_cytoid;u_currentmovementstep");
            try {
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Cannot create child samples.");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            String childsample = props.getProperty("newkeyid1", "");
            if (Util.isNull(childsample)) {
                throw new SapphireException("Child Sample not found.");
            }
//            else{
//            	props.clear();
//            	props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
//            	props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
//            	props.setProperty("u_iscytoincidentcreated", "Y");
//            }
            if ("Y".equals(isFlask))
                addFlask(childsample, parentsample, culturetype);
            else
                culturetype = addCulture(childsample, parentsample, culturetype);

            updateTrackitem(parentsample, culturetype);
            updateTrackitemForCultures(childsample);

        }
    }

    /**
     * @return True or False.
     * @throws SapphireException
     * @desc Validating department from policy before adding duplicate cultures.
     */
    public boolean validateDepartment() throws SapphireException {

        String currentUserDepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();

        List<String> deptLocation = new ArrayList<String>();

        PropertyList departmentPolicyProperties = getConfigurationProcessor().getPolicy("CytoCultrCrtValidationPolicy", "AddCultrValid");
        PropertyList pl = departmentPolicyProperties.getPropertyList("deptlist");
        PropertyListCollection plc = pl.getCollection("deptcollection");

        for (int i = 0; i < plc.size(); i++)
            deptLocation.add(plc.getPropertyList(i).getProperty("deptid"));

        return deptLocation.contains(currentUserDepartment);
    }

    /**
     * @param childsample
     * @param parentsample
     * @param culturetype
     * @return
     * @throws SapphireException
     * @Desc Adding cultures at detailment section  on maint page.
     */
    public String addCulture(String childsample, String parentsample, String culturetype) throws SapphireException {

        DataSet dsCultureCreationDetails = createCultureDetails(childsample, parentsample, culturetype);
        if (dsCultureCreationDetails == null)
            addChildSample(childsample, parentsample, culturetype, "", "");
        else {
//            if (validateDepartment()) {
                HashMap hm = new HashMap();
                hm.put("isduplicate", "N");
                DataSet ds = dsCultureCreationDetails.getFilteredDataSet(hm);
                if (ds.size() > 0) {
                    addChildSample(ds.getColumnValues("childsample", ";"), parentsample, ds.getColumnValues("culturetype", ";"), "", "");
                }
                hm.clear();
                ds.clear();
                hm.put("isduplicate", "Y");
                ds = dsCultureCreationDetails.getFilteredDataSet(hm);
                if (ds.size() > 0) {
                    String orgculturetype = ds.getColumnValues("orgculturetype", ",");
                    throw new SapphireException("Below culture(s) are already created.\n"+orgculturetype);
//                    String parentsampleculturemapid = ds.getColumnValues("parentsampleculturemapid", ";");
//                    addChildSample(ds.getColumnValues("childsample", ";"), parentsample, ds.getColumnValues("culturetype", ";"), orgculturetype, parentsampleculturemapid);
                }
                culturetype = dsCultureCreationDetails.getColumnValues("culturetype", ";");
//            } else
//                throw new SapphireException("Unable to Add Duplicate Culture. User does not have the Privilege to Add Duplicate Culture.");
        }
        return culturetype;
    }

    /**
     * @param childsample
     * @param parentsample
     * @param culturetype
     * @return
     * @throws SapphireException
     * @desc creating culture details while adding dublicate cultres.
     */
    public DataSet createCultureDetails(String childsample, String parentsample, String culturetype) throws SapphireException {

        String[] childsampleArr = StringUtil.split(childsample, ";");
        String[] culturetypeArr = StringUtil.split(culturetype, ";");
        HashMap hm = new HashMap();

        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("childsample", DataSet.STRING);
        dsFinal.addColumn("culturetype", DataSet.STRING);
        dsFinal.addColumn("orgculturetype", DataSet.STRING);
        dsFinal.addColumn("parentsampleculturemapid", DataSet.STRING);
        dsFinal.addColumn("isduplicate", DataSet.STRING);

        String sql = Util.parseMessage(CytoSqls.GET_DUPLICATE_CULTURE_INFO, parentsample, StringUtil.replaceAll(culturetype, ";", "','"));
        DataSet dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);

        sql = Util.parseMessage(CytoSqls.GET_DUPLICATE_CULTURE_COUNT, parentsample, StringUtil.replaceAll(culturetype, ";", "','"));
        DataSet dsDuplicateCountInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsCultureInfo == null)
            throw new SapphireException("Unble to fetch culture details from Database.");

        if (dsDuplicateCountInfo == null)
            throw new SapphireException("Unble to fetch duplicate culture details from Database.");

        if (dsCultureInfo.size() == 0 && dsDuplicateCountInfo.size() == 0)
            return null;
        else {
            for (int i = 0; i < culturetypeArr.length; i++) {
                hm.clear();
                hm.put("culturetypeid", culturetypeArr[i]);
                DataSet dsFilter = dsCultureInfo.getFilteredDataSet(hm);

                HashMap hmCount = new HashMap();
                hmCount.put("orgculturetype", culturetypeArr[i]);
                DataSet dsOrgCountFilter = dsDuplicateCountInfo.getFilteredDataSet(hmCount);

                if (dsFilter.size() == 0 && dsOrgCountFilter.size() == 0) {
                    // no parent(24) culture and no duplicate(24-A/B/C) culture exists
                    int rowId = dsFinal.addRow();
                    dsFinal.setValue(rowId, "childsample", childsampleArr[i]);
                    dsFinal.setValue(rowId, "culturetype", culturetypeArr[i]);
                    dsFinal.setValue(rowId, "orgculturetype", "");
                    dsFinal.setValue(rowId, "parentsampleculturemapid", "");
                    dsFinal.setValue(rowId, "isduplicate", "N");
                } else {
                    int count = Integer.parseInt(dsFilter.getValue(0, "cnt", "-1"));
                    String psampleculturemapid = dsFilter.getValue(0, "u_sampleculturemapid");

                    if (count == 0 && dsOrgCountFilter.size() == 0) {
                        // parent(24) culture exists but no duplicate(24-A/B/C) culture exists
                        int rowId = dsFinal.addRow();
                        dsFinal.setValue(rowId, "childsample", childsampleArr[i]);
                        dsFinal.setValue(rowId, "culturetype", culturetypeArr[i] + "-A");
                        dsFinal.setValue(rowId, "orgculturetype", culturetypeArr[i]);
                        dsFinal.setValue(rowId, "parentsampleculturemapid", psampleculturemapid);
                        dsFinal.setValue(rowId, "isduplicate", "Y");

                    } else if (count == -1 && dsOrgCountFilter.size() > 0) {
                        //no parent(24) culture but duplicate(24-A/B/C) culture exists
                        int startCnt = 0;
                        psampleculturemapid = dsOrgCountFilter.getValue(0, "parentsampleculturemapid");
                        String lastCulture = dsOrgCountFilter.getValue((dsOrgCountFilter.getRowCount()-1),"culturetypeid");
                        if (lastCulture.contains("-")) {
                            lastCulture = lastCulture.substring(lastCulture.indexOf("-"));
                        }

                        if (lastCulture.startsWith("-"))
                            lastCulture = lastCulture.substring(1);

                        char lstChar = lastCulture.charAt(0);

                        int ascii = (int) lstChar;
                        if (count < 26)
                            startCnt = ascii + 1;
                        else
                            throw new SapphireException("Already 26 Cultures have been created for this sample id");

                        int rowId = dsFinal.addRow();
                        dsFinal.setValue(rowId, "childsample", childsampleArr[i]);
                        dsFinal.setValue(rowId, "culturetype", culturetypeArr[i] + "-" + (char) startCnt);
                        dsFinal.setValue(rowId, "orgculturetype", culturetypeArr[i]);
                        dsFinal.setValue(rowId, "parentsampleculturemapid", psampleculturemapid);
                        dsFinal.setValue(rowId, "isduplicate", "Y");

                    } else {
                        // parent culture(24) exists and duplicate culture(24-A/B/C) also exists
                        int startCnt = 0;
                        char lstChar;
                        String lastCultureCreated = dsFilter.getValue(0, "lstculture", "");
                        if (lastCultureCreated.contains("-")) {
                            lastCultureCreated = lastCultureCreated.substring(lastCultureCreated.indexOf("-"));
                        }

                        if (lastCultureCreated.startsWith("-"))
                            lastCultureCreated = lastCultureCreated.substring(1);

                        lstChar = lastCultureCreated.charAt(0);

                        int ascii = (int) lstChar;
                        if (count < 26)
                            startCnt = ascii + 1;
                        else
                            throw new SapphireException("Already 26 Cultures have been created for this sample id");

                        int rowId = dsFinal.addRow();
                        dsFinal.setValue(rowId, "childsample", childsampleArr[i]);
                        dsFinal.setValue(rowId, "culturetype", culturetypeArr[i] + "-" + (char) startCnt);
                        dsFinal.setValue(rowId, "orgculturetype", culturetypeArr[i]);
                        dsFinal.setValue(rowId, "parentsampleculturemapid", psampleculturemapid);
                        dsFinal.setValue(rowId, "isduplicate", "Y");
                    }
                }

            }
            return dsFinal;
        }

    }

    /**
     * Created by achakraborty & modified by abanerjee.
     *
     * @param childsample
     * @param parentsample
     * @param culturetype
     * @param orgculturetype
     * @param parentsampleculturemapid
     * @throws SapphireException
     * @desc adding cultures in sample culture map
     */
    public void addChildSample(String childsample, String parentsample, String culturetype, String orgculturetype, String parentsampleculturemapid) throws SapphireException {
        if (Util.isNull(childsample)) {
            throw new SapphireException("Child Sample not found in addChildSample method");
        }
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent Sample not found in addChildSample method");
        }
        if (Util.isNull(culturetype)) {
            throw new SapphireException("Culture type not found in addChildSample method");
        }
        if (Util.isNull(orgculturetype)) {
            orgculturetype = culturetype;
        }
        String sql = Util.parseMessage(CytoSqls.AMOUNTINOCULATED, StringUtil.replaceAll(orgculturetype, ";", "','"));
        DataSet dsamountinoculated = getQueryProcessor().getSqlDataSet(sql);
        sql = Util.parseMessage(CytoSqls.DEFAULT_REAGENT_DETAILS, "Setup", connectionInfo.getDefaultDepartment());
        DataSet dsreagent = getQueryProcessor().getSqlDataSet(sql);

        if (dsamountinoculated != null && dsreagent != null) {
            String amountinoculated = dsamountinoculated.getColumnValues("amountinoculated", ";");
            //String reagenttypeid = dsreagent.getColumnValues("reagenttypeid", ";");
            //String[] reagenttypeidArr = StringUtil.split(reagenttypeid, ";");
            //String reagentlotid = dsreagent.getColumnValues("reagentlotid", ";");
            //String[] reagentlotidArr = StringUtil.split(reagentlotid, ";");
            //String type = dsreagent.getColumnValues("type", ";");
            //String[] typeArr = StringUtil.split(type, ";");
            PropertyList props = new PropertyList();
            props.setProperty(AddSDI.PROPERTY_SDCID, "SampleCultureMap");
            props.setProperty(AddSDI.PROPERTY_COPIES, "" + (StringUtil.split(childsample, ";").length));
            props.setProperty("parentsampleid", parentsample);
            props.setProperty("childsampleid", childsample);
            //props.setProperty("culturetypeid", resultculturetype);
            props.setProperty("culturetypeid", culturetype);
            props.setProperty("amountinoculated", amountinoculated);
            if (!Util.isNull(orgculturetype) && !Util.isNull(parentsampleculturemapid)) {
                props.setProperty("orgculturetype", orgculturetype);
                props.setProperty("parentsampleculturemapid", parentsampleculturemapid);
                props.setProperty("operation", "Duplicate");
            }

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                CULTUREMAPID_FOR_LABEL = props.getProperty(AddSDI.RETURN_NEWKEYID1,"");
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Something went wrong. Please contact to administrator");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
//            copyparentsampletestcode(parentsample, childsample, getQueryProcessor(), getActionProcessor());
            Util.copyTestCodeFromParent(childsample, getQueryProcessor(), getActionProcessor(), "Cytogenetics");
        }
    }

    /**
     * This method copyparentsampletestcode, to copy the LV test code id from the parent sample to child sample.
     * Here we are not using the OOB action to copy the lvtestcode.
     *
     * @param parentsample
     * @param childsample
     * @param externalProps
     * @throws SapphireException
     */
    public void copyparentsampletestcode(String parentsample, String childsample, Object... externalProps) throws SapphireException {
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent Sample not found for copyparentsampletestcode method");
        }
        if (Util.isNull(childsample)) {
            throw new SapphireException("Child Samples not found for copyparentsampletestcode method");
        }

        QueryProcessor qp = null;
        ActionProcessor ap = null;
        if (externalProps.length > 0 && externalProps.length > 2) {
            throw new SapphireException("Error: Too many aguments received in copyparentsampletestcode");
        } else if (externalProps.length == 2) {
            try {
                qp = (QueryProcessor) externalProps[0];
                ap = (ActionProcessor) externalProps[1];
            } catch (Exception e) {
                throw new SapphireException("Error: Illeagal argement data type found in.\n" + e.getMessage());
            }
        }
        String sql = Util.parseMessage(CytoSqls.TESTCODE_FOR_CHILDSAMPLE_SQL, StringUtil.replaceAll(childsample, ";", "','"));
        DataSet dsTestCode = null;
        if (qp == null)
            dsTestCode = getQueryProcessor().getSqlDataSet(sql);
        else
            dsTestCode = qp.getSqlDataSet(sql);
        if (dsTestCode == null)
            throw new SapphireException("Error: Unable to perform query in datatbase");

        if


                (dsTestCode.size() > 0) {
            // String lvtestcodes = dsTestCode.getColumnValues("lvtestcodeid", ";");
            PropertyList props = new PropertyList();
            props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsTestCode.getColumnValues("destsampleid", ";"));
            props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsTestCode.getColumnValues("lvtestcodeid", ";"));
            props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
            try {
                if (ap == null)
//                    getActionProcessor().processAction("AddTestCode", "1", props);
                    getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
                else
//                    ap.processAction("AddTestCode", "1", props);
                    ap.processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
            } catch (SapphireException e) {
                /*String errMsg = getTranslationProcessor().translate("Something went wrong. Please contact to administrator");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);*/
                throw new SapphireException("Something went wrong. Please contact to administrator: " + e.getMessage());
            }
        }
    }

    /**
     * This method updateTrackitem, to calculate the remine volume of parent sample.
     * value will be deducted after creating a each child sample with the perticular inoculated amount.
     * Here we are not using the OOB action editTrackitem to calculate the proper amount.
     *
     * @param parentsample
     * @param culturetype
     * @throws SapphireException
     */
    public void updateTrackitem(String parentsample, String culturetype) throws SapphireException {
        if (Util.isNull(parentsample)) {
            throw new SapphireException("Parent sample not found");
        }
        if (Util.isNull(culturetype)) {
            throw new SapphireException("Culture type not found");
        }
        String sql = Util.parseMessage(CytoSqls.CURRENT_QTY, StringUtil.replaceAll(parentsample, ";", "','"));
        DataSet dssql = getQueryProcessor().getSqlDataSet(sql);

        String inoculatedsql = Util.parseMessage(CytoSqls.SUM_AMOUNTI_NOCULATED, StringUtil.replaceAll(parentsample, ";", "','"));
        DataSet amount = getQueryProcessor().getSqlDataSet(inoculatedsql);

        String sqlorgsample = Util.parseMessage(CytoSqls.GET_ORG_SAMPLID, StringUtil.replaceAll(parentsample, ";", "','"));
        DataSet orgsample = getQueryProcessor().getSqlDataSet(sqlorgsample);

        String parentvol = dssql.getValue(0, "u_initialamount", "0");
        if (Util.isNull(parentvol)) {
            throw new SapphireException("Provide values for Volumn Received.");
        }
        String childunit = dssql.getColumnValues("u_initialvolunit", ";");
        if (Util.isNull(childunit)) {
            throw new SapphireException("Provide values for Volumn unit.");
        }
        String amountinoculated = amount.getValue(0, "amount", "0");
        if (Util.isNull(amountinoculated)) {
            throw new SapphireException("Culture amountinoculated not found");
        }
        String orgsampleid = orgsample.getValue(0, "orgsampleid");
        if (Util.isNull(orgsampleid)) {
            throw new SapphireException("Original sampleid id not found.");
        }
        try {
            Double remainvolume = Double.parseDouble(parentvol) - Double.parseDouble(amountinoculated);
            if (remainvolume >= 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, parentsample + ";" + orgsampleid);
                props.setProperty("qtycurrent", Double.toString(remainvolume));
                props.setProperty("qtyunits", childunit);

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } else if (remainvolume < 0) {
                String err = getTranslationProcessor().translate("Insufficient value.");
                err += "\nError Detail:" + remainvolume;
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
            }
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Can not create child samples due to insufficient volume of parent samples");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * @param parentSampleId
     * @return
     * @throws SapphireException
     * @desc creating Incident Request.
     */
    public String createIncidentRequest(String parentSampleId) throws SapphireException {
        String rid = "";
        try {
            String sql = Util.parseMessage(CytoSqls.VERIFY_DEPARTMENT, parentSampleId);
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            if (ds != null && ds.size() > 0) {
                String currdepartment = ds.getValue(0, "custodialdepartmentid", "");
                if (!currdepartment.toLowerCase(Locale.ENGLISH).endsWith("-cyto") && !"Y".equalsIgnoreCase(ds.getValue(0, "u_iscytoincidentcreated", ""))) {
                    PropertyList recordProp = new PropertyList();
                    recordProp.setProperty("sourcesdcid", "Sample");
                    recordProp.setProperty("sourcekeyid1", ds.getValue(0, "linkkeyid1", ""));
                    recordProp.setProperty("incidentcategory", "UnPlanned");
                    recordProp.setProperty("incidentdesc", "New Culture Added");
                    recordProp.setProperty("u_message", "Culture Added, Specimen required for sample id " + ds.getValue(0, "linkkeyid1", "") + " which needs to be sent back from " + ds.getValue(0, "todepartment", "") + " department.");
                    recordProp.setProperty("u_fromdepartment", connectionInfo.getDefaultDepartment());
                    recordProp.setProperty("incidentstatus", "InProgress");
                    recordProp.setProperty("reportedby", connectionInfo.getSysuserId());
                    recordProp.setProperty("departmentid", ds.getValue(0, "todepartment", ""));
                    getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);
                    rid = "New Incident has been created:" + recordProp.getProperty(RecordIncident.RETURN_NEWKEYID1, "");

                    recordProp.clear();
                    recordProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    recordProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getValue(0, "linkkeyid1", ""));
                    recordProp.setProperty("u_iscytoincidentcreated", "Y");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, recordProp);
                    } catch (ActionException ae) {
                        throw new SapphireException("Error: Unable to update cyto incident status while adding culture \n" + ae.getMessage());
                    }
                }
            } else
                Logger.logInfo("Fresh Prep department not found to create new incident request.");

        } catch (ActionException e) {
            throw new SapphireException("Unable to create new incident for Fresh Prep");
        }
        return rid;

    }

    /**
     * @param culturetype
     * @param flaskCount
     * @param parentSampleId
     * @return
     * @throws SapphireException
     * @desc creating flask.
     */
    public String createFlaskCultureName(String culturetype, int flaskCount, String parentSampleId) throws SapphireException {

        int startCnt = 65;
        String sql = Util.parseMessage(CytoSqls.FLASK_COUNT, parentSampleId);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds != null && ds.size() > 0)
            if (ds.getInt(0, "cnt") < 26)
                startCnt = 65 + ds.getInt(0, "cnt");
            else
                throw new SapphireException("Already 26 Flask created for this sample id");

        int endCnt = startCnt + flaskCount;
        for (int i = startCnt; i < endCnt; i++) {
            culturetype = culturetype + ";Flask " + (char) i;
        }
        culturetype = culturetype.substring(1, culturetype.length());
        return culturetype;
    }

    /**
     * @param childsample
     * @param parentsample
     * @param culturetype
     * @throws SapphireException
     * @desc adding flask on detailment.
     */
    public void addFlask(String childsample, String parentsample, String culturetype) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "SampleCultureMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, "" + (StringUtil.split(childsample, ";").length));
        props.setProperty("parentsampleid", parentsample);
        props.setProperty("childsampleid", childsample);
        props.setProperty("culturetypeid", culturetype);
        props.setProperty("isflask", "Y");
        props.setProperty("amountinoculated", "0.5");
        String sql = Util.parseMessage(CytoSqls.DEFAULT_REAGENT_DETAILS, "Setup", connectionInfo.getDefaultDepartment());
        DataSet dsreagent = getQueryProcessor().getSqlDataSet(sql);

        //********** modified by aritra.banerjee**************************************
        Set<String> cultrTypes = cultureReagntColmnMap.keySet();
        HashMap hm = new HashMap();

        for (String cltrType : cultrTypes) {
            String colIds = cultureReagntColmnMap.get(cltrType);
            if (!Util.isNull(colIds)) {
                String[] colIdsArr = StringUtil.split(colIds, "-");
                hm.clear();
                hm.put("type", cltrType);
                DataSet dsFilter = dsreagent.getFilteredDataSet(hm);

                if (dsFilter.size() > 0) {
                    props.setProperty(colIdsArr[0], dsFilter.getValue(0, "reagenttypeid"));
                    props.setProperty(colIdsArr[1], dsFilter.getValue(0, "reagentlotid"));
                }

            }
        }
        //********************************************************************
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (SapphireException e) {
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Unable to create Flask for the sample");
        }
//        copyparentsampletestcode(parentsample, childsample);
        Util.copyTestCodeFromParent(childsample, getQueryProcessor(), getActionProcessor(), "Cytogenetics");

        try {
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
            props.setProperty("qtycurrent", "0.5");

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("can not update the inoculated amount in QTYCRRNT column...");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * @param childsample
     * @throws SapphireException
     * @desc updating trackitem for cultures.
     */
    public void updateTrackitemForCultures(String childsample) throws SapphireException {

        String cultureamountinoculated = Util.parseMessage(CytoSqls.AMOUNTINOCULATED_FOR_CHILDSAMPLE, StringUtil.replaceAll(childsample, ";", "','"));
        DataSet cultureinoculated = getQueryProcessor().getSqlDataSet(cultureamountinoculated);

        if (cultureinoculated != null && cultureinoculated.size() > 0) {
            try {
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, cultureinoculated.getColumnValues("childsample", ";"));
                props.setProperty("qtycurrent", cultureinoculated.getColumnValues("amount", ";"));
                props.setProperty("u_currenttramstop", StringUtil.repeat("CytoSetup", cultureinoculated.size(), ";"));

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (SapphireException e) {
                String err = getTranslationProcessor().translate("can not update the inoculated amount in QTYCRRNT column...");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
            }
        } else {
            String err = getTranslationProcessor().translate("Unable to fetch data from query");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * @param ds
     * @param queryProcessor
     * @param actionProcessor
     * @param tramStop
     * @param operationType
     * @param auditreason
     * @throws SapphireException
     * @desc adding sub cultures.
     */
    public void addSubcultures(DataSet ds, QueryProcessor queryProcessor, ActionProcessor actionProcessor, String tramStop, String operationType, String auditreason, String defDept) throws SapphireException {
        if (ds == null || ds.size() == 0)
            throw new SapphireException("Error: ");
        String parentsamples = ds.getColumnValues("parentsampleid", ";");
        String subcultures = ds.getColumnValues("subcultures", ";");

        String sql = Util.parseMessage(CytoSqls.AMOUNTINOCULATED, StringUtil.replaceAll(ds.getColumnValues("querycondition", ";"), ";", "','"));
        DataSet dsamountinoculated = queryProcessor.getSqlDataSet(sql);
        if (dsamountinoculated == null)
            throw new SapphireException("Error: Unable to perform query in database");


        if (dsamountinoculated.size() > 0) {
            HashMap<String, String> hmap = new HashMap<String, String>();
            if (!ds.isValidColumn("amountinoculated"))
                ds.addColumn("amountinoculated", DataSet.STRING);

            for (int i = 0; i < ds.size(); i++) {
                String orgculturetype = ds.getValue(i, "orgculturetype", "");
                if (!Util.isNull(orgculturetype)) {
                    hmap.clear();
                    hmap.put("u_culturetypeid", orgculturetype);
                    DataSet dsamountinoculatedFiltr = dsamountinoculated.getFilteredDataSet(hmap);
                    if (dsamountinoculatedFiltr != null && dsamountinoculatedFiltr.size() > 0)
                        ds.setValue(i, "amountinoculated", dsamountinoculatedFiltr.getValue(0, "amountinoculated", ""));
                }
            }
        }


        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "SampleCultureMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, "" + ds.size());
        props.setProperty("parentsampleid", parentsamples);
        props.setProperty("childsampleid", subcultures);
        props.setProperty("orgculturetype", ds.getColumnValues("querycondition", ";"));
        props.setProperty("culturetypeid", ds.getColumnValues("newculturetypeid", ";"));
        props.setProperty("amountinoculated", ds.getColumnValues("amountinoculated", ";"));
        props.setProperty("isflask", ds.getColumnValues("isflask", ";"));
        props.setProperty("operation", operationType);
        props.setProperty("parentsampleculturemapid", ds.getColumnValues("u_sampleculturemapid", ";"));


        if (!Util.isNull(auditreason)) {
            if ("subculture".equalsIgnoreCase(operationType))
                props.setProperty("subculturereason", StringUtil.repeat(auditreason, ds.size(), ";"));
            if ("redrop".equalsIgnoreCase(operationType))
                props.setProperty("redropreason", StringUtil.repeat(auditreason, ds.size(), ";"));
            if ("reharvest".equalsIgnoreCase(operationType))
                props.setProperty("rehervestreason", StringUtil.repeat(auditreason, ds.size(), ";"));
        }
        try {
            actionProcessor.processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (SapphireException e) {
            throw new SapphireException("Error: Unable to add subcultures.");
        }

        Util.copyTestCodeFromParent(subcultures, queryProcessor, actionProcessor, "Cytogenetics");
    }

}

