package sapphire.custom.ng.action.cyto;

import com.labvantage.opal.validation.misc.ConvertUnits;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class CytoReagentAssociation extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String currentdepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();

        String linksdcid = properties.getProperty("linksdcid", "");
        String tramstop = properties.getProperty("tramstop", "");

        DataSet dsFinal = new DataSet();
        dsFinal.addColumnValues("linkkeyid1", DataSet.STRING, properties.getProperty("linkkeyid1"), ";", "");
        dsFinal.addColumnValues("linksdcid", DataSet.STRING, properties.getProperty("linksdcid"), ";", "");
        dsFinal.addColumnValues("linksampleid", DataSet.STRING, properties.getProperty("linksampleid"), ";", "");
        dsFinal.addColumnValues("reagentlotid", DataSet.STRING, properties.getProperty("reagentlotid"), ";", "");
        dsFinal.addColumnValues("amount", DataSet.STRING, properties.getProperty("amount"), ";", "");
        dsFinal.addColumnValues("unit", DataSet.STRING, properties.getProperty("unit"), ";", "");
        dsFinal.addColumnValues("trackitemamnt", DataSet.STRING, properties.getProperty("trackitemamnt"), ";", "");
        dsFinal.addColumnValues("isexisting", DataSet.STRING, properties.getProperty("isexisting"), ";", "");
        dsFinal.addColumnValues("mappingid", DataSet.STRING, properties.getProperty("mappingid"), ";", "");

        String linksampleids = dsFinal.getColumnValues("linksampleid", ";");

        String sqlStorage = Util.parseMessage(CytoSqls.GET_STORAGEDETAIL_BY_LINKKEYID1, StringUtil.replaceAll(linksampleids, ";", "','"));
        DataSet storageInfo = getQueryProcessor().getSqlDataSet(sqlStorage);

        if (storageInfo == null)
            throw new SapphireException("Unble to fetch storage details from Database.");

        if (storageInfo.size() > 0) {
            takeCustodyofLinkSampleids(storageInfo.getColumnValues("linkkeyid1", ";"), linksdcid, currentuser, currentdepartment);
        }

        HashMap<String, String> hm = new HashMap();
        hm.put("isexisting", "N");
        DataSet dsAdd = dsFinal.getFilteredDataSet(hm);
        hm.clear();
        hm.put("isexisting", "Y");
        DataSet dsEdit = dsFinal.getFilteredDataSet(hm);

        if (dsAdd != null && dsAdd.size() > 0) {

            if (!Util.isNull(dsAdd.getColumnValues("linkkeyid1", ";")) && !Util.isNull(dsAdd.getColumnValues("reagentlotid", ";"))) {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoSampleReagentMap");
                pl.setProperty(AddSDI.PROPERTY_COPIES, "" + dsAdd.size());
                pl.setProperty("linkkeyid1", dsAdd.getColumnValues("linkkeyid1", ";"));
                pl.setProperty("linksdcid", linksdcid);
                pl.setProperty("linksampleid", dsAdd.getColumnValues("linksampleid", ";"));
                pl.setProperty("reagentlotid", dsAdd.getColumnValues("reagentlotid", ";"));
                pl.setProperty("amount", dsAdd.getColumnValues("amount", ";"));
                pl.setProperty("unit", dsAdd.getColumnValues("unit", ";"));
                pl.setProperty("tramstop", tramstop);
                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                } catch (Exception ex) {
                    throw new SapphireException("Error.Unable to Add records. Reason : " + ex.getMessage());
                }
            }
        }

        if (dsEdit != null && dsEdit.size() > 0)

        {
            //need to implement for edit
            dsEdit.addColumn("updatedvolumn", DataSet.STRING);
            String sql = Util.parseMessage(CytoSqls.GET_SAMPLE_REAGENT_MAPPING, dsEdit.getColumnValues("mappingid", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            if (ds == null)
                throw new SapphireException("Unable to connect to database.");
            else if (ds.size() > 0) {
                String existingDBAmount = "";
                String existingUnit = "";
                hm.clear();
                for (int i = 0; i < dsEdit.size(); i++) {
                    hm.put("u_cytosamplereagentmapid", dsEdit.getValue(i, "mappingid"));
                    DataSet dsFilter = ds.getFilteredDataSet(hm);

                    if (dsFilter != null && dsFilter.size() > 0) {
                        existingDBAmount = dsFilter.getValue(0, "amount");
                        existingUnit = dsFilter.getValue(0, "unit");
                        // if db unit and scanned unit is same
                        if (existingUnit.equalsIgnoreCase(dsEdit.getValue(i, "unit"))) {
                            double vol = Double.parseDouble(existingDBAmount) + Double.parseDouble(dsEdit.getValue(i, "amount"));
                            dsEdit.setValue(i, "updatedvolumn", "" + vol);
                        } else {
                            String convrtedAmount = "";
                            if (!Util.isNull(dsEdit.getValue(i, "amount")) && !Util.isNull(existingUnit) && !Util.isNull(dsEdit.getValue(i, "unit"))) {
                                convrtedAmount = ConvertUnits.convertUnits(getQueryProcessor(), dsEdit.getValue(i, "unit"), existingUnit, dsEdit.getValue(i, "amount"));
                                double vol = Double.parseDouble(existingDBAmount) + Double.parseDouble(convrtedAmount);
                                dsEdit.setValue(i, "updatedvolumn", String.valueOf(vol));
                            }
                        }
                    }

                }
                if (!Util.isNull(dsEdit.getColumnValues("mappingid", ";"))) {
                    PropertyList updateProp = new PropertyList();
                    updateProp.setProperty(EditSDI.PROPERTY_SDCID, "CytoSampleReagentMap");
                    updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsEdit.getColumnValues("mappingid", ";"));
                    updateProp.setProperty("amount", dsEdit.getColumnValues("updatedvolumn", ";"));
                    updateProp.setProperty("linksdcid", linksdcid);
                    updateProp.setProperty("tramstop", tramstop);

                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                }
            }
        }

        // Update Trackitem trackitem
        if (!Util.isNull(dsAdd.getColumnValues("reagentlotid", ";")))

        {
            PropertyList props = new PropertyList();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues("reagentlotid", ";"));
            //props.setProperty("qtycurrent", dsFinal.getColumnValues("trackitemamnt", ";"));
            props.setProperty("custodialdepartmentid", currentdepartment);
            props.setProperty("custodialuserid", currentuser);
            props.setProperty("currentstorageunitid", "(null)");
            //props.setProperty("qtyunits", volUnit);

            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Error.Unable to update amount in trackitem. Reason : " + ex.getMessage());
            }
        }

    }

    private void takeCustodyofLinkSampleids(String linksampleids, String linksdcid, String currentuser, String currentdepartment) throws SapphireException {

        if (!Util.isNull(linksampleids)) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, linksampleids);
            pl.setProperty("custodialdepartmentid", currentdepartment);
            pl.setProperty("custodialuserid", currentuser);
            pl.setProperty("currentstorageunitid", "(null)");
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
            } catch (Exception e) {
                throw new SapphireException("unbale to take custody of childsamples. Reason : " + e.getMessage());
            }

        }

        if (!Util.isNull(linksampleids)) {

            try {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, linksdcid);
                pl.setProperty(EditSDI.PROPERTY_KEYID1, linksampleids);
                pl.setProperty("hanabi", "(null)");
                pl.setProperty("thermotron", "(null)");
                pl.setProperty("incubator", "(null)");
                pl.setProperty("oven", "(null)");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            } catch (ActionException e) {
                throw new SapphireException("Error: Caught exception while updating storage in " + linksdcid);
            }
        }

    }
}
