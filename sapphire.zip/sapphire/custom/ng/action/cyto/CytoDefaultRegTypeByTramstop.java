package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CytoDefaultRegTypeByTramstop extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String cytotramstop=properties.getProperty("cytotramstop","");
        String type=properties.getProperty("type","");
        String keyid1=properties.getProperty("keyid1","");
        String isdefault=properties.getProperty("isdefault","");
        String makeDefFlag=properties.getProperty("makedefflag","");

        if(Util.isNull(keyid1))
            throw new SapphireException("Keyid1 cannot be obtained.");
        if(Util.isNull(cytotramstop))
            throw new SapphireException("Tramstop name cannot be obtained");
        if(Util.isNull(type))
            throw new SapphireException("ReagentClass cannot be obtained");
        String keyid1Arr[]=StringUtil.split(keyid1,";");
        if(keyid1Arr!=null && keyid1Arr.length>1)
            throw new SapphireException("Please select only one record.");

        if("Y".equalsIgnoreCase(isdefault) && "Y".equalsIgnoreCase(makeDefFlag))
            throw new SapphireException("The selected reagent is already default for the tramstop "+cytotramstop);

        if("".equalsIgnoreCase(isdefault) && "N".equalsIgnoreCase(makeDefFlag))
            throw new SapphireException("Unable to process : The selected reagent is not marked as default for the tramstop "+cytotramstop);

        makeDefault(keyid1,cytotramstop,type,makeDefFlag);

    }

    private void makeDefault(String keyid1,String cytotramstop,String type,String makeDefFlag) throws SapphireException{
        if(!Util.isNull(keyid1) && !Util.isNull(cytotramstop) && !Util.isNull(type)){
            String sql=Util.parseMessage(CytoSqls.DEFAULT_REAGENTINFO_BY_TRAMSTOP_AND_TYPE,cytotramstop,type);
            DataSet dsDefaultRegInfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsDefaultRegInfo==null)
                throw new SapphireException("The below query cannot be executed.\n"+sql);

            String resultKeyid1="";
            String resultDefaultVal="";

            if(dsDefaultRegInfo.size()>0){
                resultKeyid1=dsDefaultRegInfo.getColumnValues("u_cytoregtramstopmapid",";");
                resultDefaultVal= StringUtil.repeat("(null)",dsDefaultRegInfo.size(),";");
            }
            if(!Util.isNull(resultKeyid1)){
                resultKeyid1+=";"+keyid1;
                resultDefaultVal+=";Y";
            }
            else{
                resultKeyid1=keyid1;
                resultDefaultVal="Y";
            }

            PropertyList pl=new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID,"CytoRegTramStopMap");

            if("Y".equalsIgnoreCase(makeDefFlag)) {
                pl.setProperty(EditSDI.PROPERTY_KEYID1, resultKeyid1);
                pl.setProperty("isdefault", resultDefaultVal);
            }
            else if("N".equalsIgnoreCase(makeDefFlag)) {
                pl.setProperty(EditSDI.PROPERTY_KEYID1,keyid1);
                pl.setProperty("isdefault", "(null)");
            }

            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
        }
    }
}
