package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by dkundu on 12/1/2016.
 */
public class UpdateCytoStatus extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("s_sampleid");
        String origFlag = properties.getProperty("orgsampleid");
        if (Util.isNull(sampleids))
            throw new SapphireException("No samples are found in action property");
        String sql;
        if("Y".equalsIgnoreCase(origFlag))
            sql = Util.parseMessage(CytoSqls.GET_SAMPLES_WITH_ORIG_OR_DUMMYID, "orgsampleid","orgsampleid",StringUtil.replaceAll(sampleids, ";", "','"));
        else
            sql = Util.parseMessage(CytoSqls.GET_CYTO_ORIG_DUMMY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));

        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        if (dsSql == null)
            throw new SapphireException("Error: Unable to perform query to database\nSQL:" + sql);
        else if (dsSql.size() == 0)
            throw new SapphireException("Error: No parent/child sample found.\nQuery returned zero rows SQL:" + sql);
        else {
            PropertyList props = new PropertyList();
            if(Util.isNull(dsSql.getValue(0,"u_cytorecvdt"))) {

                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsSql.getColumnValues("orgsampleid", ";") + ";" + dsSql.getColumnValues("cytodummysampleid", ";"));
                props.setProperty("u_cytostatus", "In Setup");
                props.setProperty("bypassorgsampleedit", "Y");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to update cyto status in Sample SDC\n" + ae.getMessage());
                }
            }

            String defaultDept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
            String curntUserid = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();

            if(Util.isNull(defaultDept))
                throw new SapphireException("Default department for the current user cannot be obtained.");

            if(Util.isNull(curntUserid))
                throw new SapphireException("Current user id cannot be obtained.");

            String orgSamplesForCustody="";
            String orgSamplesForRcvDt="";
            sql = Util.parseMessage(CytoSqls.GET_ORG_SAMPLE_DETAILS, StringUtil.replaceAll(sampleids, ";", "','"));

            DataSet dsOrgSmplDetl = getQueryProcessor().getSqlDataSet(sql);
            if (dsOrgSmplDetl == null)
                throw new SapphireException("Error: Unable to perform query to database\nSQL:" + sql);
            else if (dsOrgSmplDetl.size() == 0)
                throw new SapphireException("Error: No parent/child sample info found.\nQuery returned zero rows SQL:" + sql);
            else {
                for(int i=0;i<dsOrgSmplDetl.size();i++){
                    String tempOrgSampleId = dsOrgSmplDetl.getValue(i,"orgsmpl","");
                    String tempDmySampleId = dsOrgSmplDetl.getValue(i,"dummy","");
                    String custDept = dsOrgSmplDetl.getValue(i,"custodialdepartmentid","");
                    String custUserid = dsOrgSmplDetl.getValue(i,"custodialuserid","");

                    if(!Util.isNull(tempOrgSampleId)){

                        if( Util.isNull(custUserid) && (defaultDept.equalsIgnoreCase(custDept)) ){
                            orgSamplesForRcvDt+= ";" + tempOrgSampleId + ";" + tempDmySampleId;
                        }
                        if( !curntUserid.equalsIgnoreCase(custUserid) && (defaultDept.equalsIgnoreCase(custDept)) ){
                            orgSamplesForCustody+= ";" + tempOrgSampleId + ";" + tempDmySampleId;
                        }

                    }
                }
            }
            if(orgSamplesForCustody.startsWith(";"))
                orgSamplesForCustody = orgSamplesForCustody.substring(1);

            if(orgSamplesForRcvDt.startsWith(";"))
                orgSamplesForRcvDt = orgSamplesForRcvDt.substring(1);

            if(!Util.isNull(orgSamplesForCustody)){
                props.clear();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, orgSamplesForCustody);
                props.setProperty("custodialuserid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
                props.setProperty("custodialdepartmentid",defaultDept );
                props.setProperty("custodytakendt", properties.getProperty("custodytakendt"));
                try {
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to update Trackitem\n" + ae.getMessage());
                }
            }

            if(!Util.isNull(orgSamplesForRcvDt)){
                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, orgSamplesForRcvDt);
                props.setProperty("u_cytorecvdt", "n");
                props.setProperty("u_cytorecvdby", curntUserid);

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to update Receive Date\n" + ae.getMessage());
                }
            }


            /*for(int i=0;i<dsSql.size();i++){
                String tempOrgSampleId = dsSql.getValue(i,"orgsampleid","");
                if(!Util.isNull(tempOrgSampleId)){
                    String tempOrgCustDept = dsSql.getValue(i,"orgcustdept","");
                    if(defaultDept.equalsIgnoreCase(tempOrgCustDept))
                        orgResultatSamples+=";"+tempOrgSampleId;
                }
            }


            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            if(!Util.isNull(orgResultatSamples)) {
                if(orgResultatSamples.startsWith(";"))
                    orgResultatSamples=orgResultatSamples.substring(1);
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, orgResultatSamples + ";" + dsSql.getColumnValues("cytodummysampleid", ";"));
            }
            else
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSql.getColumnValues("cytodummysampleid", ";"));
            props.setProperty("custodialuserid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
            props.setProperty("custodialdepartmentid",defaultDept );
            props.setProperty("custodytakendt", properties.getProperty("custodytakendt"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);


                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, orgResultatSamples + ";" + dsSql.getColumnValues("cytodummysampleid", ";"));
                props.setProperty("receiveddt", "n");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            } catch (ActionException ae) {
                throw new SapphireException("Error: Unable to update Trackitem\n" + ae.getMessage());
            }*/

        }
    }
}
