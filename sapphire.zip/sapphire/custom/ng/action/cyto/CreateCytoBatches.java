package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.M18NUtil;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by dkundu on 12/20/2016.
 */
public class CreateCytoBatches extends BaseAction {

    /**
     * This method reads from Labvantage policy to find out details about Feed and Harvest Batching that need to be
     * created
     *
     * @param properties
     * @throws SapphireException
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        // This value of sqlForONC will not be blank when this action is called from SampleCultureMap while releasing a ONC culture. method name : crtBatchForONC().
        // When called from scheduler, the value will be blank.
        String sqlForONC = properties.getProperty("sqlforonc", "");
        DataSet pendingCultrFlskDs = prepareDS(sqlForONC);
        createBatch(pendingCultrFlskDs);
        editSampleCultureMapInfo(pendingCultrFlskDs);
        editSampleInfo(pendingCultrFlskDs);
    }

    /**
     * This is a generic method which is invoked for both Feed ands Harvest batch creation
     *
     * @throws SapphireException
     */
    private DataSet prepareDS(String sqlForONC) throws SapphireException {

        DataSet pendingCultrFlskDs = null;
        String sql = "";

        if (Util.isNull(sqlForONC)) {
            sql = CytoSqls.GET_CULTURES_WITHOUT_BATCH;
        } else {
            sql = sqlForONC;
        }
        pendingCultrFlskDs = getQueryProcessor().getSqlDataSet(sql);

        if (pendingCultrFlskDs == null)
            throw new SapphireException("The below query cannot be executed.\n" + sql);

        String disputedCulters = "";

        if (pendingCultrFlskDs.size() > 0) {
            pendingCultrFlskDs.addColumn("completetimelowerlmit", DataSet.STRING);
            pendingCultrFlskDs.addColumn("completetimeupperlimit", DataSet.STRING);
            pendingCultrFlskDs.addColumn("batchclass", DataSet.STRING);
            pendingCultrFlskDs.addColumn("availableat", DataSet.STRING);
            pendingCultrFlskDs.addColumn("batchtype", DataSet.STRING);
            pendingCultrFlskDs.addColumn("availableto", DataSet.STRING);
            pendingCultrFlskDs.addColumn("nextstatus", DataSet.STRING);
            pendingCultrFlskDs.addColumn("isdisputed", DataSet.STRING);
            pendingCultrFlskDs.addColumn("isflask", DataSet.STRING);
            pendingCultrFlskDs.addColumn("isculture", DataSet.STRING);
            pendingCultrFlskDs.addColumn("enablerouting", DataSet.STRING);

            String batchMasterData = parseMessage(CytoSqls.GET_BATCH_CREATION_DATA);
            DataSet dsBatchRouting = getQueryProcessor().getSqlDataSet(batchMasterData);
            if (dsBatchRouting == null)
                throw new SapphireException("Error: Unable to perform query in Database. Reason below quesy cannot be executed.\n" + batchMasterData);
            if (dsBatchRouting.size() == 0) {
                throw new SapphireException("No Cyto Batch routing logic has been defined in the system.");
            }
            HashMap<String, String> hmap = new HashMap<>();
            Calendar systemDate = new M18NUtil().getNowCalendar();
            for (int i = 0; i < pendingCultrFlskDs.size(); i++) {
                String culturetypeid = pendingCultrFlskDs.getValue(i, "culturetypeid", "");
                String orgculturetype = pendingCultrFlskDs.getValue(i, "orgculturetype", "");
                String releasedept = pendingCultrFlskDs.getValue(i, "releasedept", "");
                String lvtestcodeid = pendingCultrFlskDs.getValue(i, "lvtestcodeid", "");
                String sampleinfo = pendingCultrFlskDs.getValue(i, "u_sampleinformation", "");
                String childsampleid = pendingCultrFlskDs.getValue(i, "childsampleid", "");

                boolean isMatched = false;
                DataSet dsBatchRoutingFiltr = null;
                if (!Util.isNull(culturetypeid)) {
                    if (culturetypeid.contains("Flask")) {
                        hmap.clear();
                        hmap.put("isflask", "Y");
                        dsBatchRoutingFiltr = dsBatchRouting.getFilteredDataSet(hmap);
                        pendingCultrFlskDs.setValue(i, "isflask", "Y");
                    } else {
                        hmap.clear();
                        hmap.put("culturetypeid", culturetypeid);
                        dsBatchRoutingFiltr = dsBatchRouting.getFilteredDataSet(hmap);
                        if (dsBatchRoutingFiltr == null || dsBatchRoutingFiltr.size() == 0) {
                            hmap.clear();
                            hmap.put("culturetypeid", orgculturetype);
                            dsBatchRoutingFiltr = dsBatchRouting.getFilteredDataSet(hmap);
                        }
                        pendingCultrFlskDs.setValue(i, "isculture", "Y");
                    }

                    if (dsBatchRoutingFiltr != null && dsBatchRoutingFiltr.size() > 0) {
                        hmap.clear();
                        hmap.put("dept", releasedept);
                        hmap.put("testcode", lvtestcodeid);
                        hmap.put("specimentype", sampleinfo);
                        DataSet tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);

                        if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                            hmap.clear();
                            hmap.put("dept", releasedept);
                            hmap.put("testcode", lvtestcodeid);
                            tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);

                            if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                                hmap.clear();
                                hmap.put("testcode", lvtestcodeid);
                                hmap.put("specimentype", sampleinfo);
                                tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);

                                if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                                    hmap.clear();
                                    hmap.put("dept", releasedept);
                                    hmap.put("specimentype", sampleinfo);
                                    tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);
                                    if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                                        hmap.clear();
                                        hmap.put("dept", releasedept);
                                        tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);

                                        if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                                            hmap.clear();
                                            hmap.put("testcode", lvtestcodeid);
                                            tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);

                                            if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                                                hmap.clear();
                                                hmap.put("specimentype", sampleinfo);
                                                tempFiltrDs = dsBatchRoutingFiltr.getFilteredDataSet(hmap);
                                                if (tempFiltrDs == null || tempFiltrDs.size() == 0) {
                                                    for (int l = 0; l < dsBatchRoutingFiltr.size(); l++) {
                                                        String dept = dsBatchRoutingFiltr.getValue(l, "dept", "");
                                                        String testcode = dsBatchRoutingFiltr.getValue(l, "testcode", "");
                                                        String specimentype = dsBatchRoutingFiltr.getValue(l, "specimentype", "");
                                                        String completetimelowerlmit = dsBatchRoutingFiltr.getValue(l, "completetimelowerlmit", "");
                                                        String completetimeupperlimit = dsBatchRoutingFiltr.getValue(l, "completetimeupperlimit", "");
                                                        String availableat = dsBatchRoutingFiltr.getValue(l, "availableat", "0");
                                                        if (Util.isNull(dept) && Util.isNull(testcode) && Util.isNull(specimentype)) {
                                                            Calendar cultureSetupDate = pendingCultrFlskDs.getCalendar(i, "setupdt");
                                                            String releaselocale = pendingCultrFlskDs.getValue(i, "releaselocale");

                                                            if (cultureSetupDate != null && systemDate != null && !Util.isNull(releaselocale)) {
                                                                Integer interval = daysDifference(cultureSetupDate, systemDate);
                                                                String cultureSetupTime = Util.convertToTimeZoneHrs(cultureSetupDate, releaselocale);
                                                                Integer currentInterval = Integer.parseInt(availableat);
                                                                String[] arrTime = cultureSetupTime.split(":");
                                                                Integer setupTimeInMinute = Integer.parseInt(arrTime[0]) * 60 + Integer.parseInt(arrTime[1]);

                                                                if (Util.isNull(completetimelowerlmit) && Util.isNull(completetimeupperlimit)) {
                                                                    if (currentInterval <= interval) {
                                                                        isMatched = true;
                                                                        pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                                                                        pendingCultrFlskDs.setValue(i, "completetimelowerlmit", completetimelowerlmit);
                                                                        pendingCultrFlskDs.setValue(i, "completetimeupperlimit", completetimeupperlimit);
                                                                        pendingCultrFlskDs.setValue(i, "batchclass", dsBatchRoutingFiltr.getValue(l, "batchclass", ""));
                                                                        pendingCultrFlskDs.setValue(i, "availableat", dsBatchRoutingFiltr.getValue(l, "availableat", ""));
                                                                        pendingCultrFlskDs.setValue(i, "batchtype", dsBatchRoutingFiltr.getValue(l, "batchtype", ""));
                                                                        pendingCultrFlskDs.setValue(i, "availableto", dsBatchRoutingFiltr.getValue(l, "availableto", ""));
                                                                        pendingCultrFlskDs.setValue(i, "nextstatus", dsBatchRoutingFiltr.getValue(l, "nextstatus", ""));
                                                                        break;
                                                                    }
                                                                } else {
                                                                    String[] upperLimit = completetimeupperlimit.split(":");
                                                                    String[] lowerLimit = completetimelowerlmit.split(":");
                                                                    Integer upperLimitInMinutes = Integer.parseInt(upperLimit[0]) * 60 + Integer.parseInt(upperLimit[1]);
                                                                    Integer lowerLimitInMinutes = Integer.parseInt(lowerLimit[0]) * 60 + Integer.parseInt(lowerLimit[1]);

                                                                    if (currentInterval <= interval) {
                                                                        if(lowerLimitInMinutes<upperLimitInMinutes &&
                                                                                setupTimeInMinute >= lowerLimitInMinutes && setupTimeInMinute <= upperLimitInMinutes) {
                                                                            isMatched = true;
                                                                            pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                                                                            pendingCultrFlskDs.setValue(i, "completetimelowerlmit", completetimelowerlmit);
                                                                            pendingCultrFlskDs.setValue(i, "completetimeupperlimit", completetimeupperlimit);
                                                                            pendingCultrFlskDs.setValue(i, "batchclass", dsBatchRoutingFiltr.getValue(l, "batchclass", ""));
                                                                            pendingCultrFlskDs.setValue(i, "availableat", dsBatchRoutingFiltr.getValue(l, "availableat", ""));
                                                                            pendingCultrFlskDs.setValue(i, "batchtype", dsBatchRoutingFiltr.getValue(l, "batchtype", ""));
                                                                            pendingCultrFlskDs.setValue(i, "availableto", dsBatchRoutingFiltr.getValue(l, "availableto", ""));
                                                                            pendingCultrFlskDs.setValue(i, "nextstatus", dsBatchRoutingFiltr.getValue(l, "nextstatus", ""));
                                                                            break;
                                                                        }
                                                                        else if(lowerLimitInMinutes>upperLimitInMinutes){
                                                                            Integer maxIntermediateTimeInMinutes = (23 * 60) + 59;
                                                                            Integer minIntermediateTimeInMinutes = 0;
                                                                            if((setupTimeInMinute >= lowerLimitInMinutes && setupTimeInMinute <= maxIntermediateTimeInMinutes)
                                                                                    || (setupTimeInMinute >= minIntermediateTimeInMinutes && setupTimeInMinute <= upperLimitInMinutes)){
                                                                                isMatched = true;
                                                                                pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                                                                                pendingCultrFlskDs.setValue(i, "completetimelowerlmit", completetimelowerlmit);
                                                                                pendingCultrFlskDs.setValue(i, "completetimeupperlimit", completetimeupperlimit);
                                                                                pendingCultrFlskDs.setValue(i, "batchclass", dsBatchRoutingFiltr.getValue(l, "batchclass", ""));
                                                                                pendingCultrFlskDs.setValue(i, "availableat", dsBatchRoutingFiltr.getValue(l, "availableat", ""));
                                                                                pendingCultrFlskDs.setValue(i, "batchtype", dsBatchRoutingFiltr.getValue(l, "batchtype", ""));
                                                                                pendingCultrFlskDs.setValue(i, "availableto", dsBatchRoutingFiltr.getValue(l, "availableto", ""));
                                                                                pendingCultrFlskDs.setValue(i, "nextstatus", dsBatchRoutingFiltr.getValue(l, "nextstatus", ""));
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                        }

                                                    }
                                                    if (!isMatched) {
                                                        disputedCulters += ";" + culturetypeid;
                                                        pendingCultrFlskDs.setValue(i, "isdisputed", "Y");
                                                    }
                                                } else if (tempFiltrDs.size() > 0)
                                                    isMatched = true;
                                            } else if (tempFiltrDs.size() > 0)
                                                isMatched = true;
                                        } else if (tempFiltrDs.size() > 0)
                                            isMatched = true;
                                    } else if (tempFiltrDs.size() > 0)
                                        isMatched = true;
                                } else if (tempFiltrDs.size() > 0)
                                    isMatched = true;
                            } else if (tempFiltrDs.size() > 0)
                                isMatched = true;
                        } else if (tempFiltrDs.size() > 0)
                            isMatched = true;

                        if (isMatched && tempFiltrDs.size() > 0) {
                            isMatched = false;
                            for (int l = 0; l < tempFiltrDs.size(); l++) {
                                String dept = tempFiltrDs.getValue(l, "dept", "");
                                String testcode = tempFiltrDs.getValue(l, "testcode", "");
                                String specimentype = tempFiltrDs.getValue(l, "specimentype", "");
                                String completetimelowerlmit = tempFiltrDs.getValue(l, "completetimelowerlmit", "");
                                String completetimeupperlimit = tempFiltrDs.getValue(l, "completetimeupperlimit", "");
                                String availableat = tempFiltrDs.getValue(l, "availableat", "0");

                                Calendar cultureSetupDate = pendingCultrFlskDs.getCalendar(i, "setupdt");
                                String releaselocale = pendingCultrFlskDs.getValue(i, "releaselocale");

                                if (cultureSetupDate != null && systemDate != null && !Util.isNull(releaselocale)) {
                                    Integer interval = daysDifference(cultureSetupDate, systemDate);
                                    String cultureSetupTime = Util.convertToTimeZoneHrs(cultureSetupDate, releaselocale);
                                    Integer currentInterval = Integer.parseInt(availableat);
                                    String[] arrTime = cultureSetupTime.split(":");
                                    Integer setupTimeInMinute = Integer.parseInt(arrTime[0]) * 60 + Integer.parseInt(arrTime[1]);

                                    if (Util.isNull(completetimelowerlmit) && Util.isNull(completetimeupperlimit)) {
                                        if (currentInterval <= interval) {
                                            isMatched = true;
                                            pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                                            pendingCultrFlskDs.setValue(i, "completetimelowerlmit", completetimelowerlmit);
                                            pendingCultrFlskDs.setValue(i, "completetimeupperlimit", completetimeupperlimit);
                                            pendingCultrFlskDs.setValue(i, "batchclass", tempFiltrDs.getValue(l, "batchclass", ""));
                                            pendingCultrFlskDs.setValue(i, "availableat", tempFiltrDs.getValue(l, "availableat", ""));
                                            pendingCultrFlskDs.setValue(i, "batchtype", tempFiltrDs.getValue(l, "batchtype", ""));
                                            pendingCultrFlskDs.setValue(i, "availableto", tempFiltrDs.getValue(l, "availableto", ""));
                                            pendingCultrFlskDs.setValue(i, "nextstatus", tempFiltrDs.getValue(l, "nextstatus", ""));
                                            break;
                                        }
                                    } else {
                                        String[] upperLimit = completetimeupperlimit.split(":");
                                        String[] lowerLimit = completetimelowerlmit.split(":");
                                        Integer upperLimitInMinutes = Integer.parseInt(upperLimit[0]) * 60 + Integer.parseInt(upperLimit[1]);
                                        Integer lowerLimitInMinutes = Integer.parseInt(lowerLimit[0]) * 60 + Integer.parseInt(lowerLimit[1]);

                                        if (currentInterval <= interval) {
                                            if(lowerLimitInMinutes<upperLimitInMinutes && setupTimeInMinute >= lowerLimitInMinutes && setupTimeInMinute <= upperLimitInMinutes) {
                                                isMatched = true;
                                                pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                                                pendingCultrFlskDs.setValue(i, "completetimelowerlmit", completetimelowerlmit);
                                                pendingCultrFlskDs.setValue(i, "completetimeupperlimit", completetimeupperlimit);
                                                pendingCultrFlskDs.setValue(i, "batchclass", tempFiltrDs.getValue(l, "batchclass", ""));
                                                pendingCultrFlskDs.setValue(i, "availableat", tempFiltrDs.getValue(l, "availableat", ""));
                                                pendingCultrFlskDs.setValue(i, "batchtype", tempFiltrDs.getValue(l, "batchtype", ""));
                                                pendingCultrFlskDs.setValue(i, "availableto", tempFiltrDs.getValue(l, "availableto", ""));
                                                pendingCultrFlskDs.setValue(i, "nextstatus", tempFiltrDs.getValue(l, "nextstatus", ""));
                                                break;
                                            }
                                            else if(lowerLimitInMinutes>upperLimitInMinutes){
                                                Integer maxIntermediateTimeInMinutes = (23 * 60) + 59;
                                                Integer minIntermediateTimeInMinutes = 0;
                                                if((setupTimeInMinute >= lowerLimitInMinutes && setupTimeInMinute <= maxIntermediateTimeInMinutes)
                                                        || (setupTimeInMinute >= minIntermediateTimeInMinutes && setupTimeInMinute <= upperLimitInMinutes)){
                                                    isMatched = true;
                                                    pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                                                    pendingCultrFlskDs.setValue(i, "completetimelowerlmit", completetimelowerlmit);
                                                    pendingCultrFlskDs.setValue(i, "completetimeupperlimit", completetimeupperlimit);
                                                    pendingCultrFlskDs.setValue(i, "batchclass", tempFiltrDs.getValue(l, "batchclass", ""));
                                                    pendingCultrFlskDs.setValue(i, "availableat", tempFiltrDs.getValue(l, "availableat", ""));
                                                    pendingCultrFlskDs.setValue(i, "batchtype", tempFiltrDs.getValue(l, "batchtype", ""));
                                                    pendingCultrFlskDs.setValue(i, "availableto", tempFiltrDs.getValue(l, "availableto", ""));
                                                    pendingCultrFlskDs.setValue(i, "nextstatus", tempFiltrDs.getValue(l, "nextstatus", ""));
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                            if (!isMatched) {
                                disputedCulters += ";" + culturetypeid;
                                pendingCultrFlskDs.setValue(i, "isdisputed", "Y");
                            }

                        } else if (!isMatched) {
                            disputedCulters += ";" + culturetypeid;
                            pendingCultrFlskDs.setValue(i, "isdisputed", "Y");
                        }
                    } else if (!isMatched) {
                        disputedCulters += ";" + culturetypeid;
                        pendingCultrFlskDs.setValue(i, "isdisputed", "Y");
                    }

                }
            }
            if (!Util.isNull(disputedCulters)) {
                if (disputedCulters.startsWith(";"))
                    disputedCulters = disputedCulters.substring(1);
                logger.info("Batch routing logic is not defined for the below culture(s)\n" + disputedCulters);
            }
        } else {
            logger.info("There is no released cuture/flasks pending to be routed to harvest/feed");
        }
        return pendingCultrFlskDs;
    }

    private void enableCultrRouting(DataSet pendingCultrFlskDs) {
        if (pendingCultrFlskDs != null && pendingCultrFlskDs.size() > 0) {
            pendingCultrFlskDs.addColumn("enablerouting", DataSet.STRING);
            Calendar systemDate = new M18NUtil().getNowCalendar();
            for (int i = 0; i < pendingCultrFlskDs.size(); i++) {
                String isdisputed = pendingCultrFlskDs.getValue(i, "isdisputed", "");
                String childsampleid = pendingCultrFlskDs.getValue(i, "childsampleid", "");
                if (!"Y".equalsIgnoreCase(isdisputed)) {
                    Calendar cultureSetupDate = pendingCultrFlskDs.getCalendar(i, "setupdt");
                    String releaselocale = pendingCultrFlskDs.getValue(i, "releaselocale");
                    String completetimeupperlimit = pendingCultrFlskDs.getValue(i, "completetimeupperlimit");
                    String completetimelowerlmit = pendingCultrFlskDs.getValue(i, "completetimelowerlmit");

                    if (cultureSetupDate != null && systemDate != null && !Util.isNull(releaselocale)) {
                        Integer interval = daysDifference(cultureSetupDate, systemDate);
                        String cultureSetupTime = Util.convertToTimeZoneHrs(cultureSetupDate, releaselocale);
                        Integer currentInterval = Integer.parseInt(pendingCultrFlskDs.getValue(i, "availableat", "1"));
                        String[] arrTime = cultureSetupTime.split(":");
                        Integer setupTimeInMinute = Integer.parseInt(arrTime[0]) * 60 + Integer.parseInt(arrTime[1]);

                        if (Util.isNull(completetimelowerlmit) && Util.isNull(completetimeupperlimit)) {
                            if (currentInterval == interval) {
                                pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                            }
                        } else {
                            String[] upperLimit = completetimeupperlimit.split(":");
                            String[] lowerLimit = completetimelowerlmit.split(":");
                            Integer upperLimitInMinutes = Integer.parseInt(upperLimit[0]) * 60 + Integer.parseInt(upperLimit[1]);
                            Integer lowerLimitInMinutes = Integer.parseInt(lowerLimit[0]) * 60 + Integer.parseInt(lowerLimit[1]);

                            if (currentInterval == interval
                                    && setupTimeInMinute >= lowerLimitInMinutes && setupTimeInMinute <= upperLimitInMinutes) {
                                pendingCultrFlskDs.setValue(i, "enablerouting", "Y");
                            }
                        }
                    }
                }
            }
        }
    }

    private Integer daysDifference(Calendar startDate, Calendar endDate) {
        long end = endDate.getTimeInMillis();
        long start = startDate.getTimeInMillis();
        //System.out.println( (int)Math.ceil((end - start)/(double)(1000*3600*24)) );
        return (endDate.get(Calendar.DAY_OF_YEAR)-startDate.get(Calendar.DAY_OF_YEAR))+1;
    }


    private void createBatch(DataSet pendingCultrFlskDs) throws SapphireException {
        if (pendingCultrFlskDs != null && pendingCultrFlskDs.size() > 0) {
            pendingCultrFlskDs.addColumn("batchid", DataSet.STRING);
            //DataSet result = new DataSet();
            HashMap<String, String> hmap = new HashMap<String, String>();
            hmap.put("enablerouting", "Y");
            DataSet enabledDS = pendingCultrFlskDs.getFilteredDataSet(hmap);
            if (enabledDS != null && enabledDS.size() > 0) {
                hmap.clear();
                hmap.put("isflask", "Y");
                DataSet enabledFlaskDs = enabledDS.getFilteredDataSet(hmap);
                PropertyList inputPl = new PropertyList();
                if (enabledFlaskDs != null && enabledFlaskDs.size() > 0) {
                    enabledFlaskDs.sort("batchtype,availableto,nextstatus,releaselocale");
                    ArrayList<DataSet> enabledFlaskDsArr = enabledFlaskDs.getGroupedDataSets("batchtype,availableto,nextstatus,releaselocale");
                    if (enabledFlaskDsArr != null && enabledFlaskDsArr.size() > 0) {
                        for (int i = 0; i < enabledFlaskDsArr.size(); i++) {
                            DataSet tempDs = enabledFlaskDsArr.get(i);
                            if (tempDs != null && tempDs.size() > 0) {
                                String batchtype = tempDs.getValue(0, "batchtype", "");
                                String releaselocale = tempDs.getValue(0, "releaselocale", "");
                                if (!Util.isNull(batchtype)) {
                                    inputPl.clear();

                                    String cytoBatchId = null;

                                    inputPl.setProperty(AddSDI.PROPERTY_SDCID, "CytoBatch");
                                    inputPl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                                    inputPl.setProperty("type", batchtype);
                                    if (!Util.isNull(releaselocale))
                                        inputPl.setProperty("localeid", releaselocale);
                                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, inputPl);
                                    cytoBatchId = inputPl.getProperty("newkeyid1");

                                    if (!Util.isNull(cytoBatchId)) {
                                        for (int k = 0; k < tempDs.size(); k++) {
                                            tempDs.setValue(k, "batchid", cytoBatchId);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                hmap.clear();
                hmap.put("isculture", "Y");
                DataSet enabledCulture = enabledDS.getFilteredDataSet(hmap);
                if (enabledCulture != null && enabledCulture.size() > 0) {
                    enabledCulture.sort("batchtype,availableto,nextstatus,releaselocale,process,batchclass");
                    ArrayList<DataSet> enabledCultureDsArr = enabledCulture.getGroupedDataSets("batchtype,availableto,nextstatus,releaselocale,process,batchclass");
                    if (enabledCultureDsArr != null && enabledCultureDsArr.size() > 0) {
                        for (int i = 0; i < enabledCultureDsArr.size(); i++) {
                            DataSet tempDs = enabledCultureDsArr.get(i);
                            if (tempDs != null && tempDs.size() > 0) {
                                String batchtype = tempDs.getValue(0, "batchtype", "");
                                if (!Util.isNull(batchtype)) {
                                    inputPl.clear();

                                    inputPl.setProperty(AddSDI.PROPERTY_SDCID, "CytoBatch");
                                    inputPl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                                    inputPl.setProperty("type", batchtype);
                                    inputPl.setProperty("batchclass", tempDs.getValue(0, "batchclass", ""));
                                    inputPl.setProperty("process", tempDs.getValue(0, "process", ""));
                                    inputPl.setProperty("localeid", tempDs.getValue(0, "releaselocale", ""));

                                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, inputPl);

                                    String cytoBatchId = inputPl.getProperty("newkeyid1", "");

                                    if (!Util.isNull(cytoBatchId)) {
                                        for (int k = 0; k < tempDs.size(); k++) {
                                            tempDs.setValue(k, "batchid", cytoBatchId);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void editSampleCultureMapInfo(DataSet pendingCultrFlskDs) throws SapphireException {
        if (pendingCultrFlskDs != null && pendingCultrFlskDs.size() > 0) {
            HashMap<String, String> hmap = new HashMap<String, String>();
            hmap.put("enablerouting", "Y");
            DataSet eligibleDs = pendingCultrFlskDs.getFilteredDataSet(hmap);
            if (eligibleDs != null && eligibleDs.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                props.setProperty(EditSDI.PROPERTY_KEYID1, eligibleDs.getColumnValues("u_sampleculturemapid", ";"));
                props.setProperty("batchid", eligibleDs.getColumnValues("batchid", ";"));
                props.setProperty("frombatching", "Y");
                props.setProperty("movetohrvst", "n");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
        }
    }

    private void editSampleInfo(DataSet pendingCultrFlskDs) throws SapphireException {
        if (pendingCultrFlskDs != null && pendingCultrFlskDs.size() > 0) {
            HashMap<String, String> hmap = new HashMap<String, String>();
            hmap.put("enablerouting", "Y");
            DataSet eligibleDs = pendingCultrFlskDs.getFilteredDataSet(hmap);
            if (eligibleDs != null && eligibleDs.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, eligibleDs.getColumnValues("childsampleid", ";"));
                props.setProperty("u_cytostatus", eligibleDs.getColumnValues("nextstatus", ";"));
                props.setProperty("u_currentmovementstep", eligibleDs.getColumnValues("availableto", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

                props.clear();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, eligibleDs.getColumnValues("trackitemid", ";"));
                props.setProperty("u_currenttramstop", eligibleDs.getColumnValues("availableto", ";"));
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }
        }
    }
}
