package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CytoDefaultRegLot extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String reglotid=properties.getProperty("reagentlotid","");
        String regtypeid=properties.getProperty("reagenttypeid","");
        String isdefault=properties.getProperty("isdefault","");
        String makeDefFlag=properties.getProperty("makedefflag","");
        if(Util.isNull(reglotid))
            throw new SapphireException("Reagentlot Id cannot be obtained");
        if(Util.isNull(regtypeid))
            throw new SapphireException("ReagenttypeId cannot be obtained");

        if("Y".equalsIgnoreCase(isdefault) && "Y".equalsIgnoreCase(makeDefFlag) )
            throw new SapphireException("The selected reagentlotid is already a default lot");

        if("".equalsIgnoreCase(isdefault) && "N".equalsIgnoreCase(makeDefFlag) )
            throw new SapphireException("Unable to process : The selected reagentlot id is not marked as default.");

        makeDefaultRegLot(reglotid,regtypeid,makeDefFlag);
    }

    private void makeDefaultRegLot(String reglotid,String regtypeid, String makeDefFlag) throws SapphireException{
        if(!Util.isNull(reglotid) && !Util.isNull(regtypeid)){
            String sql=Util.parseMessage(CytoSqls.DEFAULT_REGLOT_BY_REGTYPEID, StringUtil.replaceAll(regtypeid,";","','"));
            DataSet dsDefaultRegInfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsDefaultRegInfo==null)
                throw new SapphireException("The below query cannot be executed.\n"+sql);
            String resultReglotid="";
            String resultDefValue="";
            if(dsDefaultRegInfo.size()>0){
                resultReglotid=dsDefaultRegInfo.getColumnValues("reagentlotid",";");
                resultDefValue=StringUtil.repeat("(null)",dsDefaultRegInfo.size(),";");
            }
            if(!Util.isNull(resultReglotid)){
                resultReglotid+=";"+reglotid;
                resultDefValue+=";Y";
            }
            else{
                resultReglotid=reglotid;
                resultDefValue="Y";
            }

            PropertyList pl=new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID,"LV_ReagentLot");
            pl.setProperty(EditSDI.PROPERTY_KEYID1,resultReglotid);
            if("Y".equalsIgnoreCase(makeDefFlag))
                pl.setProperty("u_isdefault",resultDefValue);
            else if("N".equalsIgnoreCase(makeDefFlag))
                pl.setProperty("u_isdefault","(null)");

            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
        }
    }
}
