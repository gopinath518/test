package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.util.DataSet;

/**
 * Created by achakraborty on 5/4/2017.
 */
public class MoveToMetafar extends BaseAction {

    private static final String PARENTSAMPLE_PROP = "parentsampleid";
    private static final String CHILDSAMPLE_PROP = "childsampleid";

    public void processAction(PropertyList properties) throws SapphireException {

        String childsample = properties.getProperty(CHILDSAMPLE_PROP);

        if (!Util.isNull(childsample)) {

            PropertyList props = new PropertyList();
            props.setProperty(AddSDI.PROPERTY_SDCID, "CytoBatch");
            props.setProperty(AddSDI.PROPERTY_COPIES, "1");
            props.setProperty("type", "M");

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Error: Unable to create batch for Metafar");
            }
            String batchid = props.getProperty("newkeyid1");
            if (!Util.isNull(batchid)) {
                updateBatchIdForChildsample(batchid, childsample);
                updateCurrentMovementStepForChildsamples(childsample);
                updateCurrentTramstopForChildsamples(childsample);
                updateOperationDate(childsample);
                autoCustodyTransfer(childsample);
            }
        }
    }

    private void updateOperationDate(String childsampleid)throws SapphireException {

        DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_CYTOSLIDE_ID, StringUtil.replaceAll(childsampleid, ";", "','")));

        if(!Util.isNull(ds.getColumnValues("u_cytoslidesid", ";"))) {

            PropertyList editProp = new PropertyList();
            editProp.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
            editProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_cytoslidesid", ";"));
            editProp.setProperty("bandeddt", "n");

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Unable to edit Metafer Complete date for selected culture(s).");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }

    /**
     * @desc Updating batchid column for cytoslides table.
     * @param batchid
     * @param childsample
     * @throws SapphireException
     */
    public void updateBatchIdForChildsample(String batchid, String childsample) throws SapphireException {

        if (!Util.isNull(batchid)) {
            if (!Util.isNull(childsample)) {

                String sql = Util.parseMessage(CytoSqls.GET_CYTOSLIDE_ID, StringUtil.replaceAll(childsample, ";", "','"));
                DataSet ds = getQueryProcessor().getSqlDataSet(sql);

                if (ds != null && ds.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("U_CYTOSLIDESID", ";"));
                    props.setProperty("batchid", batchid);
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Error: Unable to update batch IDs for selected specimens");
                    }
                }
            }
        }
    }

    /**
     * @desc Updating current movement step in s_sample table for childsamples.
     * @param childsample
     * @throws SapphireException
     */
    public void updateCurrentMovementStepForChildsamples(String childsample) throws SapphireException {

        if (!Util.isNull(childsample)) {

            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
            props.setProperty("u_currentmovementstep", "CytoMetafar");
            props.setProperty("u_cytostatus", "Metafar Scan Pending");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Error: Unable to update Current movment steps for selected Slides " + childsample);
            }
        }
    }

    /**
     * @desc Updating U_CURRENTTRAMSTOP as CytoMetafar in trackitem table for childsamples.
     * @param childsample
     * @throws SapphireException
     */
    public void updateCurrentTramstopForChildsamples(String childsample) throws SapphireException {

        if (!Util.isNull(childsample)) {

            PropertyList props = new PropertyList();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
            props.setProperty("u_currenttramstop", "CytoMetafar");
            props.setProperty("custodialuserid", "(null)");
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Error: Unable to update Current Tramstop for selected slides " + childsample);
            }
        }
    }
    public void autoCustodyTransfer(String  childsampleid) throws SapphireException {
        try {
            PropertyList autoCustodyProp = new PropertyList();
            autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsampleid, ";", true));

            getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
        }catch(SapphireException ex){
            throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
        }
    }
}
