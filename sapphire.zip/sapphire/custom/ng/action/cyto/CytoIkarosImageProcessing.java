package sapphire.custom.ng.action.cyto;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by subhashree.dash on 2/26/2018.
 * The Class is used to monitor Labvantage side Ikros image share Folder and
 * upon dumping new img file from Ikros software a new row will be created in sdiattachment table and
 * parsing the image file and store in u_cytoikarosimages table
 */
public class CytoIkarosImageProcessing extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String fpsampleid = properties.getProperty("freshprepsampleid", "");
        String ikarosimgSharedPath = getIkarosImageShareFolderPath();
        getIkarosimgShareFolder(ikarosimgSharedPath,fpsampleid);

    }
    private String getIkarosImageShareFolderPath() throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "ikrsimg.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    private void getIkarosimgShareFolder(String ikarosimgSharedPath, String freshprepSample) throws SapphireException {

        List<File> listofimagefiles = new ArrayList<>();
        if (!Util.isNull(ikarosimgSharedPath)) {
            Logger.logInfo("Ikaros Iamge Share Folder Path to Monitor::" + ikarosimgSharedPath);

            String processFolderPath = "";
            String fileName="";
            File folder = new File(ikarosimgSharedPath);

            if(!folder.exists()){
                if (folder.mkdirs())
                    Logger.logInfo(folder.getPath() + ":: created successfully");
            }

            File[] listOfFiles = folder.listFiles();

            if(listOfFiles==null || listOfFiles.length==0)
                throw new SapphireException("No image file found in the specified directory");


            if (listOfFiles.length > 0) {
                for (File file : listOfFiles) {
                    try {
                        if (file.isFile()) {
                            Logger.logInfo("Processing Ikaros Image File Name::" + file.getName());
                            fileName=file.getName();
                            if(fileName.contains(freshprepSample))
                            {
                                processFolderPath = moveToFolder(ikarosimgSharedPath, file.getName(),"process",freshprepSample,true);
                                listofimagefiles.add(new File(processFolderPath));

                            }

                        }
                    } catch (Exception e) {
                        Logger.logInfo("Error in Ikaros Image: " + e.toString());
                        throw new SapphireException(e.getMessage());
                    }
                }
                if(!Util.isNull(processFolderPath)) {
                    String processFolderRootPath = new File(processFolderPath).getParent();
                    parseFileName(processFolderRootPath, listofimagefiles, freshprepSample);
                }
            }
        } else {
            logger.error("Ikaros Image shared path is not mentioned in master data. ");
            throw new SapphireException("Ikaros Image Share folder path not set.");
        }

    }

    private void parseFileName(String processFolderRootPath, List<File> imagefilelist,String freshprepSample) throws SapphireException {

        DataSet dsfinallist = new DataSet();
        dsfinallist.addColumn("fpsampleid", DataSet.STRING);
        dsfinallist.addColumn("filename", DataSet.STRING);
        dsfinallist.addColumn("attachmentno", DataSet.STRING);

        try{

            for(File file:imagefilelist){
                String tempFileName = createFileNameForParsing(file.getName());
                String[] tempArr = StringUtil.split(tempFileName, "@*@");
                String sampleId = tempArr[0];
                String getSuccessFolderPath = moveToFolder(processFolderRootPath, file.getName(),"success",freshprepSample,false);
                addattchment(sampleId,getSuccessFolderPath,file);

                int rownum=dsfinallist.addRow();
                dsfinallist.setValue(rownum,"fpsampleid",sampleId);
                dsfinallist.setValue(rownum,"filename",getSuccessFolderPath);
            }
            String allFile = dsfinallist.getColumnValues("filename", "','");
            String sql = Util.parseMessage(CytoSqls.GET_ATTACHMENT_NUM, freshprepSample, allFile);
            DataSet dsSdiAttachement = getQueryProcessor().getSqlDataSet(sql);

            if (dsSdiAttachement != null && dsSdiAttachement.size() > 0) {
                for (int i = 0; i < dsfinallist.size(); i++) {
                    String filename = dsfinallist.getValue(i, "filename");
                    HashMap<String, String> hm = new HashMap();
                    hm.put("filename", filename);

                    DataSet dsfilter = dsSdiAttachement.getFilteredDataSet(hm);
                    if (dsfilter.size() > 0) {
                        String num = dsfilter.getValue(0, "attachmentnum");
                        dsfinallist.setValue(i, "attachmentno", num);
                    }
                }
            }

            if (dsfinallist.size() > 0) {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoIkarosImages");
                pl.setProperty(AddSDI.PROPERTY_COPIES, ""+dsfinallist.size());
                pl.setProperty("fpsampleid", dsfinallist.getColumnValues("fpsampleid",";"));
                pl.setProperty("attachmentno", dsfinallist.getColumnValues("attachmentno",";"));
                pl.setProperty("filename", dsfinallist.getColumnValues("filename",";"));

                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                } catch (Exception e) {
                    throw new SapphireException("Unable to add record in CytoIkrsAnalysisAudt.");
                }
            }

            for(File file : imagefilelist){
                String successFolderPath = moveToFolder(processFolderRootPath, file.getName(),"success",freshprepSample,true);
                Logger.logInfo( file.getName() + ":: file moved to "+successFolderPath+" folder.");
            }

        } catch(Exception e){
            String failureFolderPath = "";
            for(File file : imagefilelist){
                failureFolderPath = moveToFolder(processFolderRootPath, file.getName(),"failure",freshprepSample,true);
                Logger.logInfo( file.getName() + ":: file moved to "+failureFolderPath+" folder.");
            }
            File logFile = new File(new File(failureFolderPath).getPath()+File.separator +freshprepSample+ "_" + "error_log.txt");
            try {
                logFile.createNewFile();
                writeLog(logFile.getPath(), e.getMessage());
            } catch (Exception e1) {
                Logger.logError(("Error occurr_ed during Error file(" + logFile + ") log creation!!!"));
            }
        }

    }
    private String createFileNameForParsing(String fileName) throws SapphireException {

            String tempFileName = "";
            List<String> delimeterList = new ArrayList<String>(); // to store probable delimeter list from Policy
            Map<String,Integer> colIndexMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy
            Map<String,DataSet> colDelimeterMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy

            PropertyList filePolicyProperties = getConfigurationProcessor().getPolicy("CytoMeteferFilePatternPolicy", "IkarosImgFileFormat");
            PropertyList pl = filePolicyProperties.getPropertyList("filepattern");

            PropertyListCollection delimeterColl = pl.getCollection("filepatterncollection");
            PropertyListCollection columnIndexColl = pl.getCollection("ColumnIndex");

            for (int i = 0; i < delimeterColl.size(); i++)
                delimeterList.add(delimeterColl.getPropertyList(i).getProperty("delimeter"));

            for (int i = 0; i < columnIndexColl.size(); i++) {

                PropertyList tempPl=columnIndexColl.getPropertyList(i);
                if(tempPl!=null && tempPl.size()>0){
                    String column=tempPl.getProperty("column");
                    String index=tempPl.getProperty("index");
                    if(!Util.isNull(index))
                        colIndexMap.put(column,Integer.parseInt(index));
                    PropertyListCollection subDelimetrsPlc=tempPl.getCollection("subdelimeter");
                    if(subDelimetrsPlc!=null && subDelimetrsPlc.size()>0){
                        DataSet subDelimeterDs = new DataSet();
                        subDelimeterDs.addColumn("subdelimeterlist", DataSet.STRING);
                        for(int j=0;j<subDelimetrsPlc.size();j++){
                            PropertyList tempSubDelList=subDelimetrsPlc.getPropertyList(j);
                            if(tempSubDelList!=null && tempSubDelList.size()>0){
                                String tempDel=tempSubDelList.getProperty("subdelimeterid","");
                                if(!Util.isNull(tempDel)){
                                    int rowIndx=subDelimeterDs.addRow();
                                    subDelimeterDs.setValue(rowIndx,"subdelimeterlist",tempDel);
                                }
                            }
                        }
                        if(subDelimeterDs!=null && subDelimeterDs.size()>0)
                            colDelimeterMap.put(column,subDelimeterDs);
                    }
                }
            }

            try {
                tempFileName = fileName.substring(0, (fileName.lastIndexOf(".")));
            } catch (Exception se){
                throw new SapphireException("No Proper extension found for the scanned file.\n"+fileName);
            }

            for(String s:delimeterList){
                if(tempFileName.contains(s)) {
                    tempFileName=StringUtil.replaceAll(tempFileName,s,"@*@");
                }
            }

            if(!tempFileName.contains("@*@"))
                throw new SapphireException("No Proper delimeter defined in the policy for the scanned file.\n"+fileName);

            String[] tempArr = StringUtil.split(tempFileName, "@*@");

            String fsampleId = "";
            String cltrId = "";
            String slideid = "";
            String slideno = "";
            String imgno = "";
            //CYG17-000006;Doe, John;120IL4;1 of 3~A.0001.MMI

            Set<String> set = colIndexMap.keySet();
            Set<String> subDelimeterSet = colDelimeterMap.keySet();

            for (String str : set) {
                if ("freshprepid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    fsampleId = tempArr[index];
                } else if ("cultureid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    cltrId = tempArr[index];
                } else if ("slideid".equalsIgnoreCase(str)) {
                    int index = colIndexMap.get(str);
                    String slideSeq = tempArr[index]; //1 of 3
                    DataSet dsDlimtr = null;
                    try {
                        for (String str1 : subDelimeterSet) {
                            if ("slideid".equalsIgnoreCase(str1)) {
                                dsDlimtr = colDelimeterMap.get(str1);
                            }
                            String delimtrList = dsDlimtr.getColumnValues("subdelimeterlist", ";");
                            String[] delimtrListArr = StringUtil.split(delimtrList, ";", true);
                            for (String s : delimtrListArr) {
                                if (slideSeq.contains(s)) {
                                    slideSeq = StringUtil.replaceAll(slideSeq, s.trim(), "#*#");
                                }
                            }
                            String[] slideSeqArr = StringUtil.split(slideSeq, "#*#");

                            slideno = slideSeqArr[0];
                            imgno = slideSeqArr[3].trim();
                        }
                    } catch (Exception e) {
                        throw new SapphireException(e);
                    }
                }
            }
            if(!Util.isNull(cltrId) && !Util.isNull(slideid))
                slideid = cltrId.trim() + "-" + slideno.trim();
            return (fsampleId.trim() + "@*@" + slideid + "@*@" + imgno);
        }


    private void addattchment(String sampleId,String fullfileName, File file) throws SapphireException {
        PropertyList attachprop = new PropertyList();
        attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Sample");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, sampleId);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, fullfileName);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, file.getName());
        attachprop.setProperty("u_attachmenttype", "CytoIkarosImage");


        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + sampleId + "s_sample"+ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

    private void addIkaroImage(String sampleId,String slideno,String imgno,String filename) throws SapphireException {
        if(!Util.isNull(sampleId)) {
            String sql = Util.parseMessage(CytoSqls.GET_LATEST_ATTACHMENT_NUM, StringUtil.replaceAll(sampleId, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            //String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();

            PropertyList pl = new PropertyList();
            pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoIkarosImages");
            pl.setProperty("fpsampleid", sampleId);
            pl.setProperty("slideid", slideno);
            pl.setProperty("attachmentno", ds.getColumnValues("attachmentno", ";"));
            pl.setProperty("imageno", imgno);
            pl.setProperty("filename", filename);
            pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(ds.size()));
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + sampleId + "s_sample" + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
        }
    }

    private String moveToFolder(String path, String fileName,String operation, String freshprepSample, boolean createFile) throws SapphireException{

        String networkPath = "";
        String queryInput = "";

        if("success".equalsIgnoreCase(operation))
            queryInput = "ikrsimg.success";
        else if("failure".equalsIgnoreCase(operation))
            queryInput= "ikrsimg.failure";
        else if("process".equalsIgnoreCase(operation)){

            File file = new File(path + fileName);
            //File file = new File(path +"process"+File.separator+ fileName);
            File dir = new File(path +File.separator+operation);
            if (!dir.exists())
                if (dir.mkdirs())
                    Logger.logInfo(dir.getPath() + ":: created successfully");

            if (file.isFile() && dir.exists()) {
                if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                    Logger.logInfo(file.getName() + ":: File Moved to "+operation+" folder");

                if (file.delete())
                    Logger.logInfo(file.getName() + "::File delete from "+path+" folder");
                else
                    Logger.logInfo("Unable to delete::" + file.getName() + ":: file from "+path+" folder");

            }
            String retString = dir.getPath()+File.separator+file.getName();
            return retString;
        }

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, queryInput);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            networkPath = ds.getValue(0, "propvalue");

        DataSet inputList = new DataSet();
        inputList.addColumn("sponsorid",DataSet.STRING);
        inputList.addColumn("projectid",DataSet.STRING);

        String projectprotocolid = "";
        String sponsorname = "";

        sql = Util.parseMessage(CytoSqls.GET_SPONSOR_PROJECTNAME_BY_SPECIMENID, freshprepSample);
        DataSet dsSponDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponDetails != null && dsSponDetails.size() > 0) {
            sponsorname = dsSponDetails.getValue(0, "sponsorname");
            projectprotocolid = dsSponDetails.getValue(0, "projectprotocolid");
        }

        int rowId = inputList.addRow();
        inputList.setValue(rowId,"sponsorid",sponsorname);
        inputList.setValue(rowId,"projectid",projectprotocolid);
        String finalPath = Util.generateLocationPath(networkPath, inputList);
        //String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        File file = new File(path + File.separator+fileName);
        //File dir = new File(path + File.separator+operation+File.separator + folderDt + File.separator);
        File dir = new File(finalPath);
        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if(createFile){
            if (file.isFile() && dir.exists()) {
                if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                    Logger.logInfo(file.getName() + ":: File Moved to "+operation+" folder");

                if (file.delete())
                    Logger.logInfo(file.getName() + "::File delete from "+path+" folder");
                else
                    Logger.logInfo("Unable to delete::" + file.getName() + ":: file from "+path+" folder");
                //return dir.getPath()+File.separator+file.getName();
            }
        }
        String retString = dir.getPath()+File.separator+file.getName();
        return retString;
    }

    private void writeLog(String logFileName, String msg) {
        BufferedWriter bw = null;
        FileWriter fw = null;
        try {
            fw = new FileWriter(logFileName);
            bw = new BufferedWriter(fw);
            bw.write(msg);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (IOException ex) {

            }
        }
    }




}




