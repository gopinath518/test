package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by subhashree.dash on 2/24/2018.
 */
public class CytoDeptMovement extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleId = properties.getProperty("sampleid", "");
        String dummysample = properties.getProperty("dummysample", "");
        String from = properties.getProperty("from", "");
        if (Util.isNull(sampleId)) {
            throw new SapphireException(" Please Select Sample.");

        }
        String dept = properties.getProperty("dept");
        if (Util.isNull(dept)) {
            throw new SapphireException("Please Select Department");

        }
        String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TAKE_CUSTODY, from,StringUtil.replaceAll(dummysample, ";", "','"));

        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        if (dsSql == null)
            throw new SapphireException("Error: Unable to perform query to database\nSQL:" + sql);
        else if (dsSql.size() == 0)
            throw new SapphireException("Error: child sample not found.\nQuery returned zero rows SQL:" + sql);
        else {
            PropertyList props = new PropertyList();

            String childid = dsSql.getColumnValues("childsampleid", ";");
            if (!Util.isNull(childid)) {
                props.clear();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, childid);
                props.setProperty("custodialuserid", "");
                props.setProperty("custodialdepartmentid", dept);
                //props.setProperty("custodytakendt", properties.getProperty("custodytakendt"));
                try {
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to update Trackitem\n" + ae.getMessage());
                }
            }
        }
    }
}