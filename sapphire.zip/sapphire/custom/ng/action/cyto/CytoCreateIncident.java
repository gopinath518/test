package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.xml.PropertyList;

public class CytoCreateIncident extends BaseAction {
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String mode = properties.getProperty("mode");
		if(mode != null && "Add".equals(mode) ){
			getActionProcessor().processAction("RecordIncident", "1", properties);
		}else if(mode != null && "Edit".equals(mode) ){
			properties.setProperty(EditSDI.PROPERTY_SDCID, "LV_Incdt");
			properties.setProperty(EditSDI.PROPERTY_KEYID1, properties.getProperty("requestid"));
			getActionProcessor().processAction("EditSDI", "1", properties);
			properties.setProperty("newkeyid1", properties.getProperty("requestid"));
		}
	}

}
