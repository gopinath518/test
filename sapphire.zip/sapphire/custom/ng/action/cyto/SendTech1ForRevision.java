package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 5/24/2017.
 */
public class SendTech1ForRevision extends BaseAction {
    private static final String KEYID1_PROP = "keyid1";

    public void processAction(PropertyList properties) throws SapphireException{

        String sampleid = properties.getProperty(KEYID1_PROP);
        String freshprepsampleid = properties.getProperty("freshprepsampleid");
        String auditreason = properties.getProperty("auditreason");
        String fromTramstop="Tech2";
        String toTramStop="Tech1";
        if(!Util.isNull(sampleid)){
            String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TECH2, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            if(ds!=null && ds.size() > 0){

                String childsample = ds.getColumnValues("childsampleid", ";");
                if(!Util.isNull(childsample)){

                    PropertyList props = new PropertyList();

                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
                    props.setProperty("u_currentmovementstep", "CytoTech1");
                    props.setProperty("u_cytostatus", "1st Analysis Pending");
                    try{
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    }catch (Exception e) {
                        throw new SapphireException("Error: Unable to update the Movement Step for select specimens");
                    }
                    updateTrackitemForSamples(childsample);
                    insertReviewAudit(freshprepsampleid,auditreason,fromTramstop,toTramStop);
                    
                    properties.setProperty("msg", "Selected Specimen(s) "+Util.getUniqueList(properties.getProperty("freshprepsampleid", ""), ";", true)+" have been moved to Tech 1 Analysis for Revision" );
                }
            }
        }
    }

    public void updateTrackitemForSamples(String childsample) throws SapphireException{

        if(!Util.isNull(childsample)){

//            PropertyList props = new PropertyList();
//            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
//            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
//            props.setProperty("u_currenttramstop", "CytoTech1");
//            //props.setProperty("custodialuserid", "(null)");
//            try{
//                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
//            }catch(Exception e){
//                throw new SapphireException("Error: Unable to update Current Tramstop for the selected sample");
//            }

            try {
                /*PropertyList autoCustodyProp = new PropertyList();
                childsample = Util.getUniqueList(childsample, ";", true);
                autoCustodyProp.setProperty("sampleid", childsample);
                autoCustodyProp.setProperty("tramstop", StringUtil.repeat("CytoTech1", childsample.split(";").length,";"));

                getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);*/

                PropertyList pl=new PropertyList();
                pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID,"Sample");
                pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1,childsample);
                pl.setProperty("custodialdepartmentid",connectionInfo.getDefaultDepartment());
                pl.setProperty("custodialuserid","(null)");
                pl.setProperty("currentstorageunitid","(null)");
                pl.setProperty("u_currenttramstop", "CytoTech1");

                getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID,pl);

            }catch(SapphireException ex){
                throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
            }
        }
    }

    private void insertReviewAudit(String sampleid,String reason,String fromTramstop,String toTramstop) throws SapphireException{
        if(!Util.isNull(sampleid) && !Util.isNull(fromTramstop) && !Util.isNull(toTramstop)){
            sampleid=Util.getUniqueList(sampleid,";",true);
            String sampleIdArr[]=StringUtil.split(sampleid,";");
            if(sampleIdArr!=null && sampleIdArr.length>0) {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoCaseRevisionDtl");
                pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(sampleIdArr.length));
                pl.setProperty("totramstop", StringUtil.repeat(toTramstop,sampleIdArr.length,";" ));
                pl.setProperty("fromtramstop", StringUtil.repeat(fromTramstop,sampleIdArr.length,";"));
                pl.setProperty("sendby", StringUtil.repeat(connectionInfo.getSysuserId(),sampleIdArr.length,";"));
                pl.setProperty("senddt", StringUtil.repeat("n",sampleIdArr.length,";"));
                pl.setProperty("reason", StringUtil.repeat(reason,sampleIdArr.length,";"));
                pl.setProperty("sampleid", sampleid);

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            }
        }
    }
}
