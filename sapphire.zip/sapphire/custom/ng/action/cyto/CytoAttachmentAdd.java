package sapphire.custom.ng.action.cyto;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;

/**
 * Created by aritra.banerjee on 6/7/2017.
 * @desc Adds attachment in SDIAttachment from Cyto-Setup
 * Input property :
 * @param1 SDCID
 * @param2 KEYID1
 * @param3 FILENAME
 * @param4 DESCRIPTION
 * @param5 ATTACHMENT TYPE
 * THROWS Sapphire Exception
 */
public class CytoAttachmentAdd extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String sdcid = properties.getProperty("sdcid");
        String keyid1 = properties.getProperty("keyid1");
        String specimenid = properties.getProperty("specimenid");
        String filename = properties.getProperty("filename");
        String description = properties.getProperty("description");
        String u_attachmenttype = properties.getProperty("u_attachmenttype");
        String attachmentLabvantagePath = getLabvantageShareFolderPathOthers();
        DataSet inputList = new DataSet();
        inputList.addColumn("sponsorid",DataSet.STRING);
        inputList.addColumn("projectid",DataSet.STRING);

        String projectprotocolid = "";
        String sponsorname = "";

        String sql = Util.parseMessage(CytoSqls.GET_SPONSOR_PROJECTNAME_BY_SPECIMENID, specimenid);
        DataSet dsSponDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponDetails != null && dsSponDetails.size() > 0) {
            sponsorname = dsSponDetails.getValue(0, "sponsorname");
            projectprotocolid = dsSponDetails.getValue(0, "projectprotocolid");
        }

        int rowId = inputList.addRow();
        inputList.setValue(rowId,"sponsorid",sponsorname);
        inputList.setValue(rowId,"projectid",projectprotocolid);
        //String sourcefilename = filename.substring(filename.lastIndexOf("/")+1);
        String[] fileNameArr = StringUtil.split(filename,";",true);
        if(fileNameArr.length > 0){
            for(String str:fileNameArr){
                String sourcefilename = str.substring(str.lastIndexOf(File.separator)+1);// exel.txt
                //String networkFilePath = attachmentLabvantagePath + sourcefilename; // networkpath/excel.txt
                String networkFilePath = Util.generateLocationPath(attachmentLabvantagePath, inputList)+File.separator+ sourcefilename;


                PropertyList attachprop = new PropertyList();
                attachprop.clear();
                attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, sdcid);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, networkFilePath);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, description);
                attachprop.setProperty("ATTACHMENTCLASS", "SOP");
                attachprop.setProperty("u_attachmenttype", u_attachmenttype);
                attachprop.setProperty("sourcefilename", sourcefilename);

                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
                    moveFileToDest(new File(str), networkFilePath);
                } catch (SapphireException ex) {
                    String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + keyid1 + "Accession"+ex.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                }
            }
        }
    }

    private String getLabvantageShareFolderPathOthers() throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "cyto.other.attchment");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    private void moveFileToDest(File file, String destFileLocation) throws SapphireException {

        /*File dir = new File(destPath);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");*/

        if ( file.isFile() ) {
            if (file.renameTo(new File(destFileLocation)))
                Logger.logInfo(file.getName() + ":: File Moved to Location : "+destFileLocation);

            if (file.delete())
                Logger.logInfo(file.getName() + "::File delete from Source folder");
            else
                Logger.logInfo("Unable to delete::" + file.getName() + ":: file from Source folder");
        }

    }
}
