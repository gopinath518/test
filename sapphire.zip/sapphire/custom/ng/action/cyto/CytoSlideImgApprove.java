package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.custom.ng.util.Util;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.custom.ng.sql.cyto.CytoSqls;

/**
 * Created by aritra.banerjee on 6/20/2017.
 */
public class CytoSlideImgApprove extends BaseAction {

    private static final String SAMPLE_PROPS = "sampleid";
    private static final String FROM_TRAMSTOP_PROPS = "fromtramstop";
    private static final String FRESHPREP_SAMPLEID_PROPS = "freshprepsampleid";

    /**
     * @Desc Updates CytoSlideImgMap with Approval status for the selected samples
     * @throws SapphireException
     */

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty(SAMPLE_PROPS);
        String frmTramstop = properties.getProperty(FROM_TRAMSTOP_PROPS);
        String freshprepsampleid = properties.getProperty(FRESHPREP_SAMPLEID_PROPS);
        String testcode = properties.getProperty("testcode","");
        String addimgflag = properties.getProperty("addimgflag","");
        String keyid1 = properties.getProperty("keyid1","");

        if (!Util.isNull(sampleid) && !Util.isNull(frmTramstop)) {

            String uniqueSampleid = Util.getUniqueList(sampleid, ";", true);
            String approvedBy = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();

            String sql = Util.parseMessage(CytoSqls.GET_SLIDE_IMG_ID, StringUtil.replaceAll(uniqueSampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            if(ds == null) {
                throw new SapphireException("Error: Unable to perform query in database. : " + sql);
            }
            else if (ds.size() == 0) {
                throw new SapphireException("Error: No Record Found in Database for selected sample(s).");
            }
            String cytoSlideImgMapid = ds.getColumnValues("u_cytoslideimgmapid", ";");

            if(!Util.isNull( cytoSlideImgMapid )) {
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlideImgMap");
                props.setProperty(EditSDI.PROPERTY_KEYID1, cytoSlideImgMapid);

                if ("tech1".equalsIgnoreCase(frmTramstop)) {
                    props.setProperty("tech1reviewedby", approvedBy);
                    props.setProperty("tech1reviewdt", "n");
                } else if ("tech2".equalsIgnoreCase(frmTramstop)) {
                    props.setProperty("tech2reviewedby", approvedBy);
                    props.setProperty("tech2reviewdt", "n");
                } else if ("casereview".equalsIgnoreCase(frmTramstop)) {
                    props.setProperty("casereviewreviewedby", approvedBy);
                    props.setProperty("casereviewreviewdt", "n");
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
            /*if(!Util.isNull(keyid1)){
                PropertyList pl = new PropertyList();
                if ("tech1".equalsIgnoreCase(frmTramstop)) {

                    pl.setProperty("keyid1", keyid1);
                    pl.setProperty("freshprepsampleid", freshprepsampleid);

                    getActionProcessor().processAction("Tech1AnalysisComplete", "1", pl,true);
                } else if ("tech2".equalsIgnoreCase(frmTramstop)) {
                    pl.clear();
                    pl.setProperty("keyid1", keyid1);
                    pl.setProperty("freshprepsampleid", freshprepsampleid);
                    pl.setProperty("curmvstp", "CytoTech2");

                    getActionProcessor().processAction("Tech2AnalysisComplete", "1", pl,true);

                }
                else if ("casereview".equalsIgnoreCase(frmTramstop)) {
                    pl.clear();
                    pl.setProperty("keyid1", keyid1);
                    pl.setProperty("freshprepsampleid", freshprepsampleid);
                    pl.setProperty("totramstop", "DirectorSignOut");

                    getActionProcessor().processAction("SampleMovementFromCaseReview", "1", pl,true);

                }
            }else
                throw new SapphireException("Error: Unable to complete "+frmTramstop+" analysis as the case is already approved and moved forward.");*/

        }
        if(!Util.isNull(freshprepsampleid)){
            String outScript="<script>sapphire.page.navigate" +
                    "('rc?command=page&page=ImgDataEntryByQuery&mode=DataEntry&sdcid=Sample&fromtramstop="+frmTramstop+"&queryid=DataEntryForSlideImages&param1="+freshprepsampleid+"&testcode="+testcode+"&addimgflag="+addimgflag+"&dummysample="+keyid1+"')</script>";
            properties.setProperty("outscript",outScript);
        }
    }
}
