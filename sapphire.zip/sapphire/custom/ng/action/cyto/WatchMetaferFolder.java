package sapphire.custom.ng.action.cyto;

import java.io.File;
import java.io.IOException;

/*** 
 * Created By Subhendu - 2nd June 2017
 * The Class will keep an watch on Metafer Share folder and upon generating new file from Metafer instrument the 'MetaferFileProcessing' action will be called.
 * */

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.List;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.ConnectionProcessor;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.EncryptDecrypt;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

public class WatchMetaferFolder extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String metaferSharedPath = getLabvantageShareFolderPathMetafer();
        watchLabvantageShareFolderMetafer(metaferSharedPath);

    }

    private void watchLabvantageShareFolderMetafer(String metaferSharedPath) throws SapphireException {

        if (!Util.isNull(metaferSharedPath)) {
            Logger.logInfo("Metafer Share Folder Path to Monitor::" + metaferSharedPath);

            String fileName = "";
            File folder = new File(metaferSharedPath);
            File[] listOfFiles = folder.listFiles();
            PropertyList pl = new PropertyList();

            if (listOfFiles != null && listOfFiles.length > 0) {
                for (File file : listOfFiles) {
                    try {
                        if (file.isFile()) {
                            Logger.logInfo("Processing Metafer File Name::" + file.getName());
                            fileName = file.getName();
                            String tempFolderPath = moveToProcessFolder(metaferSharedPath, fileName);
                            pl.clear();
                            pl.setProperty("fileName", fileName);
                            pl.setProperty("serverStartFlag", "N");
                            pl.setProperty("metaferPath", metaferSharedPath);
                            pl.setProperty("processFolderPath", tempFolderPath);
                            getActionProcessor().processAction("MetaferFileProcessing", "1", pl);
                        }
                    } catch (Exception e) {
                        Logger.logInfo("Error in Metafer: " + e.toString());
                        getActionProcessor().processAction("WatchMetaferFolder", "1", pl,true);
                        throw new SapphireException(e.getMessage());
                    }
                }
            }
        } else {
            logger.error("Metafer shared path is not mentioned in master data. ");
            throw new SapphireException("Metafer Share folder path not set.");
        }

    }

    private String getLabvantageShareFolderPathMetafer() throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "metafer.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    private String moveToProcessFolder(String path, String fileName) {

        String networkProcessPath = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "cyto.metafer.process");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            networkProcessPath = ds.getValue(0, "propvalue");

        File file = new File(path + fileName);
        //File dir = new File(path + File.separator+"process"+File.separator);
        File dir = new File(networkProcessPath);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if (file.isFile()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                Logger.logInfo(file.getName() + ":: File Moved to Process folder");

            if (file.delete())
                Logger.logInfo(file.getName() + "::File delete from "+path+" folder");
            else
                Logger.logInfo("Unable to delete::" + file.getName() + ":: file from "+path+" folder");
        }

        return dir.getPath()+File.separator;
    }

}
