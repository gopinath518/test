package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

public class CytoCultureRelease extends BaseAction {
	
	 public void processAction(PropertyList properties) throws SapphireException {
		 
		 String freshprepsampleid = properties.getProperty("freshprepsampleid");
		 moveSample(freshprepsampleid);
	 }
	
	 public void moveSample(String freshprepsampleid) throws SapphireException{
		 try {
			 	PropertyList props = new PropertyList();
			 	props.setProperty("s_sampleid",freshprepsampleid);
				getActionProcessor().processAction("MoveSampleToFreshPrep", "1", props);
			} catch (ActionException e) {
				throw new SapphireException("Unable to move the parent sample to Fresh Prep");
			}
	 }

}
