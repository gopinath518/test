package sapphire.custom.ng.action.cyto;

/***
 * Created By Subhendu - 2nd June 2017
 * The Class is used to monitor Metafer share Folder and will update the cyto status field as when new file is created from Metafer instrument
 */


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import static java.nio.file.StandardCopyOption.COPY_ATTRIBUTES;

public class MetaferFileProcessing extends BaseAction {

    private String childSampleId = "";
    private String CASE_ID = "";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String fileName = properties.getProperty("fileName", "");
        String serverStartFlag = properties.getProperty("serverStartFlag", "");
        String path = properties.getProperty("metaferPath", "");
        String processFolderPath = properties.getProperty("processFolderPath", "");

        try {
            if ("Y".equalsIgnoreCase(serverStartFlag))
                processPendingFile(path, processFolderPath);
            else if (!"".equals(fileName) && !"".equals(path))
                parseFileName(fileName, path, processFolderPath);
        } catch (Exception exp) {
            String Errormsg = "MetaferFileProcessing action cannot be executed. Reason: \n" + exp.getMessage();
            moveToFailureFolder(path, fileName, processFolderPath, Errormsg);
            throw new SapphireException(Errormsg);
        }

    }

    private void parseFileName(String fileName, String path, String processFolderPath) throws SapphireException {

//		String [] tempArr = StringUtil.split(StringUtil.split(fileName, ".MSD", true)[0],".",true);

        String tempFileName = createFileNameForParsing(fileName, path, processFolderPath);
        if(Util.isNull(tempFileName))
            return;
        String[] tempArr = StringUtil.split(tempFileName, "@*@");

        String sampleId = tempArr[0];
        CASE_ID = sampleId;
        String slideId = tempArr[1];

        processFile(sampleId, slideId, path, fileName, tempArr);
        moveToSuccessFolder(path, fileName, processFolderPath);

        if (!Util.isNull(childSampleId)) {
            try {
                PropertyList pl = new PropertyList();
                pl.setProperty("childsampleid", childSampleId);
                pl.setProperty("from", "metafer");
                pl.setProperty("deptflag", "schedular");

                getActionProcessor().processAction("MoveToTech1", "1", pl);

            } catch (Exception e) {
                Logger.logInfo("Error in calling MoveToTech1 action: " + e.toString());
                throw new SapphireException(e.getMessage());
            }
        }
    }

    private String createFileNameForParsing(String fileName, String path, String processFolderPath) throws SapphireException {

        String tempFileName = "";
        List<String> delimeterList = new ArrayList<String>(); // to store probable delimeter list from Policy
        List<String> extensionList = new ArrayList<String>(); // to store probable valid extension list from Policy
        Map<String, Integer> colIndexMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy
        Map<String, DataSet> colDelimeterMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy

        PropertyList filePolicyProperties = getConfigurationProcessor().getPolicy("CytoMeteferFilePatternPolicy", "MetaferFileFormat");
        PropertyList pl = filePolicyProperties.getPropertyList("filepattern");

        PropertyListCollection delimeterColl = pl.getCollection("filepatterncollection");
        PropertyListCollection columnIndexColl = pl.getCollection("ColumnIndex");
        PropertyListCollection extensioncoll = pl.getCollection("extensioncoll");

        for (int i = 0; i < delimeterColl.size(); i++)
            delimeterList.add(delimeterColl.getPropertyList(i).getProperty("delimeter"));

        for (int i = 0; i < extensioncoll.size(); i++)
            extensionList.add(extensioncoll.getPropertyList(i).getProperty("extensiontype"));

        for (int i = 0; i < columnIndexColl.size(); i++) {

            PropertyList tempPl = columnIndexColl.getPropertyList(i);
            if (tempPl != null && tempPl.size() > 0) {
                String column = tempPl.getProperty("column");
                String index = tempPl.getProperty("index");
                if (!Util.isNull(index))
                    colIndexMap.put(column, Integer.parseInt(index));
                PropertyListCollection subDelimetrsPlc = tempPl.getCollection("subdelimeter");
                if (subDelimetrsPlc != null && subDelimetrsPlc.size() > 0) {
                    DataSet subDelimeterDs = new DataSet();
                    subDelimeterDs.addColumn("subdelimeterlist", DataSet.STRING);
                    for (int j = 0; j < subDelimetrsPlc.size(); j++) {
                        PropertyList tempSubDelList = subDelimetrsPlc.getPropertyList(j);
                        if (tempSubDelList != null && tempSubDelList.size() > 0) {
                            String tempDel = tempSubDelList.getProperty("subdelimeterid", "");
                            if (!Util.isNull(tempDel)) {
                                int rowIndx = subDelimeterDs.addRow();
                                subDelimeterDs.setValue(rowIndx, "subdelimeterlist", tempDel);
                            }
                        }
                    }
                    if (subDelimeterDs != null && subDelimeterDs.size() > 0)
                        colDelimeterMap.put(column, subDelimeterDs);
                }
            }
        }

        try {
            String tempFileExtensionName = fileName.substring(fileName.lastIndexOf("."));
            if(!Util.isNull(tempFileExtensionName)) {
                if(!extensionList.contains(tempFileExtensionName)){
                    /*moveToSuccessFolder(path, fileName, processFolderPath);
                    return "";*/
                    throw new SapphireException(tempFileExtensionName+" is Not a Valid Extension.");
                }

            } else
                throw new SapphireException("No Extension has been found for the file "+fileName);

            tempFileName = fileName.substring(0, (fileName.lastIndexOf(".")));
        } catch (Exception se) {
            throw new SapphireException("No Proper extension found for the scanned file.\n" + fileName);
        }

        for (String s : delimeterList) {
            if (tempFileName.contains(s)) {
                tempFileName = StringUtil.replaceAll(tempFileName, s.trim(), "@*@");
            }
        }

        if (!tempFileName.contains("@*@"))
            throw new SapphireException("No Proper delimeter defined in the policy for the scanned file.\n" + fileName);

        String[] tempArr = StringUtil.split(tempFileName, "@*@");

        String fsampleId = "";
        String cltrId = "";
        String slideid = "";
        String slideno = "";
        String imgno = "";
        //CYG17-000006;Doe, John;120IL4;1 of 3~A.0001.MMI

        Set<String> set = colIndexMap.keySet();
        Set<String> subDelimeterSet = colDelimeterMap.keySet();

        for (String str : set) {
            if ("freshprepid".equalsIgnoreCase(str)) {
                int index = colIndexMap.get(str);
                fsampleId = tempArr[index];
            } else if ("cultureid".equalsIgnoreCase(str)) {
                int index = colIndexMap.get(str);
                cltrId = tempArr[index];
            } else if ("slideid".equalsIgnoreCase(str)) {
                int index = colIndexMap.get(str);
                String slideSeq = tempArr[index]; //1 of 3
                DataSet dsDlimtr = null;
                try {
                    for (String str1 : subDelimeterSet) {
                        if ("slideid".equalsIgnoreCase(str1)) {
                            dsDlimtr = colDelimeterMap.get(str1);
                        }
                        String delimtrList = dsDlimtr.getColumnValues("subdelimeterlist", ";");
                        String[] delimtrListArr = StringUtil.split(delimtrList, ";", true);
                        for (String s : delimtrListArr) {
                            if (slideSeq.contains(s)) {
                                slideSeq = StringUtil.replaceAll(slideSeq, s.trim(), "#*#");
                            }
                        }
                        String[] slideSeqArr = StringUtil.split(slideSeq, "#*#");

                        slideno = slideSeqArr[0];
                        try {
                            imgno = slideSeqArr[3].trim();
                        } catch (ArrayIndexOutOfBoundsException e) {
                            imgno = "0";
                        }
                    }
                } catch (Exception e) {
                    throw new SapphireException(e);
                }
            }
        }
        slideid = cltrId.trim() + "-" + slideno.trim();
        return (fsampleId.trim() + "@*@" + slideid + "@*@" + imgno);
    }

    private void processFile(String sampleId, String slideId, String path, String fileName, String[] tempArr) throws SapphireException {
        //String status = "10X Completed";
        String status = "63X Completed";
        int imgCount = 0;
        String imgCountStr = "";
        if (tempArr == null || tempArr.length < 3)
            throw new SapphireException("File name obtained is not in proper format.");
        if (Util.isNull(tempArr[2]))
            imgCountStr = "1";
        else
            imgCountStr = tempArr[2];
        try {
            imgCount = Integer.parseInt(imgCountStr);
        } catch (NumberFormatException exp) {
            throw new SapphireException("Invalid image id obtained from the scanned file " + fileName);
        }
        if (imgCount >= 2)
            status = "63X Completed";

        childSampleId = getChildSampleId(sampleId, slideId);

        if (Util.isNull(childSampleId)) {
            throw new SapphireException("ChildSample Id for the slide " + slideId + " corresponding to freshprep sampleid " + sampleId + " is not found");
        }

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, childSampleId);
        pl.setProperty("u_cytostatus", status);

        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (ActionException e) {
            throw new SapphireException("Error during processing file.");
        }
    }

    private String getChildSampleId(String sampleId, String slideId) {

        String sql = Util.parseMessage(CytoSqls.GET_CHILD_SAM_ID_BY_FRESH_ID, sampleId, slideId);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        return ds.getString(0, "childsampleid", "");

    }

    private void moveToSuccessFolder(String path, String fileName, String processFolderPath) throws SapphireException {
        String networkSuccessPath = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "cyto.metafer.success");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            networkSuccessPath = ds.getValue(0, "propvalue");

        DataSet inputList = new DataSet();
        inputList.addColumn("sponsorid",DataSet.STRING);
        inputList.addColumn("projectid",DataSet.STRING);

        String projectprotocolid = "";
        String sponsorname = "";

        sql = Util.parseMessage(CytoSqls.GET_SPONSOR_PROJECTNAME_BY_SPECIMENID, CASE_ID);
        DataSet dsSponDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponDetails != null && dsSponDetails.size() > 0) {
            sponsorname = dsSponDetails.getValue(0, "sponsorname");
            projectprotocolid = dsSponDetails.getValue(0, "projectprotocolid");
        }

        int rowId = inputList.addRow();
        inputList.setValue(rowId,"sponsorid",sponsorname);
        inputList.setValue(rowId,"projectid",projectprotocolid);
        String finalPath = Util.generateLocationPath(networkSuccessPath, inputList);

        //String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        File file = new File(processFolderPath + fileName);
        //File dir = new File(path + File.separator + "success" + File.separator + folderDt + File.separator);
        File destDir = new File(finalPath);

        /*if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");*/

        if (!destDir.exists())
            if (destDir.mkdirs())
                Logger.logInfo(destDir.getPath() + ":: created successfully");

        if (file.isFile()) {

            /*try {
                Files.copy(file.toPath(), (new File(ikrosLabvantagePath + file.getName())).toPath(), COPY_ATTRIBUTES);
                Logger.logInfo(file.getName() + ":: File Copied to Ikaros folder");
            } catch(IOException ie){
                throw new SapphireException("Unable to move to Ikaros share folder. Reason: "+ie);
            }*/
            if (file.renameTo(new File(destDir.getPath() + File.separator + file.getName())))
                Logger.logInfo(file.getName() + ":: File Moved to Success folder");

            if (file.delete())
                Logger.logInfo(file.getName() + "::File delete from Metafer folder");
            else
                Logger.logInfo("Unable to delete::" + file.getName() + ":: file from Metafer folder");
        }
    }


    private String getLabvantageShareFolderPathIkros() throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "ikros.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    private void moveToFailureFolder(String path, String fileName, String processFolderPath, String ErrorMsg) throws SapphireException{

        String networkFailurePath = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "cyto.metafer.failure");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            networkFailurePath = ds.getValue(0, "propvalue");

        DataSet inputList = new DataSet();
        inputList.addColumn("sponsorid",DataSet.STRING);
        inputList.addColumn("projectid",DataSet.STRING);

        String projectprotocolid = "";
        String sponsorname = "";

        sql = Util.parseMessage(CytoSqls.GET_SPONSOR_PROJECTNAME_BY_SPECIMENID, CASE_ID);
        DataSet dsSponDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponDetails != null && dsSponDetails.size() > 0) {
            sponsorname = dsSponDetails.getValue(0, "sponsorname");
            projectprotocolid = dsSponDetails.getValue(0, "projectprotocolid");
        }

        int rowId = inputList.addRow();
        inputList.setValue(rowId,"sponsorid",sponsorname);
        inputList.setValue(rowId,"projectid",projectprotocolid);
        String finalPath = Util.generateLocationPath(networkFailurePath, inputList);

        //String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        File file = new File(processFolderPath + fileName);
        //File dir = new File(path + File.separator + "failure" + File.separator + folderDt + File.separator);
        File dir = new File(finalPath );
        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if (file.isFile() && dir.exists()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + file.getName()))) {
                Logger.logInfo(file.getName() + ":: File Moved to Failure folder");
                File logFile = new File(dir.getPath() + File.separator + fileName + "_" + "_error_log.txt");
                try {
                    logFile.createNewFile();
                    writeLog(logFile.getPath(), ErrorMsg);
                } catch (Exception e) {
                    Logger.logError(("Error occured during Error file(" + fileName + ") log creation!!!"));
                }
            }

            if (file.delete())
                Logger.logInfo(file.getName() + "::File delete from Metafer folder");
            else
                Logger.logInfo("Unable to delete::" + file.getName() + ":: file from Metafer folder");
        }
    }

    private void writeLog(String logFileName, String msg) {
        BufferedWriter bw = null;
        FileWriter fw = null;
        try {
            fw = new FileWriter(logFileName);
            bw = new BufferedWriter(fw);
            bw.write(msg);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (IOException ex) {

            }
        }
    }

    private void processPendingFile(String path, String processFolderPath) throws SapphireException {

        File f = new File(path);
        File[] files = f.listFiles();

        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile()) {
                    parseFileName(file.getName(), path, processFolderPath);
                    moveToSuccessFolder(path, file.getName(), processFolderPath);
                }
            }
        }
    }
}
