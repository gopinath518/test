package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CytoHalfCulture extends BaseAction{
	
	public void processAction(PropertyList properties) throws SapphireException {
		String culturemapid = StringUtil.replaceAll(properties.getProperty("culturemapid"), "|", ";");
		String childsampleid = properties.getProperty("childsampleid");
		try {
			PropertyList autoCustodyProp = new PropertyList();
			autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsampleid, ";", true));

			getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
		}catch(SapphireException ex){
			throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
		}
		updateHalfCulture(culturemapid);
	}

	private void updateHalfCulture(String culturemapid) throws SapphireException {
		PropertyList props = new PropertyList();
		props.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
		props.setProperty(EditSDI.PROPERTY_KEYID1, culturemapid);
		props.setProperty("halfcultureflag", "Y");
//		props.setProperty("setupdt", "n");
//		props.setProperty("setupuserid", connectionInfo.getSysuserId());
		props.setProperty("byPassVolUpdate", "Y");
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
		} catch (ActionException e) {
			throw new SapphireException("Error occured while doing Half Culture ");
		}

	}

}
