package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by aritra.banerjee on 8/4/2017.
 */
public class CaseReviewDetail extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String accessionidlist=properties.getProperty("accessionidlist","");
        String freshprepid=properties.getProperty("freshprepid","");
        String fromtramstop=properties.getProperty("fromtramstop","");

        if( !Util.isNull(accessionidlist) )
            updateRevieDetailInfo(accessionidlist, freshprepid, fromtramstop);
        else
            throw new SapphireException("No Accession Id has been selected.");
    }

    private void updateRevieDetailInfo(String accessionidlist, String freshprepid, String fromtramstop) throws SapphireException {
        String sql = Util.parseMessage(CytoSqls.CASE_REVIEW_INFO, freshprepid, StringUtil.replaceAll(accessionidlist, ";", "','"));
        String reviewbyColName = "";
        String reviewDtColName = "";

        if ("Tech1".equalsIgnoreCase(fromtramstop)) {
            reviewbyColName = "tech1rvwedby";
            reviewDtColName = "tech1rvwdt";
        }
        if ("Tech2".equalsIgnoreCase(fromtramstop)) {
            reviewbyColName = "tech2rvwedby";
            reviewDtColName = "tech2rvwdt";
        }
        if ("CsReview".equalsIgnoreCase(fromtramstop)) {
            reviewbyColName = "csrvwreviewedby";
            reviewDtColName = "csrvwreviewdt";
        }
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if(dsInfo == null)
            throw new SapphireException("Unable to execute Query.");
        else
            updateInfo(accessionidlist, freshprepid, dsInfo, reviewbyColName, reviewDtColName);
    }

    private void updateInfo(String accessionidlist, String freshprepid, DataSet dsInfo, String reviewbyColName, String reviewDtColName) throws SapphireException{

        String userid = connectionInfo.getSysuserId();
        String reviewdate = "n";
        if(dsInfo==null)
            throw new SapphireException("Unable to execute Query.");
        if(dsInfo.size()==0){
            PropertyList prop = new PropertyList();
            int copies = accessionidlist.split(";").length;
            try {
                prop.setProperty(AddSDI.PROPERTY_SDCID, "CytoCaseReviewDtl");
                prop.setProperty(AddSDI.PROPERTY_COPIES, ""+copies);
                prop.setProperty("sampleid", StringUtil.repeat(freshprepid, copies, ";"));
                prop.setProperty("accessionid", accessionidlist);
                prop.setProperty(reviewbyColName, StringUtil.repeat(userid, copies, ";"));
                prop.setProperty(reviewDtColName, StringUtil.repeat(reviewdate, copies, ";"));

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);

            } catch (SapphireException e) {
                throw new SapphireException("Unable to Add row in  CytoCaseReviewDtl.");
            }
        } else {
            DataSet dsAdd = new DataSet();
            dsAdd.addColumn("accessionid",DataSet.STRING);
            //dsAdd.addColumn("",DataSet.STRING);
            DataSet dsEdit = new DataSet();

            String[] accessionList = StringUtil.split(accessionidlist,";");
            for(int i=0; i<accessionList.length; i++){
                HashMap hm = new HashMap();
                hm.put("accessionid",accessionList[i]);
                hm.put("sampleid",freshprepid);
                DataSet dsFilter = dsInfo.getFilteredDataSet(hm);
                if(dsFilter.size()>0)
                    dsEdit.copyRow(dsInfo,i,1);
                else {
                    int rowId = dsAdd.addRow();
                    dsAdd.setValue(rowId, "accessionid", accessionList[i]);
                }

            }
            // impl
            if(dsAdd.size() > 0){
                PropertyList prop = new PropertyList();
                int copies = dsAdd.getRowCount();
                try {
                    prop.setProperty(AddSDI.PROPERTY_SDCID, "CytoCaseReviewDtl");
                    prop.setProperty(AddSDI.PROPERTY_COPIES, ""+copies);
                    prop.setProperty("sampleid", StringUtil.repeat(freshprepid, copies, ";"));
                    prop.setProperty("accessionid", dsAdd.getColumnValues("accessionid",";"));
                    prop.setProperty(reviewbyColName, StringUtil.repeat(userid, copies, ";"));
                    prop.setProperty(reviewDtColName, StringUtil.repeat(reviewdate, copies, ";"));

                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);

                } catch (SapphireException e) {
                    throw new SapphireException("Unable to Add row in  CytoCaseReviewDtl.");
                }
            }
            if(dsEdit.size() > 0){
                if(!Util.isNull(dsEdit.getColumnValues("u_cytocasereviewdtlid",";"))){
                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "CytoCaseReviewDtl");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsEdit.getColumnValues("u_cytocasereviewdtlid",";"));
                    props.setProperty(reviewbyColName, userid);
                    props.setProperty(reviewDtColName, reviewdate);

                    try{
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Error: Unable to update in CytoCaseReviewDtl.");
                    }
                }

            }
        }

    }
}
