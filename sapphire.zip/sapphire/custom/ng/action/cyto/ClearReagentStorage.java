package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by subhashree.dash on 4/2/2018.
 */
public class ClearReagentStorage extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String reagentlotid = properties.getProperty("keyid1");
        if (Util.isNull(reagentlotid)) {
            throw new SapphireException("Error : Reagent Lot not found, Please select atleast one... ");
        }
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, reagentlotid);
        props.setProperty("currentstorageunitid", "(null)");
        props.setProperty("custodialuserid", connectionInfo.getSysuserId());
        props.setProperty("custodialdepartmentid",connectionInfo.getDefaultDepartment());

        try{
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

        }catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Can not clear storage from selected Reagent Lot. Please contact administrator");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }
    }
