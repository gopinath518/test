package sapphire.custom.ng.action.cyto;

import com.google.gwt.junit.client.WithProperties;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class CytoAddImgToReport extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String fpsampleid = properties.getProperty("fpid", "");
        String arrindex = properties.getProperty("arrindex", "");
        String maxcnt = properties.getProperty("maxcnt", "");
        String allImgId = properties.getProperty("allImgId", "");
        String shownext = properties.getProperty("shownext", "");
        String showprev = properties.getProperty("showprev", "");
        String imageid = properties.getProperty("imageid", "");
        String addtoreportflag = properties.getProperty("addtoreportflag", "");
        String showreportbtn = properties.getProperty("showreportbtn", "");
        String previmgid = properties.getProperty("previmgid", "");

        if(Util.isNull(imageid))
            throw new SapphireException("Unable to find Image Id for modification.");

        PropertyList pl = new PropertyList();
        if(!Util.isNull(imageid)) {
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "CytoIkarosImages");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, imageid);
            pl.setProperty("addtoreportflag", addtoreportflag);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

        if(!Util.isNull(previmgid)){
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "CytoIkarosImages");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, previmgid);
            pl.setProperty("addtoreportflag", "(null)");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }


        String outScript="<Script> sapphire.page.navigate('rc?command=page&page=CytoShowImage&keyid1="+fpsampleid+"&arrindex="+arrindex+"&maxcnt="+maxcnt+
                "&shownext="+shownext+"&showprev="+showprev+"&showreportbtn="+showreportbtn+"&allImgId="+allImgId+"&imgid="+imageid+"','Y','_top',null)</script>";

        properties.setProperty("outScript",outScript);


    }
}
