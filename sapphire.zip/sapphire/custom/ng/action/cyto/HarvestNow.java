package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by rrmandal on 1/23/2017.
 */
public class HarvestNow extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String childsampleid = properties.getProperty("childsampleid", "");
        String mode = properties.getProperty("mode","");
        String storeFlag = properties.getProperty("storeflag",""); // comes as input from cancel action for Harvest & Store
        try {
            if(!storeFlag.equalsIgnoreCase("Y")) {
                PropertyList autoCustodyProp = new PropertyList();
                autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsampleid, ";", true));

                getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
            }
        }catch(SapphireException ex){
            throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
        }
        if("Cancel".equalsIgnoreCase(mode)){
            harvestingCanceledCultures(properties);
        }
        else {
            String batchType = properties.getProperty("type", "");
            //String childsampleid = properties.getProperty("childsampleid", "");
            String cytostatus = properties.getProperty("cytostatus", "");
            String batchid = crtCytoBatch(batchType);
            editCultures(properties, batchid);
            editCultureSample(childsampleid, cytostatus);
            updateOperationDate(childsampleid);
        }
        HashMap<String, String> paramValMap = new HashMap<String, String>();
        paramValMap.put("param1", StringUtil.replaceAll(properties.getProperty("freshprepsampleid", ""), ";", "\\',\\'"));
        
        if("Harvest".equals(properties.getProperty("tramstop","")))
        	properties.setProperty("msg", Util.setReturnURL("CytoFeedCultureList", "CulturesBySampleIdForFeed", paramValMap));
        if("SlideDrop".equals(properties.getProperty("tramstop","")))
        	properties.setProperty("msg", Util.setReturnURL("CytoHarvestList", "CulturesBySampleIdForHarvest", paramValMap));
    }

    private void updateOperationDate(String childsampleid)throws SapphireException {

        DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_PARENT_OF_CULTURES, StringUtil.replaceAll(childsampleid, ";", "','")));

        if(!Util.isNull(ds.getColumnValues("u_sampleculturemapid", ";"))) {

            PropertyList editProp = new PropertyList();
            editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
            editProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampleculturemapid", ";"));
            editProp.setProperty("harvesteddt", "n");

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Unable to edit Harvest date for selected culture(s).");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }

    private void harvestingCanceledCultures(PropertyList properties)throws SapphireException{
        String childsampleid = properties.getProperty("childsampleid","");
        String freshprepsampleid = properties.getProperty("freshprepsampleid","");
        String option = properties.getProperty("option","");
        String storageunit = properties.getProperty("storageunit","");


        if(Util.isNull(childsampleid)){
            throw new SapphireException("Childsampleid(s) are not found for the selected culture(s)");
        }
        if(Util.isNull(freshprepsampleid))
            throw new SapphireException("Patient sampleid(s) are not found for the selected culture(s)");
        if(Util.isNull(option))
            throw new SapphireException("Option canot be null");
        if("Harvest and Store".equalsIgnoreCase(option)){
            if(Util.isNull(storageunit))
                throw new SapphireException("Storageunit is not found");

            String sql = Util.parseMessage(CytoSqls.CHECK_FREESTORAGEINFO_BY_STORAGEUNITID,StringUtil.replaceAll(storageunit,";","','"));
            DataSet dsFreeStgInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsFreeStgInfo==null)
                throw new SapphireException("Storage info cannot be obtained from database");

            HashMap<String,String> hmap = new HashMap<String,String>();
            String storageunitArr[]=StringUtil.split(storageunit,";");
            String disputedStg = "";

            if(storageunitArr!=null && storageunitArr.length>0) {
                for (int i = 0; i < storageunitArr.length; i++) {
                    hmap.clear();
                    hmap.put("storageunitid", storageunitArr[i]);
                    DataSet tempDs = dsFreeStgInfo.getFilteredDataSet(hmap);
                    if (tempDs != null && tempDs.size() > 0) {
                        int stginfo = tempDs.getInt(0,"stginfo",-1);
                        int maxtiallowed = tempDs.getInt(0,"maxtiallowed",-1);
                        if(maxtiallowed<=0 || (maxtiallowed>0 && stginfo>=maxtiallowed))
                            disputedStg += ";" + tempDs.getValue(0, "labelpath", "");
                    }
                }
            }
            if(!Util.isNull(disputedStg)){
                if(disputedStg.startsWith(";"))
                    disputedStg=disputedStg.substring(1);
                throw new SapphireException("Below storage location(s) do not have any space to store culture\n"+disputedStg);
            }

            PropertyList pl = new PropertyList();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
            pl.setProperty("currentstorageunitid", storageunit);
            //pl.setProperty("custodialuserid", "(null)");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }
        else if("Harvest and Send to Fresh Prep".equalsIgnoreCase(option)){
            DataSet dsFPDeptInfo = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_FP_DEPT_OF_PATIENT_SAMPLE, StringUtil.replaceAll(freshprepsampleid, ";", "','")));
            if(dsFPDeptInfo!=null && dsFPDeptInfo.size()>0){
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                pl.setProperty(EditSDI.PROPERTY_KEYID1,childsampleid);
                pl.setProperty("u_cytostatus","Back To Freshprep");
                pl.setProperty("samplestatus","Cancelled");
                getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);

                String childsampleArr[] =StringUtil.split(childsampleid,";");
                String fpsampleidArr[] = StringUtil.split(freshprepsampleid,";");

                if(fpsampleidArr!=null && childsampleArr!=null && childsampleArr.length>0 && childsampleArr.length==fpsampleidArr.length){
                    DataSet result = new DataSet();
                    result.addColumn(EditTrackItem.PROPERTY_KEYID1,DataSet.STRING);
                    result.addColumn("custodialdepartmentid",DataSet.STRING);
                    result.addColumn("custodialuserid",DataSet.STRING);
                    HashMap<String,String> hmap = new HashMap<String,String>();

                    for(int i=0;i<childsampleArr.length;i++){
                        if(!Util.isNull(childsampleArr[i]) && !Util.isNull(fpsampleidArr[i])){
                            hmap.clear();
                            hmap.put("s_sampleid",fpsampleidArr[i]);
                            DataSet tempFiltered = dsFPDeptInfo.getFilteredDataSet(hmap);
                            if(tempFiltered!=null && tempFiltered.size()>0){
                                String dept = tempFiltered.getValue(0,"dept","");
                                if(!Util.isNull(dept)){
                                    int rowIndex = result.addRow();
                                    result.setValue(rowIndex,EditTrackItem.PROPERTY_KEYID1,childsampleArr[i]);
                                    result.setValue(rowIndex,"custodialdepartmentid",dept);
                                    //result.setValue(rowIndex,"custodialuserid","(null)");
                                }
                            }
                        }
                    }
                    if(result.size()>0){
                        pl.clear();
                        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, result.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                        pl.setProperty("custodialdepartmentid", result.getColumnValues("custodialdepartmentid", ";"));
                        //pl.setProperty("custodialuserid", result.getColumnValues("custodialuserid", ";"));
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                    }
                }
            }
        }
    }

    private String crtCytoBatch(String type) throws SapphireException{
        if(Util.isNull(type))
            throw new SapphireException("Batch Type is not found");
        String batchid = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID,"CytoBatch");
        pl.setProperty(AddSDI.PROPERTY_COPIES,"1");
        pl.setProperty("type",type);
        getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID,pl);
        batchid=pl.getProperty(AddSDI.RETURN_NEWKEYID1,"");
        return batchid;
    }

    private void editCultures(PropertyList properties,String batchid)throws SapphireException{
        String keyid1 = properties.getProperty("keyid1","");
        String tramstop = properties.getProperty("tramstop","");
        if(Util.isNull(keyid1))
            throw new SapphireException("Keyid1 for the selected culture(s) are not found");
        if(Util.isNull(batchid))
            throw new SapphireException("No new batchid found");

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID,"SampleCultureMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1,keyid1);
        pl.setProperty("harvestdt","n");
        pl.setProperty("harvestuser",connectionInfo.getSysuserId());
        if("Harvest".equalsIgnoreCase(tramstop))    // from Feed
            pl.setProperty("incubator","(null)");
        else if ("SlideDrop".equalsIgnoreCase(tramstop))    // from Harvest
            pl.setProperty("hanabi","(null)");

        pl.setProperty("batchid",batchid);

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
    }

    private void editCultureSample(String childsamples,String cytostatus)throws SapphireException{
        if(Util.isNull(childsamples))
            throw new SapphireException("Sampleid(s) for the selected cultures are not found");
        if(Util.isNull(cytostatus))
            throw new SapphireException("New status for the selected culture(s) is not found");

        String nextStep = "";
        if("Ready for Slide Drop".equalsIgnoreCase(cytostatus))
           nextStep = "CytoSlideDrop";
        else if ("Ready for Harvest".equalsIgnoreCase(cytostatus))
            nextStep = "CytoHarvest";

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1,childsamples);
        pl.setProperty("u_cytostatus",cytostatus);
        pl.setProperty("u_currentmovementstep", StringUtil.repeat(nextStep,childsamples.split(";").length , ";"));
        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);

        // Edit Track Item for current movement step
        String sql = Util.parseMessage(CytoSqls.GET_TRACKITEMID_SQL, StringUtil.replaceAll(childsamples, ";", "','"));
        DataSet dsTrackItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsTrackItem == null)
            throw new SapphireException("Error: Unable to perform query in Database. "+ sql);
        else if (dsTrackItem.size() > 0) {
            pl.clear();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, dsTrackItem.getColumnValues("trackitemid", ";"));
            pl.setProperty("u_currenttramstop", nextStep);
            //pl.setProperty("custodialuserid", "(null)");

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);


        }


    }
}
