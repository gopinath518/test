package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 12/29/2016.
 * This action has been created to clear storageunit ID for the select sampleid.
 * Input Props = keyid1
 * Output Props (Calling editTrackitem out of box action)
 * currentstorageunitid = null
 * Output Props for u_sampleculturemapid(Coming from GET_SAMPLECULTUREMAPID_BY_CHILDSAMPLEID query)
 * (Calling editSDI out of box action)
 * incubator=null
 * hanabi=null
 * thermotron=null
 */
public class ClearStorage extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("keyid1");
        if(Util.isNull(sampleid)){
            throw new SapphireException("Error : Specimen Id not found, Please select atleast one... ");
        }
        PropertyList props = new PropertyList();

        if(!Util.isNull(sampleid)){
            String sql = Util.parseMessage(CytoSqls.GET_SAMPLECULTUREMAPID_BY_CHILDSAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsCultureInfo!=null && dsCultureInfo.size()>0){
                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID,"SampleCultureMap");
                props.setProperty(EditSDI.PROPERTY_KEYID1,dsCultureInfo.getColumnValues("u_sampleculturemapid",";"));
                props.setProperty("incubator","(null)");
                props.setProperty("hanabi","(null)");
                props.setProperty("thermotron","(null)");

                getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,props);
            }
        }

        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        props.setProperty("currentstorageunitid", "(null)");
        props.setProperty("custodialuserid", connectionInfo.getSysuserId());
        props.setProperty("custodialdepartmentid",connectionInfo.getDefaultDepartment());

        try{
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

        }catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Can not clear storage from selected specimen. Please contact administrator");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }
}
