package sapphire.custom.ng.action.cyto;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.List;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.ConnectionProcessor;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.EncryptDecrypt;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class WatchIkrosLabFolder extends BaseAction {


    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String ikrosLabvantagePath = getLabvantageShareFolderPathIkros();
        String selectedFileNames = properties.getProperty("selectedfilename","");
        watchLabvantageShareFolderIkros(ikrosLabvantagePath, selectedFileNames);
    }

    private void watchLabvantageShareFolderIkros(String ikrosLabvantagePath, String selectedFileNames) throws SapphireException {

        List<File> listOfFiles = new ArrayList<>();

        if (!Util.isNull(ikrosLabvantagePath)) {
            Logger.logInfo("Ikaros Share Folder Path to Monitor::" + ikrosLabvantagePath);

            String fileName = "";

            if(Util.isNull(selectedFileNames)) {
                File folder = new File(ikrosLabvantagePath);
                File[] list = folder.listFiles();
                if(list != null && list.length > 0) {
                    for (File f : list) {
                        listOfFiles.add(f);
                    }
                }
            } else {
                //String[] fnames = selectedFileNames.split("@*@");
                String[] fnames = StringUtil.split(selectedFileNames, "@*@", true);
                for(String s:fnames){
                    listOfFiles.add(new File(ikrosLabvantagePath+s));
                }
            }

            PropertyList pl = new PropertyList();

            if (listOfFiles.size() > 0) {
                for (File file : listOfFiles) {
                    try {
                        if ( (Util.isNull(selectedFileNames) && file.isFile())
                                || (!Util.isNull(selectedFileNames)) ) {
                            Logger.logInfo("Processing Ikaros File Name::" + file.getName());
                            fileName = file.getName();
                            String tempFolderPath = moveToProcessFolder(ikrosLabvantagePath, fileName);
                            pl.clear();
                            pl.setProperty("slideName", fileName);
                            pl.setProperty("serverStartFlag", "N");
                            pl.setProperty("ikrosPath", ikrosLabvantagePath);
                            pl.setProperty("processFolderPath", tempFolderPath);
                            getActionProcessor().processAction("IkrosImageProcessing", "1", pl);

                          /*  pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "CytoImageStatusChanger");
                            pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
                            pl.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
                            pl.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");

                            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, pl);*/
                        }
                    } catch (Exception e) {
                        Logger.logInfo("Error in Ikaros: " + e.toString());
                        throw new SapphireException(e.getMessage());
                    }
                }
            }
        } else {
            logger.error("Ikaros shared path is not mentioned in master data. ");
            throw new SapphireException("Ikaros Share folder path not set.");
        }

    }

    private String getLabvantageShareFolderPathIkros() throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "ikros.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    private String moveToProcessFolder(String path, String fileName) {

        File file = new File(path + fileName);
        File dir = new File(path + File.separator+"process"+File.separator);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        //if (file.isFile()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                Logger.logInfo(file.getName() + ":: File Moved to Process folder");

            if (file.delete())
                Logger.logInfo(file.getName() + "::File delete from "+path+" folder");
            else
                Logger.logInfo("Unable to delete::" + file.getName() + ":: file from "+path+" folder");
        //}

        return dir.getPath()+File.separator;
    }

}
