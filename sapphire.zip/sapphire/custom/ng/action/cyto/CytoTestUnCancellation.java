package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditDataSet;
import sapphire.action.EditSDI;
import sapphire.action.EditSDIWorkItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CytoTestUnCancellation extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1= properties.getProperty("keyid1","");
        String auditreason= properties.getProperty("auditreason","");
        if(Util.isNull(keyid1))
            throw new SapphireException("Keyid1 obtained as null/blank");
        String sql = Util.parseMessage(CytoSqls.NOT_ELIIGIBLE_COUNT_FOR_CANCEL_UNCANCEL,StringUtil.replaceAll(keyid1,";","','"),
                StringUtil.replaceAll(keyid1,";","','"),
                StringUtil.replaceAll(keyid1,";","','"));
        DataSet dsNotElligibleSampleInfo=getQueryProcessor().getSqlDataSet(sql);
        if(dsNotElligibleSampleInfo==null)
            throw new SapphireException("Below query cannot be executed.\n"+sql);
        if(dsNotElligibleSampleInfo.size()>0){
            int notelligiblcnt=dsNotElligibleSampleInfo.getInt(0,"notelligiblcnt",0);
            if(notelligiblcnt>0)
                throw new SapphireException("Undo cancel operation can only be performed on the mother tube.");
        }

        sql=Util.parseMessage(CytoSqls.ACTIVE_CYTO_TESTCODE_CNT_BY_SAMPLETESTCODEMAPID,StringUtil.replaceAll(keyid1,";","','"));
        DataSet dsActiveCytoTestCnt=getQueryProcessor().getSqlDataSet(sql);
        if(dsActiveCytoTestCnt==null)
            throw new SapphireException("Below query cannot be executed.\n"+sql);
        if(dsActiveCytoTestCnt.size()>0){
            int activecytotestcnt=dsActiveCytoTestCnt.getInt(0,"activecytotestcnt",0);
            if(activecytotestcnt>0)
                throw new SapphireException("Some of the selected sample(s) are currently having active cyto testcode(s)");
        }

        sql=Util.parseMessage(CytoSqls.DUMMY_SAMPLETESTCODEMAPID,StringUtil.replaceAll(keyid1,";","','"));
        DataSet dsDummySampleTestcodeMapInfo=getQueryProcessor().getSqlDataSet(sql);
        if(dsDummySampleTestcodeMapInfo==null)
            throw new SapphireException("Below query cannot be executed.\n"+sql);
        if(dsDummySampleTestcodeMapInfo.size()>0){
            keyid1+=";"+dsDummySampleTestcodeMapInfo.getColumnValues("u_sampletestcodemapid",";");
        }

        uncancelSDIWorkitem(keyid1);
        undoTestcode(keyid1,auditreason);

    }

    private void uncancelSDIWorkitem(String keyid1) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            String sql=Util.parseMessage(CytoSqls.DATSET_INFO_BY_TESTCODEID, StringUtil.replaceAll(keyid1,";","','"));
            DataSet dsWIInfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsWIInfo==null)
                throw new SapphireException("Below query cannot be executed.\n"+sql);
            if(dsWIInfo.size()==0)
                throw new SapphireException("No Workitem info found");

            PropertyList props = new PropertyList();
            props.setProperty(EditDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(EditDataSet.PROPERTY_KEYID1, dsWIInfo.getColumnValues("keyid1", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsWIInfo.getColumnValues("paramlistid", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsWIInfo.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EditDataSet.PROPERTY_VARIANTID, dsWIInfo.getColumnValues("variantid", ";"));
            props.setProperty(EditDataSet.PROPERTY_DATASET, dsWIInfo.getColumnValues("dataset", ";"));
            props.setProperty("s_datasetstatus", StringUtil.repeat("Initial",dsWIInfo.size(),";"));
            props.setProperty("s_cancellableflag", StringUtil.repeat("(null)",dsWIInfo.size(),";"));
            props.setProperty("cancelleddt", StringUtil.repeat("(null)",dsWIInfo.size(),";"));
            props.setProperty("cancelledby", StringUtil.repeat("(null)",dsWIInfo.size(),";"));
            props.setProperty(EditDataSet.PROPERTY_PROPSMATCH,"Y");
            getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDIWorkItem.PROPERTY_SDCID,"Sample");
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID1,dsWIInfo.getColumnValues("keyid1", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMID,dsWIInfo.getColumnValues("workitemid", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMINSTANCE,dsWIInfo.getColumnValues("workiteminstance", ";"));
            props.setProperty("workitemstatus", StringUtil.repeat("Initial",dsWIInfo.size(),";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_PROPSMATCH,"Y");
            getActionProcessor().processAction(EditSDIWorkItem.ID, EditSDIWorkItem.VERSIONID, props);

        }
    }

    private void undoTestcode(String keyid1,String auditreason) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty("teststatus", "In Progress");
            props.setProperty("cancelopp", "(null)");
            props.setProperty("unused", "(null)");
            props.setProperty("prestatus", "(null)");
            props.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to Undo cancelled testcode(s).");
            }
        }
    }
}