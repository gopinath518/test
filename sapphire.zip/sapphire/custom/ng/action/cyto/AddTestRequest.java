package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.RecordIncident;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 5/25/2017.
 * Input Props : Fresh prep sample ID & client testcode ID as TestCode.
 */
public class AddTestRequest extends BaseAction {

    private static final String FRESH_PREP_SAMPLE = "sampleid";
    private static final String TEST_CODE_PROP= "clienttestcodeid";

    public void processAction(PropertyList properties) throws SapphireException{

        String sampleid = properties.getProperty(FRESH_PREP_SAMPLE);
        String testcode = properties.getProperty(TEST_CODE_PROP);
        String comment = properties.getProperty("comment");
        if(!Util.isNull(sampleid)){

            String currentUserDepartment=getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
            String todept = "";

            String sql = Util.parseMessage(CytoSqls.PARENT_INFO_OF_ORGSAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));   // Getting Source sampleid by providing destination sample ID from s_samplemap
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            String orgsample = "";

            if (ds != null && ds.size() > 0) {

                orgsample=ds.getColumnValues("sampleid",";");

                if (!Util.isNull(orgsample) && !Util.isNull(currentUserDepartment)) {

                    autoCustodyTransfer(orgsample);
                    String currUserDeptArr[] = StringUtil.split(currentUserDepartment, "-");
                    String toFinalDept = "";
                    if (currUserDeptArr != null && currUserDeptArr.length > 0)
                        toFinalDept = currUserDeptArr[0] + "-Accessioning"; // Adding 'Accessioning' with the current department.

                    if (!Util.isNull(toFinalDept) && !Util.isNull(testcode)) {
                        PropertyList prop = new PropertyList();

                        String message = "The testCode(s) " + testcode + " have been ordered as Reflex Test for the sample(s) " + StringUtil.replaceAll(orgsample, ";", ",");
                        if (!Util.isNull(comment))
                            message += "\n" + comment;

                        prop.setProperty("sourcesdcid", "Sample");
                        prop.setProperty("sourcekeyid1", orgsample);
                        prop.setProperty("incidentcategory", "UnPlanned");
                        prop.setProperty("incidentdesc", "Reflex Test Request For Accession Department");
                        prop.setProperty("u_message", message);
                        prop.setProperty("u_fromdepartment", currentUserDepartment);
                        prop.setProperty("incidentstatus", "InProgress");
                        prop.setProperty("reportedby", connectionInfo.getSysuserId());
                        prop.setProperty("departmentid", toFinalDept);

                        try {
                            getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, prop); // Calling Record Incident out of box action to generate incident & whole data will be populated on incident table.

                            prop.setProperty("departmentid", currUserDeptArr[0] + "-ClientServices");
                            prop.setProperty("incidentdesc", "Reflex Test Request For Client Service Department");
                            getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, prop);

                            prop.clear();
                            prop.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                            prop.setProperty(EditSDI.PROPERTY_KEYID1,orgsample);
                            prop.setProperty("u_hasreflextestreq","Y");

                            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,prop);

                        } catch (Exception e) {
                            throw new SapphireException("Error: Unable to create indicident for selected samples...");
                        }
                    }

                }
            }

        }
    }
    public void autoCustodyTransfer(String  freshPrepSample) throws SapphireException {

        String slidesql = Util.parseMessage(CytoSqls.GET_SLIDE_CHILDSAMPLE_BY_FRESHPREPID, StringUtil.replaceAll(freshPrepSample, ";", "','"));
        DataSet dsslidechildsample = getQueryProcessor().getSqlDataSet(slidesql);
        String childslidesample="";
        if (dsslidechildsample != null && dsslidechildsample.size() > 0 ){
            childslidesample= dsslidechildsample.getColumnValues("childsampleid", ";");
        }
        try {
            PropertyList autoCustodyProp = new PropertyList();
            autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childslidesample, ";", true));

            getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
        }catch(SapphireException ex){
            throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
        }
    }
}
