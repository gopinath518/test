package sapphire.custom.ng.action.cyto;

import com.labvantage.sapphire.actions.report.GenerateReport;
import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;

public class CytoGenerateReport extends BaseAction {
    
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        
        String sampleId = properties.getProperty("sampleid", "");
        String testCode = properties.getProperty("testcode", "");
        
        String location = getFileLocation(sampleId);
        //String location = "C:\\labvantagehome_bio\\";
        if(location ==  null || "".equals(location))
            throw new SapphireException("Report Location is not setup in Policy::"+location);
            
        String fileName = generateCytoReport(location,sampleId);
        String sampleTestCodeId = addAttachment( fileName, sampleId, testCode);
        addCytoReport(sampleTestCodeId);
        updateChildSampleStatus(sampleId,testCode);
        updateOrgSampleStatus(sampleId,sampleTestCodeId,testCode);
    }
    
    private String generateCytoReport(String location,String sampleId)throws SapphireException {
        String filename = "";
        long time = System.currentTimeMillis();
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        
        filename = location+sampleId+"_"+time+".pdf";

            PropertyList prop = new PropertyList();
            prop.clear();
            prop.setProperty(GenerateReport.PROPERTY_REPORTID, "CytogeneticsQC");
            prop.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID, "1");
            prop.setProperty("sampleid", sampleId);
            prop.setProperty("signedby", currentUser);
            prop.setProperty(GenerateReport.PROPERTY_DESTINATION, "file");
            prop.setProperty(GenerateReport.PROPERTY_DEBUGLOG, "N");
            prop.setProperty(GenerateReport.PROPERTY_FILENAME, filename);
            prop.setProperty(GenerateReport.PROPERTY_FILETYPE, "pdf");

            try {
                getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);
            } catch (SapphireException e) {
                String errMSG = getTranslationProcessor().translate("Error in generateCytoReport method::"+e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        return filename;
        
    }
    
    public String addAttachment(String fileName,String sampleId, String testCode) throws SapphireException {
        
        String sql = Util.parseMessage(CytoSqls.GET_FRESH_PREP_HIERARCHY, sampleId);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        
        String sourceSampleId =  ds.getColumnValues("sourceid", "','");
        if(!Util.isNull(sourceSampleId))
            sourceSampleId += ";"+sampleId;
        else
            sourceSampleId =  sampleId;
        
        sql = Util.parseMessage(CytoSqls.GET_SAMPLE_TESTCODE_KEYID, StringUtil.replaceAll(sourceSampleId, ";", "','"),testCode);
        ds.clear();
        ds = getQueryProcessor().getSqlDataSet(sql);
        String tempSampleTestcodeId = ds.getColumnValues("u_sampletestcodemapid", ";");
        
        for(int i=0; i<ds.size(); i++) {
            String sampleTestcodeId = ds.getValue(i, "u_sampletestcodemapid", "");
            
            PropertyList attachprop = new PropertyList();
            attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "SampleTestCodeMap");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, sampleTestcodeId);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, fileName);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(fileName).getName());
            attachprop.setProperty("u_attachmenttype", "CytogeneticsQCReport");

            try {
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate(""+ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
        }
        
            return tempSampleTestcodeId;
    }
    
    private void addCytoReport(String sampleTestCodeId) throws SapphireException {
        String sql = Util.parseMessage(CytoSqls.GET_LATEST_ATTACHMENTNUM, StringUtil.replaceAll(sampleTestCodeId, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoReport");
        pl.setProperty("attachedsdcid", "SampleTestCodeMap");
        pl.setProperty("sampletestcodemapid", ds.getColumnValues("keyid1", ";"));
        pl.setProperty("attachmentnum", ds.getColumnValues("attnum", ";"));
        pl.setProperty("signby", StringUtil.repeat(currentUser, ds.size(),";"));
        pl.setProperty("signdt", StringUtil.repeat("n", ds.size(),";"));
        pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(ds.size()));
        
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        
    }
    
    private void  updateChildSampleStatus(String sampleId,String testCode)throws SapphireException {
        String sql = Util.parseMessage(CytoSqls.CULTURE_SLIDE_SAMPLE_BY_FRESHPREPSAMPLEID, sampleId,sampleId);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds.size()>0) {
            String samples=ds.getColumnValues("childsampleid", ";");

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, samples);
            pl.setProperty("u_cytostatus", "Reported");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            sql = Util.parseMessage(CytoSqls.GET_SAMPLE_TESTCODE_KEYID, StringUtil.replaceAll(samples,";","','"),testCode);

            DataSet dsSampleTestcodeInfo=getQueryProcessor().getSqlDataSet(sql);

            if(dsSampleTestcodeInfo!=null && dsSampleTestcodeInfo.size()>0) {

                String sampleTestCodeId=dsSampleTestcodeInfo.getColumnValues("u_sampletestcodemapid",";");
                pl.clear();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleTestCodeId);
                pl.setProperty("teststatus", "Completed");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }
        }
    }


    private void  updateOrgSampleStatus(String sampleId,String sampleTestCodeId,String testCode)throws SapphireException {
        String sql = "";
//        String sql = Util.parseMessage(CytoSqls.GET_FRESH_PREP_HIERARCHY, sampleId);
//        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        sql=Util.parseMessage(CytoSqls.IS_CYTO_SAMPLE, sampleId);
        DataSet dsDummyInfo=getQueryProcessor().getSqlDataSet(sql);

        String dummySample="";

//        if(ds.size()>0) {
//            sampleId += ";"+ StringUtil.replaceAll(ds.getColumnValues("sourceid", ";"), ",",";");
//        }
        if(dsDummyInfo!=null && dsDummyInfo.size()>0)
            dummySample=dsDummyInfo.getValue(0,"cytodummysampleid","");

        if(!Util.isNull(dummySample)){
//            sampleId+=";"+dummySample;
            sql = Util.parseMessage(CytoSqls.GET_SAMPLE_TESTCODE_KEYID, dummySample,testCode);

            DataSet dsDummyTestCodeInfo=getQueryProcessor().getSqlDataSet(sql);
            if(dsDummyTestCodeInfo!=null && dsDummyTestCodeInfo.size()>0){
                sampleTestCodeId+=";"+dsDummyTestCodeInfo.getColumnValues("u_sampletestcodemapid",";");
            }
        }

        PropertyList pl = new PropertyList();

        if(!Util.isNull(dummySample)) {
            if(dummySample.startsWith(";"))
                dummySample=dummySample.substring(1);
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, dummySample);
            pl.setProperty("u_cytostatus", "Reported");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
        if(!Util.isNull(sampleTestCodeId)) {
            if(sampleTestCodeId.startsWith(";"))
                sampleTestCodeId=sampleTestCodeId.substring(1);
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleTestCodeId);
            pl.setProperty("teststatus", "Completed");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

    }
   
    
    private String getFileLocation(String sampleId) throws SapphireException {
        String fileLocation = "";
        String projectprotocolid = "";
        String sponsorname = "";

        /*PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "Report");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }*/

        String path = "";

        DataSet inputList = new DataSet();
        inputList.addColumn("sponsorid",DataSet.STRING);
        inputList.addColumn("projectid",DataSet.STRING);

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "cyto.report.path");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        sql = Util.parseMessage(CytoSqls.GET_SPONSOR_PROJECTNAME_BY_SPECIMENID, sampleId);
        DataSet dsSponDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponDetails != null && dsSponDetails.size() > 0) {
            sponsorname = dsSponDetails.getValue(0, "sponsorname");
            projectprotocolid = dsSponDetails.getValue(0, "projectprotocolid");
        }

        int rowId = inputList.addRow();
        inputList.setValue(rowId,"sponsorid",sponsorname);
        inputList.setValue(rowId,"projectid",projectprotocolid);
        fileLocation = Util.generateLocationPath(path, inputList);

        return fileLocation + File.separator;
    }
}
