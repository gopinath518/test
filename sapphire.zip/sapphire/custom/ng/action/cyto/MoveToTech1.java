package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import sapphire.custom.ng.util.Constants;

/**
 * Created by achakraborty on 5/3/2017.
 * User will select childsamples on Slide Banding list page & sample will route automaticaly to Tech 1.
 */
public class MoveToTech1 extends BaseAction {

    private static final String PARENTSAMPLE_PROP = "parentsampleid";
    private static final String CHILDSAMPLE_PROP = "childsampleid";
    private static final String FROM_TRAMSTOP_PROP = "from";
    private static final String DEPT_ASSIGN_FLAG = "deptflag";

    public void processAction(PropertyList properties) throws SapphireException {

        String childsample = properties.getProperty(CHILDSAMPLE_PROP);
        String deptflag = properties.getProperty(DEPT_ASSIGN_FLAG);
        if (!Util.isNull(childsample)) {

            String fromTramstop = properties.getProperty(FROM_TRAMSTOP_PROP);
            String techOneBatchId = null;
            if("metafer".equalsIgnoreCase(fromTramstop)){

                PropertyList props = new PropertyList();
                props.setProperty(AddSDI.PROPERTY_SDCID, "CytoBatch");
                props.setProperty(AddSDI.PROPERTY_COPIES, "1");
                props.setProperty("type", "T1");
                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                    techOneBatchId = props.getProperty("newkeyid1");
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to create Tech one batch. Reason: " + ae.getMessage());
                }

                props.clear();
                String cytoslideid = properties.getProperty("keyid1");
                if(!"".equalsIgnoreCase(cytoslideid)) {
                    props.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, cytoslideid);
                    props.setProperty("batchid", techOneBatchId);
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (ActionException ae) {
                        throw new SapphireException("Error: Unable to update batch information in CytoSlides");
                    }
                }

            }

            /*String sql = Util.parseMessage(CytoSqls.GET_PARENTSAMPLES, StringUtil.replaceAll(childsample, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            if (ds != null && ds.size() > 0) {
                String parentsampleid = ds.getColumnValues("parentsampleid", ";");
                String childsampleid = ds.getColumnValues("childsampleid", ";");
                String sampleids = parentsampleid + ";" + childsampleid;*/

            //if (!Util.isNull(sampleids))
            updateSite(childsample,deptflag);
            DataSet dsFinal = finalDataSetForSamplesStatusUpdate(childsample);

            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
            props.setProperty("u_currentmovementstep", dsFinal.getColumnValues("currentmovementstep", ";"));
            props.setProperty("u_cytostatus", dsFinal.getColumnValues("cytostatus", ";"));

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Error: Unable to update the Movement Step for select specimens");
            }

            updateTrackitemForSamples(dsFinal);
            updateOperationDate(childsample);

        }
    }

    /**
     * @desc Creating Final DataSet for cyto status and current movement step update.
     * @param childsampleid, the selected slides
     * @param deptflag, 'Y' means from query the destination dept will be decided as
     *                  analysis for the slides are in progress for the selected slides.
     * @throws SapphireException
     */
    private void updateSite(String childsampleid, String deptflag)throws SapphireException {

        String currUser = connectionInfo.getSysuserId();
        String userDept = connectionInfo.getDefaultDepartment();

        if("Y".equalsIgnoreCase(deptflag)){ // from query Destination Dept will be decided bcoz analysis for some sibling slides has already been started.
            DataSet dsFinal = new DataSet();
            dsFinal.addColumn("sampleid",DataSet.STRING);
            dsFinal.addColumn("dept",DataSet.STRING);
            dsFinal.addColumn("userid",DataSet.STRING);
            DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.SLIDE_ANALYSIS_INPROGRESS_DETAILS, StringUtil.replaceAll(childsampleid, ";", "','")));
            DataSet dsAcc = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_ACC_FOR_SAMPLES, StringUtil.replaceAll(childsampleid, ";", "','")));

            if(ds==null || dsAcc==null)
                throw new SapphireException("Error: Query returns Null value..");
            else if (ds.size() == 0 || dsAcc.size() == 0)
                return;
            ds.sort("u_accessionid");
            ArrayList<DataSet> dsFinalArr = ds.getGroupedDataSets("u_accessionid");

            if(dsFinalArr!=null && dsFinalArr.size()>0){
                for(int i=0;i<dsFinalArr.size();i++){
                    DataSet tempDs = dsFinalArr.get(i); // accession wise
                    if(tempDs!=null && tempDs.size()>0){//*
                        String inProgSldDept = tempDs.getValue(0, "custodialdepartmentid");
                        String tempDsAcc = tempDs.getValue(0, "u_accessionid");
                        HashMap<String,String> hm = new HashMap<String,String>();
                        hm.put("u_accessionid",tempDsAcc);
                        DataSet dsTemp = dsAcc.getFilteredDataSet(hm);
                        for(int j=0;j<dsTemp.size();j++){
                            int rowId=  dsFinal.addRow();
                            dsFinal.setValue(rowId,"sampleid",dsTemp.getValue(j,"s_sampleid"));
                            dsFinal.setValue(rowId,"dept",inProgSldDept);
                            if(inProgSldDept.equalsIgnoreCase(userDept)){
                                dsFinal.setValue(rowId,"userid",currUser);
                            } else {
                                dsFinal.setValue(rowId,"userid","(null)");
                            }
                        }

                    }
                }
            }
            if(!Util.isNull(dsFinal.getColumnValues("sampleid", ";"))) {

                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
                props.setProperty("custodialdepartmentid", dsFinal.getColumnValues("dept", ";"));
                props.setProperty("custodialuserid", dsFinal.getColumnValues("userid", ";"));

                try{
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                } catch (ActionException ex) {
                    String error = getTranslationProcessor().translate("Unable to update Department for the selected Slide(s).");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
            }

        }
        else if("schedular".equalsIgnoreCase(deptflag)){

            String sql = Util.parseMessage(CytoSqls.SLIDE_DRYLAB_SIBLINGS_DETAILS, StringUtil.replaceAll(childsampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            if(ds==null)
                throw new SapphireException("Error: Query returns Null value.."+sql);

            if(ds.size() == 0){
                //no sibling in dry lab. .. hence only curmvmntstep will be changed

                if(!Util.isNull(childsampleid)) {

                    PropertyList props = new PropertyList();
                    props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
                    props.setProperty("custodialuserid", "(null)");

                    try{
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                    } catch (ActionException ex) {
                        String error = getTranslationProcessor().translate("Unable to update Department for the selected Slide(s)."+childsampleid);
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                    }
                }

                return;
            } else if(ds.size() > 0){
                //some siblings are in dry lab
                if(!Util.isNull(childsampleid)) {

                    PropertyList props = new PropertyList();
                    props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
                    props.setProperty("custodialdepartmentid", ds.getValue(0,"custodialdepartmentid"));
                    props.setProperty("custodialuserid", ds.getValue(0,"custodialuserid"));

                    try{
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                    } catch (ActionException ex) {
                        String error = getTranslationProcessor().translate("Unable to update Department for the selected Slide(s)."+childsampleid);
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                    }
                }
            }

        }
        else {
            DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.SLIDE_DRYLAB_SIBLINGS_DETAILS, StringUtil.replaceAll(childsampleid, ";", "','")));

            if(ds==null)
                throw new SapphireException("Error: Query returns Null value..");

            String allChildsamples = childsampleid;
            if(!Util.isNull(ds.getColumnValues("s_sampleid",";")))
                allChildsamples += ";"+ds.getColumnValues("s_sampleid",";");

            if(!Util.isNull(allChildsamples)){
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, allChildsamples);
                props.setProperty("custodialdepartmentid", deptflag);
                props.setProperty("custodialuserid", "(null)");
                if(deptflag.equalsIgnoreCase(userDept)){
                    props.setProperty("custodialuserid",currUser);
                } else {
                    props.setProperty("custodialuserid","(null)");
                }

                try{
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                } catch (ActionException ex) {
                    String error = getTranslationProcessor().translate("Unable to update Department for the selected Slide(s).");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
            }
        }


    }

    private void updateOperationDate(String childsampleid)throws SapphireException {

        DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_CYTOSLIDE_ID, StringUtil.replaceAll(childsampleid, ";", "','")));

        if(!Util.isNull(ds.getColumnValues("u_cytoslidesid", ";"))) {

            PropertyList editProp = new PropertyList();
            editProp.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
            editProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_cytoslidesid", ";"));
            editProp.setProperty("metafercmpltdt", "n");

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Unable to edit Metafer Complete date for selected culture(s).");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }

    /**
     * @desc Updating 'u_currenttramstop' column for trackitem table.
     * @param  dsFinal dataset
     * @throws SapphireException
     */
    public void updateTrackitemForSamples(DataSet dsFinal) throws SapphireException{

        if(!Util.isNull(dsFinal.getColumnValues("sampleid", ";"))){

            PropertyList props = new PropertyList();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
            props.setProperty("u_currenttramstop", dsFinal.getColumnValues("currentmovementstep", ";"));
            //props.setProperty("custodialuserid", "(null)");
            try{
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }catch(Exception e){
                throw new SapphireException("Error: Unable to update Current Tramstop for the selected specimen(s)");
            }
        }
    }

    /**
     * @desc Creating Final DataSet for cyto status and current movement step update.
     * @param childsample
     * @throws SapphireException
     */
    public DataSet finalDataSetForSamplesStatusUpdate(String childsample) throws SapphireException{

        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("sampleid", DataSet.STRING);
        dsFinal.addColumn("cytostatus", DataSet.STRING);
        dsFinal.addColumn("currentmovementstep", DataSet.STRING);

//        String sql = Util.parseMessage(CytoSqls.GET_MAX_TRAMSTOP, StringUtil.replaceAll(childsample, ";", "','"), StringUtil.replaceAll(childsample, ";", "','"));
        String replacedSampleId = StringUtil.replaceAll(childsample, ";", "','");
        String sql = Util.parseMessage(CytoSqls.GET_MAX_TRAMSTOP, replacedSampleId, replacedSampleId, replacedSampleId, replacedSampleId);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        ds.sort("orgsampleid");
        ArrayList<DataSet> dsFinalArr = ds.getGroupedDataSets("orgsampleid");

        if(dsFinalArr!=null && dsFinalArr.size()>0){
            for(int i=0;i<dsFinalArr.size();i++){
                DataSet tempDs = dsFinalArr.get(i);
                if(tempDs!=null && tempDs.size()>0){
                    String maxCytostatus = tempDs.getValue(0, "u_cytostatus");
                    String maxCurrentmovementstep = tempDs.getValue(0, "u_currentmovementstep");
                    ArrayList<String> childsampleList = new ArrayList<String>(Arrays.asList(childsample.split(";")));
                    ArrayList<String> singleOrgsamplefromQueryList = new ArrayList<String>(Arrays.asList(tempDs.getColumnValues("childsampleid", ";").split(";")));
                    childsampleList.retainAll(singleOrgsamplefromQueryList);
                    for (String str : childsampleList) {
                        int rowId = dsFinal.addRow();
                        if (Constants.WET_LAB_STATUS_LIST.contains(maxCytostatus)) {
                            dsFinal.setValue(rowId, "sampleid", str);
                            dsFinal.setValue(rowId, "cytostatus", "Ready for 1st Analysis");
                            dsFinal.setValue(rowId, "currentmovementstep", "CytoTech1");

                        } else {
                            dsFinal.setValue(rowId, "sampleid", str);
                            dsFinal.setValue(rowId, "cytostatus", maxCytostatus);
                            dsFinal.setValue(rowId, "currentmovementstep", maxCurrentmovementstep);
                        }
                    }
                }
            }
        }
        return dsFinal;
    }

}
