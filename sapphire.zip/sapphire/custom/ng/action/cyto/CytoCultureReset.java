package sapphire.custom.ng.action.cyto;

/* 
 * Create by Subhendu
 * 
 * */

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.action.RecordIncident;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CytoCultureReset extends BaseAction{

	private final static String columnNames = " culturetypeid,sampleculturemapdesc,amountinoculated,"
			+"isflask,u_sampleculturemapid,orgculturetype";
	private String CULTUREMAPID_FOR_LABEL = "";

	public void processAction(PropertyList properties) throws SapphireException {
        
		String culturetype = StringUtil.replaceAll(properties.getProperty("culturetype"), "|", ";");
		String parentSampleId = properties.getProperty("parentSampleId");
		String childsampleid = properties.getProperty("childsampleid");
		String auditreason = properties.getProperty("auditreason");
		String selectedSampleIdForReset = StringUtil.replaceAll(properties.getProperty("selectedSampleIdForReset"), "|", ";");
		parentSampleId=StringUtil.replaceAll(parentSampleId,"|",";");
		parentSampleId=StringUtil.replaceAll(parentSampleId,"%3B",";");
		culturetype=StringUtil.replaceAll(culturetype,"%3B",";");
		selectedSampleIdForReset=StringUtil.replaceAll(selectedSampleIdForReset,"%3B",";");
//		String orgSampleId = properties.getProperty("freshprepsampleid");
		try {
			PropertyList autoCustodyProp = new PropertyList();
			autoCustodyProp.setProperty("sampleid", Util.getUniqueList(childsampleid, ";", true));

			getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
		}catch(SapphireException ex){
			throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
		}
		if(Util.isNull(culturetype) || Util.isNull(parentSampleId) || Util.isNull(selectedSampleIdForReset))
			 throw new SapphireException("CultureType/Parent Sample/Child Sample Id not found");

		String culturetypeArr[]=StringUtil.split(culturetype,";");
		String selectedSampleIdForResetArr[]=StringUtil.split(selectedSampleIdForReset,";");
		String parentSampleIdArr[]=StringUtil.split(parentSampleId,";");

		if(parentSampleIdArr!=null && selectedSampleIdForResetArr!=null && parentSampleIdArr.length==1 && parentSampleIdArr.length!=selectedSampleIdForResetArr.length){
			parentSampleId=StringUtil.repeat(parentSampleId,selectedSampleIdForResetArr.length,";");
			parentSampleIdArr =StringUtil.split(parentSampleId,";");
		}

		if(culturetypeArr==null || selectedSampleIdForResetArr==null && parentSampleIdArr==null ||
				(culturetypeArr.length!=selectedSampleIdForResetArr.length) || (selectedSampleIdForResetArr.length!=parentSampleIdArr.length))
			throw new SapphireException("Culturetype Ids, Parent Sample Ids, Child Sample Ids are not obtained properly as an input");

		for(int i=0;i<parentSampleIdArr.length;i++) {
			float finalVol = Float.parseFloat(validateSpecimenVolumeAmount(parentSampleIdArr[i], selectedSampleIdForResetArr[i]));
			if (finalVol >= 0) {
				String childSampleId = createMultiChildSample(parentSampleIdArr[i], culturetypeArr[i]);
				createNewResetCulture(childSampleId, parentSampleIdArr[i], culturetypeArr[i], selectedSampleIdForResetArr[i], auditreason);
				if(!Util.isNull(CULTUREMAPID_FOR_LABEL)){
					PropertyList props = new PropertyList();
					props.setProperty(PrintLabel.SDCID_PROP, "SampleCultureMap");
					props.setProperty(PrintLabel.KEYID1_PROP, CULTUREMAPID_FOR_LABEL);
					props.setProperty("labelmethodid", "CytoCultureLbl");
					try {
						getActionProcessor().processAction("PrintLabel", "1", props);
					} catch (SapphireException e) {
						String errMSG = getTranslationProcessor().translate("Action failed. Unbale to Print Label for Reset-Cultures from Cyto-Setup. ");
						throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
					}
				}
				CULTUREMAPID_FOR_LABEL="";
//				attachParentSampleTestCode(parentSampleIdArr[i], childSampleId);
				Util.copyTestCodeFromParent(childSampleId, getQueryProcessor(), getActionProcessor(),"Cytogenetics");
				updateRemainingSpecimen(String.valueOf(finalVol), parentSampleIdArr[i]);

			} else
				throw new SapphireException("Reseting selected Culture is not possible since the Specimen Remaining Volume is not sufficient");
		}
		if(!Util.isNull(parentSampleId)) {
			parentSampleId=Util.getUniqueList(parentSampleId,";",true);
			parentSampleIdArr=StringUtil.split(parentSampleId,";");
			if(parentSampleIdArr!=null && parentSampleIdArr.length>0) {
				for(int i=0;i<parentSampleIdArr.length;i++) {
					properties.setProperty("msg", createIncidentRequest(parentSampleIdArr[i]));
				}
			}
		}
    }
	
	public String createMultiChildSample(String parentsample, String culturetype) throws SapphireException {
       
        String[] culturetypeArr = StringUtil.split(culturetype, ";");
        PropertyList props = new PropertyList();
        if (culturetypeArr != null) {
            
            props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentsample);
            props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "" + culturetypeArr.length);
            props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_cytoid");
            try {
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Cannot create child samples.");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
        }
        return props.getProperty("newkeyid1", "");
    }
	
	 public void createNewResetCulture(String childsample, String parentsample, String culturetype,String selectedSampleIdForReset,String auditreason) throws SapphireException {

		DataSet ds = getOriginalCultureDetails(parentsample,selectedSampleIdForReset,culturetype);

		PropertyList props = new PropertyList();
		props.setProperty(AddSDI.PROPERTY_SDCID, "SampleCultureMap");
		props.setProperty(AddSDI.PROPERTY_COPIES, "" + (StringUtil.split(childsample, ";").length));
		props.setProperty("parentsampleid", StringUtil.repeat(";"+parentsample, ds.size()).substring(1));
		props.setProperty("childsampleid", childsample);
		 if(!Util.isNull(auditreason))
			 props.setProperty("resetreason",StringUtil.repeat(auditreason,(StringUtil.split(childsample, ";").length),";"));
		//props.setProperty("childsampleid", orderedChildsampleid);
		props.setProperty("operation", StringUtil.repeat("Reset", childsample.split(";").length, ";"));


		if(ds!= null && ds.size()>0){
			modifyCultureFlaskName(ds);
			resetOriginalCulture(selectedSampleIdForReset);
			for(int i =0;i<ds.getColumns().length;i++){
				 if(!ds.getColumns()[i].trim().equalsIgnoreCase("resetcount") && !ds.getColumns()[i].trim().equalsIgnoreCase("u_sampleculturemapid"))
					props.setProperty(ds.getColumns()[i], ds.getColumnValues(ds.getColumns()[i],";"));
			}
			props.setProperty("parentsampleculturemapid", ds.getColumnValues("u_sampleculturemapid",";"));

		}else
			throw new SapphireException("Fresh Prep/Original Sample Id not found ");
		
		try {
			getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
			CULTUREMAPID_FOR_LABEL = props.getProperty(AddSDI.RETURN_NEWKEYID1,"");
		} catch (Exception e) {
			String errMsg = getTranslationProcessor()
					.translate("Something went wrong. Please contact to administrator");
			errMsg += "\nError Detail:" + e.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
	   }
	 
	 public void modifyCultureFlaskName(DataSet ds)  throws SapphireException{
		 
		 int normalFlskCnt=Integer.parseInt(ds.getValue(0, "flaskcount","0"));
		 int flaskStartNum = 65+normalFlskCnt;
//		 if(tempDS == null || tempDS.size() >26)
//			 throw new SapphireException("Already 26 Flask created for this sample id");

		 if(normalFlskCnt>26)
			 throw new SapphireException("Already 26 Flask created for this sample id");
		 
		for (int i=0; i<ds.size();i++){

			String tempOrgCultype=ds.getValue(i,"orgculturetype","");
			if(Util.isNull(tempOrgCultype))
				ds.setValue(i,"orgculturetype",ds.getValue(i, "culturetypeid"));
			if("Y".equalsIgnoreCase(ds.getValue(i, "isflask"))){
				if(flaskStartNum >90 )
					throw new SapphireException("Cannot create more than 26 Flask the sample ");
				
				ds.setValue(i, "culturetypeid", "Flask "+(char)flaskStartNum);
				flaskStartNum++;
			}
			else{
				String cultureName = "";
				String cnt = ds.getValue(i, "resetcount","");
				if(Util.isNull(tempOrgCultype)) {
					if("1".equalsIgnoreCase(cnt))
						cultureName = ds.getValue(i, "culturetypeid") + "-RS" ;
					else
						cultureName = ds.getValue(i, "culturetypeid") + "-RS" + cnt;
				}
				else {
					if("1".equalsIgnoreCase(cnt))
						cultureName = tempOrgCultype + "-RS";
					else
						cultureName = tempOrgCultype + "-RS" + cnt;
				}
				ds.setValue(i, "culturetypeid", cultureName);

			}
		}
	 }
		
	  public DataSet getOriginalCultureDetails(String parentsample,String cytoCultureIds,String culturetype){
		  String sql = Util.parseMessage(CytoSqls.GET_CULTUREDETIALS,columnNames, parentsample,parentsample,parentsample,StringUtil.replaceAll(culturetype,";","','"));
		  DataSet ds = getQueryProcessor().getSqlDataSet(sql);

		  return ds;
	  }
	  
	 
	 public void attachParentSampleTestCode(String parentsample, String childsample) throws SapphireException {
		if (Util.isNull(parentsample)) 
			throw new SapphireException("Parent Sample not found for copyparentsampletestcode method");
		
		if (Util.isNull(childsample)) 
			throw new SapphireException("Child Samples not found for copyparentsampletestcode method");
		
		String sql = Util.parseMessage(CytoSqls.TESTCODE_FOR_CHILDSAMPLE_SQL,StringUtil.replaceAll(parentsample, ";", "','"));
		DataSet dsTestCode = getQueryProcessor().getSqlDataSet(sql);
		if (dsTestCode != null) {
			String lvtestcodes = dsTestCode.getColumnValues("LVTESTCODEID", ";");
			PropertyList props = new PropertyList();
			props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, childsample);
			props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,
					StringUtil.repeat(lvtestcodes, (StringUtil.split(childsample, ";").length), ";"));
			props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE,"Y");
			try {
				getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
			} catch (SapphireException e) {
				String errMsg = getTranslationProcessor()
						.translate("Something went wrong. Please contact to administrator");
				errMsg += "\nError Detail:" + e.getMessage();
				throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
			}
		}
	}
	 
	 public String validateSpecimenVolumeAmount(String parentSampleId, String selectedSampleIdForReset){
		 String sql =  Util.parseMessage(CytoSqls.CALCULATE_SPECIMAN_VOLUME,StringUtil.replaceAll(selectedSampleIdForReset, ";", "','"),parentSampleId);
		 DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		 return ds.getValue(0, "finalvol","-1"); 
	 }
	 
	 public void updateRemainingSpecimen(String finalVol,String parentSampleId) throws SapphireException{
		 	try {
	            PropertyList props = new PropertyList();
	            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
	            props.setProperty(EditTrackItem.PROPERTY_KEYID1, parentSampleId);
	            props.setProperty("qtycurrent", finalVol);
				getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
			 } catch (ActionException e) {
				throw new SapphireException("Error while updating Remaining specimen volume");
			 }
	 }
	 public String createIncidentRequest(String parentSampleId)throws SapphireException{
		 String rid ="";
		 try {
			 String sql = Util.parseMessage(CytoSqls.VERIFY_DEPARTMENT,parentSampleId);
			 DataSet ds = getQueryProcessor().getSqlDataSet(sql);
			 if(ds!=null && ds.size() >0){
				 String currdepartment = ds.getValue(0, "custodialdepartmentid","");
				 if(!currdepartment.toLowerCase().endsWith("-cyto") && !"Y".equalsIgnoreCase(ds.getValue(0, "u_iscytoincidentcreated",""))){
					 PropertyList recordProp = new PropertyList();
		             recordProp.setProperty("sourcesdcid", "Sample");
		             recordProp.setProperty("sourcekeyid1", ds.getValue(0, "linkkeyid1",""));
		             recordProp.setProperty("incidentcategory", "UnPlanned");
		             recordProp.setProperty("incidentdesc", "Culture Reseted");
		             //recordProp.setProperty("u_message", "Culture Reseted, Specimen required for sample id "+ds.getValue(0, "linkkeyid1","")+" which needs to be sent back from "+ds.getValue(0, "todepartment","")+" department.");
		             recordProp.setProperty("u_message", "A culture has been reset. Please send sample ID "+ds.getValue(0, "linkkeyid1","")+" to the "+connectionInfo.getDefaultDepartment()+" Department.");
		             recordProp.setProperty("u_fromdepartment", connectionInfo.getDefaultDepartment());
		             recordProp.setProperty("incidentstatus", "InProgress");
		             recordProp.setProperty("reportedby", connectionInfo.getSysuserId());
		             recordProp.setProperty("departmentid", ds.getValue(0, "todepartment",""));
					 getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);
					 rid = "New Incident has been created:"+recordProp.getProperty(RecordIncident.RETURN_NEWKEYID1,"");
					 
					 recordProp.clear();
					 recordProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
					 recordProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getValue(0, "linkkeyid1",""));
					 recordProp.setProperty("u_iscytoincidentcreated", "Y");
			        try {
			            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, recordProp);
			        } catch (ActionException ae) {
			            throw new SapphireException("Error: Unable to update cyto incident status while reseting culture  \n" + ae.getMessage());
			        }
				 }
			 }else
				 Logger.logInfo("Fresh Prep department not found to create new incident request.");
			 
			} catch (ActionException e) {
				throw new  SapphireException("Unable to create new incident for Fresh Prep");
			}
		 return rid;
			 
	 }
	/*
	 * Created By Subhashree
	 * After reset the culture ,the original culture and slides belongs to that culture will be hidden in entire LV system.
	 */
	public void resetOriginalCulture(String cytoCultureIds)  throws SapphireException{

		String sampleculturemapsql = Util.parseMessage(CytoSqls.GET_TRACKITEMID_BY_CHILDSAMPLEID, StringUtil.replaceAll(cytoCultureIds, ";", "','"));
		DataSet dssampleculturemap = getQueryProcessor().getSqlDataSet(sampleculturemapsql);
		String samplecultureid="";
		if (dssampleculturemap != null && dssampleculturemap.size() > 0 ){
			samplecultureid= dssampleculturemap.getColumnValues("u_sampleculturemapid", ";");
		}
		if (!Util.isNull(samplecultureid)) {
			PropertyList props = new PropertyList();
			try {
				if (!Util.isNull(cytoCultureIds)) {
					props.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
					props.setProperty(EditSDI.PROPERTY_KEYID1, samplecultureid);
					//props.setProperty("activeflag", "N");
					props.setProperty("resetflag", "Y");
					getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

				}
			}catch (ActionException ae) {
				String error = getTranslationProcessor().translate("Unable to perform reset operation.");
				error += ae.getMessage();
				throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
			}
		}

		String slidesql = Util.parseMessage(CytoSqls.GET_SLIDE_CHILDSAMPLE_ID, StringUtil.replaceAll(samplecultureid, ";", "','"));
		DataSet dsslidechildsample = getQueryProcessor().getSqlDataSet(slidesql);
		String cytoslideid="";
		if (dsslidechildsample != null && dsslidechildsample.size() > 0 ){
			cytoslideid= dsslidechildsample.getColumnValues("u_cytoslidesid", ";");
		}

		PropertyList props1 = new PropertyList();
		try {
			if (!Util.isNull(cytoslideid)) {
				props1.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
				props1.setProperty(EditSDI.PROPERTY_KEYID1, cytoslideid);
				//props1.setProperty("activeflag", "N");
				props1.setProperty("resetflag", "Y");
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props1);

			}
		}catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Unable to perform reset operation.");
			error += ae.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
		}

	}
}
