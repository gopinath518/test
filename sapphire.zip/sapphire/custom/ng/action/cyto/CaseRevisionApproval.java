package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by rrmandal on 7/8/2017.
 */
public class CaseRevisionApproval extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid=properties.getProperty("freshpresampleid","");
        String fromtramstop=properties.getProperty("fromtramstop","");
        if(!Util.isNull(sampleid))
            updateRevieInfo(sampleid,fromtramstop);
    }

    private void updateRevieInfo(String sampleid,String fromtramstop) throws SapphireException{
        String sql= Util.parseMessage(CytoSqls.CASE_REVISION_NOT_APPROVED, StringUtil.replaceAll(sampleid,";","','"),fromtramstop);
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if(dsInfo!=null){
            if(dsInfo.size()==0)
                throw new SapphireException("The case "+sampleid+" does not have any revision pending");
            PropertyList pl=new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID,"CytoCaseRevisionDtl");
            pl.setProperty(EditSDI.PROPERTY_KEYID1,dsInfo.getColumnValues("u_cytocaserevisiondtlid",";"));
            pl.setProperty("reviewby",connectionInfo.getSysuserId());
            pl.setProperty("reviewdt","n");
            getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
        }
    }
}
