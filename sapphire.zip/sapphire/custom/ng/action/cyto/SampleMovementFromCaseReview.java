package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by aritra.banerjee on 5/24/2017.
 * The below Action moves the selected Case to either Tech 1 or Tech 2 or DirectorSignOut
 * Input Props -
 * keyid1(selected case) & totramstop (destination tramstop)
 */
public class SampleMovementFromCaseReview extends BaseAction {

    private static final String SAMPLE_PROPS = "keyid1";
    private static final String TO_TRAMSTOP = "totramstop";

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty(SAMPLE_PROPS);
        String totramstop = properties.getProperty(TO_TRAMSTOP);
        String freshprepsampleid = properties.getProperty("freshprepsampleid");
        String auditreason = properties.getProperty("auditreason");
        String moveStatus = "";
        String fromTramstop = "CaseReview";
        if (!Util.isNull(sampleid) && !Util.isNull(totramstop)) {

            String currentmovementstep = "";
            String cytostatus = "";

            if ("Tech1".equalsIgnoreCase(totramstop)) {
                currentmovementstep = "CytoTech1";
                cytostatus = "Ready for 1st Analysis";
                moveStatus = "Tech1 Analysis";
            } else if ("Tech2".equalsIgnoreCase(totramstop)) {
                currentmovementstep = "CytoTech2";
                cytostatus = "Ready for 2nd Analysis";
                moveStatus = "Tech2 Analysis";
            } else if ("DirectorSignOut".equalsIgnoreCase(totramstop)) {
                currentmovementstep = "CytoDirectorSignOut";
                cytostatus = "Pre-review Complete";
                moveStatus = "Director Sign Out";
            }


            String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_CASE_REVIEW, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            if (ds != null && ds.size() > 0) {

                String childsample = ds.getColumnValues("childsampleid", ";");
                if (!Util.isNull(childsample)) {

                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
                    props.setProperty("u_currentmovementstep", currentmovementstep);
                    props.setProperty("u_cytostatus", cytostatus);

                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Error: Unable to update the Movement Step for select specimens");
                    }

                    updateTrackitemForSamples(childsample, currentmovementstep); // Updates Trackitem
                    // removes lock from the case
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                    props.setProperty("u_cytopagelockflag", "(null)");

                    try{
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Unable to remove page lock configuration.Please Contact your Administrator.");
                    }

                    if (!"DirectorSignOut".equalsIgnoreCase(totramstop))
                        insertReviewAudit(freshprepsampleid, auditreason, fromTramstop, totramstop);
                    if ("DirectorSignOut".equalsIgnoreCase(totramstop)) {
                        String msg = "Selected Specimen(s) " + Util.getUniqueList(properties.getProperty("freshprepsampleid", ""), ";", true) + " have been moved to "+moveStatus;
                        String outScript = "<script>sapphire.page.navigate('rc?command=page&page=CytoCaseReviewList&sdcid=Sample','Y','_top',null);sapphire.alert('" + msg + "');</script>";

                        properties.setProperty("msg", outScript);
                    } else
                        properties.setProperty("msg", "Selected Specimen(s) " + Util.getUniqueList(properties.getProperty("freshprepsampleid", ""), ";", true) + " have been moved to " + moveStatus);
                }

            }
        }
    }

    /**
     * @param childsample
     * @param currentmovementstep
     * @throws SapphireException
     * @desc updating trackitem for selected samples .
     */
    public void updateTrackitemForSamples(String childsample, String currentmovementstep) throws SapphireException {

        if (!Util.isNull(childsample)) {

            PropertyList props = new PropertyList();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
            props.setProperty("u_currenttramstop", currentmovementstep);
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("currentstorageunitid", "(null)");
            props.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Error: Unable to update Current Tramstop for the selected specimen");
            }

            /*try {
                PropertyList autoCustodyProp = new PropertyList();
                childsample = Util.getUniqueList(childsample, ";", true);
                autoCustodyProp.setProperty("sampleid", childsample);
                autoCustodyProp.setProperty("tramstop", StringUtil.repeat(currentmovementstep, childsample.split(";").length,";"));

                getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
            }catch(SapphireException ex){
                throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
            }*/
        }

    }

    private void insertReviewAudit(String sampleid, String reason, String fromTramstop, String toTramstop) throws SapphireException {
        if (!Util.isNull(sampleid) && !Util.isNull(fromTramstop) && !Util.isNull(toTramstop)) {
            sampleid = Util.getUniqueList(sampleid, ";", true);
            String sampleIdArr[] = StringUtil.split(sampleid, ";");
            if (sampleIdArr != null && sampleIdArr.length > 0) {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoCaseRevisionDtl");
                pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(sampleIdArr.length));
                pl.setProperty("totramstop", StringUtil.repeat(toTramstop, sampleIdArr.length, ";"));
                pl.setProperty("fromtramstop", StringUtil.repeat(fromTramstop, sampleIdArr.length, ";"));
                pl.setProperty("sendby", StringUtil.repeat(connectionInfo.getSysuserId(), sampleIdArr.length, ";"));
                pl.setProperty("senddt", StringUtil.repeat("n", sampleIdArr.length, ";"));
                pl.setProperty("reason", StringUtil.repeat(reason, sampleIdArr.length, ";"));
                pl.setProperty("sampleid", sampleid);

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            }
        }
    }
}
