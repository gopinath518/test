package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by subhashree.dash on 4/2/2018.
 */
public class CheckInCytoReagent extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {

        String readentlotid = properties.getProperty("readentlotid");
        String storage = properties.getProperty("storage");
        if (Util.isNull(readentlotid))
            throw new SapphireException("Readent Lot Id cannot be obtained");
        if (Util.isNull(storage))
            throw new SapphireException("Storage Id is obtained as null");

        String sql = Util.parseMessage(CytoSqls.GET_STORAGEUNITID, StringUtil.replaceAll(storage, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null)
            throw new SapphireException("The below query cannot be executed.");
        if (ds.size() == 0)
            throw new SapphireException("The storageunitid " + storage + " is not valid");

        if (ds != null && ds.size() > 0) {
            String storageunitid = ds.getColumnValues("storageunitid", ";");

            if (!Util.isNull(storageunitid)) {
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, readentlotid);
                props.setProperty("custodialuserid", "(null)");
                props.setProperty("custodialdepartmentid", "(null)");
                props.setProperty("currentstorageunitid", storageunitid);

                try{
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

                } catch(ActionException e){
                    throw new SapphireException("Error: Unable to update storage unit ID for selected = "+readentlotid);
                }
            }
        }
    }
}