package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

import java.nio.file.*;
import java.util.List;

/**
 * Created by rrmandal on 8/4/2017.
 */
public class IkarosFilePrcoessFinishWatch extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String serverStartFlag=properties.getProperty("serverStartFlag","");
        String ikrosLabvantagePath = getPathForIkaros();
        if("Y".equalsIgnoreCase(serverStartFlag))
            ikrosFolderWatchPriorSrvrStrt(ikrosLabvantagePath);
//        else
//            startWatchService(ikrosLabvantagePath);

    }

//    private void startWatchService(String ikarosPath) throws SapphireException{
//        if(Util.isNull(ikarosPath))
//            throw new SapphireException("Ikaros path is obtained as null.");
//        try{
//            Path ikrosDir = Paths.get(ikarosPath);
//            WatchService ikrosWatcher = ikrosDir.getFileSystem().newWatchService();
//            ikrosDir.register(ikrosWatcher, StandardWatchEventKinds.ENTRY_DELETE);
//            WatchKey ikrosWatckKey = ikrosWatcher.take();
//            PropertyList pl = new PropertyList();
//
////            while(true) {
//
//                List<WatchEvent<?>> ikrosEvents = ikrosWatckKey.pollEvents();
//                for (WatchEvent event : ikrosEvents) {
//                    if (event.kind() == StandardWatchEventKinds.ENTRY_DELETE) {
//                        String slideName = event.context().toString();
//                        Logger.logInfo("Deleted::: " + slideName);
//                        pl.clear();
//                        pl.setProperty("slideName", slideName);
//                        pl.setProperty("serverStartFlag", "N");
//                        pl.setProperty("ikrosPath", ikarosPath);
//
//                        pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "CytoImageStatusChanger");
//                        pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
//                        pl.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
//                        pl.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
//
//                        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, pl);
//                    }
//                }
//
////	        }
//        }
//        catch (Exception exp){
//            throw new SapphireException(exp.getMessage());
//        }
//    }

    private String getPathForIkaros()throws SapphireException {
        String path = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH,"ikros.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds != null && ds.size()>0)
            path = ds.getValue(0, "propvalue");

        return path;
    }

    private void ikrosFolderWatchPriorSrvrStrt( String path) throws SapphireException {
        PropertyList pl=new PropertyList();
        pl.setProperty("serverStartFlag", "Y");
        pl.setProperty("ikrosPath", path);

        try {
            getActionProcessor().processAction("CytoImageStatusChanger", "1", pl);

//            pl.clear();
//            pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "IkarosFilePrcoessFinishWatch");
//            pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
//            pl.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
//            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, pl);

        } catch (Exception e) {
            throw new SapphireException("Error occured while processing pending file");
        }
    }

}


