package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 5/15/2017.
 * @desc : This action is used for taking custody of the selected samples.
 * Mandatory Input:
 * @param1 : CHILDSAMPLE Information
 * @param2 : Sample Information
 * @param3 : AUDIT_REASON Information
 * @param4 : From tramstop as FLAG Name
 * @throws SapphireException
 */

public class CytoTakeCustody extends BaseAction {

    private static final String CHILDSAMPLE_ID = "childsampleids";
    private static final String AUDIT_REASON = "auditreason";
    private static final String KEYID1_PROP = "keyid1";
    private static final String FLAG_PROP = "flag";

    public void processAction(PropertyList properties) throws SapphireException{

        String childsampleid = properties.getProperty(CHILDSAMPLE_ID);
        String auditreason = properties.getProperty(AUDIT_REASON);
        String currentuser = connectionInfo.getSysuserId();
        String currentUserDepartment=connectionInfo.getDefaultDepartment();
        String flag = properties.getProperty(FLAG_PROP);

        if("Tech1".equalsIgnoreCase(flag) || "Tech2".equalsIgnoreCase(flag) || "CaseReview".equalsIgnoreCase(flag)  || "DirectorSignOut".equalsIgnoreCase(flag) ){
            String sample = properties.getProperty(KEYID1_PROP);
            String currentmovementstep ="";
            if( "Tech1".equalsIgnoreCase(flag) )
                currentmovementstep = "CytoTech1";
            else if( "Tech2".equalsIgnoreCase(flag) )
                currentmovementstep = "CytoTech2";
            else if( "CaseReview".equalsIgnoreCase(flag) )
                currentmovementstep = "CytoCaseReview";
            else if( "DirectorSignOut".equalsIgnoreCase(flag) )
                currentmovementstep = "CytoDirectorSignOut";

            if(!Util.isNull(sample)) {
                takingCustodyForCytoSample(sample, auditreason, currentuser, currentUserDepartment, currentmovementstep);
            }
        }

        if(!Util.isNull(childsampleid)){
            //String childsampleArr[] =StringUtil.split(childsampleid,";");
            if(!Util.isNull(auditreason)){
                if(!Util.isNull(currentuser)){
                    if(!Util.isNull(currentUserDepartment)){

                            PropertyList props = new PropertyList();

                            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                            props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
                            props.setProperty(EditTrackItem.PROPERTY_AUDITREASON, auditreason);
                            props.setProperty("custodialuserid", currentuser);
                            props.setProperty("custodialdepartmentid", currentUserDepartment);
                            props.setProperty("currentstorageunitid", "(null)");

                            try {
                                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

                                if(!Util.isNull(childsampleid)){
                                    String sql = Util.parseMessage(CytoSqls.GET_SAMPLECULTUREMAPID_BY_CHILDSAMPLEID, StringUtil.replaceAll(childsampleid, ";", "','"));
                                    DataSet dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);
                                    if(dsCultureInfo!=null && dsCultureInfo.size()>0){
                                        props.clear();
                                        props.setProperty(EditSDI.PROPERTY_SDCID,"SampleCultureMap");
                                        props.setProperty(EditSDI.PROPERTY_KEYID1,dsCultureInfo.getColumnValues("u_sampleculturemapid",";"));
                                        props.setProperty("incubator","(null)");
                                        props.setProperty("hanabi","(null)");
                                        props.setProperty("thermotron","(null)");

                                        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,props);
                                    }
                                }

                            } catch (ActionException e) {
                                throw new SapphireException("Error: Unable to Take the Custody of selected sample :" + childsampleid);
                            }
                    }
                }
            }
        }
    }

    /**
     * @Desc Updates trackitem for the selected samples
     * @param sample
     * @param auditReason
     * @param currentUser
     * @param currentUserDepartment
     * @param currentMovementStep
     * @throws SapphireException
     */
    public void takingCustodyForCytoSample(String sample, String auditReason, String currentUser, String currentUserDepartment, String currentMovementStep) throws SapphireException {

        if(!Util.isNull(sample) && !Util.isNull(auditReason) && !Util.isNull(currentUser) && !Util.isNull(currentUserDepartment) && !Util.isNull(currentMovementStep)){

            String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TAKE_CUSTODY, currentMovementStep, StringUtil.replaceAll(sample, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            if(ds!=null && ds.size()>0){

                String childsample = ds.getColumnValues("childsampleid", ";");
                if(!Util.isNull(childsample)){

                    PropertyList props = new PropertyList();

                    props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsample);
                    props.setProperty(EditTrackItem.PROPERTY_AUDITREASON, auditReason);
                    props.setProperty("custodialuserid", currentUser);
                    props.setProperty("custodialdepartmentid", currentUserDepartment);
                    props.setProperty("currentstorageunitid", "(null)");

                    try{
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Error: Unable to Take the Custody of selected sample(s) :" + sample);
                    }
                }else{
                    throw new SapphireException("Error: Sample ID not found from Query...");
                }
            }else{
                throw new SapphireException("Error: Query not fetching the proper data...");
            }
        }else{
            throw new SapphireException("Error: No proper data found for Taking custody from current Tramstop...");
        }
    }


}
