package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by dkundu on 12/12/2016.
 */
public class MoveSampleToFreshPrep extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("s_sampleid");
        if (isNull(sampleids))
            throw new SapphireException("Error: No samples found to move back to FreshPrep");


        String reject = properties.getProperty("reject","");

        DataSet dsRoute = validateSamplesBeforeRouting(sampleids);
        DataSet dsCyto = routeToFreshPrep(dsRoute);
        updateRoutingSampleDataSet(dsRoute, dsCyto);
        updateSampleStatus(dsRoute,reject);
    }

    private String fetchingAssociatedCultureCount(String sampleids) throws SapphireException {

        String childsampleid = Util.parseMessage(CytoSqls.GET_CHILD_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(childsampleid);

        if (ds == null)
            throw new SapphireException("Error: Unable to perform query in database");
        if (ds.size() == 0)
            throw new SapphireException("Error : Selected sample is in 'Cancel' OR 'Move to FreshPrep' state. Please select correct sample ");


        String samplewithculture = "";
        String samplewithoutculture = "";
        String childsampleidArr[] = sampleids.split(";");
        HashMap hm = new HashMap();
        for (int i = 0; i < childsampleidArr.length; i++) {
            hm.clear();
            hm.put("orgsampleid", childsampleidArr[i]);
            if (ds.getFilteredDataSet(hm).size() != 0)
                samplewithoutculture = samplewithoutculture + ";" + childsampleidArr[i];
            else
                samplewithculture = samplewithculture + ";" + childsampleidArr[i];
        }
        if (!isNull(samplewithculture))
            throw new SapphireException("Error: Culture is associated with the selected sample OR sample status is not In Setup");

        return samplewithoutculture.substring(1);
    }

    private DataSet validateSamplesBeforeRouting(String sampleids) throws SapphireException {
        DataSet dsRoute = new DataSet();
        dsRoute.addColumn("sampleid", DataSet.STRING);
        dsRoute.addColumn("department", DataSet.STRING);

        String freshprepStatusSQL = parseMessage(CytoSqls.GET_FRESHPREP_STATUS, StringUtil.replaceAll(sampleids, ";", "','"), "%FreshPrep");
        DataSet dsSql = getQueryProcessor().getSqlDataSet(freshprepStatusSQL);
        if (dsSql == null)
            throw new SapphireException("Error: Unable to perform query in database");
        else if (dsSql.size() == 0)
            throw new SapphireException("Error: Unable to move samples to FreshPrep as given samples do not have any records " +
                    "in FreshPrep.\nQuery returned zero rows.SQL: " + freshprepStatusSQL);
        else {
            dsSql.addColumn("freshprepdept", DataSet.STRING);
            String samples[] = sampleids.split(";");
            HashMap<String, String> hmFilter = new HashMap<>();
            for (int i = 0; i < samples.length; i++) {
                hmFilter.clear();
                hmFilter.put("sampleid", samples[i]);
                DataSet dsFilter = dsSql.getFilteredDataSet(hmFilter);
                if (dsFilter.size() == 0)
                    throw new SapphireException("Error: Unable to move sample: " + samples[i] + " to FreshPrep as given samples do " +
                            "not have any records in FreshPrep.");
                else {
                    String fromdept = dsFilter.getValue(0, "fromdepartment");
                    if (isNull(fromdept))
                        throw new SapphireException("Error: No FreshPrep department name found for sampleid " + samples[i]);
                    else {
                        int rowid = dsRoute.addRow();
                        dsRoute.setValue(rowid, "sampleid", dsFilter.getValue(0, "sampleid"));
                        dsRoute.setValue(rowid, "department", dsFilter.getValue(0, "fromdepartment"));
                    }
                }
            }
        }
        return dsRoute;
    }

    private DataSet routeToFreshPrep(DataSet dsRoute) throws SapphireException {
        if (dsRoute == null || dsRoute.size() == 0)
            throw new SapphireException("Error: No samples found to move back to FreshPrep");
        String cytoOrigNDummyIdSql = parseMessage(CytoSqls.GET_SAMPLES_WITH_ORIG_OR_DUMMYID, "orgsampleid","orgsampleid",
                StringUtil.replaceAll(dsRoute.getColumnValues("sampleid", ";"), ";", "','"));
        DataSet dsCyto = getQueryProcessor().getSqlDataSet(cytoOrigNDummyIdSql);
        if (dsCyto == null)
            throw new SapphireException("Error: No samples found to move back to FreshPrep");
        else if (dsCyto.size() == 0)
            throw new SapphireException("Error: Unable to move non Cytogenetics samples");
        else
            return dsCyto;

    }

    private void updateRoutingSampleDataSet(DataSet dsRoute, DataSet dsCyto) throws SapphireException {
        if (dsRoute == null || dsCyto == null || dsRoute.size() == 0 || dsCyto.size() == 0)
            throw new SapphireException("Error: Empty DataSet recived while routing Cytogenetics samples to FreshPrep");
        dsRoute.addColumn("cytodummysampleid", DataSet.STRING);
        dsRoute.addColumn("orgmvsteps", DataSet.STRING);
        dsRoute.addColumn("dummymvsteps", DataSet.STRING);
        HashMap<String, String> hmFilter = new HashMap<>();
        for (int i = 0; i < dsRoute.size(); i++) {
            hmFilter.clear();
            hmFilter.put("orgsampleid", dsRoute.getValue(i, "sampleid"));
            DataSet dsFilter = dsCyto.getFilteredDataSet(hmFilter);
            if (dsFilter.size() == 0)
                throw new SapphireException("Error: Unable to move non Cytogenetics samples");
            else {
                dsRoute.setValue(i, "cytodummysampleid", dsFilter.getValue(0, "cytodummysampleid"));
                dsRoute.setValue(i, "orgmvsteps", "FPCOCComplete");
                dsRoute.setValue(i, "dummymvsteps", "CytoSetup");
            }
        }

    }

    private void updateSampleStatus(DataSet dsRoute,String reject) throws SapphireException {
        PropertyList props = new PropertyList();
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsRoute.getColumnValues("sampleid", ";") + ";" + dsRoute.getColumnValues("cytodummysampleid", ";"));

        if("Y".equalsIgnoreCase(reject))
            props.setProperty("u_cytostatus", StringUtil.repeat("Rejected",dsRoute.size(),";")+";"+StringUtil.repeat("Rejected",dsRoute.size(),";"));

        props.setProperty("u_currentmovementstep", dsRoute.getColumnValues("orgmvsteps", ";") + ";" + dsRoute.getColumnValues("dummymvsteps", ";"));
        props.setProperty("bypassorgsampleedit", "Y");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            throw new SapphireException("Error: Unable to update sample while routing to FreshPrer \n" + ae.getMessage());
        }

        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsRoute.getColumnValues("sampleid", ";"));
        props.setProperty("custodialuserid", "(null)");
        props.setProperty("custodialdepartmentid", dsRoute.getColumnValues("department", ";"));
        props.setProperty("u_currenttramstop", dsRoute.getColumnValues("orgmvsteps", ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (ActionException ae) {
            throw new SapphireException("Error: Unable to update Trackitem\n" + ae.getMessage());
        }
    }
}