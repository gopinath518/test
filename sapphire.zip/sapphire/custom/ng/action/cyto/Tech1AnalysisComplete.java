package sapphire.custom.ng.action.cyto;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 5/22/2017.
 */
public class Tech1AnalysisComplete extends BaseAction {

    private static final String SAMPLE_PROPS = "keyid1";

    public void processAction(PropertyList properties) throws SapphireException{
        String sampleid = properties.getProperty(SAMPLE_PROPS);
        if(!Util.isNull(sampleid)){

            String sql = Util.parseMessage(CytoSqls.GET_CHILD_BY_PARENT_FOR_TECH1, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            if(ds!=null && ds.size() > 0){

                String childsample = ds.getColumnValues("childsampleid", ";");
                if(!Util.isNull(childsample)){

                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
                    props.setProperty("u_currentmovementstep", "CytoTech2");
                    props.setProperty("u_cytostatus", "Ready for 2nd Analysis");

                    try{
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Error: Unable to update the Movement Step for select specimens");
                    }

                    updateTrackitemForSamples(childsample);
                    String fpid = Util.getUniqueList(properties.getProperty("freshprepsampleid"),";", true);
                    updateReviewCmpltInfo(fpid);
                    // removes lock from the case
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                    props.setProperty("u_cytopagelockflag", "(null)");

                    try{
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception e) {
                        throw new SapphireException("Unable to remove page lock configuration.Please Contact your Administrator.");
                    }

                    String msg = "Selected Specimen(s) "+Util.getUniqueList(properties.getProperty("freshprepsampleid", ""), ";", true)+" have been moved to Tech 2 Analysis ";
                    String outScript = "<script>sapphire.page.navigate('rc?command=page&page=CytoTech1List&sdcid=Sample','Y','_top',null);sapphire.alert('"+msg+"');</script>";

                    properties.setProperty("msg", outScript);
                }

            } else
                throw new SapphireException("Unable to perform operation. Reason : No Slide(s) found to complete Analysis.");
        }
    }

    /**
     * @desc Updating 'u_currenttramstop' column as Cyto Tech2 for trackitem table.
     * @param childsample
     * @throws SapphireException
     */
    public void updateTrackitemForSamples(String childsample) throws SapphireException{

        if(!Util.isNull(childsample)){

            try {
                /*PropertyList autoCustodyProp = new PropertyList();
                childsample = Util.getUniqueList(childsample, ";", true);
                autoCustodyProp.setProperty("sampleid", childsample);
                autoCustodyProp.setProperty("tramstop", StringUtil.repeat("CytoTech2", childsample.split(";").length,";"));

                getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);*/

                PropertyList pl=new PropertyList();
                pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID,"Sample");
                pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1,childsample);
                pl.setProperty("custodialdepartmentid",connectionInfo.getDefaultDepartment());
                pl.setProperty("custodialuserid","(null)");
                pl.setProperty("currentstorageunitid","(null)");
                pl.setProperty("u_currenttramstop", "CytoTech2");

                getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID,pl);
            }catch(SapphireException ex){
                throw new SapphireException("Unable to update trackitem. Reason: "+ex.getMessage());
            }
        }
    }


    /**
     * @desc Updating Review info for Tech 1
     * @param fpid -Freshprep id
     * @throws SapphireException
     */
    public void updateReviewCmpltInfo(String fpid) throws SapphireException{

        if(!Util.isNull(fpid)){
            try {
                PropertyList props = new PropertyList();
                props.setProperty(AddSDI.PROPERTY_SDCID, "CytoCaseReviewDtl");
                props.setProperty(AddSDI.PROPERTY_COPIES, ""+fpid.split(";").length);
                props.setProperty("tech1rvwdt", "n");
                props.setProperty("tech1rvwedby", connectionInfo.getSysuserId());
                props.setProperty("sampleid", fpid);

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);

            }catch(SapphireException ex){
                throw new SapphireException("Unable to Add. Reason: "+ex.getMessage());
            }
        }
    }
}
