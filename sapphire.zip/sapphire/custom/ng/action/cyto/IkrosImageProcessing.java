package sapphire.custom.ng.action.cyto;
/*** 
 * Created By Subhendu - 2nd June 2017
 * The Class is used to monitor Labvantage side Ikros share Folder and upon dumping new img file from Ikros software a new row will be created in u_cytoslideimgmap table.  
 * */
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

import com.labvantage.sapphire.actions.sdi.EditSDI;
import com.labvantage.sapphire.actions.sdidata.AddDataSet;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.ExtendDataSet;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

public class IkrosImageProcessing extends BaseAction {
	
//	String slideName = "" ;
	String serverStartFlag="";

	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String slideName = properties.getProperty("slideName", "");
		serverStartFlag = properties.getProperty("serverStartFlag", "");
		String path = properties.getProperty("ikrosPath", "");
		String processFolderPath = properties.getProperty("processFolderPath", "");

		try {
			String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
			String successPath=path+"success"+File.separator+folderDt+File.separator;

			if ("Y".equalsIgnoreCase(serverStartFlag))
				processPendingFile(processFolderPath,successPath);
			else {
				processImgForSlide(slideName, processFolderPath,successPath);
				moveToSuccessFolder(processFolderPath, slideName,successPath);
			}
		} catch (Exception exp) {
			moveToFailureFolder(path,processFolderPath, slideName);
			throw new SapphireException("IkrosImageProcessing action cannot be executed. Reason: " + exp.getMessage());
		}

	}
	
	private void processImgForSlide(String slideName,String path,String successPath) throws SapphireException {
		try {
		String tempSlideName = slideName;
		String tempFileName = createFileNameForParsing(slideName);
		slideName = StringUtil.replaceAll(tempFileName,"@*@",".")+tempSlideName.substring((tempSlideName.lastIndexOf(".")));
		String[] tempArr = StringUtil.split(tempFileName, "@*@", true);
		String fSampleId = tempArr[0];
		String slideId = tempArr[1];
		String imgId = "";
		if(Util.isNull(tempArr[2]))
		 imgId = "1"+tempSlideName.substring((tempSlideName.lastIndexOf(".")));
		else
		 imgId = tempArr[2]+tempSlideName.substring((tempSlideName.lastIndexOf(".")));

		checkForExistingImgData(fSampleId,slideId, imgId,slideName,path,successPath);
		}catch (SapphireException e) {
			//throw new SapphireException("Error in processImgForSlide:: may be due filename format(Ex: FILENAME.SLIDEID.IMGNO.FILEEXTENSION ");
			throw new SapphireException("Error in processImgForSlide:: may be due to "+e);
		}
	}
	
	private void changeSlideStatus(String cytoSlideId, String slideStatus,String path) throws SapphireException {

		if(Util.isNull(cytoSlideId))
			throw new SapphireException("LvslideId for the slide obtained as input cannot found");
		
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "CytoSlides");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, cytoSlideId);
		pl.setProperty("slidestatus", slideStatus);
		try {
		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSION, pl);
		}catch (ActionException e) {
			throw new SapphireException("Error Occured while changeSlideStatus method:: "+e.getMessage());
		}
	}
	
	private void checkForExistingImgData(String fSampleId, String slideId, String imgId, String slideName,String path,String successPath) throws SapphireException{
		
		String sql = Util.parseMessage(CytoSqls.GET_EXISTING_SLIDE_IMG,fSampleId,slideId,imgId,fSampleId,slideId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);

		if(ds==null)
			throw new SapphireException("The sql: "+CytoSqls.GET_EXISTING_SLIDE_IMG+" can not be executed");
		
		if(ds.size() >0) {
			logger.info("Slide and Img combination already exists::"+fSampleId+"::"+imgId);
		}
		if(ds.size()==0) {
			sql = Util.parseMessage(CytoSqls.GET_PARENTID_BY_FSAMPLEID, fSampleId, slideId);
			DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
			if (tempDS.size() == 0)
				throw new SapphireException("Parent Sample Id not found for slide:: for fSampleId::" + fSampleId + "slideId::" + slideId);

			String lvSLideId=tempDS.getValue(0, "u_cytoslidesid", "");

//			if (WatchIkrosLabFolder.pendingSampleList == null)
//				throw new SapphireException("WatchIkrosLabFolder.pendingSampleList is obtained as null");
//			WatchIkrosLabFolder.pendingSampleList.add(fSampleId + "." + slideId);

			int copies;
			if(!Util.isNull(imgId)) {
				String imgIdArr[] = StringUtil.split(imgId,";");
				if(imgIdArr!=null) {
					copies = imgIdArr.length;
					if (copies == 0)
						throw new SapphireException("imgId.split is returning an array of length 0. The image id is obtained as " + imgId + ".");
					if (copies > 0) {
						PropertyList pl = new PropertyList();
						try {
							String reslutantImgSampleId="";
							for(int i=0;i<imgIdArr.length;i++){
								String tempImgId="";
								if(!Util.isNull(imgIdArr[i])){
									String tempArr[]=StringUtil.split(imgIdArr[i],".");
									if(tempArr!=null && tempArr.length>0) {
										String tempImgNo=tempArr[0];
										if(!Util.isNull(tempImgNo)) {
											if (tempImgNo.length() == 1)
												tempImgId = "00" + tempImgNo;
											else if (tempImgNo.length() == 2)
												tempImgId = "0" + tempImgNo;
											else
												tempImgId = tempImgNo;
										}
									}
								}
								if(!Util.isNull(tempImgId))
									reslutantImgSampleId+=";"+lvSLideId+tempImgId;
							}
							if(!Util.isNull(reslutantImgSampleId)) {
								if(reslutantImgSampleId.startsWith(";"))
									reslutantImgSampleId=reslutantImgSampleId.substring(1);

								pl.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
								pl.setProperty(AddSDI.PROPERTY_KEYID1,reslutantImgSampleId);
								pl.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY,"Y");
//								pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copies));

								getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

								String newKeyId = pl.getProperty(AddSDI.RETURN_NEWKEYID1);

								if (!Util.isNull(newKeyId)) {

									pl.clear();
									pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoSlideImgMap");
									pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copies));
									pl.setProperty("parentsampleid", StringUtil.repeat(tempDS.getValue(0, "parentsampleid"), copies, ";"));
									pl.setProperty("freshprepsampleid", StringUtil.repeat(tempDS.getValue(0, "freshprepsampleid"), copies, ";"));
									pl.setProperty("sampleid", newKeyId);
									pl.setProperty("cytoslideid", StringUtil.repeat(slideId, copies, ";"));
									pl.setProperty("lvslideid", StringUtil.repeat(lvSLideId, copies, ";"));
									pl.setProperty("imgid", imgId);
									pl.setProperty("imagepath", successPath + slideName);

									getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

									addParamForNewSample(newKeyId, copies, path);

									if (!Util.isNull(tempDS.getValue(0, "saminf", "")))
										addExtendedParamFornewSample(ds, newKeyId, copies, path);

									/*if(!"Y".equalsIgnoreCase(serverStartFlag))
										changeSlideStatus(lvSLideId, "ImageAnalysisPending", path);*/
								}
							}

						} catch (SapphireException e) {
							throw new SapphireException("Error Occured while checkForExistingImgData method:: " + e.getMessage());
						}
					}
				}
			}
		}
	}
	
	private void addParamForNewSample(String newKeyId, int copies,String path)throws SapphireException {
		
		PropertyList props = new PropertyList();
		props.setProperty(AddDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(AddDataSet.PROPERTY_KEYID1, newKeyId);
        props.setProperty(AddDataSet.PROPERTY_PARAMLISTID, StringUtil.repeat("CytoSlidePL",copies,";"));
        props.setProperty(AddDataSet.PROPERTY_PARAMLISTVERSIONID, StringUtil.repeat("1",copies,";"));
        props.setProperty(AddDataSet.PROPERTY_VARIANTID, StringUtil.repeat("1",copies,";"));
        
        try {
			getActionProcessor().processAction(AddDataSet.ID, AddDataSet.VERSIONID, props);
		} catch (ActionException e) {
			throw new SapphireException("Error Occured While adding dataset:: "+e.getMessage());
		}
	}
	private void addExtendedParamFornewSample(DataSet ds,String newKeyId, int copies,String path) throws SapphireException {
		 
		 	PropertyList plExtendDataSet = new PropertyList();
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_SDCID, "Sample" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_KEYID1, newKeyId );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_PARAMLISTID, "CytoSlidePL" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_PARAMLISTVERSIONID, "1" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_PARAMID, "A" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_VARIANTID, "1" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_DATASET, "1" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_PARAMTYPE, "Standard" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_NUMREPLICATE, "1" );
            plExtendDataSet.setProperty( ExtendDataSet.PROPERTY_PROPSMATCH, "Y" );
            try {
				getActionProcessor().processAction( ExtendDataSet.ID, ExtendDataSet.VERSIONID, plExtendDataSet );
			} catch (ActionException e) {
				throw new SapphireException("Error Occured While adding extended dataset:: "+e.getMessage());
			}
	 }
	
	 
	 private void processPendingFile(String path,String successPath) throws SapphireException {

		File f = new File(path);
		File[] files = f.listFiles();
		
		if (files != null) {
			for (int i = 0; i < files.length; i++) {
				File file = files[i];
				if (file.isFile())   {
					processImgForSlide(file.getName(),path,successPath);
					moveToSuccessFolder(path, file.getName(),successPath);
				}
			}
		}
	 }
	 
	 private void moveToSuccessFolder(String path,String fileName,String successPath) {
//		 String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		 File file = new File(path+fileName);
//		 File dir = new File(path+File.separator+"success"+File.separator+folderDt+File.separator);
		 File dir = new File(successPath);

	     if (!dir.exists())
             if(dir.mkdirs())
                 Logger.logInfo(dir.getPath()+":: created successfully"); 
		 
		 if (file.isFile() && dir.exists())   {
			 if(file.renameTo(new File(dir.getPath()+File.separator+file.getName())))
			     Logger.logInfo(file.getName()+":: File Moved to Success folder");
			 
			 if(file.delete())
                 Logger.logInfo(file.getName()+"::File delete from Source folder");
             else
                 Logger.logInfo("Unable to delete::"+file.getName()+":: file from Source folder");
		 }
	 }
	 
	 private void moveToFailureFolder(String path, String processFolderPath,String fileName) {
		 String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		 File file = new File(processFolderPath+fileName);
		 File dir = new File(path+File.separator+"failure"+File.separator+folderDt+File.separator);
		 if (!dir.exists())
			 if(dir.mkdirs())
			     Logger.logInfo(dir.getPath()+":: created successfully"); 
			     
		 if (file.isFile() && dir.exists())   {
			 if(file.renameTo(new File(dir.getPath()+File.separator+file.getName())))
			     Logger.logInfo(file.getName()+":: File Moved to Failure folder");
			 
			 if(file.delete())
                 Logger.logInfo(file.getName()+"::File delete from Source folder");
             else
                 Logger.logInfo("Unable to delete::"+file.getName()+":: file from Source folder");
		 }
	 }

	private String createFileNameForParsing(String fileName) throws SapphireException {

		String tempFileName = "";
		List<String> delimeterList = new ArrayList<String>(); // to store probable delimeter list from Policy
		//List<String> extensionList = new ArrayList<String>(); // to store probable extension list from Policy
		Map<String,Integer> colIndexMap = new LinkedHashMap<>();  // to store probable Col-Index pair from Policy

		PropertyList filePolicyProperties = getConfigurationProcessor().getPolicy("CytoMeteferFilePatternPolicy", "IkarosFileFormat");
		PropertyList pl = filePolicyProperties.getPropertyList("filepattern");

		PropertyListCollection delimeterColl = pl.getCollection("filepatterncollection");
		PropertyListCollection columnIndexColl = pl.getCollection("ColumnIndex");
		//PropertyListCollection extensioncoll = pl.getCollection("extensioncoll");

		for (int i = 0; i < delimeterColl.size(); i++)
			delimeterList.add(delimeterColl.getPropertyList(i).getProperty("delimeter"));

      /*  for (int i = 0; i < extensioncoll.size(); i++)
            extensionList.add(extensioncoll.getPropertyList(i).getProperty("extensiontype"));*/

		for (int i = 0; i < columnIndexColl.size(); i++)
			colIndexMap.put(columnIndexColl.getPropertyList(i).getProperty("column"),
					Integer.parseInt(columnIndexColl.getPropertyList(i).getProperty("index")));

		try {
			tempFileName = fileName.substring(0, (fileName.lastIndexOf(".")));
		} catch (Exception se){
			throw new SapphireException("No Proper extension found for the scanned file.\n"+fileName);
		}

		for(String s:delimeterList){
			if(tempFileName.contains(s)) {
				tempFileName=StringUtil.replaceAll(tempFileName,s.trim(),"@*@");
			}
		}

		if(!tempFileName.contains("@*@"))
			throw new SapphireException("No Proper delimeter defined in the policy for the scanned file.\n"+fileName);

		String[] tempArr = StringUtil.split(tempFileName, "@*@");

		String fsampleId = "";
		String slideId = "";
		String noOfslideCopy = "";

		Set<String> set = colIndexMap.keySet();
		for(String str:set){
			if("freshprepid".equalsIgnoreCase(str)){
				int index = colIndexMap.get(str);
				fsampleId = tempArr[index];
			}
			else if("slideid".equalsIgnoreCase(str)){
				int index = colIndexMap.get(str);
				slideId = tempArr[index];
			}
			else if("copy".equalsIgnoreCase(str)){
				int index = colIndexMap.get(str);
				noOfslideCopy = tempArr[index];
			}

		}
		return (fsampleId+"@*@"+slideId+"@*@"+noOfslideCopy);
	}
}
