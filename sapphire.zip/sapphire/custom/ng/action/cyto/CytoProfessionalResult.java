package sapphire.custom.ng.action.cyto;


import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created By Subhendu on 8th June 2017
 */
public class CytoProfessionalResult extends BaseAction {
    
   @Override
    public void processAction(PropertyList properties) throws SapphireException {
       
       String freshPrepId = properties.getProperty("freshprepid", "");
       String karyotype = properties.getProperty("karyotype", "");
       String interpretation = properties.getProperty("interpretation", "");
       String recommendation = properties.getProperty("recommendation", "");
       String comments = properties.getProperty("comments", "");
       
       String bandingFlag = properties.getProperty("bandingflag", "");
       String bandingResolution = properties.getProperty("bandingresolution", "");

       String metaphasesCounted = properties.getProperty("metaphasescounted", "");
       String metaphasesAnalyzed = properties.getProperty("metaphasesanalyzed", "");
       String metaphasesKaryotyped = properties.getProperty("metaphaseskaryotyped", "");

       String bandingTechnique = properties.getProperty("bandingtechnique", "");


       HashMap<String, String> profParamMap = new HashMap<String, String>();
       if("Y".equalsIgnoreCase(bandingFlag)) {
           profParamMap.put("Banding Resolution",bandingResolution);
       }
       else if("BTechnique".equalsIgnoreCase(bandingFlag)) {
           profParamMap.put("Banding Technique",bandingTechnique);
       }
       else {
           profParamMap.put("KARYOTYPE",karyotype);
           profParamMap.put("Interpretation",interpretation);
           profParamMap.put("Recommendation",recommendation);
           profParamMap.put("Comments",comments);
           profParamMap.put("Banding Resolution",bandingResolution);

           profParamMap.put("Metaphases Counted",metaphasesCounted);
           profParamMap.put("Metaphases Analyzed",metaphasesAnalyzed);
           profParamMap.put("Metaphases Karyotyped",metaphasesKaryotyped);
       }
       enterProfessionalResult(freshPrepId,profParamMap);
    }
   
   private void enterProfessionalResult(String freshprepid, HashMap<String, String> profParamMap) throws SapphireException {
       
       DataSet ds =  new DataSet();
       ds.addColumn(EnterDataItem.PROPERTY_KEYID1, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_PARAMLISTID, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_VARIANTID, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_DATASET, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_PARAMID, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_PARAMTYPE, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_REPLICATEID, DataSet.STRING);
       ds.addColumn(EnterDataItem.PROPERTY_ENTEREDTEXT, DataSet.STRING);

       if(!Util.isNull(freshprepid)) {
           freshprepid=Util.getUniqueList(freshprepid,";",true);
           String sql = Util.parseMessage(CytoSqls.GET_CHILD_SAMPLE_DESC, StringUtil.replaceAll(freshprepid, ";", "','"));
           DataSet parentSampleDS = getQueryProcessor().getSqlDataSet(sql);
           if(parentSampleDS==null)
               throw new SapphireException("The below query cannot be executed.\n"+sql);
           sql=Util.parseMessage(CytoSqls.ACTIVE_DATASET_INFO_BY_SAMPLEID,StringUtil.replaceAll(freshprepid, ";", "','"));
           DataSet dsPLInfo=getQueryProcessor().getSqlDataSet(sql);
           if(dsPLInfo==null)
               throw new SapphireException("The below query cannot be executed.\n"+sql);

           String[] freshprepidArr = StringUtil.split(freshprepid, ";", true);

           if(freshprepidArr!=null) {
               for (String fpid : freshprepidArr) {
                   HashMap<String, String> hmFp = new HashMap<>();
                   hmFp.put("destsampleid", fpid);
                   DataSet dsParentInfo = parentSampleDS.getFilteredDataSet(hmFp);
                   hmFp.clear();
                   hmFp.put("keyid1", fpid);
                   DataSet dsPLFIltr=dsPLInfo.getFilteredDataSet(hmFp);

                   if(dsPLFIltr!=null && dsPLFIltr.size()>0) {
                       for (String key : profParamMap.keySet()) {
                           int rowIndex = ds.addRow();
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_KEYID1, fpid);
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMLISTID, dsPLFIltr.getValue(0,"paramlistid",""));
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsPLFIltr.getValue(0,"paramlistversionid",""));
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_VARIANTID, dsPLFIltr.getValue(0,"variantid",""));
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_DATASET, dsPLFIltr.getValue(0,"dataset",""));
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMID, key);
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMTYPE, "Standard");
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_REPLICATEID, "1");
                           ds.setValue(rowIndex, EnterDataItem.PROPERTY_ENTEREDTEXT, profParamMap.get(key));

                           if (dsParentInfo != null && dsParentInfo.size() > 0) {
                               for (int i = 0; i < dsParentInfo.size(); i++) {
                                   rowIndex = ds.addRow();
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_KEYID1, dsParentInfo.getValue(i, "sourcesampleid"));
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMLISTID, dsPLFIltr.getValue(0,"paramlistid",""));
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsPLFIltr.getValue(0,"paramlistversionid",""));
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_VARIANTID, dsPLFIltr.getValue(0,"variantid",""));
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_DATASET, dsPLFIltr.getValue(0,"dataset",""));
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMID, key);
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_PARAMTYPE, "Standard");
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_REPLICATEID, "1");
                                   ds.setValue(rowIndex, EnterDataItem.PROPERTY_ENTEREDTEXT, profParamMap.get(key));
                               }
                           }
                       }
                   }
               }
           }
           if(ds!=null && ds.size()>0) {
               PropertyList pl = new PropertyList();

               pl.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
               pl.setProperty(EnterDataItem.PROPERTY_KEYID1, ds.getColumnValues(EnterDataItem.PROPERTY_KEYID1, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, ds.getColumnValues(EnterDataItem.PROPERTY_PARAMLISTID, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, ds.getColumnValues(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_VARIANTID, ds.getColumnValues(EnterDataItem.PROPERTY_VARIANTID, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_DATASET, ds.getColumnValues(EnterDataItem.PROPERTY_DATASET, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_PARAMID, ds.getColumnValues(EnterDataItem.PROPERTY_PARAMID, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, ds.getColumnValues(EnterDataItem.PROPERTY_PARAMTYPE, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_REPLICATEID, ds.getColumnValues(EnterDataItem.PROPERTY_REPLICATEID, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, ds.getColumnValues(EnterDataItem.PROPERTY_ENTEREDTEXT, ";"));
               pl.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");
               try {
                   getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, pl);
               } catch (SapphireException e) {
                   throw new SapphireException("Below error occurred while entering data.\n" + e.getMessage());
               }
           }
       }
   }

}
