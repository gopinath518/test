package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by achakraborty on 1/19/2017.
 * Author: dkundu
 */
public class CytoSubCulture extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String childsampleid = properties.getProperty("childsampleid");
        String mode = properties.getProperty("mode");
        String status = properties.getProperty("status");
        String auditreason = properties.getProperty("auditreason");

        if (Util.isNull(childsampleid))
            throw new SapphireException("Error: No cultures found");

        autoCustodyTransfer(childsampleid);

        if (Util.isNull(mode)) 
        	 throw new SapphireException("Error: Mode not found");

        int copies = 0;
        if(properties.getProperty("copy")!= null && Util.isInteger(properties.getProperty("copy")))
            copies = Integer.parseInt(properties.getProperty("copy"));

        DataSet dsParents = new DataSet();
        getSelectedCultureInformation( dsParents, childsampleid, copies, mode, status,auditreason);
        
        HashMap<String, String> paramValMap = new HashMap<String, String>();
        paramValMap.put("param1", StringUtil.replaceAll(properties.getProperty("freshprepsampleid", ""), ";", "\\',\\'"));

        updateOperationDate(childsampleid, mode);

        if("subculture".equals(mode))
        	properties.setProperty("msg", Util.setReturnURL("CytoFeedCultureList", "CulturesBySampleIdForFeed", paramValMap));
        
        else if("reharvest".equals(mode))
        	properties.setProperty("msg", "Please navigate to Feed Tramstop to get the Reharvested Culture for the below sample \n " +Util.getUniqueList(properties.getProperty("freshprepsampleid", ""), ";", true));
        
    }

    private void updateOperationDate(String childsampleid,String mode)throws SapphireException {

        DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_PARENT_OF_CULTURES, StringUtil.replaceAll(childsampleid, ";", "','")));

        if(!Util.isNull(ds.getColumnValues("u_sampleculturemapid", ";"))) {

            PropertyList editProp = new PropertyList();
            editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
            editProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampleculturemapid", ";"));
            if("redrop".equalsIgnoreCase(mode))
                editProp.setProperty("redropdt", "n");
            else if("reharvest".equalsIgnoreCase(mode))
                editProp.setProperty("reharvestdt", "n");

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Unable to edit "+mode+" date for selected culture(s).");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }

    /**
     * @desc getting selected culture information.
     * @param dsParents
     * @param childsampleid
     * @param copies
     * @param mode
     * @param status
     * @param auditreason
     * @throws SapphireException
     */
    private void getSelectedCultureInformation(DataSet dsParents, String childsampleid, int copies, String mode, String status,String auditreason)throws SapphireException {
    	DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_PARENT_OF_CULTURES, StringUtil.replaceAll(childsampleid, ";", "','")));
    	
    	 if (ds == null)
             throw new SapphireException("Error: Unable to perform query in database");
         else if (ds.size() == 0)
             throw new SapphireException("Error: No parent samples found for given cultures");

         ds.addColumn("subcultures", DataSet.STRING);
         ds.addColumn("querycondition", DataSet.STRING);

         for (int i = 0; i < ds.size(); i++) {
             dsParents.copyRow(ds, i, copies );
         }
        String subcultures="";
        if(!"redrop".equalsIgnoreCase(mode)) {
            subcultures = createSubcultureSamples(dsParents.getColumnValues("parentsampleid", ";"));
            getSubCultureMapping(dsParents,subcultures);
            sampleMappingwithSampleCultureMap( dsParents,  mode);
            new AddCulture().addSubcultures(dsParents, getQueryProcessor(), getActionProcessor(), status, mode, auditreason, connectionInfo.getDefaultDepartment());
            updateSubcultureCytoStatus(subcultures , status);
            autoCustodyTransfer(subcultures);
        }

         if("reharvest".equalsIgnoreCase(mode))
             updateSampleCultureMap(ds.getColumnValues("u_sampleculturemapid" , ";"));
        String batchid = "";
        if (!Util.isNull(mode)) {
            if("reharvest".equalsIgnoreCase(mode))
                batchid = "Reharvest";
            else if("redrop".equalsIgnoreCase(mode)) {
                batchid = "Redrop";
                updateRedropStatus(mode,status,childsampleid);
            }
        }
        if(!Util.isNull(batchid) && !Util.isNull(subcultures))
            updateBatchidForSubCultures(subcultures,batchid);

    }

    /**
     * @desc Get the deatils of newly created sub cultures from samplemap
     * @param dsParents
     * @param subcultures
     * @throws SapphireException
     */
    private void getSubCultureMapping(DataSet dsParents, String subcultures) throws SapphireException {
        DataSet dsSubCulture = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_CHILD_SAMPLE_DESC, StringUtil.replaceAll(subcultures, ";", "','")));
        if (dsSubCulture == null)
            throw new SapphireException("Error: Unable to perform query in database");

        for (int i = 0; i < dsSubCulture.size(); i++) {

            String prntSample = dsSubCulture.getValue(i, "sourcesampleid");
            if(!Util.isNull(prntSample)) {
                int rowNum = -1;
                for(int k=0;k<dsParents.size();k++){
                    String tempsubcultures=dsParents.getValue(k,"subcultures","");
                    String tempPrntSample=dsParents.getValue(k,"parentsampleid","");
                    if(!Util.isNull(tempPrntSample) && tempPrntSample.equalsIgnoreCase(prntSample) && Util.isNull(tempsubcultures)){
                        rowNum=k;
                        break;
                    }
                }

                if(rowNum>-1) {

                    dsParents.setValue(rowNum, "subcultures", dsSubCulture.getValue(i, "destsampleid"));
                    dsParents.setValue(rowNum, "visited", "Y");

                    String currOrgType = dsParents.getValue(rowNum, "orgculturetype");
                    if (Util.isNull(currOrgType))
                        dsParents.setValue(rowNum, "querycondition", dsParents.getValue(rowNum, "culturetypeid"));
                    else
                        dsParents.setValue(rowNum, "querycondition", currOrgType);
                }
            }
        }
    }

    /**
     * @param dsParents
     * @param mode
     * @throws SapphireException
     */
    private void sampleMappingwithSampleCultureMap(DataSet dsParents, String mode)throws SapphireException {
    	 String sql = Util.parseMessage(CytoSqls.GET_ORG_CULTURETYPE_COUNT, StringUtil.replaceAll(dsParents.getColumnValues("parentsampleid", ";"), ";", "','"), StringUtil.replaceAll(dsParents.getColumnValues("querycondition", ";"), ";", "','"),mode);
         String typeflag = "";
    	 if (!Util.isNull(mode)) {
 	        if("reharvest".equalsIgnoreCase(mode)) 
 	            typeflag = "RH";
 	        else if("redrop".equalsIgnoreCase(mode)) 
 	            typeflag = "RD";
         }
    	 
         DataSet dsCultureCount = getQueryProcessor().getSqlDataSet(sql);
         if (dsCultureCount == null) {
             throw new SapphireException("Error: Unable to perform query in database");
         }

         //Create a hash map that represents dsCultureCount DataSet
         HashMap<String, Integer> hmTypeCount = new HashMap();
         for (int i = 0; i < dsCultureCount.size(); i++) {
             String key = dsCultureCount.getValue(i, "parentsampleid") + "$" + dsCultureCount.getValue(i, "orgculturetype");
             hmTypeCount.put(key, dsCultureCount.getInt(i, "totalcount"));
         }

         //Add a column that will hold new culturetypes of subcultures
         dsParents.addColumn("newculturetypeid", DataSet.STRING);
         for (int i = 0; i < dsParents.size(); i++) {
             String typeUsedInQuery = dsParents.getValue(i, "querycondition");
             String parentsample = dsParents.getValue(i, "parentsampleid");
             String key = parentsample + "$" + typeUsedInQuery;
             Integer count = hmTypeCount.get(key);

             if (count == null) {
                 if(!Util.isNull(typeflag))
            	    dsParents.setValue(i, "newculturetypeid", (typeUsedInQuery + "-" + typeflag));
                 else
                     dsParents.setValue(i, "newculturetypeid", (typeUsedInQuery + "-1"));
                 hmTypeCount.put(key, 1);
             } else {
            	 dsParents.setValue(i, "newculturetypeid", (typeUsedInQuery + "-" + typeflag + (count + 1)));
                 hmTypeCount.put(key, count + 1);
             }
         }
    }

    /**
     * @desc Creating subculture samples.
     * @param parentsampleids
     * @return
     * @throws SapphireException
     */
    private String createSubcultureSamples(String parentsampleids) throws SapphireException {
        String newsamples = "";
        if(!Util.isNull(parentsampleids)) {
            String prntSampleArr[]=StringUtil.split(parentsampleids,";");
            if(prntSampleArr!=null && prntSampleArr.length>0) {
                PropertyList props = new PropertyList();
                for(int i=0;i<prntSampleArr.length;i++) {
                    props.clear();
                    props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, prntSampleArr[i]);
                    props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
                    props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;" +
                            "u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_cytoid;u_initialamount,u_initialvolunit,u_cellcount");
                    try {
                        getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
                        newsamples +=";"+ props.getProperty("newkeyid1");
                    } catch (SapphireException e) {
                        String errMsg = getTranslationProcessor().translate("Unable to create child samples.");
                        errMsg += "\nError Detail:" + e.getMessage();
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                    }
                }
            }
        }
        if(!Util.isNull(newsamples) && newsamples.startsWith(";"))
            newsamples=newsamples.substring(1);
        return newsamples;
    }

    /**
     * @desc Updating subculture status for sample table.
     * @param subcultures
     * @param status
     * @throws SapphireException
     */
    private void updateSubcultureCytoStatus(String subcultures , String status) throws SapphireException{
        PropertyList editProp = new PropertyList();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, subcultures);
        editProp.setProperty("u_cytostatus", "Ready for "+status);
        editProp.setProperty("u_currentmovementstep", "Cyto"+status);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Unable to edit cytostatus of subcultures");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        editProp.clear();
        editProp.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
        editProp.setProperty(EditTrackItem.PROPERTY_KEYID1, subcultures);
        editProp.setProperty("u_currenttramstop", "Cyto"+status);
        
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editProp);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Unable to edit current Tramstop of subcultures in Trackitem");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        
    }

    /**
     * @desc Update isHarvested column as 'Y' on sample culture map table culture mapid.
     * @param sampleculturemapid
     * @throws SapphireException
     */
    private void updateSampleCultureMap(String sampleculturemapid) throws SapphireException{
        PropertyList editProp = new PropertyList();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, sampleculturemapid);
        editProp.setProperty("isreharvested", "Y");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Unable to edit harvest flag of cultures");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    private void updateBatchidForSubCultures(String newChildSampls,String batchid) throws SapphireException{
        if(!Util.isNull(newChildSampls) && !Util.isNull(batchid)){
            DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_PARENT_OF_CULTURES, StringUtil.replaceAll(newChildSampls, ";", "','")));
            if(ds!=null && ds.size()>0){
                String sql=Util.parseMessage(CytoSqls.CYTOBATCHINFO_BYBATCHID,batchid);
                DataSet dsBatchInfo=getQueryProcessor().getSqlDataSet(sql);
                if(dsBatchInfo==null)
                    throw new SapphireException("Batch info is not found from database");
                if(dsBatchInfo.size()==0){
                    PropertyList prop = new PropertyList();
                    prop.setProperty(AddSDI.PROPERTY_SDCID,"CytoBatch");
                    prop.setProperty(AddSDI.PROPERTY_KEYID1,batchid);
                    prop.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY,"Y");
                    getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID,prop);
                }
                PropertyList editProp = new PropertyList();
                editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleCultureMap");
                editProp.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampleculturemapid" , ";"));
                editProp.setProperty("batchid", batchid);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
                } catch (ActionException ex) {
                    String error = getTranslationProcessor().translate("Unable to edit harvest flag of cultures");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
            }
        }
    }

    public void autoCustodyTransfer(String  sampleSubculturesId) throws SapphireException {
        try {
            PropertyList autoCustodyProp = new PropertyList();
            autoCustodyProp.setProperty("sampleid", Util.getUniqueList(sampleSubculturesId, ";", true));

            getActionProcessor().processAction("AutoCustodyTransfer", "1", autoCustodyProp);
        }catch(SapphireException ex){
            throw new SapphireException("Unable to take custody. Reason: "+ex.getMessage());
        }
    }

    public void  updateRedropStatus(String mode,String status,String childsampleid ) throws SapphireException  {

            DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_STATUS_BY_SAMPLE, StringUtil.replaceAll(childsampleid, ";", "','")));
            if (ds != null && ds.size() > 0) {
                ds.addColumn("newcytostatus", DataSet.STRING);
                for (int i = 0; i <= ds.size(); i++) {
                    ds.setValue(i,"newcytostatus",ds.getValue(i, "u_prevcytostatus"));
                }
                PropertyList props = new PropertyList();
                try {
                    if (!Util.isNull(childsampleid)) {
                        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                        props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
                        props.setProperty("u_cytostatus", ds.getColumnValues("newcytostatus", ";"));
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

                    }
                }catch (ActionException ae) {
                    String error = getTranslationProcessor().translate("Unable to perform redrop operation.");
                    error += ae.getMessage();
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
            }

    }

}
