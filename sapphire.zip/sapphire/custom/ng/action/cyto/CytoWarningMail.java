package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.SendMail;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by achakraborty on 12/12/2016.
 */
public class CytoWarningMail extends BaseAction {

    private static final String SENDMAIL_POLICY = "";
    private static final String NODEID_MAILPOLICY = "";
    public static final String PARENT_SAMPLEID = "keyid1";
    public static final String FROM_MAIL = "admin@hcl.com";
    public static final String MAIL_ADDRESS = "agniv.c@hcl.com";
    public static final String MAIL_SUBJECT = "Reagent Ids has been expired...";

    public void processAction(PropertyList properties) throws SapphireException {

        //String sampleid = properties.getProperty(PARENT_SAMPLEID);
        String sql = Util.parseMessage(CytoSqls.REAGENTLOT_WARNING_DATE);
        DataSet dssql = getQueryProcessor().getSqlDataSet(sql);
        String expirydt = dssql.getValue(0, "expirydt", "0");
        String expirydtArr[] = StringUtil.split(expirydt, ";");
        String reagentlot = dssql.getValue(0, "reagentlotid", "0");
        String reagentlotArr[] = StringUtil.split(reagentlot, ";");
        String MESSAGE = "Reagent Lot ids " + reagentlotArr + ". has been expired on" + expirydtArr;
        //sendMailForWarningReagent(SENDMAIL_POLICY);
        PropertyList props = new PropertyList();
        props.setProperty(SendMail.PROPERTY_FROM, FROM_MAIL);
        props.setProperty(SendMail.PROPERTY_SUBJECT, MAIL_SUBJECT);
        props.setProperty(SendMail.PROPERTY_ADDRESS, MAIL_ADDRESS);
        props.setProperty(SendMail.PROPERTY_MESSAGE, MESSAGE);
        try {
            getActionProcessor().processAction(SendMail.ID, SendMail.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Unable to send the Email...");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }
    /*public void sendMailForWarningReagent(String SENDMAIL_POLICY) throws SapphireException {
        PropertyList props = getConfigurationProcessor().getPolicy(SENDMAIL_POLICY,NODEID_MAILPOLICY);
    }*/
}
