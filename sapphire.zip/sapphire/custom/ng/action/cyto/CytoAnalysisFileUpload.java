package sapphire.custom.ng.action.cyto;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CytoAnalysisFileUpload extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String destFilename = "";
        String path = properties.getProperty("path", "");
        String comment = properties.getProperty("comment", "");
        String fpsampleid = properties.getProperty("freshprepsampleid", "");
        String ikrosExcelLabvantagePath = getLabvantageShareFolderPathIkros(fpsampleid);

        List<File> listoffiles = new ArrayList<>();
        List<File> finalListoffiles = new ArrayList<>();

        if (Util.isNull(path))
            throw new SapphireException("No Files have been uploaded. Please upload a file.");

        if (Util.isNull(fpsampleid))
            throw new SapphireException("No Fresh Prep sample id found..");

        String[] pathArr = StringUtil.split(path, ";");
        for (String s : pathArr)
            listoffiles.add(new File(s));


        if (listoffiles != null && listoffiles.size() > 0) {
            for (File file : listoffiles) {
                if (file.isFile()) {
                    long time = System.currentTimeMillis();
                    String fname = file.getName().substring(0, file.getName().lastIndexOf("."));
                    String extname = file.getName().substring(file.getName().lastIndexOf("."));
                    destFilename = fname + "_" + time + extname;
                    String fullFileName = ikrosExcelLabvantagePath + destFilename;

                    attachFile(fpsampleid, fullFileName, file.getName());
                    finalListoffiles.add(new File(fullFileName));

                    copyFileToDest(file, ikrosExcelLabvantagePath, destFilename);
                }
            }
        }

        DataSet dsFinal = createAttachmentDetail(fpsampleid, finalListoffiles);

        if (dsFinal.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(AddSDI.PROPERTY_SDCID, "CytoIkrsAnalysisAudt");
            pl.setProperty(AddSDI.PROPERTY_COPIES, ""+dsFinal.size());
            pl.setProperty("fpsampleid", fpsampleid);
            pl.setProperty("attachmentno", dsFinal.getColumnValues("attachmentno",";"));
            pl.setProperty("filename", dsFinal.getColumnValues("filename",";"));
            pl.setProperty("fileversion", dsFinal.getColumnValues("fileversion",";"));
            pl.setProperty("notes", comment);

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            } catch (Exception e) {
                throw new SapphireException("Unable to add record in CytoIkrsAnalysisAudt.");
            }
        }

    }

    private DataSet createAttachmentDetail(String fpsampleid, List<File> finalListoffiles) {

        int totalAttachmentNo = 0;
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("fpsample", DataSet.STRING);
        dsFinal.addColumn("attachmentno", DataSet.STRING);
        dsFinal.addColumn("filename", DataSet.STRING);
        dsFinal.addColumn("fileversion", DataSet.STRING);

        String sql = Util.parseMessage(CytoSqls.GET_ATTACHMENT_COUNT, fpsampleid);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds != null && ds.size() > 0)
            totalAttachmentNo = ds.getInt(0, "cnt", 0);

        int fileversion = totalAttachmentNo;

        for (File f : finalListoffiles) {
            int rowId = dsFinal.addRow();
            fileversion++;
            dsFinal.setValue(rowId, "fpsample", fpsampleid);
            dsFinal.setValue(rowId, "filename", f.toString());
            dsFinal.setValue(rowId, "fileversion", "" + fileversion);
        }

        String allFile = dsFinal.getColumnValues("filename", "','");
        sql = Util.parseMessage(CytoSqls.GET_ATTACHMENT_NUM, fpsampleid, allFile);
        DataSet dsSdiAttachement = getQueryProcessor().getSqlDataSet(sql);

        if (dsSdiAttachement != null && dsSdiAttachement.size() > 0) {
            for (int i = 0; i < dsFinal.size(); i++) {
                String filename = dsFinal.getValue(i, "filename");
                HashMap<String, String> hm = new HashMap();
                hm.put("filename", filename);

                DataSet dsfilter = dsSdiAttachement.getFilteredDataSet(hm);
                if (dsfilter.size() > 0) {
                    String num = dsfilter.getValue(0, "attachmentnum");
                    dsFinal.setValue(i, "attachmentno", num);
                }
            }
        }
        return dsFinal;
    }

    private void copyFileToDest(File file, String destPath, String destFilename) throws SapphireException {

        File dir = new File(destPath);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if (file.isFile() && dir.exists()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + destFilename)))
                Logger.logInfo(file.getName() + ":: File Moved to "+dir.getPath()+" folder");

            if (file.delete())
                Logger.logInfo(file.getName() + "::File delete from Source folder");
            else
                Logger.logInfo("Unable to delete::" + file.getName() + ":: file from Source folder");
        }

    }

    private String getLabvantageShareFolderPathIkros(String fpsampleid) throws SapphireException {
        String path = "";
        String fileLocation = "";

        String sql = Util.parseMessage(CytoSqls.GET_INSTRUMENT_SHARE_PATH, "ikros.share.folder");
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0)
            path = ds.getValue(0, "propvalue");

        DataSet inputList = new DataSet();
        inputList.addColumn("sponsorid",DataSet.STRING);
        inputList.addColumn("projectid",DataSet.STRING);

        String projectprotocolid = "";
        String sponsorname = "";

        sql = Util.parseMessage(CytoSqls.GET_SPONSOR_PROJECTNAME_BY_SPECIMENID, fpsampleid);
        DataSet dsSponDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponDetails != null && dsSponDetails.size() > 0) {
            sponsorname = dsSponDetails.getValue(0, "sponsorname");
            projectprotocolid = dsSponDetails.getValue(0, "projectprotocolid");
        }

        int rowId = inputList.addRow();
        inputList.setValue(rowId,"sponsorid",sponsorname);
        inputList.setValue(rowId,"projectid",projectprotocolid);
        fileLocation = Util.generateLocationPath(path, inputList);

        if(!fileLocation.endsWith(File.separator))
            return fileLocation + File.separator;
        else
            return fileLocation;
    }

    private void attachFile(String fpsampleid, String fullFileName,String actualfilename) throws SapphireException {

        PropertyList attachprop = new PropertyList();
        attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Sample");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, fpsampleid);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, fullFileName);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, actualfilename);
        attachprop.setProperty("u_attachmenttype", "CytoAnalysisReport");

        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("" + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }
}
