package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;
import static sapphire.custom.ng.util.Util.parseMessage;

/**
 * Created by rrmandal on 11/22/2016.
 */
public class MoveSampleToCyto extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String inputSampleIds=properties.getProperty("sampleid", "");
        inputSampleIds=Util.getUniqueList(inputSampleIds,";",true);
        String firstTimeCytoSamples = getFirstTimeCytoSamples(inputSampleIds);
        if( !isNull(firstTimeCytoSamples)) {
            PropertyList props = new PropertyList();
            //Create a dummy sample for every cyto sample
            props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, firstTimeCytoSamples);
            props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
            props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;" +
                    "u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_cytoid;u_initialamount,u_initialvolunit,u_cellcount");
            try {
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Cannot create child samples.");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            String chidSample = props.getProperty(MultiSampleChild.RETURN_NEWKEYID1,"");
            if(!Util.isNull(chidSample)) {
                //Retrieve original and corresponding dummy sampleid from samplemap
                String sqlString = Util.parseMessage(CytoSqls.GET_PARENT_DUMMY_SAMPLEID, "destsampleid", StringUtil.replaceAll(chidSample, ";", "','"));
                DataSet dsSql = getQueryProcessor().getSqlDataSet(sqlString);
                if (dsSql == null)
                    throw new SapphireException("Error: Unable to query Database\nSQL: " + sqlString);
                else if (dsSql.size() == 0)
                    throw new SapphireException("Error: No cyto dummy sample is present");
                else {
                    //Copy testcode from original sample id to dummy cyto sampleid
                    Util.copyTestCodeFromParent(dsSql.getColumnValues("cytodummysampleid", ";"), getQueryProcessor(), getActionProcessor(),"Cytogenetics");
                    //Create cyto sampleid for every dummy sampleid
                    createCytoSampleId(dsSql, properties.getProperty("sampleprefix"));
                    //Update cytosample id column for every dummysample id in Sample SDC
                    updateCytoSampleIdInSampleSDC(dsSql);
                    updateTrckItemForDummySamples(dsSql.getColumnValues("orgsampleid", ";"));
                }
            }
        }
    }

    private void createCytoSampleId(DataSet dsOrigCyto, String prefix) throws SapphireException {
        dsOrigCyto.addColumn("u_cytodummysampleid", DataSet.STRING);
        Integer year = new GregorianCalendar().get(Calendar.YEAR);
        prefix = prefix + (year.toString()).substring(2) + "-";

        /*StringBuilder sbSql = new StringBuilder();
        sbSql.append("select u_cytoid from s_sample where u_cytoid like '");
        sbSql.append(prefix);
        sbSql.append("%'");*/

//        String sql = Util.parseMessage(CytoSqls.GET_CURRENTSITE_CYTO_SAMPLEIDS, prefix + "%");
//        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
//        if (dsSql == null)
//            throw new SapphireException("Error:Unable to create cyto sampleid");
//        else if (dsSql.size() == 0) {
//            createSequence(0, dsOrigCyto, prefix);
//        } else {
//            int maxSequenceNumber = Integer.MIN_VALUE;
//            for (int i = 0; i < dsSql.size(); i++) {
//                String currentSampleid = dsSql.getValue(i, "u_cytoid", "");
//                int currentSequenceNumber = Integer.parseInt(currentSampleid.substring(currentSampleid.indexOf('-') + 1));
//                maxSequenceNumber = (currentSequenceNumber > maxSequenceNumber) ? currentSequenceNumber : maxSequenceNumber;
//            }
//            createSequence(maxSequenceNumber, dsOrigCyto, prefix);
//        }

        PropertyList props = new PropertyList();
        Integer numberOfEntries = dsOrigCyto.size();

        props.clear();
        props.setProperty(AddSDI.PROPERTY_SDCID, "CytoDummySample");
        props.setProperty(AddSDI.PROPERTY_COPIES, numberOfEntries.toString());
        props.setProperty("orgsampleid", dsOrigCyto.getColumnValues("orgsampleid",";"));
        props.setProperty("cytodummysampleid", dsOrigCyto.getColumnValues("cytodummysampleid",";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (ActionException ae) {
            throw new SapphireException("Unable to add dummy sample id of Cyto samples in CytoDummySample SDC");
        }

    }

    private void createSequence(Integer startSequence, DataSet dsCytoDummy, String prefix) throws SapphireException {
        String completeSequence = "";
        for (int i = 0; i < dsCytoDummy.size(); i++) {
            startSequence++;
            if (startSequence.toString().length() > 6)
                throw new SapphireException("Error: Unable to generate Cyto sampleid as it exceeds maximum length");
            int prefixZeros = 6 - startSequence.toString().length();
            for (int j = 0; j < prefixZeros; j++)
                completeSequence += "0";
            completeSequence += startSequence;
            dsCytoDummy.setValue(i, "u_cytodummysampleid", prefix + completeSequence);
            completeSequence = "";
        }
    }

    private void updateCytoSampleIdInSampleSDC(DataSet dsCytoDummy) throws SapphireException {
        PropertyList props = new PropertyList();
        //Update cyto id and cyto step for dummy samples
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsCytoDummy.getColumnValues("cytodummysampleid", ";"));
//        props.setProperty("u_cytoid", dsCytoDummy.getColumnValues("u_cytodummysampleid", ";"));
        props.setProperty("u_cytostatus", "Ready for Setup");
        props.setProperty("u_iscytoincidentcreated", "N");
        props.setProperty("u_currentmovementstep", "CytoSetup");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            throw new SapphireException("Error: Unable to update cyto sampleid(s)/cyto steps in Sample SDC\n" + ae.getMessage());
        }

/*        //Update cyto step for original samples
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsCytoDummy.getColumnValues("orgsampleid", ";"));
        props.setProperty("u_cytostatus", "Ready for Setup");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            throw new SapphireException("Error: Unable to update cyto steps in Sample SDC\n" + ae.getMessage());
        }*/
    }

    private void updateTrckItemForDummySamples(String parentSamples) throws SapphireException{
        if(!Util.isNull(parentSamples)){
            String sql = Util.parseMessage(CytoSqls.CYTODUMMYSAMPLE_TRACKITEM_INFO,StringUtil.replaceAll(parentSamples,";","','"));
            DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsInfo!=null && dsInfo.size()>0){
                PropertyList prop = new PropertyList();
                prop.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
                prop.setProperty(EditTrackItem.PROPERTY_KEYID1,dsInfo.getColumnValues("cytodummysampleid",";"));
                prop.setProperty("qtycurrent",dsInfo.getColumnValues("qtycurrent",";"));
                prop.setProperty("qtyunits",dsInfo.getColumnValues("qtyunits",";"));
                prop.setProperty("custodialuserid",dsInfo.getColumnValues("custodialuserid",";"));
                prop.setProperty("u_currenttramstop",dsInfo.getColumnValues("u_currenttramstop",";"));
                prop.setProperty("custodialdepartmentid",dsInfo.getColumnValues("custodialdepartmentid",";"));

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID,prop);
            }
        }
    }

    private String getFirstTimeCytoSamples(String sampleids) throws SapphireException{
        if(isNull(sampleids))
            throw new SapphireException("Error: No sampleid(s) found to route to Cytogenetics Setup");
        String dummyIdCheckSql = parseMessage(CytoSqls.GET_SAMPLES_WITH_ORIG_OR_DUMMYID,"orgsampleid","s_sample.s_sampleid",
                StringUtil.replaceAll(sampleids , ";" , "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(dummyIdCheckSql);
        if(dsSql == null)
            throw new SapphireException("Error: Unable to perform query in Database");
        else if(dsSql.size() == 0)
            return sampleids;
        else{
            String firstTimeCytoSamples = "";
            DataSet dsRecurringCytoSamples = new DataSet();
            String samples[] = sampleids.split(";");
            HashMap<String,String> hmFilter = new HashMap();
            for(int i = 0 ; i < samples.length ; i++){
                hmFilter.clear();
                hmFilter.put("orgsampleid" , samples[i]);
                DataSet dsTemp = dsSql.getFilteredDataSet(hmFilter);
                if( dsTemp.size() == 0)
                    firstTimeCytoSamples = firstTimeCytoSamples + ";" + samples[i];
                else
                    dsRecurringCytoSamples.copyRow(dsTemp , 0 , 1);
            }
//            if( dsRecurringCytoSamples.size() != 0 )
//                updateStatusForRecurringSamples(dsRecurringCytoSamples);
            if(isNull(firstTimeCytoSamples))
                return firstTimeCytoSamples;
            else
                return firstTimeCytoSamples.substring(1);
        }
    }

    private void updateStatusForRecurringSamples( DataSet dsRecurringCytoSamples) throws SapphireException{
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsRecurringCytoSamples.getColumnValues("orgsampleid", ";") + ";"
                +dsRecurringCytoSamples.getColumnValues("cytodummysampleid", ";"));
        props.setProperty("u_currentmovementstep", "CytoSetup");
        props.setProperty("u_cytostatus", "Ready for Setup");
        props.setProperty("u_iscytoincidentcreated", "N");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            throw new SapphireException("Error: Unable to update cyto sampleid(s)/cyto steps in Sample SDC\n" + ae.getMessage());
        }

    }

}