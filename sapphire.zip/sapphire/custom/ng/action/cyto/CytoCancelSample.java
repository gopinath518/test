package sapphire.custom.ng.action.cyto;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import java.util.HashMap;

/**
 * Created by achakraborty on 12/22/2016.
 */
public class CytoCancelSample extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String orgsample = properties.getProperty("orgsample","");
        String event = properties.getProperty("event","");
        String dummysampleid = properties.getProperty("dummysampleid","");
        String option = properties.getProperty("option","");
        String culture = properties.getProperty("culture","");
        if("SampleCancel".equalsIgnoreCase(event) && (Util.isNull(orgsample) || Util.isNull(dummysampleid))){
            throw new SapphireException("Please select atleast one item to cancel");
        }
        if("SampleCancel".equalsIgnoreCase(event)){
            String sql = Util.parseMessage(CytoSqls.GET_CULTURES_BY_PARENTSAMPLEID,StringUtil.replaceAll(dummysampleid,";","','"));
            DataSet dsCultureInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsCultureInfo!=null ){
                String samples="";
                if(dsCultureInfo.size()>0)
                    samples = orgsample+";"+dummysampleid+";"+dsCultureInfo.getColumnValues("childsampleid",";");
                else
                    samples=orgsample+";"+dummysampleid;
                if("Discard".equalsIgnoreCase(option)){
                    if(!Util.isNull(samples)){
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1,samples);
                        pl.setProperty("u_cytostatus","Unused");
                        pl.setProperty("samplestatus","Cancelled");
                        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
                    }
                }
                else if("Return".equalsIgnoreCase(option)){
                    if(!Util.isNull(samples)){
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1,samples);
                        pl.setProperty("u_cytostatus","Back To Freshprep");
                        pl.setProperty("samplestatus","Cancelled");
                        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);

                        pl.clear();

                        if(!Util.isNull(orgsample)) {
                            DataSet dsFPDeptInfo = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_FP_DEPT_OF_PATIENT_SAMPLE, StringUtil.replaceAll(orgsample, ";", "','")));
                            if(dsFPDeptInfo!=null && dsFPDeptInfo.size()>0) {
                                HashMap<String,String> fpSampleDeptMap = new HashMap<String,String>();
                                for(int i=0;i<dsFPDeptInfo.size();i++){
                                    fpSampleDeptMap.put(dsFPDeptInfo.getValue(i,"s_sampleid",""),dsFPDeptInfo.getValue(i,"dept",""));
                                }
                                if(fpSampleDeptMap.size()>0){
                                    String orgSampleArr[]=StringUtil.split(orgsample,";");
                                    String dummySampleArr[]=StringUtil.split(dummysampleid,";");
                                    if(orgSampleArr!=null && dummySampleArr!=null && orgSampleArr.length==dummySampleArr.length){
                                        HashMap<String,String> orgAndDummySampleMap = new HashMap<String,String>();
                                        for(int i=0;i<orgSampleArr.length;i++){
                                            orgAndDummySampleMap.put(dummySampleArr[i],orgSampleArr[i]);
                                        }
                                        if(orgAndDummySampleMap.size()>0) {
                                            for (int i = 0; i < dsCultureInfo.size(); i++) {
                                                String tempDummySampleId = dsCultureInfo.getValue(i, "parentsampleid", "");
                                                String tempCultureId = dsCultureInfo.getValue(i, "childsampleid", "");
                                                if (!Util.isNull(tempCultureId) && !Util.isNull(tempDummySampleId)) {
                                                    String tempOrgSampleid = orgAndDummySampleMap.get(tempDummySampleId);
                                                    if(!Util.isNull(tempOrgSampleid)){
                                                        String tempDept = fpSampleDeptMap.get(tempOrgSampleid);
                                                        if(!Util.isNull(tempDept)){
                                                            int rowIndex = dsFPDeptInfo.addRow();
                                                            dsFPDeptInfo.setValue(rowIndex,"s_sampleid",tempCultureId);
                                                            dsFPDeptInfo.setValue(rowIndex,"dept",tempDept);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                                pl.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFPDeptInfo.getColumnValues("s_sampleid",";"));
                                pl.setProperty("custodialdepartmentid", dsFPDeptInfo.getColumnValues("dept",";"));
                                pl.setProperty("custodialuserid", StringUtil.repeat("(null)",dsCultureInfo.size(),";"));
                                getActionProcessor().processAction(EditTrackItem.ID,EditTrackItem.VERSIONID,pl);
                            }
                        }
                    }
                }
                else if("Process".equalsIgnoreCase(option)){
                    if(!Util.isNull(samples)){
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1,samples);
                        pl.setProperty("samplestatus","Cancelled");
                        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
                    }
                }
            }
        }
        else if("CultureCancel".equalsIgnoreCase(event)){
            if(Util.isNull(culture))
                throw new SapphireException("Please select atleast one culture");
            if("Discard".equalsIgnoreCase(option)){
                if(!Util.isNull(culture)){
                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1,culture);
                    pl.setProperty("u_cytostatus","Unused");
                    pl.setProperty("samplestatus","Cancelled");
                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
                }
            }
            else if("Return".equalsIgnoreCase(option)){
                if(!Util.isNull(culture)){
                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1,culture);
                    pl.setProperty("u_cytostatus","Back To Freshprep");
                    pl.setProperty("samplestatus","Cancelled");
                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);

                    pl.clear();

                    if(!Util.isNull(orgsample)) {
                        DataSet dsFPDeptInfo = getQueryProcessor().getSqlDataSet(Util.parseMessage(CytoSqls.GET_FP_DEPT_OF_PATIENT_SAMPLE, StringUtil.replaceAll(orgsample, ";", "','")));
                        if(dsFPDeptInfo!=null && dsFPDeptInfo.size()>0) {
                            HashMap<String,String> fpSampleDeptMap = new HashMap<String,String>();
                            for(int i=0;i<dsFPDeptInfo.size();i++){
                                fpSampleDeptMap.put(dsFPDeptInfo.getValue(i,"s_sampleid",""),dsFPDeptInfo.getValue(i,"dept",""));
                            }
                            DataSet result = null;
                            if( fpSampleDeptMap.size()>0){
                                String orgSampleArr[]=StringUtil.split(orgsample,";");
                                String dummySampleArr[]=StringUtil.split(dummysampleid,";");
                                String cultureArr[]=StringUtil.split(culture,";");
                                if(orgSampleArr!=null && dummySampleArr!=null && cultureArr!=null && orgSampleArr.length==dummySampleArr.length && orgSampleArr.length==cultureArr.length){
                                    result=new DataSet();
                                    result.addColumn("s_sampleid",DataSet.STRING);
                                    result.addColumn("dept",DataSet.STRING);
                                    for (int i = 0; i < orgSampleArr.length; i++) {
                                        String tempDummySampleId = dummySampleArr[i];
                                        String tempCultureId = cultureArr[i];
                                        if (!Util.isNull(orgSampleArr[i]) && !Util.isNull(tempCultureId) && !Util.isNull(tempDummySampleId)) {
                                            String tempOrgSampleid = orgSampleArr[i];
                                            if(!Util.isNull(tempOrgSampleid)){
                                                String tempDept = fpSampleDeptMap.get(tempOrgSampleid);
                                                if(!Util.isNull(tempDept)){
                                                    int rowIndex = result.addRow();
                                                    result.setValue(rowIndex,"s_sampleid",tempCultureId);
                                                    result.setValue(rowIndex,"dept",tempDept);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if(result!=null && result.size()>0) {
                                pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                                pl.setProperty(EditTrackItem.PROPERTY_KEYID1, result.getColumnValues("s_sampleid", ";"));
                                pl.setProperty("custodialdepartmentid", result.getColumnValues("dept", ";"));
                                pl.setProperty("custodialuserid", StringUtil.repeat("(null)", result.size(), ";"));
                                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                            }
                        }
                    }
                }
            }
            else if("Process".equalsIgnoreCase(option)){
                if(!Util.isNull(culture)){
                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1,culture);
                    pl.setProperty("samplestatus","Cancelled");
                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
                }
            }
        }
    }
}
