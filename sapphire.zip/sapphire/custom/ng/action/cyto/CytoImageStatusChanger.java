
package sapphire.custom.ng.action.cyto;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CytoImageStatusChanger extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String serverStartFlag=properties.getProperty("serverStartFlag","");
        String ikrosPath=properties.getProperty("ikrosPath","");
        String slideName=properties.getProperty("slideName","");
        searchImgFolder(serverStartFlag,slideName,ikrosPath);
    }


    private  void searchImgFolder(String serverStartFlag,String inputFile,String ikrosPath)  throws SapphireException {
        String imgAnalysisNotPendingSlides = "";
//        String imgAnalysisNotPendingList = "";

        DataSet slideListToChk=null;

        if("Y".equalsIgnoreCase(serverStartFlag)){
            String sql= Util.parseMessage(CytoSqls.IMAGE_ANALYSIS_PENDING_SLIDE_LIST);
            slideListToChk=getQueryProcessor().getSqlDataSet(sql);
        }
        else{
            String[] tempArr = StringUtil.split(inputFile, ".", true);
            if(tempArr!=null && tempArr.length>1) {
                String fSampleId = tempArr[0];
                String slideId = tempArr[1];
                slideListToChk = new DataSet();
                slideListToChk.addColumn("fliename", DataSet.STRING);
                int rownum = slideListToChk.addRow();
                slideListToChk.setValue(rownum, "fliename", fSampleId+"."+slideId);
            }
        }

        if(slideListToChk!=null && slideListToChk.size()>0) {
            for (int i=0;i<slideListToChk.size();i++) {
                String fileName=slideListToChk.getValue(i,"fliename","");
                if(!Util.isNull(fileName)) {
                    String tempNotPendingSlide = processImgFile(fileName,ikrosPath);
                    if (!Util.isNull(tempNotPendingSlide)) {
//                    imgAnalysisNotPendingList += ";" + tempNotPendingSlide;// StringUtil.replaceAll(tempNotPendingSlide, ".", "#@#");
                        imgAnalysisNotPendingSlides += ";" + StringUtil.replaceAll(tempNotPendingSlide, ".", "#@#");
                    }
                }
            }
            if (!Util.isNull(imgAnalysisNotPendingSlides)) {
                if (imgAnalysisNotPendingSlides.startsWith(";"))
                    imgAnalysisNotPendingSlides = imgAnalysisNotPendingSlides.substring(1);
//                if (imgAnalysisNotPendingList.startsWith(";"))
//                    imgAnalysisNotPendingList = imgAnalysisNotPendingList.substring(1);



                String sql = Util.parseMessage(CytoSqls.GET_PARENTID_WITH_PENDING_SAMPLEID, StringUtil.replaceAll(imgAnalysisNotPendingSlides, ";", "','"));
                DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

                if (dsSampleInfo != null && dsSampleInfo.size() > 0) {

//                    String imgAnalysisNotPendingListArr[]=StringUtil.split(imgAnalysisNotPendingList,";");
//                    if(imgAnalysisNotPendingListArr!=null && imgAnalysisNotPendingListArr.length>0){
//                        for(int i=0;i<imgAnalysisNotPendingListArr.length;i++){
//                            if(WatchIkrosLabFolder.pendingSampleList.remove(imgAnalysisNotPendingListArr[i]))
//                                logger.info("Slide "+imgAnalysisNotPendingListArr[i]+" has been removed from pending list WatchIkrosLabFolder.pendingSampleList.");
//                            else
//                                logger.info("Slide "+imgAnalysisNotPendingListArr[i]+" can not be removed from pending list WatchIkrosLabFolder.pendingSampleList.");
//                        }
//                    }

                    PropertyList pl = new PropertyList();
                    pl.setProperty(sapphire.action.EditSDI.PROPERTY_SDCID, "CytoSlides");
                    pl.setProperty(sapphire.action.EditSDI.PROPERTY_KEYID1, dsSampleInfo.getColumnValues("u_cytoslidesid", ";"));
                    pl.setProperty("slidestatus", "(null)");

                    getActionProcessor().processAction(sapphire.action.EditSDI.ID, sapphire.action.EditSDI.VERSIONID, pl);
                }
            }
        }
    }
    
    private String processImgFile(String fileName,String ikrosPath) throws SapphireException {
        
        File f = new File(ikrosPath);
        File[] files = f.listFiles();
        boolean isPending=false;
        
        if (files != null && files.length >0) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile() && (file.getName().toUpperCase(Locale.ENGLISH)).startsWith(fileName.toUpperCase()))   {
                    isPending=true;
                    break;
                }
            }
        }
        if(!isPending) {
            return fileName;
        }
        return "";

     }

}
