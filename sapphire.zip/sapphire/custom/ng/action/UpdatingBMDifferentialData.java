package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDIWorkItem;
import sapphire.action.BaseAction;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
/**
 * Created by ssen on 11/4/2016.
 */
public class UpdatingBMDifferentialData extends BaseAction {
    /**
     * This action is used for FulroScan File parse.
     * @param properties
     * @throws sapphire.SapphireException
     * */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String paramlistid = "CBC PL";
        String paramlistversn = "1";
        String paramlistvarient = "1";
        String params = properties.getProperty("parameters", "");
        String values = properties.getProperty("values", "");
        String reportoptionid = properties.getProperty("reportoptionid", "");
        if (Util.isNull(params))
                throw new SapphireException("Parameters could not be blank");
        if(Util.isNull(values))
            throw new SapphireException("Parameter values could not be blank");
        if(Util.isNull(reportoptionid))
            throw new SapphireException("ReportOption id could not be blank");
        String paramsql ="select paramtype from PARAMLISTITEM where paramlistid='"+paramlistid+"' and" +
                " paramid  in('"+ StringUtil.replaceAll(params,";","','")+"')";
        DataSet dssql = getQueryProcessor().getSqlDataSet(paramsql);
        if(dssql == null || dssql.size()==0 )
            throw new SapphireException("Query"+paramsql+" is not returning any row ");
        String paramtype= dssql.getColumnValues("paramtype",";");
        String keyIdArr[]=StringUtil.split(reportoptionid,";");

        if(Util.isNull(paramtype))
            throw new SapphireException("Parameter type is not available for input parameters ");
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIWorkItem.PROPERTY_SDCID,"ReportOption");
        props.setProperty(AddSDIWorkItem.PROPERTY_KEYID1,reportoptionid);
        props.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID,paramlistid);
        props.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID,paramlistversn);
        props.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM,"Y");
        try {
            getActionProcessor().processAction(AddSDIWorkItem.ID, AddSDIWorkItem.VERSIONID, props);
        }
        catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String resultKeyId1 = "";
        String resultParamList = "";
        String resultParam = "";
        String resultParamValue = "";
        String resultVersion ="";
        String resultVarient ="";
        String resultDatasetNm ="";
        String resultParamType ="";
        String resultReplicate = "";
        String paramsarr[]=StringUtil.split(params,";");
        if(paramsarr==null || paramsarr.length==0)
            throw  new SapphireException("Array object conversion is not possible from the list of params");
        String paramList = StringUtil.repeat(paramlistid,paramsarr.length,";");
        String paramVersion = StringUtil.repeat(paramlistversn,paramsarr.length,";");
        String paramVarient = StringUtil.repeat(paramlistvarient,paramsarr.length,";");
        String replicate = StringUtil.repeat("1",paramsarr.length,";");
        String datasetnm = StringUtil.repeat("1",paramsarr.length,";");
        String paramListArr[] = StringUtil.split(paramList,";");

        if(keyIdArr!=null && keyIdArr.length>0){
            for(int i=0;i<keyIdArr.length;i++){
                for(int j=0;j<paramListArr.length;j++){
                   resultKeyId1+=";"+keyIdArr[i];
                }
                resultParamList+=";"+paramList;
                resultParamValue+=";"+values;
                resultParam+=";"+params;
                resultVersion+=";"+paramVersion;
                resultVarient+=";"+paramVarient;
                resultDatasetNm+=";"+datasetnm;
                resultReplicate+=";"+replicate;
                resultParamType+=";"+paramtype;
            }
        }

        if(!Util.isNull(resultParam)) {
            resultParamList = resultParamList.substring(1);
            resultParamValue = resultParamValue.substring(1);
            resultParam = resultParam.substring(1);
            resultVersion = resultVersion.substring(1);
            resultVarient = resultVarient.substring(1);
            resultDatasetNm = resultDatasetNm.substring(1);
            resultReplicate = resultReplicate.substring(1);
            resultParamType = resultParamType.substring(1);
            resultKeyId1 = resultKeyId1.substring(1);

            PropertyList props1 = new PropertyList();
            props1.setProperty(EnterDataItem.PROPERTY_SDCID, "ReportOption");
            props1.setProperty(EnterDataItem.PROPERTY_KEYID1, resultKeyId1);
            props1.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, resultParamList);
            props1.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, resultVersion);
            props1.setProperty(EnterDataItem.PROPERTY_VARIANTID, resultVarient);
            props1.setProperty(EnterDataItem.PROPERTY_DATASET, resultDatasetNm);
            props1.setProperty(EnterDataItem.PROPERTY_PARAMID, resultParam);
            props1.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, resultParamType);
            props1.setProperty(EnterDataItem.PROPERTY_REPLICATEID, resultReplicate);
            props1.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, resultParamValue);
            props1.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");
            try {
                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props1);
            } catch (SapphireException ex) {
                String error = getTranslationProcessor().translate("Action failed try again");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
    }
}
