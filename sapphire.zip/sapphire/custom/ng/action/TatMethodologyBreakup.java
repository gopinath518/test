/**
 * Created By Subhendu 27/11/2018
 */

package sapphire.custom.ng.action;

import java.util.ArrayList;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.TatCalculation;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class TatMethodologyBreakup extends BaseAction {

    public static String ID = "TatMethodologyBreakup";
    public static String VERSIONID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String mode = properties.getProperty("mode", "");
        DataSet intialPrimaryDS = null;
        DataSet primaryDS = new DataSet(properties.getProperty("primaryDS", ""));

        if ("UPDATE".equals(mode)) {
            intialPrimaryDS = new DataSet(properties.getProperty("intialprimaryds", ""));
            updateOperation(primaryDS, intialPrimaryDS, mode);
        } else if ("ADD".equals(mode))
            addOperation(primaryDS, mode);
//		throw new SapphireException("Test");

    }

    private void addOperation(DataSet primaryDS, String mode) throws SapphireException {
        if(primaryDS == null || primaryDS.size()==0){
            return;
        }
        primaryDS.sort("methodology");
        ArrayList<?> groupList = primaryDS.getGroupedDataSets("methodology");
        for (Object obj : groupList) {
            DataSet methodologyDS = (DataSet) obj;
            if (methodologyDS != null && methodologyDS.size() > 0) {
                String methodology = methodologyDS.getValue(0, "methodology");
                if ("FLOW".equalsIgnoreCase(methodology))
                    setFlowData(methodologyDS, mode);
                else if ("IHC".equalsIgnoreCase(methodology))
                    setIHCData(methodologyDS, mode);
                else if ("MOLECULAR".equalsIgnoreCase(methodology))
                    setMolecularData(methodologyDS, mode);
                else if ("FISH".equalsIgnoreCase(methodology))
                    setFishData(methodologyDS, mode); // FISH
                else if ("MULTIOMYX".equalsIgnoreCase(methodology))
                    setMultiomnixData(methodologyDS, mode);
                else if ("CYTOGENETICS".equalsIgnoreCase(methodology))
                    setCytoData(methodologyDS, mode);
            }
        }
    }

    private void setFlowData(DataSet methodologyDS, String mode) throws SapphireException {

        DataSet tatDS = new DataSet();
        methodologyDS = Util.getUniqueValueInDataSetByColumn(methodologyDS, "panelcode");
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);
        tatDS.addColumnValues("panelcode", DataSet.STRING, methodologyDS.getColumnValues("lvtestpanelid", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("tramstop", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);


        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_BY_PC, Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"));
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS != null && tempDS.size() > 0) {
            for (int i = 0; i < tempDS.size(); i++) {
                String tempSample = tempDS.getValue(i, "s_sampleid");
                for (int j = 0; j < tatDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tatDS.getValue(j, "sampleid"))) {
                        tatDS.setValue(j, "accessionid", tempDS.getValue(i, "u_accessionid"));
                        tatDS.setValue(j, "tramstop", tempDS.getValue(i, "u_currentmovementstep"));
                        tatDS.setValue(j, "parentsampleid", tempDS.getValue(i, "parentsample", tempDS.getValue(i, "s_sampleid")));
                        tatDS.setValue(j, "rootsampleid", tempDS.getValue(i, "u_rootsample"));
                        tatDS.setValue(j, "tattimeinhours", tempDS.getValue(i, "tattimeinhours"));
                    }
                }
            }
        }
        tatDS = Util.filterNotEqualValue(tatDS, "tramstop", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }

    private void setIHCData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);
        tatDS.addColumnValues("testcode", DataSet.STRING, methodologyDS.getColumnValues("lvtestcodeid", ";"), ";", null);
        tatDS.addColumnValues("sampletestcodemapid", DataSet.STRING, methodologyDS.getColumnValues("u_sampletestcodemapid", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("tramstop", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "IHC");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS == null)
            return;
        if (tempDS != null && tempDS.size() > 0) {
            for (int i = 0; i < tempDS.size(); i++) {
                String tempSample = tempDS.getValue(i, "s_sampleid");
                for (int j = 0; j < tatDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tatDS.getValue(j, "sampleid"))) {
                        tatDS.setValue(j, "accessionid", tempDS.getValue(i, "u_accessionid"));
                        tatDS.setValue(j, "tramstop", tempDS.getValue(i, "u_currentmovementstep"));
                        tatDS.setValue(j, "parentsampleid", tempDS.getValue(i, "parentsample", ""));
                        tatDS.setValue(j, "rootsampleid", tempDS.getValue(i, "u_rootsample"));
                        tatDS.setValue(j, "tattimeindays", tempDS.getValue(i, "tattimeindays"));
                        tatDS.setValue(j, "tattimeinhours", tempDS.getValue(i, "tattimeinhours"));
                    }
                }
            }
        }
        tatDS = Util.filterNotEqualValue(tatDS, "tramstop", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }

    private void setMolecularData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);
        tatDS.addColumnValues("testcode", DataSet.STRING, methodologyDS.getColumnValues("lvtestcodeid", ";"), ";", null);
        tatDS.addColumnValues("sampletestcodemapid", DataSet.STRING, methodologyDS.getColumnValues("u_sampletestcodemapid", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("tramstop", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "Molecular");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS == null)
            return;
        if (tempDS != null && tempDS.size() > 0) {
            for (int i = 0; i < tempDS.size(); i++) {
                String tempSample = tempDS.getValue(i, "s_sampleid");
                for (int j = 0; j < tatDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tatDS.getValue(j, "sampleid"))) {
                        tatDS.setValue(j, "accessionid", tempDS.getValue(i, "u_accessionid"));
                        tatDS.setValue(j, "tramstop", tempDS.getValue(i, "u_currentmovementstep"));
                        tatDS.setValue(j, "parentsampleid", tempDS.getValue(i, "parentsample", ""));
                        tatDS.setValue(j, "rootsampleid", tempDS.getValue(i, "u_rootsample"));
                        tatDS.setValue(j, "tattimeinhours", tempDS.getValue(i, "tattimeinhours"));
                        tatDS.setValue(j, "tattimeindays", tempDS.getValue(i, "tattimeindays"));
                    }
                }
            }
        }
        tatDS = Util.filterNotEqualValue(tatDS, "tramstop", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }

    }

    private void setFishData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet dsTAT = new DataSet();
        dsTAT.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        dsTAT.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);
        dsTAT.addColumnValues("testcode", DataSet.STRING, methodologyDS.getColumnValues("lvtestcodeid", ";"), ";", null);
        dsTAT.addColumnValues("sampletestcodemapid", DataSet.STRING, methodologyDS.getColumnValues("u_sampletestcodemapid", ";"), ";", null);

        dsTAT.addColumn("accessionid", DataSet.STRING);
        dsTAT.addColumn("panelcode", DataSet.STRING);
        dsTAT.addColumn("tramstop", DataSet.STRING);
        dsTAT.addColumn("parentsampleid", DataSet.STRING);
        dsTAT.addColumn("rootsampleid", DataSet.STRING);
        dsTAT.addColumn("sampletestcodemapid", DataSet.STRING);
        dsTAT.addColumn("tattimeinhours", DataSet.STRING);
        dsTAT.addColumn("tattimeindays", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_SAMPLE_TAT_DETAIL_FISH,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "FISH");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);

        HashMap hm = new HashMap();
        if (tempDS == null || tempDS.size() == 0) {
            return;
        }

        for (int i = 0; i < dsTAT.size(); i++) {
            String sampleID = dsTAT.getValue(i, "sampleid");
            String lvtestcodeid = dsTAT.getValue(i, "testcode");
            hm.clear();
            hm.put("s_sampleid", sampleID);
            hm.put("lvtestcodeid", lvtestcodeid);

            DataSet dsFilter = tempDS.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                dsTAT.setValue(i, "accessionid", dsFilter.getValue(0, "u_accessionid", "(null)"));
                dsTAT.setValue(i, "panelcode", dsFilter.getValue(0, "lvtestpanelid", "(null)"));
                dsTAT.setValue(i, "tramstop", dsFilter.getValue(0, "u_currentmovementstep", "(null)"));
                dsTAT.setValue(i, "parentsampleid", dsFilter.getValue(0, "parentsample", ""));
                dsTAT.setValue(i, "rootsampleid", dsFilter.getValue(0, "u_rootsample", "(null)"));
                dsTAT.setValue(i, "tattimeinhours", dsFilter.getValue(0, "tattimeinhours", "(null)"));
                dsTAT.setValue(i, "tattimeindays", dsFilter.getValue(0, "tattimeindays", "(null)"));

            }
        }

        dsTAT = Util.filterNotEqualValue(dsTAT, "tramstop", "null");
        if (dsTAT != null && dsTAT.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", dsTAT.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }

    }

    private void setMultiomnixData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        methodologyDS = Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid,panelcode");
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);
        tatDS.addColumnValues("panelcode", DataSet.STRING, methodologyDS.getColumnValues("lvtestpanelid", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("tramstop", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("testcode", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "Multiomyx");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS != null && tempDS.size() > 0) {
            for (int i = 0; i < tempDS.size(); i++) {
                String tempSample = tempDS.getValue(i, "s_sampleid");
                for (int j = 0; j < tatDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tatDS.getValue(j, "sampleid"))) {
                        tatDS.setValue(j, "accessionid", tempDS.getValue(i, "u_accessionid"));
                        tatDS.setValue(j, "tramstop", tempDS.getValue(i, "u_currentmovementstep"));
                        tatDS.setValue(j, "parentsampleid", tempDS.getValue(i, "parentsample", ""));
                        tatDS.setValue(j, "rootsampleid", tempDS.getValue(i, "u_rootsample"));
                        tatDS.setValue(j, "tattimeindays", tempDS.getValue(i, "tattimeindays"));
                        tatDS.setValue(j, "tattimeinhours", tempDS.getValue(i, "tattimeinhours"));
                        String temPanelId = tatDS.getValue(j, "panelcode", "");
                        if (Util.isNull(temPanelId))
                            tatDS.setValue(j, "testcode", tempDS.getValue(i, "lvtestcodeid"));
                    }
                }
            }
        }

        tatDS = Util.filterNotEqualValue(tatDS, "tramstop", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }

    private void setCytoData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);
        tatDS.addColumnValues("testcode", DataSet.STRING, methodologyDS.getColumnValues("lvtestcodeid", ";"), ";", null);
        tatDS.addColumnValues("sampletestcodemapid", DataSet.STRING, methodologyDS.getColumnValues("u_sampletestcodemapid", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("tramstop", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "Cytogenetics");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS != null && tempDS.size() > 0) {
            for (int i = 0; i < tempDS.size(); i++) {
                String tempSample = tempDS.getValue(i, "s_sampleid");
                for (int j = 0; j < tatDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tatDS.getValue(j, "sampleid"))) {
                        tatDS.setValue(j, "accessionid", tempDS.getValue(i, "u_accessionid"));
                        tatDS.setValue(j, "tramstop", tempDS.getValue(i, "u_currentmovementstep"));
                        tatDS.setValue(j, "parentsampleid", tempDS.getValue(i, "parentsample", ""));
                        tatDS.setValue(j, "rootsampleid", tempDS.getValue(i, "u_rootsample"));
                        tatDS.setValue(j, "tattimeinhours", tempDS.getValue(i, "tattimeinhours"));
                        tatDS.setValue(j, "tattimeindays", tempDS.getValue(i, "tattimeindays"));
                    }
                }
            }
        }
        tatDS = Util.filterNotEqualValue(tatDS, "tramstop", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }


    private void updateOperation(DataSet primaryDS, DataSet intialPrimaryDS, String mode) throws SapphireException {
        primaryDS = setMethodology(primaryDS);
        if(primaryDS == null || primaryDS.size()==0){
            return;
        }
        primaryDS.sort("methodology");
        ArrayList<?> groupList = primaryDS.getGroupedDataSets("methodology");
        for (Object obj : groupList) {
            DataSet methodologyDS = (DataSet) obj;
            if (methodologyDS != null && methodologyDS.size() > 0) {
                String methodology = methodologyDS.getValue(0, "methodology");
                if ("FLOW".equalsIgnoreCase(methodology))
                    setUpdateFlowData(methodologyDS, mode);
                else if ("IHC".equalsIgnoreCase(methodology))
                    setUpdateIHCData(methodologyDS, mode);
                else if ("MOLECULAR".equalsIgnoreCase(methodology))
                    setUpdateMolecularData(methodologyDS, mode);
                else if ("FISH".equalsIgnoreCase(methodology))
                    setUpdateFishData(methodologyDS, mode); //FISH-
                else if ("MULTIOMYX".equalsIgnoreCase(methodology))
                    setUpdateMultiomnixData(methodologyDS, mode);
                else if ("CYTOGENETICS".equalsIgnoreCase(methodology))
                    setUpdateCytoData(methodologyDS, mode);
            }
        }
    }

    private void setUpdateFlowData(DataSet methodologyDS, String mode) throws SapphireException {
        methodologyDS = Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid");
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("tramstop", DataSet.STRING, methodologyDS.getColumnValues("u_currentmovementstep", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("panelcode", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("custodialdepartmentid", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_UPDATED_TAT_DATA_PC, Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"));
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS != null && tempDS.size() > 0) {
            tempDS.sort("s_sampleid");
            int size = tatDS.size();
            DataSet ds = new DataSet(tatDS.toXML());

            int rownum = 0;
            for (int i = 0; i < size; i++) {
                String tempSample = ds.getValue(i, "sampleid");
                for (int j = 0; j < tempDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tempDS.getValue(j, "s_sampleid"))) {
                        if (j > 0) {
                            tatDS.addRow(rownum);
                            tatDS.setValue(rownum, "sampleid", tempDS.getValue(j, "s_sampleid"));
                            tatDS.setValue(rownum, "tramstop", tempDS.getValue(j, "u_currentmovementstep"));
                            tatDS.setValue(rownum, "methodology", tempDS.getValue(j, "methodology"));
                        }

                        tatDS.setValue(rownum, "accessionid", tempDS.getValue(j, "u_accessionid"));
                        tatDS.setValue(rownum, "sampletestcodemapid", tempDS.getValue(j, "u_sampletestcodemapid"));
                        tatDS.setValue(rownum, "parentsampleid", tempDS.getValue(j, "parentsample", ""));
                        tatDS.setValue(rownum, "rootsampleid", tempDS.getValue(j, "u_rootsample"));
                        tatDS.setValue(rownum, "tattimeinhours", tempDS.getValue(j, "tattimeinhours"));
                        tatDS.setValue(rownum, "panelcode", tempDS.getValue(j, "lvtestpanelid"));
                        tatDS.setValue(rownum, "custodialdepartmentid", tempDS.getValue(j, "custodialdepartmentid"));
                        rownum++;
                    }
                }
            }

        }
        tatDS = Util.filterNotEqualValue(tatDS, "accessionid", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }


    private void setUpdateIHCData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("tramstop", DataSet.STRING, methodologyDS.getColumnValues("u_currentmovementstep", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("testcode", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("custodialdepartmentid", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "IHC");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS == null)
            return;
        if (tempDS != null && tempDS.size() > 0) {
            tempDS.sort("s_sampleid");
            int size = tatDS.size();
            DataSet ds = new DataSet(tatDS.toXML());

            int rownum = 0;
            for (int i = 0; i < size; i++) {
                String tempSample = ds.getValue(i, "sampleid");
                for (int j = 0; j < tempDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tempDS.getValue(j, "s_sampleid"))) {
                        if (j > 0) {
                            tatDS.addRow(rownum);
                            tatDS.setValue(rownum, "sampleid", tempDS.getValue(j, "s_sampleid"));
                            tatDS.setValue(rownum, "tramstop", tempDS.getValue(j, "u_currentmovementstep"));
                            tatDS.setValue(rownum, "methodology", "IHC");
                        }

                        tatDS.setValue(rownum, "accessionid", tempDS.getValue(j, "u_accessionid"));
                        tatDS.setValue(rownum, "sampletestcodemapid", tempDS.getValue(j, "u_sampletestcodemapid"));
                        tatDS.setValue(rownum, "parentsampleid", tempDS.getValue(j, "parentsample", ""));
                        tatDS.setValue(rownum, "rootsampleid", tempDS.getValue(j, "u_rootsample"));
                        tatDS.setValue(rownum, "tattimeindays", tempDS.getValue(j, "tattimeindays"));
                        tatDS.setValue(rownum, "tattimeinhours", tempDS.getValue(j, "tattimeinhours"));
                        tatDS.setValue(rownum, "testcode", tempDS.getValue(j, "lvtestcodeid"));
                        tatDS.setValue(rownum, "custodialdepartmentid", tempDS.getValue(j, "custodialdepartmentid"));
                        rownum++;
                    }
                }
            }

        }
        tatDS = Util.filterNotEqualValue(tatDS, "accessionid", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }

    private void setUpdateMolecularData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("tramstop", DataSet.STRING, methodologyDS.getColumnValues("u_currentmovementstep", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("testcode", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("custodialdepartmentid", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "Molecular");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS == null)
            return;
        if (tempDS != null && tempDS.size() > 0) {
            tempDS.sort("s_sampleid");
            int size = tatDS.size();
            DataSet ds = new DataSet(tatDS.toXML());

            int rownum = 0;
            for (int i = 0; i < size; i++) {
                String tempSample = ds.getValue(i, "sampleid");
                for (int j = 0; j < tempDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tempDS.getValue(j, "s_sampleid"))) {
                        if (j > 0) {
                            tatDS.addRow(rownum);
                            tatDS.setValue(rownum, "sampleid", tempDS.getValue(j, "s_sampleid"));
                            tatDS.setValue(rownum, "tramstop", tempDS.getValue(j, "u_currentmovementstep"));
                            tatDS.setValue(rownum, "methodology", "Molecular");
                        }

                        tatDS.setValue(rownum, "accessionid", tempDS.getValue(j, "u_accessionid"));
                        tatDS.setValue(rownum, "sampletestcodemapid", tempDS.getValue(j, "u_sampletestcodemapid"));
                        tatDS.setValue(rownum, "parentsampleid", tempDS.getValue(j, "parentsample", ""));
                        tatDS.setValue(rownum, "rootsampleid", tempDS.getValue(j, "u_rootsample"));
                        tatDS.setValue(rownum, "tattimeindays", tempDS.getValue(j, "tattimeindays"));
                        tatDS.setValue(rownum, "tattimeinhours", tempDS.getValue(j, "tattimeinhours"));
                        tatDS.setValue(rownum, "testcode", tempDS.getValue(j, "lvtestcodeid"));
                        tatDS.setValue(rownum, "custodialdepartmentid", tempDS.getValue(j, "custodialdepartmentid"));
                        rownum++;
                    }
                }
            }
        }
        tatDS = Util.filterNotEqualValue(tatDS, "accessionid", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }

    private void setUpdateFishData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumn("sampleid", DataSet.STRING);
        tatDS.addColumn("tramstop", DataSet.STRING);
        tatDS.addColumn("methodology", DataSet.STRING);
        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("panelcode", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("testcode", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);

        String allSampleIds = Util.getUniqueList(methodologyDS.getColumnValues("s_sampleid", ";"), ";", true);
        String sql = Util.parseMessage(CommonSql.GET_SAMPLE_TAT_DETAIL_FISH, StringUtil.replaceAll(allSampleIds, ";", "','"), "FISH");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);

        if (tempDS == null || tempDS.getRowCount() == 0) {
            return;
        }

        HashMap hm = new HashMap();
        for (int i = 0; i < tempDS.size(); i++) {
            String sampleID = tempDS.getValue(i, "s_sampleid");

            hm.clear();
            hm.put("s_sampleid", sampleID);
            DataSet dsFilter = methodologyDS.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                int rowID = tatDS.addRow();
                tatDS.setValue(rowID, "sampleid", dsFilter.getValue(0, "s_sampleid"));
                tatDS.setValue(rowID, "tramstop", dsFilter.getValue(0, "u_currentmovementstep"));
                tatDS.setValue(rowID, "methodology", dsFilter.getValue(0, "methodology"));
                tatDS.setValue(rowID, "accessionid", tempDS.getValue(i, "u_accessionid", ""));
                tatDS.setValue(rowID, "sampletestcodemapid", tempDS.getValue(i, "u_sampletestcodemapid", ""));
                tatDS.setValue(rowID, "parentsampleid", tempDS.getValue(i, "parentsample", ""));
                tatDS.setValue(rowID, "rootsampleid", tempDS.getValue(i, "u_rootsample", "(null)"));
                tatDS.setValue(rowID, "tattimeindays", tempDS.getValue(i, "tattimeindays", "(null)"));
                tatDS.setValue(rowID, "tattimeinhours", tempDS.getValue(i, "tattimeinhours", "(null)"));
                tatDS.setValue(rowID, "testcode", tempDS.getValue(i, "lvtestcodeid", "(null)"));
                tatDS.setValue(rowID, "panelcode", tempDS.getValue(i, "lvtestpanelid", "(null)"));
            }
        }

        tatDS = Util.filterNotEqualValue(tatDS, "accessionid", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }

    private void setUpdateMultiomnixData(DataSet methodologyDS, String mode) throws SapphireException {
        methodologyDS = Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid");
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("tramstop", DataSet.STRING, methodologyDS.getColumnValues("u_currentmovementstep", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("panelcode", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("custodialdepartmentid", DataSet.STRING);
        tatDS.addColumn("testcode", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "Multiomyx");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS != null && tempDS.size() > 0) {
            tempDS.sort("s_sampleid");
            int size = tatDS.size();
            DataSet ds = new DataSet(tatDS.toXML());

            int rownum = 0;
            for (int i = 0; i < size; i++) {
                String tempSample = ds.getValue(i, "sampleid");
                for (int j = 0; j < tempDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tempDS.getValue(j, "s_sampleid"))) {
                        if (j > 0) {
                            tatDS.addRow(rownum);
                            tatDS.setValue(rownum, "sampleid", tempDS.getValue(j, "s_sampleid"));
                            tatDS.setValue(rownum, "tramstop", tempDS.getValue(j, "u_currentmovementstep"));
                            tatDS.setValue(rownum, "methodology", "Multiomyx");
                        }

                        tatDS.setValue(rownum, "accessionid", tempDS.getValue(j, "u_accessionid"));
                        tatDS.setValue(rownum, "parentsampleid", tempDS.getValue(j, "parentsample", ""));
                        tatDS.setValue(rownum, "rootsampleid", tempDS.getValue(j, "u_rootsample"));
                        tatDS.setValue(rownum, "tattimeindays", tempDS.getValue(j, "tattimeindays"));
                        tatDS.setValue(rownum, "tattimeinhours", tempDS.getValue(j, "tattimeinhours"));
                        String tempPanelId = tempDS.getValue(j, "lvtestpanelid");
                        if (!Util.isNull(tempPanelId))
                            tatDS.setValue(rownum, "panelcode", tempPanelId);
                        else
                            tatDS.setValue(rownum, "testcode", tempDS.getValue(j, "lvtestcodeid"));
                        tatDS.setValue(rownum, "custodialdepartmentid", tempDS.getValue(j, "custodialdepartmentid"));
                        rownum++;
                    }
                }
            }
        }

        tatDS = Util.filterNotEqualValue(tatDS, "accessionid", "null");
        if (tatDS != null && tatDS.size() > 0) {
            tatDS.sort("sampleid,panelcode,testcode");
            ArrayList<DataSet> tatDSArr = tatDS.getGroupedDataSets("sampleid,panelcode,testcode");
            if (tatDSArr != null && tatDSArr.size() > 0) {
                DataSet result = new DataSet();
                for (int i = 0; i < tatDSArr.size(); i++) {
                    DataSet tempDataSet = tatDSArr.get(i);
                    if (tempDataSet != null && tempDataSet.size() > 0) {
                        result.copyRow(tempDataSet, 0, 1);
                    }

                }
                if (result != null && result.size() > 0) {
                    PropertyList pl = new PropertyList();
                    pl.setProperty("mode", mode);
                    pl.setProperty("tatDS", result.toXML());
                    getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
                }
            }
        }
    }

    private void setUpdateCytoData(DataSet methodologyDS, String mode) throws SapphireException {
        DataSet tatDS = new DataSet();
        tatDS.addColumnValues("sampleid", DataSet.STRING, methodologyDS.getColumnValues("s_sampleid", ";"), ";", null);
        tatDS.addColumnValues("tramstop", DataSet.STRING, methodologyDS.getColumnValues("u_currentmovementstep", ";"), ";", null);
        tatDS.addColumnValues("methodology", DataSet.STRING, methodologyDS.getColumnValues("methodology", ";"), ";", null);

        tatDS.addColumn("accessionid", DataSet.STRING);
        tatDS.addColumn("sampletestcodemapid", DataSet.STRING);
        tatDS.addColumn("parentsampleid", DataSet.STRING);
        tatDS.addColumn("rootsampleid", DataSet.STRING);
        tatDS.addColumn("testcode", DataSet.STRING);
        tatDS.addColumn("tattimeindays", DataSet.STRING);
        tatDS.addColumn("tattimeinhours", DataSet.STRING);
        tatDS.addColumn("custodialdepartmentid", DataSet.STRING);

        String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_SAMPLE_TC,
                Util.getUniqueValueInDataSetByColumn(methodologyDS, "s_sampleid").getColumnValues("s_sampleid", "','"), "Cytogenetics");
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        if (tempDS != null && tempDS.size() > 0) {
            tempDS.sort("s_sampleid");
            int size = tatDS.size();
            DataSet ds = new DataSet(tatDS.toXML());

            int rownum = 0;
            for (int i = 0; i < size; i++) {
                String tempSample = ds.getValue(i, "sampleid");
                for (int j = 0; j < tempDS.size(); j++) {
                    if (tempSample.equalsIgnoreCase(tempDS.getValue(j, "s_sampleid"))) {
                        if (j > 0) {
                            tatDS.addRow(rownum);
                            tatDS.setValue(rownum, "sampleid", tempDS.getValue(j, "s_sampleid"));
                            tatDS.setValue(rownum, "tramstop", tempDS.getValue(j, "u_currentmovementstep"));
                            tatDS.setValue(rownum, "methodology", "Cytogenetics");
                        }

                        tatDS.setValue(rownum, "accessionid", tempDS.getValue(j, "u_accessionid"));
                        tatDS.setValue(rownum, "sampletestcodemapid", tempDS.getValue(j, "u_sampletestcodemapid"));
                        tatDS.setValue(rownum, "parentsampleid", tempDS.getValue(j, "parentsample", ""));
                        tatDS.setValue(rownum, "rootsampleid", tempDS.getValue(j, "u_rootsample"));
                        tatDS.setValue(rownum, "tattimeindays", tempDS.getValue(j, "tattimeindays"));
                        tatDS.setValue(rownum, "tattimeinhours", tempDS.getValue(j, "tattimeinhours"));
                        tatDS.setValue(rownum, "testcode", tempDS.getValue(j, "testcodeid"));
                        tatDS.setValue(rownum, "custodialdepartmentid", tempDS.getValue(j, "custodialdepartmentid"));
                        rownum++;
                    }
                }
            }

        }
        tatDS = Util.filterNotEqualValue(tatDS, "accessionid", "null");
        if (tatDS != null && tatDS.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("mode", mode);
            pl.setProperty("tatDS", tatDS.toXML());
            getActionProcessor().processAction(EnterTatData.ID, EnterTatData.VERSIONID, pl);
        }
    }


    private DataSet setMethodology(DataSet primaryDS) {
        primaryDS.addColumn("methodology", DataSet.STRING);
        String sql = Util.parseMessage(CommonSql.SAMPLETESTCODEMAPINFO_SAMPLEID,
                Util.getUniqueValueInDataSetByColumn(primaryDS, "s_sampleid").getColumnValues("s_sampleid", "','"));
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        DataSet result = null;
        if (tempDS != null && tempDS.size() > 0) {
            result = new DataSet();
            result.addColumn("methodology", DataSet.STRING);
            HashMap<String, String> hashMap = new HashMap<String, String>();
            for (int j = 0; j < primaryDS.size(); j++) {
                String sampleid = primaryDS.getValue(j, "s_sampleid");
                if (!Util.isNull(sampleid)) {
                    hashMap.clear();
                    hashMap.put("s_sampleid", sampleid);
                    DataSet tempDSFiltr = tempDS.getFilteredDataSet(hashMap);
                    if (tempDSFiltr != null && tempDSFiltr.size() > 0) {
                        String tempMethodology = tempDSFiltr.getColumnValues("methodology", ";");
                        if (!Util.isNull(tempMethodology)) {
                            tempMethodology = Util.getUniqueList(tempMethodology, ";", true);
                            String tempMethodologyArr[] = StringUtil.split(tempMethodology, ";");
                            if (tempMethodologyArr != null && tempMethodologyArr.length > 0) {
                                for (int i = 0; i < tempMethodologyArr.length; i++) {
                                    result.copyRow(primaryDS, j, 1);
                                    result.setValue(result.size() - 1, "methodology", tempMethodologyArr[i]);
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }
}
