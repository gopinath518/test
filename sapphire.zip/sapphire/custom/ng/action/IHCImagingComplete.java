package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class IHCImagingComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("sampleid", "");
        String vmsqccomment = properties.getProperty("u_vmsqccomment", "");
        String imagingcompltstep = properties.getProperty("imagingcompltstep", "N");
        String sql = Util.parseMessage(ApSql.GET_QC_STATUS_SAMPLE, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
            PropertyList prop = new PropertyList();
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("u_vmsqcstatus", null);
            DataSet dsFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                sampleId = dsFilter.getColumnValues("s_sampleid", ";");
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
                prop.setProperty("u_vmsqccomment", StringUtil.repeat(vmsqccomment, dsFilter.size(), ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (Exception ex) {
                    throw new SapphireException("Unable to update comments.");
                }
            }
            hm.clear();
            hm.put("u_vmsqcstatus", "QCFail");
            dsFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                sampleId = dsFilter.getColumnValues("s_sampleid", ";");
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
                prop.setProperty("u_vmsqccomment", StringUtil.repeat(vmsqccomment, dsFilter.size(), ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (Exception ex) {
                    throw new SapphireException("Unable to update comments.");
                }
            }
            sampleId = dsSampleInfo.getColumnValues("s_sampleid", ";");
            prop.clear();
            prop.setProperty("sampleid", sampleId);
            prop.setProperty("imagingcompltstep", imagingcompltstep);
            try {
                getActionProcessor().processAction("IHCFlowCompleteStep", "1", prop);
            } catch (Exception ex) {
                throw new SapphireException(ex.getMessage());
            }
            properties.setProperty("msg", prop.getProperty("msg"));
        }


        //throw new SapphireException("Imaging complete step");
    }
}
