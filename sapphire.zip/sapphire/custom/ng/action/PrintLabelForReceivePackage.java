package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.GenerateLabel;
import sapphire.custom.ng.sql.PrintLabel.PrintLabelSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by tutu.rajsahoo on 12/22/2017.
 */
public class PrintLabelForReceivePackage extends BaseAction {
    public static final String KEYID1_PROP="keyid1";
    public static final String SDCID_PROP="sdcid";
    public static final String LABELMETHOD_PROP="labelmethodid";
    public static final String COPIES="copies";

    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty(KEYID1_PROP, "");
        String sdcid = properties.getProperty(SDCID_PROP, "");
        String labelmethod = properties.getProperty(LABELMETHOD_PROP, "");
        String copies = properties.getProperty(COPIES,"1");
        try {
            if ("ReceivingModule".equalsIgnoreCase(sdcid)) {
                String printer=getPrinterId();
                if (Util.isNull(printer)) {
                    throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                            " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                            "Also the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
                } else {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
                    prop.setProperty(GenerateLabel.PROPERTY_KEYID1, keyid1);
                    prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, labelmethod);
                    prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
                    prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID,printer );
                    prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                    prop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);

                    getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, prop);
                }
            }
        } catch(SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    private String getPrinterId()throws SapphireException{
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
        String sql = Util.parseMessage(PrintLabelSql.GET_PRINTER_INFO,userId,depratmentId,depratmentId);
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if(dsInfo!=null && dsInfo.size()>0){
            String userprinter = dsInfo.getValue(0,"userprinter","");
            String deptprinter = dsInfo.getValue(0,"deptprinter","");
            if(!Util.isNull(userprinter) ) {
                printerId = userprinter;
            }
            else if(!Util.isNull(deptprinter)) {
                printerId = deptprinter;
            }
        }
        return printerId;
    }
}
