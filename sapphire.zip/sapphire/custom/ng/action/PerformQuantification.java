package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.ExcelParsing;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by AGupta on 9/1/2016.
 */
public class PerformQuantification extends BaseAction {
    /**
     * This action is used for Qubit File parse.
     * @param properties
     * @throws sapphire.SapphireException
     * */
    public void processAction(PropertyList properties) throws SapphireException {
        String file = properties.getProperty("path", "");
        String columnname =properties.getProperty("columnid", "");
        if(Util.isNull(file))
            throw new SapphireException("file is not found. Please upload a valid file.");
        if(file.indexOf(".csv")<=0)
            throw new SapphireException("Invalid file format obtained. Please upload a csv file format.");
        else {
            DataSet ds = ExcelParsing.csvFileParse(file);
            if (ds == null && ds.size() == 0)
                throw new SapphireException("No Data Found inside file.");
                String sampleIdSQL = "SELECT s.s_sampleid as sampleid " +
                        "FROM s_sample s,trackitem t " +
                        "WHERE s.s_sampleid= t.linkkeyid1 " +
                        "AND s.s_sampleid in ('" + StringUtil.replaceAll(ds.getColumnValues("name", ";"), ";", "','") + "') " +
                        "AND ( t.containertypeid= 'Ellution Tube' OR t.containertypeid is null ) ";
                DataSet dssample = getQueryProcessor().getSqlDataSet(sampleIdSQL);
                if(dssample==null || dssample.size()==0)
                    throw new SapphireException("Query "+sampleIdSQL+" is not returning any row.");
                HashMap<String,String>hmap = new HashMap<>();
                for(int i=0;i<ds.size();i++){
                    String sampleId=ds.getValue(i,"name","");
                    if(Util.isNull(sampleId))
                        throw  new SapphireException("Sample Id is not found in the row "+(i+1));
                    hmap.clear();
                    hmap.put("sampleid",sampleId);
                    DataSet tempFiltrDs = dssample.getFilteredDataSet(hmap);
                    if(tempFiltrDs==null || tempFiltrDs.size()==0)
                        throw  new SapphireException("Sample id "+sampleId+" is not a valid Elusion Tube");
                }

                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("name", ";"));
                if(columnname == "")
                    props.setProperty("concentration", ds.getColumnValues("stockconc.", ";"));
                else
                    props.setProperty(columnname, ds.getColumnValues("stockconc.", ";"));
                props.setProperty("concentrationunits", ds.getColumnValues("stockunits", ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (Exception e) {
                    throw new SapphireException("u_controlflag not created");
                }

        }
    }

}
