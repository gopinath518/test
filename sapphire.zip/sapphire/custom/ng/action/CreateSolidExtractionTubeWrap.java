package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.servlet.ServletException;
import java.util.HashMap;

public class CreateSolidExtractionTubeWrap extends BaseAction {
    String requestid = "";
    Boolean isclienthne = false;
    String ffpeextractiontype = "";
    String msg = "Unable to fetch ExtractionID";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        ffpeextractiontype = properties.getProperty("ffpeextractiontype", "");
        String hne = properties.getProperty("hne");
        String uss = properties.getProperty("uss");
        String ishnescanned = properties.getProperty("ishnescanned");
        requestid = properties.getProperty("requestid", "");

        if ("Y".equalsIgnoreCase(ishnescanned)) {
            validateScannedItem(hne);
        }
        validateScannedItem(uss);
        isclienthne = checkForClienthne(uss);
        if ("Y".equalsIgnoreCase(ishnescanned)) {
            findSample(hne, uss);
        } else {
            findSampleWOHNEScanned(uss, ishnescanned);
        }
        properties.setProperty("msg", msg);
        //throw new SapphireException("Test");
    }

    private Boolean checkForClienthne(String hne) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_UTYPE_BY_SAMPLE, hne);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.getValue(0, "u_type").equalsIgnoreCase("CH") || ds.getValue(0, "u_type").equalsIgnoreCase("CU")
                || ds.getValue(0, "u_type").equalsIgnoreCase("FB")) {
            return true;
        } else if (ds.getValue(0, "u_type").equalsIgnoreCase("SH")) {
            sql = Util.parseMessage(MolecularSql.GET_SHARE_HNE_INFO, StringUtil.replaceAll(hne, ";", "','"));
            DataSet dsShareHNEInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsShareHNEInfo.size() == 0)
                throw new SapphireException("Below Share H&E does not have testcode associated." + hne);
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("methodology", "Molecular");
            DataSet dsMolFilter = dsShareHNEInfo.getFilteredDataSet(hm);
            if (dsMolFilter.size() == 0)
                throw new SapphireException("Below Share H&E does not allow for Molecular workflow." + hne);
            return false;
        } else {
            return false;
        }
    }


    /**
     * This function is use to get all other samples belongs to
     * same parent block with one child hne and a unstained slide as input .
     *
     * @param hne
     * @param uss
     * @throws ServletException
     */

    private void findSample(String hne, String uss) throws SapphireException {
        String sql = "";
        if (isclienthne) {
            String concatstr = hne + "','" + uss;
            sql = Util.parseMessage(MolecularSql.GET_CLIENT_SAMPLE_BY_SAMPLE, hne, uss);
        } else {
            sql = Util.parseMessage(MolecularSql.GET_CHILDS_BY_PARENTS, hne, uss);
        }

        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (!dsSampleInfo.isValidColumn("testname")) {
            dsSampleInfo.addColumn("testname", DataSet.STRING);
        }
        if (!dsSampleInfo.isValidColumn("methodology")) {
            dsSampleInfo.addColumn("methodology", DataSet.STRING);
        }
        //validate Others like must be heme sample
        String samples = dsSampleInfo.getColumnValues("s_sampleid", ";");
        String samp = StringUtil.replaceAll(samples, ";", "','");
        String testsql = Util.parseMessage(MolecularSql.TESTS_BY_SAMPEID, samp);
        DataSet dsTestName = getQueryProcessor().getSqlDataSet(testsql);

        HashMap hm = new HashMap();
        for (int i = 0; i < dsTestName.getRowCount(); i++) {
            hm.clear();
            hm.put("s_sampleid", dsTestName.getValue(i, "s_sampleid"));
            int j = dsSampleInfo.findRow(hm);
            if (j >= 0) {
                dsSampleInfo.setValue(j, "testname", dsTestName.getValue(i, "testname", ""));
                dsSampleInfo.setValue(j, "methodology", "Molecular");
            }
        }

        hm.clear();
        hm.put("methodology", "Molecular");
        DataSet dsMolecularSampleInfo = dsSampleInfo.getFilteredDataSet(hm);
        String extrtype = getExtractionType(uss);
        hm.clear();
        hm.put("extractiontype", extrtype);
        DataSet dsMolFilteredByExtrtn = dsSampleInfo.getFilteredDataSet(hm);
        if (dsMolFilteredByExtrtn != null && dsMolFilteredByExtrtn.size() > 0) {
            hm.clear();
            hm.put("s_sampleid", hne);
            DataSet dsMolFilteredByHNE = dsSampleInfo.getFilteredDataSet(hm);
            if (dsMolFilteredByHNE != null && dsMolFilteredByHNE.size() > 0) {
                dsMolecularSampleInfo.clear();// = new DataSet();
                int rowID = dsMolecularSampleInfo.addRow();
                dsMolecularSampleInfo.setValue(rowID, "extractiontype", dsMolFilteredByHNE.getValue(0, "extractiontype", ""));
                dsMolecularSampleInfo.setValue(rowID, "u_accessionid", dsMolFilteredByHNE.getValue(0, "u_accessionid", ""));
                dsMolecularSampleInfo.setValue(rowID, "u_sampleinformation", dsMolFilteredByHNE.getValue(0, "u_sampleinformation", ""));
                dsMolecularSampleInfo.setValue(rowID, "s_sampleid", dsMolFilteredByHNE.getValue(0, "s_sampleid", ""));
                dsMolecularSampleInfo.setValue(rowID, "u_type", dsMolFilteredByHNE.getValue(0, "u_type", ""));
                dsMolecularSampleInfo.setValue(rowID, "u_clientspecimenid", dsMolFilteredByHNE.getValue(0, "u_clientspecimenid", ""));
                dsMolecularSampleInfo.setValue(rowID, "sampletypeid", dsMolFilteredByHNE.getValue(0, "sampletypeid", ""));
                dsMolecularSampleInfo.setValue(rowID, "containertypeid", dsMolFilteredByHNE.getValue(0, "containertypeid", ""));
                dsMolecularSampleInfo.setValue(rowID, "patientid", dsMolFilteredByHNE.getValue(0, "patientid", ""));
                dsMolecularSampleInfo.setValue(rowID, "methodology", "Molecular");
                dsMolecularSampleInfo.setValue(rowID, "testname", dsMolFilteredByHNE.getValue(0, "testname", ""));
                for (int i = 0; i < dsMolFilteredByExtrtn.size(); i++) {
                    int nxtrowID = dsMolecularSampleInfo.addRow();
                    dsMolecularSampleInfo.setValue(nxtrowID, "extractiontype", dsMolFilteredByExtrtn.getValue(i, "extractiontype", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_accessionid", dsMolFilteredByExtrtn.getValue(i, "u_accessionid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_sampleinformation", dsMolFilteredByExtrtn.getValue(i, "u_sampleinformation", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "s_sampleid", dsMolFilteredByExtrtn.getValue(i, "s_sampleid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_type", dsMolFilteredByExtrtn.getValue(i, "u_type", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "u_clientspecimenid", dsMolFilteredByExtrtn.getValue(i, "u_clientspecimenid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "sampletypeid", dsMolFilteredByExtrtn.getValue(i, "sampletypeid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "containertypeid", dsMolFilteredByExtrtn.getValue(i, "containertypeid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "patientid", dsMolFilteredByExtrtn.getValue(i, "patientid", ""));
                    dsMolecularSampleInfo.setValue(nxtrowID, "methodology", "Molecular");
                    dsMolecularSampleInfo.setValue(nxtrowID, "testname", dsMolFilteredByExtrtn.getValue(i, "testname", ""));
                }
                //dsMolecularSampleInfo = dsMolFilteredByExtrtn;
            }

        }

        if (dsMolecularSampleInfo.size() > 0) {  //sample found
            String newkeyid1 = createExtractionTubenLabel(hne, uss);
            //String newkeyidArr=newkeyid1.split(";")
            //labelPrint(newkeyid1);      //Print Label call_todo printLabel Due. labelPrint is added in action.

            String exid_sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_BY_SAMPLEID, newkeyid1.replaceAll(";", "','"));
            DataSet dsExtraction = getQueryProcessor().getSqlDataSet(exid_sql);
            if (dsExtraction.size() > 0) {
                msg = dsExtraction.getColumnValues("u_extractionid", ";");
            }
        } else {
            String err = "Scanned H&E and Unstained slide not belongs to same Block/Accession.";
            logger.debug(err);
            logger.error(err + " Query framed- \n" + sql);
            throw new SapphireException(err);
        }

    }

    private void findSampleWOHNEScanned(String uss, String isHNEScanned) throws SapphireException {
        String sql = "";
        sql = Util.parseMessage(MolecularSql.GET_SAMPLE_WO_HNE, uss);
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (!dsSampleInfo.isValidColumn("testname")) {
            dsSampleInfo.addColumn("testname", DataSet.STRING);
        }
        if (!dsSampleInfo.isValidColumn("methodology")) {
            dsSampleInfo.addColumn("methodology", DataSet.STRING);
        }
        //validate Others like must be heme sample
        String samples = dsSampleInfo.getColumnValues("s_sampleid", ";");
        String samp = StringUtil.replaceAll(samples, ";", "','");
        String testsql = Util.parseMessage(MolecularSql.GET_WO_TESTNAME_BY_SAMPLE, samp);
        DataSet dsTestName = getQueryProcessor().getSqlDataSet(testsql);

        HashMap hm = new HashMap();
        for (int i = 0; i < dsTestName.getRowCount(); i++) {
            hm.clear();
            hm.put("s_sampleid", dsTestName.getValue(i, "s_sampleid"));
            int j = dsSampleInfo.findRow(hm);
            if (j >= 0) {
                dsSampleInfo.setValue(j, "testname", dsTestName.getValue(i, "testname", ""));
                dsSampleInfo.setValue(j, "methodology", "Molecular");
            }
        }

        hm.clear();
        hm.put("methodology", "Molecular");
        DataSet dsMolecularSampleInfo = dsSampleInfo.getFilteredDataSet(hm);
        String extrtype = getExtractionType(uss);
        hm.clear();
        hm.put("extractiontype", extrtype);
        DataSet dsMolFilteredByExtrtn = dsSampleInfo.getFilteredDataSet(hm);
        if (dsMolFilteredByExtrtn != null && dsMolFilteredByExtrtn.size() > 0) {
            dsMolecularSampleInfo.clear();
            for (int i = 0; i < dsMolFilteredByExtrtn.size(); i++) {
                int nxtrowID = dsMolecularSampleInfo.addRow();
                dsMolecularSampleInfo.setValue(nxtrowID, "extractiontype", dsMolFilteredByExtrtn.getValue(i, "extractiontype", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "u_accessionid", dsMolFilteredByExtrtn.getValue(i, "u_accessionid", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "u_sampleinformation", dsMolFilteredByExtrtn.getValue(i, "u_sampleinformation", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "s_sampleid", dsMolFilteredByExtrtn.getValue(i, "s_sampleid", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "u_type", dsMolFilteredByExtrtn.getValue(i, "u_type", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "u_clientspecimenid", dsMolFilteredByExtrtn.getValue(i, "u_clientspecimenid", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "sampletypeid", dsMolFilteredByExtrtn.getValue(i, "sampletypeid", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "containertypeid", dsMolFilteredByExtrtn.getValue(i, "containertypeid", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "patientid", dsMolFilteredByExtrtn.getValue(i, "patientid", ""));
                dsMolecularSampleInfo.setValue(nxtrowID, "methodology", "Molecular");
                dsMolecularSampleInfo.setValue(nxtrowID, "testname", dsMolFilteredByExtrtn.getValue(i, "testname", ""));
            }
        }

        if (dsMolecularSampleInfo.size() > 0) {  //sample found
            String newkeyid1 = createExtractionTubenLabelWOHNE(uss, isHNEScanned);
            //String newkeyidArr=newkeyid1.split(";")
            //labelPrint(newkeyid1);      //Print Label call_todo printLabel Due. labelPrint is added in action.
            String exid_sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_BY_SAMPLEID, newkeyid1.replaceAll(";", "','"));
            DataSet dsExtraction = getQueryProcessor().getSqlDataSet(exid_sql);
            if (dsExtraction.size() > 0) {
                msg = dsExtraction.getColumnValues("u_extractionid", ";");
            }
        } else {
            String err = "Scanned H&E and Unstained slide not belongs to same Block/Accession.";
            logger.debug(err);
            logger.error(err + " Query framed- \n" + sql);
            throw new SapphireException(err);
        }


    }

    /**
     * This function is use to create extraction tube i.e. pooled sample
     * with hne and unstained slides .
     *
     * @param hne
     * @param uss
     * @return
     * @throws SapphireException
     */
    private String createExtractionTubenLabel(String hne, String uss) throws SapphireException {
        PropertyList hs = new PropertyList();
        hs.setProperty("hnesample", hne);
        hs.setProperty("testslide", uss);
        hs.setProperty("requestid", requestid);
        hs.setProperty("isclienthne", String.valueOf(isclienthne));
        hs.setProperty("ffpeextractiontype", ffpeextractiontype);


        try {
            //   getActionProcessor().processAction("CreateExtractionTube", "1", hs);
            getActionProcessor().processAction("CreateBlockExtractionTube", "1", hs);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Unable to create Extraction tube ");
            errMSG += "\n" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        String newkeyid1 = hs.getProperty("newkeyid1");
        return newkeyid1;
    }

    private String createExtractionTubenLabelWOHNE(String uss, String isHNEScanned) throws SapphireException {
        PropertyList hs = new PropertyList();
        hs.setProperty("hnesample", "");
        hs.setProperty("testslide", uss);
        hs.setProperty("ishnescanned", isHNEScanned);
        hs.setProperty("requestid", requestid);
        hs.setProperty("isclienthne", String.valueOf(isclienthne));
        hs.setProperty("ffpeextractiontype", ffpeextractiontype);


        try {
            //   getActionProcessor().processAction("CreateExtractionTube", "1", hs);
            getActionProcessor().processAction("CreateBlockExtractionTube", "1", hs);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Unable to create Extraction tube ");
            errMSG += "\n" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        String newkeyid1 = hs.getProperty("newkeyid1");
        return newkeyid1;
    }

    /**
     * This function is use to check any blank or null inputs.
     *
     * @param searchedText
     * @throws SapphireException
     */
    private void validateScannedItem(String searchedText) throws SapphireException {
        if (searchedText == null || "".equalsIgnoreCase(searchedText.trim())) {
            throw new SapphireException("Scanned item is blank.");
        }


    }

    private void labelPrint(String newkeyid1) throws SapphireException {
        String sqlExTube = "select distinct s.s_sampleid,stm.extractiontype from s_sample s,u_sampletestcodemap stm " +
                "where stm.methodology='Molecular' and s.s_sampleid=stm.s_sampleid and s.s_sampleid in('" + StringUtil.replaceAll(newkeyid1, ";", "','") + "')";
        DataSet dsExTube = getQueryProcessor().getSqlDataSet(sqlExTube);
        if (dsExTube == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlExTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsExTube.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample Type not found.");
            errMsg += "\nQuery returns zero rows:" + sqlExTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        for (int i = 0; i < dsExTube.size(); i++) {
            String sample = dsExTube.getValue(i, "s_sampleid", "");
            if (Util.isNull(sample)) {
                String errMsg = getTranslationProcessor().translate("Sample id not found.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }

            String extractiontype = dsExTube.getValue(i, "extractiontype", "");
            if (Util.isNull(extractiontype)) {
                String errMsg = getTranslationProcessor().translate("Extraction type not found for sample:" + sample);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
        }
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, dsExTube.getColumnValues("s_sampleid", ";"));
        props.setProperty(PrintLabel.EXTRACTION_TYPE, Util.getUniqueList(dsExTube.getColumnValues("extractiontype", ";"), ";", true));//added
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Molecular");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, "ExtractionTube");
        props.setProperty(PrintLabel.TRAMLINE_PROP, "Extraction");
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    private String getExtractionType(String uss) throws SapphireException {
        String extractiontyep = "";
        String sql = Util.parseMessage(MolecularSql.GET_MAPID_BY_SAMPLE, uss);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        extractiontyep = Util.getUniqueList(ds.getColumnValues("extractiontype", ";"), ";", true);
        //if (Util.isNull(extractiontyep)) {//TODO IMPLEMENTING TNA WORKFLOW
        if (Util.isNull(extractiontyep) && !"TNA".equalsIgnoreCase(extractiontyep)) {
            extractiontyep = ffpeextractiontype;
            sql = Util.parseMessage(MolecularSql.GET_ALL_BY_USS, uss);
            DataSet dsAllUSS = getQueryProcessor().getSqlDataSet(sql);
            String alluss = StringUtil.replaceAll(dsAllUSS.getColumnValues("s_sampleid", ";"), ";", "','");
            sql = Util.parseMessage(MolecularSql.GET_NANO_SAMPLES, alluss);
            DataSet dsUSS = getQueryProcessor().getSqlDataSet(sql);
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsUSS.getColumnValues("u_sampletestcodemapid", ";"));
            prop.setProperty("extractiontype", StringUtil.repeat(extractiontyep, dsUSS.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }
        return extractiontyep;
    }
}
