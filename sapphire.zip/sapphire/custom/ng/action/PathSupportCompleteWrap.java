package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class PathSupportCompleteWrap extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid", "");
        String u_assignedtodoctor = properties.getProperty("u_assignedtodoctor", "");
        getEligibleDoctors(properties);
        PropertyList prop = new PropertyList();
        prop.setProperty("keyid1", sampleid);
        prop.setProperty("u_assignedtodoctor", u_assignedtodoctor);
        try {
            getActionProcessor().processAction("AssignToDoctor", "1", prop);
        } catch (Exception ex) {
            throw new SapphireException(ex.getMessage());
        }
        prop.clear();
        prop.setProperty("sampleid", sampleid);
        try {
            getActionProcessor().processAction("IHCFlowCompleteStep", "1", prop);
        } catch (Exception ex) {
            throw new SapphireException(ex.getMessage());
        }
        properties.setProperty("msg", prop.getProperty("msg"));

        //throw new SapphireException("test");
    }

    private void getEligibleDoctors(PropertyList properties) throws SapphireException {
        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
        dsDisplayMsg.addColumn("accession_id", DataSet.STRING);
        dsDisplayMsg.addColumn("project_id", DataSet.STRING);
        dsDisplayMsg.addColumn("assigned_doctor", DataSet.STRING);
        String sampleid = properties.getProperty("sampleid", "");
        String u_assignedtodoctor = Util.getUniqueList(properties.getProperty("u_assignedtodoctor", ""), ";", true);
        String sampleids = StringUtil.replaceAll(sampleid, ";", "','");
        String sql = Util.parseMessage(ApSql.GET_PROJECTS_BY_SAMPLE, sampleids);
        DataSet dsProjects = getQueryProcessor().getSqlDataSet(sql);
        String projectsid = dsProjects.getColumnValues("u_bioprojectsid", ";");
        sql = Util.parseMessage(ApSql.GET_PROJECTS_DOCTORS, StringUtil.replaceAll(projectsid, ";", "','"));
        DataSet dsDoctors = getQueryProcessor().getSqlDataSet(sql);
        if (!dsProjects.isValidColumn("isvalid")) {
            dsProjects.addColumn("isvalid", DataSet.STRING);
        }
        if (dsProjects.size() > 0) {
            for (int i = 0; i < dsProjects.size(); i++) {
                String projectid = dsProjects.getValue(i, "u_bioprojectsid", "");
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("projectid", projectid);
                hm.put("userid", u_assignedtodoctor);
                DataSet dsDoctorFilter = dsDoctors.getFilteredDataSet(hm);
                if (dsDoctorFilter.size() > 0) {
                    dsProjects.setValue(i, "isvalid", "Y");
                }
                if (dsDoctorFilter.size() == 0) {
                    dsProjects.setValue(i, "isvalid", "N");
                }
            }
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("isvalid", "N");
            DataSet dsInvalidDoctorFilter = dsProjects.getFilteredDataSet(hm);
            if (dsInvalidDoctorFilter.size() > 0) {
                for (int i = 0; i < dsInvalidDoctorFilter.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsInvalidDoctorFilter.getValue(i, "s_sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "accession_id", dsInvalidDoctorFilter.getValue(i, "u_accessionid", ""));
                    dsDisplayMsg.setValue(rowID, "project_id", dsInvalidDoctorFilter.getValue(i, "projectprotocolid", ""));
                    dsDisplayMsg.setValue(rowID, "assigned_doctor", u_assignedtodoctor);
                }
                String errMsg = Util.getDisplayMessage("Below doctor(s) does not associated with the project.", dsDisplayMsg);
                //String invalidsample = dsInvalidDoctorFilter.getColumnValues("projectprotocolid", ",");
                throw new SapphireException(errMsg);
            }
        }
    }
}
