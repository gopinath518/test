package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by kshahbaz on 4/21/2016.
 */

/**
 * Description:This action create request for single or multiple samples
 * Request is created by lab user when samples are consumed or destroyed
 * Mandatory Input:
 * @param1 : Laboratory
 * @param2 : Sample Id
 * @throws SapphireException
 */
public class CreateRequest extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String lab = properties.getProperty("lab");
        String sampleid = properties.getProperty("s_sampleid");

        String newkeyid = createRequest(lab);
        updateRequest(newkeyid, sampleid);
    }

    private String createRequest(String lab) throws SapphireException {
        String newkeyid1 = "";

        PropertyList props = new PropertyList();

        try {
            props.setProperty(AddSDI.PROPERTY_SDCID, "Request");
            props.setProperty(AddSDI.PROPERTY_COPIES, "1");
            props.setProperty("u_lab", lab);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            newkeyid1 = props.getProperty("newkeyid1");
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't create request");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
        return newkeyid1;
    }

    /**
     * @desc : This method is used to update request for a sample into database table
     * @param requestid
     * @param sampleid
     * @return void
     * @throws SapphireException
     */
    private void updateRequest(String requestid, String sampleid) throws SapphireException {

        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("requestid", requestid);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update request in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}

