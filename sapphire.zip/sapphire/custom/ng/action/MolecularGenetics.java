package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.report.GenerateReport;
import sapphire.SapphireException;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.util.NGSendMail;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;
import sapphire.action.AddToDoListEntry;
import sapphire.custom.ng.action.util.NGSendMail;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;


/**
 * Created by kshahbaz on 7/1/2016.
 * Modified by msubhra on 10/4/2016.
 */
public class MolecularGenetics extends BaseAction {

    private final String POLICY_NAME = "PanelAutoBatchCreatePolicy";
    private final String POLICY_NODE = "MolAutoBatchCrt";

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("s_sampleid", "");
        String batchid = properties.getProperty("u_ngbatchid", "");
        
        /* Validation For New York:: Added by Subhendu + */
        if (!validateNYLicence(sampleid))
            throw new SapphireException("Login User does not have valid NY License number to release NY Accession");
        /* Validation For New York:: Added by Subhendu - */

        if (!Util.isNull(sampleid) && !Util.isNull(batchid)) {
            sampleid = automaticBatchValidation(sampleid, batchid);
            String uniqueSamples = Util.getUniqueList(sampleid, ";", true);
            String sampleids = uniqueSamples.replaceAll(";", "','");
            String[] sampArr = StringUtil.split(uniqueSamples, ";");
            String tc_sql = "select distinct st.s_sampleid,t.testcodedesc from u_sampletestcodemap st,u_testcode t where st.lvtestcodeid = t.u_testcodeid " +
                    " and st.lvtestpanelid is null  and NVL(t.ispanel,'N') = 'N' and st.s_sampleid in('" + sampleids + "')";

            String tp_sql = "select distinct st.s_sampleid,t.testname from u_sampletestcodemap st,u_testcode t where st.lvtestpanelid = t.u_testcodeid and " +
                    "st.ispanel = 'Y' and s_sampleid in ('" + sampleids + "')";
            DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
            DataSet dstespanel = getQueryProcessor().getSqlDataSet(tp_sql);

            if (dstestcode == null || dstespanel == null) {
                String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + tc_sql + "\n" + tp_sql;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

            }

            if (dstestcode.size() == 0 && dstespanel.size() == 0) {
                String error = getTranslationProcessor().translate("SampleID " + sampleids + " doesn't have any Test !" + tc_sql + tp_sql);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }

            //String location = getFileLocation();//TODO CHAGED FOR FOLDER STRUCTURED FOR 1.5.1 release

            /**
             * For business logic GenerateReport action is used in loop. In a batch there are more than one sample so
             * report need to be generated per sample.
             */
            // for (int i = 0; i < sampArr.length; i++) {
            //   String getSample = sampArr[i];
            // try {
            String newfileloc = generatereport(uniqueSamples, /*location,*/ batchid);
            // addAttachment(uniqueSamples, batchid, newfileloc);
              /*  } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. Molecular Report not created for " + getSample + "Sample ID" + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);

                }

            }*/

            updateReportDate(uniqueSamples);
            updateBatchStatus(batchid);
            properties.setProperty("msg", "Report Generated Successfully");
//            throw new SapphireException("Test");
        } else {
            String err = "Either SampleId or BatchId is blank.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

    }

    /**
     * Description : This method will call CopyFile action using AddToDoListEntry.This will copy generated file to
     * given location.
     *
     * @param sourceFile
     * @param sampleid
     * @throws SapphireException
     * @throws IOException
     */
    private void copyFileSFTPPath(String sourceFile, String sampleid) throws SapphireException, IOException {
        PropertyList prop = new PropertyList();
        prop.setProperty("sourcefile", sourceFile);
        prop.setProperty("sampleid", sampleid);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, CopyFile.ID);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, CopyFile.VERSIONID);
        prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
        prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
    }

    private String getFileLocation(String sampleid) throws SapphireException {
        String fileLocation = "";

        /*PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "Report");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }*/
        String sql = Util.parseMessage(MolecularSql.GET_ACCESSION_INFO_BY_SAMPLE, sampleid);
        DataSet dsAccessionIfo = getQueryProcessor().getSqlDataSet(sql);
        String sponsornumber = "", projectprotocolid = "";
        if (dsAccessionIfo.size() > 0) {
            sponsornumber = dsAccessionIfo.getValue(0, "sponsornumber");
            projectprotocolid = dsAccessionIfo.getValue(0, "projectprotocolid");
        }
        sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        //fileLocation = Util.generateMolLocPath(baseloc, "Molecular", "Reports");
        fileLocation = Util.generateMolReportLocPath(baseloc, sponsornumber, projectprotocolid, "Molecular", "Report");
        logger.info("MolecularGenetics>>Report Path>>>", fileLocation);

        return fileLocation;
    }

    /**
     * Description : This method is use to  generate report for Samples. This method takes input as sample Id and location.
     * When this method is called then a PDF report  is generated per sample an stored in the location which is provided as an Input
     *
     * @param sampleid
     * @param batchid
     * @throws SapphireException
     */

    public String generatereport(String sampleid, /*String location,*/ String batchid) throws SapphireException {
        String filename = "";
//        String batchID = "";


        if (!Util.isNull(sampleid) && !Util.isNull(batchid)) {
            String[] sampArr = StringUtil.split(sampleid, ";");
            String[] batchArr = StringUtil.split(batchid, ";");

            String sqlCorrectionValue = " select u_correctionvalue,s_sampleid from s_sample where s_sampleid" +
                    " in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "') ";

            DataSet dsCorrectionValue = getQueryProcessor().getSqlDataSet(sqlCorrectionValue);

            if (dsCorrectionValue == null) {
                String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sqlCorrectionValue;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

            }

            /**
             * For business logic GenerateReport action is used in loop. In a batch there are more than one sample so
             * report need to be generated per sample.
             */

            for (int i = 0; i < sampArr.length; i++) {
                String location = getFileLocation(sampArr[i]);
                String sql = "SELECT s.u_clientspecimenid,s.s_sampleid FROM s_sample s,s_sample ss WHERE s.s_sampleid = ss.u_rootsample and ss.s_sampleid =  '" + sampArr[i] + "'";

                String tc_sql = "select distinct t.testcodedesc from u_sampletestcodemap st,u_testcode t where st.lvtestcodeid = t.u_testcodeid " +
                        " and st.lvtestpanelid is null  and NVL(t.ispanel,'N') = 'N' and st.s_sampleid ='" + sampArr[i] + "'"; // Modified By msubhra
                DataSet dsTest = getQueryProcessor().getSqlDataSet(tc_sql);
                String tp_sql = "select distinct t.testname from u_sampletestcodemap st,u_testcode t where st.lvtestpanelid = t.u_testcodeid and " +
                        "st.ispanel = 'Y' and s_sampleid = '" + sampArr[i] + "'";
                DataSet dsPanel = getQueryProcessor().getSqlDataSet(tp_sql);
                DataSet ds = getQueryProcessor().getSqlDataSet(sql);

                if (ds == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

                }

                if (ds.size() == 0) {
                    String error = getTranslationProcessor().translate("Parent Sample of " + sampArr[i] + " doesn't have Client Specimen ID !" + sql);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

                }


                if (dsTest == null && dsPanel == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed:";
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

                }

                if (dsTest.size() == 0 && dsPanel.size() == 0) {
                    String error = getTranslationProcessor().translate("SampleID " + sampArr[i] + " doesn't have any Test !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

                }
                String rootsampleid = ds.getValue(0, "s_sampleid", "");
                if (Util.isNull(rootsampleid)) {
                    String error = getTranslationProcessor().translate("Parent Sample not found of sample " + sampArr[i]);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
                String clientspecimenid = ds.getValue(0, "u_clientspecimenid", "");
                if (Util.isNull(clientspecimenid)) {
                    String error = getTranslationProcessor().translate("Parent Sample of " + sampArr[i] + " doesn't have Client Specimen ID !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }

                //if (dsTest.size() > 0 && ds.size() > 0) {
                if (dsTest.size() > 0) {
                    // filename = location + File.separator+ "MolecularGenetics" + dsTest.getValue(0, "testcodedesc") + ds.getValue(0, "u_clientspecimenid") + ".pdf";
                    //filename = location + File.separator + clientspecimenid + "MolecularGenetics" + new Date().getTime() + ".pdf";TODO FILE SEPERATOR NOT NEEDED
                    filename = location + File.separator + clientspecimenid + "MolecularGenetics" + new Date().getTime() + ".pdf";
                    //} else if (dsPanel.size() > 0 && ds.size() > 0) {
                } else if (dsPanel.size() > 0) {
                    //  filename = location + "MolecularGenetics" + dsPanel.getValue(0, "testname") + ds.getValue(0, "u_clientspecimenid") + ".pdf";
                    filename = location + File.separator + clientspecimenid + "MolecularGenetics" + new Date().getTime() + ".pdf";
                    //filename = location + File.separator + clientspecimenid + "MolecularGenetics" + new Date().getTime() + ".pdf";TODO FILE SEPERATOR NOT NEEDED
                }

                String batch_sql = "select distinct b.u_ngbatchid from U_BATCH_SAMPLE_DETAIL bs,u_ngbatch b where b.u_ngbatchid=bs.u_ngbatchid and b.origin = 'Reporting' and bs.sampleid = '" + sampArr[i] + "'";
                String batch_sql1 = "select distinct ngbatchid from U_NGBATCHSAMPLEMAP where sampleid = '" + sampArr[i] + "'";

                DataSet ds_batch_sql = getQueryProcessor().getSqlDataSet(batch_sql);
                DataSet ds_batch_sql1 = getQueryProcessor().getSqlDataSet(batch_sql1);

                if (ds_batch_sql == null && ds_batch_sql1 == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed: ";
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
                }
                if (ds_batch_sql.size() == 0 && ds_batch_sql1.size() == 0) {
                    String err = "Sample " + sampArr[i] + " is not associated with any batch";
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
                }

//                if (Util.isNull(ds_batch_sql.getValue(0, "u_ngbatchid"))) {
//                    batchID = ds_batch_sql1.getValue(0, "ngbatchid");
//                } else {
//                    batchID = ds_batch_sql.getValue(0, "u_ngbatchid");
//                }

                PropertyList prop = new PropertyList();
                prop.clear();
                prop.setProperty("reportid", "MolecularGenetics");
                prop.setProperty("reportversionid", "1");
                prop.setProperty("sampleid", sampArr[i]);
                //prop.setProperty("batchid", batchID);
                //prop.setProperty("batchid", batchArr[i]);
                prop.setProperty("batchid", batchid);
                prop.setProperty("destination", "file");
                prop.setProperty("debuglog", "Y");
                prop.setProperty("filename", filename);
                prop.setProperty("filetype", "PDF");
                //prop.setProperty("actionid", "GenerateReport");
                //prop.setProperty("actionversionid", "1");


                try {
                    // getActionProcessor().processAction("AddToDoListEntry", "1", prop);
                    getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);//TODO OPEN AS REPORT WILL GENERATE FOR MSI
                    sendEmailNotificationForBioPharma(sampArr[i], batchid, rootsampleid, filename);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. Molecular Report not created for " + sampArr[i] + "Sample ID" + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }

                HashMap hm = new HashMap();
                hm.clear();
                hm.put("s_sampleid", sampArr[i]);
                DataSet dsFilterValue = dsCorrectionValue.getFilteredDataSet(hm);

                PropertyList propSamp = new PropertyList();
                propSamp.clear();
                propSamp.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                propSamp.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
                propSamp.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                propSamp.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                propSamp.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                propSamp.setProperty("ATTACHMENTCLASS", "SOP");


                try {
                    //getActionProcessor().processAction("AddToDoListEntry", "1", prop);
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, propSamp);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. Molecular Report not created for " + sampArr[i] + "Sample ID" + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }
                //Bellow code added for created report will also attach to the root sample.
                PropertyList propRoot = new PropertyList();
                propRoot.clear();
                propRoot.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Sample");
                propRoot.setProperty(AddSDIAttachment.PROPERTY_KEYID1, rootsampleid);
                propRoot.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                propRoot.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                propRoot.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                propRoot.setProperty("ATTACHMENTCLASS", "SOP");
                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, propRoot);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate(" Molecular Report not created for root sampleid:" + rootsampleid + "Error:" + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }

                /*    Modified by abanerjee */

                String sqlUpdate = " update sdiattachment set u_attachmenttype='" + dsFilterValue.getValue(0, "u_correctionvalue", "Normal") + "' where keyid1='" + rootsampleid + "'" +
                        " and sdcid='Sample' and attachmentnum=(select max(attachmentnum) from sdiattachment where keyid1='" + rootsampleid + "')";

                database.executeUpdate(sqlUpdate);
                /*    Modified by abanerjee */

                try {
                    copyFileSFTPPath(filename, sampArr[i]);
                } catch (Exception e) {
                    e.getMessage();
                }
            }
        }
        return filename;
    }


    /**
     * Description : This method is use to add the generated report in SDIAttachment SDC. Attachment should be associated with the sampleid
     * for which the report is being is created.
     *
     * @param sampleid
     * @param newfileloc
     * @throws SapphireException
     */
    public void addAttachment(String sampleid, String batchid, String newfileloc) throws SapphireException {

        String filename = "";
        String description = "";
        String batchID = "";


        if (!Util.isNull(sampleid) && !Util.isNull(batchid)) {
            String[] sampArr = StringUtil.split(sampleid, ";");
            String[] batchArr = StringUtil.split(batchid, ";");
            /**
             * For business logic AddSDIAttachment action is used in loop. In a batch there are more than one sample so
             * report need to be attached per sample with the batch.
             */
            for (int i = 0; i < sampArr.length; i++) {

                String sql = "SELECT s.u_clientspecimenid,s.s_sampleid FROM s_sample s,s_sample ss WHERE s.s_sampleid = ss.u_rootsample and ss.s_sampleid =  '" + sampArr[i] + "'";

                String tc_sql = "select distinct t.testcodedesc from u_sampletestcodemap st,u_testcode t where st.lvtestcodeid = t.u_testcodeid " +
                        " and st.lvtestpanelid is null  and NVL(t.ispanel,'N') = 'N' and st.s_sampleid ='" + sampArr[i] + "'"; // Modified By msubhra
                DataSet dsTest = getQueryProcessor().getSqlDataSet(tc_sql);
                String tp_sql = "select distinct t.testname from u_sampletestcodemap st,u_testcode t where st.lvtestpanelid = t.u_testcodeid and " +
                        "st.ispanel = 'Y' and s_sampleid = '" + sampArr[i] + "'";
                DataSet dsPanel = getQueryProcessor().getSqlDataSet(tp_sql);
                DataSet ds = getQueryProcessor().getSqlDataSet(sql);

                if (ds == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

                }

                /*This validation code is modified by bellow code
                if (ds.size() == 0) {
                    String error = getTranslationProcessor().translate("Parent Sample of " + sampArr[i] + " doesn't have Client Specimen ID !" + sql);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

                }*/
                String rootsampleid = ds.getValue(0, "s_sampleid", "");
                if (Util.isNull(rootsampleid)) {
                    String error = getTranslationProcessor().translate("Parent Sample not found of sample " + sampArr[i]);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
                String clientspecimenid = ds.getValue(0, "u_clientspecimenid", "");
                if (Util.isNull(clientspecimenid)) {
                    String error = getTranslationProcessor().translate("Parent Sample of " + sampArr[i] + " doesn't have Client Specimen ID !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }


                if (dsTest == null && dsPanel == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed:";
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

                }

                if (dsTest.size() == 0 && dsPanel.size() == 0) {
                    String error = getTranslationProcessor().translate("SampleID " + sampArr[i] + " doesn't have any Test !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

                }

             /*   //if (dsTest.size() > 0 && ds.size() > 0) {
                if (dsTest.size() > 0) {
                   // filename = location + "MolecularGenetics" + dsTest.getValue(0, "testcodedesc") + ds.getValue(0, "u_clientspecimenid") + ".pdf";
                    filename = location +  File.separator+ "MolecularGenetics" +new Date().getTime()+ ".pdf";
                   // description = location + "MolecularGenetics" + dsTest.getValue(0, "testcodedesc") + ds.getValue(0, "u_clientspecimenid") + ".pdf";
                    description = location + File.separator+ "MolecularGenetics" +new Date().getTime()+ ".pdf";
                    //} else if (dsPanel.size() > 0 && ds.size() > 0) {
                } else if (dsPanel.size() > 0) {
                   // filename = location + "MolecularGenetics" + dsPanel.getValue(0, "testname") + ds.getValue(0, "u_clientspecimenid") + ".pdf";
                   // description = location + "MolecularGenetics" + dsPanel.getValue(0, "testname") + ds.getValue(0, "u_clientspecimenid") + ".pdf";
                    filename = location +  File.separator+ "MolecularGenetics" +new Date().getTime()+ ".pdf";
                    description = location + File.separator+ "MolecularGenetics" +new Date().getTime()+ ".pdf";
                }*/

                String batch_sql = "select distinct b.u_ngbatchid from U_BATCH_SAMPLE_DETAIL bs,u_ngbatch b where b.u_ngbatchid=bs.u_ngbatchid and b.origin = 'Reporting' and bs.sampleid = '" + sampArr[i] + "'";
                String batch_sql1 = "select distinct ngbatchid from U_NGBATCHSAMPLEMAP where sampleid = '" + sampArr[i] + "'";

                DataSet ds_batch_sql = getQueryProcessor().getSqlDataSet(batch_sql);
                DataSet ds_batch_sql1 = getQueryProcessor().getSqlDataSet(batch_sql1);

                if (ds_batch_sql == null && ds_batch_sql1 == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed: ";
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
                }
                if (ds_batch_sql.size() == 0 && ds_batch_sql1.size() == 0) {
                    String err = "Sample " + sampArr[i] + " is not associated with any batch";
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
                }

                if (Util.isNull(ds_batch_sql.getValue(0, "u_ngbatchid"))) {
                    batchID = ds_batch_sql1.getValue(0, "ngbatchid");
                } else {
                    batchID = ds_batch_sql.getValue(0, "u_ngbatchid");
                }


                PropertyList prop = new PropertyList();
                prop.clear();
                prop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                //prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchID);
                prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchArr[i]);
                prop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                prop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newfileloc);
                prop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, newfileloc);
                prop.setProperty("ATTACHMENTCLASS", "SOP");
                //prop.setProperty("actionid", "AddSDIAttachment");
                //prop.setProperty("actionversionid", "1");
                //prop.setProperty("SDCID", "NGBatch");
                //prop.setProperty("keyid1", batchid);
                //prop.setProperty("description", description);
                //prop.setProperty("filename", filename);
                //prop.setProperty("type", "R");
                //prop.setProperty("ATTACHMENTCLASS", "SOP");


                try {
                    //getActionProcessor().processAction("AddToDoListEntry", "1", prop);
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, prop);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed. Molecular Report not created for " + sampArr[i] + "Sample ID" + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }
                //Bellow code added for created report will also attach to the root sample.
                PropertyList propRoot = new PropertyList();
                propRoot.clear();
                propRoot.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Sample");
                propRoot.setProperty(AddSDIAttachment.PROPERTY_KEYID1, rootsampleid);
                propRoot.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                propRoot.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newfileloc);
                propRoot.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, newfileloc);
                propRoot.setProperty("ATTACHMENTCLASS", "SOP");
                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, propRoot);
                } catch (SapphireException e) {
                    String errMSG = getTranslationProcessor().translate(" Molecular Report not created for root sampleid:" + rootsampleid + "Error:" + e.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }

            }
        }


    }

    /**
     * Description : This method is used to update date when the report is being created.
     *
     * @param samples
     * @throws SapphireException
     */

    public void updateReportDate(String samples) throws SapphireException {
        if (!Util.isNull(samples)) {
            String[] sampArr = StringUtil.split(samples, ";");
            /*DataSet dsReportingDate = new DataSet();
            dsReportingDate.addColumn("s_sampleid", DataSet.STRING);
            dsReportingDate.addColumn("u_reportingdt", DataSet.STRING);

            for (int i = 0; i < sampArr.length; i++) {
                int rowID = dsReportingDate.addRow();
                dsReportingDate.setValue(rowID, "s_sampleid", sampArr[i]);
                dsReportingDate.setValue(rowID, "u_reportingdt", "n");
            }*/


            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, samples);
            //prop.setProperty("u_reportingdts",StringUtil.repeat("n",sampArr.length,";"));
            prop.setProperty("u_reportingdts", "n");

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. Report date is not added to " + samples + "Samples" + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }

        }
    }

    private void sendEmailNotificationForBioPharma(String sampleid, String batchid, String rootsampleid, String filename) throws SapphireException {
        if (!Util.isNull(sampleid)) {
            String sql = Util.parseMessage(CommonSql.GET_INFO_FROM_SITE_LABEL_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(CommonSql.GET_INFO_FROM_PROJECT_LABEL_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
            ds.copyRow(dsProject, -1, 1);

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                DataSet tempDsFiltr = null;
                DataSet tempDsFiltrProjectLevel = null;
                String nodeId = "";
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            //TODO RESULT NOTIFICATION
                            hmap.put("type", "Email");
                            hmap.put("event", "Result Notification");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Result Notification");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ResultNotification";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, rootsampleid, nodeId, "SendMail", "");

                            //TODO REPORT DISTRIBUTION
                            hmap.clear();
                            hmap.put("type", "Email");
                            hmap.put("event", "Report Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Report Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ReportDistribution";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, rootsampleid, nodeId, "AttachReport", filename);

                            //TODO FAX DISTRIBUTION
                            hmap.clear();
                            hmap.put("type", "Fax");
                            hmap.put("event", "Fax Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Fax");
                            hmap.put("projevent", "Fax Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ReportFax";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, rootsampleid, nodeId, "AttachReport", filename);
                        }
                    }
                }
            }
        }
    }

    private void sendEmailNotificationForBioPharma_old(String sampleid, String batchid, String rootsampleid, String filename) throws SapphireException {
        if (!Util.isNull(sampleid)) {
            String sql = "select ac.u_accessionid,ac.patientid,ac.bioprojectname,ac.biositeid siteid,bio.invesitagtorname,bio.projectid,bio.sitename, biomail.email,biomail.event," +
                    "biomail.type,s.s_sampleid,subject.u_biopharmasubjectid,bioproject.projectprotocolid " +
                    "from u_accession ac,u_biosite bio,s_sample s,u_biositeemail biomail,s_subject subject,u_bioprojects bioproject " +
                    "where s.s_sampleid in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "') " +
                    "and s.u_accessionid = ac.u_accessionid " +
                    "and ac.biositeid = bio.u_biositeid " +
                    "and bio.u_biositeid=biomail.biositeid " +
                    "and ac.patientid=subject.s_subjectid " +
                    "and bio.projectid=bioproject.u_bioprojectsid " +
                    "order by ac.u_accessionid";

            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(CommonSql.PROJECT_EMAIL, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
            ds.copyRow(dsProject, -1, 1);

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                DataSet tempDsFiltr = null;
                DataSet tempDsFiltrProjectLevel = null;
                String nodeId = "";
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("type", "Email");
                            hmap.put("event", "Result Notification");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Result Notification");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0)
                                nodeId = "ResultNotification";
                            else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0)
                                nodeId = "ClinicalAccession";

                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, rootsampleid, nodeId, "SendMail", "");

                            hmap.clear();
                            hmap.put("type", "Email");
                            hmap.put("event", "Report Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Report Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0)
                                nodeId = "ReportDistribution";
                            else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0)
                                nodeId = "ClinicalAccession";

                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, rootsampleid, nodeId, "AttachReport", filename);

                            hmap.clear();
                            hmap.put("type", "Fax");
                            hmap.put("event", "Fax Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Fax");
                            hmap.put("projevent", "Fax Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0)
                                nodeId = "ReportFax";
                            else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0)
                                nodeId = "ClinicalAccession";
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, rootsampleid, nodeId, "AttachReport", filename);
                        }
                    }
                }
            }
        }
    }

    private void sendNotification(DataSet tempDsFiltr, DataSet tempDsFiltrProjectLevel, String batchid, String rootsampleid, String nodeid, String mode, String filename) throws SapphireException {
        String toList = "";
        PropertyList prop = new PropertyList();
        prop.setProperty(NGSendMail.NODE_ID, nodeid);
        prop.setProperty(NGSendMail.MODE, mode);
        if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
            toList = tempDsFiltr.getColumnValues("email", ";");
            if (!Util.isNull(toList)) {
                toList = Util.getUniqueList(toList, ";", true);
                String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                if (!Util.isNull(invistigatoName))
                    invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(rootsampleid, ";", true));
                prop.setProperty(NGSendMail.BATCHID, Util.getUniqueList(batchid, ";", true));
                prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                if (!Util.isNull(filename))
                    prop.setProperty(NGSendMail.FILENAME, filename);
            }
        }
        if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
            toList = tempDsFiltrProjectLevel.getColumnValues("email", ";") + ";" + toList;
            if (!Util.isNull(toList))
                toList = Util.getUniqueList(toList, ";", true);

            String sponcerName = tempDsFiltrProjectLevel.getColumnValues("sponsername", ";");
            if (!Util.isNull(sponcerName))
                sponcerName = Util.getUniqueList(sponcerName, ";", true);

            String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
            if (!Util.isNull(invistigatoName))
                invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

            prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(rootsampleid, ";", true));
            prop.setProperty(NGSendMail.BATCHID, Util.getUniqueList(batchid, ";", true));
            prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", ";"), ";", true));
            prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", "','"), ";", true));
            prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
            prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("investigatorsiteid", ";"), ";", true));
            prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
            prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("projectprotocolid", ";"), ";", true));
            prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
            prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
            if (!Util.isNull(filename))
                prop.setProperty(NGSendMail.FILENAME, filename);
        }
        if (toList != null && !"".equals(toList)) {
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }

    private void sendNotification_old(DataSet tempDsFiltr, DataSet tempDsFiltrProjectLevel, String batchid, String rootsampleid, String nodeid, String mode, String filename) throws SapphireException {
        String toList = "";
        PropertyList prop = new PropertyList();
        prop.setProperty(NGSendMail.NODE_ID, nodeid);
        prop.setProperty(NGSendMail.MODE, mode);
        if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
            toList = tempDsFiltr.getColumnValues("email", ";");
            if (!Util.isNull(toList)) {
                toList = Util.getUniqueList(toList, ";", true);
                String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                if (!Util.isNull(invistigatoName))
                    invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(rootsampleid, ";", true));
                prop.setProperty(NGSendMail.BATCHID, Util.getUniqueList(batchid, ";", true));
                prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                if (!Util.isNull(filename))
                    prop.setProperty(NGSendMail.FILENAME, filename);
            }
        }
        if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
            toList = tempDsFiltrProjectLevel.getColumnValues("emailorsftp", ";") + ";" + toList;
            if (!Util.isNull(toList))
                toList = Util.getUniqueList(toList, ";", true);

            String sponcerName = tempDsFiltrProjectLevel.getColumnValues("sponcername", ";");
            if (!Util.isNull(sponcerName))
                sponcerName = Util.getUniqueList(sponcerName, ";", true);

            prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(rootsampleid, ";", true));
            prop.setProperty(NGSendMail.BATCHID, Util.getUniqueList(batchid, ";", true));
            prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", ";"), ";", true));
            prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", "','"), ";", true));
            prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
            prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("projectprotocolid", ";"), ";", true));
            prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
            prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
            if (!Util.isNull(filename))
                prop.setProperty(NGSendMail.FILENAME, filename);
        }
        if (toList != null && !"".equals(toList)) {
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }

    private String automaticBatchValidation(String sampleid, String batchid) throws SapphireException {

        /*DataSet dsPanel = getMolPanelFrmPolicy();
        String sql = "select distinct st.s_sampleid,t.testcodedesc from u_sampletestcodemap st,u_testcode t where st.lvtestcodeid = t.u_testcodeid " +
                " and (st.lvtestpanelid is null or st.lvtestpanelid in('" + StringUtil.replaceAll(dsPanel.getColumnValues("panelid", ";"), ";", "','") + "'))" +
                " and st.s_sampleid in('" + StringUtil.replaceAll(samples.substring(1), ";", "','") + "')";

        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);*/
        DataSet ds = new DataSet();
        ds.addColumn("sampleid", DataSet.STRING);
        if (sampleid.startsWith(";"))
            sampleid = sampleid.substring(1);
        String sql = "select batchname,origin,nvl(mmerbatch,'N') mmerbatch from u_ngbatch where u_ngbatchid='" + batchid + "'";
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() > 0) {
            HashMap hm = new HashMap();
            hm.put("mmerbatch", "Y");
            DataSet dsAutoBatch = dsBatchInfo.getFilteredDataSet(hm);
            if (dsAutoBatch != null && dsAutoBatch.size() > 0) {
                sql = "select s.s_sampleid,ngsmp.ngbatchid,s.u_extractionid from u_ngbatchsamplemap ngsmp, s_sample s where" +
                        " s.s_sampleid = ngsmp.sampleid" +
                        " and ngsmp.ngbatchid='" + batchid + "' and ngsmp.sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
                DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
                    String extractionid = Util.getUniqueList(dsSampleInfo.getColumnValues("u_extractionid", ";"), ";", true);
                    String extracArry[] = StringUtil.split(extractionid, ";");
                    for (int i = 0; i < extracArry.length; i++) {
                        hm.clear();
                        hm.put("u_extractionid", extracArry[i]);
                        DataSet dsFilter = dsSampleInfo.getFilteredDataSet(hm);
                        if (dsFilter != null && dsFilter.size() > 0) {
                            int rowId = ds.addRow();
                            ds.setValue(rowId, "sampleid", dsFilter.getValue(0, "s_sampleid", ""));
                        }
                    }
                    sampleid = ds.getColumnValues("sampleid", ";");
                }

            }

            hm.clear();
            hm.put("mmerbatch", "N");
            DataSet dsNormalBatch = dsBatchInfo.getFilteredDataSet(hm);
            if (dsNormalBatch != null && dsNormalBatch.size() > 0) {
                sampleid = sampleid;
            }
        }

        return sampleid;

    }

    private DataSet getMolPanelFrmPolicy() throws SapphireException {
        DataSet dsPanelIds = new DataSet();
        dsPanelIds.addColumn("panelid", DataSet.STRING);
        PropertyList policyProps = getConfigurationProcessor().getPolicy(POLICY_NAME, POLICY_NODE);
        if (policyProps != null) {
            PropertyListCollection panelcollectioninfo = policyProps.getCollection("panelcollection");
            for (int i = 0; i < panelcollectioninfo.size(); i++) {
                int rowID = dsPanelIds.addRow();
                dsPanelIds.setValue(rowID, "panelid", panelcollectioninfo.getPropertyList(i).getProperty("panelid"));
            }
        }
        return dsPanelIds;
    }

    private boolean validateNYLicence(String sampleId) {
        String currentUser = connectionInfo.getSysuserId();
        String sql = "select 1 from u_physician where userid = '" + currentUser + "' and nyflag = 'Y' and nylicensenumber is not null";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        String uniqueSamples = Util.getUniqueList(sampleId, ";", true);

        if (ds != null && ds.size() == 0) {
            sql = "select u_accession.u_accessionid,u_accession.clientid,u_client.nyflag from u_accession,u_client "
                    + " where  u_accession.u_accessionid in (select u_accessionid from s_sample where s_sampleid in('" + uniqueSamples.replaceAll(";", "','") + "')) "
                    + " and u_accession.clientid = u_client.u_clientid and u_client.nyflag='Y' ";

            ds.clear();
            ds = getQueryProcessor().getSqlDataSet(sql);
            if (ds != null && ds.size() > 0)
                return false;
        }
        return true;
    }

    private void updateBatchStatus(String batchid) throws SapphireException {
        String sql = "select 1 from s_sample where s_sampleid in (select sampleid from u_batch_sample_detail where u_ngbatchid ='" + batchid + "') "
                + " and u_reportingdts is not null ";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0) {
            try {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
                prop.setProperty("batchstatusview", "Reporting Completed");
                prop.setProperty("batchcompletedts", "n");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. Unable to update batch status::" + batchid + "::" + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
        }

    }
}






