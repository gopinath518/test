package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.DecimalFormat;

/**
 * Created by akumar on 3/28/2017.
 */
public class DiscoveryAgilentCalculation extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String sql = "select s_sampleid,u_ngsdisagilentconc,u_ngsdisagilentpipetvol,u_agilentdilutionfactor,u_agilentrsbtodilute" +
                " from s_sample where s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "') and u_agilentdilutionfactor is null";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        float dilutionfactor, dsrsbtodilute;
        if (ds.size() > 0) {
            DecimalFormat df = new DecimalFormat("#.#");

            for (int i = 0; i < ds.size(); i++) {
                if (ds.getValue(i, "u_ngsdisagilentconc") != null && ds.getValue(i, "u_ngsdisagilentpipetvol") != null) {
                    if (!ds.getValue(i, "u_ngsdisagilentconc").equalsIgnoreCase("") && !ds.getValue(i, "u_ngsdisagilentpipetvol").equalsIgnoreCase("")) {
                        float conc = Float.parseFloat(ds.getValue(i, "u_ngsdisagilentconc"));
                        float vol = Float.parseFloat(ds.getValue(i, "u_ngsdisagilentpipetvol"));
                        dilutionfactor = Float.parseFloat(df.format(conc/4));
                        dsrsbtodilute = Float.parseFloat(df.format((vol*dilutionfactor)-vol));
                        ds.setValue(i, "u_agilentdilutionfactor", String.valueOf(dilutionfactor));
                        ds.setValue(i, "u_agilentrsbtodilute", String.valueOf(dsrsbtodilute));

                    }
                }
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_agilentdilutionfactor", ds.getColumnValues("u_agilentdilutionfactor", ";"));
            prop.setProperty("u_agilentrsbtodilute", ds.getColumnValues("u_agilentrsbtodilute", ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }
    }
}
