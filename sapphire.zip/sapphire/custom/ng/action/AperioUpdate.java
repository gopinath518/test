package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by dgupta on 7/16/2016.
 * Modified by surajit.baitalik
 */
public class AperioUpdate extends BaseAction {

    /*
    *   This is out of box method provide to override and put requirement specific logic here
    *   currently it is adding a row in aperiostatus sdc and calling a function to update
    *   sample status
    *   @param  properties  property set of input
    *
    * */
    public void processAction(PropertyList properties) throws SapphireException {
        String barcode = properties.getProperty("barcode");
        String filepath = properties.getProperty("filepath");
        String filename = properties.getProperty("filename");
        String statuscode = properties.getProperty("statuscode");
        String statusmessage = properties.getProperty("statusmessage");
        String scanner = properties.getProperty("scanner");
        String scanstarttime = properties.getProperty("scanstarttime");
        String siteid = properties.getProperty("siteid");
        logger.info("AperioUpdate::", "Scanned Sampleid: " + barcode);
        try {
            if (null == barcode || 0 == barcode.trim().length()) {
                throw new SapphireException(getTranslationProcessor().translate("Bar code id can not be null"));
            }
            //GET TEST INFORMATION BY BARCODE
            String sql = Util.parseMessage(ApSql.GET_TESTNAME_BY_SAMPLEID, barcode);
            DataSet dsTestInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTestInfo.size() == 0) {
                logger.info("AperioUpdate::", "No Test found into the specimen.");
            }
            String methodology = "";
            if (dsTestInfo != null || dsTestInfo.size() > 0) {
                methodology = dsTestInfo.getValue(0, "methodology", "");
                logger.info("AperioUpdate::", "Test found into the specimen.");
                dsTestInfo.showData();
            }
            //GET INFORMATION FOR BARCODE
            String sqlSpPr = Util.parseMessage(ApSql.GET_SPONSOR_PROJECT_INFO_BY_SAMPLEID, StringUtil.replaceAll(barcode, ";", "','"));
            DataSet dsSpPrInfo = getQueryProcessor().getSqlDataSet(sqlSpPr);
            if (dsSpPrInfo == null || dsSpPrInfo.size() == 0) {
                logger.info("AperioUpdate::", "Invalid specimen. No Sponsor, Project data found.");
                throw new SapphireException("AperioUpdate::Invalid specimen.");
            }
            dsSpPrInfo.showData();
            String sponsor = dsSpPrInfo.getValue(0, "sponsorname");
            String study = dsSpPrInfo.getValue(0, "projectprotocolid");
            String u_sponsorid = dsSpPrInfo.getValue(0, "u_sponsorid");
            String u_bioprojectsid = dsSpPrInfo.getValue(0, "u_bioprojectsid");
            if (Util.isNull(sponsor) || Util.isNull(study) || Util.isNull(u_sponsorid) || Util.isNull(u_bioprojectsid)) {
                logger.info("AperioUpdate::", "Valid specimen: " + barcode + " Sponsor: " + sponsor + " Project: " + study + " data found.");
                throw new SapphireException("AperioUpdate:: Failed for blank value(s) of SponsorName: " + sponsor + " or Project: "
                        + study + " or SponsorKeyid1: " + u_sponsorid + " or ProjectkeyId1: " + u_bioprojectsid);
            }
            logger.info("AperioUpdate::", "Valid specimen: " + barcode + " Sponsor: " + sponsor + " Project: " + study + " data found.");

            String rootpath = "";
            PropertyList props = new PropertyList();
            if ("Flow".equalsIgnoreCase(methodology)) {
                rootpath = filepath;
                logger.info("AperioUpdate::", methodology + " Path:" + rootpath);
            } else {
                logger.info("AperioUpdate::", methodology + " Path:" + rootpath);
                //GET WINDOWN MAPPING PATH FROM DB
                DataSet dsMountedPath = getMountedPath(siteid, methodology);
                rootpath = dsMountedPath.getValue(0, "windowspath", "");
                if (Util.isNull(rootpath)) {
                    logger.info("AperioUpdate::", "Windows path not found.Keyid1 is AperioPath");
                    String errMsg = getTranslationProcessor().translate("Root path can't be null.Please contact to Admin to provide a root path in configuration.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
                logger.info("AperioUpdate::", "Windows path found.");
                String serverpath = dsMountedPath.getValue(0, "mounteddrive");
                if (Util.isNull(serverpath)) {
                    logger.info("AperioUpdate::", "Mounted path not found.Keyid1 is AperioPath");
                    String errMsg = getTranslationProcessor().translate("Mounted path can't be null.Please contact to Admin to provide a root path in configuration.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
                logger.info("AperioUpdate::", "Mounted path found.Keyid1 is AperioPath");
                File theDir = new File(serverpath);
                if (!theDir.canWrite()) {
                    logger.info("AperioUpdate::", serverpath + " path have no write permission.");
                    String errMsg = getTranslationProcessor().translate("Unable to proceed." + serverpath + " directory doesn't have write permission.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
                logger.info("AperioUpdate::", serverpath + " path have write permission.");
                theDir = new File(serverpath);
                if (!theDir.isDirectory()) {
                    logger.info("AperioUpdate::", serverpath + " path is not a directory.");
                    String errMsg = getTranslationProcessor().translate("Unable to proceed. " + filepath + " directory doesn't have write permission.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
                logger.info("AperioUpdate::", serverpath + " path is a directory.");
            }

            String parentfolder = "";
            sql = Util.parseMessage(ApSql.GET_VMSFOLDERID_BY_PATH, u_sponsorid, u_bioprojectsid);
            DataSet dsRootInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsRootInfo.size() > 0) {
                parentfolder = dsRootInfo.getValue(0, "u_vmsfolderid", "");
                logger.info("AperioUpdate::", "Parent Folder found for Sponsor: " + u_sponsorid + ",Project:" + u_bioprojectsid);
            }
            if (dsRootInfo.size() == 0) {
                logger.info("AperioUpdate::", "Parent Folder not found for Sponsor: " + u_sponsorid + ",Project:" + u_bioprojectsid);
                props.clear();
                props.setProperty(AddSDI.PROPERTY_SDCID, "VMSFolder");
                props.setProperty(AddSDI.PROPERTY_COPIES, "1");
                props.setProperty("rootfolder", rootpath);
                props.setProperty("foldername", study);
                props.setProperty("folderpath", filepath);
                props.setProperty("sponsorid", u_sponsorid);
                props.setProperty("projectid", u_bioprojectsid);
                props.setProperty("type", "FLD");
                props.setProperty("isrootfolder", "Y");
                props.setProperty("methodology", methodology);
                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                } catch (Exception ex) {
                    logger.info("AperioUpdate::", "Can't create Root Project Folder into VMS>>>>>>" + ex.getMessage());
                    throw new SapphireException("Can't create Root Project Folder into VMS>>>>>>" + ex.getMessage());
                }
                parentfolder = props.getProperty("newkeyid1");
                logger.info("AperioUpdate::", "Root Project Folder into VMS successfully created.");
            }
            sql = Util.parseMessage(ApSql.CHECK_APERIO_RECORD, barcode);
            DataSet dsAperioUpdates = getQueryProcessor().getSqlDataSet(sql);
            if (dsAperioUpdates.size() == 0) {
                logger.info("AperioUpdate::", "First time scan barcode: " + barcode);
                addAperioScannedRecord(properties, rootpath, u_sponsorid, u_bioprojectsid, parentfolder, barcode, methodology);
            } else {
                logger.info("AperioUpdate::", "Updating Aperio records for scan barcode: " + barcode);
                updateAperioScannedRecord(properties, dsAperioUpdates.getValue(0, "currentfolderid"),
                        dsAperioUpdates.getValue(0, "u_aperiostatusid"), methodology);
            }
            updateSampleStatus(barcode, statuscode.equalsIgnoreCase("0") ? "ImagingCompleted" : "ImagingFail", statuscode);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Exception:: " + ex.getMessage());
            throw new SapphireException("Exception:" + ex.getMessage());
        }
        logger.info("AperioUpdate::", "Exit");
        //throw new SapphireException("test");
    }

    /*
    *  This methos update sample status and status code as provided in input
    *  @param  barcode its input sampleid
    *  @param  samplestatus  status of sample to be set
    *  @param  statuscode  string value of status cod
    *
    * */

    private void updateSampleStatus(String barcode, String samplestatus, String statuscode) throws SapphireException {
        //DataSet dsSample = getQueryProcessor().getSqlDataSet("select s_sampleid from s_sample where s_sampleid ='" + barcode + "'");
        DataSet dsSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(ApSql.GET_INFO_SAMPLEID_APERIO_UPDATE, barcode));
        if (null == dsSample || dsSample.getRowCount() == 0) {
            logger.info("AperioUpdate::", "No matching labvantage sample id found for barcode " + barcode);
            throw new SapphireException(getTranslationProcessor().translate("No matching labvantage sample id found for barcode " + barcode));
        }
        logger.info("AperioUpdate::", "Labvantage sample id found for barcode " + barcode);
        if (statuscode.equalsIgnoreCase("0")) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, barcode);
            //prop.setProperty("u_currentmovementstep", samplestatus);
            prop.setProperty("u_imageingqcstatus", samplestatus);
            prop.setProperty("u_imagingdts", "n");
            prop.setProperty("u_vmsqcstatus", "(null)");
            prop.setProperty("u_vmsqcreason", "(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                logger.info("AperioUpdate::", "Sample status update failed for barcode: " + barcode + " Error:" + ex.getMessage());
                throw new SapphireException("Sample status update failed for barcode: " + barcode + " Error:" + ex.getMessage());
            }
            logger.info("AperioUpdate::", "Sample status update successfully for barcode: " + barcode);
        } else {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, barcode);
            //prop.setProperty("u_currentmovementstep", samplestatus);
            prop.setProperty("u_imageingqcstatus", samplestatus);
            prop.setProperty("u_vmsqcstatus", "(null)");
            prop.setProperty("u_vmsqcreason", "(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                logger.info("AperioUpdate::", "Sample status update failed for barcode: " + barcode + " Error:" + ex.getMessage());
                throw new SapphireException("Sample status update failed for barcode: " + barcode + " Error:" + ex.getMessage());
            }
            logger.info("AperioUpdate::", "Sample status update successfully for barcode: " + barcode);
        }
    }

    private void addAperioScannedRecord(PropertyList properties, String rootpath, String u_sponsorid, String u_bioprojectsid,
                                        String parentfolder, String barcode, String methodology) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "VMSFolder");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props.setProperty("rootfolder", rootpath);
        props.setProperty("foldername", properties.getProperty("filename"));
        props.setProperty("folderpath", properties.getProperty("filepath") + "\\" + properties.getProperty("filename"));
        props.setProperty("sponsorid", u_sponsorid);
        props.setProperty("projectid", u_bioprojectsid);
        props.setProperty("vmsfolderparentid", parentfolder);
        props.setProperty("type", "IMG");
        props.setProperty("methodology", methodology);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Image file can not inserted into VMSFolder for barcode: " + barcode + " Error:" + ex.getMessage());
            throw new SapphireException("Image file can not inserted into VMSFolder for barcode: " + barcode + " Error:" + ex.getMessage());
        }
        logger.info("AperioUpdate::", "Image file inserted successfully into VMSFolder for barcode: " + barcode);
        String folderid = props.getProperty("newkeyid1");
        props.clear();
        props.setProperty(AddSDI.PROPERTY_SDCID, "AperioStatus");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props.setProperty("barcode", barcode);
        props.setProperty("filepath", properties.getProperty("filepath"));
        props.setProperty("filename", properties.getProperty("filename"));
        props.setProperty("statuscode", properties.getProperty("statuscode"));
        props.setProperty("statusmessage", properties.getProperty("statusmessage"));
        props.setProperty("scanner", properties.getProperty("scanner"));
        props.setProperty("scanstarttime", properties.getProperty("scanstarttime"));
        props.setProperty("siteid", properties.getProperty("siteid"));
        props.setProperty("scanendtime", "n");
        props.setProperty("currentfolderid", folderid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Image file can not inserted into AperioStatus for barcode: " + barcode + " Error:" + ex.getMessage());
            throw new SapphireException("Image file can not inserted into AperioStatus for barcode: " + barcode + " Error:" + ex.getMessage());
        }
        logger.info("AperioUpdate::", "Image file inserted successfully into AperioStatus for barcode: " + barcode);

        //UPDATE IMAGING DATES
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, barcode);
        prop.setProperty("u_imagingdts", "n");
        prop.setProperty("u_vmsqcstatus", "(null)");
        prop.setProperty("u_vmsqcreason", "(null)");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Sample status update failed for barcode: " + barcode + " Error:" + ex.getMessage());
            throw new SapphireException("Sample status update failed for barcode: " + barcode + " Error:" + ex.getMessage());
        }
        updateImagingDtAnalyte(barcode);
        logger.info("AperioUpdate::", "Sample status update successfully for barcode: " + barcode);
    }

    private void updateAperioScannedRecord(PropertyList properties, String vmsfolderid, String aperioid, String methodology) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "VMSFolder");
        props.setProperty(EditSDI.PROPERTY_KEYID1, vmsfolderid);
        //props.setProperty("rootfolder", rootpath);
        props.setProperty("foldername", properties.getProperty("filename"));
        props.setProperty("folderpath", properties.getProperty("filepath") + "\\" + properties.getProperty("filename"));
        props.setProperty("methodology", methodology);
        //props.setProperty("sponsorid", u_sponsorid);
        //props.setProperty("projectid", u_bioprojectsid);
        //props.setProperty("vmsfolderparentid", parentfolder);
        //props.setProperty("type", "IMG");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Image file update failed into VMSfolder for filename: " + properties.getProperty("filename") + " Error: " + ex.getMessage());
            throw new SapphireException("Image file update failed into VMSfolder for filename: " + properties.getProperty("filename") + " Error: " + ex.getMessage());
        }
        logger.info("AperioUpdate::", "Image file update successfully into VMSfolder for filename: " + properties.getProperty("filename"));
        //String folderid = props.getProperty("newkeyid1");
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "AperioStatus");
        props.setProperty(EditSDI.PROPERTY_KEYID1, aperioid);
        //props.setProperty("barcode", barcode);
        props.setProperty("filepath", properties.getProperty("filepath"));
        props.setProperty("filename", properties.getProperty("filename"));
        props.setProperty("statuscode", properties.getProperty("statuscode"));
        props.setProperty("statusmessage", properties.getProperty("statusmessage"));
        props.setProperty("scanner", properties.getProperty("scanner"));
        props.setProperty("scanstarttime", properties.getProperty("scanstarttime"));
        props.setProperty("siteid", properties.getProperty("siteid"));
        props.setProperty("scanendtime", "n");
        //props.setProperty("currentfolderid", folderid);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Image file update failed into AperioStatus for filename: " + properties.getProperty("filename") + " Error: " + ex.getMessage());
            throw new SapphireException("Image file update failed into AperioStatus for filename: " + properties.getProperty("filename") + " Error: " + ex.getMessage());
        }
        logger.info("AperioUpdate::", "Image file update successfully into AperioStatus for filename: " + properties.getProperty("filename"));
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, properties.getProperty("barcode"));
        prop.setProperty("u_imagingdts", "n");
        prop.setProperty("u_vmsqcstatus", "(null)");
        prop.setProperty("u_vmsqcreason", "(null)");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            logger.info("AperioUpdate::", "Sample status update failed for barcode: " + properties.getProperty("barcode") + " Error:" + ex.getMessage());
            throw new SapphireException("Sample status update failed for barcode: " + properties.getProperty("barcode") + " Error:" + ex.getMessage());
        }
        updateImagingDtAnalyte(properties.getProperty("barcode"));
        logger.info("AperioUpdate::", "Sample status update successfully for barcode: " + properties.getProperty("barcode"));
    }

    private DataSet getMountedPath(String siteid, String methodology) throws SapphireException {
        DataSet dsMountedPath = null;
        /*String crrntdept = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(crrntdept, "-")[0];*/
        //String sql = ApSql.GET_WINDOWS_MAPPING_PATH;
        String sql = Util.parseMessage(ApSql.GET_WINDOWS_MAPPING_PATH, siteid, methodology);
        dsMountedPath = getQueryProcessor().getSqlDataSet(sql);

        if (dsMountedPath == null)
            throw new SapphireException("Network path and mounted drive mapping info cannot be obtained from database.");
        if (dsMountedPath.size() == 0)
            throw new SapphireException("The Query:\n" + sql + "\n is returning no row.");
        if (dsMountedPath.size() > 1)
            throw new SapphireException(siteid + " site has more than one mounted path to scan image(s).");

        return dsMountedPath;
    }

    private void updateImagingDtAnalyte(String sampleid) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_PARAMS_IMAGINGDT, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsImagingDt = getQueryProcessor().getSqlDataSet(sql);
        if (dsImagingDt != null && dsImagingDt.size() > 0) {
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
            Date date = new Date();
            String crrntdt = formatter.format(date);
            PropertyList props = new PropertyList();
            props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsImagingDt.getColumnValues("childsampleid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsImagingDt.getColumnValues("paramlistid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsImagingDt.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsImagingDt.getColumnValues("paramid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsImagingDt.getColumnValues("variantid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsImagingDt.getColumnValues("paramtype", ";"));
            props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsImagingDt.getColumnValues("replicateid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_DATASET, dsImagingDt.getColumnValues("dataset", ";"));
            props.setProperty("enteredtext", StringUtil.repeat(crrntdt.toUpperCase(), dsImagingDt.size(), ";"));
            props.setProperty("displayvalue", StringUtil.repeat(crrntdt.toUpperCase(), dsImagingDt.size(), ";"));
            try {
                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException("IHC Imaging date  not performed." + e.getMessage());
            }
        }
    }
}
