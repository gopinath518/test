package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Constants;
import sapphire.error.ErrorDetail;
import sapphire.util.ConnectionInfo;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;


/**
 * Created by Ashish kumar on 3/23/2016.
 *
 * @Desc : This Action adds multiple sample under one  Accession
 * Generates clientspecimenid for the samples and also sets the custodian of the samples.
 */
public class AddMultiSample extends BaseAction {
    String gnewkeyid1;
    public static final String ID = "AddMultiSample";
    public static final String VERSIONID = "1";

    public static final String DATASET_COLUMN_TYPE = "u_type";
    public static final String DATASET_COLUMN_TYPE_UPDATED = "iftypeupdated";
    public static final String TRANSPORT_TYPE_UNSTAINED_SLIDE = "Unstained Slide";
    public static final String TRANSPORT_TYPE_STAINED_SLIDE = "Stained Slide";
    public static final String TRANSPORT_TYPE_HNE_SLIDE = "H&E Slide";
    public static final String SAMPLE_TYPE_HNE_SLIDE = "FFPE scrolls";

    public void processAction(PropertyList properties) throws SapphireException {
        String copies = properties.getProperty("copies", "1");
        String sampletypeid = properties.getProperty("sampletype");
        String accessionid = properties.getProperty("accession");
        String transporttype = properties.getProperty("transporttype");
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();

        int noOfItem = StringUtil.split(sampletypeid, ";").length;

        DataSet dsSample = new DataSet();
        dsSample.addColumnValues("sampletypeid", DataSet.STRING, sampletypeid, ";");
        dsSample.addColumnValues("transporttypeid", DataSet.STRING, transporttype, ";");
        dsSample.addColumnValues("copies", DataSet.STRING, copies, ";");
        dsSample.addColumnValues("accessionid", DataSet.STRING, StringUtil.repeat(accessionid, noOfItem, ";"), ";");

        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("sampletypeid", DataSet.STRING);
        dsSamplefinal.addColumn("transporttypeid", DataSet.STRING);// transport
        dsSamplefinal.addColumn("accessionid", DataSet.STRING);//aacc
        dsSamplefinal.addColumn("study", DataSet.STRING);
        dsSamplefinal.addColumn("currentuser", DataSet.STRING);
        dsSamplefinal.addColumn("defaultdepartment", DataSet.STRING);

        for (int i = 0; i < dsSample.getRowCount(); i++) {
            int cp = Integer.parseInt(dsSample.getValue(i, "copies"));
            for (int j = 0; j < cp; j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "sampletypeid", dsSample.getValue(i, "sampletypeid"));
                dsSamplefinal.setValue(rowID, "transporttypeid", dsSample.getValue(i, "transporttypeid"));
                dsSamplefinal.setValue(rowID, "accessionid", dsSample.getValue(i, "accessionid"));
                dsSamplefinal.setValue(rowID, "study", "NeoClinical");
                dsSamplefinal.setValue(rowID, "currentuser", currentuser);
                dsSamplefinal.setValue(rowID, "defaultdepartment", defaultdepartment);

            }
        }

        createSample(dsSamplefinal);
        generateSpecimenID(gnewkeyid1);
        /*if ("Unstained Slide(s)".equalsIgnoreCase(transporttype)) {
            markAsUnstainedSlide(gnewkeyid1);
        }*/
        markClientSlides(dsSamplefinal);

        // properties.setProperty("newkeyid1", gnewkeyid1);
        properties.setProperty("newsample", gnewkeyid1);


    }

    /**
     * @param gnewkeyid1 -Newly created sampleid
     * @throws SapphireException
     * @Desc :Generates the clientspecimenid for the newly created samples
     */

    private void generateSpecimenID(String gnewkeyid1) throws SapphireException {
        PropertyList hsCreateContainer = new PropertyList();
        hsCreateContainer.clear();
        hsCreateContainer.setProperty("sampleid", gnewkeyid1);

        try {
            getActionProcessor().processAction("CreateContainer", "1", hsCreateContainer);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * @param dsSampleFinal -DataSet which contains information to create samples
     * @throws SapphireException
     * @Desc :Creates new sample based on the sampletype chosen
     */

    private void createSample(DataSet dsSampleFinal) throws SapphireException {

     /*   dsSampleFinal.addColumn("movementstep", DataSet.STRING);
        //dsSample

        String sampleTypeIDs = dsSampleFinal.getColumnValues("sampletypeid", ";");
        String transportTypeIDs = dsSampleFinal.getColumnValues("transporttypeid", ";");

        String sql = "select s_sampletypeid,containertypeid,u_movementstep" +
                " from s_sampletypecontainertype" +
                " where s_sampletypeid in ('" + StringUtil.replaceAll(sampleTypeIDs, ";", "','") + "')" +
                " and containertypeid in ('" + StringUtil.replaceAll(transportTypeIDs, ";", "','") + "')";
        DataSet dsStepMap = getQueryProcessor().getSqlDataSet(sql);
        if (dsStepMap == null) {
            String errMSG = getTranslationProcessor().translate("Contact you Administrator. SQL failed:");
            errMSG += sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        if (dsStepMap.size() == 0) {
            String errMSG = getTranslationProcessor().translate("Steps is not defined in master data. SQL failed:");
            errMSG += sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMSG);
        }

        for (int i = 0; i < dsSampleFinal.size(); i++) {
            HashMap hm = new HashMap();
            hm.put("s_sampletypeid", dsSampleFinal.getValue(i, "sampletypeid"));
            hm.put("containertypeid", dsSampleFinal.getValue(i, "transporttypeid"));


            DataSet dsFilter = dsStepMap.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0)
                dsSampleFinal.setValue(i, "movementstep", dsFilter.getValue(0, "u_movementstep"));
        }
*/

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsSampleFinal.getRowCount()));
        props.setProperty("sstudyid", dsSampleFinal.getColumnValues("study", ";"));
        props.setProperty("sampletypeid", dsSampleFinal.getColumnValues("sampletypeid", ";"));
        //   props.setProperty("u_currentmovementstep", dsSampleFinal.getColumnValues("movementstep", ";"));
        props.setProperty("u_accessionid", dsSampleFinal.getColumnValues("accessionid", ";"));
        props.setProperty("storagestatus", "In Circulation");
        props.setProperty("u_accessioningcomplete", "N");
        props.setProperty("u_currentmovementstep", "Accession");

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        String newkeyid = props.getProperty("newkeyid1");
        gnewkeyid1 = newkeyid;
        //props.put("newkeyid1",newkeyid);
        String[] sampleid = StringUtil.split(newkeyid, ";");
        dsSampleFinal.addColumn("sampleid", DataSet.STRING);
        for (int i = 0; i < dsSampleFinal.getRowCount(); i++) {

            dsSampleFinal.setValue(i, "sampleid", sampleid[i]);
        }

        updateTrackItem(dsSampleFinal);

    }

    /**
     * @param dsSampleFinal-DataSet containing sample related information
     * @throws SapphireException
     * @Desc :updates the containertype and custodian of a sample in Trackitem for tracking.
     */

    private void updateTrackItem(DataSet dsSampleFinal) throws SapphireException {
        PropertyList editTIProps = new PropertyList();

        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSampleFinal.getColumnValues("sampleid", ";"));
        editTIProps.setProperty("containertypeid", dsSampleFinal.getColumnValues("transporttypeid", ";"));
        editTIProps.setProperty("custodialuserid", dsSampleFinal.getColumnValues("currentuser", ";"));
        editTIProps.setProperty("custodialdepartmentid", dsSampleFinal.getColumnValues("defaultdepartment", ";"));
        editTIProps.setProperty("u_currenttramstop", StringUtil.repeat("Accession", dsSampleFinal.size(), ";"));//for tracking u_currenttramstop

        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);

    }

    /*private void markAsUnstainedSlide(String newkeyid) throws SapphireException {
        String sampleidArry[] = StringUtil.split(newkeyid, ";");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid);
        prop.setProperty("u_type", StringUtil.repeat("CU", sampleidArry.length, ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
    }*/
    private void markClientSlides(DataSet dsFinal) throws SapphireException {
        if (!dsFinal.isValidColumn(DATASET_COLUMN_TYPE)) {
            dsFinal.addColumn(DATASET_COLUMN_TYPE, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_COLUMN_TYPE_UPDATED)) {
            dsFinal.addColumn(DATASET_COLUMN_TYPE_UPDATED, DataSet.STRING);
        }

        HashMap hm = new HashMap();
        hm.put("transporttypeid", TRANSPORT_TYPE_UNSTAINED_SLIDE);
        DataSet dsUnstainedSlide = dsFinal.getFilteredDataSet(hm);
        if (dsUnstainedSlide != null && dsUnstainedSlide.size() > 0) {
            for (int i = 0; i < dsUnstainedSlide.size(); i++) {
                dsUnstainedSlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                dsUnstainedSlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_UNSTAINED_SLIDE);
            }

        }
        hm.clear();
        hm.put("transporttypeid", TRANSPORT_TYPE_STAINED_SLIDE);
        DataSet stainedSlide = dsFinal.getFilteredDataSet(hm);
        if (stainedSlide != null && stainedSlide.size() > 0) {
            for (int i = 0; i < stainedSlide.size(); i++) {
                stainedSlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                stainedSlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_STAINED_SLIDE); //Client Stained Slide
            }

        }

        hm.clear();
        hm.put("transporttypeid", TRANSPORT_TYPE_HNE_SLIDE);
        DataSet HNESlide = dsFinal.getFilteredDataSet(hm);
        if (HNESlide != null && HNESlide.size() > 0) {
            for (int i = 0; i < HNESlide.size(); i++) {
                HNESlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                HNESlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_HNE_SLIDE); //Client H&E
            }

        }

        hm.clear();
        hm.put("sampletypeid", SAMPLE_TYPE_HNE_SLIDE);
        DataSet scroolsfiletr = dsFinal.getFilteredDataSet(hm);
        if (scroolsfiletr != null && scroolsfiletr.size() > 0) {
            for (int i = 0; i < scroolsfiletr.size(); i++) {
                scroolsfiletr.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                scroolsfiletr.setValue(i, DATASET_COLUMN_TYPE, "FB"); //FFPE SCROLLS
            }

        }

        hm.clear();
        hm.put(DATASET_COLUMN_TYPE_UPDATED, "Y");
        DataSet dsToUpdate = dsFinal.getFilteredDataSet(hm);

        if (dsToUpdate != null && dsToUpdate.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsToUpdate.getColumnValues("sampleid", ";"));
            prop.setProperty("u_type", dsToUpdate.getColumnValues(DATASET_COLUMN_TYPE, ";"));
            prop.setProperty("u_rootsample", dsToUpdate.getColumnValues("sampleid", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }
    }


}


