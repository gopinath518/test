package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.CreateArray;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by kshahbaz on 6/8/2016.
 */
public class NormalizationAddBatch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("sampleid");
        String reagent = properties.getProperty("reagentid");
        String batchname = properties.getProperty("batchname");
        String batchtype = properties.getProperty("batchtype");
        String batchid=createBatch(batchname,batchtype);
        updateDetail(batchid,sampleid,reagent);


    }

    private String createBatch(String batchname,String batchtype) throws SapphireException {
        String ngbatchid;
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype",batchtype);
        pl.setProperty("batchname",batchname);
        pl.setProperty("origin","Normalization");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid=pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return  ngbatchid;
    }





    private void updateDetail(String batchid, String sampleid, String reagent) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
        pl.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
        pl.setProperty("sampleid",sampleid);
        pl.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_sample_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);


        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
        props.setProperty("reagentid",reagent);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_reagent_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);


        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }


}
