package sapphire.custom.ng.action.ihc;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class IHCSlideRouting extends BaseAction {

    public static final String ACTION_ID = "IHCSlideRouting";
    public static final String ACTION_VERSION_ID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleid", "");
        if (Util.isNull(sampleids))
            throw new SapphireException("Specimen can't be blank.");
        DataSet dsBlockSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.FORHL7_BLOCKSAMPLE_SAMPLE,
                StringUtil.replaceAll(sampleids, ";", "','")));

        HashMap hmFilter = new HashMap();
        // check all samples are from same accession otherwiswe throw exception
        hmFilter.put("u_accessionid", dsBlockSample.getString(0, "u_accessionid"));
        DataSet dsFilter = dsBlockSample.getFilteredDataSet(hmFilter);
        if (dsBlockSample.getRowCount() != dsFilter.getRowCount())
            throw new SapphireException(getTranslationProcessor().translate("All Blocks are not from same accession"));  // all blocks are not yet cut

        // filter for block for which mcrotomy has performed
        DataSet dsSample = null;
        hmFilter.clear();
        hmFilter.put("u_microtomycompleteflag", "Y");
        dsFilter = dsBlockSample.getFilteredDataSet(hmFilter);

        //  now select all sample from same accession adn with IHC test but not the block samples so s_sampleid not in (block sampleids)
        String strSql = IHCSql.FORHL7_NOTBLOCK_SAMPLES;
        if (dsFilter.getRowCount() > 0) {
            strSql = strSql + " and s.u_accessionid = '" + dsBlockSample.getString(0, "u_accessionid") + "'  and s.s_sampleid not in( '" + dsFilter.getColumnValues("s_sampleid", "','") + "')  ";
        } else if (dsBlockSample.getRowCount() > 0) {
            strSql = strSql + " and s.u_accessionid = '" + dsBlockSample.getString(0, "u_accessionid") + "'  and s.s_sampleid not in( '" + dsBlockSample.getColumnValues("s_sampleid", "','") + "')  ";
        } else {
            strSql = strSql + " and s.s_sampleid in ('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        }
        dsSample = getQueryProcessor().getSqlDataSet(strSql);
        String[] los = StringUtil.split(Util.getUniqueList(dsSample.getColumnValues("los", ";"), ";", true), ";");

        String currentDepartment = connectionInfo.getDefaultDepartment();
        String site = currentDepartment.substring(0, currentDepartment.indexOf("-"));
        String destinationpartment = site + "-AP";
        if (!Util.validateDepartment(destinationpartment, getQueryProcessor(), getTranslationProcessor()))
            throw new SapphireException("Unable to roupte sample as department: " + destinationpartment + " does not exist");

        initializeDataSet();//TODO INITIALIZE THE FINAL DATASET WHICH NEEDS TO BE CREATED
        if (dsSample.size() > 0) {
            for (int i = 0; i < dsSample.size(); i++) {
                String s_sampleid = dsSample.getValue(i, "s_sampleid", "");
                String sampletypeid = dsSample.getValue(i, "sampletypeid", "");
                String u_isbesthne = dsSample.getValue(i, "u_isbesthne", "");
                String u_type = dsSample.getValue(i, "u_type", "");
                String trasnporttype = dsSample.getValue(i, "specimentype", "");
                String samlos = dsSample.getValue(i, "los", "");

                if ("Morphology".equalsIgnoreCase(samlos) && "H".equalsIgnoreCase(u_type)) {
                    //TODO H&E AND MORPHOLOGY SLIDES WILL ROUTE TO IHC QC AFTER SETUP COMPLETE
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "IHC QC", "StainCompleted");
                } else if ("U".equalsIgnoreCase(u_type) || "CU".equalsIgnoreCase(u_type) || "Unstained Slide".equalsIgnoreCase(trasnporttype)) {
                    //TODO USS OR CLIENT USS OR UNSTATINED SLIDES WILL ROUTE TO IHC Staining AFTER SETUP COMPLETE
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "IHC Staining", "IHCSetup");
                } else if ("U".equalsIgnoreCase(u_type) || "CU".equalsIgnoreCase(u_type) || "Stained Slide".equalsIgnoreCase(trasnporttype) ||
                        "CST".equalsIgnoreCase(u_type) || ("Paraffin Tissue".equalsIgnoreCase(sampletypeid) && "Stained Slide".equalsIgnoreCase(trasnporttype))) {
                    //TODO U OR CU OR STAINER SLIDE OR CST OR (Paraffin Tissue and Stained Slide) WILL ROUTE TO IHC Staining AFTER SETUP COMPLETE
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "IHC QC", "StainCompleted");
                } else if ("H".equalsIgnoreCase(u_type) && Util.isNull(u_isbesthne)) {
                    //TODO CHOOSE BEST H&E WILL ROUTE TO STAINING FOR 1st ROUND
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "IHC Staining", "IHCSetup");
                } else if ("H".equalsIgnoreCase(u_type) && "Y".equalsIgnoreCase(u_isbesthne)) {
                    //TODO CHOOSE BEST H&E WILL ROUTE TO QC FOR 2nd ROUND
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "IHC QC", "StainCompleted");
                } else if ("CH".equalsIgnoreCase(u_type) || "PC".equalsIgnoreCase(u_type) || "NC".equalsIgnoreCase(u_type)) {
                    //TODO CH OR PC OR NC WILL ROUTE TO STAINING
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "IHC Staining", "IHCSetup");
                } else if ("B".equalsIgnoreCase(u_type)) {
                    //TODO BACKUP WILL ROUTE TO HistologyArchive
                    currentDepartment = site + "-Accessioning";
                    int rowID = dsFinal.addRow();
                    addRecordsToFinalDataSet(rowID, s_sampleid, currentDepartment, "Histology Archive", "HistologyArchive");
                }
            }
        }
        if (dsFinal != null && dsFinal.size() > 0) {
            performSlideRouting();
        }
    }

    private void initializeDataSet() throws SapphireException {
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CURRENT_DEPT, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CURRENT_TRAMSTOP, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CURRENT_STEP, DataSet.STRING);
        }
    }

    private void performSlideRouting() throws SapphireException {
        if (dsFinal.size() > 0) {
            PropertyList updateProp = new PropertyList();
            updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
            updateProp.setProperty("u_currentmovementstep", dsFinal.getColumnValues(DATASET_PROPERTY_CURRENT_STEP, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update movement step." + ex.getMessage());
            }
            // Updating trackitem
            updateProp.clear();
            updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
            updateProp.setProperty("custodialdepartmentid", dsFinal.getColumnValues(DATASET_PROPERTY_CURRENT_DEPT, ";"));
            updateProp.setProperty("custodialuserid", StringUtil.repeat("(null)", dsFinal.size(), ";"));
            updateProp.setProperty("u_currentmovementstep", dsFinal.getColumnValues(DATASET_PROPERTY_CURRENT_STEP, ";"));
            updateProp.setProperty("u_currenttramstop", dsFinal.getColumnValues(DATASET_PROPERTY_CURRENT_TRAMSTOP, ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update department." + ex.getMessage());
            }
        }
    }

    private void addRecordsToFinalDataSet(int rowID, String s_sampleid, String currentdept, String currenttramstop, String currentstep) throws SapphireException {
        dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, s_sampleid);
        dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENT_DEPT, currentdept);
        dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENT_TRAMSTOP, currenttramstop);
        dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENT_STEP, currentstep);
    }

    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_SAMPLEID = "s_sampleid";
    private static final String DATASET_PROPERTY_CURRENT_DEPT = "currentdept";
    private static final String DATASET_PROPERTY_CURRENT_TRAMSTOP = "currenttramstop";
    private static final String DATASET_PROPERTY_CURRENT_STEP = "currentstep";
}
