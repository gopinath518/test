package sapphire.custom.ng.action.ihc;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/*
 * This action is used for backup flow for multiple specimen.
 */
public class IHCFlowBackMovement extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("sampleid", "");
        String fromStepName = properties.getProperty("fromstepname", "");
        String toStepName = properties.getProperty("tostepname", "");
        if (toStepName.contains("&")) {
            toStepName = StringUtil.replaceAll(toStepName, "&", "&'||'");
        }
        if ("".equals(sampleId) || "".equals(fromStepName) || "".equals(toStepName))
            throw new SapphireException("Insuffient Data: SampleId/From Step/To Step missing");
        /*
        String sql = Util.parseMessage(ApSql.GET_LOS_BYSAMPELID, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsLos = getQueryProcessor().getSqlDataSet(sql);
        if (dsLos == null) {
            throw new SapphireException("Query failed: Please contact your administrator." + sql);
        }
        if (dsLos.size() == 0) {
            throw new SapphireException("No LOS found for the specimen(s)");
        }
        String accessionid[] = StringUtil.split(Util.getUniqueList(dsLos.getColumnValues("accession_id", ";"), ";", true), ";");
        String los[] = StringUtil.split(Util.getUniqueList(dsLos.getColumnValues("los", ";"), ";", true), ";");
        if (accessionid.length > 1) {
            String errorCode = Util.getDisplayMessage(dsLos);
            throw new SapphireException("Multiple accession(s) can not allowed to proceed at a time\n" + errorCode);
        }
        if (los.length > 1) {
            String errorCode = Util.getDisplayMessage(dsLos);
            throw new SapphireException("Multiple LOS can not allowed to proceed at a time\n" + errorCode);
        }*/
        processIHCBackStep(sampleId, fromStepName, toStepName);

        if (toStepName.contains("&'||'")) {
            toStepName = StringUtil.replaceAll(toStepName, "&'||'", "&");
        }
        if (toStepName.contains("H&E")) {
            toStepName = StringUtil.replaceAll(toStepName, "H&E", "H&E ");
        }
        if (toStepName.contains("Imaging")) {
            toStepName = StringUtil.replaceAll(toStepName, "Imaging", "IHC Imaging");
        }
        properties.setProperty("msg", sampleId + "- has/have been moved to <b>" + toStepName + "</b> tramstop.");

    }

    public void processIHCBackStep(String sampleId, String fromStepName, String toStepName) throws SapphireException {

        if(!Util.isNull(sampleId)) {
            sampleId=Util.getUniqueList(sampleId,";",true);
            String sampleIdArr[]=StringUtil.split(sampleId,";",true);
            if(sampleIdArr!=null && sampleIdArr.length>0) {
                for (int i=0;i<sampleIdArr.length;i++) {
                    String tempSampleArr[] = StringUtil.split(sampleIdArr[i], ";");
                    validationBackwardMovement(sampleIdArr[i],fromStepName,toStepName);
                    String sql = Util.parseMessage(ApSql.IHC_GET_BACK_STEP_INFO_SQL, toStepName, tempSampleArr[0], fromStepName, tempSampleArr[0], StringUtil.replaceAll(sampleIdArr[i], ";", "','"));
                    DataSet ds = getQueryProcessor().getSqlDataSet(sql);
                    if (ds != null && ds.size() > 0) {
                        setPendingStep(ds.getColumnValues("u_sampletestcodestpmapid", ";"));
                        setBackWardStep(sampleIdArr[i], toStepName);
                    }
                }
            }
        }

    }

    public void setPendingStep(String sampletestcodestpmapid) throws ActionException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodestpmapid);
        pl.setProperty("status", "Pending");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    public void setBackWardStep(String sampleId, String toStepName) throws SapphireException {
        String sql = Util.parseMessage(ApSql.IHC_GET_BACK_CURRENT_STEP, toStepName);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0) {

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
            pl.setProperty("u_currentmovementstep", ds.getValue(0, "currentmovementstep", ""));
            try{
            	getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("setBackWardStep failed." + ex.getMessage());
            }

            String workingDepartment = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0] + "-" + ds.getValue(0, "workingdepartment", "");

            pl.clear();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
            pl.setProperty("custodialuserid", "(null)");
            pl.setProperty("custodialdepartmentid", workingDepartment);
            pl.setProperty("u_currenttramstop", ds.getValue(0, "workingtramstop", ""));
            try{
            	getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("setBackWardStep failed." + ex.getMessage());
            }
        }

    }
    /*
     * This is added for validation only.
     */
    public void validationBackwardMovement(String sampleId, String fromStepName, String toStepName) throws SapphireException {
    	String sqlStepName= Util.parseMessage(ApSql.GET_SPECIMEN_STEP, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsStepName = getQueryProcessor().getSqlDataSet(sqlStepName);
        if (dsStepName == null) {
            throw new SapphireException("Query failed: Please contact your administrator." + sqlStepName);
        }
        if (dsStepName.size() == 0) {
            throw new SapphireException("No LOS found for the specimen(s)");
        }
        HashMap<String,String> hmFilter=new HashMap<>();
        hmFilter.clear();
        hmFilter.put("s_sampleid", sampleId);
        hmFilter.put("stepname", toStepName);
        DataSet dsFilter=dsStepName.getFilteredDataSet(hmFilter);
        if (dsFilter.size() == 0) {
            throw new SapphireException("Step is not defined for the specimen "+sampleId+",You can't send specimen to "+toStepName+" tramstop.");
        }
    }
}


