package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.EditSDIDetail;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by DMondal on 2/17/2017.
 */
public class ChangeExtractionPrinterForUser extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String userDepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String user = connectionInfo.getSysuserId();
        String printerid = properties.getProperty("printerid");
        String extractiontype = properties.getProperty("extractiontype");
        if (Util.isNull(printerid)) {
            String error = getTranslationProcessor().translate("Selected Printerid is null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (Util.isNull(extractiontype)) {
            String error = getTranslationProcessor().translate("Extraction type can not be null for the selected printer.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (Util.isNull(user)) {
            String error = getTranslationProcessor().translate("Userid is null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        String id = getId(user, userDepartment,extractiontype);
        if(Util.isNull(id)) {
            addPrinter(user, userDepartment, printerid,extractiontype);
        }
        else {
            changePrinter(id, user, userDepartment, printerid,extractiontype);
        }
    }
    /**
     * Description : This method will find auto generated id against logged userid for updating printer.
     * @param user
     * @return
     * @throws SapphireException
     */
    private String getId(String user, String userDepartment,String extractionType) throws SapphireException {
        String sqlId = "select id from u_userdefaultprinter where sysuserid='" +user+ "' " +
                "and departmentid='"+userDepartment+"' and extractiontype='"+extractionType+"'";

        DataSet dsId = getQueryProcessor().getSqlDataSet(sqlId);
        if (dsId == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += sqlId;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String id = dsId.getValue(0, "id", "");
        return id;
    }

    /**
     * Description : This method will call EditSDIDetail to change printer.
     * @param id
     * @param user
     * @param userDepartment
     * @param printerid
     * @throws SapphireException
     */
    private void changePrinter(String id,String user,String userDepartment,String printerid,String extractiontype) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditSDIDetail.PROPERTY_SDCID, "User");
        props.setProperty(EditSDIDetail.PROPERTY_KEYID1, user);
        props.setProperty("id", id);
        props.setProperty("departmentid", userDepartment);
        props.setProperty("printerid", printerid);
        props.setProperty("extractiontype", extractiontype);
        props.setProperty("printertype", "Device");
        props.setProperty(EditSDIDetail.PROPERTY_LINKID, "userdefaultprinter_link");
        try {
            getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, props);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in change printer.Error:"+ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /**
     * Description : This method used for add printer to the user if user doesn't have printer.
     * @param user
     * @param userDepartment
     * @param printerid
     * @throws SapphireException
     */
    private void addPrinter(String user,String userDepartment,String printerid,String extractiontype) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "User");
        props.setProperty("sysuserid", user);
        props.setProperty("departmentid", userDepartment);
        props.setProperty("printerid", printerid);
        props.setProperty("extractiontype", extractiontype);
        props.setProperty("printertype", "Device");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "userdefaultprinter_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in change printer.Error:"+ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }
}