package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDIDetail;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.CopyNanoBatch;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by Subhashree.dash on 12/12/2017.
 */
public class QuantificationBatchComplete extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String sdcid = properties.getProperty("sdcid");
        String batchcompletedts = properties.getProperty("batchcompletedts");
        String batchcompleteflag = properties.getProperty("batchcompleteflag");
        String batchmovestatus = properties.getProperty("batchmovestatus");
        String batchtype = properties.getProperty("batchtype");
        String origin = properties.getProperty("origin");
        String childbatchtype = properties.getProperty("childbatchtype");
        String batchstatusview = properties.getProperty("batchstatusview");
        if (Util.isNull(batchid))
            throw new SapphireException("Please select batch.");
        String sqlbatchdeta = Util.parseMessage(MolecularSql.GET_BATCH_DETAILS_BY_BATCHID,
                StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sqlbatchdeta);
        String getSampleStatus = Util.parseMessage(MolecularSql.GET_SAMPLESTATUS, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsSampleStatus = getQueryProcessor().getSqlDataSet(getSampleStatus);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
        prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        prop.setProperty("batchcompletedts", batchcompletedts);
        prop.setProperty("batchcompleteflag", batchcompleteflag);
        prop.setProperty("batchmovestatus", batchmovestatus);
        prop.setProperty("batchtype", batchtype);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
            throw new SapphireException("Batch not completed." + e.getMessage());
        }
        if (dsSampleStatus != null || dsSampleStatus.size() != 0) {
            updateCurrentmovementstep(dsSampleStatus, batchmovestatus);
            if (batchmovestatus.equals("QuantificationComplete")) {
                PropertyList editparentbatch = new PropertyList();
                editparentbatch.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
                editparentbatch.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
                editparentbatch.setProperty("origin", origin);
                editparentbatch.setProperty("batchstatusview", batchstatusview);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editparentbatch);
                } catch (Exception e) {
                    throw new SapphireException("Batch not completed." + e.getMessage());
                }

            }
            //updateCalcualtion(dsSampleStatus);
        }
        //throw new SapphireException("test");
    }

    private void updateCurrentmovementstep(DataSet samplestatus, String batchstatus) throws SapphireException {
        try {
            if (samplestatus.size() > 0) {
                if (batchstatus.equals("QuantificationComplete")) {
                    String batchspecimen = samplestatus.getColumnValues("sampleid", ";");
                    String sql = Util.parseMessage(MolecularSql.GET_EXTRACTED_METERIAL_CHECK, StringUtil.replaceAll(batchspecimen, ";", "','"));
                    DataSet dsExtractedMeterialInfo = getQueryProcessor().getSqlDataSet(sql);
                    PropertyList props1 = new PropertyList();
                    if (dsExtractedMeterialInfo != null && dsExtractedMeterialInfo.size() > 0) {
                        props1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                        props1.setProperty(EditSDI.PROPERTY_KEYID1, dsExtractedMeterialInfo.getColumnValues("s_sampleid", ";"));
                        props1.setProperty("u_currentmovementstep", "QuantCompleted");
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props1);
                    }
                    props1.clear();
                    props1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props1.setProperty(EditSDI.PROPERTY_KEYID1, batchspecimen);
                    props1.setProperty("u_currentmovementstep", "QuantCompleted");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props1);
                    //TODO NOT NECESSARY AS BATCH CONTAINS ELUTION TUBES
                    /*sql = Util.parseMessage(MolecularSql.GET_ELLUTION_BY_EXTRACTION_TUBE, StringUtil.replaceAll(batchspecimen, ";", "','"));
                    DataSet dsElution = getQueryProcessor().getSqlDataSet(sql);
                    if (dsElution.size() > 0) {
                        props1.clear();
                        props1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                        props1.setProperty(EditSDI.PROPERTY_KEYID1, dsElution.getColumnValues("s_sampleid", ";"));
                        props1.setProperty("u_currentmovementstep", "QuantCompleted");
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props1);
                    }*/
                }
            }
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }

    }

    private void deleteReagentInstrument(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_REAGENT_BY_BATCHID, batchid);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("reagentid", dsReagents.getColumnValues("reagentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }

        sql = Util.parseMessage(MolecularSql.GET_INSTRUMENT_BY_BATCHID, batchid);
        DataSet dsInstruments = getQueryProcessor().getSqlDataSet(sql);
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("instrumentid", dsInstruments.getColumnValues("instrumentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

    private void updateCalcualtion(DataSet dsInfo) throws SapphireException {
        DataSet dsFinalElution = new DataSet();
        dsFinalElution.addColumn("sampleid", DataSet.STRING);
        dsFinalElution.addColumn("qtycurrent", DataSet.STRING);
        //dsElution.addColumn("sampleid",DataSet.STRING);
        if (dsInfo != null && dsInfo.size() > 0) {
            String extrctube = StringUtil.replaceAll(dsInfo.getColumnValues("sampleid", ";"), ";", "','");
            String extractionid = StringUtil.replaceAll(dsInfo.getColumnValues("u_extractionid", ";"), ";", "','");
            String sql = Util.parseMessage(MolecularSql.GET_ALL_INFO_BY_EXTRACTION_ID, extractionid);
            DataSet dsExtrctnInfo = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            for (int i = 0; i < dsInfo.size(); i++) {
                String elutiontube = dsInfo.getValue(i, "sampleid", "");
                String extrcid = dsInfo.getValue(i, "u_extractionid", "");
                hm.clear();
                hm.put("u_extractionid", extrcid);
                hm.put("containertypeid", "Extraction Tube");
                DataSet dsExtractionFilter = dsExtrctnInfo.getFilteredDataSet(hm);
                if (dsExtractionFilter.size() > 0) {
                    double u_qtyinitial = Double.parseDouble(dsExtractionFilter.getValue(i, "u_qtyinitial", "0.0"));
                    int rowID = dsFinalElution.addRow();
                    dsFinalElution.setValue(rowID, "sampleid", elutiontube);
                    dsFinalElution.setValue(rowID, "qtycurrent", String.valueOf(u_qtyinitial));
                }
            }
            /*sql = Util.parseMessage(MolecularSql.GET_ELLUTION_BY_EXTRACTION_TUBE, extrctube);
            DataSet dsElutionInfo = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();*/

            /*if (dsExtrctnInfo.size() > 0) {
                for (int i = 0; i < dsExtrctnInfo.size(); i++) {
                    String lvtestcodeid = dsElutionInfo.getValue(i, "lvtestcodeid", "");
                    double sampleload = Double.parseDouble(dsExtrctnInfo.getValue(i, "sampleload", "0.0"));
                    double u_qtyinitial = Double.parseDouble(dsExtrctnInfo.getValue(i, "u_qtyinitial", "0.0"));
                    double elutionvol = Math.max(0, (sampleload - u_qtyinitial));
                    String extractionid = dsExtrctnInfo.getValue(i, "u_extractionid", "");
                    hm.clear();
                    hm.put("u_extractionid", extractionid);
                    DataSet dsEluFilter = dsElutionInfo.getFilteredDataSet(hm);
                    if (dsEluFilter.size() > 0) {
                        String elutiontube = dsEluFilter.getValue(0, "s_sampleid", "");
                        int rowID = dsFinalElution.addRow();
                        dsFinalElution.setValue(rowID, "sampleid", elutiontube);
                        dsFinalElution.setValue(rowID, "qtycurrent", String.valueOf(u_qtyinitial));
                    }
                }
            }*/
        }
        if (dsFinalElution.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinalElution.getColumnValues("sampleid", ";"));
            prop.setProperty("qtycurrent", dsFinalElution.getColumnValues("qtycurrent", ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update quantity");
            }
        }
    }
}
