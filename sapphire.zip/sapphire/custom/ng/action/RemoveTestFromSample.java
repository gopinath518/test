package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.DeleteSDIWorkItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by DMondal on 4/20/2017.
 * This action will delete assign test from sample.Input should be sample id and lvtestcodeid or lvpanelid.
 */
public class RemoveTestFromSample extends BaseAction{
    public void processAction(PropertyList prop) throws SapphireException{
        /**
         * Receiving input sample by variable s_sampleid
         */
        String s_sampleid=prop.getProperty("s_sampleid","");
        if(Util.isNull(s_sampleid)){
            String err=getTranslationProcessor().translate("Input sample can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,err);
        }
        /**
         * Receiving input lvtestcodeid or lvpanelid by variable lvtestorpanelid
         */
        String lvtestorpanelid=prop.getProperty("lvtestorpanelid","");
        if(Util.isNull(lvtestorpanelid)){
            String err=getTranslationProcessor().translate("Input lvtestid/lvpanelid can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,err);
        }
        /**
         * For initialize DataSet only.
         */
        initializeDataSet();
        /**
         *
         */
        DataSet dsSampleDetails=getSampleDetails(s_sampleid,lvtestorpanelid);
        /**
         * Adding all data to main dataset
         */
        addDataToDsMain(dsSampleDetails);
        /**
         * Removing lvtestcodeid or lvpanelid from s_sample
         */
        removeTest();
    }

    /**
     * This method will search all required information related to the given input.
     * If User is given some wrong input it will throw an error.
     * @param s_sampleid      - This is input sampleid by user.
     * @param lvtestorpanelid - This is for input lvtestcodeid/lvpanelid.
     * @throws SapphireException
     */
    private DataSet getSampleDetails(String s_sampleid, String lvtestorpanelid) throws SapphireException {
        String sqlSampleDetails = " select s.s_sampleid,m.u_sampletestcodemapid,sdi.workitemid,sdi.workiteminstance," +
                " m.lvtestpanelid,m.lvtestcodeid,nvl(m.ispanel,'N') as ispanel " +
                " from s_sample s, u_sampletestcodemap m, sdiworkitem sdi " +
                " where s.s_sampleid = m.s_sampleid and s.s_sampleid= sdi.keyid1 and m.testname = sdi.workitemid and " +
                " s.s_sampleid='"+s_sampleid+"' and (m.lvtestcodeid='"+lvtestorpanelid+"' or m.lvtestpanelid='"+lvtestorpanelid+"')";
        DataSet dssqlSampleDetails = getQueryProcessor().getSqlDataSet(sqlSampleDetails);
        if (dssqlSampleDetails == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dssqlSampleDetails.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Please provide some valid input.");
            errMsg += "\nQuery retuns no rows:" + sqlSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        return dssqlSampleDetails;
    }

    /**
     * Description : This method is used for setting all searched data to the main dataset and if found null data it will
     * throw an exception with proper message.
     *
     * @param dsSamples
     * @throws SapphireException
     */
    private void addDataToDsMain(DataSet dsSamples) throws SapphireException {
        int rowInc = 0;
        for (int i = 0; i < dsSamples.size(); i++) {
            rowInc = dsMain.addRow();
            dsMain.setValue(rowInc, DATASET_PROPERTY_SAMPLE_ID, dsSamples.getValue(i, "s_sampleid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_WORKITEMID, dsSamples.getValue(i, "workitemid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_WORKITEMINSTANCE, dsSamples.getValue(i, "workiteminstance", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_LVTESTPANELID, dsSamples.getValue(i, "lvtestpanelid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_LVTESTCODEID, dsSamples.getValue(i, "lvtestcodeid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, dsSamples.getValue(i, "u_sampletestcodemapid", ""));
        }
    }

    /**
     * This method will remove test from sample.
     * @throws SapphireException
     */
    public void removeTest() throws SapphireException{

        PropertyList props = new PropertyList();
        try {
            props.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID, dsMain.getColumnValues(DATASET_PROPERTY_WORKITEMID, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE, dsMain.getColumnValues(DATASET_PROPERTY_WORKITEMINSTANCE, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES, StringUtil.repeat("Y", dsMain.size(), ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, StringUtil.repeat("Y", dsMain.size(), ";"));
            getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from SDIWorkItem and related tables.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
        props.clear();
        try {
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, ";"));
            props.setProperty("lvtestcodeid", dsMain.getColumnValues(DATASET_PROPERTY_LVTESTCODEID, ";"));
            props.setProperty("lvtestpanelid", dsMain.getColumnValues(DATASET_PROPERTY_LVTESTPANELID, ";"));
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from SampleTestCodeMap.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /*****************
     * BASE DESIGN ***********DO NOT CHANGE THIS
     *****************************/
    private DataSet dsMain = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "s_sampleid";
    private static final String DATASET_PROPERTY_WORKITEMID = "workitemid";
    private static final String DATASET_PROPERTY_WORKITEMINSTANCE = "workiteminstance";
    private static final String DATASET_PROPERTY_SAMPLETESTCODEMAP_ID = "sampletestcodemapid";
    private static final String DATASET_PROPERTY_LVTESTPANELID = "lvtestpanelid";
    private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_WORKITEMID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_WORKITEMINSTANCE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTPANELID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
        }
    }
}
