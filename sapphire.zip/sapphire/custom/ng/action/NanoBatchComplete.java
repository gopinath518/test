package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdi.DeleteSDIDetail;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class NanoBatchComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String origin = properties.getProperty("origin");
        String batchtype = properties.getProperty("batchtype");
        String newKeyid1 = "";

        String sql = MolecularSql.GET_SAMPLES_BY_BATCHID;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchSamples = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSamples == null && dsBatchSamples.size() == 0) {
            throw new SapphireException("This Batch does not have specimen(s).");
        }

        PropertyList editbatch = new PropertyList();
        editbatch.setProperty("parentbatchid", batchid);
        editbatch.setProperty("origin", origin);
        editbatch.setProperty("batchtype", batchtype);//batchtype
        editbatch.setProperty("batchmovestatus", properties.getProperty("batchmovestatus"));
        try {
            getActionProcessor().processAction(CopyNanoBatch.ID, CopyNanoBatch.VERSIONID, editbatch);
            newKeyid1 = editbatch.getProperty("childbatchid", "");
            deleteReagentInstrument(newKeyid1);
            updateMovement(batchid, dsBatchSamples, properties);
            if ("Hybridization".equalsIgnoreCase(batchtype)) {
                updateElutionVolumn(batchid);
            }
        } catch (SapphireException se) {
            throw new SapphireException("Can not create duplicate Batch.\n" + se.getMessage());
        }
    }

    private void updateMovement(String batchid, DataSet dsSample, PropertyList properties) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        prop.setProperty("batchtype", properties.getProperty("childbatchtype"));
        prop.setProperty("batchstatusview", properties.getProperty("batchstatusview"));
        prop.setProperty("batchcompletedts", "n");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update batch movement.\n" + ex.getMessage());
        }
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsSample.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currentmovementstep", properties.getProperty("batchtype"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update sample movement.\n" + ex.getMessage());
        }
        prop.clear();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSample.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currenttramstop", properties.getProperty("batchtype"));
        //prop.setProperty("u_currenttramstop", properties.getProperty("batchmovestatus"));//TODO CHANGED FOR 1.6.1
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update sample custody.\n" + ex.getMessage());
        }
    }

    private void deleteReagentInstrument(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_REAGENT_BY_BATCHID, batchid);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("reagentid", dsReagents.getColumnValues("reagentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }

        sql = Util.parseMessage(MolecularSql.GET_INSTRUMENT_BY_BATCHID, batchid);
        DataSet dsInstruments = getQueryProcessor().getSqlDataSet(sql);
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("instrumentid", dsInstruments.getColumnValues("instrumentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

    private void updateElutionVolumn(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLE_BY_BATCH_NANO, batchid);
        DataSet dsBatch = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatch.size() > 0) {
            for (int i = 0; i < dsBatch.size(); i++) {
                //String sampleid = dsBatch.getValue(i, "sampleid", "");
                String amtofsample = dsBatch.getValue(i, "amtofsample", "0.0");
                String qtycurrent = dsBatch.getValue(i, "qtycurrent", "0.0");
                double balancqty = Double.parseDouble(qtycurrent) - Double.parseDouble(amtofsample);
                balancqty = Util.roundAvoid(balancqty);
                if (Double.isInfinite(balancqty))
                    balancqty = 0.0;
                else if (balancqty < 0)
                    balancqty = 0.0;

                dsBatch.setValue(i, "qtycurrent", String.valueOf(balancqty));
            }
            PropertyList props = new PropertyList();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsBatch.getColumnValues("sampleid", ";"));
            props.setProperty("qtycurrent", dsBatch.getColumnValues("qtycurrent", ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update elution volume");
            }
        }
    }
}
