package sapphire.custom.ng.action;

/*   
 * Created By Subhendu 17th April 2017
 * 
 * Automatic SQL Script Generation
 * Input Param: 
 * ---TABLENAME (semicolon separated value)
 * ---OPERATIONTYPE(semicolon separated value)
 * ---STARTDATE
 * ---ENDDATE
 * ---OUTPUTDIR
 * 
 * Note:: The number of TABLENAME should be equal to number of OPERATIONTYPE
 * */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import sapphire.SapphireException;
import sapphire.accessor.SDCProcessor;
import sapphire.action.BaseAction;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

public class MigrateData extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		 
		
		String[] tableNames = properties.getProperty("tablename","").toUpperCase().split(";");
		String[] operationType = properties.getProperty("operationtype","").toUpperCase().split(";");
//		String[] startDate = properties.getProperty("startdate","").split(";");
//		String[] endDate = properties.getProperty("enddate","").split(";");
		String startDate = properties.getProperty("startdate","");
		String endDate = properties.getProperty("enddate","");
		String outputDIR = properties.getProperty("outputdir","");
		
		HashMap<String, LinkedHashMap<String,String>> tableMap = mapTableData(tableNames,operationType,startDate,endDate);
		
		Logger.logInfo("Table Map::"+tableMap);
		processTableMapData(tableMap,outputDIR);
		
	}
	
	private HashMap<String, LinkedHashMap<String,String>> mapTableData(String[] tableNames,String[] operationType,String startDate,String endDate)throws SapphireException {
		
		HashMap<String,  LinkedHashMap<String,String>> tableMap = new HashMap<String,  LinkedHashMap<String,String>>();
		LinkedHashMap<String,String> tableDataMap = null;
		Logger.logInfo("TABLENAMES::"+tableNames+"\n Total No. of Tables::"+tableNames.length);
		Logger.logInfo("OPERATIONTYPE"+operationType+"\n Total No. of Operation::"+operationType.length);
		
		if(tableNames.length != operationType.length)
				throw new SapphireException("The total number of table names should be equal to total number of operation.");
			
		for (int i=0; i< tableNames.length;i++) {
			tableDataMap = new LinkedHashMap<String,String>();
			
			if(tableMap.containsKey(tableNames[i])) {
				tableDataMap.putAll(tableMap.get(tableNames[i]));
				tableDataMap.put("operationType"+i,operationType[i]);
				tableDataMap.put("startDate"+i,startDate);
				tableDataMap.put("endDate"+i,endDate);
				
			}else{
				tableDataMap.put("operationType" + i, operationType[i]);
				tableDataMap.put("startDate" + i, startDate);
				tableDataMap.put("endDate" + i, endDate);
				
			}
			tableMap.put(tableNames[i], tableDataMap);
		}
		
		return tableMap;
	}
	
	private void processTableMapData(HashMap<String, LinkedHashMap<String,String>> tableMap, String outputDIR) {
		String tempTableId = "";
		int seq = 1;
		for(String tableId: tableMap.keySet()) {
			
			LinkedHashMap<String,String> tableDataMap = tableMap.get(tableId);
			for(String key: tableDataMap.keySet()) {
				if(key.startsWith("operationType") && "INSERT".equals(tableDataMap.get(key))) {
					//insert operation
					processInsertOperation(tableId,tableDataMap.get("startDate"+key.lastIndexOf(key)),tableDataMap.get("endDate"+key.lastIndexOf(key)), 
							outputDIR, tableId.equals(tempTableId),seq);
				}else if(key.startsWith("operationType") && "UPDATE".equals(tableDataMap.get(key))) {
					processUpdateOperation(tableId,tableDataMap.get("startDate"+key.lastIndexOf(key)),tableDataMap.get("endDate"+key.lastIndexOf(key)), 
							outputDIR, tableId.equals(tempTableId),seq);
				}else if(key.startsWith("operationType") && "BOTH".equals(tableDataMap.get(key))) {
					//both operation
				}
				seq++;
			}
			tempTableId = tableId;
		}
	}
	
	private void processInsertOperation(String tableId,String startDate, String endDate, String outputDIR, boolean tableFlag, int seq){
		String sql = "select * from "+ tableId + " "+getWhereClause(startDate,endDate);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql,true);
		StringBuffer colName = new StringBuffer();
		StringBuffer colValue = new StringBuffer();
		String[] colArr = ds.getColumns();
		String sqlStatement = "";
		for(int i=0; i<ds.size();i++) {
			colName.setLength(0);
			colValue.setLength(0);
			for(int j=0; j<colArr.length;j++) {
				colName.append( colArr[j]+",");
				
				if(ds.getColumnType(colArr[j]) == 0) //Varchar
					colValue.append("'"+ds.getValue(i, colArr[j]).replaceAll("'", "''")+"',");
				
				else if(ds.getColumnType(colArr[j]) == 1) // Number
					colValue.append(ds.getValue(i, colArr[j],null)+",");
				
				else if(ds.getColumnType(colArr[j]) == 2) { //Date
					if(!"".equals(ds.getValue(i, colArr[j],"")))
						colValue.append("to_date(substr('"+ds.getTimestamp(i, colArr[j])+"',1,19),'yyyy-mm-dd HH24:mi:ss'),");
					else
						colValue.append("null,");
				}
				
				else if(ds.getColumnType(colArr[j]) == 3) //clob
					colValue.append("'"+ds.getClob(i, colArr[j],"")+"',");
			}
			sqlStatement = "INSERT INTO "+tableId +"("+colName.toString().substring(0, colName.toString().length()-1)+") "
					+ "values("+colValue.toString().substring(0, colValue.toString().length()-1)+"); \ncommit;\n";
			
//			Logger.logInfo( "INSERT INTO "+tableId +"("+colName.toString().substring(0, colName.toString().length()-1)+") " + "values("+colValue.toString().substring(0, colValue.toString().length()-1)+")" );
			
			processSQLFile( outputDIR, tableId, sqlStatement, tableFlag, seq);
		}
	}
	
	private void processUpdateOperation(String tableId,String startDate, String endDate, String outputDIR, boolean tableFlag, int seq){
		String sql = "select * from "+ tableId + " "+getWhereClause(startDate,endDate);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql, true);
		
		StringBuffer colValue = new StringBuffer();
		String[] colArr = ds.getColumns();
		String sqlStatement = ""; 
		
		for(int i=0; i<ds.size();i++) {
			
			colValue.setLength(0);
			for(int j=0; j<colArr.length;j++) {
				
				if(ds.getColumnType(colArr[j]) == 0) //Varchar
					colValue.append(colArr[j]+" = '"+ds.getValue(i, colArr[j],"").replaceAll("'", "''")+"',");
				
				else if(ds.getColumnType(colArr[j]) == 1) // Number
					colValue.append(colArr[j]+" = "+ds.getValue(i, colArr[j], null)+",");
				
				else if(ds.getColumnType(colArr[j]) == 2) { //Date
					if(!"".equals(ds.getValue(i, colArr[j],"")))
						colValue.append(colArr[j]+" = "+"to_date(substr('"+ds.getTimestamp(i, colArr[j])+"',1,19),'yyyy-mm-dd HH24:mi:ss'),");
					else
						colValue.append("null,");
				}
				
				else if(ds.getColumnType(colArr[j]) == 3) //clob
					colValue.append(colArr[j]+" = '"+ds.getClob(i, colArr[j],"")+"',");
			}
			 
			sqlStatement = "UPDATE "+tableId +" set "+colValue.toString().substring(0, colValue.toString().length()-1)+ getUpdateWhereClause(tableId, ds, i)+"; \ncommit;\n";
			
//			Logger.logInfo( "UPDATE "+tableId +" set "+colValue.toString().substring(0, colValue.toString().length()-1)+ getUpdateWhereClause(tableId, ds, i)+"; \ncommit;\n");
			
			processSQLFile( outputDIR, tableId, sqlStatement, tableFlag, seq);
		}
	}
	
	private String getUpdateWhereClause(String tableId,DataSet ds, int index) {
		SDCProcessor sdcProcessor = getSDCProcessor();
		DataSet dsPrimary =sdcProcessor.getTableColumnData(tableId.toLowerCase());
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("pkflag", "Y");
		
		DataSet finalPrimaryDS = dsPrimary.getFilteredDataSet(hm);
		
		String whereClause = "";
		for(int x= 0; x < finalPrimaryDS.size(); x++) {
			if(ds.getColumnType(finalPrimaryDS.getValue(x, "columnid")) == 0) //Varchar
				whereClause += finalPrimaryDS.getValue(x, "columnid") +" = '"+ds.getValue(index, finalPrimaryDS.getValue(x, "columnid")) +"',";
			else if(ds.getColumnType(finalPrimaryDS.getValue(x, "columnid")) == 1) // Number
				whereClause += finalPrimaryDS.getValue(x, "columnid") +" = "+ds.getValue(index, finalPrimaryDS.getValue(x, "columnid")) +",";
		}
		
		return " where "+whereClause.substring(0, whereClause.length()-1); 
	}
	
	
	private void processSQLFile(String outputDIR, String tableId, String sqlStatement, boolean tableFlag, int seq) {
		
		BufferedWriter bw = null;
		try {
			SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date();
			String dt = sf.format(date);
			
			File file = new File(outputDIR +tableId+"_"+dt+".sql");
			
			if (file.createNewFile()) {
				Logger.logInfo("New File Created"+file.getName());
				bw = new BufferedWriter(new FileWriter(file,true));
				bw.write("SET DEFINE OFF;\n");// For escaping ampersand character in any column value.
				bw.write(sqlStatement);
			}else {
				bw = new BufferedWriter(new FileWriter(file,true));
				bw.write(sqlStatement);
			}
			
		} catch (Exception e) {
			Logger.logError("Error occured during processing sql file");
		}finally {
			try {
				if (bw != null)
					bw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	private String getWhereClause(String startDate, String endDate) {
		String whereClause= "";
		if(startDate != null && !"".equals(startDate) && "".equals(endDate))
			whereClause = " where moddt between to_date ('"+startDate+"','dd/mm/yyyy') and sysdate";
		else if(startDate != null && !"".equals(startDate) && !"".equals(endDate))
			whereClause = " where moddt between to_date ('"+startDate+"','dd/mm/yyyy') and to_date ('"+endDate+"','dd/mm/yyyy')";
		
		return whereClause;
	}
}

