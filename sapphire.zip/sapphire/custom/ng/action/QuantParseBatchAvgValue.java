package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

public class QuantParseBatchAvgValue extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("sampleid", DataSet.STRING);
        dsFinal.addColumn("columnname", DataSet.STRING);
        dsFinal.addColumn("columnvalue", DataSet.STRING);
        DataSet ds = Util.propertyListToDataSet(properties);
        if (!ds.isValidColumn("errormsg"))
            ds.addColumn("errormsg", DataSet.STRING);
        if (!ds.isValidColumn("iscountable"))
            ds.addColumn("iscountable", DataSet.STRING);
        if (!ds.isValidColumn("sampleid"))
            ds.addColumn("sampleid", DataSet.STRING);
        if (!ds.isValidColumn("isuserseq"))
            ds.addColumn("isuserseq", DataSet.NUMBER);
        boolean isStart = false;
        int count = 0;
        String sampleid = "";
        if (ds != null && ds.size() > 0) {
            for (int i = 0; i < ds.size(); i++) {
                String cola = ds.getValue(i, "columna", "").trim();
                if (!Util.isNull(cola) && "Sample Name".equalsIgnoreCase(cola)) {
                    count++;
                    sampleid = ds.getValue(i, "columnb", "");
                    ds.setValue(i, "sampleid", sampleid);
                    ds.setValue(i, "iscountable", "Y");
                    ds.setNumber(i, "isuserseq", count);
                } else if (!Util.isNull(cola) && "Region Table".equalsIgnoreCase(cola)) {
                    isStart = true;
                } else if (!Util.isNull(cola) && "Peak Table".equalsIgnoreCase(cola)) {
                    isStart = false;
                } else if (!Util.isNull(cola) && isStart) {
                    count++;
                    ds.setValue(i, "sampleid", sampleid);
                    ds.setValue(i, "iscountable", "Y");
                    ds.setNumber(i, "isuserseq", count);
                } else {
                    isStart = false;
                    ds.setValue(i, "iscountable", "N");
                }
            }
        }
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("iscountable", "Y");
        DataSet dsCountable = ds.getFilteredDataSet(hm);
        if (dsCountable != null && dsCountable.size() > 0) {

            for (int i = 0; i < dsCountable.size(); i++) {

                String avgcol = dsCountable.getValue(i, "columnf", "").trim();
                if (!Util.isNull(avgcol) && "Average Size [bp]".equalsIgnoreCase(avgcol)) {
                    //dsFinal.setValue(rowID, "sampleid", dsCountable.getValue(i, "sampleid", ""));
                    isStart = true;
                } else if (Util.isNull(avgcol)) {
                    isStart = false;
                } else if (!Util.isNull(avgcol) && isStart) {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, "sampleid", dsCountable.getValue(i, "sampleid", ""));
                    dsFinal.setValue(rowID, "columnname", "Average Size [bp]");
                    dsFinal.setValue(rowID, "columnvalue", avgcol);
                }
            }
            if (dsFinal != null && dsFinal.size() > 0) {
                //properties.setProperty("sampleid", dsFinal.getColumnValues("sampleid", ";"));
                //properties.setProperty("averagesize", dsFinal.getColumnValues("columnvalue", ";"));
                if (!dsFinal.isValidColumn("lvsampleid"))
                    dsFinal.addColumn("lvsampleid", DataSet.STRING);
                dsFinal.sort("sampleid");
                ArrayList<DataSet> dsGroupInfoArr = dsFinal.getGroupedDataSets("sampleid");
                if (dsGroupInfoArr.size() > 1) {
                    for (int i = 0; i < dsGroupInfoArr.size(); i++) {
                        DataSet dsEach = (DataSet) dsGroupInfoArr.get(i);
                        if (dsEach.size() > 1) {
                            throw new SapphireException("<b><u>More than one record found for Specimen: " + dsEach.getValue(0, "sampleid", "") + "</u></b>");
                        }
                    }
                }
                String molbatchspecid = dsFinal.getColumnValues("sampleid", ";");
                String sql = Util.parseMessage(MolecularSql.GET_SAMPLES_BY_MOL_BATCH_SPECIMEN, StringUtil.replaceAll(molbatchspecid, ";", "','"));
                DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
                    for (int i = 0; i < dsFinal.size(); i++) {
                        String batchsampleid = dsFinal.getValue(i, "sampleid");
                        hm.clear();
                        hm.put("u_molbatchspecimenid", batchsampleid);
                        DataSet dsFilter = dsSampleInfo.getFilteredDataSet(hm);
                        if (dsFilter.size() == 0) {
                            throw new SapphireException("<b><u>" + batchsampleid + " Specimen can not find into the system.</u></b>");
                        }
                        String lvsampleid = dsFilter.getValue(0, "s_sampleid");
                        dsFinal.setValue(i, "lvsampleid", lvsampleid);
                    }
                }
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("lvsampleid", ";"));
                prop.setProperty("u_averagesize", dsFinal.getColumnValues("columnvalue", ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (Exception ex) {
                    throw new SapphireException("<b>Unable to update Average Size for the specimen(s).</b>");
                }
            }
        }
        properties.setProperty("sampleid", dsFinal.getColumnValues("sampleid", ";"));
        properties.setProperty("averagesize", dsFinal.getColumnValues("columnvalue", ";"));
    }

}
