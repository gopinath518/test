package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by rrmandal on 7/12/2016.
 */
public class CreateBigDyeBatch extends BaseAction {

    private String DEFAULT_COPY_DOWN = "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String orgBatchID = properties.getProperty("batchid");
        String samplSql = "select u_ngbatchid , sampleid, analyte, concentrationratio, containertypeid from u_ngbatch_sample,trackitem where linksdcid='Sample' " +
                "  and linkkeyid1=sampleid  and  u_ngbatchid = '" + orgBatchID + "'";
        String reagentSql = "select u_ngbatchid , reagentid, reagenttype, reagenttypeversion from u_ngbatch_reagent where u_ngbatchid = '" + orgBatchID + "'";
        String controlSql  = "select u_ngbatchid , sampleid, analyte, position from u_ngbatch_sample  where u_ngbatchid = '" + orgBatchID + "'";
        DataSet dsBatch = getQueryProcessor().getSqlDataSet("select batchname, batchtype from u_ngbatch where u_ngbatchid='" +orgBatchID + "'");
        DataSet dsSample  = getQueryProcessor().getSqlDataSet(samplSql) ;
        String batchType = dsBatch.getValue(0,"batchtype","");
        if(!Util.isNull(batchType))
            batchType+="_Sequencing";
        // create new batch
        PropertyList newBatchProp = new PropertyList();
        newBatchProp.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        //newBatchProp.setProperty("parentbatchid", orgBatchID);
        newBatchProp.setProperty("batchmovestatus", "ExoSapComplete");
        newBatchProp.setProperty("origin", "BigDye");
        newBatchProp.setProperty("batchtype", batchType);
        newBatchProp.setProperty("batchname", dsBatch.getString(0, "batchname", ""));
        newBatchProp.setProperty("batchstatusview", "BigDye Pending");
        newBatchProp.setProperty("batchtype", "Molecular");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, newBatchProp);
        // add old batch reagents and control to new batch
        String newBatchid = newBatchProp.getProperty("newkeyid1");
        deleteRegInfo(newBatchid);

//        addReagents(newBatchid, orgBatchID);
//        addControls(newBatchid, orgBatchID);
//        // create child sample from old batch samples
//        PropertyList samplePl = prepareChildSamples(dsSample, DEFAULT_COPY_DOWN);
//        getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, samplePl);
//
//        String childSamples = samplePl.getProperty("newkeyid1");
//        if(null == childSamples)
//            throw new SapphireException("could not create child samples");
//        //assign child sample to new batch
//        PropertyList sampleBatchPl =getSampleBatchProps(childSamples,newBatchid, dsSample);
//        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleBatchPl);
//
//        // apply test from old samples to new samples
//        PropertyList plSampleTest = applyTestToChild(childSamples, dsSample);
//        getActionProcessor().processAction("AddTestCode", "1", plSampleTest);
//
//        //load to plate and create new plate
//        PropertyList plBatchPlate = new PropertyList();
//        plBatchPlate.setProperty("batchid", newBatchid);
//        plBatchPlate.setProperty("batchtypeid", batchType);
//        getActionProcessor().processAction("NGAutoPlateLoading", "1", plBatchPlate);

        //Edit batchmovementstatus for old batch
        PropertyList oldBatchProp = new PropertyList();
        oldBatchProp.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        oldBatchProp.setProperty(EditSDI.PROPERTY_KEYID1, orgBatchID);
        oldBatchProp.setProperty("batchmovestatus", "Complete");
        oldBatchProp.setProperty("batchstatusview", "ExoSap Complete");
        oldBatchProp.setProperty("batchcompletedts", "n");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, oldBatchProp);

    }

    private PropertyList applyTestToChild(String newSamples, DataSet dsSample) throws SapphireException {
        String psample = dsSample.getColumnValues("sampleid",  "','");
        String tc_sql = "select distinct ts.s_sampleid, tc.u_testcodeid testcodeid,  tc.ispanel  ispanel, sm.destsampleid sampleid  from u_testcode tc, u_sampletestcodemap ts, s_samplemap sm " +
                "  where tc.u_testcodeid  = ts.lvtestcodeid  and sm.sourcesampleid =ts.s_sampleid and  ts.s_sampleid in('" + psample + "')  and sm.destsampleid in ('" +
                StringUtil.replaceAll(newSamples, ";", "','") + "')";
        DataSet dsTestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        String[] samparr = StringUtil.split(newSamples, ";");
        HashMap<String, String > hmSample = new HashMap();
        DataSet dsFilter = new DataSet();
        String allsampes="";
        String allTestCode="";
        String allIsPanel="";
        if (dsTestcode.size() == 0 ) {
            String error = getTranslationProcessor().translate("Samples  " + psample + " doesn't have any Test !");
            //throw new SapphireException( error);
        }
        for (String currentsamp : samparr) {
            hmSample.clear();
            hmSample.put("sampleid",currentsamp );
            dsFilter = dsTestcode.getFilteredDataSet(hmSample);
            if(dsFilter.getRowCount()>0){
                allsampes = allsampes + ";" + dsFilter.getColumnValues("sampleid", ";");
                allTestCode = allTestCode + ";" + dsFilter.getColumnValues("testcodeid", ";");
                allIsPanel = allIsPanel + ";" + dsFilter.getColumnValues("ispanel", ";");
            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", allsampes.startsWith(";") ? allsampes.substring(1): allsampes);
        hsAddTestCode.setProperty("lvtestcode", allTestCode.startsWith(";") ? allTestCode.substring(1): allTestCode);
        hsAddTestCode.setProperty("ispanel", allIsPanel.startsWith(";") ? allIsPanel.substring(1): allIsPanel);
        hsAddTestCode.setProperty("bypassvalidation", "Y");
        hsAddTestCode.setProperty("workitemflag", "Y");
        return hsAddTestCode;
    }

    private PropertyList getSampleBatchProps(String newSamples, String newBatchid, DataSet dsSample){
        PropertyList plBatchSample = new PropertyList();
        plBatchSample.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
        plBatchSample.setProperty(AddSDIDetail.PROPERTY_KEYID1,newBatchid);
        plBatchSample.setProperty("sampleid",newSamples);
        plBatchSample.setProperty("analyte",dsSample.getColumnValues("analyte",";"));
        plBatchSample.setProperty("concentrationratio",dsSample.getColumnValues("concentrationratio",";"));
        plBatchSample.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_sample_link");
        return plBatchSample;
    }

    private void addReagents(String newbatchid, String OldBatchid) throws SapphireException {
        String reagentSql = "select u_ngbatchid , reagentid, reagenttype, reagenttypeversion from u_ngbatch_reagent  where u_ngbatchid = '" + OldBatchid + "'";
        DataSet dsReagents  = getQueryProcessor().getSqlDataSet(reagentSql);
        if(dsReagents.getRowCount()>0){
            PropertyList plReagent = new PropertyList();
            plReagent.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            plReagent.setProperty(AddSDIDetail.PROPERTY_KEYID1, newbatchid);
            plReagent.setProperty("reagentid", dsReagents.getColumnValues("reagentid", ";"));
            plReagent.setProperty("reagenttype", dsReagents.getColumnValues("reagenttype", ";"));
            plReagent.setProperty("reagenttypeversion", dsReagents.getColumnValues("reagenttypeversion", ";"));
            plReagent.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plReagent);
        }
    }

    private void addControls(String newbatchid, String OldBatchid) throws SapphireException {
        String controlSql  = "select u_ngbatchid , sampleid, analyte, position from u_ngbatch_control  where u_ngbatchid = '" + OldBatchid + "'";
        DataSet dsControl  = getQueryProcessor().getSqlDataSet(controlSql);
        if(dsControl.getRowCount()>0){
            PropertyList plControls = new PropertyList();
            plControls.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            plControls.setProperty(AddSDIDetail.PROPERTY_KEYID1, newbatchid);
            plControls.setProperty("sampleid", dsControl.getColumnValues("sampleid", ";"));
            plControls.setProperty("analyte", dsControl.getColumnValues("analyte", ";"));
            plControls.setProperty("position", dsControl.getColumnValues("position", ";"));
            plControls.setProperty(AddSDIDetail.PROPERTY_LINKID, "ngbatch_control_link");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plControls);
        }
    }

    private PropertyList prepareChildSamples(DataSet dsSample, String copyDownCol) {
        PropertyList properties = new PropertyList();
        properties.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, dsSample.getColumnValues("sampleid", ";"));
        properties.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
        properties.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, copyDownCol);
        //properties.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY, "0.001");
        // properties.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT , "ul");
        properties.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT , "N");
        properties.setProperty("containertypeid", dsSample.getColumnValues("containertypeid", ";"));

        /*properties.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, dsSample.getColumnValues("sampleid", ";"));
        properties.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "1");
        //properties.setProperty(CreateChildSamples.PROPERTY_COPYDOWNCOLUMNS, copyDownCol);
        properties.setProperty(CreateChildSamples.PROPERTY_CHILD_QUANTITY, "0.001");
        properties.setProperty(CreateChildSamples.PROPERTY_CHILD_UNIT , "ul");
        properties.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT , "N");
        properties.setProperty(CreateChildSamples.PROPERTY_CHILD_CONTAINERTYPEID , "EDTA");*/
        //properties.setProperty(MultiSampleChild.PROPERTY_CHILD_SAMPLETYPEID, "");
        return properties;
    }


    private void deleteRegInfo(String newBatch)throws SapphireException{
        if(!Util.isNull(newBatch)) {
            String sql = "select u_ngbatchid,analyte,reagentid,testcodeid,direction from u_ngbatcg_reagent_detail " +
                    "where u_ngbatchid in('"+ StringUtil.replaceAll(newBatch,";","','")+"') ";
            DataSet dsRegInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsRegInfo!=null && dsRegInfo.size()>0) {
                dsRegInfo.sort("u_ngbatchid");
                ArrayList<DataSet> dsRegInfoArr = dsRegInfo.getGroupedDataSets("u_ngbatchid");
                if(dsRegInfoArr!=null && dsRegInfoArr.size()>0) {
                    PropertyList prop = new PropertyList();
                    for(int i=0;i<dsRegInfoArr.size();i++) {
                        DataSet tempDS = dsRegInfoArr.get(i);
                        if(tempDS!=null  && tempDS.size()>0) {
                            String keyid1= tempDS.getValue(0,"u_ngbatchid","");
                            if(!Util.isNull(keyid1)) {
                                prop.clear();
                                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, keyid1);
                                prop.setProperty("analyte", tempDS.getColumnValues("analyte", ";"));
                                prop.setProperty("reagentid", tempDS.getColumnValues("reagentid", ";"));
                                prop.setProperty("testcodeid", tempDS.getColumnValues("testcodeid", ";"));
                                prop.setProperty("direction", tempDS.getColumnValues("direction", ";"));
                                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");

                                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
                            }
                        }
                    }
                }
            }
        }
    }
}
