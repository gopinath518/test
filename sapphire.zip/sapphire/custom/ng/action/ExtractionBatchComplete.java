package sapphire.custom.ng.action;

import java.io.File;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

/**
 * Modified by aparna.chatterjee on 3/06/2018.
 * Description : This action is used for upadte Extraction and Quantification batch status.It will create a copy of batch and move to Historical batch.
 * It will update Currentmovementstep of sample belongs to the current batch. .
 */
public class ExtractionBatchComplete extends BaseAction {

    private static final String FILELOCATIONPOLICY = "FileLocationPolicy";
    private static final String NODEID = "MolecularDefaultLocation";
    private static final String PROPS_LOCATION = "location";
    private static final String PROPS_LOCATIONS = "locations";

    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String sdcid = properties.getProperty("sdcid");
        String batchcompletedts = properties.getProperty("batchcompletedts");
        String batchcompleteflag = properties.getProperty("batchcompleteflag");
        String batchmovestatus = properties.getProperty("batchmovestatus");
        String batchtype = properties.getProperty("batchtype");
        String origin = properties.getProperty("origin");
        String childbatchtype = properties.getProperty("childbatchtype");
        String batchstatusview = properties.getProperty("batchstatusview");
        if (Util.isNull(batchid))
            throw new SapphireException("Please select batch.");
        String sqlbatchdeta = Util.parseMessage(MolecularSql.GET_BATCH_DETAILS_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sqlbatchdeta);
        String sql = Util.parseMessage(MolecularSql.GET_REAGENT_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsReagent = getQueryProcessor().getSqlDataSet(sql);
        String sqlelusionreagent = Util.parseMessage(MolecularSql.GET_ELUSION_REAGENT_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsElutionReagent = getQueryProcessor().getSqlDataSet(sqlelusionreagent);

        String sqlinstu = Util.parseMessage(MolecularSql.GET_INSTRUMENT_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsInstrument = getQueryProcessor().getSqlDataSet(sqlinstu);
        String sqlelutionbfrflg = Util.parseMessage(MolecularSql.GET_ELUTION_BUFFER_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        String getSampleStatus = Util.parseMessage(MolecularSql.GET_SAMPLESTATUS, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsElutionBffr = getQueryProcessor().getSqlDataSet(sqlelutionbfrflg);
        DataSet dsSampleStatus = getQueryProcessor().getSqlDataSet(getSampleStatus);

        boolean norgnt = false;
        boolean noInstr = false;
        boolean noElutionReagnent = false;
        HashMap hm = new HashMap();
        for (int i = 0; i < dsBatchDetails.size(); i++) {
            hm.clear();
            hm.put("u_ngbatchid", dsBatchDetails.getValue(i, "u_ngbatchid", ""));
            DataSet dsInStrumentFilter = dsInstrument.getFilteredDataSet(hm);
            if (dsInStrumentFilter == null || dsInStrumentFilter.size() == 0) {
                noInstr = true;
            }
            hm.clear();
            hm.put("u_ngbatchid", dsBatchDetails.getValue(i, "u_ngbatchid", ""));
            DataSet dsReagentFilter = dsReagent.getFilteredDataSet(hm);
            if (dsReagentFilter == null || dsReagentFilter.size() == 0) {
                norgnt = true;
            }
            hm.clear();
            hm.put("u_ngbatchid", dsBatchDetails.getValue(i, "u_ngbatchid", ""));
            DataSet dsElutionReagentFilter = dsElutionReagent.getFilteredDataSet(hm);
            if (dsElutionReagentFilter == null || dsElutionReagentFilter.size() == 0) {
                //noElutionReagnent = true;
                hm.clear();
                hm.put("u_ngbatchid", dsBatchDetails.getValue(i, "u_ngbatchid", ""));
                DataSet dsElusnBrrfFilter = dsElutionBffr.getFilteredDataSet(hm);
                String elusnbffrflag = dsElusnBrrfFilter.getValue(0, "kitelutionbfrflag", "");
                if ("N".equalsIgnoreCase(elusnbffrflag)) {
                    noElutionReagnent = true;
                } else {
                    noElutionReagnent = false;
                }
            }
            if (norgnt == true && noInstr == true && noElutionReagnent == true) {
                throw new SapphireException("Please add Extraction Reagent & Elusion Reagent/Please check Elution buffer & Please add Instrument.");
            } else if (norgnt == true) {
                throw new SapphireException("Please add Extraction Reagent.");
            } else if (noInstr == true) {
                throw new SapphireException("Please add Instrument.");
            } else if (noElutionReagnent == true) {
                throw new SapphireException("Please add Elusion Reagent.");
            }
        }

        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
        prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        prop.setProperty("batchcompletedts", batchcompletedts);
        prop.setProperty("batchcompleteflag", batchcompleteflag);
        prop.setProperty("batchmovestatus", batchmovestatus);
        prop.setProperty("batchtype", batchtype);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
            throw new SapphireException("Batch not completed." + e.getMessage());
        }
        if (dsSampleStatus != null || dsSampleStatus.size() != 0) {
            updateCurrentmovementstep(dsSampleStatus, batchmovestatus);
            //TODO NEED TO CREATE DUPLICATE BATCH AND DETAILS FOR CHILD BATCH
            prop.clear();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(AddSDI.PROPERTY_TEMPLATEKEYID1, batchid);
            prop.setProperty("batchtype", childbatchtype);
            prop.setProperty("origin", origin);
            prop.setProperty("batchstatusview", batchstatusview);
            prop.setProperty("batchmovestatus", batchmovestatus);
            prop.setProperty("parentbatchid", batchid);

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (SapphireException s) {
                throw new SapphireException("Something went wrong.Batch can not be copied");
            }
            String newbatchid = prop.getProperty("newkeyid1");
            if (!Util.isNull(newbatchid)) {
                updateBatchDetail(newbatchid);
                //TODO NEED TO CREATE DUPLICATE ElUTION REAGENT DETAILS AND ATTACHMENT FOR CHILD BATCH
                copyElutionReagentToChild(batchid, newbatchid);
                addAttachmentToChild(batchid, newbatchid);//TODO OPEN BEFORE DEPLOY INTO SERVER
            }
            deleteReagentInstrument(batchid);
            reAssignElutionTubeToBatch(batchid);
            updateCalcualtion(dsSampleStatus, batchid);
        }
        //throw new SapphireException("test");
    }

    private void updateCurrentmovementstep(DataSet samplestatus, String batchstatus) throws SapphireException {

        if (samplestatus.size() > 0) {
            PropertyList props1 = new PropertyList();
            props1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props1.setProperty(EditSDI.PROPERTY_KEYID1, samplestatus.getColumnValues("sampleid", ";"));
            props1.setProperty("u_currentmovementstep", "ExtractionCompleted");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props1);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Can't update in sample");
                error += ae.getMessage();
                throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
            }
        }

    }

    private void deleteReagentInstrument(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_REAGENT_BY_BATCHID, batchid);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("reagentid", dsReagents.getColumnValues("reagentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }

        sql = Util.parseMessage(MolecularSql.GET_INSTRUMENT_BY_BATCHID, batchid);
        DataSet dsInstruments = getQueryProcessor().getSqlDataSet(sql);
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("instrumentid", dsInstruments.getColumnValues("instrumentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

    private void updateBatchDetail(String newbatch) throws SapphireException {
        String removetag = "select sampleid from u_ngbatch_sample where u_ngbatchid='" + newbatch + "'";
        DataSet dsremovetag = getQueryProcessor().getSqlDataSet(removetag);
        PropertyList proptag = new PropertyList();
        proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
        proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, newbatch);
        proptag.setProperty("sampleid", dsremovetag.getColumnValues("sampleid", ";"));
        proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        // proptag.setProperty("tagid",
        // StringUtil.repeat("(null)",dsremovetag.size(),";"));
        proptag.setProperty("tagid", "(null)");
        proptag.setProperty("rulebypass", "Y");

        try {
            getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail");
        }
    }

    private void addAttachmentToChild(String parentbatchid, String newbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.COPY_ATTACHMENT_BY_BATCHID,
                StringUtil.replaceAll(parentbatchid, ";", "','"));
        DataSet dsDetails = getQueryProcessor().getSqlDataSet(sql);
        PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy(FILELOCATIONPOLICY, NODEID);
        if (plCaseFilePolicy == null)
            throw new SapphireException("File Location path can't be found");
        PropertyListCollection plc = plCaseFilePolicy.getCollection(PROPS_LOCATIONS);
        String newfileLocation = "";
        if (plc != null) {
            newfileLocation = plc.getPropertyList(0).getProperty(PROPS_LOCATION);
            if (Util.isNull(newfileLocation))
                throw new SapphireException("Please specify the path for keeping the plate maps in the policy "
                        + FILELOCATIONPOLICY + " under the node " + NODEID);
        }
        //CHECK INSTRUMENT FOLDER
        newfileLocation = Util.createFolderForMolecular(newfileLocation, "ExtractionMap");

        logger.info("ExtractionBatchComplete>>>", "File has to move this location: " + newfileLocation);
        String newFile = "";
        if (dsDetails != null && dsDetails.size() > 0) {
            for (int i = 0; i < dsDetails.size(); i++) {
                newFile = Util.copyFile(dsDetails.getValue(i, "filename", ""), newfileLocation);
                PropertyList plAttachment = new PropertyList();
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newbatchid);
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newFile);
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(newFile).getName());
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, plAttachment);
                } catch (SapphireException se) {
                    throw new SapphireException("File is not attached to a batch");
                }
            }

        }
    }

    /**
     * @throws : SapphireException
     * @Desc : This function is used to copy Elution Reagent for child batch of Extraction Historical Batches
     * @Paramid : PARENTBATCHID,
     * @Paramid: CHILDBATCHID
     */

    private void copyElutionReagentToChild(String parentbatchid, String childbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ELUTION_REAGENT_BY_PARENTBATCH, parentbatchid);
        DataSet dsElutionReagents = getQueryProcessor().getSqlDataSet(sql);
        if (dsElutionReagents.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "MolecularReagent");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "" + dsElutionReagents.size());
            prop.setProperty("reagentid", dsElutionReagents.getColumnValues("reagentid", ";"));
            prop.setProperty("volume", dsElutionReagents.getColumnValues("reagentvol", ";"));
            prop.setProperty("reagenttype", dsElutionReagents.getColumnValues("reagenttype", ";"));
            prop.setProperty("u_ngbatchid", StringUtil.repeat(childbatchid, dsElutionReagents.size(), ";"));
            prop.setProperty("volume", dsElutionReagents.getColumnValues("reagentvol", ";"));
            prop.setProperty("isbypassrule", "Y");
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (Exception e) {
                throw new SapphireException("Unable to copy elution reagents." + e.getMessage());
            }
        }
    }

    private void reAssignElutionTubeToBatch(String batchid) throws SapphireException {
        String getSampleStatus = Util.parseMessage(MolecularSql.GET_SAMPLESTATUS, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsSampleStatus = getQueryProcessor().getSqlDataSet(getSampleStatus);
        if (dsSampleStatus != null && dsSampleStatus.size() > 0) {
            String extrctiontubes = dsSampleStatus.getColumnValues("sampleid", ";");
            PropertyList attachprop = new PropertyList();
            attachprop.clear();
            attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
            attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
            attachprop.setProperty("sampleid", extrctiontubes);
            attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            attachprop.setProperty("rulebypass", "Y");

            try {
                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate(ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
            String sql = Util.parseMessage(MolecularSql.GET_ELLUTION_BY_EXTRACTION_TUBE, StringUtil.replaceAll(extrctiontubes, ";", "','"));
            DataSet dsElution = getQueryProcessor().getSqlDataSet(sql);
            if (dsElution != null && dsElution.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                /*START-Code modified to make sampleId unique*/
                props.setProperty("sampleid", Util.getUniqueList(dsElution.getColumnValues("s_sampleid", ";"), ";", true));
                /*END-Code modified to make sampleId unique*/
                props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                props.setProperty("rulebypass", "Y");
                try {
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                } catch (SapphireException ex) {
                    String msg = getTranslationProcessor().translate(ex.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                }
                String elutube = dsElution.getColumnValues("s_sampleid", ";");
                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, elutube);
                props.setProperty("u_currentmovementstep", StringUtil.repeat("QuantPending", dsElution.size(), ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (SapphireException ex) {
                    String msg = getTranslationProcessor().translate(ex.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                }
            }
        }
    }

    private void updateCalcualtion(DataSet dsInfo, String batchid) throws SapphireException {
        DataSet dsFinalElution = new DataSet();
        dsFinalElution.addColumn("sampleid", DataSet.STRING);
        dsFinalElution.addColumn("qtycurrent", DataSet.STRING);
        //dsElution.addColumn("sampleid",DataSet.STRING);
        if (dsInfo != null && dsInfo.size() > 0) {
            String extrctube = StringUtil.replaceAll(dsInfo.getColumnValues("sampleid", ";"), ";", "','");
            String sql = Util.parseMessage(MolecularSql.GET_EXTRC_INFO_BTCH_SAMPLE_BY_SAMPLEID, extrctube);
            DataSet dsExtrctnInfo = getQueryProcessor().getSqlDataSet(sql);
            sql = Util.parseMessage(MolecularSql.GET_ELLUTION_BY_EXTRACTION_TUBE, extrctube);
            DataSet dsElutionInfo = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();

            if (dsExtrctnInfo.size() > 0) {
                for (int i = 0; i < dsExtrctnInfo.size(); i++) {
                    double u_qtyinitial = Double.parseDouble(dsExtrctnInfo.getValue(i, "samplevolmn", "0.0"));
                    String extractionid = dsExtrctnInfo.getValue(i, "u_extractionid", "");
                    hm.clear();
                    hm.put("u_extractionid", extractionid);
                    DataSet dsEluFilter = dsElutionInfo.getFilteredDataSet(hm);
                    if (dsEluFilter.size() > 0) {
                        String elutiontube = dsEluFilter.getValue(0, "s_sampleid", "");
                        String isindependentflag = dsEluFilter.getValue(0, "isindependentflag", "N");
                        String elutionvolume = dsEluFilter.getValue(0, "elutionvolume", "");
                        int rowID = dsFinalElution.addRow();
                        dsFinalElution.setValue(rowID, "sampleid", elutiontube);
                        if ("N".equalsIgnoreCase(isindependentflag)) {
                            dsFinalElution.setValue(rowID, "qtycurrent", String.valueOf(u_qtyinitial));
                        } else {
                            dsFinalElution.setValue(rowID, "qtycurrent", String.valueOf(elutionvolume));
                        }
                    }
                }
            }
        }
        if (dsFinalElution.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinalElution.getColumnValues("sampleid", ";"));
            prop.setProperty("qtycurrent", dsFinalElution.getColumnValues("qtycurrent", ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update quantity" + ex.getMessage());
            }

            PropertyList proptag = new PropertyList();
            proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
            proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, batchid);
            proptag.setProperty("sampleid", dsFinalElution.getColumnValues("sampleid", ";"));
            proptag.setProperty("samplevolmn", dsFinalElution.getColumnValues("qtycurrent", ";"));
            proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            proptag.setProperty("rulebypass", "Y");

            try {
                getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
            } catch (SapphireException se) {
                throw new SapphireException("Can not edit batch detail" + se.getMessage());
            }
        }
    }
}
