package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

import static sapphire.custom.ng.util.Util.getUniqueList;

/**
 * Created by achakraborty on 10/27/2016.
 */
public class QuantificationComplete extends BaseAction {
	public void processAction(PropertyList properties) throws SapphireException {
		String samp = properties.getProperty("keyid1");
		if (Util.isNull(samp))
			throw new SapphireException("Keyid1 is obtained as null");

		PropertyList prop = new PropertyList();
		prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		String sql = Util.parseMessage(MolecularSql.GET_MOLSUBMETHODOLOGY_BY_SAMPLEID,
				StringUtil.replaceAll(samp, ";", "','"));
		DataSet dsMolSubMetho = getQueryProcessor().getSqlDataSet(sql);
		if (dsMolSubMetho != null && dsMolSubMetho.size() > 0) {
			HashMap hm = new HashMap();
			hm.clear();
			hm.put("molecularsubmethodology", "NanoString");
			DataSet dsFilter = dsMolSubMetho.getFilteredDataSet(hm);
			if (dsFilter != null && dsFilter.size() > 0) {
				prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
				prop.setProperty("u_pcrpending", "N");
			} else {
				prop.setProperty(EditSDI.PROPERTY_KEYID1, samp);
				prop.setProperty("u_pcrpending", "Y");
			}
		}
		prop.setProperty("u_quantificationcompletedts", "n");
		prop.setProperty("u_currentmovementstep", "QuantCompleted");
		prop.setProperty("u_mareceiveddts", "n");

		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
		updateQuantificationTrackItem(samp);
		// disposeBlocksAndUSSlides(samp); -- Disable by soumen. ( why all the
		// samples are disposed in quant complete)
	}

	private void disposeBlocksAndUSSlides(String sampleid) throws SapphireException {
		if (!Util.isNull(sampleid)) {
			String sql = "(select sourcesampleid from s_samplemap where destsampleid in('"
					+ StringUtil.replaceAll(sampleid, ";", "','") + "')) " + "union "
					+ "(select sourcesampleid from s_samplemap where destsampleid in "
					+ "(select sourcesampleid from s_samplemap where destsampleid in('"
					+ StringUtil.replaceAll(sampleid, ";", "','") + "')))";

			DataSet dsParntSamplleInfo = getQueryProcessor().getSqlDataSet(sql);
			if (dsParntSamplleInfo != null && dsParntSamplleInfo.size() > 0) {
				String prntSampleids = dsParntSamplleInfo.getColumnValues("sourcesampleid", ";");
				if (!Util.isNull(prntSampleids))
					sampleid += ";" + prntSampleids;
				if (!Util.isNull(sampleid)) {
					sampleid = Util.getUniqueList(sampleid, ";", true);
					PropertyList pl = new PropertyList();
					pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
					pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
					pl.setProperty("samplestatus", "Disposed");
					pl.setProperty("storagedisposalstatus", "Disposed");
					// pl.setProperty("storagestatus","Disposed"); -- Disable by
					// soumen; Disposed is not a valid storage status
					getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
				}
			}
		}
	}

	private void updateQuantificationTrackItem(String samp) throws SapphireException {
		String currentuser = connectionInfo.getSysuserId();
		String defaultdepartment = connectionInfo.getDefaultDepartment();
		String sampleid = StringUtil.replaceAll(samp, ";", "','");
		// String sql = "select tc.u_testcodeid, stm.s_sampleid,
		// stm.methodology, nvl(tc.molecularworkflow,'PCR') molecularworkflow "
		// +
		// "from u_sampletestcodemap stm, u_testcode tc " +
		// "where tc.u_testcodeid = stm.lvtestcodeid and s_sampleid in ('"+
		// sampleid +"') ";
		// DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		// DataSet dsFinal = null;
		// if (ds == null)
		// throw new SapphireException("Something wrong happened. Contact your
		// Administrator");
		// else if (ds.size() == 0)
		// throw new SapphireException("Error: Query returned zero rows\n
		// SQL:"+sql);
		// else {
		// HashMap<String, String> hmFilter = new HashMap<>();
		// hmFilter.put("methodology", "Molecular");
		// dsFinal = ds.getFilteredDataSet(hmFilter);
		// }
		// if(dsFinal!=null && dsFinal.size()>0) {
		PropertyList editTIProps = new PropertyList();
		editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, samp);
		editTIProps.setProperty("u_currenttramstop", "QuantCompleted");
		// editTIProps.setProperty("custodialuserid", currentuser);
		// editTIProps.setProperty("custodialdepartmentid",
		// destinationDepartment);
		// editTIProps.setProperty("custodialdepartmentid", defaultdepartment);

		try {
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Error in edit track item.");
			error += ae.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
		}
		// }

	}
}
