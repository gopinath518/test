package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.util.SetRootForPoolSample;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by DMondal on 10/24/2016.
 * Description : This action will dispose selected HnE samples and it will  create a new child sample and apply test to child that
 * was present in parent samples.
 */
public class SharedHnE  extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("keyid1");
        String sampleWithNoBackup=checkBackUpSlide(sampleids);
        if(!Util.isNull(sampleWithNoBackup)) {
            validation(sampleWithNoBackup);
        }
        updateStatus(sampleids);
        String newSample=createPoolSample(sampleids);
        updateCurrentmovementstep(newSample,sampleids);
        setRootSample( sampleids,  newSample);
        String test=getDataFromPolicy();
        String testCode=validateTest(test);
        DataSet dsTestparent=getParentTestCode(sampleids);
        applyTestCodesToChild(newSample,dsTestparent,testCode);
        String samples=getKeyidForShowInListPage(newSample,sampleids);
        properties.setProperty("sampleid1",samples);
    }

    /**
     * Descriptyion : This method will set root sample of created child sample.if multiple root coming it will not set any root sample.
     * @param parentsamples
     * @param childsample
     * @throws SapphireException
     */
    private void setRootSample(String parentsamples, String childsample) throws SapphireException {
        String parentSample = StringUtil.replaceAll(parentsamples, ";", "','");
        String sqlroot = "select s.u_rootsample from s_sample s where s.s_sampleid in ('" + parentSample + "')";
        DataSet dsRoot = getQueryProcessor().getSqlDataSet(sqlroot);
        if (dsRoot == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlroot;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String root = Util.getUniqueList(dsRoot.getColumnValues("u_rootsample", ";"), ";", true);

        if (Util.isNull(root)) {
            String sqlroot1 = "select s.u_rootsample from s_sample s,s_samplemap sm where sm.destsampleid in ('" + parentSample + "') " +
                    " and s.s_sampleid =sm.sourcesampleid";
            DataSet dsRoot1 = getQueryProcessor().getSqlDataSet(sqlroot1);
            if (dsRoot1 == null) {
                String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
                errStr += "\n Query failed: " + sqlroot1;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            String root1 = Util.getUniqueList(dsRoot1.getColumnValues("u_rootsample", ";"), ";", true);
            if (Util.isNull(root1)) {
                String errStr = getTranslationProcessor().translate("No root sample found for the sampleid:" + parentSample);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            //This code is for,if multiple root sample coming we will not set root.
            String[] rootArr1=root1.split(";");
            if(rootArr1.length>1){
                return;
            }
        }else {
            //This code is for,if multiple root sample coming we will not set root.
            String[] rootArr = root.split(";");
            if (rootArr.length > 1) {
                return;
            }
        }
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        Util.setRootForPoolSample(childsample, parentsamples,getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

    }

    /**
     * Description : This is for getting parent testcode.
     * @param parentSample
     * @return
     * @throws SapphireException
     */
    private DataSet getParentTestCode(String parentSample) throws SapphireException {
        DataSet dsMain=new DataSet();
        dsMain.addColumn("sample",DataSet.STRING);
        dsMain.addColumn("testcodepanelcode",DataSet.STRING);
        //1 Get parents test code
        String sqlTestCode = "select lvtestcodeid,lvtestpanelid,nvl(ispanel,'N') as ispanel,s_sampleid from u_sampletestcodemap " +
                "where s_sampleid in ('" + StringUtil.replaceAll(parentSample, ";", "','") + "')";
        DataSet dsTestCode = getQueryProcessor().getSqlDataSet(sqlTestCode);
        if (dsTestCode == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlTestCode;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsTestCode.size() == 0) {
            String errStr = getTranslationProcessor().translate("No test code found for the parent sample");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        //2. filter testcode by parent and assign to child in main dataset
        int incr=0;
        for (int i = 0; i < dsTestCode.getRowCount(); i++) {
                String isPanelExists =dsTestCode.getValue(i,"ispanel", ""); // This will be either Y or N // if mixmatch then logic will be change
                if ("Y".equalsIgnoreCase(isPanelExists)) {
                    //Test panel block
                    incr=dsMain.addRow();
                    dsMain.setValue(incr, "sample", dsTestCode.getValue(i,"s_sampleid", ""));
                    dsMain.setValue(incr, "testcodepanelcode", dsTestCode.getValue(i,"lvtestpanelid", ""));
                } else {
                    //Test code block
                    incr=dsMain.addRow();
                    dsMain.setValue(incr, "sample", dsTestCode.getValue(i,"s_sampleid", ""));
                    dsMain.setValue(incr, "testcodepanelcode", dsTestCode.getValue(i,"lvtestcodeid", ""));
                }
        }
        return dsMain;
    }

    /**
     * Description : This will validate testcode that is coming from policy.
     * @param test
     * @return
     * @throws SapphireException
     */
    private String validateTest(String test) throws SapphireException {
        String sqlTestCode="select u_testcodeid from u_testcode where u_testcodeid ='"+test+"'";
        DataSet dsTestCode = getQueryProcessor().getSqlDataSet(sqlTestCode);
        if (dsTestCode == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlTestCode;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsTestCode.size() == 0) {
            String errStr = getTranslationProcessor().translate("TestCode "+test+" not found in Lv DataBase");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String testcode=dsTestCode.getValue(0,"u_testcodeid");
        return testcode;
    }

    /**
     * Description : This will fetch test from policy.
     * @return
     * @throws SapphireException
     */
    private String getDataFromPolicy() throws SapphireException {
        PropertyList plGlobalPolicy = getConfigurationProcessor().getPolicy("SharedHnE", "hne");
        String test = plGlobalPolicy.getProperty("test");
        return test;
    }

    /**
     * Description : this is for apply testcode to the new generated sample.
     * @param newSample
     * @param dsTestparent
     * @param testCode
     * @throws SapphireException
     */
    private void applyTestCodesToChild(String newSample,DataSet dsTestparent,String testCode) throws SapphireException {
        String parentTest=Util.getUniqueList(dsTestparent.getColumnValues("testcodepanelcode", ";"), ";", true);
        String alltestCode="";
        if(Util.isNull(parentTest)) {
            alltestCode =  testCode;
        }else{
            alltestCode = parentTest + ";" + testCode;
        }
        String[] allTestArr = StringUtil.split(alltestCode, ";");
        String samples=StringUtil.repeat(newSample, allTestArr.length, ";");

        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, samples);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, alltestCode);
        try {
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
        }catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in assign testcode.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error+"Err:"+ex.getMessage());
        }
    }



    /**
     * Not required
     * Description : This method will check client speciment id same or not.
     * @param allSamples
     * @return
     * @throws SapphireException
     */
    private void checkClientSpecimenid(String allSamples) throws SapphireException {
        String sampleids = StringUtil.replaceAll(allSamples, ";", "','");
        String sqlSamples="select distinct s.u_clientspecimenid from s_sample s where s.s_sampleid in ('"+sampleids+"') ";
        DataSet dsSamples = getQueryProcessor().getSqlDataSet(sqlSamples);
        if (dsSamples == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlSamples;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        else if (dsSamples.size() == 0) {
            String errStr = getTranslationProcessor().translate("Client specimen id not found for the selected sample.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        else if (dsSamples.size() > 1) {
            String errStr = getTranslationProcessor().translate("Sampleid not belongs to same client specimen id.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String clientspecimen=dsSamples.getColumnValues("u_clientspecimenid",";");
        if(Util.isNull(clientspecimen)){
            String errStr = getTranslationProcessor().translate("Client specimen id not found for the selected sample.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
    }
    /**
     * Description : Backup slides will not go for validation.
     * @param allSamples
     * @return
     * @throws SapphireException
     */
    private String checkBackUpSlide(String allSamples) throws SapphireException {
        String sampleids = StringUtil.replaceAll(allSamples, ";", "','");
        String sqlSamples="select s_sampleid from s_sample where s_sampleid in ('"+sampleids+"') and u_type!='B'";
        DataSet dsSamples = getQueryProcessor().getSqlDataSet(sqlSamples);
        if (dsSamples == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlSamples;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String findSamples="";
        if (dsSamples.size() > 0) {
            findSamples=dsSamples.getColumnValues("s_sampleid",";");
        }

        return findSamples;
    }

    /**
     * description : This method will search all the samples that was created from parent sample and newly created samples and send it to
     * list page for display.
     * @param newSample
     * @param sampleids1
     * @return
     * @throws SapphireException
     */
    private String getKeyidForShowInListPage(String newSample,String sampleids1) throws SapphireException {
        String allSamples=sampleids1+";"+newSample;
        String sampleids = StringUtil.replaceAll(allSamples, ";", "','");
        String sqlSamples="select LISTAGG( destsampleid, ';') WITHIN GROUP (ORDER BY destsampleid) AS destsampleid from s_samplemap where sourcesampleid in " +
                "(select sourcesampleid from s_Samplemap where destsampleid in ('"+sampleids+"'))";
        DataSet dsSamples = getQueryProcessor().getSqlDataSet(sqlSamples);
        if (dsSamples == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlSamples;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsSamples.size() == 0) {
            String errStr = getTranslationProcessor().translate("Sample not found in s_samplemap table.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String findSamples=dsSamples.getValue(0,"destsampleid");
        return findSamples;
    }

    /**
     * Description : This method is used for validation.It will check that methodology should be Molecular or IHC and type should be HnE.
     * @param sampleid1
     * @throws SapphireException
     */
    private DataSet validation(String sampleid1) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sampleid1, ";", "','");
        String sqlType="select s.s_sampleid,stm.methodology,s.u_type from s_sample s,u_sampletestcodemap stm " +
                "where s.s_sampleid=stm.s_sampleid and s.s_sampleid in ('"+sampleid+"')";
        DataSet dsType = getQueryProcessor().getSqlDataSet(sqlType);
        if (dsType == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlType;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsType.size() == 0) {
            String errStr = getTranslationProcessor().translate("selected sample has no test associated.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        int hbflag=0;
        int chflag=0;
        int oflag=0;
        for(int i=0;i<dsType.size();i++){
            String sample=dsType.getValue(i,"s_sampleid");
            String methodology=dsType.getValue(i,"methodology");
            if (Util.isNull(methodology)) {
                String error = getTranslationProcessor().translate("Methodology not found for the test code which is associated with sample:"+sample);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String type=dsType.getValue(i,"u_type");
            if (Util.isNull(type)) {
                String error = getTranslationProcessor().translate("Slide type not define for the sample:"+sample);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            if(!("Molecular".equalsIgnoreCase(methodology)|| "FISH".equalsIgnoreCase(methodology))){
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Sample id:"+sample+" does not associated with Molecular or FISH methodology.");
            }

            if("H".equalsIgnoreCase(type) || "B".equalsIgnoreCase(type)){
                hbflag=1;
                if(chflag==1 || oflag==1){
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Please select either H&E or backup Slide only.");
                }
            } else if(("CH".equalsIgnoreCase(type))) {
                if(hbflag==1 || oflag==1 || chflag==1){
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "You can not select any slides with client H&E Slide.");
                }
                chflag=1;
            }
            else if("U".equalsIgnoreCase(type)){
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Please Select HNE sample(s) only.Sample id:"+sample+" is unstained Slide.");
            }else{
                if(hbflag==1 || chflag==1){
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Please select either H&E or backup Slide(s) only.");
                }
                oflag=1;
            }
        }
        ///Old logic
        /*for(int i=0;i<dsType.size();i++){
            String sample=dsType.getValue(i,"s_sampleid");
            String methodology=dsType.getValue(i,"methodology");
            String type=dsType.getString(i,"u_type");
            if(!("Molecular".equalsIgnoreCase(methodology)|| "FISH".equalsIgnoreCase(methodology))){
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Sample id:"+sample+" does not associated with Molecular or FISH methodology.");
            }
            if(("U".equalsIgnoreCase(type))) {
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "You can not select unstained Slide.Sample id:"+sample+" is unstained Slide.");
            }
            else if(("CH".equalsIgnoreCase(type))) {
                if (i > 0 || (i==0 && dsType.size()>1)) {
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "You can not select any slides with client H&E Slide.");
                }
            }
            else if(!("H".equalsIgnoreCase(type) || "B".equalsIgnoreCase(type))){
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Sample id:"+sample+" is not H&E or backup Slide.");
            }
        }*/
        return dsType;
    }
    /**
     * Description : This method is used for dispose the selected samples.
     * @param sampleid
     * @throws SapphireException
     */
    private void updateStatus(String sampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("storagestatus", "Disposed");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update request in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
    /**
     * Description : This method is used for updating current movementstep step for newly created sample.
     * @param newsampleid
     * @throws SapphireException
     */
    private void updateCurrentmovementstep(String newsampleid,String parentsample) throws SapphireException {
        String sampleid = StringUtil.replaceAll(parentsample, ";", "','");
        String sqlSampleinfo="select a.u_accessionid,s.u_microtomystation from u_accession a,s_sample s " +
                "where s.u_accessionid=a.u_accessionid and s.s_sampleid in ('"+sampleid+"')";
        DataSet dsSampleinfo = getQueryProcessor().getSqlDataSet(sqlSampleinfo);
        if (dsSampleinfo == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlSampleinfo;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsSampleinfo.size() == 0) {
            String errStr = getTranslationProcessor().translate("Accessionid not found of parent sample:"+sampleid);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String accession=dsSampleinfo.getValue(0,"u_accessionid","");
        if(Util.isNull(accession)){
            String errStr = getTranslationProcessor().translate("Accessionid not found of parent sample:"+sampleid);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String microtomystation=dsSampleinfo.getValue(0,"u_microtomystation","");
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, newsampleid);
            props.setProperty("u_currentmovementstep", "Microtomy");
            props.setProperty("u_accessionid", accession);
            props.setProperty("u_microtomystation", microtomystation);
            props.setProperty("u_type", "H");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update current movementstep in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }


    /**
     * Description :This method creates a pool sample from the samples which are selected by user.
     * @param parentsample -  selected samples.
     * @return - Returns the poolsampleid.
     * @throws SapphireException
     */
    private String createPoolSample(String parentsample) throws SapphireException {
        String[] samplecount= StringUtil.split(parentsample,";");
        int samplecountVal=samplecount.length;
        PropertyList prop = new PropertyList();
        prop.setProperty("sampleid", parentsample);
        prop.setProperty("quantity", String.valueOf(samplecountVal));
        prop.setProperty("poolquantity", "1");
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, prop);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  "+e.getMessage());
        }
        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

}
