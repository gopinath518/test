package sapphire.custom.ng.action;

import ca.uhn.hl7v2.model.v21.datatype.ST;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by rrmandal on 8/11/2016.
 */
public class CreateReportingBatch extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String orgbatchtatus = properties.getProperty("orgbatchtatus","Precipitation Complete");
        if (Util.isNull(batchid)) {
            throw new SapphireException("Complete process cannot be performed.\nReason: Batchid is not found");
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(AddSDI.PROPERTY_TEMPLATEID, batchid);
        prop.setProperty("batchmovestatus", "SequencingComplete");
        prop.setProperty("origin", "Reporting");
        prop.setProperty("batchstatusview", "Reporting Pending");
        prop.setProperty("batchtype", "Molecular");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        String newBatch = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");

        if (!Util.isNull(newBatch)) {
            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
            prop.setProperty("batchmovestatus", "Complete");
            prop.setProperty("batchcompletedts", "n");
            prop.setProperty("batchstatusview", orgbatchtatus);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            deleteRegInfo(newBatch);

            String sql = "select filename from sdiattachment where keyid1='" + batchid + "'";
            DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
            if (dsAttachment != null && dsAttachment.size() > 0) {
                String filename = dsAttachment.getValue(0, "filename", "");
                if (!Util.isNull(filename)) {
                    prop.clear();
                    prop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                    prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newBatch);
                    prop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                    prop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                    prop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, prop);
                }
            }
            sql = "select sampleid from u_batch_sample_detail where u_ngbatchid='" + batchid + "'";
            DataSet dsSamples = getQueryProcessor().getSqlDataSet(sql);
            if (dsSamples != null && dsSamples.size() > 0) {
                String uniqueSamples = Util.getUniqueList(dsSamples.getColumnValues("sampleid", ";"), ";", true);
                prop.clear();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, uniqueSamples);
                prop.setProperty("u_reportflag", StringUtil.repeat("Y", StringUtil.split(uniqueSamples, ";").length, ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            }
            String mmerbatchid = autoMMERBatchCreate(newBatch);
            sql = "select batchname from u_ngbatch where u_ngbatchid='" + mmerbatchid + "'";
            DataSet dsNgBatchName = getQueryProcessor().getSqlDataSet(sql);
            String batchname = dsNgBatchName.getValue(0, "batchname", "");
            if (!Util.isNull(batchname)) {
                String url = "rc?command=page&page=ReportingBatchMaintMMER&returntolistpage=ReportingBatchList&sdcid=NGBatch&multisdimode=EditSet&ismmer=Y&keyid1=" + mmerbatchid;
                properties.setProperty("msg", "<a href='" + url + "' target='_blank'>" + batchname + "</a>");
            } else {
                properties.setProperty("msg", "Operation Successful");
            }
        } else {
            throw new SapphireException("Reporting batch cannot be created.");
        }
        //throw new SapphireException("Change");
    }

    private String autoMMERBatchCreate(String newBatch) throws SapphireException {
        String mmerbatchid = "";
        String sql = "select sm.destsampleid,s.u_extractionid,smp.lvtestcodeid,smp.testname,nvl(smp.lvtestpanelid,'N') lvtestpanelid from s_samplemap sm,s_sample s,u_sampletestcodemap smp where" +
                " sm.sourcesampleid=s.s_sampleid" +
                " and smp.s_sampleid = s.s_sampleid" +
                " and sm.destsampleid in (select distinct sampleid from u_batch_sample_detail where u_ngbatchid='" + newBatch + "')";
        DataSet dsResult = getQueryProcessor().getSqlDataSet(sql);
        if (dsResult != null && dsResult.size() > 0) {
            String extractionid = dsResult.getColumnValues("u_extractionid", ";");
            String sampleid = dsResult.getColumnValues("destsampleid", ";");
            String paramlist = dsResult.getColumnValues("testname", ";");
            PropertyList prop = new PropertyList();
            prop.setProperty("u_extractionid", extractionid);
            prop.setProperty("s_sampleid", sampleid);
            prop.setProperty("paramlistid", paramlist);
            prop.setProperty("tramstop", "Precepetation");
            getActionProcessor().processAction(AutoNGBatchCreate.ID, AutoNGBatchCreate.VERSION, prop);

            mmerbatchid = prop.getProperty("newmmerbatchid", "");

            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, newBatch);
            prop.setProperty("mmerbatchid", mmerbatchid);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

        }
        return mmerbatchid;
    }

    private void deleteRegInfo(String newBatch)throws SapphireException{
        if(!Util.isNull(newBatch)) {
            String sql = "select u_ngbatchid,analyte,reagentid,testcodeid,direction from u_ngbatcg_reagent_detail " +
                    "where u_ngbatchid in('"+ StringUtil.replaceAll(newBatch,";","','")+"') ";
            DataSet dsRegInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsRegInfo!=null && dsRegInfo.size()>0) {
                dsRegInfo.sort("u_ngbatchid");
                ArrayList<DataSet> dsRegInfoArr = dsRegInfo.getGroupedDataSets("u_ngbatchid");
                if(dsRegInfoArr!=null && dsRegInfoArr.size()>0) {
                    PropertyList prop = new PropertyList();
                    for(int i=0;i<dsRegInfoArr.size();i++) {
                        DataSet tempDS = dsRegInfoArr.get(i);
                        if(tempDS!=null  && tempDS.size()>0) {
                            String keyid1= tempDS.getValue(0,"u_ngbatchid","");
                            if(!Util.isNull(keyid1)) {
                                prop.clear();
                                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, keyid1);
                                prop.setProperty("analyte", tempDS.getColumnValues("analyte", ";"));
                                prop.setProperty("reagentid", tempDS.getColumnValues("reagentid", ";"));
                                prop.setProperty("testcodeid", tempDS.getColumnValues("testcodeid", ";"));
                                prop.setProperty("direction", tempDS.getColumnValues("direction", ";"));
                                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");

                                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
                            }
                        }
                    }
                }
            }
        }
    }
}
