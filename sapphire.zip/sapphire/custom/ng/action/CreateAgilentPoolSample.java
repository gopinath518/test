package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Created by akumar on 6/18/2016.
 *
 * @desc : Creates a pool sample after Agilent day2 batch creation.
 * This pool sample is created by taking all the samples altogether and create a
 * new sample which will have all the tests applied on it which are applied on those
 * samples.
 */
public class CreateAgilentPoolSample extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("u_ngbatchid");
        //String parentsample=properties.getProperty("sampleid");
        //String sql = "select sampleid from u_ngbatch_sample where u_ngbatchid='" + batchid + "'";
        String sql = "select ns.sampleid from u_ngbatch_sample ns ,s_sample s \n" +
                " where ns.sampleid=s.s_sampleid and ns.u_ngbatchid='" + batchid + "' and s.pooledflag is null";
        DataSet sample = getQueryProcessor().getSqlDataSet(sql);
        String parentsample = sample.getColumnValues("sampleid", ";");
        String newkeyid1 = createPoolSample(parentsample);
        associatePoolSample(batchid, newkeyid1);
        properties.setProperty("outmsg", newkeyid1);

    }

    /**
     * @param parentsample : All the samples which are loaded into plate.
     * @return :Returns the poolsampleid.
     * @throws SapphireException
     * @desc :This method creates a pool sample from the samples which are loaded into plate.
     */
    private String createPoolSample(String parentsample) throws SapphireException {
        String samples = StringUtil.replaceAll(parentsample, ";", "','");
        String ssql = "select lvtestcodeid,ispanel from u_sampletestcodemap where s_sampleid in('" + samples + "')";
        DataSet pool = getQueryProcessor().getSqlDataSet(ssql);
        HashSet<String> parentlist = new HashSet<String>(Arrays.asList(parentsample.split(";")));
        String sample1 = "";
        for (String s : parentlist) {
            sample1 = sample1 + ";" + s;
        }
        String sourcesampleid = sample1.substring(1);

        PropertyList prop = new PropertyList();
        prop.setProperty("sampleid", sourcesampleid);
        prop.setProperty("quantity", "10");
        prop.setProperty("poolquantity", "10");
        //props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        // props.setProperty("poolcustodialdepartmentid", dstrack.getValue(0, "custodialdepartmentid"
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, prop);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        String newkeyid = prop.getProperty("newkeyid1");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        //TODO NOT NECESSARY TO ASSOCIATE ROOT SAMPLE FOR THIS SCENARIO
        //Util.setRootForPoolSample(newkeyid, parentsample, getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        addTestCode(pool, newkeyid);

        return newkeyid;
    }

    /**
     * @param pool           :Dataset which contains all the information of samples and test
     * @param newkeyid:Newly created pool sample id.
     * @throws SapphireException
     * @desc :Applies all the tests on the newly created pool sample.
     */
    private void addTestCode(DataSet pool, String newkeyid) throws SapphireException {

        if (pool == null) {
            throw new SapphireException("No test is assigned to the Samples");
        }
        if (pool.size() == 0)
            throw new SapphireException("No test is assigned to the Samples");
        PropertyList props = new PropertyList();
        String lvtestcode = pool.getColumnValues("lvtestcodeid", ";");
        String ispanel = pool.getColumnValues("ispanel", ";");

        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);

        for (int j = 0; j < pool.getRowCount(); j++) {
            int rowID = dsSamplefinal.addRow();
            dsSamplefinal.setValue(rowID, "s_sampleid", newkeyid);
            dsSamplefinal.setValue(rowID, "lvtestcode", pool.getValue(j, "lvtestcodeid"));
            dsSamplefinal.setValue(rowID, "ispanel", pool.getValue(j, "ispanel", ""));
        }
        if (dsSamplefinal == null) {
            throw new SapphireException("DataSet containing Sample and test information is null");
        }
        if (dsSamplefinal.size() == 0) {
            throw new SapphireException("No test is assigned on the samples");
        }
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsSamplefinal.getColumnValues("s_sampleid", ";"));
        //props.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode",";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsSamplefinal.getColumnValues("lvtestcode", ";"));
        //props.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel",";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL, dsSamplefinal.getColumnValues("ispanel", ";"));
        //props.setProperty("bypassvalidation", "Y");
        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
        try {
            getActionProcessor().processAction("AssignTestCode", "1", props);

        } catch (Exception e) {
            throw new SapphireException("Unable to add a Test on a pool Sample");

        }

    }

    private void associatePoolSample(String ngbatchid, String sampleid) {
        PropertyList sampleprop = new PropertyList();
        sampleprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        sampleprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        sampleprop.setProperty("sampleid", sampleid);
        sampleprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleprop);
        } catch (SapphireException se) {

            String er1 = getTranslationProcessor().translate("Pool Sample not associated to batch");
            //ajaxResponse.addCallbackArgument("msg", er1);
        }
    }

}
