package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.CSVFileCreation;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by akumar on 10/3/2016.
 * Action creates csv file for Miseq and Nextseq and stores it
 * into defined path.This requires all the inputs to be entered
 * manually by user to create files for Miseq and Nextseq.
 */
public class MiseqAndNextseq extends BaseAction {
    private static final String DATASET_PROPERTY_IEMFileVersion = "IEMFileVersion";
    private static final String DATASET_PROPERTY_Investigator_Name = "Investigator Name";
    //private static final String DATASET_PROPERTY_Project_Name = "Project Name";
    private static final String DATASET_PROPERTY_Experiment_Name = "Experiment Name";
    private static final String DATASET_PROPERTY_Date = "Date";
    private static final String DATASET_PROPERTY_Workflow = "Workflow";
    private static final String DATASET_PROPERTY_Application = "Application";
    private static final String DATASET_PROPERTY_Assay = "Assay";
    private static final String DATASET_PROPERTY_Description = "Description";
    private static final String DATASET_PROPERTY_Chemistry = "Chemistry";
    private static final String DATASET_PROPERTY_Adapter = "Adapter";
    //Manifest
    private static final String DATASET_PROPERTY_ManifestA = "A";
    private static final String DATASET_PROPERTY_ManifestB = "B";
    private static final String DATASET_PROPERTY_ManifestC = "C";
    //Setting
    private static final String DATASET_PROPERTY_VariantCaller = "VariantCaller";
    private static final String DATASET_PROPERTY_VariantFilterQualityCutoff = "VariantFilterQualityCutoff";
    private static final String DATASET_PROPERTY_outputgenomevcf = "outputgenomevcf";
    //NextSeq
    private static final String DATASET_PROPERTY_FileVersion = "FileVersion";
    private static final String DATASET_PROPERTY_LibraryPrepKit = "LibraryPrepKit";
    private static final String DATASET_PROPERTY_ContainerType = "ContainerType";
    private static final String DATASET_PROPERTY_ContainerID = "ContainerID";
    private static final String DATASET_PROPERTY_Notes = "Notes";
    private static final String DATASET_PROPERTY_Species = "Species";
    private static final ArrayList<String> miseqeuence=new ArrayList<String>();
    private static final ArrayList<String> manifest=new ArrayList<String>();
    private static final ArrayList<String> settings=new ArrayList<String>();
    private static final ArrayList<String> nextseqeuence=new ArrayList<String>();


    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String batchname = properties.getProperty("batchname");
        String flow = properties.getProperty("flow");
        String iemfileversion = properties.getProperty("iemfileversion");
        String investigatorname = properties.getProperty("investigatorname");
        String projectname = properties.getProperty("projectname");
        String experimentname = properties.getProperty("experimentname");
        String date = properties.getProperty("date");
        String workflow = properties.getProperty("workflow");
        String application = properties.getProperty("application");
        String assay = properties.getProperty("assay");
        String description = properties.getProperty("description");
        String chemistry = properties.getProperty("chemistry");
        String illworkflow=properties.getProperty("illworkflow");
        //String un=properties.getProperty("151");
        //String un1=properties.getProperty("151");
        String adapter = properties.getProperty("adapter");
        //[Manifests]
        String manifesta = properties.getProperty("manifesta");
        String manifestb = properties.getProperty("manifestb");
        String manifestc = properties.getProperty("manifestc");
        //[Reads]
        String reads1 = properties.getProperty("reads1");
        String reads2 = properties.getProperty("reads2");
        //[Settings]
        String variantcaller = properties.getProperty("variantcaller");
        String variantfilter = properties.getProperty("variantfilter");
        String outputgenomevcf = properties.getProperty("outputgenomevcf");
        //NextSeq
        String fileversion=properties.getProperty("fileversion","");
        String libraryprepkit=properties.getProperty("libraryprepkit","");
        String containertype=properties.getProperty("containertype","");
        String containerid=properties.getProperty("containerid","");
        String notes=properties.getProperty("notes","");
        String species=properties.getProperty("species","");
        //DataSet for Batch Info
        //String batchdetail = "select sampleid,tagid,tagidp5 from u_ngbatch_sample where u_ngbatchid='" + batchid + "'";
        String batchdetail = "select s.u_extractionid as extractionid,s.s_sampleid as sampleid,tagid,tagidp5 from u_ngbatch_sample us,s_sample s,trackitem t " +
                " where us.sampleid=s.s_sampleid and s.s_sampleid=t.linkkeyid1 and t.containertypeid = 'Dilution Tube' and u_ngbatchid='" + batchid + "'";

        DataSet batchinfo = getQueryProcessor().getSqlDataSet(batchdetail);
        //DataSet Plate
        String plate="select plateid from u_ngbatch_plate where u_ngbatchid='"+batchid+"'";
        DataSet plateid=getQueryProcessor().getSqlDataSet(plate);
        //DataSet Item Label
        String platecontent="select a.itemlabel,ac.contentkeyid1 \n" +
                " from arrayitem a,arrayitemcontent ac where a.arrayitemid=ac.arrayitemid and a.arrayid='"+plateid.getColumnValues("plateid",";")+"'";
        DataSet itemlabel=getQueryProcessor().getSqlDataSet(platecontent);
        for(int i=0;i<itemlabel.size();i++){
            int j = itemlabel.getValue(i,"itemlabel").length();
            if(j==2){
                String wellpos = itemlabel.getValue(i,"itemlabel");
                wellpos = wellpos.substring(0,1)+"0"+wellpos.substring(1);
                itemlabel.setValue(i,"itemlabel",wellpos);
            }
        }
        //
        String tagid=batchinfo.getColumnValues("tagid",";");
        String tagp7= StringUtil.replaceAll(tagid,";","','");
        String tagidp5=batchinfo.getColumnValues("tagidp5",";");
        String tagp5=StringUtil.replaceAll(tagidp5,";","','");
        String index="select refvalueid,refdisplayvalue from refvalue where reftypeid='TagSequence' and refvalueid in('"+tagp7+"')";
        DataSet dsp7=getQueryProcessor().getSqlDataSet(index);
        String index2="select refvalueid,refdisplayvalue from refvalue where reftypeid='TagSequenceP5' and refvalueid in('"+tagp5+"')";
        DataSet dsp5=getQueryProcessor().getSqlDataSet(index2);
        /*
        if (itemlabel==null || itemlabel.size()==0){
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,"Plate Does not have any contents");
        }*/
        batchinfo.addColumn("sample_well",DataSet.STRING);
        batchinfo.addColumn("I7_Index_ID",DataSet.STRING);
        batchinfo.addColumn("I5_Index_ID",DataSet.STRING);
        //
        //Index value for I7 and I5
        String miseqindex="select i7index,i7indexvalue,i5index,i5indexvalue from u_miseqdata where application='"+application+"' and assay='"+assay+"'";
        DataSet miindex=getQueryProcessor().getSqlDataSet(miseqindex);
        HashMap hm=new HashMap();
        for(int i=0;i<itemlabel.size();i++) {
            hm.clear();
            hm.put("sampleid", itemlabel.getValue(i,"contentkeyid1"));
            int j=batchinfo.findRow(hm);
            batchinfo.setValue(j,"sample_well",itemlabel.getValue(i,"itemlabel"));
        }/*
        HashMap hmp5=new HashMap();
        for(int i=0;i<batchinfo.size();i++){
            hmp5.clear();
            hmp5.put("tagidp5",dsp5.getValue(i,"tagidp5"));
            hmp5.put("tagid",dsp7.getValue(i,"tagid"));
            int k=batchinfo.findRow(hmp5);
            batchinfo.setValue(k,"I5_Index_ID",dsp5.getValue(i,"refdisplayvalue"));
            batchinfo.setValue(k,"I7_Index_ID",dsp7.getValue(i,"refdisplayvalue"));
        }*//*
        HashMap hmp7=new HashMap();
        for(int i=0;i<dsp7.size();i++){
            hmp7.clear();
            hmp7.put("tagid",dsp7.getValue(i,"refvalueid"));
            int j=batchinfo.findRow(hmp7);
            batchinfo.setValue(j,"I7_Index_ID",dsp7.getValue(i,"refdisplayvalue"));
        }*/

        DataSet dsmiseq = new DataSet();
        dsmiseq.addColumn(DATASET_PROPERTY_IEMFileVersion, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Investigator_Name, DataSet.STRING);
        //dsmiseq.addColumn(DATASET_PROPERTY_Project_Name, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Experiment_Name, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Date, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Workflow, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Application, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Assay, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Description, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Chemistry, DataSet.STRING);
        dsmiseq.addColumn(DATASET_PROPERTY_Adapter, DataSet.STRING);

        DataSet dsManifest=new DataSet();
        dsManifest.addColumn(DATASET_PROPERTY_ManifestA,DataSet.STRING);
        dsManifest.addColumn(DATASET_PROPERTY_ManifestB,DataSet.STRING);
        dsManifest.addColumn(DATASET_PROPERTY_ManifestC,DataSet.STRING);

        DataSet dsSettings=new DataSet();
        dsSettings.addColumn(DATASET_PROPERTY_VariantCaller,DataSet.STRING);
        dsSettings.addColumn(DATASET_PROPERTY_VariantFilterQualityCutoff,DataSet.STRING);
        dsSettings.addColumn(DATASET_PROPERTY_outputgenomevcf,DataSet.STRING);


        dsmiseq.addColumnValues(DATASET_PROPERTY_IEMFileVersion, DataSet.STRING, iemfileversion, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Investigator_Name, DataSet.STRING, investigatorname, ";");
        //dsmiseq.addColumnValues(DATASET_PROPERTY_Project_Name, DataSet.STRING, projectname, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Experiment_Name, DataSet.STRING, experimentname, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Date, DataSet.STRING, date, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Workflow, DataSet.STRING, workflow, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Application, DataSet.STRING, application, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Assay, DataSet.STRING, assay, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Description, DataSet.STRING, description, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Chemistry, DataSet.STRING, chemistry, ";");
        dsmiseq.addColumnValues(DATASET_PROPERTY_Adapter, DataSet.STRING, adapter, ";");



        dsManifest.addColumnValues(DATASET_PROPERTY_ManifestA, DataSet.STRING, manifesta, ";");
        dsManifest.addColumnValues(DATASET_PROPERTY_ManifestB, DataSet.STRING, manifestb, ";");
        dsManifest.addColumnValues(DATASET_PROPERTY_ManifestC, DataSet.STRING, manifestc, ";");

        dsSettings.addColumnValues(DATASET_PROPERTY_VariantCaller,DataSet.STRING,variantcaller,";");
        dsSettings.addColumnValues(DATASET_PROPERTY_VariantFilterQualityCutoff,DataSet.STRING,variantfilter,";");
        dsSettings.addColumnValues(DATASET_PROPERTY_outputgenomevcf,DataSet.STRING,outputgenomevcf,";");



        DataSet dsnextseq = new DataSet();
        //dsmiseq.addColumn("IEMFileVersion",DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_FileVersion, DataSet.STRING);
        //dsmiseq.addColumn("Project Name",DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_LibraryPrepKit, DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_ContainerType, DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_ContainerID, DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_Notes, DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_Species, DataSet.STRING);
        /*
        dsnextseq.addColumn(DATASET_PROPERTY_Assay, DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_Description, DataSet.STRING);
        dsnextseq.addColumn(DATASET_PROPERTY_Chemistry, DataSet.STRING);*/
        //dsmiseq.addColumn("Adapter",DataSet.STRING);

        //dsmiseq.addColumnValues("IEMFileVersion",DataSet.STRING,iemfileversion,";");
        dsnextseq.addColumnValues(DATASET_PROPERTY_FileVersion, DataSet.STRING, fileversion, ";");
        //dsmiseq.addColumnValues("Project Name",DataSet.STRING,projectname,";");
        dsnextseq.addColumnValues(DATASET_PROPERTY_LibraryPrepKit, DataSet.STRING, libraryprepkit, ";");
        dsnextseq.addColumnValues(DATASET_PROPERTY_ContainerType, DataSet.STRING, containertype, ";");
        dsnextseq.addColumnValues(DATASET_PROPERTY_ContainerID, DataSet.STRING, containerid, ";");
        dsnextseq.addColumnValues(DATASET_PROPERTY_Notes, DataSet.STRING, notes, ";");
        dsnextseq.addColumnValues(DATASET_PROPERTY_Species, DataSet.STRING, species, ";");
        //dsmiseq.addColumnValues("Adapter",DataSet.STRING,adapter,";");


        try {
            if (flow.equalsIgnoreCase("miseq")) {
                miseqeuence.add(0, DATASET_PROPERTY_IEMFileVersion);
                miseqeuence.add(1, DATASET_PROPERTY_Investigator_Name);
               // miseqeuence.add(2, DATASET_PROPERTY_Project_Name);
                miseqeuence.add(2, DATASET_PROPERTY_Experiment_Name);
                miseqeuence.add(3, DATASET_PROPERTY_Date);
                miseqeuence.add(4, DATASET_PROPERTY_Workflow);
                miseqeuence.add(5, DATASET_PROPERTY_Application);
                miseqeuence.add(6, DATASET_PROPERTY_Assay);
                miseqeuence.add(7, DATASET_PROPERTY_Description);
                miseqeuence.add(8, DATASET_PROPERTY_Chemistry);
                miseqeuence.add(9, DATASET_PROPERTY_Adapter);

                //manifest
                manifest.add(0,DATASET_PROPERTY_ManifestA);
                manifest.add(1,DATASET_PROPERTY_ManifestB);
                manifest.add(2,DATASET_PROPERTY_ManifestC);

                //settings
                settings.add(0,DATASET_PROPERTY_VariantCaller);
                settings.add(1,DATASET_PROPERTY_VariantFilterQualityCutoff);
                settings.add(2,DATASET_PROPERTY_outputgenomevcf);
                String location=getFileLocation(flow);
                String miseqfile=CSVFileCreation.writeCSV(batchname,miindex,location,illworkflow,reads1,reads2,dsmiseq,dsManifest,dsSettings, batchinfo,manifest,settings, miseqeuence);
                properties.setProperty("msg",miseqfile);
            }
            if (flow.equalsIgnoreCase("nextseq")) {
                nextseqeuence.add(0,DATASET_PROPERTY_FileVersion);
                nextseqeuence.add(1,DATASET_PROPERTY_LibraryPrepKit);
                nextseqeuence.add(2,DATASET_PROPERTY_ContainerType);
                nextseqeuence.add(3,DATASET_PROPERTY_ContainerID);
                nextseqeuence.add(4,DATASET_PROPERTY_Notes);
                nextseqeuence.add(5,DATASET_PROPERTY_Species);
                String locnext=getFileLocation(flow);
                String nextseqfile=CSVFileCreation.writeCSVnextseq(batchname,locnext,illworkflow,dsnextseq, batchinfo,nextseqeuence);
                properties.setProperty("msg",nextseqfile);
            }

        } catch (FileNotFoundException e) {
            throw new SapphireException("Can not create a file");
        }
    }
    private String getFileLocation(String instrumentworkflow) throws SapphireException {
        String fileLocation = "";
        String id = "";
        String title = "";
        PropertyList filelocprop=null;

        //PropertyList filelocprop = getConfigurationProcessor().getPolicy("FileLocationPolicy", "ExtractionMap");
        //PropertyList filelocprop = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MiSeqNextSeq");
        if(instrumentworkflow.equalsIgnoreCase("miseq")){
            filelocprop = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MiSeq");
        }
        if(instrumentworkflow.equalsIgnoreCase("nextseq")){
            filelocprop = getConfigurationProcessor().getPolicy("FileLocationPolicy", "NextSeq500");
        }
        PropertyListCollection plc = filelocprop.getCollection("locations");
        //PropertyListCollection plc = locprop.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        if (fileLocation.equalsIgnoreCase("")) {
            throw new SapphireException("Location is not found");
        }
        return fileLocation;
    }

}
