package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 5/28/2016.
 * todo provide action details
 */
public class CreateDaughterSample extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String parentsample = properties.getProperty("parentsample");
        String daughterno = properties.getProperty("daughterno");
        String volume = properties.getProperty("volume");
        String units = properties.getProperty("units");
        String quantity = properties.getProperty("quantity");
        String currentuser=connectionInfo.getSysuserId();

        String childsampleid=createDaughterTube(parentsample, daughterno, volume, units, quantity);
        properties.setProperty("newkeyid1",childsampleid);
        String sql="select containertypeid,custodialdepartmentid from trackitem where linksdcid='Sample' and linkkeyid1='"+parentsample+"'";
        DataSet ds=getQueryProcessor().getSqlDataSet(sql);
        String containertype=ds.getColumnValues("containertypeid",";");
        String custodialdepartmentid=ds.getColumnValues("custodialdepartmentid",";");
        updateSample(childsampleid,volume,units);
        updateTrackitem(childsampleid,currentuser,volume,units,containertype,custodialdepartmentid);
        labelPrint(childsampleid);
    }

    private String createDaughterTube(String parentsample, String daughterno, String volume, String units, String quantity) throws SapphireException {

        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentsample);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, daughterno);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY, volume);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT, units);
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_QUANTITY, quantity);
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_markminimal;u_sampleinformation;u_accessionid;u_currentmovementstep;u_clientspecimenid;collectiondt");

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create Daughter specimen.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String newkeyid=prop.getProperty("newkeyid1");
       return newkeyid;
    }

    private void updateTrackitem(String childsampleid,String currentuser,String volume,String units,String containertype,String custodialdepartmentid ) throws SapphireException{
        PropertyList props=new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1,childsampleid);
        props.setProperty("containertypeid",containertype);
        props.setProperty("custodialuserid",currentuser);
        props.setProperty("custodialdepartmentid",custodialdepartmentid);
        props.setProperty("custodytakendt","n");
        props.setProperty("qtycurrent",volume);
        props.setProperty("qtyunits",units);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }catch(SapphireException e){
            String err = getTranslationProcessor().translate("Cannot update Trackitem for specimen.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }
    private void updateSample(String childsampleid,String volume,String units) throws SapphireException{
        PropertyList prop1=new PropertyList();
        prop1.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        prop1.setProperty(EditSDI.PROPERTY_KEYID1,childsampleid);
        prop1.setProperty("u_initialamount",volume);
        prop1.setProperty("u_initialvolunit",units);
        prop1.setProperty("storagestatus","In Circulation");

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,prop1);

    }

    /**
     * Description : This labelPrint method added for automatic printing of daughter tube label.
     * @param childsampleid
     * @throws SapphireException
     */
    private void labelPrint(String childsampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, childsampleid);
        props.setProperty(PrintLabel.LABELTYPE_PROP , "FreshPrep");
        props.setProperty(PrintLabel.TRAMLINE_PROP, "FreshPrep");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, "FreshPrepDaughterTube");
        try {
            getActionProcessor().processAction("PrintLabel",PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }
}


