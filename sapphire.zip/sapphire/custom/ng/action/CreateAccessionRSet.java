package sapphire.custom.ng.action;

import com.labvantage.sapphire.RSet;
import sapphire.SapphireException;
import sapphire.accessor.DAMProcessor;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by SBaitalik on 9/16/2017.
 */
public class CreateAccessionRSet extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("keyid1", "");
        String pagename = properties.getProperty("pagename", "");
        String typeaction = properties.getProperty("typeaction", "CL");
        String sql = Util.parseMessage(AccessionPageSql.GET_RSET_BY_ACCESSIONID, accessionid);
        DataSet dsRsetCheck = getQueryProcessor().getSqlDataSet(sql);
        if (dsRsetCheck != null && dsRsetCheck.size() > 0) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("connectionid", getConnectionProcessor().getConnectionid());
            DataSet dsFilter = dsRsetCheck.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                if ("CL".equalsIgnoreCase(typeaction)) {
                    sql = Util.parseMessage(AccessionPageSql.GET_RSET_BY_ACCESSIONID, accessionid);
                    DataSet dsRes = getQueryProcessor().getSqlDataSet(sql);
                    if (dsRes != null && dsRes.size() > 0) {
                        String rsetid = dsRes.getValue(0, "rsetid", "");
                        getDAMProcessor().clearRSet(rsetid);
                    }
                } else if ("CR".equalsIgnoreCase(typeaction)) {
                    String rsetid = getDAMProcessor().createRSet("Accession", pagename, "U", accessionid);
                }
                properties.setProperty("islocked", "N");
            } else {
                /*if ("CL".equalsIgnoreCase(typeaction)) {
                    sql = Util.parseMessage(AccessionPageSql.GET_RSET_BY_ACCESSIONID, accessionid);
                    DataSet dsRes = getQueryProcessor().getSqlDataSet(sql);
                    if (dsRes != null && dsRes.size() > 0) {
                        String rsetid = dsRes.getValue(0, "rsetid", "");
                        getDAMProcessor().clearRSet(rsetid);
                    }
                } else if ("CR".equalsIgnoreCase(typeaction)) {
                    String rsetid = getDAMProcessor().createRSet("Accession", pagename, "U", accessionid);
                }*/
                properties.setProperty("islocked", "Y");
            }
        } else {
            if ("CL".equalsIgnoreCase(typeaction)) {
                sql = Util.parseMessage(AccessionPageSql.GET_RSET_BY_ACCESSIONID, accessionid);
                DataSet dsRes = getQueryProcessor().getSqlDataSet(sql);
                if (dsRes != null && dsRes.size() > 0) {
                    String rsetid = dsRes.getValue(0, "rsetid", "");
                    getDAMProcessor().clearRSet(rsetid);
                }
            } else if ("CR".equalsIgnoreCase(typeaction)) {
                String rsetid = getDAMProcessor().createRSet("Accession", pagename, "U", accessionid);
            }
            properties.setProperty("islocked", "N");
        }

    }
}
