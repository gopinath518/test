package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.QueryProcessor;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.ConnectionInfo;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by ajha on 4/27/2016.
 * @Desc : This action is used to provide accessioning comment to the sample
 * @Param1 : sampleid
 * @throws : SapphireException
 */
public class AccessionComment extends BaseAction

{
    public void processAction(PropertyList properties) throws SapphireException {

        String comments = properties.getProperty("comment");
        String sampleid = properties.getProperty("sampleid");
        String commentby = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String departmentId = properties.getProperty("departmentid");

        String sql = "select u_accessionid from  s_sample  where  s_sampleid in('" + sampleid.replaceAll(";", "','") + "')";
        //completeStep(comments,sampleid,completedby);

        DataSet accession = getQueryProcessor().getSqlDataSet(sql);

        if(accession == null){
            String errMsg =getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg+="\nQuery returns null, Query failed:"+sql;

            throw new SapphireException(ErrorDetail.TYPE_FAILURE,errMsg);

        }
        if(accession.size()==0){
            String errMsg =getTranslationProcessor().translate("No Accession Id found for source sample.");
            errMsg+="\nSampleID:"+sampleid+", Query retuns no rows:"+sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,errMsg);
        }
        if(accession.size() >0 && accession != null){
            accession.addColumnValues("sampleid", DataSet.STRING, sampleid, ";");
            // ds.addColumnValues("comments", DataSet.STRING, comments, ";");
            accession.addColumnValues("comments", DataSet.STRING, StringUtil.repeat(comments, accession.size(), ";"), ";");
            //  ds.addColumnValues("commentby", DataSet.STRING, commentby, ";");
            accession.addColumnValues("commentby", DataSet.STRING, StringUtil.repeat(commentby, accession.size(), ";"), ";");
            accession.addColumnValues("departmentid", DataSet.STRING, StringUtil.repeat(departmentId, accession.size(), ";"), ";");
            updateComment(accession);


        }
       // String accessionid = accession.getColumnValues("u_accessionid", ";");

    }

    /**
     * Description:
     * @param ds properties
     * @throws SapphireException
     */
    private void updateComment(DataSet ds) throws SapphireException {


        PropertyList props = new PropertyList();

        try {
            props.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
            props.setProperty(AddSDI.PROPERTY_COPIES, "" + ds.getRowCount());

            props.setProperty("sampleid", ds.getColumnValues("sampleid", ";"));
            props.setProperty("comments", ds.getColumnValues("comments", ";"));
            props.setProperty("accessionid", ds.getColumnValues("u_accessionid", ";"));
            props.setProperty("commentby", ds.getColumnValues("commentby", ";"));
            props.setProperty("commentdt", "n");
            props.setProperty("departmentid", ds.getColumnValues("departmentid", ";"));
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);


        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move next step");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }

    }

}