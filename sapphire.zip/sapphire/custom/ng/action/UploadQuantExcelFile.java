package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;

/**
 * Created by gpandi on 10/26/2017
 * Description : This action used for Attach XLS file in Molecular Quantification Batch.
 * Table Used : sdiattachment
 */
public class UploadQuantExcelFile extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid", "");
        String file = properties.getProperty("path", "");
        String tramstop = properties.getProperty("tramstop", "");
        if (Util.isNull(file))
            throw new SapphireException("Plate map file is not found. Please upload a valid file.");
        if (file.indexOf(".xls") <= 0)
            throw new SapphireException("Invalid file format obtained. Please upload  Excel file.");

        attachedCount(batchid, tramstop);
        addAttachment(batchid, file);
    }

    /**
     * Description : Used to validate count of attachment in sdiattachment
     * param  : batchid
     * throws : SapphireException
     */
    private void attachedCount(String batchid, String tramstop) throws SapphireException {

        String sqlCount = Util.parseMessage(MolecularSql.QUANTPARSER_ATTACHCOUNT, batchid);
        DataSet dsCount = getQueryProcessor().getSqlDataSet(sqlCount);
        if (dsCount.size() == 0) {
            String errStr = getTranslationProcessor().translate("Specimen Attachment Count not found");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        int cnt = dsCount.getInt(0, "attachcount");
        if (!"COBAS".equalsIgnoreCase(tramstop)) {
            if (cnt >= 3) {
                String errStr = getTranslationProcessor().translate("You can't upload file more than 3 times.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        } else {
            if (cnt >= 4) {
                String errStr = getTranslationProcessor().translate("You can't upload file more than 4 times.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
    }

    /**
     * Description : Attach the Excel File to Molecular Batch.
     * param : batchid, file
     * throws : SapphireException
     */
    private void addAttachment(String batchid, String file) throws SapphireException {
        if (!Util.isNull(batchid) && !Util.isNull(file)) {
            PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
            if (plCaseFilePolicy == null)
                throw new SapphireException("File Location path can't be found");
            PropertyListCollection plc = plCaseFilePolicy.getCollection("locations");
            String fileTemplateIdentifier = "xls";
            if (plc != null) {
                String newfileLocation = plc.getPropertyList(0).getProperty("location");
                //CHECK FOLDER
                newfileLocation = Util.createFolderForMolecular(newfileLocation, "Instrument");
                if (Util.isNull(newfileLocation))
                    throw new SapphireException("Respective path is missing, Please contact Administrator. ");
                String newFile = Util.copyFile(file, newfileLocation, (fileTemplateIdentifier + "_"));
                if (Util.isNull(newFile))
                    throw new SapphireException("File can't be created in the location " + newfileLocation);

                PropertyList pl = new PropertyList();
                pl.setProperty(sapphire.action.AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(sapphire.action.AddSDIAttachment.PROPERTY_KEYID1, batchid);
                pl.setProperty(sapphire.action.AddSDIAttachment.PROPERTY_FILENAME, newFile);
                pl.setProperty(sapphire.action.AddSDIAttachment.PROPERTY_DESCRIPTION, new File(newFile).getName());
                pl.setProperty(sapphire.action.AddSDIAttachment.PROPERTY_TYPE, "R");
                pl.setProperty("sourcefilename", "Quantit");
                getActionProcessor().processAction(sapphire.action.AddSDIAttachment.ID, sapphire.action.AddSDIAttachment.VERSIONID, pl);
            }
        }
    }
}


