package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by akumar on 6/29/2016.
 *
 * @desc :Manually move the samples from PathSupport to IHC and vice versa.
 * It takes sampleid and currentmovementstep as input and moves the samples.
 */
public class PathSupportToIHC extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String currentmovement = properties.getProperty("currentmovement");
        String dept = connectionInfo.getDefaultDepartment();
        String fromcurrmovstep = properties.getProperty("fromcurrmovstep");
        String sampletype = properties.getProperty("sampletype");
        String methodology = properties.getProperty("methodology");
        methodology = Util.getUniqueList(methodology, ";", true);

        if (Util.isNull(sampleid))
            throw new SapphireException("SampleId(s) cannot be obtained.");
        String methodologyArr[] = null;
        if (!Util.isNull(methodology))
            methodologyArr = StringUtil.split(methodology, ";", true);
        if (methodologyArr != null && methodologyArr.length > 1)
            throw new SapphireException("Please select the specimen(s) belonging to a single methodology.");

        DataSet dsSmplType = new DataSet();
        dsSmplType.addColumnValues("sampleid",DataSet.STRING,sampleid,";");
        dsSmplType.addColumnValues("sampletype",DataSet.STRING,sampletype,";");

        String[] sampleArr = StringUtil.split(sampleid,";");
        String[] sampletypeArr = StringUtil.split(sampletype,";");

        if ("MOQCSample".equalsIgnoreCase(currentmovement)) {
            if (!"Multiomyx".equalsIgnoreCase(methodologyArr[0])) {
                throw new SapphireException("Only Multiomyx specimen(s) can be routed to MO-WetLab");
            }
            for(int i=0;i< sampletypeArr.length; i++){
                /*if("H".equalsIgnoreCase(sampletypeArr[i]) || "CH".equalsIgnoreCase(sampletypeArr[i]) )
                    throw new SapphireException("Error : Below Selected H&E Specimen(s) can not be Routed to MO-WetLab -\n"+sampleArr[i]);*/
                if(!"U".equalsIgnoreCase(sampletypeArr[i]) || !"CU".equalsIgnoreCase(sampletypeArr[i]) )
                    throw new SapphireException("Error : Only Unstained/Client Unstained Slide(s) can be Routed to MO-WetLab..");
            }

            validateMOHneSpecimenStatus(sampleid);
        } else {
            if("Multiomyx".equalsIgnoreCase(methodologyArr[0])){
                for(int i=0;i< sampletypeArr.length; i++){
                    if( "U".equalsIgnoreCase(sampletypeArr[i]) || "CU".equalsIgnoreCase(sampletypeArr[i])  )
                        throw new SapphireException("Erroe : Below Selected Multiomyx Unstained slide(s) can not be Routed to IHC -\n"+sampleArr[i]);
                }
            }
        }

        sampleid = Util.getUniqueList(sampleid, ";", true);
        sampleArr = StringUtil.split(sampleid, ";", true);
        if (sampleArr != null && sampleArr.length > 0) {
            for (int i = 0; i < sampleArr.length; i++) {
                try {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleArr[i]);
                    prop.setProperty("u_currentmovementstep", currentmovement);

                    HashMap hm = new HashMap();
                    hm.put("sampleid",sampleArr[i]);
                    DataSet dsFilter = dsSmplType.getFilteredDataSet(hm);

                    hm.clear();
                    hm.put("sampletype","U");
                    DataSet dsFilterUtype = dsFilter.getFilteredDataSet(hm);

                    hm.clear();
                    hm.put("sampletype","CU");
                    DataSet dsFilterCUtype = dsFilter.getFilteredDataSet(hm);

                    if (dept.contains("-")) {
                        if ("Multiomyx".equalsIgnoreCase(methodologyArr[0]) &&
                                (dsFilterCUtype.size() > 0 || dsFilterUtype.size() > 0) ) {
                            dept = dept.substring(0, (dept.indexOf("-") + 1)) + "MOWetLab";
                        } else {
                            dept = dept.substring(0, (dept.indexOf("-") + 1)) + "AP";
                        }
                    } else
                        throw new SapphireException("Department not found");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

                    PropertyList propTrack = new PropertyList();
                    propTrack.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    propTrack.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleArr[i]);
                    propTrack.setProperty("custodialdepartmentid", dept);
                    propTrack.setProperty("custodialuserid", "");
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, propTrack);
                } catch (SapphireException se) {
                    String error = getTranslationProcessor().translate("Samples not moved back. " + se.getMessage());
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
                if (!"MOQCSample".equalsIgnoreCase(currentmovement)) {
                    if ("Multiomyx".equalsIgnoreCase(methodology)) {
                        String tempSampleArr[] = StringUtil.split(sampleArr[i], ";");
                        if (tempSampleArr == null || tempSampleArr.length == 0)
                            throw new SapphireException("Sampleid could not be blank");
                        if (Util.isNull(fromcurrmovstep) || Util.isNull(currentmovement))
                            throw new SapphireException("Step is not defined.");
                        String sql = Util.parseMessage(ApSql.IHC_GET_BACK_STEP_INFO_BY_MOVMNTSTP, currentmovement, tempSampleArr[0], fromcurrmovstep, tempSampleArr[0], StringUtil.replaceAll(sampleArr[i], ";", "','"));
                        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
                        if (ds != null && ds.size() > 0) {
                            setPendingStep(ds.getColumnValues("u_sampletestcodestpmapid", ";"));

                        }
                    }
                }
            }
        }
    }

    private void validateMOHneSpecimenStatus(String sampleid) throws SapphireException {


        String sql = Util.parseMessage(ApSql.GET_HNEDATAENTRY_VALUES, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsInfo == null)
            throw new SapphireException("Dataset object is obtained as null. Please check the database connection.");

        if (dsInfo.size() == 0)
            throw new SapphireException("Error : Unable to route to Mo-WetLab.\nReason : Multiomyx Specimen H&E Evaluation has not been performed yet.");

        DataSet dsHNENotPerformed = new DataSet();
        DataSet dsQNS = new DataSet();
        DataSet dsHNEPass = new DataSet();
        DataSet dsHNEFail = new DataSet();

        if (dsInfo.size() > 0) {
            String[] sampleArr = StringUtil.split(sampleid, ";");
            for (String str : sampleArr) {
                HashMap hm = new HashMap();
                hm.put("uss", str);

                DataSet dsFilter = dsInfo.getFilteredDataSet(hm);
                if (dsFilter.size() > 0) {
                    for (int i = 0; i < dsFilter.size(); i++) {
                        String qnsValue = dsFilter.getValue(i, "qns", "");
                        if ("Y".equalsIgnoreCase(qnsValue)) { // for QNS
                            dsQNS.copyRow(dsFilter, i, 1);
                            break;
                        } else {
                            // for pass or fail
                            boolean flag = false; // false :HNE is failed... true : HNE passed
                            String[] colList = dsInfo.getColumns();
                            for (String col : colList) {
                                if (!"hne".equalsIgnoreCase(col) && !"uss".equalsIgnoreCase(col)
                                        && !"sampleid".equalsIgnoreCase(col) && !"qns".equalsIgnoreCase(col)) {
                                    String colValue = dsFilter.getValue(i, col);
                                    if (!Util.isNull(colValue)) {
                                        flag = true;
                                        break;
                                    }
                                }
                            }

                            if (flag)
                                dsHNEPass.copyRow(dsFilter, i, 1);
                            else
                                dsHNEFail.copyRow(dsFilter, i, 1);
                        }
                    }

                } else {
                    dsHNENotPerformed.copyRow(dsFilter, -1, 1);
                }
            }

        }
        if (dsHNENotPerformed.size() > 0) {
            throw new SapphireException("Error : Unable to route to Mo-WetLab." +
                    "\nReason : Multiomyx Specimen H&E Evaluation has not been performed for the below specimen(s)-" +
                    "\n" + Util.getUniqueList(dsHNENotPerformed.getColumnValues("uss", ", "), ", ", true));
        } else if (dsQNS.size() > 0) {
            throw new SapphireException("Error : Unable to route to Mo-WetLab." +
                    "\nReason : QNS has been marked for the below Multiomyx Specimen H&E -" +
                    "\n" + Util.getUniqueList(dsQNS.getColumnValues("uss", ", "), ", ", true));
        } else if (dsHNEFail.size() > 0) {
            throw new SapphireException("Error : Unable to route to Mo-WetLab." +
                    "\nReason : Multiomyx Specimen H&E Evaluation has been Failed for the below specimen(s) -" +
                    "\n" + Util.getUniqueList(dsHNEFail.getColumnValues("uss", ", "), ", ", true));
        }

    }

    public void setPendingStep(String sampletestcodestpmapid) throws ActionException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodestpmapid);
        pl.setProperty("status", "Pending");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }
}

