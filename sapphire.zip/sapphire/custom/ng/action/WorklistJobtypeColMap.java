package sapphire.custom.ng.action;

import java.util.HashMap;

import com.labvantage.sapphire.actions.sdi.AddSDI;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.generalsql.GeneralSql;
import sapphire.custom.ng.sql.worklist.WorkListSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class WorklistJobtypeColMap extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String jobtypeid = properties.getProperty("jobtypeid");
        String elearr = properties.getProperty("columnlist");
        String u_wlrowlimit = properties.getProperty("u_wlrowlimit");
        String seq = properties.getProperty("sequence");
        if (Util.isNull(jobtypeid))
            throw new SapphireException("Current job type could not be blank.");
        if (Util.isNull(elearr))
            throw new SapphireException("No column has been selected.");

        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("currentuser", DataSet.STRING);
        dsFinal.addColumn("columnlist", DataSet.STRING);
        dsFinal.addColumn("sequence", DataSet.STRING);
        DataSet dsEdit = new DataSet();
        dsEdit.addColumn("keyid1", DataSet.STRING);
        dsEdit.addColumn("sequence", DataSet.STRING);

        DataSet ds = new DataSet();
        ds.addColumnValues("columnlist", DataSet.STRING, elearr, ";");
        ds.addColumnValues("sequence", DataSet.STRING, seq, ";");


        //String columnList = StringUtil.replaceAll(elearr, ";", "','");
        String rawSql = WorkListSql.JOBTYPE_COLLIST_FRM_USER_COL;
        String sql = Util.parseMessage(rawSql, jobtypeid);
        DataSet dssql = getQueryProcessor().getSqlDataSet(sql);
        if (dssql != null && dssql.size() > 0) {
            HashMap<String, String> hmFilter = new HashMap();
            for (int i = 0; i < ds.size(); i++) {
                String colArr = ds.getValue(i, "columnlist", "");
                hmFilter.clear();
                hmFilter.put("colname", colArr);
                DataSet dsTemp = dssql.getFilteredDataSet(hmFilter);
                if (dsTemp.size() == 0) {
                    int row = dsFinal.addRow();
                    dsFinal.setValue(row, "currentuser", jobtypeid);
                    dsFinal.setValue(row, "columnlist", colArr);
                    dsFinal.setValue(row, "sequence", ds.getValue(i, "sequence"));
                } else {
                    String existngSeq = dsTemp.getValue(0, "usersequence", "");
                    String recentSeq = ds.getValue(i, "sequence", "");
                    int existngnm = Integer.parseInt(existngSeq);
                    int recentnm = Integer.parseInt(recentSeq);
                    if (existngnm != recentnm) {
                        int row = dsEdit.addRow();
                        dsEdit.setValue(row, "keyid1", dsTemp.getValue(0, "u_worklistusrcolmapid", ""));
                        dsEdit.setValue(row, "sequence", recentSeq);

                    }

                }

            }

        } else {
            for (int i = 0; i < ds.size(); i++) {
                int row = dsFinal.addRow();
                dsFinal.setValue(row, "currentuser", jobtypeid);
                dsFinal.setValue(row, "columnlist", ds.getValue(i, "columnlist", ""));
                dsFinal.setValue(row, "sequence", ds.getValue(i, "sequence", ""));
            }

        }


        PropertyList props = new PropertyList();
        if (dsFinal != null && dsFinal.size() > 0) {
            props.setProperty(AddSDI.PROPERTY_SDCID, "WorkListUsrColMap");
            props.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(dsFinal.size()));
            props.setProperty("jobtypeid", dsFinal.getColumnValues("currentuser", ";"));
            props.setProperty("colname", dsFinal.getColumnValues("columnlist", ";"));
            props.setProperty("usersequence", dsFinal.getColumnValues("sequence", ";"));
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to Add WorkListUsrColMap" + ex.getMessage());
            }
        }
        if (dsEdit != null && dsEdit.size() > 0) {
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "WorkListUsrColMap");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsEdit.getColumnValues("keyid1", ";"));
            props.setProperty("usersequence", dsEdit.getColumnValues("sequence", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to Edit WorkListUsrColMap " + ex.getMessage());
            }

        }

        if (!Util.isNull(u_wlrowlimit)) {
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "LV_JobType");
            props.setProperty(EditSDI.PROPERTY_KEYID1, jobtypeid);
            props.setProperty("u_wlrowlimit", u_wlrowlimit);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update User."+ex.getMessage());
            }


        }
        DataSet dsDelete = CheckingDataForDelete(ds, dssql);
        if (dsDelete != null && dsDelete.size() > 0) {
            String keyid1all = dsDelete.getColumnValues("keyid1", ";");
            if(keyid1all.contains(";"))
                keyid1all = StringUtil.replaceAll(keyid1all, ";", "','");
            String datasql = Util.parseMessage(GeneralSql.WORKLISTFILTERMAP_BY_USERCOLMAPID, keyid1all);
            DataSet dsFltrMapData = getQueryProcessor().getSqlDataSet(datasql);
            if(dsFltrMapData != null && dsFltrMapData.size()>0){
            	System.out.println("delete:");
                props.clear();
                props.setProperty(DeleteSDI.PROPERTY_SDCID, "WorkListFiltrMap");
                props.setProperty(DeleteSDI.PROPERTY_KEYID1, dsFltrMapData.getColumnValues("u_worklistfiltrmapid", ";"));
                try {
                    getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("Unable to delete WorkListFiltrMap."+e.getMessage());
                }

            }
            props.clear();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "WorkListUsrColMap");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, dsDelete.getColumnValues("keyid1", ";"));
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException("Unable to delete WorkListUsrColMap."+e.getMessage());
            }

        }

        //throw new SapphireException("Testing.");

    }

    private DataSet CheckingDataForDelete(DataSet ds, DataSet dsSql) throws SapphireException {
        DataSet dsDelete = new DataSet();
        if (ds != null && ds.size() > 0 && dsSql != null && dsSql.size() > 0) {
            dsDelete.addColumn("keyid1", DataSet.STRING);
            HashMap<String, String> hmFilter = new HashMap();
            for (int i = 0; i < dsSql.size(); i++) {
                hmFilter.clear();
                hmFilter.put("columnlist", dsSql.getValue(i, "colname", ""));
                DataSet dsFilter = ds.getFilteredDataSet(hmFilter);
                if (dsFilter.size() == 0) {
                    int row = dsDelete.addRow();
                    dsDelete.setValue(row, "keyid1", dsSql.getValue(i, "u_worklistusrcolmapid", ""));

                }

            }
        }

        return dsDelete;


    }


}

