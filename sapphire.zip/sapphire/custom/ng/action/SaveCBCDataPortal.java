package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDIWorkItem;
import sapphire.action.BaseAction;
import sapphire.action.EnterDataSet;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 7/25/2016.
 */
public class SaveCBCDataPortal extends BaseAction {

    /*
    *   OOB method override to save CBCD data
    * */
    public void processAction(PropertyList properties) throws SapphireException {

        String sdcid = "ReportOption";
        String workitemid = "CBC PL";
        String reportoptionid = properties.getProperty("reportoptionid");
        String paramlistid = properties.getProperty("paramlistid");
        String dataset = properties.getProperty("dataset");
        DataSet dsRegion = null;
        logger.info("GET PORTAL ALL INPUT DATA>>>>>>>>>>>>>>"+properties.toJSONString());

        // check its new region and result created or region is moved and for the same region new result is created
        DataSet dsCBCworkitem = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.SAVECBCDDATAPORTAL_WORKITEM, reportoptionid, workitemid));

        // check if paramlist exist then update result or throw exception.
        if (dsCBCworkitem != null && dsCBCworkitem.getRowCount() > 0) {
            dsRegion = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.SAVECBCDDATAPORTAL_REGION, reportoptionid, paramlistid, dataset));

            editResult(sdcid, reportoptionid, properties, dsRegion);
        } else {
            applyCBCWorkIitem(sdcid, reportoptionid, workitemid);
            dsRegion = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.SAVECBCDDATAPORTAL_REGION_ELSE, reportoptionid, paramlistid, dataset));
            editResult(sdcid, reportoptionid, properties, dsRegion);
        }
        logger.info("GET PORTAL ALL AFTER EXECUTION DATA>>>>>>>>>>>>>>"+properties.toJSONString());

    }

    /*
    *   Apply workitem if its not there
    *   @param  sdcid   SDCID of the itme
    *   @param  keyid1  keyid1 of the sdc
    *   @param  workitemID  work item id of
    * */
    private void applyCBCWorkIitem(String sdcid, String keyid1, String workitemID) throws SapphireException {

        PropertyList props = new PropertyList();
        props.setProperty(AddSDIWorkItem.PROPERTY_SDCID, sdcid);
        props.setProperty(AddSDIWorkItem.PROPERTY_KEYID1, keyid1);
        props.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM, "Y");
        props.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID, workitemID);
        props.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID, "1");
        try {
            getActionProcessor().processAction(AddSDIWorkItem.ID, "1", props);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /*
    *   This method is used to editbresult
    *   @param  sdcid           sdcid of sdc
     *  @param  reportoptionid
    * */
    private void editResult(String sdcid, String reportoptionid, PropertyList properties, DataSet dsRegion) throws ActionException {
        //DataSet dsCopy = dsRegion.copy();
        DataSet dsCopy = new DataSet();
        dsCopy.addColumn("paramid", DataSet.STRING);
        dsCopy.addColumn("paramtype", DataSet.STRING);
        dsCopy.addColumn("replicateid", DataSet.STRING);
        dsCopy.addColumn("entertext", DataSet.STRING);

        String paramName = "";
        PropertyList props = new PropertyList();
        props.setProperty(EnterDataSet.PROPERTY_SDCID, sdcid);
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, reportoptionid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, properties.getProperty("paramlistid"));
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, properties.getProperty("dataset"));

        for (int i = 0; i < dsRegion.getRowCount(); i++) {
            paramName = dsRegion.getString(i, "paramid");
            if (properties.containsKey(paramName.trim())) {
                int j = dsCopy.addRow();
                dsCopy.setString(j, "paramid", dsRegion.getString(i, "paramid"));
                dsCopy.setString(j, "paramtype", dsRegion.getString(i, "paramtype"));
                dsCopy.setString(j, "replicateid", "" + dsRegion.getInt(i, "replicateid"));
                dsCopy.setString(j, "enteredtext", properties.getProperty(paramName.trim()));
            }
        }
        if (dsCopy.getRowCount() > 0) {
            for (int i = 1; i <= dsCopy.getRowCount(); i++) {
                props.setProperty("paramid" + i, dsCopy.getString(i - 1, "paramid"));
                props.setProperty("paramtype" + i, dsCopy.getString(i - 1, "paramtype"));
                props.setProperty("replicateid" + i, dsCopy.getString(i - 1, "replicateid"));
                props.setProperty("enteredtext" + i, dsCopy.getString(i - 1, "enteredtext"));
            }
            props.setProperty("params", "" + dsCopy.getRowCount());
            props.setProperty("matchusersequence", "Y");

            getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, props);
        } else {
            throw new ActionException("Analyte's not found, one of these analyte's must be prsent " + dsRegion.getColumnValues("paramid", ";"));
        }

    }

}
