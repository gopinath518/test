package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.HashMap;

public class ValidateEntityRelation extends BaseAction {

    DataSet extractionreagentprops = null;

    public void processAction(PropertyList properties) throws SapphireException {
        String inputtramstop = properties.getProperty("inputtramstop");
        String inputdetailele = properties.getProperty("inputdetailele");
        String inputvalue = properties.getProperty("inputvalue");
        String inputtestcodevalidation = properties.getProperty("inputtestcodevalidation");

        String currentdept = connectionInfo.getDefaultDepartment();
        String sql = MolecularSql.GET_SITE_BY_DEPARTMENTID;
        sql = Util.parseMessage(sql, currentdept);
        DataSet dsSite = getQueryProcessor().getSqlDataSet(sql);
        String usersite = dsSite.getValue(0, "u_site", "");
        if ("Reagent".equalsIgnoreCase(inputdetailele)) {
            if ("Extraction".equalsIgnoreCase(inputtramstop)) {
                getExtractionEntityMapPolicy();
                String batchid = properties.getProperty("batchid");
                String sqlExt = Util.parseMessage(CommonSql.GET_EXTRACTIONTYPE_BY_BATCHID, batchid);
                DataSet dsExtrc = getQueryProcessor().getSqlDataSet(sqlExt);
                String extrcttype = "";
                if (dsExtrc.size() > 0) {
                    extrcttype = dsExtrc.getValue(0, "extractiontype", "");
                    HashMap hm = new HashMap();
                    hm.put("extractiontype", extrcttype);
                    DataSet dsExtracFilter = extractionreagentprops.getFilteredDataSet(hm);
                    if (dsExtracFilter.size() > 0) {
                        //String reagenttype = StringUtil.replaceAll(dsExtracFilter.getColumnValues("reagenttype", ";"), ";", "','");
                        sql = MolecularSql.IS_VALID_REAGENT;
                        sql = Util.parseMessage(sql, inputvalue);
                        DataSet dsIsReagents = getQueryProcessor().getSqlDataSet(sql);
                        if (dsIsReagents == null || dsIsReagents.size() == 0) {
                            throw new SapphireException("Please scan valid reagent.");
                        }
                        sql = CommonSql.EXTRACTION_REAGENT_ENTITY_MAP;
                        //sql = Util.parseMessage(sql, inputvalue, inputtramstop, inputdetailele, usersite, reagenttype);
                        sql = Util.parseMessage(sql, inputvalue, inputtramstop, inputdetailele, usersite);
                        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
                        if (dsReagents == null || dsReagents.size() == 0) {
                            throw new SapphireException("This Extraction Reagent does not exist into the system.");
                        }
                        hm.clear();
                        hm.put("tramstop", "All");
                        DataSet dsBulkReagents = dsReagents.getFilteredDataSet(hm);
                        hm.clear();
                        hm.put("tramstop", "Universal");
                        DataSet dsUniversalReagents = dsReagents.getFilteredDataSet(hm);
                        if (dsBulkReagents.size() > 0 || dsUniversalReagents.size() > 0) {
                            return;
                        } else {

                            for (int i = 0; i < dsReagents.size(); i++) {
                                hm.clear();
                                hm.put("reagenttype", dsReagents.getValue(i, "entityclass", ""));
                                DataSet dsExtracReagents = dsExtracFilter.getFilteredDataSet(hm);
                                if (dsExtracReagents.size() == 0) {
                                    throw new SapphireException("This Extraction Reagent does not match into the system.");
                                }
                            }


                        }
                    }
                }
            } else {
                validateReagent(inputvalue, usersite, inputtramstop, inputdetailele);
            }
        } else if ("Instrument".equalsIgnoreCase(inputdetailele)) {
            validateInstrument(inputvalue, usersite, inputtramstop, inputdetailele);
        }
    }

    private void validateReagent(String inputscanval, String usersite, String inputtramstop, String inputdetailele) throws SapphireException {
        String sql = MolecularSql.IS_VALID_REAGENT;
        sql = Util.parseMessage(sql, inputscanval);
        DataSet dsIsReagents = getQueryProcessor().getSqlDataSet(sql);
        if (dsIsReagents == null || dsIsReagents.size() == 0) {
            throw new SapphireException("Please scan valid reagent.");
        }
        sql = MolecularSql.REAGENT_ENTITY_MAP;
        sql = Util.parseMessage(sql, inputscanval, inputtramstop, inputdetailele, usersite);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        if (dsReagents == null || dsReagents.size() == 0) {
            throw new SapphireException("This Reagent does not match into the system.");
        }
    }

    private void validateInstrument(String inputscanval, String usersite, String inputtramstop, String inputdetailele) throws SapphireException {
        String sql = MolecularSql.IS_VALID_INSTRUMENT;
        sql = Util.parseMessage(sql, inputscanval);
        DataSet dsIsInstrument = getQueryProcessor().getSqlDataSet(sql);
        if (dsIsInstrument == null || dsIsInstrument.size() == 0) {
            throw new SapphireException("Please provide an instrument value.");
        }
        sql = MolecularSql.INSTRUMENT_ENTITY_MAP;
        sql = Util.parseMessage(sql, inputscanval, inputtramstop, inputdetailele, usersite);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        if (dsReagents == null || dsReagents.size() == 0) {
            throw new SapphireException("This Instrument does not match into the system.");
        }
    }

    private void getExtractionEntityMapPolicy() throws SapphireException {
        if (extractionreagentprops == null) {
            extractionreagentprops = new DataSet();
            extractionreagentprops.addColumn("extractiontype", DataSet.STRING);
            extractionreagentprops.addColumn("reagenttype", DataSet.STRING);
            PropertyList plExtractionPolicy = getConfigurationProcessor().getPolicy("ReagentExtractionPolicy", "ExtractionReagents");
            if (plExtractionPolicy == null)
                throw new SapphireException("Homogeneous LOS policy is not define in System Admin-> Policy.");
            PropertyListCollection plclosmap = plExtractionPolicy.getCollection("extractiontypelist");
            for (int i = 0; i < plclosmap.size(); i++) {
                String extractionetype = plclosmap.getPropertyList(i).getProperty("extractionetype");
                PropertyListCollection plReagentTypeList = plclosmap.getPropertyList(i).getCollection("reagenttypelist");
                for (int j = 0; j < plReagentTypeList.size(); j++) {
                    String reagenttype = plReagentTypeList.getPropertyList(j).getProperty("reagenttype");
                    int rowID = extractionreagentprops.addRow();
                    extractionreagentprops.setValue(rowID, "extractiontype", extractionetype);
                    extractionreagentprops.setValue(rowID, "reagenttype", reagenttype);
                    //extractionreagentprops.setProperty(reagenttype, extractionetype);
                }
            }
        }
    }
}
