package sapphire.custom.ng.action.accession;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

public class CreateAccession extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String accessionlab = properties.getProperty("accessionlab");
        String pagename = properties.getProperty("pagename", "");
        String typeaction = properties.getProperty("typeaction", "");

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "Accession");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props.setProperty("accessionlab", accessionlab);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to create accession. " + ex.getMessage());
        }
        String keyid1 = props.getProperty("newkeyid1");
        props.clear();
        props.setProperty("keyid1", keyid1);
        props.setProperty("pagename", pagename);
        props.setProperty("typeaction", typeaction);
        try {
            getActionProcessor().processAction("CreateAccessionRSet", "1", props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to create lock. " + ex.getMessage());
        }
        String islocked = props.getProperty("islocked");

        properties.setProperty("accessionid", keyid1);
        properties.setProperty("islocked", islocked);
    }
}
