package sapphire.custom.ng.action.accession;

import java.util.ArrayList;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.action.accession.MolAutoCreateBatchSample;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

public class AssignTestcodeWrap extends BaseAction {
    public static final String INPUT_PROPERTY_BYPASS_INITIAL_REPEAT = "initialrepeatbypass";
    public static final String INPUT_PROPERTY_SAMPLE_ID = "s_sampleid";
    public static final String INPUT_PROPERTY_LV_TEST_CODE = "lvtestcode";

    public void processAction(PropertyList properties) throws SapphireException {
        String isInitialRepeatBypas = properties.getProperty(INPUT_PROPERTY_BYPASS_INITIAL_REPEAT, "N");
        String sampleids = properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");
        String lvtestcodes = properties.getProperty(INPUT_PROPERTY_LV_TEST_CODE, "");
        String sampleidsarr[] = StringUtil.split(properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, ""), ";");
        String lvtestcodesarr[] = StringUtil.split(properties.getProperty(INPUT_PROPERTY_LV_TEST_CODE, ""), ";");
        String sql = Util.parseMessage(ApSql.GET_SAMPLES_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.size() == 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty("s_sampleid", sampleids);
            prop.setProperty("lvtestcode", lvtestcodes);
            prop.setProperty("initialrepeatbypass", "Y");
            try {
                getActionProcessor().processAction("AssignTestCode", "1", prop);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed.AssignTestCode ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        } else {
            DataSet dsSamplefinal = new DataSet();
            dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
            dsSamplefinal.addColumn("isslide", DataSet.STRING);// transport
            String specimenArray[] = StringUtil.split(sampleids, ";");
            for (int i = 0; i < specimenArray.length; i++) {
                HashMap<String, String> hm = new HashMap<String, String>();
                hm.put("s_sampleid", sampleidsarr[i]);
                DataSet dsFilter = ds.getFilteredDataSet(hm);
                if (dsFilter.size() == 0) {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", sampleidsarr[i]);
                    dsSamplefinal.setValue(rowID, "isslide", "N");
                } else {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", sampleidsarr[i]);
                    dsSamplefinal.setValue(rowID, "isslide", "Y");
                }
            }
        }
    }
}
