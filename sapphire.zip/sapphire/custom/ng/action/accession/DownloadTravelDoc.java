package sapphire.custom.ng.action.accession;

import com.labvantage.sapphire.actions.report.GenerateReport;
import sapphire.SapphireException;
import sapphire.action.AddSDIAttachment;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DownloadTravelDoc extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("DownloadTravelDoc>>", "Action Started." + properties.toString());
        String keyid1 = properties.getProperty("accessionid", "");
        if (Util.isNull(keyid1))
            throw new SapphireException("AccessionID can't be blank.");
        String filelocation = getFileLocation();
        logger.info("DownloadTravelDoc>>", "Action Started.filelocation" + filelocation);
        String timestamp = new SimpleDateFormat("MMddyyyyhmmssa").format(new Date());
        if (filelocation.endsWith("/"))
            filelocation = filelocation;
        else
            filelocation = filelocation + File.separator;
        String filenameformat = filelocation + keyid1 + "_TravelDoc_" + timestamp + ".pdf";
        logger.info("DownloadTravelDoc>>", "Action Started.filenameformat" + filenameformat);
        logger.info("DownloadTravelDOc>>>", "Calling Report for generate TravelDoc");
        PropertyList prop = new PropertyList();
        prop.clear();
        prop.setProperty("reportid", "TravelDocReport");
        prop.setProperty("reportversionid", "1");
        prop.setProperty("accessionid", keyid1);
        prop.setProperty("destination", "file");
        prop.setProperty("debuglog", "Y");
        prop.setProperty("filename", filenameformat);
        prop.setProperty("filetype", "PDF");
        try {
            getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);//TODO OPEN AS REPORT WILL GENERATE FOR MSI
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed to download TravelDoc." + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        addAttachment(keyid1, filenameformat);
        String sql = Util.parseMessage(AccessionPageSql.GET_ATTACHMENT_BY_ACCESSION, keyid1);
        DataSet dsAttachmnt = getQueryProcessor().getSqlDataSet(sql);
        int attachnum = Integer.parseInt(dsAttachmnt.getValue(0, "attachmentnum", "0"));
        String url = "rc?command=ViewAttachment&sdcid=Dummy&keyid1=" + keyid1 + "&keyid2=TravelDoc&attachmentnum=" + attachnum + "&download=Y";
        properties.setProperty("url", url);
        logger.info("TravelDoc>>>", "Delete from the location.");
        prop.clear();
        prop.setProperty("id", keyid1);
        prop.setProperty("location", filenameformat);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "InventoryReportingTempDeleteAction");
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
        prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
        prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n+1");
        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";
        String sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        //CHECK FOLDER
        //fileLocation = "C:\\Temp";
        fileLocation = Util.createFolderForMolecular(baseloc, "TravelDoc");
        return fileLocation;
    }

    private void addAttachment(String keyid1, String filenameformat) throws SapphireException {
        PropertyList propSamp = new PropertyList();
        propSamp.clear();
        propSamp.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Dummy");
        propSamp.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1);
        propSamp.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "TravelDoc");
        propSamp.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        propSamp.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenameformat);
        propSamp.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filenameformat).getName());
        propSamp.setProperty("ATTACHMENTCLASS", "SOP");
        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, propSamp);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. to add atachment." + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }
}
