package sapphire.custom.ng.action.accession;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class MolAutoCreateBatchSample extends BaseAction {

    public static final String ID = "MolAutoCreateBatchSample";
    public static final String VERSIONID = "1";

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleids");
        String lvtestcodeid = properties.getProperty("lvtestcodeid");
        String isSpecialBatchFlag = properties.getProperty("ismanualbatch", "N");
        if ("Y".equalsIgnoreCase(isSpecialBatchFlag)) {
            String sql = Util.parseMessage(MolecularSql.GET_MOL_SAMPLES, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsMolSamples = getQueryProcessor().getSqlDataSet(sql);
            if (dsMolSamples == null || dsMolSamples.size() == 0) {
                throw new SapphireException("Please select Molecular sample(s) only.");
            }
            sampleids = dsMolSamples.getColumnValues("s_sampleid", ";");
            lvtestcodeid = dsMolSamples.getColumnValues("lvtestcodeid", ";");
        }

        //STARTED BATCH CREATION EXECUTION PROCESS
        String sql = Util.parseMessage(MolecularSql.GET_SPONSOR_ABBRE_BY_SAMPLEID,
                StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsSampleinfo = getQueryProcessor().getSqlDataSet(sql);
        String sponsorabbr = Util.getUniqueList(dsSampleinfo.getColumnValues("molbatchabbreviation", ";"), ";", true).trim();
        if (Util.isNull(sponsorabbr)) {
            throw new SapphireException("<b>Unable to proceed as this sponsor does not have abbreviation mentioned into master data at sponsor label.</b>");
        }
        String molbatchid = Util.getUniqueList(dsSampleinfo.getColumnValues("molbatchid", ";"), ";", true);
        String latestseq = "";
        DataSet dsBatchPolicy = getPolicy();
        if (Util.isNull(molbatchid)) {
            sql = Util.parseMessage(MolecularSql.GET_MOL_BATCH_DETAILS_BY_BATCHID, molbatchid);
            DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sql);
            molbatchid = dsBatchDetails.getValue(0, "batchname", "");
            latestseq = getBatchSequence(molbatchid, dsBatchPolicy, sponsorabbr) + "-" + sponsorabbr;
            PropertyList props = new PropertyList();
            props.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDI.PROPERTY_COPIES, "1");
            props.setProperty("batchname", latestseq);
            props.setProperty("batchtype", "Accession");
            props.setProperty("origin", "Accession");
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Can't create batch.");
            }
            String batchid = props.getProperty("newkeyid1");
            props.clear();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
            props.setProperty("sampleid", dsSampleinfo.getColumnValues("s_sampleid", ";"));
            props.setProperty("testcodeid", lvtestcodeid);
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

            try {
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not edit batch detail" + se.getMessage());
            }

            String accessionid = Util.getUniqueList(dsSampleinfo.getColumnValues("u_accessionid", ";"), ";", true);
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            props.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            props.setProperty("molbatchid", batchid);
            props.setProperty("molbatchflag", "Y");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Batch is not updated in accession");
            }
            molbatchid = Util.getUniqueList(dsSampleinfo.getColumnValues("molbatchid", ";"), ";", true);
            String sampleseq = getBatchSamplesSequence(dsBatchPolicy, latestseq, sampleids, batchid, lvtestcodeid, isSpecialBatchFlag);
        } else {
            sql = Util.parseMessage(MolecularSql.GET_MOL_BATCH_DETAILS_BY_BATCHID, molbatchid);
            DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sql);
            String batchname = dsBatchDetails.getValue(0, "batchname", "");
            String sampleseq = batchname + "-" + getBatchSamplesSequence(dsBatchPolicy, batchname, sampleids, molbatchid, lvtestcodeid, isSpecialBatchFlag);
            //TODO MULTIPLE ACCESSION WILL OPEN
            /*sql = Util.parseMessage(MolecularSql.GET_SPONSOR_ABBRE_BY_SAMPLEID_BATCHID, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsElutionOnly = getQueryProcessor().getSqlDataSet(sql);
            if (dsElutionOnly.size() == 0) {
                sql = Util.parseMessage(MolecularSql.GET_MOL_BATCH_DETAILS_BY_BATCHID, molbatchid);
                DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sql);
                String batchname = dsBatchDetails.getValue(0, "batchname", "");
                String sampleseq = batchname + "-"
                        + getBatchSamplesSequence(dsBatchPolicy, batchname, sampleids, molbatchid, lvtestcodeid, isSpecialBatchFlag);
            }
            if (dsElutionOnly.size() > 0) {
                copyBatchSpecimenIDFrmParentElutionOnly(dsElutionOnly.getColumnValues("s_sampleid",";"),
                        dsElutionOnly, dsElutionOnly.getColumnValues("lvtestcodeid",";"),
                        dsElutionOnly.getColumnValues("molbatchid",";"));
                return;
            }*/
        }
        //throw new SapphireException("testA");
    }

    private String getBatchSequence(String molbatchid, DataSet dsBatchPolicy, String sponsorabbr) throws SapphireException {
        String LATESTBATCHSEQ = "";
        LATESTBATCHSEQ = dsBatchPolicy.getValue(0, "batchseq", "");
        if (Util.isNull(molbatchid)) {
            String CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            String YY = CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length());
            String SEQ_INITIALS = "N" + YY + "%";
            //String SEQ_INITIALS = "N" + YY + "%-" + sponsorabbr + "%";//TODO CHANGES AS BATCH ID WILL CREATE UNIQUELY FEEDBACK BY HO USER(03/01/2018)
            String sql = Util.parseMessage(MolecularSql.GET_MAX_SEQ, SEQ_INITIALS);
            DataSet dsMaxSeq = getQueryProcessor().getSqlDataSet(sql);
            String maxmolbatchid = dsMaxSeq.getValue(0, "molbatchid", "");
            if (!Util.isNull(maxmolbatchid)) {
                String maxseq = StringUtil.split(dsMaxSeq.getValue(0, "molbatchid", ""), "-")[0];
                LATESTBATCHSEQ = StringUtil.replaceAll(maxseq, "N" + YY, "");
                int seq = Integer.parseInt(LATESTBATCHSEQ) + 1;
                LATESTBATCHSEQ = "N" + YY + "" + String.format("%0" + LATESTBATCHSEQ.length() + "d", seq);
            } else {
                int seq = Integer.parseInt(LATESTBATCHSEQ) + 1;
                LATESTBATCHSEQ = "N" + YY + "" + String.format("%0" + LATESTBATCHSEQ.length() + "d", seq);
            }
        }
        return LATESTBATCHSEQ;
    }

    private String getBatchSamplesSequence(DataSet dsBatchPolicy, String batchname, String sampleids, String molbatchid, String lvtestcodeid, String isSpecialBatchFlag)
            throws SapphireException {
        DataSet dsError = new DataSet();
        dsError.addColumn("sampleid", DataSet.STRING);
        dsError.addColumn("clientspecimenid", DataSet.STRING);
        String LATESTBATCHSEQ = "";
        LATESTBATCHSEQ = dsBatchPolicy.getValue(0, "sampleseq");
        if (!Util.isNull(batchname)) {
            String SEQ_INITIALS = batchname + "-%";
            String sql = Util.parseMessage(MolecularSql.GET_MAX_SAMPLE_SEQ, SEQ_INITIALS);
            DataSet dsMaxSeq = getQueryProcessor().getSqlDataSet(sql);
            String sampleseq = dsMaxSeq.getValue(0, "u_molbatchspecimenid", "");
            if (!Util.isNull(sampleseq)) {
                String maxseq = StringUtil.split(dsMaxSeq.getValue(0, "u_molbatchspecimenid", ""), "-")[2];
                LATESTBATCHSEQ = StringUtil.replaceAll(maxseq, batchname + "-", "");
                int seq = Integer.parseInt(LATESTBATCHSEQ) + 1;
                LATESTBATCHSEQ = String.format("%0" + LATESTBATCHSEQ.length() + "d", seq);
            } else {
                int seq = Integer.parseInt(LATESTBATCHSEQ) + 1;
                LATESTBATCHSEQ = String.format("%0" + LATESTBATCHSEQ.length() + "d", seq);
            }
            sql = Util.parseMessage(MolecularSql.GET_SPONSOR_ABBRE_BY_SAMPLEID,
                    StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            HashMap hmUSS = new HashMap();
            //TODO MULTIPLE SLIDES CAN BE ASSIGNED
            for (int i = 0; i < dsSampleInfo.size(); i++) {
                String sampleid = dsSampleInfo.getValue(i, "s_sampleid", "");
                String u_type = dsSampleInfo.getValue(i, "u_type", "");
                if ("H".equalsIgnoreCase(u_type) || "U".equalsIgnoreCase(u_type))
                    copyBatchSpecimenIDFromParent(sampleid, lvtestcodeid, molbatchid);
            }
            /*hmUSS.clear();
            hmUSS.put("u_type", "U");
            DataSet dsFilterUSS = dsSampleInfo.getFilteredDataSet(hmUSS);
            if (dsFilterUSS != null && dsFilterUSS.size() > 0) {
                String usslides = dsFilterUSS.getColumnValues("s_sampleid", ";");
                copyBatchSpecimenIDFrmParent(usslides, dsFilterUSS, lvtestcodeid, molbatchid);
                return "";
            }
            hmUSS.clear();
            hmUSS.put("u_type", "H");
            DataSet dsFilterH = dsSampleInfo.getFilteredDataSet(hmUSS);
            if (dsFilterH != null && dsFilterH.size() > 0) {
                String usslides = dsFilterH.getColumnValues("s_sampleid", ";");
                copyBatchSpecimenIDFrmParent(usslides, dsFilterH, lvtestcodeid, molbatchid);
                return "";
            }*/
            hmUSS.clear();
            hmUSS.put("specimentype", "Extraction Tube");
            DataSet dsFilterExtractionTube = dsSampleInfo.getFilteredDataSet(hmUSS);
            if (dsFilterExtractionTube != null && dsFilterExtractionTube.size() > 0) {
                String extractiontubes = dsFilterExtractionTube.getColumnValues("s_sampleid", ";");
                copyBatchSpecimenIDFrmParent(extractiontubes, dsFilterExtractionTube, lvtestcodeid, molbatchid);
                return "";
            }
            hmUSS.clear();
            hmUSS.put("u_type", null);
            hmUSS.put("specimentype", "Ellution Tube");
            DataSet dsFilterEllutionTube = dsSampleInfo.getFilteredDataSet(hmUSS);
            if (dsFilterEllutionTube != null && dsFilterEllutionTube.size() > 0) {
                String elutiontube = dsFilterEllutionTube.getColumnValues("s_sampleid", ";");
                copyBatchSpecimenIDFrmParent(elutiontube, dsFilterEllutionTube, lvtestcodeid, molbatchid);
                return "";
            }

            DataSet dsFinal = new DataSet();
            dsFinal.addColumn("sampleid", DataSet.STRING);
            dsFinal.addColumn("batchspecimenid", DataSet.STRING);
            for (int i = 0; i < dsSampleInfo.size(); i++) {
                String clientspecid = dsSampleInfo.getValue(i, "u_clientspecimenid", "");
                String u_class = dsSampleInfo.getValue(i, "u_class", "");
                if (Util.isNull(clientspecid) && !"Y".equalsIgnoreCase(isSpecialBatchFlag) && !"Fluid".equalsIgnoreCase(u_class)) {
                    int rowIdd = dsError.addRow();
                    dsError.setValue(rowIdd, "sampleid", dsSampleInfo.getValue(i, "s_sampleid", ""));
                    dsError.setValue(rowIdd, "clientspecimenid", dsSampleInfo.getValue(i, "u_clientspecimenid", ""));
                }

            }
            if (dsError != null && dsError.size() > 0) {
                String errCodes = "<table border=1 style='border-collapse: collapse;border: 1px solid #000;background:#E0F8F7;color:#000;'><tr>"
                        + "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>SPECIMEN ID</b></th>"
                        + "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>CLIENT SPECIMEN ID</b></th>"
                        + "</tr>";
                for (int i = 0; i < dsError.size(); i++) {
                    errCodes += "<tr><td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>"
                            + dsError.getValue(i, "sampleid", "") + "</td>";
                    errCodes += "<td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>"
                            + dsError.getValue(i, "clientspecimenid", "N/A") + "</td></tr>";
                }
                errCodes += "</table>";
                throw new SapphireException("Please add client specimen id(s).\n" + errCodes);
            }
            //VALIDATE SPECIMEN CLASS
            String sqlClass = Util.parseMessage(MolecularSql.GET_SAMPLE_CLASS_BY_SAMPLEID, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsSampleClass = getQueryProcessor().getSqlDataSet(sqlClass);
            if (dsSampleClass != null && dsSampleClass.size() > 0)
                molBatchSpecimenForSolid(dsSampleClass, batchname, dsBatchPolicy, LATESTBATCHSEQ);
            /*HashMap hmclass = new HashMap();
            hmclass.clear();
            hmclass.put("u_class", "Fluid");
            DataSet dsFluid = dsSampleClass.getFilteredDataSet(hmclass);
            if (dsFluid.size() > 0) {
                molBatchSpecimenForFluid(dsFluid, batchname, dsBatchPolicy, LATESTBATCHSEQ);
            }

            hmclass.clear();
            hmclass.put("u_class", "Solid");
            DataSet dsSolidFilter = dsSampleClass.getFilteredDataSet(hmclass);

            //ALL SAMPLES
            if (dsSolidFilter.size() > 0) {
                molBatchSpecimenForSolid(dsSolidFilter, batchname, dsBatchPolicy, LATESTBATCHSEQ);
            }*/

            sql = Util.parseMessage(MolecularSql.GET_NGBATCH_SAMPLE, molbatchid);
            DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            for (int i = 0; i < dsSampleInfo.size(); i++) {
                hm.clear();
                hm.put("sampleid", dsSampleInfo.getValue(i, "s_sampleid", ""));
                DataSet dsFilter = dsBatchSample.getFilteredDataSet(hm);
                if (dsFilter.size() == 0) {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, "sampleid", dsSampleInfo.getValue(i, "s_sampleid", ""));

                }
            }
            if (dsFinal != null && dsFinal.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                props.setProperty(AddSDIDetail.PROPERTY_KEYID1, molbatchid);
                props.setProperty("sampleid", dsFinal.getColumnValues("sampleid", ";"));
                //props.setProperty("testcodeid", lvtestcodeid);
                props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

                try {
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                } catch (SapphireException se) {
                    throw new SapphireException("Can not edit batch detail");
                }
            }

        }
        return LATESTBATCHSEQ;
    }

    private String getLatestBatchSampleSeq(DataSet dsBatchPolicy, String batchname) throws SapphireException {
        String latestbatchsampleseq = "";
        String actualseq = dsBatchPolicy.getValue(0, "sampleseq");
        String SEQ_INITIALS = batchname + "-%";
        String sql = Util.parseMessage(MolecularSql.GET_MAX_SAMPLE_SEQ, SEQ_INITIALS);
        DataSet dsMaxSeq = getQueryProcessor().getSqlDataSet(sql);
        String sampleseq = dsMaxSeq.getValue(0, "u_molbatchspecimenid", "");
        if (Util.isNull(sampleseq)) {
            return "";
        }
        String maxseq = StringUtil.split(sampleseq, "-")[2];
        latestbatchsampleseq = StringUtil.replaceAll(maxseq, batchname + "-", "");
        int seq = Integer.parseInt(latestbatchsampleseq) + 1;
        latestbatchsampleseq = String.format("%0" + actualseq.length() + "d", seq);
        return latestbatchsampleseq;
    }

    private DataSet getPolicy() throws SapphireException {
        DataSet dsAccessionBatch = new DataSet();
        dsAccessionBatch.addColumn("batchseq", DataSet.STRING);
        dsAccessionBatch.addColumn("sampleseq", DataSet.STRING);

        PropertyList plExtractionPolicy = getConfigurationProcessor().getPolicy("AccessionBatchPolicy", "MolAccession");
        if (plExtractionPolicy == null)
            throw new SapphireException("Accession Batch policy is not define in System Admin-> Policy.");
        PropertyListCollection plclosmap = plExtractionPolicy.getCollection("accessionpolicy");
        if (plclosmap != null) {
            String sampleseq = plclosmap.getPropertyList(0).getProperty("sampleseq");
            String batchseq = plclosmap.getPropertyList(0).getProperty("batchseq");
            int rowID = dsAccessionBatch.addRow();
            dsAccessionBatch.setValue(rowID, "sampleseq", sampleseq);
            dsAccessionBatch.setValue(rowID, "batchseq", batchseq);
        }

        return dsAccessionBatch;
    }

    private void copyBatchSpecimenIDFrmParent(String childsampleids, DataSet dsFilterChilds, String lvtestcodeids, String molbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ROOT_SAMPLE_BY_CHILDID, StringUtil.replaceAll(childsampleids, ";", "','"));
        DataSet dsSlidesUss = getQueryProcessor().getSqlDataSet(sql);
        String batchspecid = Util.getUniqueList(dsSlidesUss.getColumnValues("u_molbatchspecimenid", ";"), ";", true);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFilterChilds.getColumnValues("s_sampleid", ";"));
        prop.setProperty("u_molbatchspecimenid", batchspecid);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
            throw new SapphireException("Specimen can't update.");
        }
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, molbatchid);
        props.setProperty("sampleid", dsFilterChilds.getColumnValues("s_sampleid", ";"));
        props.setProperty("testcodeid", lvtestcodeids);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail");
        }
    }

    private void copyBatchSpecimenIDFromParent(String childsampleids, String lvtestcodeids, String molbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ROOT_SAMPLE_BY_CHILDID, StringUtil.replaceAll(childsampleids, ";", "','"));
        DataSet dsSlidesUss = getQueryProcessor().getSqlDataSet(sql);
        String batchspecid = Util.getUniqueList(dsSlidesUss.getColumnValues("u_molbatchspecimenid", ";"), ";", true);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, childsampleids);
        prop.setProperty("u_molbatchspecimenid", batchspecid);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
            throw new SapphireException("Specimen can't update.");
        }
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, molbatchid);
        props.setProperty("sampleid", childsampleids);
        props.setProperty("testcodeid", lvtestcodeids);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail");
        }
    }

    private void copyBatchSpecimenIDFrmParentElutionOnly(String childsampleids, DataSet dsFilterChilds, String lvtestcodeids, String molbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ROOT_SAMPLE_BY_CHILDID, StringUtil.replaceAll(childsampleids, ";", "','"));
        DataSet dsSlidesUss = getQueryProcessor().getSqlDataSet(sql);
        String batchspecid = Util.getUniqueList(dsSlidesUss.getColumnValues("u_molbatchspecimenid", ";"), ";", true);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFilterChilds.getColumnValues("s_sampleid", ";"));
        prop.setProperty("u_molbatchspecimenid", batchspecid);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
            throw new SapphireException("Specimen can't update.");
        }
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, molbatchid);
        props.setProperty("sampleid", dsFilterChilds.getColumnValues("s_sampleid", ";"));
        props.setProperty("testcodeid", lvtestcodeids);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail");
        }
    }

    private void molBatchSpecimenForSolid(DataSet dsSolidFilter, String batchname, DataSet dsBatchPolicy, String LATESTBATCHSEQ) throws SapphireException {
        DataSet dsSolidSample = new DataSet();
        dsSolidSample.addColumn("s_sampleid", DataSet.STRING);
        dsSolidSample.addColumn("molspecid", DataSet.STRING);
        dsSolidSample.addColumn("molbatchname", DataSet.STRING);
        dsSolidSample.addColumn("u_accessionid", DataSet.STRING);
        dsSolidSample.addColumn("u_clientspecimenid", DataSet.STRING);
        dsSolidSample.addColumn("collectiondt", DataSet.STRING);
        dsSolidSample.addColumn("isnewbatchspecid", DataSet.STRING);

        String sampleids = dsSolidFilter.getColumnValues("s_sampleid", ";");
        String sql = Util.parseMessage(MolecularSql.GET_SPONSOR_ABBRE_BY_SAMPLEID,
                StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        dsSampleInfo.sort("u_accessionid,u_clientspecimenid,collectiondt");
        ArrayList arrayCombination = dsSampleInfo.getGroupedDataSets("u_accessionid,u_clientspecimenid,collectiondt");
        for (int j = 0; j < arrayCombination.size(); j++) {
            DataSet dsEach = (DataSet) arrayCombination.get(j);
            String u_accessionid = Util.getUniqueList(dsEach.getColumnValues("u_accessionid", ";"), ";", true);
            String u_clientspecimenid = Util.getUniqueList(dsEach.getColumnValues("u_clientspecimenid", ";"), ";", true);
            String collectiondt = Util.getUniqueList(dsEach.getColumnValues("collectiondt", ";"), ";", true);

            for (int i = 0; i < dsEach.size(); i++) {
                if (i == 0) {
                    int rowID = dsSolidSample.addRow();
                    dsSolidSample.setValue(rowID, "s_sampleid", dsEach.getValue(i, "s_sampleid", ""));
                    dsSolidSample.setValue(rowID, "molbatchname", batchname);
                    dsSolidSample.setValue(rowID, "isnewbatchspecid", "Y");
                    dsSolidSample.setValue(rowID, "collectiondt", collectiondt);
                    dsSolidSample.setValue(rowID, "u_clientspecimenid", u_clientspecimenid);
                    dsSolidSample.setValue(rowID, "u_accessionid", u_accessionid);
                } else {
                    int rowID = dsSolidSample.addRow();
                    dsSolidSample.setValue(rowID, "s_sampleid", dsEach.getValue(i, "s_sampleid", ""));
                    dsSolidSample.setValue(rowID, "molbatchname", batchname);
                    dsSolidSample.setValue(rowID, "isnewbatchspecid", "N");
                    dsSolidSample.setValue(rowID, "collectiondt", collectiondt);
                    dsSolidSample.setValue(rowID, "u_clientspecimenid", u_clientspecimenid);
                    dsSolidSample.setValue(rowID, "u_accessionid", u_accessionid);
                }
            }
        }
        if (dsSolidSample.size() > 0) {
            dsSolidSample.sort("s_sampleid");
            ArrayList sortSampleArry = dsSolidSample.getGroupedDataSets("s_sampleid");
            for (int j = 0; j < sortSampleArry.size(); j++) {
                DataSet dsEach = (DataSet) sortSampleArry.get(j);
                String u_accessionid = Util.getUniqueList(dsEach.getColumnValues("u_accessionid", ";"), ";", true);
                String u_clientspecimenid = Util.getUniqueList(dsEach.getColumnValues("u_clientspecimenid", ";"), ";", true);
                String collectiondt = Util.getUniqueList(dsEach.getColumnValues("collectiondt", ";"), ";", true);
                //CONVERT MM/DD/YYYY HH:MM AM to MM/DD/YYYY
                if (!Util.isNull(collectiondt)) {
                    try {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy HH:mm a");
                        Date varDate = dateFormat.parse(collectiondt);
                        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                        collectiondt = dateFormat.format(varDate);
                    } catch (Exception ex) {
                        logger.info("Unable to parse collection date.");
                    }
                }
                sql = Util.parseMessage(MolecularSql.GET_MOL_BATCH_SPEC_ID_BY_SAMECOMBINATION, u_accessionid + "#" + u_clientspecimenid + "#" + collectiondt);
                DataSet dsBatchSpecIds = getQueryProcessor().getSqlDataSet(sql);
                String u_molbatchspecimenid = dsBatchSpecIds.getValue(0, "u_molbatchspecimenid", "");
                String latestsamplseq = "";
                String getlatestsampleseq = getLatestBatchSampleSeq(dsBatchPolicy, batchname);
                if (!Util.isNull(u_molbatchspecimenid)) {
                    latestsamplseq = u_molbatchspecimenid;
                } else if (Util.isNull(getlatestsampleseq)) {
                    latestsamplseq = batchname + "-" + LATESTBATCHSEQ;
                } else {
                    latestsamplseq = batchname + "-" + getlatestsampleseq;
                }
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsEach.getColumnValues("s_sampleid", ";"));
                //prop.setProperty("u_molbatchspecimenid", batchname + "-" + latestsamplseq);
                prop.setProperty("u_molbatchspecimenid", StringUtil.repeat(latestsamplseq, dsEach.size(), ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (Exception e) {
                    throw new SapphireException("Specimen can't update." + e.getMessage());
                }
            }
        }
    }

    private void molBatchSpecimenForFluid(DataSet dsFluid, String batchname, DataSet dsBatchPolicy, String LATESTBATCHSEQ) throws SapphireException {
        DataSet dsFluidSample = new DataSet();
        dsFluidSample.addColumn("s_sampleid", DataSet.STRING);
        dsFluidSample.addColumn("molspecid", DataSet.STRING);
        dsFluidSample.addColumn("molbatchname", DataSet.STRING);
        dsFluidSample.addColumn("u_accessionid", DataSet.STRING);
        dsFluidSample.addColumn("u_clientspecimenid", DataSet.STRING);
        dsFluidSample.addColumn("collectiondt", DataSet.STRING);
        dsFluidSample.addColumn("sampletypeid", DataSet.STRING);
        dsFluidSample.addColumn("isnewbatchspecid", DataSet.STRING);
        String sampleids = dsFluid.getColumnValues("s_sampleid", ";");
        String sql = Util.parseMessage(MolecularSql.GET_SPONSOR_ABBRE_BY_SAMPLEID,
                StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        dsSampleInfo.sort("u_accessionid,u_clientspecimenid,collectiondt,sampletypeid");
        ArrayList arrayCombination = dsSampleInfo.getGroupedDataSets("u_accessionid,u_clientspecimenid,collectiondt,sampletypeid");
        for (int j = 0; j < arrayCombination.size(); j++) {
            DataSet dsEach = (DataSet) arrayCombination.get(j);
            String u_accessionid = Util.getUniqueList(dsEach.getColumnValues("u_accessionid", ";"), ";", true);
            String u_clientspecimenid = Util.getUniqueList(dsEach.getColumnValues("u_clientspecimenid", ";"), ";", true);
            String collectiondt = Util.getUniqueList(dsEach.getColumnValues("collectiondt", ";"), ";", true);
            String sampletypeid = Util.getUniqueList(dsEach.getColumnValues("sampletypeid", ";"), ";", true);

            for (int i = 0; i < dsEach.size(); i++) {
                if (i == 0) {
                    int rowID = dsFluidSample.addRow();
                    dsFluidSample.setValue(rowID, "s_sampleid", dsEach.getValue(i, "s_sampleid", ""));
                    dsFluidSample.setValue(rowID, "molbatchname", batchname);
                    dsFluidSample.setValue(rowID, "isnewbatchspecid", "Y");
                    dsFluidSample.setValue(rowID, "collectiondt", collectiondt);
                    dsFluidSample.setValue(rowID, "u_clientspecimenid", u_clientspecimenid);
                    dsFluidSample.setValue(rowID, "u_accessionid", u_accessionid);
                    dsFluidSample.setValue(rowID, "sampletypeid", sampletypeid);
                } else {
                    int rowID = dsFluidSample.addRow();
                    dsFluidSample.setValue(rowID, "s_sampleid", dsEach.getValue(i, "s_sampleid", ""));
                    dsFluidSample.setValue(rowID, "molbatchname", batchname);
                    dsFluidSample.setValue(rowID, "isnewbatchspecid", "N");
                    dsFluidSample.setValue(rowID, "collectiondt", collectiondt);
                    dsFluidSample.setValue(rowID, "u_clientspecimenid", u_clientspecimenid);
                    dsFluidSample.setValue(rowID, "u_accessionid", u_accessionid);
                    dsFluidSample.setValue(rowID, "sampletypeid", sampletypeid);
                }
            }
        }
        if (dsFluidSample.size() > 0) {
            dsFluidSample.sort("s_sampleid");
            ArrayList sortSampleArry = dsFluidSample.getGroupedDataSets("s_sampleid");
            for (int j = 0; j < sortSampleArry.size(); j++) {
                DataSet dsEach = (DataSet) sortSampleArry.get(j);
                String u_accessionid = Util.getUniqueList(dsEach.getColumnValues("u_accessionid", ";"), ";", true);
                String u_clientspecimenid = Util.getUniqueList(dsEach.getColumnValues("u_clientspecimenid", ";"), ";", true);
                String collectiondt = Util.getUniqueList(dsEach.getColumnValues("collectiondt", ";"), ";", true);
                String sampletypeid = Util.getUniqueList(dsEach.getColumnValues("sampletypeid", ";"), ";", true);
                //CONVERT MM/DD/YYYY HH:MM AM to MM/DD/YYYY
                if (!Util.isNull(collectiondt)) {
                    try {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy HH:mm a");
                        Date varDate = dateFormat.parse(collectiondt);
                        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                        collectiondt = dateFormat.format(varDate);
                    } catch (Exception ex) {
                        logger.info("Unable to parse collection date.");
                    }
                }
                sql = Util.parseMessage(MolecularSql.GET_MOL_BATCH_SPEC_ID_BY_SAMECOMBINATION_CLASS, u_accessionid + "#"
                        + u_clientspecimenid + "#" + collectiondt + "#" + sampletypeid);
                DataSet dsBatchSpecIds = getQueryProcessor().getSqlDataSet(sql);
                String u_molbatchspecimenid = dsBatchSpecIds.getValue(0, "u_molbatchspecimenid", "");
                String latestsamplseq = "";
                String getlatestsampleseq = getLatestBatchSampleSeq(dsBatchPolicy, batchname);
                if (!Util.isNull(u_molbatchspecimenid)) {
                    latestsamplseq = u_molbatchspecimenid;
                } else if (Util.isNull(getlatestsampleseq)) {
                    latestsamplseq = batchname + "-" + LATESTBATCHSEQ;
                } else {
                    latestsamplseq = batchname + "-" + getlatestsampleseq;
                }

                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsEach.getColumnValues("s_sampleid", ";"));
                //prop.setProperty("u_molbatchspecimenid", batchname + "-" + latestsamplseq);
                prop.setProperty("u_molbatchspecimenid", StringUtil.repeat(latestsamplseq, dsEach.size(), ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (Exception e) {
                    throw new SapphireException("Specimen can't update." + e.getMessage());
                }
            }
        }
    }
}
