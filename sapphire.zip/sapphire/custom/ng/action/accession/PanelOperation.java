package sapphire.custom.ng.action.accession;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.action.PerformTestcodeDel;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

public class PanelOperation extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1", "");
        String chooseoprtn = properties.getProperty("chooseoprtn", "");
        if (Util.isNull(keyid1))
            throw new SapphireException("Please select specimen(s).");
        if (Util.isNull(chooseoprtn))
            throw new SapphireException("Please select operation.");
        String sql = Util.parseMessage(ApSql.GET_PANEL_TESTS_IHC_SLIDE, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsPanelSlides = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        hm.put("ispanel", "N");
        DataSet dsNotPanel = dsPanelSlides.getFilteredDataSet(hm);
        if (dsNotPanel.size() > 0) {
            DataSet dsShowMsg = new DataSet();
            dsShowMsg.addColumn("specimen_id", DataSet.STRING);
            dsShowMsg.addColumn("testcode_name", DataSet.STRING);
            dsShowMsg.addColumn("is_panel", DataSet.STRING);
            for (int i = 0; i < dsNotPanel.size(); i++) {
                String ispanel = dsNotPanel.getValue(i, "ispanel", "No");
                if ("N".equalsIgnoreCase(ispanel))
                    ispanel = "No";
                else if ("Y".equalsIgnoreCase(ispanel))
                    ispanel = "Yes";
                int rowID = dsShowMsg.addRow();
                dsShowMsg.setValue(rowID, "specimen_id", dsNotPanel.getValue(i, "s_sampleid", ""));
                dsShowMsg.setValue(rowID, "testcode_name", dsNotPanel.getValue(i, "testcodedesc", ""));
                dsShowMsg.setValue(rowID, "is_panel", ispanel);
            }
            if (dsShowMsg.size() > 0) {
                String errCode = Util.getDisplayMessage("Only panel can be performed from here.", dsShowMsg);
                throw new SapphireException(errCode);
            }

        }
        String lvtestpanelid = dsPanelSlides.getColumnValues("lvtestpanelid", ";");
        sql = Util.parseMessage(ApSql.GET_INDIVIDULA_TEST_BY_PANEL, StringUtil.replaceAll(lvtestpanelid, ";", "','"));
        DataSet dsPanelTests = getQueryProcessor().getSqlDataSet(sql);
        if (dsPanelTests == null || dsPanelTests.size() == 0)
            throw new SapphireException("No test(s) found for the panel." + StringUtil.replaceAll(lvtestpanelid, ";", "','"));
        //SORT PANEL PER CLIENT SPECIMEN
        dsPanelSlides.sort("u_accessionid,u_clientspecimenid,methodology,lvtestpanelid");
        ArrayList<DataSet> dsPanelInfoArr = dsPanelSlides.getGroupedDataSets("u_accessionid,u_clientspecimenid,methodology,lvtestpanelid");
        for (int i = 0; i < dsPanelInfoArr.size(); i++) {
            DataSet dsEach = (DataSet) dsPanelInfoArr.get(i);
            hm.clear();
            hm.put("u_testcodeid", dsEach.getValue(0, "lvtestpanelid", ""));
            DataSet dsPanelTestFilter = dsPanelTests.getFilteredDataSet(hm);
            if (dsEach.size() != dsPanelTestFilter.size()) {
                lvtestpanelid = Util.getUniqueList(lvtestpanelid, ";", true);
                throw new SapphireException("Individual Test(s) can not be " + chooseoprtn + " for the panel: " + StringUtil.replaceAll(lvtestpanelid, ";", "','"));
            }
            //TESTCODE OPERATION
            PropertyList props = new PropertyList();
            props.setProperty("keyid1", dsEach.getColumnValues("u_sampletestcodemapid", ";"));
            props.setProperty("eventtype", chooseoprtn);
            if ("undo".equalsIgnoreCase(chooseoprtn))
                props.setProperty("isundobypass", "Y");
            props.setProperty("evntreason", chooseoprtn);
            try {
                getActionProcessor().processAction("PerformTestcodeDel", "1", props);
            } catch (Exception ex) {
                throw new SapphireException(ex.getMessage());
            }
        }
    }
}
