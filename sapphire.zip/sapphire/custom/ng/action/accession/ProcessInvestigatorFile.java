package sapphire.custom.ng.action.accession;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.sql.sdcrule.RulesSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ProcessInvestigatorFile extends BaseAction {

    private HashMap<String, String> errorCode = new HashMap() {{
        put("AccessionEmail", "Error in Accession Notifications Email");
        put("ResultEmail", "Error in Result Notifications Email");
        put("SecureEmail", "Error in Secure Email Report Distribution");
        put("DuplicateRecord", "Duplicate Record");
    }};
    private static Pattern emailNamePtrn = Pattern.compile(
            "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

//	  	String siteNumber = properties.getProperty("sitenumber","");
        DataSet ds = Util.propertyListToDataSet(properties);
        if (!ds.isValidColumn("errormsg"))
            ds.addColumn("errormsg", DataSet.STRING);

        if (!ds.isValidColumn("rowno"))
            ds.addColumn("rowno", DataSet.STRING);

        if (!ds.isValidColumn("isduplicaterow"))
            ds.addColumn("isduplicaterow", DataSet.STRING);

        if (!ds.isValidColumn("invalidsponsor"))
            ds.addColumn("invalidsponsor", DataSet.STRING);

        if (!ds.isValidColumn("invalidproject"))
            ds.addColumn("invalidproject", DataSet.STRING);

        if (!ds.isValidColumn("invalidsponprojcomb"))
            ds.addColumn("invalidsponprojcomb", DataSet.STRING);

        if (!ds.isValidColumn("invalidsitecomb"))
            ds.addColumn("invalidsitecomb", DataSet.STRING);

        if (!ds.isValidColumn("invalidaccessemail"))
            ds.addColumn("invalidaccessemail", DataSet.STRING);

        if (!ds.isValidColumn("invalidresultemail"))
            ds.addColumn("invalidresultemail", DataSet.STRING);

        if (!ds.isValidColumn("invalidsecuremail"))
            ds.addColumn("invalidsecuremail", DataSet.STRING);

        if (!ds.isValidColumn("invalidspprositnositname"))
            ds.addColumn("invalidspprositnositname", DataSet.STRING);

        if (!ds.isValidColumn("invalidspprositnosit"))
            ds.addColumn("invalidspprositnosit", DataSet.STRING);

        validateDuplicateEntry(ds);
        validateSponsors(ds);
        getAllProject(ds);
        validateSponsorProjectComb(ds);
        validateInvestigatorSiteCombination(ds);
        validateInvestigatorData(ds);
        String newkeyid1 = addInvestigatorData(ds);
        addInvestigatorEmail(newkeyid1, ds);
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("errormsg", "Y");
        DataSet dsErrorFilter = ds.getFilteredDataSet(hm);
        if (dsErrorFilter != null && dsErrorFilter.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("row_nos", DataSet.STRING);
            dsDisplayMsg.addColumn("sitenumber", DataSet.STRING);
            dsDisplayMsg.addColumn("project", DataSet.STRING);
            dsDisplayMsg.addColumn("sponsor", DataSet.STRING);
            dsDisplayMsg.addColumn("sponsor_project", DataSet.STRING);
            dsDisplayMsg.addColumn("site_combination", DataSet.STRING);
            dsDisplayMsg.addColumn("accession_email", DataSet.STRING);
            dsDisplayMsg.addColumn("result_email", DataSet.STRING);
            dsDisplayMsg.addColumn("secure_email", DataSet.STRING);
            dsDisplayMsg.addColumn("sponsor_project_sitenumber_sitename", DataSet.STRING);
            dsDisplayMsg.addColumn("sponsor_project_sitenumber", DataSet.STRING);

            for (int i = 0; i < dsErrorFilter.size(); i++) {
                String rowno = dsErrorFilter.getValue(i, "rowno", "");
                String isduplicaterow = dsErrorFilter.getValue(i, "isduplicaterow", "");
                String invalidsponsor = dsErrorFilter.getValue(i, "invalidsponsor", "");
                String invalidproject = dsErrorFilter.getValue(i, "invalidproject", "");
                String invalidsponprojcomb = dsErrorFilter.getValue(i, "invalidsponprojcomb", "");
                String invalidsitecomb = dsErrorFilter.getValue(i, "invalidsitecomb", "");
                String invalidaccessemail = dsErrorFilter.getValue(i, "invalidaccessemail", "");
                String invalidresultemail = dsErrorFilter.getValue(i, "invalidresultemail", "");
                String invalidsecuremail = dsErrorFilter.getValue(i, "invalidsecuremail", "");
                String invalidspprositnositname = dsErrorFilter.getValue(i, "invalidspprositnositname", "");
                String invalidspprositnosit = dsErrorFilter.getValue(i, "invalidspprositnosit", "");

                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "row_nos", rowno);
                dsDisplayMsg.setValue(rowID, "sitenumber", isduplicaterow);
                dsDisplayMsg.setValue(rowID, "project", invalidproject);
                dsDisplayMsg.setValue(rowID, "sponsor", invalidsponsor);
                dsDisplayMsg.setValue(rowID, "sponsor_project", invalidsponprojcomb);
                dsDisplayMsg.setValue(rowID, "site_combination", invalidsitecomb);
                dsDisplayMsg.setValue(rowID, "accession_email", invalidaccessemail);
                dsDisplayMsg.setValue(rowID, "result_email", invalidresultemail);
                dsDisplayMsg.setValue(rowID, "secure_email", invalidsecuremail);
                dsDisplayMsg.setValue(rowID, "sponsor_project_sitenumber_sitename", invalidspprositnositname);
                dsDisplayMsg.setValue(rowID, "sponsor_project_sitenumber", invalidspprositnosit);
            }
            if (dsDisplayMsg != null && dsDisplayMsg.size() > 0) {
                String error = Util.getDisplayMessageInvestigator("Below validation error found into the uploaded file", dsDisplayMsg);
                throw new SapphireException(error);
            }
        }
        //throw new SapphireException("TEST");

    }

    private void validateDuplicateEntry(DataSet ds) throws SapphireException {
        if (ds != null && ds.size() > 0) {
            DataSet dsDuplicate = new DataSet();
            dsDuplicate.addColumn("sponsor_number", DataSet.STRING);
            dsDuplicate.addColumn("project_id", DataSet.STRING);
            dsDuplicate.addColumn("site_number", DataSet.STRING);
            dsDuplicate.addColumn("rows", DataSet.STRING);
            for (int i = 0; i < ds.size(); i++) {
                String projectid = ds.getValue(i, "projectid");
                String sponsornumber = ds.getValue(i, "sponsornumber");
                String sitenumber = ds.getValue(i, "sitenumber");
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("sponsornumber", sponsornumber);
                hm.put("projectid", projectid);
                hm.put("sitenumber", sitenumber);
                DataSet dsDuplicateFiletr = ds.getFilteredDataSet(hm);
                if (dsDuplicateFiletr.size() > 1) {
                    int rowId = dsDuplicate.addRow();
                    dsDuplicate.setValue(rowId, "sponsor_number", sponsornumber);
                    dsDuplicate.setValue(rowId, "project_id", projectid);
                    dsDuplicate.setValue(rowId, "site_number", sitenumber);
                    dsDuplicate.setValue(rowId, "rows", String.valueOf(i + 1));
                    //SET VALUE FOR DUPLICATE ENTRY
                    ds.setValue(i, "errormsg", "Y");
                    ds.setValue(i, "rowno", String.valueOf(i + 1));
                    ds.setValue(i, "isduplicaterow", "Duplicate Investigator Site.");
                }
            }
            /*if (dsDuplicate != null && dsDuplicate.size() > 0) {
                String error = Util.getDisplayMessage("Duplicate entry found into the sheet below: ", dsDuplicate);
                throw new SapphireException(error);
            }*/
        }
    }

    private void validateInvestigatorData(DataSet ds) throws SapphireException {
        DataSet dsInvalidEmail = new DataSet();
        dsInvalidEmail.addColumn("category", DataSet.STRING);
        dsInvalidEmail.addColumn("emails", DataSet.STRING);
        dsInvalidEmail.addColumn("rows", DataSet.STRING);
        if (ds != null && ds.size() > 0) {
            for (int i = 0; i < ds.size(); i++) {
                String accNotificationEmail = ds.getValue(i, "accnotificationemail", "");
                if (!"".equals(accNotificationEmail)) {
                    DataSet dsAccountNotification = validateEmail(accNotificationEmail);
                    if (dsAccountNotification != null && dsAccountNotification.size() > 0) {
                        int rowID = dsInvalidEmail.addRow();
                        dsInvalidEmail.setValue(rowID, "category", "Accession Notification");
                        dsInvalidEmail.setValue(rowID, "emails", dsAccountNotification.getColumnValues("invalid_emails", ", "));
                        dsInvalidEmail.setValue(rowID, "rows", "" + (i + 1));
                        //SET VALUE FOR DUPLICATE ENTRY
                        ds.setValue(i, "errormsg", "Y");
                        ds.setValue(i, "rowno", String.valueOf(i + 1));
                        ds.setValue(i, "invalidaccessemail", "Error in Accession Email Notification");
                    }
                }

                String resultNotoficationEmail = ds.getValue(i, "resultnotoficationemail", "");
                if (!"".equals(resultNotoficationEmail)) {
                    DataSet dsResultNotoficationEmail = validateEmail(resultNotoficationEmail);
                    if (dsResultNotoficationEmail != null && dsResultNotoficationEmail.size() > 0) {
                        int rowID = dsInvalidEmail.addRow();
                        dsInvalidEmail.setValue(rowID, "category", "Result Notification");
                        dsInvalidEmail.setValue(rowID, "emails", dsResultNotoficationEmail.getColumnValues("invalid_emails", ", "));
                        dsInvalidEmail.setValue(rowID, "rows", "" + (i + 1));
                        //SET VALUE FOR DUPLICATE ENTRY
                        ds.setValue(i, "errormsg", "Y");
                        ds.setValue(i, "rowno", String.valueOf(i + 1));
                        ds.setValue(i, "invalidresultemail", "Error in Result Email Notification");
                    }
                }

                String secureEmailrptDistribution = ds.getValue(i, "secureemailrptdistribution", "");
                if (!"".equals(secureEmailrptDistribution)) {
                    DataSet dsSecureEmailrptDistribution = validateEmail(secureEmailrptDistribution);
                    if (dsSecureEmailrptDistribution != null && dsSecureEmailrptDistribution.size() > 0) {
                        int rowID = dsInvalidEmail.addRow();
                        dsInvalidEmail.setValue(rowID, "category", "Secure Email Notification");
                        dsInvalidEmail.setValue(rowID, "emails", dsSecureEmailrptDistribution.getColumnValues("invalid_emails", ", "));
                        dsInvalidEmail.setValue(rowID, "rows", "" + (i + 1));
                        //SET VALUE FOR DUPLICATE ENTRY
                        ds.setValue(i, "errormsg", "Y");
                        ds.setValue(i, "rowno", String.valueOf(i + 1));
                        ds.setValue(i, "invalidsecuremail", "Error in Secure Email Notification");
                    }
                }
            }
            /*if (dsInvalidEmail != null && dsInvalidEmail.size() > 0) {
                DataSet dsDisplatMsg = new DataSet();
                dsDisplatMsg.addColumn("emails", DataSet.STRING);
                dsDisplatMsg.addColumn("rows", DataSet.STRING);
                dsInvalidEmail.sort("rows");
                ArrayList arrySlides = dsInvalidEmail.getGroupedDataSets("rows");
                for (int i = 0; i < arrySlides.size(); i++) {
                    DataSet dsEach = (DataSet) arrySlides.get(i);
                    int rowid = dsDisplatMsg.addRow();
                    dsDisplatMsg.setValue(rowid, "emails", dsEach.getColumnValues("emails", ","));
                    dsDisplatMsg.setValue(rowid, "rows", Util.getUniqueList(dsEach.getColumnValues("rows", ";"), ";", true));
                }
                if (dsDisplatMsg != null && dsDisplatMsg.size() > 0) {
                    String err = Util.getDisplayMessage("Invalid Emails", dsDisplatMsg);
                    throw new SapphireException(err);
                }
            }*/
        } else {
            throw new SapphireException("No Data found in the Excel sheet");
        }

    }

    private DataSet validateEmail(String emailList) throws SapphireException {
        DataSet dsInvalidEmail = new DataSet();
        dsInvalidEmail.addColumn("invalid_emails", DataSet.STRING);
        String[] tempEmailArr = StringUtil.split(emailList, ";");
        for (String email : tempEmailArr) {
            boolean valid = validateEmailAddress(email.trim());
            if (!valid) {
                int rowID = dsInvalidEmail.addRow();
                dsInvalidEmail.setValue(rowID, "invalid_emails", email.trim());
            }
        }
        return dsInvalidEmail;
    }

    public static boolean validateEmailAddress(String userName) {

        Matcher mtch = emailNamePtrn.matcher(userName);
        if (mtch.matches()) {
            return true;
        }
        return false;
    }

    private String addInvestigatorData(DataSet ds) throws SapphireException {

        if (ds == null || ds.size() == 0)
            throw new SapphireException("Upload Failed:: Cannot convert data to Labvantage format.");

        for (int i = 0; i < ds.size(); i++) {
            String zipcode = ds.getValue(i, "postalcode", "");
            if (zipcode.contains(".")) {
                String arrZio = StringUtil.split(zipcode, ".")[0];
                ds.setValue(i, "postalcode", arrZio);
            }
        }

        PropertyList pl = new PropertyList();

        pl.setProperty(AddSDI.PROPERTY_SDCID, "BioSite");
        pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(ds.size()));
        pl.setProperty("sitenumber", ds.getColumnValues("sitenumber", ";"));
        pl.setProperty("projectid", ds.getColumnValues("projectid", ";"));
        pl.setProperty("sponsorid", ds.getColumnValues("sponsornumber", ";"));
        pl.setProperty("sitename", ds.getColumnValues("sitename", ";"));
        pl.setProperty("address1", ds.getColumnValues("address1", ";"));
        pl.setProperty("address2", ds.getColumnValues("address2", ";"));
        pl.setProperty("address3", ds.getColumnValues("address3", ";"));
        pl.setProperty("street", ds.getColumnValues("street", ";"));
        pl.setProperty("city", ds.getColumnValues("city", ";"));
        pl.setProperty("state", ds.getColumnValues("state", ";"));
        pl.setProperty("country", ds.getColumnValues("country", ";"));
        pl.setProperty("zipcode", ds.getColumnValues("postalcode", ";"));
        pl.setProperty("invesitagtorname", ds.getColumnValues("investigatorname", ";"));
        pl.setProperty("rulebypass", "Y");
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        } catch (Exception ex) {
            throw new SapphireException("Unable to upload Investgator site.");
        }
        String newKeyId1 = pl.getProperty("newkeyid1");
        return newKeyId1;
    }

    private void addInvestigatorEmail(String newKeyId1, DataSet ds) throws SapphireException {
        DataSet dsEmails = new DataSet();
        dsEmails.addColumn("biositeid", DataSet.STRING);
        dsEmails.addColumn("email", DataSet.STRING);
        dsEmails.addColumn("type", DataSet.STRING);
        dsEmails.addColumn("event", DataSet.STRING);
        String sql = Util.parseMessage(ApSql.GET_INVESTIGATOR_SITE, StringUtil.replaceAll(newKeyId1, ";", "','"));
        DataSet dsInvsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInvsInfo != null & dsInvsInfo.size() > 0) {
            for (int i = 0; i < dsInvsInfo.size(); i++) {
                String u_biositeid = dsInvsInfo.getValue(i, "u_biositeid");
                String invsitenumber = dsInvsInfo.getValue(i, "sitenumber");
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("sitenumber", invsitenumber);
                DataSet dsFilter = ds.getFilteredDataSet(hm);
                if (dsFilter.size() > 0) {
                    String accnotificationemail = StringUtil.replaceAll(dsFilter.getValue(0, "accnotificationemail", ""), "#semicolon#", ";");
                    String[] arryAccessionMail = StringUtil.split(accnotificationemail, ";");
                    String resultnotoficationemail = StringUtil.replaceAll(dsFilter.getValue(0, "resultnotoficationemail", ""), "#semicolon#", ";");
                    String[] arryResultMail = StringUtil.split(resultnotoficationemail, ";");
                    String secureemailrptdistribution = StringUtil.replaceAll(dsFilter.getValue(0, "secureemailrptdistribution", ""), "#semicolon#", ";");
                    String[] arrySecureMail = StringUtil.split(secureemailrptdistribution, ";");
                    String[] arryFaxdistribution = StringUtil.split(StringUtil.replaceAll(dsFilter.getValue(0, "faxdistribution", ""), "#semicolon#", ";"), ";");
                    String[] arrySftpreportdistribution = StringUtil.split(dsFilter.getValue(0, "sftpreportdistribution", ""), ";");
                    if (arryAccessionMail.length > 0) {
                        for (int c = 0; c < arryAccessionMail.length; c++) {
                            String accemail = arryAccessionMail[c].trim();
                            if (!Util.isNull(accemail)) {
                                int rowID = dsEmails.addRow();
                                dsEmails.setValue(rowID, "biositeid", u_biositeid);
                                dsEmails.setValue(rowID, "email", accemail);
                                dsEmails.setValue(rowID, "type", "Email");
                                dsEmails.setValue(rowID, "event", "Accession Notification");
                            }
                        }
                    }
                    if (arryResultMail.length > 0) {
                        for (int c = 0; c < arryResultMail.length; c++) {
                            String resemail = arryResultMail[c].trim();
                            if (!Util.isNull(resemail)) {
                                int rowID = dsEmails.addRow();
                                dsEmails.setValue(rowID, "biositeid", u_biositeid);
                                dsEmails.setValue(rowID, "email", resemail);
                                dsEmails.setValue(rowID, "type", "Email");
                                dsEmails.setValue(rowID, "event", "Result Notification");
                            }
                        }
                    }
                    if (arrySecureMail.length > 0) {
                        for (int c = 0; c < arrySecureMail.length; c++) {
                            String securemail = arrySecureMail[c].trim();
                            if (!Util.isNull(securemail)) {
                                int rowID = dsEmails.addRow();
                                dsEmails.setValue(rowID, "biositeid", u_biositeid);
                                dsEmails.setValue(rowID, "email", securemail);
                                dsEmails.setValue(rowID, "type", "Email");
                                dsEmails.setValue(rowID, "event", "Report Distribution");
                            }
                        }
                    }
                    if (arryFaxdistribution.length > 0) {
                        for (int c = 0; c < arryFaxdistribution.length; c++) {
                            String faxd = arryFaxdistribution[c].trim();
                            if (!Util.isNull(faxd)) {
                                int rowID = dsEmails.addRow();
                                dsEmails.setValue(rowID, "biositeid", u_biositeid);
                                dsEmails.setValue(rowID, "email", faxd);
                                dsEmails.setValue(rowID, "type", "Fax");
                                dsEmails.setValue(rowID, "event", "Fax Distribution");
                            }
                        }
                    }
                    if (arrySftpreportdistribution.length > 0) {
                        for (int c = 0; c < arrySftpreportdistribution.length; c++) {
                            String path = arrySftpreportdistribution[c].trim();
                            if (!Util.isNull(path)) {
                                int rowID = dsEmails.addRow();
                                dsEmails.setValue(rowID, "biositeid", u_biositeid);
                                dsEmails.setValue(rowID, "email", path);
                                dsEmails.setValue(rowID, "type", "Path");
                                dsEmails.setValue(rowID, "event", "SFTP Path");
                            }
                        }
                    }
                }
            }
            if (dsEmails != null && dsEmails.size() > 0) {
                PropertyList pl = new PropertyList();
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("type", "Email");
                DataSet dsEmsilsFilter = dsEmails.getFilteredDataSet(hm);
                if (dsEmsilsFilter != null && dsEmsilsFilter.size() > 0) {
                    pl.clear();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "BioSiteEmail");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsEmsilsFilter.size()));
                    pl.setProperty("propsmatch", "Y");
                    pl.setProperty("biositeid", dsEmsilsFilter.getColumnValues("biositeid", ";"));
                    pl.setProperty("email", dsEmsilsFilter.getColumnValues("email", ";"));
                    pl.setProperty("type", dsEmsilsFilter.getColumnValues("type", ";"));
                    pl.setProperty("event", dsEmsilsFilter.getColumnValues("event", ";"));
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                }
                hm.clear();
                hm.put("type", "Fax");
                DataSet dsFaxFilter = dsEmails.getFilteredDataSet(hm);
                if (dsFaxFilter != null && dsFaxFilter.size() > 0) {
                    pl.clear();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "BioSiteEmail");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsFaxFilter.size()));
                    pl.setProperty("propsmatch", "Y");
                    pl.setProperty("biositeid", dsFaxFilter.getColumnValues("biositeid", ";"));
                    pl.setProperty("email", dsFaxFilter.getColumnValues("email", ";"));
                    pl.setProperty("type", dsFaxFilter.getColumnValues("type", ";"));
                    pl.setProperty("event", dsFaxFilter.getColumnValues("event", ";"));
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                }
                hm.clear();
                hm.put("type", "Path");
                DataSet dsPathFilter = dsEmails.getFilteredDataSet(hm);
                if (dsPathFilter != null && dsPathFilter.size() > 0) {
                    pl.clear();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "BioSiteSFTPPath");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsPathFilter.size()));
                    pl.setProperty("propsmatch", "Y");
                    pl.setProperty("biositeid", dsPathFilter.getColumnValues("biositeid", ";"));
                    pl.setProperty("path", dsPathFilter.getColumnValues("email", ";"));
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                }
            }
        }
    }

    private void validateSponsors(DataSet ds) throws SapphireException {
        DataSet dsSposnorNotExist = new DataSet();
        dsSposnorNotExist.addColumn("sponsor_number", DataSet.STRING);
        dsSposnorNotExist.addColumn("rows", DataSet.STRING);
        if (ds != null && ds.size() > 0) {
            String sql = MolecularSql.GETALLSPONCER;
            DataSet sponcerDS = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            for (int i = 0; i < ds.size(); i++) {
                hm.clear();
                hm.put("sponsornumber", ds.getValue(i, "sponsornumber"));
                DataSet dsSponsorFiletr = sponcerDS.getFilteredDataSet(hm);
                if (dsSponsorFiletr.size() == 0) {
                    int rowID = dsSposnorNotExist.addRow();
                    dsSposnorNotExist.setValue(rowID, "sponsor_number", ds.getValue(i, "sponsornumber"));
                    dsSposnorNotExist.setValue(rowID, "rows", String.valueOf(i + 1));
                    //SET VALUE FOR DUPLICATE ENTRY
                    ds.setValue(i, "errormsg", "Y");
                    ds.setValue(i, "rowno", String.valueOf(i + 1));
                    ds.setValue(i, "invalidsponsor", "Invalid sponsor");
                }
                if (dsSponsorFiletr.size() > 0) {
                    ds.setValue(i, "sponsornumber", dsSponsorFiletr.getValue(0, "u_sponsorid"));
                }
            }
        }
        /*if (dsSposnorNotExist != null && dsSposnorNotExist.size() > 0) {
            String error = Util.getDisplayMessage("Below Sponsor(s) does not exist into the system.", dsSposnorNotExist);
            throw new SapphireException(error);
        }*/
    }

    private void getAllProject(DataSet ds) throws SapphireException {

        DataSet dsSposnorNotExist = new DataSet();
        dsSposnorNotExist.addColumn("project_id", DataSet.STRING);
        dsSposnorNotExist.addColumn("rows", DataSet.STRING);
        if (ds != null && ds.size() > 0) {
            String sql = Util.parseMessage(MolecularSql.GETALLPROJECT);
            DataSet projectDS = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            for (int i = 0; i < ds.size(); i++) {
                hm.clear();
                hm.put("projectprotocolid", ds.getValue(i, "projectid"));
                DataSet dsSponsorFiletr = projectDS.getFilteredDataSet(hm);
                if (dsSponsorFiletr.size() == 0) {
                    int rowID = dsSposnorNotExist.addRow();
                    dsSposnorNotExist.setValue(rowID, "project_id", ds.getValue(i, "projectid"));
                    dsSposnorNotExist.setValue(rowID, "rows", String.valueOf(i + 1));

                    //SET VALUE FOR DUPLICATE ENTRY
                    ds.setValue(i, "errormsg", "Y");
                    ds.setValue(i, "rowno", String.valueOf(i + 1));
                    ds.setValue(i, "invalidproject", "Invalid Project/Protocol ID");

                }
                if (dsSponsorFiletr.size() > 0) {
                    ds.setValue(i, "projectid", dsSponsorFiletr.getValue(0, "u_bioprojectsid"));
                }
            }
        }
        /*if (dsSposnorNotExist != null && dsSposnorNotExist.size() > 0) {
            String error = Util.getDisplayMessage("Below Project/Protocol ID(s) does not exist into the system.", dsSposnorNotExist);
            throw new SapphireException(error);
        }*/
    }

    private void validateSponsorProjectComb(DataSet ds) throws SapphireException {

        DataSet dsSposnorNotExist = new DataSet();
        dsSposnorNotExist.addColumn("sponsor_number", DataSet.STRING);
        dsSposnorNotExist.addColumn("project_id", DataSet.STRING);
        dsSposnorNotExist.addColumn("rows", DataSet.STRING);
        if (ds != null && ds.size() > 0) {
            String sql = Util.parseMessage(MolecularSql.GETALLPROJECT_SPONSOR_COMB);
            DataSet projectDS = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            for (int i = 0; i < ds.size(); i++) {
                hm.clear();
                hm.put("sponsorid", ds.getValue(i, "sponsornumber"));
                hm.put("u_bioprojectsid", ds.getValue(i, "projectid"));
                DataSet dsSponsorFiletr = projectDS.getFilteredDataSet(hm);
                if (dsSponsorFiletr.size() == 0) {
                    int rowID = dsSposnorNotExist.addRow();
                    dsSposnorNotExist.setValue(rowID, "sponsor_number", ds.getValue(i, "sponsornumber"));
                    dsSposnorNotExist.setValue(rowID, "project_id", ds.getValue(i, "projectid"));
                    dsSposnorNotExist.setValue(rowID, "rows", String.valueOf(i + 1));

                    //SET VALUE FOR DUPLICATE ENTRY
                    ds.setValue(i, "errormsg", "Y");
                    ds.setValue(i, "rowno", String.valueOf(i + 1));
                    ds.setValue(i, "invalidsponprojcomb", "Sponsor & Project/Protocol ID combination doesn't exist.");
                }

            }
        }
        /*if (dsSposnorNotExist != null && dsSposnorNotExist.size() > 0) {
            String error = Util.getDisplayMessage("Below Sponsor & Project/Protocol ID(s) does not exist into the system.", dsSposnorNotExist);
            throw new SapphireException(error);
        }*/
    }

    private void validateInvestigatorSiteCombination(DataSet dsPrimary) throws SapphireException {
        DataSet dsInputSites = new DataSet();
        dsInputSites.addColumn("sponsorid", DataSet.STRING);
        dsInputSites.addColumn("sponsornumber", DataSet.STRING);
        dsInputSites.addColumn("projectid", DataSet.STRING);
        dsInputSites.addColumn("projectprotocolid", DataSet.STRING);
        dsInputSites.addColumn("sitenumber", DataSet.STRING);
        dsInputSites.addColumn("sitename", DataSet.STRING);

        for (int i = 0; i < dsPrimary.size(); i++) {
            int rowId = dsInputSites.addRow();
            dsInputSites.setValue(rowId, "sponsorid", dsPrimary.getValue(i, "sponsornumber", ""));
            dsInputSites.setValue(rowId, "projectid", dsPrimary.getValue(i, "projectid", ""));
            dsInputSites.setValue(rowId, "sitenumber", dsPrimary.getValue(i, "sitenumber", ""));
            dsInputSites.setValue(rowId, "sitename", dsPrimary.getValue(i, "sitename", ""));
        }
        if (dsInputSites != null && dsInputSites.size() > 0) {
            HashMap hm = new HashMap();
            String sponsorid = dsInputSites.getColumnValues("sponsorid", ";");
            String projectid = dsInputSites.getColumnValues("projectid", ";");
            String sitenumber = dsInputSites.getColumnValues("sitenumber", ";");
            String sitename = dsInputSites.getColumnValues("sitename", ";");
            String sql = Util.parseMessage(RulesSql.GET_INVESTIGATOR_SITE_INFO_BY_PROJECT_AND_SPONSOR,
                    StringUtil.replaceAll(sponsorid, ";", "','"),
                    StringUtil.replaceAll(projectid, ";", "','"));
            DataSet dsSiteInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsSiteInfo != null && dsSiteInfo.size() > 0) {
                for (int i = 0; i < dsInputSites.size(); i++) {
                    sponsorid = dsInputSites.getValue(i, "sponsorid", "");
                    projectid = dsInputSites.getValue(i, "projectid", "");
                    sitenumber = dsInputSites.getValue(i, "sitenumber", "");
                    sitename = dsInputSites.getValue(i, "sitename", "");
                    hm.clear();
                    hm.put("sponsorid", sponsorid);
                    hm.put("projectid", projectid);
                    hm.put("sitenumber", sitenumber);
                    hm.put("sitename", sitename);
                    DataSet dsFilterDuplicate = dsSiteInfo.getFilteredDataSet(hm);
                    if (dsFilterDuplicate != null && dsFilterDuplicate.size() > 0) {
                        sql = Util.parseMessage(RulesSql.SITES_INFO_BY_SPONSORNUMBER, sponsorid);
                        DataSet dsSponsor = getQueryProcessor().getSqlDataSet(sql);

                        sql = Util.parseMessage(RulesSql.SITES_INFO_BY_PROJECTPROTOCOLID, projectid);
                        DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
                        String spnno = dsSponsor.getValue(0, "sponsornumber");
                        String prjno = dsProject.getValue(0, "projectprotocolid");
                        String siteno = dsFilterDuplicate.getValue(0, "sitenumber");
                        String sitenam = dsFilterDuplicate.getValue(0, "sitename");
                        /*String errCodes = getErrorTableNew("<b>Duplicate Sponsor, Project, Site Number & Site Name is not allowed:</b>", spnno, prjno, siteno, sitenam);
                        throw new SapphireException(errCodes);*/
                        //SET VALUE FOR DUPLICATE ENTRY
                        dsPrimary.setValue(i, "errormsg", "Y");
                        dsPrimary.setValue(i, "rowno", String.valueOf(i + 1));
                        dsPrimary.setValue(i, "invalidspprositnositname", "Duplicate Sponsor, Project, Site Number & Site Name.");
                    }
                    hm.clear();
                    hm.put("sponsorid", sponsorid);
                    hm.put("projectid", projectid);
                    hm.put("sitenumber", sitenumber);
                    // hm.put("sitename", sitename);
                    DataSet dsFilterDuplicateSiteName = dsSiteInfo.getFilteredDataSet(hm);
                    if (dsFilterDuplicateSiteName != null && dsFilterDuplicateSiteName.size() > 0) {
                        sql = Util.parseMessage(RulesSql.SITES_INFO_BY_SPONSORNUMBER, sponsorid);
                        DataSet dsSponsor = getQueryProcessor().getSqlDataSet(sql);

                        sql = Util.parseMessage(RulesSql.SITES_INFO_BY_PROJECTPROTOCOLID, projectid);
                        DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
                        String spnno = dsSponsor.getValue(0, "sponsornumber");
                        String prjno = dsProject.getValue(0, "projectprotocolid");
                        String siteno = dsFilterDuplicateSiteName.getValue(0, "sitenumber");
                        String sitenam = dsFilterDuplicateSiteName.getValue(0, "sitename");
                        /*String errCodes = getErrorTableNew("Sponsor, Project, Site Number & Site Name is already exist:", spnno, prjno, siteno, sitenam);
                        throw new SapphireException(errCodes);*/
                        //SET VALUE FOR DUPLICATE ENTRY
                        dsPrimary.setValue(i, "errormsg", "Y");
                        dsPrimary.setValue(i, "rowno", String.valueOf(i + 1));
                        dsPrimary.setValue(i, "invalidspprositnosit", "Duplicate sponsor, Project & Site Number.");
                    }
                }
            } else {
                return;
            }
        } else {
            return;
        }
    }

    private void checkSponserExist(DataSet dsInvSites, DataSet dsInputSites) throws SapphireException {
        String sponsornumber = dsInputSites.getValue(0, "sponsornumber", "");
        String projectprotocolid = dsInputSites.getValue(0, "projectprotocolid", "");
        String sitenumber = dsInputSites.getValue(0, "sitenumber", "");
        // String sitename = dsInputSites.getValue(0, "sitename", "");
        // sponsorid
        HashMap<String, String> hmap = new HashMap<String, String>();
        hmap.clear();
        hmap.put("sponsornumber", sponsornumber);
        hmap.put("projectprotocolid", projectprotocolid);
        hmap.put("sitenumber", sitenumber);
        // hmap.put("sitename", sitename);
        DataSet dsFiltr = dsInvSites.getFilteredDataSet(hmap);
        if (dsFiltr != null && dsFiltr.size() > 0) {
            // 2nd time. 4 value matched...not allow to insert
            String msg = "The given Sponsor number,Project/Protocol Id, Site number and Site name is already exist in the system.";
            String errCodes = getErrorTable(msg, sponsornumber, projectprotocolid, sitenumber);
            throw new SapphireException(errCodes);
        } else {
            // site name or site number is attached to differen sponser.
            hmap.clear();
            hmap.put("sponsornumber", sponsornumber);
            DataSet dsFiltrSpProj = dsInvSites.getFilteredDataSet(hmap);// if data present,this will return only 1row
            if (dsFiltrSpProj.size() == 0) {
                String msg = "The given Site number or site Name is already exist with different Sponsor Number  into the system.";
                String errCodes = getErrorTable(msg, sponsornumber, projectprotocolid, sitenumber);
                throw new SapphireException(errCodes);
            } else {
                // check same sponser,dif prj but site num and site name are null
                checkSiblingSites(dsFiltrSpProj, dsInputSites, dsInvSites);
            }

        }
    }

    private void checkSiblingSites(DataSet dsFiltrSpProj, DataSet dsInputSites, DataSet dsInvSites) throws SapphireException {
        //HashMap<String, String> hmap = new HashMap<String, String>();
        String sponsornumber = dsInputSites.getValue(0, "sponsornumber", "");
        String projectprotocolid = dsInputSites.getValue(0, "projectprotocolid", "");
        String sitenumber = dsInputSites.getValue(0, "sitenumber", "");
        // String sitename = dsInputSites.getValue(0, "sitename", "");
        // check same sponser,dif prj but site num and site name are null
        for (int proj = 0; proj < dsFiltrSpProj.size(); proj++) {
            String sponum = dsFiltrSpProj.getValue(proj, "sponsornumber", "");
            String projid = dsFiltrSpProj.getValue(proj, "projectprotocolid", "");
            String siteno = dsFiltrSpProj.getValue(proj, "sitenumber", "");
            // String sitenm = dsFiltrSpProj.getValue(proj, "sitename", "");

            if ((sponum.equalsIgnoreCase(sponsornumber) && !projid.equalsIgnoreCase(projectprotocolid) && (Util.isNull(siteno)))) {
                // site name and site number is blank
                return;

            } else {
                // sibling having different site name and number as input given.
                if ((sponum.equalsIgnoreCase(sponsornumber) && projid.equalsIgnoreCase(projectprotocolid)) && (sitenumber.equalsIgnoreCase(siteno))) {
                    // return;
                    String errCodes = getErrorTable("The given site number or site name is already exist into the system.", sponsornumber, projectprotocolid, sitenumber);
                    throw new SapphireException(errCodes);
                } // same sposer,same prj,same site name and diff site number
                else if (((sponum.equalsIgnoreCase(sponsornumber) && projid.equalsIgnoreCase(projectprotocolid)) && (!sitenumber.equalsIgnoreCase(siteno)))) {
                    String errCodes = getErrorTable("The given site number  is already exist into the system.", sponsornumber, projectprotocolid, sitenumber);
                    throw new SapphireException(errCodes);
                } // same sposer,same prj,diff site name and same site number
                else if (((sponum.equalsIgnoreCase(sponsornumber) && projid.equalsIgnoreCase(projectprotocolid)) && (sitenumber.equalsIgnoreCase(siteno)))) {
                    String errCodes = getErrorTable("The given site name  is already exist into the system.", sponsornumber, projectprotocolid, sitenumber);
                    throw new SapphireException(errCodes);
                } // same sponser,same prj different site number and name
                else if ((sponum.equalsIgnoreCase(sponsornumber) && projid.equalsIgnoreCase(projectprotocolid)) && (!sitenumber.equalsIgnoreCase(siteno))) {
                    return;
                } else if (((sponum.equalsIgnoreCase(sponsornumber) && !projid.equalsIgnoreCase(projectprotocolid)) && (Util.isNull(siteno)))) {
                    // same sponser sibling site number and site name is blank.
                    return;
                } // same sposer,diff prj,diff site name and diff site number
                else if (((sponum.equalsIgnoreCase(sponsornumber) && !projid.equalsIgnoreCase(projectprotocolid)) && (!sitenumber.equalsIgnoreCase(siteno)))) {
                    return;
                } // same sposer,diff prj,same site name and diff site number
                else if (((sponum.equalsIgnoreCase(sponsornumber) && !projid.equalsIgnoreCase(projectprotocolid)) && (!sitenumber.equalsIgnoreCase(siteno)))) {
                    String errCodes = getErrorTable("The given site name  is already exist into the system.", sponsornumber, projectprotocolid, sitenumber);
                    throw new SapphireException(errCodes);
                }
                // same sposer,diff prj,diff site name and same site number
                else if (((sponum.equalsIgnoreCase(sponsornumber) && !projid.equalsIgnoreCase(projectprotocolid)) && (sitenumber.equalsIgnoreCase(siteno)))) {
                    String errCodes = getErrorTable("The given site number is already exist into the system.", sponsornumber, projectprotocolid, sitenumber);
                    throw new SapphireException(errCodes);
                }

            }
        } // for
    }

    private String getErrorTable(String msg, String sponsernumber, String projectprotocolid, String sitenumber) throws SapphireException {

        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("sponsor_number", DataSet.STRING);
        dsDisplayMsg.addColumn("project_id", DataSet.STRING);
        dsDisplayMsg.addColumn("site_number", DataSet.STRING);

        int rowID = dsDisplayMsg.addRow();
        dsDisplayMsg.setValue(rowID, "sponsor_number", sponsernumber);
        dsDisplayMsg.setValue(rowID, "project_id", projectprotocolid);
        dsDisplayMsg.setValue(rowID, "site_number", sitenumber);

        String errCodes = Util.getDisplayMessageInvestigator(msg, dsDisplayMsg);
        return errCodes;
    }

    private String getErrorTableNew(String msg, String sponsernumber, String projectprotocolid, String sitenumber, String sitename) throws SapphireException {
        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("sponsor_number", DataSet.STRING);
        dsDisplayMsg.addColumn("project_id", DataSet.STRING);
        dsDisplayMsg.addColumn("site_number", DataSet.STRING);
        dsDisplayMsg.addColumn("site_name", DataSet.STRING);

        int rowID = dsDisplayMsg.addRow();
        dsDisplayMsg.setValue(rowID, "sponsor_number", sponsernumber);
        dsDisplayMsg.setValue(rowID, "project_id", projectprotocolid);
        dsDisplayMsg.setValue(rowID, "site_number", sitenumber);
        dsDisplayMsg.setValue(rowID, "site_name", sitename);
        String errCodes = Util.getDisplayMessageInvestigator(msg, dsDisplayMsg);
        return errCodes;
    }
}
