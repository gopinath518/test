package sapphire.custom.ng.action.accession;

import java.text.SimpleDateFormat;
import java.util.Date;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class SaveAccessionData extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        if (Util.isNull(accessionid))
            throw new SapphireException("Accession ID can't be blank.");

        updateSponsorInfo(properties);
        updateProjectInfo(properties);
        updateVisistInfo(properties);
        updateSiteInfo(properties);
        updateAccessionCommentsInfo(properties);
        String issubjectadd = properties.getProperty("issubjectadd", "");
        if ("Y".equalsIgnoreCase(issubjectadd)) {
            addSubjectInfo(properties);
        }
        if ("N".equalsIgnoreCase(issubjectadd)) {
            updateSubjectInfo(properties);
        }
        updateCroNumber(properties);
        updateProtocolCohort(properties);
        updateRandomization(properties);
        updateDiaognosisInfo(properties);
        updateSlideSectionDate(properties);//This is added for removing slide sectioning date from accession page.Now slide section date will update while saving

        properties.setProperty("msg", "Operation successful.");
    }
    
    private void updateSlideSectionDate(PropertyList properties) throws SapphireException {
    	 try {
    		 String accessionid = properties.getProperty("accessionid");
             //DataSet dsTestCodePolicy = getTestCodePolicy();
             DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
             if (dsTestCodePolicy.size() > 0) {
                 enterDataForAmgen(accessionid, dsTestCodePolicy);
             }
            // getResponse(ajaxResponse, "Success", tabletype, accessionid);
         } catch (Exception ex) {
        	 throw new SapphireException("Error in updateSlideSectionDate method.\n" + ex.getMessage());
             //getResponse(ajaxResponse, "Failed", tabletype, accessionid);
         }
    }
    
    private void enterDataForAmgen(String accessionid, DataSet dsTestCodePolicy) throws SapphireException {
        String testcodePolicy = dsTestCodePolicy.getColumnValues("testcode", "','");
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES, accessionid, testcodePolicy);
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES, accessionid, testcodePolicy);
        String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES_PORTAL, accessionid, testcodePolicy);
        DataSet dsTestAmgen = getQueryProcessor().getSqlDataSet(sampleTestAmgen);
        if (dsTestAmgen != null && dsTestAmgen.size() > 0) {
            String testname = StringUtil.replaceAll(dsTestAmgen.getColumnValues("testname", ";"), ";", "','");
            String slides = StringUtil.replaceAll(dsTestAmgen.getColumnValues("s_sampleid", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_PARAMIDS, slides, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                for (int i = 0; i < dsSqlEnterData.size(); i++) {
                    String slidesectiondt = dsSqlEnterData.getValue(i, "u_slidesectiondate", "");
                    if (!Util.isNull(slidesectiondt)) {
                        try {
                            //input date format
                            SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyyy");
                            //output date format
                            SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd-MMM-yyyy");
                            Date date = dFormat.parse(slidesectiondt);
                            String formtSlideSectndt = dFormatFinal.format(date);
                            dsSqlEnterData.setValue(i, "u_slidesectiondate", formtSlideSectndt.toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }
    
    private void updateSponsorInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String sponsorid = properties.getProperty("sponsorid", "");
        if (!Util.isNull(sponsorid)) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("clientid", sponsorid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update sponsor information.\n" + ex.getMessage());
            }
        }
    }

    private void updateProjectInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String projectid = properties.getProperty("projectid", "");
        if (!Util.isNull(projectid)) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("bioprojectname", projectid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update project information.\n" + ex.getMessage());
            }
        }
    }

    private void addSubjectInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String patientinitials = properties.getProperty("patientinitials", "");
        String bioeditsubjectid = properties.getProperty("bioeditsubjectid", "");
        String patientgender = properties.getProperty("patientgender", "");
        String patientmonth = properties.getProperty("patientmonth", "");
        String patientday = properties.getProperty("patientday", "");
        String patientyear = properties.getProperty("patientyear", "");
        PropertyList prop = new PropertyList();
        String fi = "", mi = "", li = "";
        if (Util.isNull(bioeditsubjectid)) {
            bioeditsubjectid = "(null)";
        }
        if (!Util.isNull(patientinitials)) {
            int charlng = patientinitials.length();
            if (charlng == 1) {
                li = patientinitials;
            } else if (charlng == 2) {
                li = String.valueOf(patientinitials.charAt(0));
                fi = String.valueOf(patientinitials.charAt(1));
            } else if (charlng == 3) {
                li = String.valueOf(patientinitials.charAt(0));
                mi = String.valueOf(patientinitials.charAt(1));
                fi = String.valueOf(patientinitials.charAt(2));
            }
        }
        if (!Util.isNull(patientmonth)) {
            String sql = Util.parseMessage(AccessionPageSql.GET_SUBJECT_MONTH_BY_NUMBER, patientmonth);
            DataSet dsSubjectMonth = getQueryProcessor().getSqlDataSet(sql);
            patientmonth = dsSubjectMonth.getValue(0, "refdisplayvalue", "");
        }
        String dob1 = patientday + "/" + patientmonth + "/" + patientyear;
        if (Util.isNull(patientmonth) && Util.isNull(patientday) && Util.isNull(patientyear)) {
            dob1 = "(null)";
        }
        prop.clear();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "LV_Subject");
        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
        prop.setProperty("u_firstname", fi);
        prop.setProperty("u_middlename", mi);
        prop.setProperty("u_lastname", li);
        prop.setProperty("u_birthdt", dob1);
        prop.setProperty("genderflag", patientgender);
        prop.setProperty("u_biopharmasubjectid", bioeditsubjectid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add subject information." + ex.getMessage());
        }
        String patientid = prop.getProperty("newkeyid1");
        if (!Util.isNull(patientid)) {
            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("patientid", patientid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update subject information." + ex.getMessage());
            }
        }

    }

    private void updateSubjectInfo(PropertyList properties) throws SapphireException {
        String patientkeyid1 = properties.getProperty("patientkeyid1", "");
        if (Util.isNull(patientkeyid1))
            throw new SapphireException("Subject Id can't be blank.");

        String patientinitials = properties.getProperty("patientinitials", "");
        String bioeditsubjectid = properties.getProperty("bioeditsubjectid", "");
        String patientgender = properties.getProperty("patientgender", "");
        String patientmonth = properties.getProperty("patientmonth", "");
        String patientday = properties.getProperty("patientday", "");
        String patientyear = properties.getProperty("patientyear", "");
        PropertyList prop = new PropertyList();
        String fi = "", mi = "", li = "";
        if (!Util.isNull(patientinitials)) {
            int charlng = patientinitials.length();
            if (charlng == 1) {
                li = patientinitials;
            } else if (charlng == 2) {
                li = String.valueOf(patientinitials.charAt(0));
                fi = String.valueOf(patientinitials.charAt(1));
            } else if (charlng == 3) {
                li = String.valueOf(patientinitials.charAt(0));
                mi = String.valueOf(patientinitials.charAt(1));
                fi = String.valueOf(patientinitials.charAt(2));
            }
            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "LV_Subject");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, patientkeyid1);
            if (!Util.isNull(fi)) {
                prop.setProperty("u_firstname", fi);
            }
            if (!Util.isNull(mi)) {
                prop.setProperty("u_middlename", mi);
            }
            if (!Util.isNull(li)) {
                prop.setProperty("u_lastname", li);
            }
            String sql = Util.parseMessage(AccessionPageSql.GET_SUBJECT_MONTH_BY_NUMBER, patientmonth);
            DataSet dsSubjectMonth = getQueryProcessor().getSqlDataSet(sql);
            patientmonth = dsSubjectMonth.getValue(0, "refdisplayvalue", "");
            //String dob1 = patientmonth + "/" + patienday + "/" + patientyear;
            String dob1 = patientday + "/" + patientmonth + "/" + patientyear;
            if (Util.isNull(patientmonth) && Util.isNull(patientday) && Util.isNull(patientyear)) {
                prop.setProperty("u_birthdt", "(null)");
            } else {
                prop.setProperty("u_birthdt", dob1);
            }
            prop.setProperty("genderflag", patientgender);
            prop.setProperty("u_biopharmasubjectid", bioeditsubjectid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to add subject information." + ex.getMessage());
            }
        }
    }

    private void updateSiteInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String siteclickid = properties.getProperty("siteclickid", "");
        if (!Util.isNull(siteclickid)) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("biositeid", siteclickid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update site information.\n" + ex.getMessage());
            }
        }
    }

    private void updateAccessionCommentsInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String accessioncommnt = properties.getProperty("accessioncommnt", "");
        if (!Util.isNull(accessioncommnt)) {
            String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
            String custodialdepartmentid = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
            PropertyList prop = new PropertyList();
            prop.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("accessionid", accessionid);
            prop.setProperty("commentby", currentuser);
            prop.setProperty("commentdt", "n");
            prop.setProperty("comments", accessioncommnt);
            prop.setProperty("departmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to add comments.\n" + ex.getMessage());
            }
        }
    }

    private void updateCroNumber(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String cronumberaccession = properties.getProperty("cronumberaccession", "");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
        prop.setProperty("croaccessionno", cronumberaccession);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update CRO numbers.\n" + ex.getMessage());
        }
    }

    private void updateProtocolCohort(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String protocolcohort = properties.getProperty("protocolcohort", "");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
        prop.setProperty("protocolcohort", protocolcohort);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update protocol cohort.\n" + ex.getMessage());
        }
    }

    private void updateRandomization(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String randomizationumber = properties.getProperty("randomizationumber", "");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
        prop.setProperty("randomizationno", randomizationumber);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update randomization number.\n" + ex.getMessage());
        }
    }

    private void updateDiaognosisInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String diaognasys = properties.getProperty("diaognasys", "");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
        prop.setProperty("biodiagnosis", diaognasys);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update diagnosis.\n" + ex.getMessage());
        }
    }

    private void updateVisistInfo(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String visitno = properties.getProperty("visitno", "");
        if (!Util.isNull(visitno)) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
            prop.setProperty("biovisitname", visitno);

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update visit.\n" + ex.getMessage());
            }
        }
    }
}
