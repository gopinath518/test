package sapphire.custom.ng.action.accession;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.util.Util;
import sapphire.custom.ng.util.XMLParsing;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ProcessXMLData extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String fileName = properties.getProperty("fileName");
        String outputDIR = properties.getProperty("outputDIR");
        processXML(fileName, outputDIR);

    }

    private void processXML(String fileName, String outputDIR) throws SapphireException {
        try {
            StringBuffer sbMSG = new StringBuffer();
            int flag = 0;
            ArrayList<DataSet> ads = new ArrayList<DataSet>();


            String returnMsg = new XMLParsing().createAccessionfromXML(fileName, ads);
            if (!Util.isNull(returnMsg))
                throw new SapphireException(returnMsg);

            for (DataSet ds : ads) {
                if (ds != null) {
                    String neoAcc = ds.getValue(0, "neogenomicsaccession", "");
                    String sql = " select u_accessionid from u_accession" + " where neogenomicsaccession='" + neoAcc + "'";
                    String eAcc = "";
                    DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql);

                    if (dsQuery != null && dsQuery.size() > 0) {
                        flag = 1;
                        eAcc = dsQuery.getValue(0, "u_accessionid", "");
                    } else if (dsQuery == null) {
                        returnMsg = neoAcc + "::Unable to get Accession Id from Labvantage system.";
                        throw new SapphireException(returnMsg);
                    }

                    sbMSG.setLength(0);
                    initialValidation(ds, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String patientId = createPatientInfo(ds, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String clientId = createClientInfo(ds, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String physicianId = createPhysicianInfo(ds, clientId, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String accessionId = createAccession(ds, patientId, clientId, flag, eAcc, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String mapId = addingAccClientPhyMapInfo(accessionId, clientId, physicianId, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String specimenId = createSpecimen(ds, accessionId, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String sampleTestCodeMapIdMsg = createSpecimenTestCodeMapping(ds, specimenId, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }

                    sbMSG.setLength(0);
                    String icd9Id = createICD9Info(ds, accessionId, flag, sbMSG);
                    returnMsg = sbMSG.toString();
                    if (!Util.isNull(returnMsg)) {
                        throw new SapphireException(neoAcc + "::" + returnMsg);
                    }
                    moveFile(fileName, outputDIR, true, neoAcc, returnMsg);

                } else {
                    throw new SapphireException("No_Accession:: No value in the Dataset");
                }
            }
        } catch (Exception e) {
            throw new SapphireException("XML parsing Failed::" + e.getMessage());
        }
    }


    private String initialValidation(DataSet d, StringBuffer sbMSG) throws SapphireException {

        String sampleType = Util.getUniqueList(d.getColumnValues("specimentype", ";"), ";", true);
        String transportType = Util.getUniqueList(d.getColumnValues("specimentransport", ";"), ";", true);
        String bodySite = Util.getUniqueList(d.getColumnValues("specimenbodysite", ";"), ";", true);
        String testCode = Util.getUniqueList(d.getColumnValues("testneogenomicstestcode", ";"), ";", true);


        String sqlSpecimenType = " select s_sampletypeid from s_sampletype where s_sampletypeid " +
                " in ('" + StringUtil.replaceAll(sampleType, ";", "','") + "')";
        DataSet dsQuerySample = getQueryProcessor().getSqlDataSet(sqlSpecimenType);

        if (dsQuerySample == null) {
            Logger.logError("Error: Unable to Execute Query for Specimen Type.");
            sbMSG.append("Error: Unable to Execute Query for Specimen Type.");
            return "";
        }
        if ((dsQuerySample.size() != sampleType.split(";").length) && (sampleType.length() > 0)) {
            String temp = "";
            HashMap hm = new HashMap();
            String[] tempArray = sampleType.split(";");
            for (String s : tempArray) {
                hm.put("s_sampletypeid", s);
                DataSet dsFilter = dsQuerySample.getFilteredDataSet(hm);

                if (dsFilter.size() == 0)
                    temp = temp + s + ",";
            }
            Logger.logError("Error: Specimen Type( " + temp + ") does not exist in LV system.");
            sbMSG.append("Error: Specimen Type( " + temp + ") does not exist in LV system.");
            return "";
        }
//---------------------------------------
        String sqlTransport = " select containertypeid from containertype where containertypeid " +
                " in ('" + StringUtil.replaceAll(transportType, ";", "','") + "')";
        DataSet dsQueryTransport = getQueryProcessor().getSqlDataSet(sqlTransport);

        if (dsQueryTransport == null) {
            Logger.logError("Error: Unable to Execute Query for Transport Type.");
            sbMSG.append("Error: Unable to Execute Query for Transport Type.");
            return "";
        }
        if ((dsQueryTransport.size() != transportType.split(";").length) && (transportType.length() > 0)) {
            String temp = "";
            HashMap hm = new HashMap();
            String[] tempArray = transportType.split(";");
            for (String s : tempArray) {
                hm.put("containertypeid", s);
                DataSet dsFilter = dsQueryTransport.getFilteredDataSet(hm);

                if (dsFilter.size() == 0)
                    temp = temp + s + ",";
            }
            Logger.logError("Error: Transport Type( " + temp + ")  does not exist in LV system.");
            sbMSG.append("Error: Transport Type( " + temp + ")  does not exist in LV system.");
            return "";
        }
        //------------------------------------
        String sqlBodysite = " select u_bodysiteid from u_bodysite where u_bodysiteid " +
                " in ('" + StringUtil.replaceAll(bodySite, ";", "','") + "')";
        DataSet dsQueryBodySite = getQueryProcessor().getSqlDataSet(sqlBodysite);

        if (dsQueryBodySite == null) {
            Logger.logError("Error: Unable to Execute Query for Body Site.");
            sbMSG.append("Error: Unable to Execute Query for Body Site.");
            return "";
        }
        if ((dsQueryBodySite.size() != bodySite.split(";").length) && (bodySite.length() > 0)) {
            String temp = "";
            HashMap hm = new HashMap();
            String[] tempArray = bodySite.split(";");
            for (String s : tempArray) {
                hm.put("u_bodysiteid", s);
                DataSet dsFilter = dsQueryBodySite.getFilteredDataSet(hm);

                if (dsFilter.size() == 0)
                    temp = temp + s + ",";
            }
            Logger.logError("Error: Body Site( " + temp + ")  does not exist in LV system.");
            sbMSG.append("Error: Body Site( " + temp + ") does not exist in LV system.");
            return "";
        }
        //----------------------------------
        String sqlTestCode = " select u_testcodeid from u_testcode where u_testcodeid " +
                " in ('" + StringUtil.replaceAll(testCode, ";", "','") + "')";
        DataSet dsQueryTestCode = getQueryProcessor().getSqlDataSet(sqlTestCode);

        if (dsQueryTestCode == null) {
            Logger.logError("Error: Unable to Execute Query for Test Code.");
            sbMSG.append("Error: Unable to Execute Query for Test Code.");
            return "";
        }
        if ((dsQueryTestCode.size() != testCode.split(";").length) && (testCode.length() > 0)) {
            String tcode = "";
            HashMap hm = new HashMap();
            String[] testCodeArray = testCode.split(";");
            for (String s : testCodeArray) {
                hm.put("u_testcodeid", s);
                DataSet dsFilter = dsQueryTestCode.getFilteredDataSet(hm);

                if (dsFilter.size() == 0)
                    tcode = tcode + s + ",";
            }

            Logger.logError("Error: Test Code( " + tcode + ") does not exist in LV system.");
            sbMSG.append("Error: Test Code( " + tcode + ")  does not exist in LV system.");
            return "";
        }
        return "";
    }

    private String createPatientInfo(DataSet d, int flag, StringBuffer sbMSG) throws SapphireException {

        String patientId = "";
        String gender = "";
        try {
            String birthdt = dateConversion(d.getValue(0, "patientdob", ""));
            String neogenPatientid = d.getValue(0, "patientneogenomicspatientid", "");
            String firstName = d.getValue(0, "patientfirst", "");
            String middleName = d.getValue(0, "patientmiddle", "");
            String lastName = d.getValue(0, "patientlast", "");
            String ssn = d.getValue(0, "patientssn", "");

            if (d.getValue(0, "patientgender").equalsIgnoreCase("Male"))
                gender = "M";
            else if (d.getValue(0, "patientgender").equalsIgnoreCase("Female"))
                gender = "F";

            String sql = " select s_subjectid from s_subject where u_neogenomicspatientid='" + neogenPatientid + "'";
            DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql);

            PropertyList pl = new PropertyList();
            if (dsQuery != null && dsQuery.size() == 0) {
                pl.setProperty(AddSDI.PROPERTY_SDCID, "LV_Subject");
                pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                pl.setProperty("u_mrn", d.getValue(0, "patientmrn", ""));
                pl.setProperty("u_firstname", firstName);
                pl.setProperty("u_middlename", middleName);
                pl.setProperty("u_lastname", lastName);
                pl.setProperty("birthdt", birthdt);
                pl.setProperty("genderflag", gender);
                pl.setProperty("u_ssn", ssn);
                pl.setProperty("u_neogenomicspatientid", neogenPatientid);
            } else if (flag == 0 && dsQuery.size() > 0) {
                patientId = dsQuery.getValue(0, "s_subjectid", "");
                return patientId;
            }

            if (flag == 1 && dsQuery.size() > 0) {
                patientId = dsQuery.getValue(0, "s_subjectid", "");
                pl.setProperty(EditSDI.PROPERTY_SDCID, "LV_Subject");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, patientId);
                pl.setProperty("u_mrn", d.getValue(0, "patientmrn", ""));
                pl.setProperty("u_firstname", firstName);
                pl.setProperty("u_middlename", middleName);
                pl.setProperty("u_lastname", lastName);
                pl.setProperty("birthdt", birthdt);
                pl.setProperty("genderflag", gender);
                pl.setProperty("u_ssn", ssn);

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                } catch (Exception ex) {
                    Logger.logError("Error occured during editing Patient Information::" + ex.getMessage());
                    sbMSG.append("Error occured during editing Patient Information::" + ex.getMessage());
                }
            } else if (dsQuery.size() == 0) {
                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                    patientId = pl.getProperty("newkeyid1");

                } catch (Exception ex) {
                    Logger.logError("Error occured during adding Patient Information::" + ex.getMessage());
                    sbMSG.append("Error occured during adding Patient Information::" + ex.getMessage());
                }
            }

        } catch (Exception ex) {
            Logger.logError("Error occured in createPatientInfo method::" + ex.getMessage());
            sbMSG.append("Error occured in createPatientInfo method::" + ex.getMessage());
        }
        return patientId;
    }

    private String createClientInfo(DataSet d, int flag, StringBuffer sbMSG) throws SapphireException {
        String clientId = "";
        try {
            String neoClientNumber = d.getValue(0, "clientneogenomicsclientnumber", "");
            String sql = " select u_clientid from u_client where neogenomicsclientnumber='" + neoClientNumber + "'";
            DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql);

            if (flag == 0 && dsQuery != null) {
                if (dsQuery.size() == 0) {
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddSDI.PROPERTY_SDCID, "Client");
                        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        pl.setProperty("u_clientid", d.getValue(0, "clientclientid", ""));
                        pl.setProperty("clientname", d.getValue(0, "clientclientname", ""));
                        pl.setProperty("address1", d.getValue(0, "clientstreetaddress1", ""));
                        pl.setProperty("address2", d.getValue(0, "clientstreetaddress2", ""));
                        pl.setProperty("city", d.getValue(0, "clientcity", ""));
                        pl.setProperty("state", d.getValue(0, "clientstate", ""));
                        pl.setProperty("postalcode", d.getValue(0, "clientzipcode", ""));
                        pl.setProperty("telephone", d.getValue(0, "clientphone", ""));
                        pl.setProperty("fax", d.getValue(0, "clientfax", ""));
                        pl.setProperty("neogenomicsclientnumber", neoClientNumber);

                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                        clientId = pl.getProperty("newkeyid1");

                    } catch (Exception ex) {
                        Logger.logError("Error occured during adding Client Information::" + ex.getMessage());
                        sbMSG.append("Error occured during adding Client Information::" + ex.getMessage());
                    }
                } else {
                    clientId = dsQuery.getValue(0, "u_clientid", "");
                }

            } else { // edit
                if (dsQuery.size() == 0) {
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddSDI.PROPERTY_SDCID, "Client");
                        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        pl.setProperty("u_clientid", d.getValue(0, "clientclientid", ""));
                        pl.setProperty("clientname", d.getValue(0, "clientclientname", ""));
                        pl.setProperty("address1", d.getValue(0, "clientstreetaddress1", ""));
                        pl.setProperty("address2", d.getValue(0, "clientstreetaddress2", ""));
                        pl.setProperty("city", d.getValue(0, "clientcity", ""));
                        pl.setProperty("state", d.getValue(0, "clientstate", ""));
                        pl.setProperty("postalcode", d.getValue(0, "clientzipcode", ""));
                        pl.setProperty("telephone", d.getValue(0, "clientphone", ""));
                        pl.setProperty("fax", d.getValue(0, "clientfax", ""));
                        pl.setProperty("neogenomicsclientnumber", neoClientNumber);

                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                        clientId = pl.getProperty("newkeyid1");

                    } catch (Exception ex) {
                        Logger.logError("Error occured during adding Client Information::" + ex.getMessage());
                        sbMSG.append("Error occured during adding Client Information::" + ex.getMessage());
                    }
                } else {
                    try {
                        clientId = dsQuery.getValue(0, "u_clientid", "");

                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "Client");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, clientId);
                        pl.setProperty("u_clientid", d.getValue(0, "clientclientid", ""));
                        pl.setProperty("clientname", d.getValue(0, "clientclientname", ""));
                        pl.setProperty("address1", d.getValue(0, "clientstreetaddress1", ""));
                        pl.setProperty("address2", d.getValue(0, "clientstreetaddress2", ""));
                        pl.setProperty("city", d.getValue(0, "clientcity", ""));
                        pl.setProperty("state", d.getValue(0, "clientstate", ""));
                        pl.setProperty("postalcode", d.getValue(0, "clientzipcode", ""));
                        pl.setProperty("telephone", d.getValue(0, "clientphone", ""));
                        pl.setProperty("fax", d.getValue(0, "clientfax", ""));

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                    } catch (Exception ex) {
                        Logger.logError("Error occured during editing Client Information::" + ex.getMessage());
                        sbMSG.append("Error occured during editing Client Information::" + ex.getMessage());
                    }
                }
            }
        } catch (Exception ex) {
            Logger.logError("Error occured in createClientInfo method::" + ex.getMessage());
            sbMSG.append("Error occured in createClientInfo method::" + ex.getMessage());
        }
        return clientId;
    }

    private String createPhysicianInfo(DataSet d, String clientId, int flag, StringBuffer sbMSG) throws SapphireException {

        String physicianId = "";
        try {
            String clientsql = "select u_clientid,address1,address2,city,postalcode,contactname,fax,primaryemail from u_client where u_clientid='" + clientId + "'";

            String neoDocId = d.getValue(0, "doctorneogenomicsdoctorid", "");
            String doctorfirstName = d.getValue(0, "doctorfirst", "");
            String doctorlastName = d.getValue(0, "doctorlast", "");
            String doctormiddleName = d.getValue(0, "doctormiddle", "");
            String doctornpi = d.getValue(0, "doctornpi", "");

            String neoTreatId = d.getValue(0, "treatingphysicianneogenomicsdoctorid", "");
            String treatingfirstName = d.getValue(0, "treatingphysicianfirst", "");
            String treatinglastName = d.getValue(0, "treatingphysicianlast", "");
            String treatingmiddleName = d.getValue(0, "treatingphysicianmiddle", "");
            String treatingnpi = d.getValue(0, "treatingphysiciannpi", "");


            String doctorsql = " select u_physicianid from u_physician where neogenomicsdoctorid='" + neoDocId + "'";
            String treatingsql = " select u_physicianid from u_physician where neogenomicsdoctorid='" + neoTreatId + "'";

            DataSet dsClient = getQueryProcessor().getSqlDataSet(clientsql);
            if (dsClient == null) {
                sbMSG.append("Error: Unable to Execute Client Query");
                return "";
            }
            //Adding Doctor
            DataSet dsQuery = getQueryProcessor().getSqlDataSet(doctorsql);

            String docId = null;
            String treatingId = null;

            if (dsQuery == null) {
                sbMSG.append("Error: Unable to Execute Doctor Query");
                return "";
            }

            if (flag == 0) {
                if (dsQuery.size() == 0) {
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddSDI.PROPERTY_SDCID, "Physician");
                        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        pl.setProperty("physiciantype", "orderingphysician");
                        pl.setProperty("firstname", doctorfirstName);
                        pl.setProperty("lastname", doctorlastName);
                        pl.setProperty("middlename", doctormiddleName);
                        pl.setProperty("npi", doctornpi);
                        pl.setProperty("clientid", clientId);
                        pl.setProperty("address1", dsClient.getValue(0, "address1", ""));
                        pl.setProperty("address2", dsClient.getValue(0, "address2", ""));
                        pl.setProperty("city", dsClient.getValue(0, "city", ""));
                        pl.setProperty("zipcode", dsClient.getValue(0, "postalcode", ""));
                        pl.setProperty("phonenumber", dsClient.getValue(0, "contactname", ""));
                        pl.setProperty("fax", dsClient.getValue(0, "fax", ""));
                        pl.setProperty("email", dsClient.getValue(0, "primaryemail", ""));
                        pl.setProperty("neogenomicsdoctorid", neoDocId);

                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                        docId = pl.getProperty("newkeyid1");

                    } catch (Exception ex) {
                        Logger.logError("Error occured during adding Ordering Physician Information::" + ex.getMessage());
                        sbMSG.append("Error occured during adding Ordering Physician Information::" + ex.getMessage());
                        return "";
                    }
                } else {
                    docId = dsQuery.getValue(0, "u_physicianid", "");
                }

            } else {       //edit
                if (dsQuery.size() == 0) {
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddSDI.PROPERTY_SDCID, "Physician");
                        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        pl.setProperty("physiciantype", "orderingphysician");
                        pl.setProperty("firstname", doctorfirstName);
                        pl.setProperty("lastname", doctorlastName);
                        pl.setProperty("middlename", doctormiddleName);
                        pl.setProperty("npi", doctornpi);
                        pl.setProperty("clientid", clientId);
                        pl.setProperty("address1", dsClient.getValue(0, "address1", ""));
                        pl.setProperty("address2", dsClient.getValue(0, "address2", ""));
                        pl.setProperty("city", dsClient.getValue(0, "city", ""));
                        pl.setProperty("zipcode", dsClient.getValue(0, "postalcode", ""));
                        pl.setProperty("phonenumber", dsClient.getValue(0, "contactname", ""));
                        pl.setProperty("fax", dsClient.getValue(0, "fax", ""));
                        pl.setProperty("email", dsClient.getValue(0, "primaryemail", ""));
                        pl.setProperty("neogenomicsdoctorid", neoDocId);

                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                        docId = pl.getProperty("newkeyid1");

                    } catch (Exception ex) {
                        Logger.logError("Error occured during adding Ordering Physician Information::" + ex.getMessage());
                        sbMSG.append("Error occured during adding Ordering Physician Information::" + ex.getMessage());
                        return "";
                    }
                } else {
                    try {
                        docId = dsQuery.getValue(0, "u_physicianid", "");

                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "Physician");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, docId);
                        pl.setProperty("physiciantype", "orderingphysician");
                        pl.setProperty("firstname", doctorfirstName);
                        pl.setProperty("lastname", doctorlastName);
                        pl.setProperty("middlename", doctormiddleName);
                        pl.setProperty("npi", doctornpi);
                        pl.setProperty("clientid", clientId);
                        pl.setProperty("address1", dsClient.getValue(0, "address1", ""));
                        pl.setProperty("address2", dsClient.getValue(0, "address2", ""));
                        pl.setProperty("city", dsClient.getValue(0, "city", ""));
                        pl.setProperty("zipcode", dsClient.getValue(0, "postalcode", ""));
                        pl.setProperty("phonenumber", dsClient.getValue(0, "contactname", ""));
                        pl.setProperty("fax", dsClient.getValue(0, "fax", ""));
                        pl.setProperty("email", dsClient.getValue(0, "primaryemail", ""));

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    } catch (Exception ex) {
                        Logger.logError("Error occured during editing Ordering Physician Information::" + ex.getMessage());
                        sbMSG.append("Error occured during editing Ordering Physician Information::" + ex.getMessage());
                        return "";
                    }
                }
            }
            //Adding treating doctor
            dsQuery.clear();
            dsQuery = getQueryProcessor().getSqlDataSet(treatingsql);

            if (dsQuery == null) {
                Logger.logError("Error: Unable to Execute Treating Query");
                sbMSG.append("Error: Unable to Execute Treating Query");
                return "";
            }
            if (flag == 0) {
                if (dsQuery.size() == 0) {
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddSDI.PROPERTY_SDCID, "Physician");
                        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        pl.setProperty("physiciantype", "treatingphysician");
                        pl.setProperty("firstname", treatingfirstName);
                        pl.setProperty("lastname", treatinglastName);
                        pl.setProperty("middlename", treatingmiddleName);
                        pl.setProperty("npi", treatingnpi);
                        pl.setProperty("clientid", clientId);
                        pl.setProperty("address1", dsClient.getValue(0, "address1", ""));
                        pl.setProperty("address2", dsClient.getValue(0, "address2", ""));
                        pl.setProperty("city", dsClient.getValue(0, "city", ""));
                        pl.setProperty("zipcode", dsClient.getValue(0, "postalcode", ""));
                        pl.setProperty("phonenumber", dsClient.getValue(0, "contactname", ""));
                        pl.setProperty("fax", dsClient.getValue(0, "fax", ""));
                        pl.setProperty("email", dsClient.getValue(0, "primaryemail", ""));
                        pl.setProperty("neogenomicsdoctorid", neoTreatId);

                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                        treatingId = pl.getProperty("newkeyid1");

                    } catch (Exception ex) {
                        Logger.logError("Error occured during adding Treating Physician Information::" + ex.getMessage());
                        sbMSG.append("Error occured during adding Treating Physician Information::" + ex.getMessage());
                        return "";
                    }
                } else {
                    treatingId = dsQuery.getValue(0, "u_physicianid", "");
                }
            } else {      //edit treating

                if (dsQuery.size() == 0) {
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddSDI.PROPERTY_SDCID, "Physician");
                        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        pl.setProperty("physiciantype", "treatingphysician");
                        pl.setProperty("firstname", treatingfirstName);
                        pl.setProperty("lastname", treatinglastName);
                        pl.setProperty("middlename", treatingmiddleName);
                        pl.setProperty("npi", treatingnpi);
                        pl.setProperty("clientid", clientId);
                        pl.setProperty("address1", dsClient.getValue(0, "address1", ""));
                        pl.setProperty("address2", dsClient.getValue(0, "address2", ""));
                        pl.setProperty("city", dsClient.getValue(0, "city", ""));
                        pl.setProperty("zipcode", dsClient.getValue(0, "postalcode", ""));
                        pl.setProperty("phonenumber", dsClient.getValue(0, "contactname", ""));
                        pl.setProperty("fax", dsClient.getValue(0, "fax", ""));
                        pl.setProperty("email", dsClient.getValue(0, "primaryemail", ""));
                        pl.setProperty("neogenomicsdoctorid", neoTreatId);

                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                        treatingId = pl.getProperty("newkeyid1");

                    } catch (Exception ex) {
                        Logger.logError("Error occured during adding Treating Physician Information::" + ex.getMessage());
                        sbMSG.append("Error occured during adding Treating Physician Information::" + ex.getMessage());
                        return "";
                    }
                } else {
                    try {
                        treatingId = dsQuery.getValue(0, "u_physicianid", "");

                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "Physician");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, treatingId);
                        pl.setProperty("physiciantype", "treatingphysician");
                        pl.setProperty("firstname", treatingfirstName);
                        pl.setProperty("lastname", treatinglastName);
                        pl.setProperty("middlename", treatingmiddleName);
                        pl.setProperty("npi", treatingnpi);
                        pl.setProperty("clientid", clientId);
                        pl.setProperty("address1", dsClient.getValue(0, "address1", ""));
                        pl.setProperty("address2", dsClient.getValue(0, "address2", ""));
                        pl.setProperty("city", dsClient.getValue(0, "city", ""));
                        pl.setProperty("zipcode", dsClient.getValue(0, "postalcode", ""));
                        pl.setProperty("phonenumber", dsClient.getValue(0, "contactname", ""));
                        pl.setProperty("fax", dsClient.getValue(0, "fax", ""));
                        pl.setProperty("email", dsClient.getValue(0, "primaryemail", ""));

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    } catch (Exception ex) {
                        Logger.logError("Error occured during editing Treating Physician Information::" + ex.getMessage());
                        sbMSG.append("Error occured during editing Treating Physician Information::" + ex.getMessage());
                        return "";
                    }
                }
            }

            physicianId = docId + ";" + treatingId;
        } catch (Exception ex) {
            Logger.logError("Error occured in createPhysicianInfo method::" + ex.getMessage());
            sbMSG.append("Error occured in createPhysicianInfo method::" + ex.getMessage());
            return "";
        }
        return physicianId;
    }

    private String createAccession(DataSet d, String patientId, String clientId, int flag, String eAcc, StringBuffer sbMSG) throws SapphireException {
        String accessionId = "";

        if (flag == 0) {
            try {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDI.PROPERTY_SDCID, "Accession");
                pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
                pl.setProperty("createdt", "n");
                pl.setProperty("createby", d.getValue(0, "accessionuser", ""));
                pl.setProperty("patientid", patientId);
                pl.setProperty("clientid", clientId);
                pl.setProperty("accessionlab", d.getValue(0, "accessionlab", ""));
                pl.setProperty("billingtype", d.getValue(0, "accessionbillingtype", ""));
                pl.setProperty("secbillingtype", d.getValue(0, "accessionsecondarybillingtype", ""));
                pl.setProperty("reasonforreferal", d.getValue(0, "clinicalreasonforreferral", ""));
                pl.setProperty("neogenomicsaccession", d.getValue(0, "neogenomicsaccession", ""));

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                accessionId = pl.getProperty("newkeyid1");

            } catch (Exception ex) {
                Logger.logError("Error occured during adding Accession Information::" + ex.getMessage());
                sbMSG.append("Error occured during adding Accession Information::" + ex.getMessage());
                return "";
            }
        } else {
            try {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, eAcc);
                pl.setProperty("createby", d.getValue(0, "accessionuser", ""));
                pl.setProperty("patientid", patientId);
                pl.setProperty("clientid", clientId);
                pl.setProperty("accessionlab", d.getValue(0, "accessionlab", ""));
                pl.setProperty("billingtype", d.getValue(0, "accessionbillingtype", ""));
                pl.setProperty("secbillingtype", d.getValue(0, "accessionsecondarybillingtype", ""));
                pl.setProperty("reasonforreferal", d.getValue(0, "clinicalreasonforreferral", ""));

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (Exception ex) {
                Logger.logError("Error occured during editing Accession Information::" + ex.getMessage());
                sbMSG.append("Error occured during editing Accession Information::" + ex.getMessage());
                return "";
            }
            accessionId = eAcc;
        }
        return accessionId;
    }

    private String addingAccClientPhyMapInfo(String accessionId, String clientId, String physicianId, int flag, StringBuffer sbMSG) throws SapphireException {
        String mapId = "";
        try {
            PropertyList pl = new PropertyList();
            if (flag == 0) {
                try {
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "ClientPhysicianMap");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, "" + physicianId.split(";").length);
                    pl.setProperty("physicianid", physicianId);
                    pl.setProperty("clientid", StringUtil.repeat(clientId, physicianId.split(";").length, ";"));

                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                    mapId = pl.getProperty("newkeyid1");

                } catch (Exception ex) {
                    Logger.logError("Error occured during adding ClientPhysicianMap Information::" + ex.getMessage());
                    sbMSG.append("Error occured during adding ClientPhysicianMap Information::" + ex.getMessage());
                    return "";
                }
                try {
                    pl.clear();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "AccPhysicianMap");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, "" + physicianId.split(";").length);
                    pl.setProperty("physicianid", physicianId);
                    pl.setProperty("accessionid", StringUtil.repeat(accessionId, physicianId.split(";").length, ";"));
                    pl.setProperty("physiciantype", "orderingphysician;treatingphysician");

                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                    mapId = mapId + ";" + pl.getProperty("newkeyid1");

                } catch (Exception ex) {
                    Logger.logError("Error occured during adding AccPhysicianMap Information::" + ex.getMessage());
                    sbMSG.append("Error occured during adding AccPhysicianMap Information::" + ex.getMessage());
                    return "";
                }
            } else {        //  edit mapping
                String sql = " select u_accphysicianmapid from u_accphysicianmap where accessionid='" + accessionId + "' and PHYSICIANTYPE in ('orderingphysician','treatingphysician')";
                DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql);

                if (dsQuery == null) {
                    Logger.logError("Error: Unable to Execute u_accphysicianmapid Query");
                    sbMSG.append("Error: Unable to Execute u_accphysicianmapid Query");
                    return "";
                }
                if (dsQuery.size() != 0) {
                    try {
                        String mId = dsQuery.getColumnValues("u_accphysicianmapid", ";");
                        pl.clear();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "AccPhysicianMap");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, mId);
                        pl.setProperty("physicianid", physicianId);

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    } catch (Exception ex) {
                        Logger.logError("Error occured during editing AccPhysicianMap Information::" + ex.getMessage());
                        sbMSG.append("Error occured during editing AccPhysicianMap Information::" + ex.getMessage());
                        return "";
                    }
                }
                try {
                    pl.clear();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "ClientPhysicianMap");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, "" + physicianId.split(";").length);
                    pl.setProperty("physicianid", physicianId);
                    pl.setProperty("clientid", StringUtil.repeat(clientId, physicianId.split(";").length, ";"));

                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                    mapId = pl.getProperty("newkeyid1");

                } catch (Exception ex) {
                    Logger.logError("Error occured during adding ClientPhysicianMap Information::" + ex.getMessage());
                    sbMSG.append("Error occured during adding ClientPhysicianMap Information::" + ex.getMessage());
                    return "";
                }
            }
        } catch (Exception ex) {
            Logger.logError("Error occured in addingAccClientPhyMapInfo method::" + ex.getMessage());
            sbMSG.append("Error occured in addingAccClientPhyMapInfo method::" + ex.getMessage());
            return "";
        }
        return mapId;
    }

    //to create Specimen Dataset for each accession, this will be called from createSpecimen
    private DataSet createDataset(DataSet d, String accessionId, int flag, String toAdd) throws SapphireException {

        DataSet specimenDataset = new DataSet();
        String specimenid = null;
        if (flag == 0) {
            specimenid = Util.getUniqueList(d.getColumnValues("specimenneogenomicsspecimenid", ";"), ";", true);
        } else {
            specimenid = toAdd;
        }

        String[] specimenidArray = StringUtil.split(specimenid, ";");

        specimenDataset.addColumn("collectiondt", DataSet.STRING);
        specimenDataset.addColumn("receiveddt", DataSet.STRING);
        specimenDataset.addColumn("u_clientspecimenid", DataSet.STRING);
        specimenDataset.addColumn("accession", DataSet.STRING);
        specimenDataset.addColumn("sampletype", DataSet.STRING);
        specimenDataset.addColumn("transporttype", DataSet.STRING);
        specimenDataset.addColumn("u_bodysite", DataSet.STRING);
        specimenDataset.addColumn("u_neogenomicscaseno", DataSet.STRING);
        specimenDataset.addColumn("u_ngspecimenid", DataSet.STRING);

        for (int j = 0; j < specimenidArray.length; j++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("specimenneogenomicsspecimenid", specimenidArray[j]);
            DataSet dd = d.getFilteredDataSet(hm);
            int row = specimenDataset.addRow();

            specimenDataset.setValue(row, "collectiondt", dateConversion(dd.getValue(0, "specimencollectiondate", "")));
            specimenDataset.setValue(row, "receiveddt", dateConversion(dd.getValue(0, "specimenreceiveddate", "")));
            specimenDataset.setValue(row, "u_clientspecimenid", dd.getValue(0, "specimeninternalspecimenid", ""));
            specimenDataset.setValue(row, "accession", accessionId);
            specimenDataset.setValue(row, "sampletype", dd.getValue(0, "specimentype", ""));
            specimenDataset.setValue(row, "transporttype", dd.getValue(0, "specimentransport", ""));
            specimenDataset.setValue(row, "u_bodysite", dd.getValue(0, "specimenbodysite", ""));
            specimenDataset.setValue(row, "u_neogenomicscaseno", dd.getValue(0, "neogenomicscaseno", ""));
            specimenDataset.setValue(row, "u_ngspecimenid", dd.getValue(0, "specimenneogenomicsspecimenid", ""));
            //p.showData(dd);
        }

        return specimenDataset;
    }

    private String dateConversion(String dateTime) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat sdfNew = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dtNew = "";
        try {
            Date dt = sdf.parse(dateTime);

            dtNew = sdfNew.format(dt);


        } catch (Exception e) {
            Logger.logError("Error: Unable to Parse Date" + dateTime);
            //sbMSG.append("Error: Unable to Parse Date");
            return dateTime;
        }


        return dtNew;
    }

    private String createSpecimen(DataSet d, String accessionId, int flag, StringBuffer sbMSG) throws SapphireException {
        String specimenId = "";
        try {
            //String existingSpecId = "";
            String trackitemId = "";
            DataSet specDS = null;

            String sql = " select s_sampleid,u_ngspecimenid from s_sample where u_accessionid='" + accessionId + "'";
            DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql);

            if (dsQuery == null) {
                Logger.logError("Error: Unable to Execute Query for sampleid and u_ngspecimenid");
                sbMSG.append("Error: Unable to Execute Query for sampleid and u_ngspecimenid");
                return "";
            }
            String toAdd = "";
            String sz = "";
            String[] ngSpecimenId = null;
            String[] lvSpecimenId = null;

            specDS = createDataset(d, accessionId, flag, toAdd);
            sz = "" + specDS.size();

            if (dsQuery.size() != 0) {
                int f = 0;
                specDS = createDataset(d, accessionId, f, toAdd);
                //existingSpecId = dsQuery.getColumnValues("s_sampleid", ";");
                ngSpecimenId = StringUtil.split(specDS.getColumnValues("u_ngspecimenid", ";"), ";");
                lvSpecimenId = StringUtil.split(dsQuery.getColumnValues("u_ngspecimenid", ";"), ";");

                String a = "";
                for (int i = 0; i < ngSpecimenId.length; i++) {
                    boolean notfound = true;
                    for (int j = 0; j < lvSpecimenId.length; j++) {
                        if ((ngSpecimenId[i].equalsIgnoreCase(lvSpecimenId[j]))) {
                            notfound = false;
                            break;
                        }
                    }
                    if (notfound)
                        a = a + ngSpecimenId[i] + ";";
                }
                if (a.length() > 0)
                    toAdd = a.substring(0, (a.length() - 1));
            }

            if (flag == 0 || (flag == 1 && (ngSpecimenId.length > lvSpecimenId.length))) {

                if (flag == 1 && (ngSpecimenId.length > lvSpecimenId.length)) {
                    specDS = createDataset(d, accessionId, flag, toAdd);
                    sz = "" + toAdd.split(";").length;
                }
                String newtrackitemid = "";
                try {
                    PropertyList pl = new PropertyList();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, "" + sz);
                    pl.setProperty("collectiondt", specDS.getColumnValues("collectiondt", ";"));
                    pl.setProperty("receiveddt", specDS.getColumnValues("receiveddt", ";"));
                    pl.setProperty("u_bodysite", specDS.getColumnValues("u_bodysite", ";"));
                    pl.setProperty("u_clientspecimenid", specDS.getColumnValues("u_clientspecimenid", ";"));
                    pl.setProperty("u_accessionid", specDS.getColumnValues("accession", ";"));
                    pl.setProperty("sampletypeid", specDS.getColumnValues("sampletype", ";"));
                    pl.setProperty("u_accessioningcomplete", StringUtil.repeat("N", Integer.parseInt(sz), ";"));
                    pl.setProperty("u_ngspecimenid", specDS.getColumnValues("u_ngspecimenid", ";"));
                    pl.setProperty("samplestatus", StringUtil.repeat("Initial", Integer.parseInt(sz), ";"));
                    pl.setProperty("sstudyid", StringUtil.repeat("NeoClinical", Integer.parseInt(sz), ";"));
                    pl.setProperty("storagestatus", StringUtil.repeat("In Circulation", Integer.parseInt(sz), ";"));
                    pl.setProperty("u_currentmovementstep", StringUtil.repeat("Accession", Integer.parseInt(sz), ";"));

                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                    specimenId = pl.getProperty("newkeyid1");
                    newtrackitemid = pl.getProperty("newtrackitemid");

                } catch (Exception ex) {
                    Logger.logError("Error occured during adding Sample Information::" + ex.getMessage());
                    sbMSG.append("Error occured during adding Sample Information::" + ex.getMessage());
                    return "";
                }
                // for track item Entry
                try {
                    PropertyList ptrackitem = new PropertyList();
                    ptrackitem.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
                    ptrackitem.setProperty(EditSDI.PROPERTY_KEYID1, newtrackitemid);
                    ptrackitem.setProperty("containertypeid", specDS.getColumnValues("transporttype", ";"));

                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, ptrackitem);
                    trackitemId = ptrackitem.getProperty("newkeyid1");

                } catch (Exception ex) {
                    Logger.logError("Error occured during editing TrackItemSDC Information::" + ex.getMessage());
                    sbMSG.append("Error occured during editing TrackItemSDC Information::" + ex.getMessage());
                    return "";

                }
            } else {     //edit
                String linksdcid = "";
                int f = 0;
                specDS = createDataset(d, accessionId, f, toAdd);
                String sqlS = " select s_sampleid,u_ngspecimenid from s_sample where u_ngspecimenid " +
                        " in ('" + StringUtil.replaceAll(specDS.getColumnValues("u_ngspecimenid", ";"), ";", "','") + "')";
                DataSet dsQueryS = getQueryProcessor().getSqlDataSet(sqlS);

                if (dsQueryS == null) {
                    Logger.logError("Error: Unable to Execute Query for sampleid and u_ngspecimenid");
                    sbMSG.append("Error: Unable to Execute Query for sampleid and u_ngspecimenid");
                    return "";
                }

                if (dsQueryS.size() != 0) {
                    String[] ngSpecArray = specDS.getColumnValues("u_ngspecimenid", ";").split(";");
                    HashMap<String, String> hm = new HashMap<String, String>();
                    specimenId = "";
                    for (int i = 0; i < ngSpecArray.length; i++) {
                        hm.clear();
                        hm.put("u_ngspecimenid", ngSpecArray[i]);
                        DataSet dsTemp = dsQueryS.getFilteredDataSet(hm);
                        specimenId = specimenId + dsTemp.getValue(0, "s_sampleid") + ";";
                    }

                    specimenId = specimenId.substring(0, (specimenId.length() - 1));
                    try {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, specimenId);
                        pl.setProperty("collectiondt", specDS.getColumnValues("collectiondt", ";"));
                        pl.setProperty("receiveddt", specDS.getColumnValues("receiveddt", ";"));
                        pl.setProperty("u_bodysite", specDS.getColumnValues("u_bodysite", ";"));
                        pl.setProperty("u_clientspecimenid", specDS.getColumnValues("u_clientspecimenid", ";"));

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    } catch (Exception ex) {
                        Logger.logError("Error occured during editing sample Information::" + ex.getMessage());
                        sbMSG.append("Error occured during editing sample Information::" + ex.getMessage());
                        return "";

                    }
                    String sqlT = " select trackitemid from trackitem where linkkeyid1 in ('" + StringUtil.replaceAll(specimenId, ";", "','") + "')";
                    DataSet dsQueryT = getQueryProcessor().getSqlDataSet(sqlT);

                    if (dsQueryT == null) {
                        Logger.logError("Error: Unable to Execute Query for trackitem");
                        sbMSG.append("Error: Unable to Execute Query for trackitem");
                        return "";
                    }
                    if (dsQueryT.size() != 0) {
                        try {
                            trackitemId = dsQueryT.getColumnValues("trackitemid", ";");

                            PropertyList ptrackitem = new PropertyList();
                            ptrackitem.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
                            ptrackitem.setProperty(EditSDI.PROPERTY_KEYID1, trackitemId);
                            ptrackitem.setProperty("containertypeid", specDS.getColumnValues("transporttype", ";"));

                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, ptrackitem);

                        } catch (Exception ex) {
                            Logger.logError("Error occured during editing sample Information::" + ex.getMessage());
                            sbMSG.append("Error occured during editing sample Information::" + ex.getMessage());
                            return "";
                        }
                    }
                    linksdcid = trackitemId;
                }
            }
        } catch (Exception ex) {
            Logger.logError("Error occured in createSpecimen method::" + ex.getMessage());
            sbMSG.append("Error occured in createSpecimen method::" + ex.getMessage());
            return "";
        }
        return specimenId;
    }

    private String createSpecimenTestCodeMapping(DataSet d, String specimenId, int flag, StringBuffer sbMSG) throws SapphireException {
        String sampleTestCodeMapIdMsg = "";
        try {

            DataSet ds = new DataSet();
            ds.addColumn("sampleid", DataSet.STRING);
            ds.addColumn("lvtestcode", DataSet.STRING);
            String specimenIdArry[] = StringUtil.split(specimenId, ";");
            String testcodeid = Util.getUniqueList(d.getColumnValues("testneogenomicstestcode", ";"), ";", true);

            String testcode[] = StringUtil.split(testcodeid, ";");
            for (int i = 0; i < specimenIdArry.length; i++) {
                for (int j = 0; j < testcode.length; j++) {
                    if (!"MOLPX".equalsIgnoreCase(testcode[j])) {
                        int addRow = ds.addRow();
                        ds.setValue(addRow, "sampleid", specimenIdArry[i]);
                        ds.setValue(addRow, "lvtestcode", testcode[j]);
                    }
                }
            }

            if (flag == 0) {
                PropertyList props = new PropertyList();
                props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, ds.getColumnValues("sampleid", ";"));
                props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, ds.getColumnValues("lvtestcode", ";"));

                getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
                sampleTestCodeMapIdMsg = props.getProperty("msg");
                updateCaseNumber(d, specimenIdArry, testcodeid);

            } else {
                DataSet dsAdd = new DataSet();
                dsAdd.addColumn("sampleid", DataSet.STRING);
                dsAdd.addColumn("lvtestcode", DataSet.STRING);

                String sqltcodeOrPanel = " select u_testcodeid,ispanel from u_testcode where u_testcodeid" +
                        " in('" + StringUtil.replaceAll(testcodeid, ";", "','") + "')";
                DataSet dssqltcodeOrPanel = getQueryProcessor().getSqlDataSet(sqltcodeOrPanel);
                if (dssqltcodeOrPanel == null) {
                    throw new SapphireException("Error: Unable to Execute Query in CreateSpecimenTestCodeMapping. Test code or Panel checking.");
                }
                String pCode = "";
                String tCode = "";
                if (dssqltcodeOrPanel.size() > 0) {
                    for (int i = 0; i < dssqltcodeOrPanel.size(); i++) {

                        if (dssqltcodeOrPanel.getValue(i, "ispanel").equalsIgnoreCase("Y")) {
                            pCode = pCode + dssqltcodeOrPanel.getValue(i, "u_testcodeid") + ";";
                        } else
                            tCode = tCode + dssqltcodeOrPanel.getValue(i, "u_testcodeid") + ";";
                    }
                }

                if (pCode.length() > 0) {
                    pCode = pCode.substring(0, (pCode.lastIndexOf(";")));
                    String pcodeArray[] = StringUtil.split(pCode, ";");
                    for (int i = 0; i < specimenIdArry.length; i++) {
                        for (int j = 0; j < pcodeArray.length; j++) {
                            String sam = specimenIdArry[i];
                            String pncode = pcodeArray[j];
                            String stmId = pncode + "#" + sam;

                            String pcodeSql = "select u_sampletestcodemapid from u_sampletestcodemap "
                                    + " where lvtestpanelid||'#'||s_sampleid='" + stmId + "'";
                            DataSet dsKeyid1 = getQueryProcessor().getSqlDataSet(pcodeSql);
                            if (dsKeyid1.size() == 0) {
                                int addRow = dsAdd.addRow();
                                dsAdd.setValue(addRow, "sampleid", sam);
                                dsAdd.setValue(addRow, "lvtestcode", pncode);
                            }
                        }
                    }
                }

                if (tCode.length() > 0) {
                    tCode = tCode.substring(0, (tCode.lastIndexOf(";")));
                    String tcodeArray[] = StringUtil.split(tCode, ";");

                    for (int i = 0; i < specimenIdArry.length; i++) {
                        for (int j = 0; j < tcodeArray.length; j++) {
                            String sam = specimenIdArry[i];
                            String tscode = tcodeArray[j];
                            String stmId = tscode + "#" + sam;

                            String testcodeSql = "select u_sampletestcodemapid from u_sampletestcodemap "
                                    + " where lvtestcodeid||'#'||s_sampleid='" + stmId + "'";
                            DataSet dsKeyid1 = getQueryProcessor().getSqlDataSet(testcodeSql);
                            if (dsKeyid1.size() == 0) {
                                int addRow = dsAdd.addRow();
                                dsAdd.setValue(addRow, "sampleid", sam);
                                dsAdd.setValue(addRow, "lvtestcode", tscode);
                            }
                        }
                    }
                }


                if (dsAdd.size() != 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsAdd.getColumnValues("sampleid", ";"));
                    props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,
                            dsAdd.getColumnValues("lvtestcode", ";"));

                    getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
                    sampleTestCodeMapIdMsg = props.getProperty("msg");
                }

                updateCaseNumber(d, specimenIdArry, testcodeid);
            }
        } catch (Exception ex) {
            Logger.logError("Error occured in createSpecimenTestCodeMapping method::" + ex.getMessage());
            sbMSG.append("Error occured in createSpecimenTestCodeMapping method::" + ex.getMessage());
            return "";
        }
        return sampleTestCodeMapIdMsg;

    }

    private String createICD9Info(DataSet d, String accessionId, int flag, StringBuffer sbMSG) throws SapphireException {

        String icd9Id = "";
        try {
            // String icd9MapId = "";
            String icd = d.getValue(0, "clinicalicd9s", "");
            if (Util.isNull(icd)) {
                return "";
            }
            String icds = icdCodeChecking(icd);

            String[] icdArray = icds.split(";");
            for (int i = 0; i < icdArray.length; i++) {
                String sql1 = " select u_accessionicdcodemapid from u_accessionicdcodemap" + " where icdcodeid='"
                        + icdArray[i] + "' and accessionid='" + accessionId + "'";

                DataSet dsQuery = getQueryProcessor().getSqlDataSet(sql1);
                if (dsQuery == null) {
                    throw new SapphireException("Error: Unable to Execute ICD Query.");
                }

                if (dsQuery.size() == 0) {
                    icd9Id = icd9Id + icdArray[i] + ";";
                }
            }

            if (icd9Id.length() > 0) {
                try {
                    icd9Id = icd9Id.substring(0, (icd9Id.length() - 1));
                    PropertyList pl = new PropertyList();
                    pl.setProperty(AddSDI.PROPERTY_SDCID, "AccessionICDCodeMap");
                    pl.setProperty(AddSDI.PROPERTY_COPIES, "" + icd9Id.split(";").length);
                    pl.setProperty("icdcodeid", icd9Id);
                    pl.setProperty("accessionid", StringUtil.repeat(accessionId, (icd9Id.split(";").length), ";"));
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                    // icd9MapId = pl.getProperty("newkeyid1");

                } catch (Exception ex) {
                    Logger.logError("Error occured during adding AccessionICDCodeMap Information::" + ex.getMessage());
                    sbMSG.append("Error occured during adding AccessionICDCodeMap Information::" + ex.getMessage());
                    return "";
                }
            }
        } catch (Exception ex) {
            Logger.logError("Error occured in createICD9Info method::" + ex.getMessage());
            sbMSG.append("Error occured in createICD9Info method::" + ex.getMessage());
            return "";
        }
        return icd9Id;
    }

    public String icdCodeChecking(String icd) throws SapphireException {

        String[] icdArray = icd.split(";");  //A1#A2-;-B1#B2
        DataSet dsIcd = new DataSet();
        dsIcd.addColumn("code", DataSet.STRING);
        dsIcd.addColumn("desc", DataSet.STRING);

        for (int i = 0; i < icdArray.length; i++) {
            int rowNum = dsIcd.addRow();
            String[] a = icdArray[i].split("#");
            dsIcd.setValue(rowNum, "code", a[0]);
            dsIcd.setValue(rowNum, "desc", a[1]);
        }

        String icdCode = dsIcd.getColumnValues("code", ";");
        String sql = " select u_icdcodeid from u_icdcode" +
                " where u_icdcodeid in ('" + StringUtil.replaceAll(icdCode, ";", "','") + "')";

        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);

        if (dsSql == null) {
            throw new SapphireException("Error: Unable to Execute Query.");
        }


        if (dsSql.size() == 0) {
            addIcd(dsIcd.getColumnValues("code", ";"), dsIcd.getColumnValues("desc", ";"));
            return dsIcd.getColumnValues("code", ";");
        } else if (dsSql.size() == dsIcd.size()) {
            return dsIcd.getColumnValues("code", ";");
        } else {
            DataSet dsAdd = new DataSet();
            HashMap hm = new HashMap();
            for (int i = 0; i < dsIcd.size(); i++) {
                hm.clear();
                hm.put("u_icdcodeid", dsIcd.getValue(i, "code"));
                if (dsSql.getFilteredDataSet(hm).size() == 0)
                    dsAdd.copyRow(dsIcd, i, 1);
            }
            addIcd(dsAdd.getColumnValues("code", ";"), dsAdd.getColumnValues("desc", ";"));
            return dsIcd.getColumnValues("code", ";");
        }


    }

    private void addIcd(String code, String desc) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "ICDCode");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "" + code.split(";").length);
        pl.setProperty("u_icdcodeid", code);
        pl.setProperty("icdcodedesc", desc);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            // icd9Id = pl.getProperty("newkeyid1");

        } catch (Exception ex) {
            String error = getTranslationProcessor().translate("Error : Unable to Add ICD9");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    public void updateCaseNumber(DataSet d, String[] specimenIdArry, String testcodeid) throws SapphireException {

        String sqlCheckCode = " select u_testcodeid,ispanel from u_testcode where u_testcodeid" +
                " in('" + StringUtil.replaceAll(testcodeid, ";", "','") + "')";
        DataSet dsSqlCheck = getQueryProcessor().getSqlDataSet(sqlCheckCode);
        if (dsSqlCheck == null) {
            throw new SapphireException("Error: Unable to Execute Query in updateCaseNumber.");
        }
        String panelCode = "";
        String testCode = "";
        String testcodeSampleCom = "";
        if (dsSqlCheck.size() > 0) {
            for (int i = 0; i < dsSqlCheck.size(); i++) {

                if (dsSqlCheck.getValue(i, "ispanel").equalsIgnoreCase("Y")) {
                    panelCode = panelCode + dsSqlCheck.getValue(i, "u_testcodeid") + ";";
                    testcodeSampleCom = "stp.lvtestpanelid#stp.s_sampleid";
                } else
                    testCode = testCode + dsSqlCheck.getValue(i, "u_testcodeid") + ";";
            }
        }

        if (panelCode.length() > 0) {
            panelCode = panelCode.substring(0, (panelCode.lastIndexOf(";")));
            String stmId = "";
            String testcode[] = StringUtil.split(panelCode, ";");
            for (int i = 0; i < specimenIdArry.length; i++) {
                for (int j = 0; j < testcode.length; j++) {
                    String sam = specimenIdArry[i];
                    String tcode = testcode[j];
                    stmId = stmId + tcode + "#" + sam + ";";
                }
            }
            stmId = stmId.substring(0, (stmId.length() - 1));
            String ts = " select stp.u_sampletestcodemapid,concat(concat(stp.lvtestpanelid,'#'),sam.u_ngspecimenid) as sample#testcode"
                    + " from u_sampletestcodemap stp, s_sample sam where stp.s_sampleid=sam.S_SAMPLEID and stp.lvtestpanelid||'#'||stp.s_sampleid "
                    + " in('" + StringUtil.replaceAll(stmId, ";", "','") + "')";
            DataSet dsSql = getQueryProcessor().getSqlDataSet(ts);

            if (dsSql == null) {
                throw new SapphireException("Error: Unable to Execute Query.");
            }

            if (dsSql.size() == 0) {
                throw new SapphireException("Error: No match found in SampleTestCodeMap "
                        + "for the following 'PanelCode#Sample' combinations :" + stmId);
            } else {
                dsSql.addColumn("ngcasenumber", DataSet.STRING);
                HashMap<String, String> hm = new HashMap<String, String>();

                for (int j = 0; j < d.size(); j++) {
                    String val = d.getValue(j, "testneogenomicstestcode") + "#"
                            + d.getValue(j, "specimenneogenomicsspecimenid");
                    hm.clear();
                    hm.put("sample#testcode", val);
                    DataSet dsTemp = dsSql.getFilteredDataSet(hm);
                    for (int i = 0; i < dsTemp.size(); i++) {
                        dsTemp.setValue(i, "ngcasenumber", d.getValue(j, "neogenomicscaseno"));
                    }

                }

                PropertyList pl = new PropertyList();
                String stpId = dsSql.getColumnValues("u_sampletestcodemapid", ";");
                String caseNumber = dsSql.getColumnValues("ngcasenumber", ";");

                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, stpId);
                pl.setProperty("ngcasenumber", caseNumber);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                } catch (Exception ex) {
                    String error = getTranslationProcessor().translate("Unable to Update Case Number for Samples");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
            }


        }
        if (testCode.length() > 0) {
            testCode = testCode.substring(0, (testCode.lastIndexOf(";")));
            String stmId = "";
            String testcode[] = StringUtil.split(testCode, ";");
            for (int i = 0; i < specimenIdArry.length; i++) {
                for (int j = 0; j < testcode.length; j++) {
                    String sam = specimenIdArry[i];
                    String tcode = testcode[j];
                    stmId = stmId + tcode + "#" + sam + ";";
                }
            }
            stmId = stmId.substring(0, (stmId.length() - 1));
            String ts = " select stp.u_sampletestcodemapid,concat(concat(stp.lvtestcodeid,'#'),sam.u_ngspecimenid) as sample#testcode"
                    + " from u_sampletestcodemap stp, s_sample sam where stp.s_sampleid=sam.S_SAMPLEID and stp.lvtestcodeid||'#'||stp.s_sampleid "
                    + " in('" + StringUtil.replaceAll(stmId, ";", "','") + "')";
            DataSet dsSql = getQueryProcessor().getSqlDataSet(ts);

            if (dsSql == null) {
                throw new SapphireException("Error: Unable to Execute Query.");
            }

            if (dsSql.size() == 0) {
                throw new SapphireException("Error: No match found in SampleTestCodeMap "
                        + "for the following 'TestCode#Sample' combinations :" + stmId);
            } else {
                dsSql.addColumn("ngcasenumber", DataSet.STRING);
                HashMap<String, String> hm = new HashMap<String, String>();

                for (int j = 0; j < d.size(); j++) {
                    String val = d.getValue(j, "testneogenomicstestcode") + "#"
                            + d.getValue(j, "specimenneogenomicsspecimenid");
                    hm.clear();
                    hm.put("sample#testcode", val);
                    DataSet dsTemp = dsSql.getFilteredDataSet(hm);
                    dsTemp.setValue(0, "ngcasenumber", d.getValue(j, "neogenomicscaseno"));
                }

                PropertyList pl = new PropertyList();
                String stpId = dsSql.getColumnValues("u_sampletestcodemapid", ";");
                String caseNumber = dsSql.getColumnValues("ngcasenumber", ";");

                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, stpId);
                pl.setProperty("ngcasenumber", caseNumber);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                } catch (Exception ex) {
                    String error = getTranslationProcessor().translate("Unable to Update Case Number for Samples");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
            }

        }


    }

    private void moveFile(String fileName, String pathToMove, boolean xmlExeFlag, String accessionId, String msg) {

        File fName = new File(fileName);
        String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        String fileDt = new SimpleDateFormat("dd-MM-yyyy_HH-MM-ss").format(new Date());
        try {
            File dir = null;
            if (xmlExeFlag)
                dir = new File(pathToMove + "/" + folderDt + "/Success");
            else
                dir = new File(pathToMove + "/" + folderDt + "/Failure");

            if (!dir.exists())
                dir.mkdirs();

            if (fName.renameTo(new File(dir.getPath() + "/" + accessionId + "_" + fileDt + ".xml"))) {
                Logger.logInfo(("File is moved successful!"));
            } else {
                Logger.logError(("File is failed to move!"));
            }
            if (!xmlExeFlag) {
                File logFile = new File(dir.getPath() + "/" + accessionId + "_" + fileDt + "_log.txt");
                logFile.createNewFile();
                writeLog(logFile.getName(), msg);
            }

        } catch (Exception e) {
            Logger.logError(("Error occured during file movement!!"));
        }
    }

    private void writeLog(String logFileName, String msg) {
        BufferedWriter bw = null;
        FileWriter fw = null;
        try {
            fw = new FileWriter(logFileName);
            bw = new BufferedWriter(fw);
            bw.write(msg);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (IOException ex) {

            }
        }
    }

}
