package sapphire.custom.ng.action.accession;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

/**
 * Created by abanerjee on 12/27/2016.
 * This Action is creating new acccession and corresponding details like patient,client and associated samples and their test codes.
 * Updated tables are s_subject,u_client,u_accession,s_sample,u_sample_testcode_map and u_sample_testcode_steps_map
 */
public class CreateAccessionFromXML extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String outputDIR = properties.getProperty("outputDIR");
        String fileName= "";
        
        File folder = new File(properties.getProperty("xmlpath"));
		File[] listOfFiles = folder.listFiles();
		PropertyList pl = new PropertyList();

		for (File file : listOfFiles) {
			try{
				if (file.isFile()) {
					Logger.logInfo("Processing XML File Name::"+file.getName());
			        fileName = folder+"/"+file.getName();
			        pl.setProperty("fileName", fileName);
			        pl.setProperty("outputDIR", outputDIR);
			        getActionProcessor().processAction("ProcessXMLData", "1", pl,true);
				}
			}catch(Exception e){
				moveFile(fileName, outputDIR,false,file.getName(),e.getMessage());
			}
		}
    }   

	private void moveFile(String fileName, String pathToMove, boolean xmlExeFlag, String xmlFileName, String msg) {

		File fName = new File(fileName);
		String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		String fileDt = new SimpleDateFormat("dd-MM-yyyy_HH-MM-ss").format(new Date());
		try {
			File dir = null;
			if (xmlExeFlag)
				dir = new File(pathToMove + "/" + folderDt + "/Success");
			else
				dir = new File(pathToMove + "/" + folderDt + "/Failure");

			if (!dir.exists())
				dir.mkdirs();

			if (fName.renameTo(new File(dir.getPath() + "/" + xmlFileName + "_" + fileDt + ".xml"))) {
				Logger.logInfo(("File is moved successful!"));
			} else {
				Logger.logError(("File is failed to move!"));
			}
			if (!xmlExeFlag) {
				File logFile = new File(dir.getPath() + "/" + xmlFileName + "_" + fileDt + "_log.txt");
				logFile.createNewFile();
				writeLog(logFile.getPath(), msg);
			}

		} catch (Exception e) {
			Logger.logError(("Error occured during file movement!!"));
		}
	}

	private void writeLog(String logFileName, String msg) {
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			fw = new FileWriter(logFileName);
			bw = new BufferedWriter(fw);
			bw.write(msg);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {

			}
		}
	}

}       
