package sapphire.custom.ng.action;

import it.businesslogic.ireport.chart.Dataset;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.GenerateLabel;
import sapphire.custom.ng.sql.PrintLabel.PrintLabelSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;

/**
 * Created by shahbaz.khan on 11/28/2018.
 */
public class NGRegenerateLabel extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String labeleventid=properties.getProperty("labeleventid");
        //String labelinfo =Util.parseMessage(PrintLabelSql.GET_LabelEvent_Info, labeleventid);   // This is not working, so using the query in this action itself.
        String labelinfo =" select  lv.labeleventid,   lv.labelmethodid,lv.labelmethodversionid,lv.labelsdcid,lv.numcopies,lvi.itemkeyid1,\n" +
                "     case\n" +
                "     when lv.labelsdcid='Sample' then nvl((select distinct extractiontype from labvantage.u_sampletestcodemap\n" +
                "     where s_Sampleid=lvi.itemkeyid1),'Not Required') \n" +
                "     when  lvi.itemkeyid1 like 'DNA%' then 'DNA' when  lvi.itemkeyid1 like 'RNA%' then 'RNA' \n" +
                "     when  lvi.itemkeyid1 like 'TNA%' then 'TNA' when  (lvi.itemkeyid1 like 'Protein%' or lvi.itemkeyid1 like 'PROTEIN%') then 'Protein' \n" +
                "     when  lvi.itemkeyid1 like 'PLASMA%' then 'Plasma' else 'Not Required' end as extractiontype \n" +
                "     from labvantage.labelevent lv,labvantage.labeleventitem lvi \n" +
                "     where lv.labeleventid=lvi.labeleventid and lv.labeleventid ='" +labeleventid+ "' order by lv.labeleventid";
        DataSet dslabeleventinfo=getQueryProcessor().getSqlDataSet(labelinfo);
        if (dslabeleventinfo == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dslabeleventinfo.size() == 0) {
            String errmsg = getTranslationProcessor().translate("No label event information found for selected label event.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        String extractiontype =dslabeleventinfo.getValue(0,"extractiontype");
        String printerid="";
        if ("DNA".equalsIgnoreCase(extractiontype) || "TNA".equalsIgnoreCase(extractiontype) ||
                "RNA".equalsIgnoreCase(extractiontype) || "Plasma".equalsIgnoreCase(extractiontype)
                || "Protein".equalsIgnoreCase(extractiontype) ) {
            printerid = getColorPrinterIdForExtraction(extractiontype);
        } else {
            printerid = getPrinterId();
        }
        if (Util.isNull(printerid)) {
            throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                    " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                    "Or the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
            //return;
        }
        try {
            PropertyList prop = new PropertyList();
            prop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, dslabeleventinfo.getValue(0, "labelsdcid", ";"));
            prop.setProperty(GenerateLabel.PROPERTY_KEYID1, dslabeleventinfo.getColumnValues("itemkeyid1", ";"));
            prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, dslabeleventinfo.getValue(0,"labelmethodid", ";"));
            prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, dslabeleventinfo.getValue(0,"labelmethodversionid", ";"));
            prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
            prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
            prop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, dslabeleventinfo.getValue(0, "numcopies", ";"));
            getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
        }
    }
    /**
     * Description : This is for getting user's printer and department's default printer.
     *
     * @return
     * @throws SapphireException
     */
    private String getPrinterId() throws SapphireException {
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
        String sql = Util.parseMessage(PrintLabelSql.GET_Normal_Printer, userId, depratmentId, depratmentId);

        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo != null && dsInfo.size() > 0) {
            String userprinter = dsInfo.getValue(0, "userprinter", "");
            String deptprinter = dsInfo.getValue(0, "deptprinter", "");
            if (!Util.isNull(userprinter)) {
                printerId = userprinter;
            } else if (!Util.isNull(deptprinter)) {
                printerId = deptprinter;
            }
        }
        return printerId;
    }
    /**
     * Description : This is for getting user's color printer and department's default color printer.
     *
     * @param extractiontype
     * @return
     * @throws SapphireException
     */
    private String getColorPrinterIdForExtraction(String extractiontype) throws SapphireException {
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
        String sql = Util.parseMessage(PrintLabelSql.GET_Colour_Printer, userId, depratmentId, extractiontype, depratmentId, extractiontype);

        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo == null) {
            throw new SapphireException("Please contact your admin.Query failed.Sql:" + sql);
        }
        if (dsInfo.size() > 0) {
            String userprinter = dsInfo.getValue(0, "userprinter", "");
            String deptprinter = dsInfo.getValue(0, "deptprinter", "");
            if (!Util.isNull(userprinter)) {
                printerId = userprinter;
            } else if (!Util.isNull(deptprinter)) {
                printerId = deptprinter;
            } else {
                throw new SapphireException("Default " + extractiontype + " Printer is not defined for " + userId + " user in " + depratmentId + " department.");
            }
        } else {
            throw new SapphireException("Default " + extractiontype + " Printer is not defined for " + userId + " user in " + depratmentId + " department.");
        }
        return printerId;
    }
}