package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by ajha on 5/6/2016.
 * todo please provide action details
 */
public class CheckOutStorage extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String cassetteid = properties.getProperty("u_cassetteid");
        String queCassette= StringUtil.replaceAll(cassetteid,";","','");
        String sql = "select currentstorageunitid from trackitem where linkkeyid1 in ('"+queCassette+"') and linksdcid= 'Cassette') and linksdcid= 'Sample'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        updateTrackItem(cassetteid);

    }
    private void updateTrackItem(String cassetteid) throws SapphireException {
        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, cassetteid);
            props.setProperty("CURRENTSTORAGEUNITID", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }
        catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }
}
