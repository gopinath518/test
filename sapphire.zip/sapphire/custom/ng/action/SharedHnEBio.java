package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Shared HnE sample for FISH
 * @author debasis.mondal
 *
 */
public class SharedHnEBio extends BaseAction {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleids = properties.getProperty("keyid1");
		if (Util.isNull(sampleids)) {
			String errMsg = getTranslationProcessor().translate("Please scan a valid slide.");
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
		}
		validation(sampleids);
		updateType(sampleids);
	}

	/**
	 * Used for validate HnE sample or not.
	 * @param sampleids
	 * @throws SapphireException
	 */
	private void validation(String sampleids) throws SapphireException {
		String sqlType = Util.parseMessage(FishSqls.GET_TYPE, StringUtil.replaceAll(sampleids, ";", "','"));
		DataSet dsType = getQueryProcessor().getSqlDataSet(sqlType);
		if (dsType == null) {
			String errMsg = getTranslationProcessor()
					.translate("Something wrong happened. Contact your Administrator.");
			errMsg += "\nQuery returns null, Query failed:" + sqlType;
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
		if (dsType.size() == 0) {
			String errMsg = getTranslationProcessor().translate("No u_type found for the sample(s):" + sampleids);
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
		}
		for (String type : StringUtil.split(dsType.getColumnValues("u_type", ";"), ";")) {
			if (!"H".equalsIgnoreCase(type)) {
				String errMsg = getTranslationProcessor().translate("Please select H&E sample only.");
				throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
			}
		}
	}

	/**
	 * For update u_type in sample table
	 * @param sampleid
	 * @throws SapphireException
	 */
	private void updateType(String sampleid) throws SapphireException {
		PropertyList props = new PropertyList();
		try {
			props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
			props.setProperty("u_type", "SH");
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Can't update request in sample");
			error += ae.getMessage();
			throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
		}
	}
}
