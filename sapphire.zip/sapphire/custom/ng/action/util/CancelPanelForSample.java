package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CancelPanelForSample extends BaseAction {
	public static final String ID = "CancelPanelForSample";
	public static final String VERSIONID = "1";
	public static final String PROPERTY_SAMPLEID = "sampleid";
	public static final String PROPERTY_PANELID = "panelid";
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String sampleId = properties.getProperty("sampleid","");
		String panelId = properties.getProperty("panelid","");
		if("".equals(sampleId) || "".equals(panelId))
			throw new SapphireException("Sample Id and Panel Id is required to cancel Panel for Sample");
		
		cancelPanel(sampleId, panelId);
	}
	
	private void cancelPanel(String sampleId, String panelId) throws SapphireException {
		String sql = Util.parseMessage(CommonSql.GET_SAMPLEMAPID_BY_SAMPLE_AND_PANEL, constructInClause(sampleId, panelId));
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		PropertyList pl = new PropertyList();
		
		if(ds != null && ds.size() > 0){
			pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampletestcodemapid", ";"));
			pl.setProperty("teststatus", "Cancelled");
			
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		}
	}
	
	private String constructInClause(String sampleId, String panelId){
		String [] tempSampleArr = StringUtil.split(sampleId, ";");
		String [] tempPanelArr = StringUtil.split(panelId, ";");
		String inClause = "";
		for(int i =0; i<tempPanelArr.length; i++){
			inClause += sampleId+"@#"+tempPanelArr[i]+"','";
		}
		return inClause.substring(0,inClause.length()-3);
	}
}
