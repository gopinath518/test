package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.GenerateReport;
import sapphire.action.PrintReport;
import sapphire.action.SendMail;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

/**
 * Created by rrmandal on 2/10/2017.
 */
public class NGSendMail extends BaseAction {

    private static final String MAIL_CONFIG_POLICY_ID = "MailNotificationPolicy";

    public static final String ID = "NGSendMail";
    public static final String VERSIONID = "1";
    public static final String NODE_ID = "nodeid";
    public static final String EMAILTOLIST="emailtolist";//Optional
    public static final String EMAILFROM="emailfrom";//Optional
    public static final String EMAILCCLIST="emailcclist";//Optional
    public static final String KEYID1="keyid1";
    public static final String ACCESSIONID="accessionid";
    public static final String SUBJECTID="subjectid";
    public static final String PROJECTID="projectid";
    public static final String INVESTIGATOR_SITE_ID="investigatorsiteid";
    public static final String INVESTIGATOR_NAME="investigatorname";
    public static final String REPORTID="reportid";
    public static final String REPORTVERSIONIDID="reportversionidid";
    public static final String SAMPLEID="sampleid";
    public static final String BATCHID="batchid";
    public static final String MODE="mode";
    public static final String PARAM1_NAME="param1name";
    public static final String PARAM1_VAL="param1val";
    public static final String PARAM2_NAME="param2name";
    public static final String PARAM2_VAL="param2val";
    public static final String PARAM3_NAME="param3name";
    public static final String PARAM3_VAL="param3val";
    public static final String FILENAME="filename";
    public static final String SPONCER_NAME="sponcername";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String nodeid = properties.getProperty(NODE_ID,"");
        if(Util.isNull(nodeid))
            throw new SapphireException("Node Id for the policy "+MAIL_CONFIG_POLICY_ID+" is not found.");
        PropertyList mailConfigPolicy= getConfigurationProcessor().getPolicy(MAIL_CONFIG_POLICY_ID, nodeid);
        if(mailConfigPolicy==null)
            throw new SapphireException("Data from the "+MAIL_CONFIG_POLICY_ID+" policy cannot be obtained.");
        if(mailConfigPolicy.size()==0)
            throw new SapphireException("The policy "+MAIL_CONFIG_POLICY_ID+" is not properly defined for the nodeid "+nodeid);

        PropertyList mailconfigProp = mailConfigPolicy.getPropertyList("mailconfig");
        if(mailconfigProp==null || mailconfigProp.size()==0)
            throw new SapphireException("The policy "+MAIL_CONFIG_POLICY_ID+" is not properly defined for the nodeid "+nodeid);
        sendMail(properties,mailconfigProp,nodeid);

    }

    private void sendMail(PropertyList properties,PropertyList mailconfigProp,String nodeid) throws SapphireException{
        if(properties!=null && properties.size()>0 && mailconfigProp!=null && mailconfigProp.size()>0){
            String mailServerInfo = getConnectionProcessor().getConfigProperty( "com.labvantage.sapphire.server.smtphost" );

            if(Util.isNull(mailServerInfo))
                throw new SapphireException("Please provide the Mail Server info in the System Configuration under Miscellaneous Option tab.");

            String mode=properties.getProperty(MODE,"");
            String toList = getToEmailId(properties,mailconfigProp);
            String ccList = getCCEmailId(properties,mailconfigProp);
            String fromId = getFromEmailId(properties,mailconfigProp);
            String subject = mailconfigProp.getProperty("emailsubject","");

            if(Util.isNull(subject))
                throw new SapphireException("Subject cannot be obtained. Please configure the Subject property in the policy "+MAIL_CONFIG_POLICY_ID+" under the node "+nodeid+".");
            subject=getProperString(properties,subject);

            String body = mailconfigProp.getProperty("emailmessage","");
            if(Util.isNull(body))
                throw new SapphireException("Subject cannot be obtained. Please configure the Message property in the policy "+MAIL_CONFIG_POLICY_ID+" under the node "+nodeid+".");
            body=getProperString(properties,body);

            if(Util.isNull(toList))
                throw new SapphireException("To List is not found.Please configure the To List or To List By Query property in the policy "+MAIL_CONFIG_POLICY_ID+" " +
                        "under the node "+nodeid+" or please provide the value for the action property "+EMAILTOLIST+".");

            if(Util.isNull(fromId))
                throw new SapphireException("From Id is not found. Please configure the From Address or From Address By Query in the policy "+MAIL_CONFIG_POLICY_ID+" " +
                        "under the node "+nodeid+" or please provide the from address in the System Configuration under the Miscellaneous Option tab.");
            String fromIdArr[]=StringUtil.split(fromId,";");
            if(fromIdArr!=null && fromIdArr.length>1)
                throw new SapphireException("Multiple From Email Id obtained. Please specify the From Id either in From Address or specify the query returning the From Id " +
                        "in From Address By Query or in the System Configuration under the Miscellaneous Option tab.");

            if("SendMail".equalsIgnoreCase(mode)){
                PropertyList pl = new PropertyList();
                pl.setProperty(SendMail.PROPERTY_FROM,fromId);
                pl.setProperty(SendMail.PROPERTY_ADDRESS,toList);
                if(!Util.isNull(ccList))
                    pl.setProperty(SendMail.PROPERTY_CC,ccList);
                pl.setProperty(SendMail.PROPERTY_MESSAGE,body);
                pl.setProperty(SendMail.PROPERTY_SUBJECT,subject);
                pl.setProperty(SendMail.PROPERTY_MAILFORMAT, "html");
                getActionProcessor().processAction(SendMail.ID,SendMail.VERSIONID,pl);
            }
            else if("AttachReport".equalsIgnoreCase(mode)){
                String filename = properties.getProperty(FILENAME,"");
                PropertyList pl = new PropertyList();

                pl.setProperty(SendMail.PROPERTY_FROM,fromId);
                pl.setProperty(SendMail.PROPERTY_ADDRESS,toList);
                if(!Util.isNull(ccList))
                    pl.setProperty(SendMail.PROPERTY_CC,ccList);
                pl.setProperty(SendMail.PROPERTY_MESSAGE,body);
                pl.setProperty(SendMail.PROPERTY_SUBJECT,subject);
                pl.setProperty(SendMail.PROPERTY_MAILFORMAT, "html");
                pl.setProperty(SendMail.PROPERTY_FILENAME, filename);
                getActionProcessor().processAction(SendMail.ID,SendMail.VERSIONID,pl);
            }
        }

    }

    private String getToEmailId(PropertyList properties,PropertyList mailconfigProp) throws SapphireException{
        String resultToEmailId = "";
        if(properties!=null && properties.size()>0){
            String tempToList = properties.getProperty(EMAILTOLIST,"");
            if(!Util.isNull(tempToList))
                resultToEmailId+=";"+tempToList;
        }
        if(mailconfigProp!=null && mailconfigProp.size()>0){

            PropertyListCollection emailtolist = mailconfigProp.getCollection("emailtolist");
            if(emailtolist!=null && emailtolist.size()>0) {
                for (int i = 0; i < emailtolist.size(); i++) {
                    PropertyList tempPl = emailtolist.getPropertyList(i);
                    if (tempPl != null && tempPl.size() > 0) {
                        String tempToAddress = tempPl.getProperty("emailtoaddress", "");
                        if (!Util.isNull(tempToAddress))
                            resultToEmailId += ";" + tempToAddress;
                    }
                }
            }
            String emailtobyqry = mailconfigProp.getProperty("emailtobyqry","");
            if(!Util.isNull(emailtobyqry)){
                emailtobyqry=getProperString(properties,emailtobyqry);
                DataSet dsToAddressInfo = getQueryProcessor().getSqlDataSet(emailtobyqry);
                if(dsToAddressInfo!=null && dsToAddressInfo.size()>0) {
                    String colsArr[]=dsToAddressInfo.getColumns();
                    if(colsArr.length>1){
                        logger.info("Cannot obtained the To Email Address from the Query, as multiple columns found inthe select statement of the query");
                    }
                    else if(colsArr.length==1) {
                        resultToEmailId += ";" + dsToAddressInfo.getColumnValues(colsArr[0],";");
                    }
                }
            }

        }
        if(!Util.isNull(resultToEmailId)){
            if(resultToEmailId.startsWith(";"))
                resultToEmailId=resultToEmailId.substring(1);
        }

        return resultToEmailId;
    }


    private String getCCEmailId(PropertyList properties,PropertyList mailconfigProp) throws SapphireException{
        String resultCCEmailId = "";
        if(properties!=null && properties.size()>0){
            String tempCCList = properties.getProperty(EMAILCCLIST,"");
            if(!Util.isNull(tempCCList))
                resultCCEmailId+=";"+tempCCList;
        }
        if(mailconfigProp!=null && mailconfigProp.size()>0){

            PropertyListCollection emailcclist = mailconfigProp.getCollection("emailcclist");
            if(emailcclist!=null && emailcclist.size()>0) {
                for (int i = 0; i < emailcclist.size(); i++) {
                    PropertyList tempPl = emailcclist.getPropertyList(i);
                    if (tempPl != null && tempPl.size() > 0) {
                        String tempCCAddress = tempPl.getProperty("emailccaddress", "");
                        if (!Util.isNull(tempCCAddress))
                            resultCCEmailId += ";" + tempCCAddress;
                    }
                }
            }
            String emailccbyqry = mailconfigProp.getProperty("emailccbyqry","");
            if(!Util.isNull(emailccbyqry)){
                emailccbyqry=getProperString(properties,emailccbyqry);
                DataSet dsCCAddressInfo = getQueryProcessor().getSqlDataSet(emailccbyqry);
                if(dsCCAddressInfo!=null && dsCCAddressInfo.size()>0) {
                    String colsArr[]=dsCCAddressInfo.getColumns();
                    if(colsArr.length>1){
                        logger.info("Cannot obtained the CC Email Address from the Query, as multiple columns found in the select statement of the query");
                    }
                    else if(colsArr.length==1) {
                        resultCCEmailId += ";" + dsCCAddressInfo.getColumnValues(colsArr[0],";");
                    }
                }
            }

        }
        if(!Util.isNull(resultCCEmailId)){
            if(resultCCEmailId.startsWith(";"))
                resultCCEmailId=resultCCEmailId.substring(1);
        }

        return resultCCEmailId;
    }


    private String getFromEmailId(PropertyList properties,PropertyList mailconfigProp) throws SapphireException{
        String resultFromEmailId = "";
        if(properties!=null && properties.size()>0){
            String tempFromList = properties.getProperty(EMAILFROM,"");
            if(!Util.isNull(tempFromList))
                resultFromEmailId+=";"+tempFromList;
        }
        if(!Util.isNull(resultFromEmailId)){
            if(resultFromEmailId.startsWith(";"))
                resultFromEmailId=resultFromEmailId.substring(1);
            return resultFromEmailId;
        }
        if(mailconfigProp!=null && mailconfigProp.size()>0){
            String emailfromid = mailconfigProp.getProperty("emailfromid","");
            if(!Util.isNull(emailfromid)) {
                return emailfromid;
            }
            String emailfrombyqry = mailconfigProp.getProperty("emailfrombyqry","");
            if(!Util.isNull(emailfrombyqry)){
                emailfrombyqry=getProperString(properties,emailfrombyqry);
                DataSet dsFROMAddressInfo = getQueryProcessor().getSqlDataSet(emailfrombyqry);
                if(dsFROMAddressInfo!=null && dsFROMAddressInfo.size()>0) {
                    String colsArr[]=dsFROMAddressInfo.getColumns();
                    if(colsArr.length>1){
                        logger.info("Cannot obtained the From Email Address from the Query, as multiple columns found in the select statement of the query");
                    }
                    else if(colsArr.length==1) {
                        resultFromEmailId += ";" + dsFROMAddressInfo.getColumnValues(colsArr[0],";");
                    }
                }
            }

        }
        if(!Util.isNull(resultFromEmailId)){
            if(resultFromEmailId.startsWith(";"))
                resultFromEmailId=resultFromEmailId.substring(1);
        }
        else
            resultFromEmailId = getConnectionProcessor().getConfigProperty( "com.labvantage.sapphire.server.emailfromaddress" );

        return resultFromEmailId;
    }


    private String getProperString(PropertyList prop,String str){
        if(!Util.isNull(str) && prop!=null && prop.size()>0){
            String keyid1 = prop.getProperty(KEYID1,"");
            String accessionid = prop.getProperty(ACCESSIONID,"");
            String subjectid = prop.getProperty(SUBJECTID,"");
            String projectid = prop.getProperty(PROJECTID,"");
            String investigator = prop.getProperty(INVESTIGATOR_SITE_ID,"");
            String reportid = prop.getProperty(REPORTID,"");
            String reportVerid = prop.getProperty(REPORTVERSIONIDID,"");
            String sampleId = prop.getProperty(SAMPLEID,"");
            String batchid = prop.getProperty(BATCHID,"");
            String investigatorname = prop.getProperty(INVESTIGATOR_NAME,"");
            String sponcername = prop.getProperty(SPONCER_NAME,"");
            
            str= StringUtil.replaceAll(str,"[keyid1]",keyid1);
            str=StringUtil.replaceAll(str,"[currentuserid]",connectionInfo.getSysuserId());
            str=StringUtil.replaceAll(str,"[accessionid]",accessionid);
            str=StringUtil.replaceAll(str,"[subjectid]",subjectid);
            str=StringUtil.replaceAll(str,"[sampleid]",sampleId);
            str=StringUtil.replaceAll(str,"[projectid]",projectid);
            str=StringUtil.replaceAll(str,"[investigatorsiteid]",investigator);
            str=StringUtil.replaceAll(str,"[reportid]",reportid);
            str=StringUtil.replaceAll(str,"[reportversionid]",reportVerid);
            str=StringUtil.replaceAll(str,"[investigatorname]",investigatorname);
            str=StringUtil.replaceAll(str,"[batchid]",batchid);
            str=StringUtil.replaceAll(str,"[sponcername]",sponcername);
        }
        return str;
    }
}
