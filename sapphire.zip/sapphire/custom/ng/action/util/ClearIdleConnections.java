package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

/**
 * Created by smitra on 2/7/2017.
 */

/**
 * Deletes unwanted connections
 */
public class ClearIdleConnections extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String currentuser = connectionInfo.getSysuserId();
        String sql = "";
        if (currentuser != null) {
            sql = "delete from connection where tool='TDLProcessing' and sysuserid='" + currentuser + "'";
        } else {
            sql = "delete from connection where tool='TDLProcessing'";
        }
        getQueryProcessor().execSQL(sql);


    }
}
