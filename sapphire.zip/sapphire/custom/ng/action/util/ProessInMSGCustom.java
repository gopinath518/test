package sapphire.custom.ng.action.util;

import com.labvantage.sapphire.Trace;
import com.labvantage.sapphire.actions.messaging.ProcessInMessage;
import com.labvantage.sapphire.messaging.MessageLogUtil;
import com.labvantage.sapphire.services.ActionService;
import com.labvantage.sapphire.services.AutomationService;
import com.labvantage.sapphire.services.SapphireConnection;
import com.labvantage.sapphire.services.ServiceException;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.QueryProcessor;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by rrmandal on 10/27/2017.
 */
public class ProessInMSGCustom extends BaseAction {
    public static final String PROPERTY_MESSAGELOGID = "messagelogid";
    private StringBuffer processLog;

    public void processAction(PropertyList propertyList) throws SapphireException {
        String msgLogId = propertyList.getProperty(PROPERTY_MESSAGELOGID, "");
        String messageTypeId = propertyList.getProperty("messagetypeid", "");
        String message = propertyList.getProperty("message", "");
        String messageTag = propertyList.getProperty("messagetag", "");
        String processedBy;
        String processStatus;
        if(messageTag.length() == 0) {
            processedBy = propertyList.getProperty("tagpropertyid", "");
            if(processedBy.length() > 0) {
                processStatus = propertyList.getProperty(processedBy, "");
                propertyList.setProperty("messagetag", processStatus);
            }
        }

        processedBy = propertyList.getProperty("processedby", "");
        if(processedBy.length() == 0) {
            processedBy = this.connectionInfo.getSysuserId();
            propertyList.setProperty("processedby", processedBy);
        }

        if(processedBy.equalsIgnoreCase("(system)")) {
            propertyList.setProperty("processedby", "");
        }

        this.processLog = new StringBuffer();
        if(msgLogId.length() == 0) {
            if(message.length() == 0 || messageTypeId.length() == 0) {
                throw new ActionException("messagetypeid, message are mandatory properties");
            }

            DataSet processStatus1 = this.getMessageTypeDetails(this.getQueryProcessor(), messageTypeId);
            String processActionMode = propertyList.getProperty("processactionmode", "");
            if(processActionMode.length() == 0) {
                this.processLog.append("ProcessActionMode is not specified, assumed to be S\n");
                processActionMode = processStatus1.getString(0, "processactionflag", "S");
            }

            if("S".equals(processActionMode)) {
                this.processLog.append("Processing message Synchronously.\n");
                this.processMessageSync(propertyList, processStatus1);
            } else if("A".equals(processActionMode)) {
                this.processLog.append("Creating message log entry to be processed Asynchronously.\n");
                this.handleAsyncMessage(propertyList, processStatus1);
            } else if("M".equals(processActionMode)) {
                this.processLog.append("Creating message log entry to be manually processed.\n");
                this.handleManualMessage(propertyList, processStatus1);
            }
        } else {
            processStatus = MessageLogUtil.getProcessStatus(this.getQueryProcessor(), msgLogId);
            if("NOT STARTED".equals(processStatus)) {
                this.processLog.append("Message is being manually processed \n");
                this.processManualAsyncMessage(msgLogId, propertyList, "Manual message processed successfully.\n");
            } else if("WAITING".equals(processStatus)) {
                this.processLog.append("Message is being processed Asynchronously.\n");
                this.processManualAsyncMessage(msgLogId, propertyList, "Asynchronous message processed successfully.");
            } else {
                this.processLog.append("Reprocessing message.\n");
                this.reprocessMessage(msgLogId, propertyList);
            }
        }

    }

    private DataSet getMessageTypeDetails(QueryProcessor qp, String messageTypeId) throws ActionException {
        String sql = "SELECT directionflag, processactionid, processactionversionid, processactionflag, sendactionid, sendactionversionid, sendactionflag, allowreprocessflag, allowresendflag, messageclass, allowlogflag FROM messagetype WHERE messagetypeid=\'" + messageTypeId + "\'";
        DataSet result = qp.getSqlDataSet(sql);
        if(result != null && result.getRowCount() != 0) {
            return result;
        } else {
            throw new ActionException("Message Type details not found for messagetypeid: " + messageTypeId);
        }
    }

    private void processMessageSync(PropertyList propertyList, DataSet messageTypeInfo) {
        String allowLogFlag = messageTypeInfo.getString(0, "allowlogflag");
        String msgLogId = "";
        if("Y".equals(allowLogFlag)) {
            msgLogId = MessageLogUtil.addMsgLogEntry(this.getActionProcessor(), propertyList, messageTypeInfo.getString(0, "messageclass", ""), "IN");
            propertyList.setProperty(PROPERTY_MESSAGELOGID, msgLogId);
        }

        String processedBy = propertyList.getProperty("processedby");
        String processAction = messageTypeInfo.getString(0, "processactionid", "ProcessSECMessage");
        String processActionVersion = messageTypeInfo.getString(0, "processactionversionid", "1");

        try {
            this.processLog.append("Calling the processAction: ").append(processAction).append("\n");
            boolean processStatus = "Y".equals(propertyList.getProperty("processnotransaction"));
            if(!processStatus) {
                this.getActionProcessor().processAction(processAction, processActionVersion, propertyList, true);
            } else {
                SapphireConnection error = new SapphireConnection(this.database.getConnection(), this.connectionInfo);
                ActionService responseMessage = new ActionService(error);
                responseMessage.processAction(processAction, processActionVersion, propertyList);
            }

            if("FAILED".equals(propertyList.getProperty("status", "SUCCESS"))) {
                throw new ActionException(propertyList.getProperty("ErrorMsg", "Action not processed successfully"));
            }
        } catch (ActionException exp) {
            this.processLog.append("ERROR: processAction failed with exception" + exp.getMessage() + "\n");
            this.handleProcessActionException(exp, msgLogId, allowLogFlag, messageTypeInfo, propertyList);
            return;
        } catch (Exception exp) {
            this.processLog.append("ERROR: processAction failed.").append(exp.getMessage()).append("\n");
            MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "ERROR", propertyList.getProperty("customerrmsg", "Action not processed successfully"), propertyList.getProperty("processedby"), this.processLog.toString());
            propertyList.setProperty("status", "FAILED");
            propertyList.setProperty("error",propertyList.getProperty("ErrorMsg", "Action not processed successfully"));
            propertyList.setProperty("log", this.processLog.toString());
            return;
        }

        String processStatus1 = propertyList.getProperty("status", "SUCCESS");
        String error1 = propertyList.getProperty("error", "");
        String responseMessage1 = propertyList.getProperty("responsemessage", "");
        if(propertyList.getProperty("log", "").length() > 0) {
            this.processLog.append("processAction ").append(processAction).append(" returned Log:\n");
            this.processLog.append(propertyList.getProperty("log", ""));
        }

        this.processLog.append("processAction completed.\n");
        if(responseMessage1.length() > 0) {
            this.processLog.append("ProcessAction responseMessage returned is: \n");
            this.processLog.append(responseMessage1);
        } else {
            this.processLog.append("No responseMessage created by processAction.\n");
        }

        if(processStatus1.length() > 0 && processStatus1.equals("FAILED")) {
            MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "ERROR", error1, processedBy, this.processLog.toString());
        } else {
            MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "COMPLETE", "Incoming message processed successfully", processedBy, this.processLog.toString());
        }

        if(responseMessage1.length() != 0) {
            MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Response returned", responseMessage1, this.processLog.toString());
        }

        propertyList.setProperty("status", processStatus1);
        propertyList.setProperty("log", this.processLog.toString());
    }

    private String handleProcessActionException(ActionException e, String msgLogId, String allowLogFlag, DataSet messageTypeInfo, PropertyList propertyList) {
        String error = e.getMessage();
        if((msgLogId == null || msgLogId.length() == 0) && "F".equals(allowLogFlag)) {
            msgLogId = MessageLogUtil.addMsgLogEntry(this.getActionProcessor(), propertyList, messageTypeInfo.getString(0, "messageclass"), "IN");
            propertyList.setProperty("messagelogid", msgLogId);
        }

        if(e.getErrorHandler() != null && e.getErrorHandler().hasErrors()) {
            ErrorDetail errorDetail = (ErrorDetail)e.getErrorHandler().get(0);
            error = errorDetail.getMessage();
            if(error.endsWith("|")) {
                error = error.substring(0, error.lastIndexOf("|"));
            }

            this.processLog.append("processAction error: ").append(error).append("\n");
        }

        if(msgLogId != null) {
            MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "ERROR", error, propertyList.getProperty("processedby"), this.processLog.toString());
        }

        propertyList.setProperty("status", "FAILED");
        propertyList.setProperty("error", error);
        propertyList.setProperty("log", this.processLog.toString());
        return msgLogId;
    }

    private void handleAsyncMessage(PropertyList propertyList, DataSet messageTypeInfo) {
        String allowLogFlag = messageTypeInfo.getString(0, "allowlogflag", "Y");
        if(!"Y".equals(allowLogFlag)) {
            allowLogFlag = "Y";
            Trace.log("Ignoring setting for allowlogflag for asynchronous message processing request");
        }

        String msgLogId = MessageLogUtil.addMsgLogEntry(this.getActionProcessor(), propertyList, messageTypeInfo.getString(0, "messageclass", ""), "IN");
        propertyList.setProperty("messagelogid", msgLogId);
        this.processLog.append("Creating messagelog entry\n");
        MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "WAITING", "Added to todo list", this.processLog.toString());
        PropertyList asyncProps = new PropertyList();
        asyncProps.setProperty("messagelogid", msgLogId);
        asyncProps.setProperty("processedby", propertyList.getProperty("processedby"));
        AutomationService ac = new AutomationService(new SapphireConnection(this.database.getConnection(), this.connectionInfo));

        try {
            ac.addToDoListEntry((String)null, "ProcessInMessage", "1", asyncProps, (String)null, true);
            this.processLog.append("Added asynchronous message to todo list.\n");
            propertyList.setProperty("status", "SUCCESS");
            propertyList.setProperty("log", this.processLog.toString());
        } catch (ServiceException var8) {
            this.processLog.append("Failed to add message to todo list: ");
            this.processLog.append(var8.getMessage());
            this.processLog.append("\n");
            MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "ERROR", var8.getMessage(), this.processLog.toString());
            propertyList.setProperty("status", "FAILED");
            propertyList.setProperty("error", var8.getMessage());
            propertyList.setProperty("log", this.processLog.toString());
        }

    }

    private void handleManualMessage(PropertyList propertyList, DataSet messageTypeInfo) {
        String allowLogFlag = messageTypeInfo.getString(0, "allowlogflag");
        if(!"Y".equals(allowLogFlag)) {
            allowLogFlag = "Y";
            Trace.log("Ignoring setting for allowlogflag for manual message processing request");
        }

        String msgLogId = MessageLogUtil.addMsgLogEntry(this.getActionProcessor(), propertyList, messageTypeInfo.getString(0, "messageclass", ""), "IN");
        propertyList.setProperty("messagelogid", msgLogId);
        this.processLog.append("reated a log entry for manual message. Ready for processing.\n");
        MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "NOT STARTED", "To be executed manually", this.processLog.toString());
        propertyList.setProperty("status", "SUCCESS");
        propertyList.setProperty("log", this.processLog.toString());
    }

    private PropertyList loadOldPropertyList(String msgLogId, PropertyList propertyList) throws SapphireException {
        PropertyList oldProperties = MessageLogUtil.getPropertyList(this.getQueryProcessor(), msgLogId);
        Object[] keyes = oldProperties.keySet().toArray();

        for(int j = 0; j < keyes.length; ++j) {
            if(!keyes[j].toString().equals("processactionmode") && (!keyes[j].toString().equals("processedby") || propertyList.getProperty("processedby", "").length() <= 0)) {
                propertyList.setProperty((String)keyes[j], oldProperties.getProperty((String)keyes[j]));
            }
        }

        return propertyList;
    }

    private void reprocessMessage(String msgLogId, PropertyList propertyList) {
        DataSet messageTypeInfo = null;

        String responseMessage;
        String sendResponseAction;
        String sendResponseActionVersion;
        try {
            propertyList = this.loadOldPropertyList(msgLogId, propertyList);
            MessageLogUtil.updateReprocessInfo(this.getActionProcessor(), msgLogId, propertyList);
            responseMessage = propertyList.getProperty("messagetypeid");
            messageTypeInfo = this.getMessageTypeDetails(this.getQueryProcessor(), responseMessage);
            sendResponseAction = messageTypeInfo.getString(0, "processactionid", "ProcessSECMessage");
            sendResponseActionVersion = messageTypeInfo.getString(0, "processactionversionid", "1");
            this.getActionProcessor().processAction(sendResponseAction, sendResponseActionVersion, propertyList, true);
            if("FAILED".equals(propertyList.getProperty("status", "SUCCESS"))) {
                throw new ActionException(propertyList.getProperty("error", "Action not processed successfully"));
            }
        } catch (ActionException var11) {
            this.handleProcessActionException(var11, msgLogId, "Y", messageTypeInfo, propertyList);
            return;
        } catch (SapphireException var12) {
            this.processLog.append("processAction failed: ");
            this.processLog.append(var12.getMessage());
            this.processLog.append("\n");
            MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "ERROR", var12.getMessage(), this.processLog.toString());
            propertyList.setProperty("status", "FAILED");
            propertyList.setProperty("error", var12.getMessage());
            propertyList.setProperty("log", this.processLog.toString());
            return;
        }

        if(propertyList.getProperty("log", "").length() > 0) {
            this.processLog.append("\n");
            this.processLog.append("Reprocess log returned: \n");
            this.processLog.append("_________________________________________________________________\n");
            this.processLog.append(propertyList.getProperty("log"));
            this.processLog.append("_________________________________________________________________\n");
        }

        MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Message processed successfully", this.processLog.toString());
        responseMessage = propertyList.getProperty("responsemessage", "");
        if(responseMessage.length() != 0) {
            sendResponseAction = messageTypeInfo.getString(0, "sendactionid", "");
            sendResponseActionVersion = messageTypeInfo.getString(0, "sendactionversionid", "1");
            String sendResponseActionMode = messageTypeInfo.getString(0, "sendactionflag", "A");
            if(sendResponseAction.length() != 0) {
                try {
                    if("S".equals(sendResponseActionMode)) {
                        this.processLog.append("Sending response synchronously.\n");
                        this.getActionProcessor().processAction(sendResponseAction, sendResponseActionVersion, propertyList);
                        MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Response message sent successfully", responseMessage, this.processLog.toString());
                    } else {
                        this.processLog.append("Sending response asynchronously.\n");
                        AutomationService e = new AutomationService(new SapphireConnection(this.database.getConnection(), this.connectionInfo));
                        e.addToDoListEntry((String)null, sendResponseAction, sendResponseActionVersion, propertyList, (String)null, true);
                        MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Send Response request on todo list", responseMessage, this.processLog.toString());
                    }

                    propertyList.setProperty("status", "SUCCESS");
                    propertyList.setProperty("log", this.processLog.toString());
                } catch (ActionException var9) {
                    this.handleSendActionException(var9, msgLogId, "Y", messageTypeInfo, propertyList);
                } catch (ServiceException var10) {
                    this.processLog.append("Failed to send message. ").append(var10.getMessage()).append("\n");
                    MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "SENDERROR", var10.getMessage(), responseMessage, this.processLog.toString());
                    propertyList.setProperty("status", "FAILED");
                    propertyList.setProperty("error", var10.getMessage());
                    propertyList.setProperty("log", this.processLog.toString());
                }
            } else {
                Trace.log("No sendResponseAction specified");
                propertyList.setProperty("status", "SUCCESS");
                this.processLog.append("Reprocessed message successfully.\n");
                propertyList.setProperty("log", this.processLog.toString());
                MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Reprocessing completed", this.processLog.toString());
                MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "UNSENT", "No send action specified", responseMessage, this.processLog.toString());
            }
        } else {
            propertyList.setProperty("status", "SUCCESS");
            propertyList.setProperty("log", this.processLog.toString());
            MessageLogUtil.changeProcessStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Reprocessing completed", this.processLog.toString());
        }

    }

    private void processManualAsyncMessage(String msgLogId, PropertyList propertyList, String successMessage) {
        DataSet messageTypeInfo = null;

        String responseMessage;
        String sendResponseAction;
        String sendResponseActionVersion;
        try {
            propertyList = this.loadOldPropertyList(msgLogId, propertyList);
            responseMessage = propertyList.getProperty("messagetypeid");
            messageTypeInfo = this.getMessageTypeDetails(this.getQueryProcessor(), responseMessage);
            sendResponseAction = messageTypeInfo.getString(0, "processactionid", "ProcessSECMessage");
            sendResponseActionVersion = messageTypeInfo.getString(0, "processactionversionid", "1");
            this.processLog.append("Calling processAction ").append(sendResponseAction).append("\n");
            MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "PROCESSING", "Processing message", propertyList.getProperty("processedby"), this.processLog.toString());
            this.getActionProcessor().processAction(sendResponseAction, sendResponseActionVersion, propertyList, true);
        } catch (ActionException var12) {
            this.processLog.append("ERROR: processAction failed.").append(var12.getMessage()).append("\n");
            this.handleProcessActionException(var12, msgLogId, "Y", messageTypeInfo, propertyList);
            return;
        } catch (SapphireException var13) {
            this.processLog.append("ERROR: processAction failed.").append(var13.getMessage()).append("\n");
            MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "ERROR", var13.getMessage(), propertyList.getProperty("processedby"), this.processLog.toString());
            propertyList.setProperty("status", "FAILED");
            propertyList.setProperty("error", var13.getMessage());
            propertyList.setProperty("log", this.processLog.toString());
            return;
        }

        this.processLog.append("SUCCESS: processAction executed successfully.\n");
        if(propertyList.getProperty("log", "").length() > 0) {
            this.processLog.append(propertyList.getProperty("log"));
        }

        responseMessage = propertyList.getProperty("responsemessage", "");
        if(responseMessage.length() > 0) {
            this.processLog.append("processAction returned responseMessage: \n");
            this.processLog.append(responseMessage);
        }

        MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "COMPLETE", successMessage, propertyList.getProperty("processedby"), this.processLog.toString());
        if(responseMessage.length() != 0) {
            sendResponseAction = messageTypeInfo.getString(0, "sendactionid", "");
            sendResponseActionVersion = messageTypeInfo.getString(0, "sendactionversionid", "1");
            String sendResponseActionMode = messageTypeInfo.getString(0, "sendactionflag", "A");
            if(sendResponseAction.length() != 0) {
                try {
                    if("S".equals(sendResponseActionMode)) {
                        this.processLog.append("Sending response synchronously.\n");
                        this.getActionProcessor().processAction(sendResponseAction, sendResponseActionVersion, propertyList);
                        MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Response message sent successfully", responseMessage, this.processLog.toString());
                    } else {
                        this.processLog.append("Sending response asynchronously.\n");
                        AutomationService e = new AutomationService(new SapphireConnection(this.database.getConnection(), this.connectionInfo));
                        e.addToDoListEntry((String)null, sendResponseAction, sendResponseActionVersion, propertyList, (String)null, true);
                        MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "COMPLETE", "Send Response request on todo list", responseMessage, this.processLog.toString());
                    }

                    propertyList.setProperty("status", "SUCCESS");
                    propertyList.setProperty("log", this.processLog.toString());
                } catch (ActionException var10) {
                    this.handleSendActionException(var10, msgLogId, "Y", messageTypeInfo, propertyList);
                } catch (ServiceException var11) {
                    this.processLog.append("ERROR: Failed to process sendAction.").append(var11.getMessage()).append("\n");
                    MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "SENDERROR", var11.getMessage(), responseMessage, this.processLog.toString());
                    propertyList.setProperty("status", "FAILED");
                    propertyList.setProperty("error", var11.getMessage());
                    propertyList.setProperty("log", this.processLog.toString());
                }
            } else {
                Trace.log("No sendResponseAction specified");
                this.processLog.append("No sendAction specified\n");
                propertyList.setProperty("status", "SUCCESS");
                propertyList.setProperty("log", this.processLog.toString());
                MessageLogUtil.setProcessInfo(this.getActionProcessor(), msgLogId, "COMPLETE", "Manual processing completed", propertyList.getProperty("processedby"), this.processLog.toString());
                MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "UNSENT", "No send action specified", responseMessage, this.processLog.toString());
            }
        } else {
            propertyList.setProperty("status", "SUCCESS");
            propertyList.setProperty("log", this.processLog.toString());
        }

    }

    private String handleSendActionException(ActionException e, String msgLogId, String allowLogFlag, DataSet messageTypeInfo, PropertyList propertyList) {
        if((msgLogId == null || msgLogId.length() == 0) && "F".equals(allowLogFlag)) {
            msgLogId = MessageLogUtil.addMsgLogEntry(this.getActionProcessor(), propertyList, messageTypeInfo.getString(0, "messageclass"), "IN");
            propertyList.setProperty("messagelogid", msgLogId);
        }

        if(e.getErrorHandler() != null && e.getErrorHandler().hasErrors()) {
            ErrorDetail errorDetail = (ErrorDetail)e.getErrorHandler().get(0);
            String error = errorDetail.getMessage();
            if(error.endsWith("|")) {
                error = error.substring(0, error.lastIndexOf("|"));
            }

            this.processLog.append("sendAction error: ").append(error).append("\n");
            if(msgLogId != null) {
                MessageLogUtil.setSendStatus(this.getActionProcessor(), msgLogId, "SENDERROR", error, propertyList.getProperty("processedby"), this.processLog.toString());
            }

            propertyList.setProperty("status", "FAILED");
            propertyList.setProperty("error", error);
            propertyList.setProperty("log", this.processLog.toString());
        }

        return msgLogId;
    }
}
