package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class AutoCustodyTransfer extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid=properties.getProperty("sampleid","");
        String tramstop=properties.getProperty("tramstop","");

        updateSampleCustody(sampleid,tramstop);
    }

    private void updateSampleCustody(String sampleId,String tramstop)throws SapphireException{
        if(!Util.isNull(sampleId)){
            HashMap<String,String> sampleTRamMap=null;
            if(!Util.isNull(tramstop)){
                String sampleArr[]=StringUtil.split(sampleId,";");
                String tramArr[]=StringUtil.split(tramstop,";");
                if(sampleArr!=null && tramArr!=null){
                    sampleTRamMap=new HashMap<String,String>();
                    String sampleHvngNoTram="";
                    for (int i=0;i<sampleArr.length;i++){
                        if(i<tramArr.length){
                            if(Util.isNull(tramArr[i]))
                                sampleHvngNoTram+=";"+sampleArr[i];
                            else
                                sampleTRamMap.put(sampleArr[i],tramArr[i]);
                        }
                        else
                            sampleHvngNoTram+=";"+sampleArr[i];
                    }
                    if(!Util.isNull(sampleHvngNoTram)){
                        if(sampleHvngNoTram.startsWith(";"))
                            sampleHvngNoTram=sampleHvngNoTram.substring(1);
                        throw new SapphireException("Destination tramstop(s) are not mentioned for the below samples(s).\n"+sampleHvngNoTram);
                    }
                }
            }
            String currentuser=connectionInfo.getSysuserId();
            String currentUserDept=connectionInfo.getDefaultDepartment();
            if(!Util.isNull(currentuser) && !"(system)".equalsIgnoreCase(currentuser)){
                String sql=Util.parseMessage(CommonSql.SAMPLE_NOT_IN_GIVEN_USER_CUSTODY, StringUtil.replaceAll(sampleId,";","','"),currentuser);
                DataSet dsSampleTIInfo=getQueryProcessor().getSqlDataSet(sql);
                if(dsSampleTIInfo!=null && dsSampleTIInfo.size()>0){
                    String disputeSamples="";
                    dsSampleTIInfo.addColumn("tramstop",DataSet.STRING);

                    for(int i=0;i<dsSampleTIInfo.size();i++){
                        String sampleCustDept=dsSampleTIInfo.getValue(i,"custodialdepartmentid","");
                        if(!currentUserDept.equalsIgnoreCase(sampleCustDept))
                            disputeSamples += ";"+dsSampleTIInfo.getValue(i,"sampleid","");
                        else if(sampleTRamMap!=null && sampleTRamMap.size()>0)
                            dsSampleTIInfo.setValue(i,"tramstop",sampleTRamMap.get(dsSampleTIInfo.getValue(i,"sampleid","")));
                    }

                    if(!Util.isNull(disputeSamples)){
                        if(disputeSamples.startsWith(";"))
                            disputeSamples=disputeSamples.substring(1);
                        throw new SapphireException("Below sample(s) do not belong to the department of the current user.\n"+disputeSamples);
                    }

                    PropertyList pl=new PropertyList();
                    pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID,"Sample");
                    pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1,dsSampleTIInfo.getColumnValues("sampleid",";"));
                    pl.setProperty("custodialdepartmentid",StringUtil.repeat(currentUserDept,dsSampleTIInfo.size(),";"));
                    pl.setProperty("custodialuserid",StringUtil.repeat(currentuser,dsSampleTIInfo.size(),";"));
                    pl.setProperty("currentstorageunitid",StringUtil.repeat("(null)",dsSampleTIInfo.size(),";"));
                    if(!Util.isNull(tramstop))
                        pl.setProperty("u_currenttramstop", dsSampleTIInfo.getColumnValues("tramstop",";"));

                    getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID,pl);
                }
                 else {

                    if(!Util.isNull(tramstop)){
                        PropertyList pl=new PropertyList();
                        pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID,"Sample");
                        pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1,sampleId);
                        pl.setProperty("u_currenttramstop", tramstop);

                        getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID,pl);
                    }
                }
            }
        }
    }
}
