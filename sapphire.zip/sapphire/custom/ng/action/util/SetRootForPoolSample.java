package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by DMondal on 11/23/2016.
 * Description : This action only for pool sample.This will search root sample of parent samples,after creating pool sample
 * it will update root sample to the child sample.
 */
public class SetRootForPoolSample extends BaseAction {
    public static final String PARENT_SAMPLES = "parentsamples";
    public static final String CHILD_SAMPLE = "childsample";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String parentsamples = properties.getProperty(PARENT_SAMPLES, "");
        String childsample = properties.getProperty(CHILD_SAMPLE, "");
        String clientflag = properties.getProperty("clientflag","");
        if(!Util.isNull(clientflag) && "Y".equalsIgnoreCase(clientflag))
            setRootForClientSampleChildren(childsample);
        else {
            String[] parentsamplesArr = parentsamples.split(";");
            String[] childsampleArr = childsample.split(";");
            if (parentsamplesArr.length > 1 && childsampleArr.length > 1) {
                if (parentsamplesArr.length == childsampleArr.length) {
                    setRootSampleForSingalParent(parentsamples, childsample);//Multiple updation of root sample at a time.
                } else {
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Number of parent samples and Number of child samples are different.");
                }
            } else {
                setRootSampleForPool(parentsamples, childsample);//This will cater (i)pool parent sample and one child(ii)one parent one and child sample.
            }
        }
    }

    /**
     * Description : Update root for child samples which have been originated from Client samples
     *
     * @param childsamples
     * @throws SapphireException
     */
    private void setRootForClientSampleChildren( String childsamples) throws SapphireException{
        if(Util.isNull(childsamples))
            throw new SapphireException("Error: Child samples found to update");
        StringBuilder sb = new StringBuilder("select sourcesampleid, destsampleid from s_samplemap where destsampleid in ('");
        sb.append(StringUtil.replaceAll(childsamples,";","','"));
        sb.append("')");

        DataSet dsSql = getQueryProcessor().getSqlDataSet(sb.toString());
        if(dsSql == null)
            throw new SapphireException("Error: Unable to perform query in datatbase");
        if(dsSql.size() == 0)
            throw new SapphireException("Error: Child samples "+childsamples+" do not have any parent samples");
        else{
            String []arrChildSamples = childsamples.split(";");
            DataSet dsFinal = new DataSet();
            HashMap<String, String> hmFilter = new HashMap<>();
            for (int i = 0 ; i < arrChildSamples.length ; i++){
                hmFilter.clear();
                hmFilter.put("destsampleid", arrChildSamples[i]);
                DataSet dsFilter = dsSql.getFilteredDataSet(hmFilter);
                if(dsFilter.size() == 0)
                    throw new SapphireException("Error: Parent not found for "+arrChildSamples[i]);
                else
                    dsFinal.copyRow(dsFilter, 0 , 1);
            }

            if(dsFinal.size() == 0)
                throw new SapphireException("");
            else{
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("destsampleid", ";"));
                props.setProperty("u_rootsample", dsFinal.getColumnValues("sourcesampleid", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
        }
    }

    /**
     * Description : Multiple updation of root sample at a time.e.g:Parent sample like p1;p2;p3... and child should be c1;c2;c3...
     * This will cater only more than one parent and same number of child.
     * The method will search root sample of each parent and update to the child.
     *
     * @param parentsamples
     * @param childsamples
     * @throws SapphireException
     */
    private void setRootSampleForSingalParent(String parentsamples, String childsamples) throws SapphireException {
        DataSet dsRootForUpdate = new DataSet();
        dsRootForUpdate.addColumn("rootsample", DataSet.STRING);
        dsRootForUpdate.addColumn("parentsample", DataSet.STRING);
        dsRootForUpdate.addColumn("childsample", DataSet.STRING);

        String parentSample = StringUtil.replaceAll(parentsamples, ";", "','");
        String childSample = StringUtil.replaceAll(childsamples, ";", "','");
        String sqlroot = "select s.u_rootsample rootsample,s.s_sampleid parentsample,sm.destsampleid childsample from s_sample s,s_samplemap sm " +
                "where s.s_sampleid = sm.sourcesampleid and sm.sourcesampleid in  ('" + parentSample + "') and sm.destsampleid in  ('" + childSample + "')";
        DataSet dsRoot = getQueryProcessor().getSqlDataSet(sqlroot);
        if (dsRoot == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlroot;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        int incr = 0;
        String root = "";
        for (int i = 0; i < dsRoot.size(); i++) {
            incr = dsRootForUpdate.addRow();
            root = dsRoot.getValue(i, "rootsample");
            if (Util.isNull(root)) {
                root = dsRoot.getValue(i, "parentsample");
            }
            dsRootForUpdate.setValue(incr, "rootsample", root);
            dsRootForUpdate.setValue(incr, "parentsample", dsRoot.getValue(i, "parentsample"));
            dsRootForUpdate.setValue(incr, "childsample", dsRoot.getValue(i, "childsample"));
        }

        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsRootForUpdate.getColumnValues("childsample", ";"));
        props.setProperty("u_rootsample", dsRootForUpdate.getColumnValues("rootsample", ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

    }


    /**
     * Description : This method will search and update root sample of child.
     *
     * @param parentsamples
     * @param childsample
     * @throws SapphireException
     */
    private void setRootSampleForPool(String parentsamples, String childsample) throws SapphireException {
        String parentSample = StringUtil.replaceAll(parentsamples, ";", "','");
        String sqlroot = "select s.u_rootsample from s_sample s where s.s_sampleid in ('" + parentSample + "')";
        DataSet dsRoot = getQueryProcessor().getSqlDataSet(sqlroot);
        if (dsRoot == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlroot;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String root = "";
        root = Util.getUniqueList(dsRoot.getColumnValues("u_rootsample", ";"), ";", true);
        if (Util.isNull(root)) {
            //Parent have no root sample. Here Parent sample will be root of child.
            //1. parent can be multiple (FFPA for extraction tube )
            String[] parentSampleArr = parentsamples.split(";");
            if (parentSampleArr.length > 1) {
                root = findRootWhenParentisMultiple(parentSample);
            } else {
                //2. Parent can be one sample (Non FFPE for extraction tube )
                root = parentSample;
            }
        }

        if (!Util.isNull(root)) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, childsample);
            props.setProperty("u_rootsample", root);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

        }
    }

    /**
     * Description : When parent will be multiple this method will call to find root sample of parent.
     *
     * @param parentsamples
     * @return
     * @throws SapphireException
     */
    private String findRootWhenParentisMultiple(String parentsamples) throws SapphireException {
        String sqlGrandParent = "select s.u_rootsample from s_sample s,s_samplemap sm where sm.destsampleid in ('" + parentsamples + "') " +
                " and s.s_sampleid =sm.sourcesampleid";
        DataSet dsGrandParent = getQueryProcessor().getSqlDataSet(sqlGrandParent);
        if (dsGrandParent == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlGrandParent;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsGrandParent.size() == 0) {
            String errStr = getTranslationProcessor().translate("No root sample found for the sampleid:" + parentsamples);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String rootOfGrandParent = Util.getUniqueList(dsGrandParent.getColumnValues("u_rootsample", ";"), ";", true);
        return rootOfGrandParent;
    }
}
