package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.cyto.MoveSampleToCyto;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;
import java.util.Set;

public class MannualSampleRouting extends BaseAction {

    public static final String PROPERTY_SAMPLEID="sampleid";
    public static final String PROPERTY_DEPARTMENTID="departmentid";
    public static final String PROPERTY_SAMPLE_COL_TO_BE_MODIFIED="modsamplecol";

    PropertyList inputproperties=null;

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid=properties.getProperty(PROPERTY_SAMPLEID,"");
        String deptId=properties.getProperty(PROPERTY_DEPARTMENTID,"");
        if(Util.isNull(sampleid))
            throw new SapphireException("Sampleid cannot be obtained from the input.");
        if(Util.isNull(deptId))
            throw new SapphireException("Destination department cannot be obtained from the input.");
        inputproperties=properties;
        routeSample(sampleid,deptId);
        executeActionBeforeRouting(sampleid,deptId);
    }

    private  void routeSample(String sampleid,String deptId) throws SapphireException{
        if(!Util.isNull(sampleid) && !Util.isNull(deptId)){
            if(sampleid.startsWith(";"))
                sampleid=sampleid.substring(1);
            if(deptId.startsWith(";"))
                deptId=deptId.substring(1);

            String sampleIdArr[]= StringUtil.split(sampleid,";");
            String deptIdArr[]=StringUtil.split(deptId,";");
            if(sampleIdArr!=null && deptIdArr!=null){
                if(sampleIdArr.length!=deptIdArr.length)
                    throw new SapphireException("Destination department(s) cannot be obatined for all the sample(s)");

                DataSet result = new DataSet();
                result.addColumnValues("sampleid",DataSet.STRING,sampleid,";");
                result.addColumnValues("destdeptid",DataSet.STRING,deptId,";");
                result.addColumn("landingstep",DataSet.STRING);

                String currentDept=connectionInfo.getDefaultDepartment();
                String sql=Util.parseMessage(CommonSql.LANDINGSTEP_BY_DEPARTMENT,StringUtil.replaceAll(deptId+";"+currentDept,";","','"));
                DataSet landingStepInfoDs=getQueryProcessor().getSqlDataSet(sql);
                if(landingStepInfoDs==null)
                    throw new SapphireException("The below query cannot be executed.\n"+sql);
                if(landingStepInfoDs.size()==0)
                    throw new SapphireException("Below departments are invalid.\n"+deptId);

                HashMap<String,String> hmap=new HashMap<String,String>();

                DataSet disputedDeptDS=new DataSet();
                disputedDeptDS.addColumn("destdeptid",DataSet.STRING);
                disputedDeptDS.addColumn("errorreason",DataSet.STRING);
                disputedDeptDS.addColumn("sampleid",DataSet.STRING);

                hmap.clear();
                hmap.put("departmentid",currentDept);
                DataSet currDeptInfoDS=landingStepInfoDs.getFilteredDataSet(hmap);
                if(currDeptInfoDS==null || currDeptInfoDS.size()==0)
                    throw new SapphireException("Current user's logged in department info cannot be obtained");
                String currentSite=currDeptInfoDS.getValue(0,"u_site","");

                for(int i=0;i<result.size();i++){
                    String tempSampleid=result.getValue(i,"sampleid","");
                    if(!Util.isNull(sampleid)){
                        String tempDestDeptId=result.getValue(i,"destdeptid","");
                        if(Util.isNull(tempDestDeptId)){
                            int tempRowIndex=disputedDeptDS.addRow();
                            disputedDeptDS.setValue(tempRowIndex,"sampleid",tempSampleid);
                            disputedDeptDS.setValue(tempRowIndex,"errorreason","Department Id cannot be blank");
                        }
                        else{
                            hmap.clear();
                            hmap.put("departmentid",tempDestDeptId);
                            DataSet filtrDs=landingStepInfoDs.getFilteredDataSet(hmap);
                            if(filtrDs==null || filtrDs.size()==0){
                                int tempRowIndex=disputedDeptDS.addRow();
                                disputedDeptDS.setValue(tempRowIndex,"sampleid",tempSampleid);
                                disputedDeptDS.setValue(tempRowIndex,"destdeptid",tempDestDeptId);
                                disputedDeptDS.setValue(tempRowIndex,"errorreason","Department Id is not valid");
                            }
                            else{
                                String tempLandingStep=filtrDs.getValue(0,"u_landingstep","");
                                String tempSite=filtrDs.getValue(0,"u_site","");
                                if(Util.isNull(tempLandingStep)){
                                    int tempRowIndex=disputedDeptDS.addRow();
                                    disputedDeptDS.setValue(tempRowIndex,"sampleid",tempSampleid);
                                    disputedDeptDS.setValue(tempRowIndex,"destdeptid",tempDestDeptId);
                                    disputedDeptDS.setValue(tempRowIndex,"errorreason","Landing step cannot be obtained");
                                }
                                if(!Util.isNull(tempSite) && !tempSite.equalsIgnoreCase(currentSite)){
                                    int tempRowIndex=disputedDeptDS.addRow();
                                    disputedDeptDS.setValue(tempRowIndex,"sampleid",tempSampleid);
                                    disputedDeptDS.setValue(tempRowIndex,"destdeptid",tempDestDeptId);
                                    disputedDeptDS.setValue(tempRowIndex,"errorreason","Department doesn't belong to current site");
                                }
                                else{
                                    result.setValue(i,"landingstep",tempLandingStep);
                                }
                            }
                        }
                    }
                }
                if(disputedDeptDS!=null && disputedDeptDS.size()>0){
                    String msg = "Sample(s) cannot be routed due to the below reason(s).\nReason: " +
                            "<table border=1>" +
                            "<tr border=1><th>Sample Id</th><th>Department Id</th><th>Reason</th></tr>";
                    for (int i = 0; i < disputedDeptDS.size(); i++) {
                        msg += "<tr border=1><td>" + disputedDeptDS.getValue(i, "sampleid", "") + "</td>" +
                                "<td>" + disputedDeptDS.getValue(i, "destdeptid", "") + "</td>" +
                                "<td>" + disputedDeptDS.getValue(i, "errorreason", "") + "</td></tr>";
                    }
                    msg += "</table>";
                    throw new SapphireException(msg);
                }
                if(result!=null && result.size()>0){
                    performSampleUpdatesBeforeRouting(result);
                    otherSampleInfoUpdate(result);
                    PropertyList props=new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, result.getColumnValues("sampleid", ";"));
                    props.setProperty("u_currentmovementstep", result.getColumnValues("landingstep", ";"));
                    String reultColList[]=result.getColumns();
                    if(reultColList!=null && reultColList.length>0){
                        for (int i=0;i<reultColList.length;i++){
                            props.setProperty(reultColList[i],result.getColumnValues(reultColList[i],";"));
                        }
                    }
                    props.setProperty("bypassorgsampleedit", "Y");
                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,props);

                    props.clear();
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
                    prop.setProperty(EditTrackItem.PROPERTY_KEYID1,result.getColumnValues("sampleid", ";"));
                    prop.setProperty("custodialuserid",StringUtil.repeat("(null)",result.size(),";"));
                    prop.setProperty("u_currenttramstop",result.getColumnValues("landingstep", ";"));
                    prop.setProperty("custodialdepartmentid",result.getColumnValues("destdeptid", ";"));

                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID,prop);
                }
            }
        }
    }

    private void performSampleUpdatesBeforeRouting(DataSet result){
        if(result!=null && result.size()>0){
            String fromDept=connectionInfo.getDefaultDepartment();
            if(!Util.isNull(fromDept)){
                if (fromDept.endsWith("-Cyto")) {
                    if(!result.isValidColumn("u_cytorecvdt"))
                        result.addColumnValues("u_cytorecvdt",DataSet.STRING,"(null)",";");
                    if(!result.isValidColumn("u_cytorecvdby"))
                        result.addColumnValues("u_cytorecvdby",DataSet.STRING,"(null)",";");
                }
            }
        }
    }

    private  void otherSampleInfoUpdate(DataSet result){
        if(result!=null && result.size()>0 && inputproperties!=null && inputproperties.size()>0){
            String colsToModify=inputproperties.getProperty(PROPERTY_SAMPLE_COL_TO_BE_MODIFIED,"");
            if(!Util.isNull(colsToModify)){
                String colsToModifyArr[]=StringUtil.split(colsToModify,",");
                if(colsToModifyArr!=null && colsToModifyArr.length>0){
                    for(String tempCol:colsToModifyArr){
                        if(!Util.isNull(tempCol)){
                            result.addColumnValues(tempCol,DataSet.STRING,inputproperties.getProperty(tempCol),";");
                        }
                    }
                }
            }
        }
    }

    private void executeActionBeforeRouting(String sampleid,String destDept) throws SapphireException{
        if(!Util.isNull(sampleid) && !Util.isNull(destDept)) {
            PropertyList props = new PropertyList();
            String sampleArr[]=StringUtil.split(sampleid,";");
            String destDeptArr[]=StringUtil.split(destDept,";");

            if(sampleArr!=null && destDeptArr!=null && sampleArr.length==destDeptArr.length) {
                String cytoSamples="";
                String cytoresultDestDept="";

                for(int i=0;i<destDeptArr.length;i++) {
                    if (!Util.isNull(destDeptArr[i])) {
                        if (destDeptArr[i].endsWith("-Cyto")) {
                            cytoSamples+=";"+sampleArr[i];
                            if(Util.isNull(cytoresultDestDept))
                                cytoresultDestDept=destDeptArr[i];
                        }
                    }
                }

                if(!Util.isNull(cytoSamples)){
                    if(cytoSamples.startsWith(";"))
                        cytoSamples=cytoSamples.substring(1);
                    props.clear();
                    props.setProperty("sampleid", cytoSamples);
                    props.setProperty("sampleprefix", "CG" + cytoresultDestDept.substring(0, 1));
                    getActionProcessor().processAction("MoveSampleToCyto", MoveSampleToCyto.VERSION, props);
                }

            }
        }
    }
}
