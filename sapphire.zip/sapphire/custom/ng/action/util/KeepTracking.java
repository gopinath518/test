package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by msubhra on 7/4/2016.
 */
public class KeepTracking extends BaseAction {

    public String MANDATORY_INPUT_SAMPLE_ID = "";
    public String MANDATORY_INPUT_ToTramstop = "";
    public static final String ID = "KeepTracking";
    public static final String VERSIONID = "1";

    public void processAction(PropertyList properties) throws SapphireException{
        //String s_sampleid = properties.getProperty("s_sampleid");
        MANDATORY_INPUT_SAMPLE_ID = properties.getProperty("sampleid");
        MANDATORY_INPUT_ToTramstop = properties.getProperty("currenttramstop");
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String userDepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String sql = "select fromuser,touser,fromdate,todate,fromtramstop,totramstop from u_samplemovementsteps where sampleid in ('"+MANDATORY_INPUT_SAMPLE_ID+"')";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if(ds.size()== 0)
        {
            addSampleMovement(MANDATORY_INPUT_SAMPLE_ID,MANDATORY_INPUT_ToTramstop,currentUser,userDepartment);
        }
        else
        {
            updateSampleMovement(MANDATORY_INPUT_SAMPLE_ID,ds,currentUser,userDepartment,MANDATORY_INPUT_ToTramstop);
        }

    }

    /**
     *
     * @param sampleid
     * @param currenttramstop tramstop where user get the custody
     * @param currentUser     user who is taking custody
     * @param userdepartment  department for the user who is taking custody
     * @throws SapphireException
     */

    public void addSampleMovement (String sampleid,String currenttramstop,String currentUser,String userdepartment) throws  SapphireException
    {
        PropertyList props = new PropertyList();
        if(!Util.isNull(sampleid)) {

            try {
                props.setProperty(AddSDI.PROPERTY_SDCID, "SampleMovementSteps");
                props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(StringUtil.split(sampleid, ";").length));
                props.setProperty("sampleid", sampleid);
                props.setProperty("touser", currentUser);
                props.setProperty("todate", "n");
                props.setProperty("userdepartment", userdepartment);
                props.setProperty("totramstop", currenttramstop);

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);


            } catch (SapphireException ae) {
                String error = getTranslationProcessor().translate("Sample is not in track");
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }

        }
    }

    public void updateSampleMovement(String sampleid,DataSet ds,String currentUser,String userdepartment,String currentTramstop) throws  SapphireException {
        if (!Util.isNull(sampleid)) {
            String[] sampleids = StringUtil.split(sampleid, ";");


            HashMap<String, String> hm = new HashMap<String, String>();
            DataSet dsSampleMovement = new DataSet();
            dsSampleMovement.addColumn("sampleid", DataSet.STRING);
            dsSampleMovement.addColumn("fromuser", DataSet.STRING);
            dsSampleMovement.addColumn("touser", DataSet.STRING);
            dsSampleMovement.addColumn("fromdate", DataSet.DATE);
            dsSampleMovement.addColumn("todate", DataSet.DATE);
            dsSampleMovement.addColumn("fromtramstop", DataSet.STRING);
            dsSampleMovement.addColumn("totramstop", DataSet.STRING);
            dsSampleMovement.addColumn("userdepartment", DataSet.STRING);
            for (int i = 0; i < sampleids.length; i++) {
                hm.clear();
                hm.put("sampleid", sampleids[i]);
                DataSet dsfilter = ds.getFilteredDataSet(hm);
                if (dsfilter != null && dsfilter.size() > 0) {
                    String fromuser = dsfilter.getValue(0, "fromuser", "");
                    String touser = dsfilter.getValue(0, "touser", "");
                    String fromdate = dsfilter.getValue(0, "fromdate", "");
                    String todate = dsfilter.getValue(0, "todate", "");
                    String fromtramstop = dsfilter.getValue(0, "fromtramstop", "");
                    String totramstop = dsfilter.getValue(0, "totramstop", "");
                    int rowID = dsSampleMovement.addRow();
                    dsSampleMovement.setValue(rowID, "sampleid", sampleids[i]);
                    dsSampleMovement.setValue(rowID, "fromuser", touser);
                    dsSampleMovement.setValue(rowID, "touser", currentUser);
                    dsSampleMovement.setValue(rowID, "fromdate", todate);
                    dsSampleMovement.setValue(rowID, "todate", "n");
                    dsSampleMovement.setValue(rowID, "fromtramstop", totramstop);
                    dsSampleMovement.setValue(rowID, "totramstop", currentTramstop);
                    dsSampleMovement.setValue(rowID, "userdepartment", userdepartment);

                }
            }


            PropertyList p = new PropertyList();
            p.clear();
            p.setProperty(AddSDI.PROPERTY_SDCID, "SampleMovementSteps");
            p.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsSampleMovement.size()));
            p.setProperty("sampleid", dsSampleMovement.getColumnValues("sampleid", ";"));
            p.setProperty("fromuser", dsSampleMovement.getColumnValues("fromuser", ";"));
            p.setProperty("touser", dsSampleMovement.getColumnValues("touser", ";"));
            p.setProperty("fromdate", dsSampleMovement.getColumnValues("fromdate", ";"));
            p.setProperty("todate", dsSampleMovement.getColumnValues("todate", ";"));
            p.setProperty("fromtramstop", dsSampleMovement.getColumnValues("fromtramstop", ";"));
            p.setProperty("totramstop", dsSampleMovement.getColumnValues("totramstop", ";"));
            p.setProperty("userdepartment", dsSampleMovement.getColumnValues("userdepartment", ";"));

            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, p);
            } catch (SapphireException ae) {
                String error = getTranslationProcessor().translate("Can't update tracking of the samples");
                error += ae.getMessage();
                throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
            }

        }

    }

}
