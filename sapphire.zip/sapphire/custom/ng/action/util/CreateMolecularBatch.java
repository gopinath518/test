package sapphire.custom.ng.action.util;

import org.apache.poi.POIXMLDocument;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.util.ExcelParsing;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by rrmandal on 8/5/2016.
 */
public class CreateMolecularBatch extends BaseAction {

    private ArrayList<DataSet> elutionTubeDsArr = null;
    private ArrayList<DataSet> controlTubeDsArr = null;
    private ArrayList<DataSet> mmTubeDsArr = null;
    private ArrayList<DataSet> orgArr = null;
    private DataSet samplesInput = null;
    private DataSet ctrlInputs = null;
    private DataSet allControls = null;
    private HashMap<String, String> elusionDilutionMap = null;
    private HashMap<String, String> ctrlMap = null;
    private String copyFile = "";
    private String fileTemplateIdentifier = null;
    String isNGS = "N";
    String isCOBAS = "N";
    String isMicroArray = "N";

    private static final String POSITION_PROP = "position";
    private static final String CONTENTID_PROP = "contentid";
    private static final String CONTENTTYPE_PROP = "contenttype";
    private static final String TESTCODE_PROP = "testcode";
    private static final String ANALYTE_PROP = "analyte";
    private static final String VOLUME_PROP = "volume";
    private static final String DILUTION_PROP = "dilution";
    private static final String SAMPLEID_PROP = "sampleid";
    private static final String CONCENTRATION_PROP = "concentration";
    private static final String OPTIMALCONCENTRATION_PROP = "optimalconcentration";

    private static final String FILELOCATIONPOLICY = "FileLocationPolicy";
    private static final String NODEID = "MolecularDefaultLocation";
    private static final String PROPS_LOCATION = "location";
    private static final String PROPS_LOCATIONS = "locations";
    private long timeStamp;


    @Override
    /**
     * This action creates a new batch  and loads all the detail records coming from excel parsing/ edit an existing batch detail records with the records coming fro excel parsing.
     */
    public void processAction(PropertyList properties) throws SapphireException {
        String file = properties.getProperty("path", "");
        if (Util.isNull(file))
            throw new SapphireException("Plate map file is not found. Please upload a valid file.");

        if (file.indexOf(".xlsx") <= 0 && file.indexOf(".xls") <= 0)
            throw new SapphireException("Invalid file format obtained. Please upload plate map as an excel sheet format.");

        timeStamp = new Date().getTime();

        String batchid = properties.getProperty("batchid", "");
        String origin = properties.getProperty("origin", "");
        String batchname = properties.getProperty("batchname", "");
        String associateReagent = properties.getProperty("associatereagent", "Y");
        String pageid = properties.getProperty("pageid", "");
        String returntolistPage = properties.getProperty("returntolistpage", "");
        String batchmovestatus = properties.getProperty("batchmovestatus", "");
        String batchstatusview = properties.getProperty("batchstatusview", "");
        String batchtype = properties.getProperty("batchtype", "");
        copyFile = properties.getProperty("copyfile", "N");

        if (Util.isNull(batchid) && !Util.isNull(origin) && !Util.isNull(batchname))
            batchid = createBatch(batchname, origin, batchmovestatus, batchstatusview, batchtype);
        if (!Util.isNull(batchid)) {
            try {
                deleteBatchDetail(batchid);
                String fileName = new File(file).getName();
                String tokens[] = StringUtil.split(fileName, "_");
                fileTemplateIdentifier = tokens[0];
                if (tokens != null && tokens.length > 0) {
                    ExcelParsing.setQueryProcessor(getQueryProcessor());
                    if ("NGS".equalsIgnoreCase(tokens[0])) {
                        isNGS = "Y";
                        orgArr = ExcelParsing.parseNGSXLSFile(file);
                    } else if ("HVT".equalsIgnoreCase(tokens[0]))
                        orgArr = ExcelParsing.parseEGFRXLSXFile(file);
                    else if ("HVS".equalsIgnoreCase(tokens[0]))
                        orgArr = ExcelParsing.fileParseBCR(file);
                    else if ("HVTCOBAS".equalsIgnoreCase(tokens[0])) {
                        orgArr = ExcelParsing.parseCOBASXLSXFile(file);
                        isCOBAS="Y";
                    }
                    else if ("HVSH".equalsIgnoreCase(tokens[0]))
                        orgArr = ExcelParsing.fileParseBCRHybrid(file);
                    else if ("MT".equalsIgnoreCase(tokens[0]))
                        orgArr = ExcelParsing.parseMultiPlateXLSFile(file);
                    else if ("MCA".equalsIgnoreCase(tokens[0])) {
                        isMicroArray = "Y";
                        orgArr = ExcelParsing.parseEGFRXLSXFile(file);
                    } else {
                        throw new SapphireException("Invalid File Name. File name should have one of the below prefixes.\n" +
                                "<table border=1>" +
                                "<tr border=1><th>Prefix</th><th>Test Type</th></tr>" +
                                "<tr border=1><td>NGS_</td><td>NGS Testcode</td></tr>" +
                                "<tr border=1><td>MCA_</td><td>MicroArray Testcode</td></tr>" +
                                "<tr border=1><td>HVT_</td><td>High volume test having PCR analyte at the top</td></tr>" +
                                "<tr border=1><td>HVS_</td><td>High volume test having PCR analyte at right</td></tr>" +
                                "<tr border=1><td>HVSH_</td><td>High volume test having PCR analyte at right and also multi tests are being performed in some of the wells</td></tr>" +
                                "<tr border=1><td>MT_</td><td>High volume Multiple test</td></tr>" +
                                "</table>");
                    }
                }
                /*logger.info("================================dk1987===============================================");
                for(DataSet temp:orgArr) {
                    temp.showData();
                    logger.info("===============================================================================");
                }*/
                //logger.info("===============================================================================");

                if (orgArr != null && orgArr.size() > 0) {
                    validateData();
                    separateSampleAndCtrl();
                    String plates = createArray();

//                    if("Y".equalsIgnoreCase(isNGS) || "Y".equalsIgnoreCase(isMicroArray)){
                    if ("Y".equalsIgnoreCase(isNGS)) {
                        crtDilutionForNGS(plates, batchid);
                    } else
                        createDilutionTube(plates, batchid);

//                    if(!"Y".equalsIgnoreCase(isNGS) && !"Y".equalsIgnoreCase(isMicroArray)) {
                    if (!"Y".equalsIgnoreCase(isNGS)) {
                        createControlSample(plates, batchid);
                        if ("Y".equalsIgnoreCase(associateReagent))
                            associatingMMToBatch(batchid);
                    }

                    associatePlateWithBatch(plates, batchid);
                    attachPlateMap(batchid, file);
                    if (!Util.isNull(pageid)) {
                        String url = "<script>sapphire.page.navigate('rc?command=page&page=" + pageid + "&sdcid=NGBatch&mode=Edit&keyid1=" + batchid + "&returntolistpage=" + returntolistPage + "', 'Y', '_top')</script>";
                        properties.setProperty("msg", url);
                        properties.setProperty("batchid", batchid);
                    }
                }
            } catch (Exception exp) {
                throw new SapphireException("Batch cannot be created.\nError: " + exp.getMessage());
            }

            //added for root set
            String allElusion = "";
            String allDilusion = "";
            if (elusionDilutionMap.size() > 0) {
                Set<String> keySet = elusionDilutionMap.keySet();
                for (String elusion : keySet) {
                    String dilusion = elusionDilutionMap.get(elusion);
                    int index = elusion.indexOf("@");
                    if (index >= 0)
                        elusion = elusion.substring(0, index);
                    allElusion = allElusion + ";" + elusion;
                    allDilusion = allDilusion + ";" + dilusion;
                }
                String elusionTubes = allElusion.substring(1);
                String dilusionTubes = allDilusion.substring(1);
                //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples/Single parent -------------------
                Util.setRootForPoolSample(dilusionTubes, elusionTubes, getTranslationProcessor(), getActionProcessor());
                //End----------------------------------------------------------------------------------------------------------------------------------------------------
            }
        }
    }

    private void checkValidFileFormat(String file) throws SapphireException {
        boolean result = false;
        BufferedInputStream bis = null;
        try {
            bis = new BufferedInputStream(new FileInputStream(file));
            boolean isXlsx = POIXMLDocument.hasOOXMLHeader(bis);
            bis.reset();
            boolean isXls = POIFSFileSystem.hasPOIFSHeader(bis);

            if (!isXlsx && !isXls) {
                throw new SapphireException("Invalid file format obtained. Please upload plate map as an excel sheet format.");
            }
        } catch (FileNotFoundException e) {
            throw new SapphireException(e.getMessage());
        } catch (IllegalArgumentException e) {
            throw new SapphireException(e.getMessage());
        } catch (IOException e) {
            throw new SapphireException(e.getMessage());
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    logger.error(e.getMessage());
                }
            }
        }
    }

    /**
     * This method validate the data those are coming from excel file.
     * Validations are: 1. Valid extraction id
     * 2. Valid control Id
     * 3. Valid ReagentLot Id
     *
     * @throws SapphireException
     */
    private void validateData() throws SapphireException {
        if (orgArr != null && orgArr.size() > 0) {
            for (int i = 0; i < orgArr.size(); i++) {
                DataSet tempDs = orgArr.get(i);
                if (tempDs != null && tempDs.size() > 0) {
                    if ("Y".equalsIgnoreCase(isNGS))
                        Util.validateNGSPlateDataSet(tempDs, getQueryProcessor());
//                    else if("Y".equalsIgnoreCase(isMicroArray)){
//                        Util.validateMicroArrayDataSet(tempDs,getQueryProcessor());
//                    }
                    else
                        Util.validationForPlateLoadFromExcel(tempDs, getQueryProcessor(), getConfigurationProcessor());

                    /** Testing :: Recording value in log*/
                    logger.info("================================dk1987===============================================");
                    tempDs.showData();
                    logger.info("===============================================================================");
                }
            }
        }
    }

    /**
     * This method creates a new molecular batch
     *
     * @param batchname
     * @param origin
     * @param batchmovestatus
     * @return
     * @throws SapphireException
     */

    private String createBatch(String batchname, String origin, String batchmovestatus, String batchstatusview, String batchtype) throws SapphireException {
        /*if ("Normalization".equalsIgnoreCase(origin)) {
            String sql = "select batchname from u_ngbatch where batchname='" + batchname + "'";
            DataSet dsBatchName = getQueryProcessor().getSqlDataSet(sql);
            if (dsBatchName != null && dsBatchName.size() > 0) {
                String error = getTranslationProcessor().translate(batchname + " already exist into the system,please give another name.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }*/
        Util.validateDuplicateBatchName(batchname, origin, getQueryProcessor());
        String ngbatchid = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchname", batchname);
        pl.setProperty("origin", origin);
        pl.setProperty("batchmovestatus", batchmovestatus);
        pl.setProperty("batchstatusview", batchstatusview);
        pl.setProperty("batchtype", batchtype);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }

    /**
     * This method seperates the extraction tubes, controls and mastermixes and creates different arraylist for each of those
     */

    private void separateSampleAndCtrl() {
        if (orgArr != null && orgArr.size() > 0) {
            HashMap<String, String> hmap = new HashMap<String, String>();
            for (int i = 0; i < orgArr.size(); i++) {
                DataSet tempDs = orgArr.get(i);
                int plateno = i;
                if (tempDs != null && tempDs.size() > 0) {
                    if (!tempDs.isValidColumn("plateno"))
                        tempDs.addColumn("plateno", DataSet.NUMBER);
                    tempDs.setNumber(-1, "plateno", plateno);
                    hmap.clear();
                    hmap.put(CONTENTTYPE_PROP, "Sample");
                    DataSet dsFiltr = tempDs.getFilteredDataSet(hmap);
                    if (dsFiltr != null && dsFiltr.size() > 0) {
                        if (elutionTubeDsArr == null)
                            elutionTubeDsArr = new ArrayList<DataSet>();
                        elutionTubeDsArr.add(dsFiltr);
                        if (samplesInput == null)
                            samplesInput = new DataSet();
                        samplesInput.copyRow(dsFiltr, -1, 1);

                    }
                    hmap.clear();
                    hmap.put(CONTENTTYPE_PROP, "Control");
                    dsFiltr = tempDs.getFilteredDataSet(hmap);
                    if (dsFiltr != null && dsFiltr.size() > 0) {
                        if (controlTubeDsArr == null)
                            controlTubeDsArr = new ArrayList<DataSet>();
                        controlTubeDsArr.add(dsFiltr);
                        if (allControls == null)
                            allControls = new DataSet();
                        allControls.copyRow(dsFiltr, -1, 1);
                        if (ctrlInputs == null)
                            ctrlInputs = new DataSet();
                        ctrlInputs.copyRow(dsFiltr, -1, 1);
                    }
                    hmap.clear();
                    hmap.put(CONTENTTYPE_PROP, "MasterMix");
                    dsFiltr = tempDs.getFilteredDataSet(hmap);
                    if (dsFiltr != null && dsFiltr.size() > 0) {
                        if (mmTubeDsArr == null)
                            mmTubeDsArr = new ArrayList<DataSet>();
                        mmTubeDsArr.add(dsFiltr);
                    }
                }
            }
        }
    }

    /**
     * This method creates one plate for each arraymethod specified in the global array ARRAYMETHODS_VAL
     * and returns the newly created arrayids.
     *
     * @return
     */

    private String createArray() throws SapphireException {
        String newArrays = "";
        if (orgArr != null && orgArr.size() > 0) {
            PropertyList plCrtArr = new PropertyList();
            DataSet dsPlate = new DataSet();
            dsPlate.addColumn("plateid", DataSet.STRING);
            dsPlate.addColumn("desc", DataSet.STRING);
            dsPlate.addColumn("sequencing", DataSet.STRING);
            for (int i = 0; i < orgArr.size(); i++) {
                DataSet dsTemp = orgArr.get(i);
                String desc = "";
                String seq = "";
                if (dsTemp != null && dsTemp.size() > 0) {
                    String direction = dsTemp.getColumnValues("direction", ";");
                    if (!Util.isNull(direction))
                        direction = Util.getUniqueList(direction, ";", true);
                    String directionArr[] = null;
                    if (!Util.isNull(direction))
                        directionArr = StringUtil.split(direction, ";");
                    if (directionArr != null && directionArr.length > 0) {
                        if (directionArr.length == 1) {
                            if ("F".equalsIgnoreCase(direction)) {
                                desc = "Forward Sequencing Plate";
                                seq = "F";
                            } else if ("R".equalsIgnoreCase(direction)) {
                                desc = "Reverse Sequencing Plate";
                                seq = "R";
                            }
                        } else if (directionArr.length > 1) {
                            desc = "Forward & Reverse Sequencing Plate";
                            seq = "FR";
                        }
                    }
                }
                try {
                    plCrtArr.clear();
                    plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYMETHODID, "NGPlateArrayMethod");
                    plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYMETHODVERSIONID, "1");
                    plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYLAYOUTID, "NGPlateLayout");
                    plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYLAYOUTVERSIONID, "1");
                    plCrtArr.setProperty(CreateArray.PROPERTY_COPIES, "1");
                    getActionProcessor().processAction(CreateArray.ID, CreateArray.VERSIONID, plCrtArr);
                    String newTempArry = plCrtArr.getProperty(CreateArray.RETURN_ARRAYID, "");
                    newArrays += ";" + newTempArry;

                    int index = dsPlate.addRow();
                    dsPlate.setValue(index, "plateid", newTempArry);
                    dsPlate.setValue(index, "desc", desc);
                    dsPlate.setValue(index, "sequencing", seq);

                } catch (Exception e) {
                    logger.debug("Error is getting generated from createArray method of the action CreateNormalizationBatch. Reason: " + e.getMessage());
                    throw new SapphireException("Plate creation cannot be possible.\nReason: " + e.getMessage());
                }
            }
            if (!Util.isNull(newArrays)) {
                if (newArrays.startsWith(";"))
                    newArrays = newArrays.substring(1);
            }
            if (dsPlate != null && dsPlate.size() > 0) {
                PropertyList propEdit = new PropertyList();
                propEdit.setProperty(EditSDI.PROPERTY_SDCID, "LV_Array");
                propEdit.setProperty(EditSDI.PROPERTY_KEYID1, dsPlate.getColumnValues("plateid", ";"));
                propEdit.setProperty("arraydesc", dsPlate.getColumnValues("desc", ";"));
                propEdit.setProperty("u_sequencing", dsPlate.getColumnValues("sequencing", ";"));

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propEdit);
            }
        }
        return newArrays;
    }


    /**
     * This method creates dilution tubes for NGS workflow.
     * This method creates dilution tubes for each well where samples are being put from the elusion tubes
     * Assumption: Same elusion tube is not repeated in different plates of the plate for NGS. This is because they don't want to track analytes for NGS.
     * So we can assume that for NGS, tests not being performed per analyte.So there is no point of putting samples in different well from same elusion tube
     *
     * @param plates
     * @param batchid
     * @throws SapphireException
     */

    private void crtDilutionForNGS(String plates, String batchid) throws SapphireException {
        if (elutionTubeDsArr != null && elutionTubeDsArr.size() > 0) {
            DataSet result = new DataSet();
            String elutionTubes = "";
            for (int i = 0; i < elutionTubeDsArr.size(); i++) {
                DataSet tempDS = elutionTubeDsArr.get(i);
                if (tempDS != null && tempDS.size() > 0) {
                    result.copyRow(tempDS, -1, 1);
                }
            }
            if (result != null && result.size() > 0) {
                for (int i = 0; i < result.size(); i++) {
                    elutionTubes += ";" + result.getValue(i, SAMPLEID_PROP, "");
                }
                if (!Util.isNull(elutionTubes) && elutionTubes.startsWith(";"))
                    elutionTubes = elutionTubes.substring(1);

                PropertyList prop = new PropertyList();
                prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", result.size(), ";"));
                prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_pathologycomments;u_extractioncomments");
                prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, result.getColumnValues(SAMPLEID_PROP, ";"));
                prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
                prop.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
                getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);

                String dilutionTubes = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
                String elArr[] = StringUtil.split(elutionTubes, ";");
                String dlArr[] = StringUtil.split(dilutionTubes, ";");

                if (elArr != null && dlArr != null && elArr.length == dlArr.length) {
                    if (elusionDilutionMap == null)
                        elusionDilutionMap = new HashMap<String, String>();
                    for (int i = 0; i < elArr.length; i++) {
                        elusionDilutionMap.put(elArr[i], dlArr[i]);
                    }
                }
                if (elusionDilutionMap != null && elusionDilutionMap.size() > 0) {
                    result.clear();
                    for (int i = 0; i < elutionTubeDsArr.size(); i++) {
                        DataSet dsTemp = elutionTubeDsArr.get(i);
                        if (dsTemp != null && dsTemp.size() > 0) {
                            if (!dsTemp.isValidColumn("childsample"))
                                dsTemp.addColumn("childsample", DataSet.STRING);
                            if (!dsTemp.isValidColumn(DILUTION_PROP))
                                dsTemp.addColumn(DILUTION_PROP, DataSet.STRING);
                            for (int j = 0; j < dsTemp.size(); j++) {
                                String elTubeId = dsTemp.getValue(j, SAMPLEID_PROP, "");
                                dsTemp.setValue(j, "childsample", elusionDilutionMap.get(elTubeId));

                                String existingDilution = dsTemp.getValue(j, DILUTION_PROP, "");
                                if (Util.isNull(existingDilution)) {
                                    double optimalconcentration = Double.parseDouble(dsTemp.getValue(j, OPTIMALCONCENTRATION_PROP, "0"));
                                    double sampleConc = Double.parseDouble(dsTemp.getValue(j, CONCENTRATION_PROP, "0"));
                                    String concRatio = Util.calculateConcentrationRatio(sampleConc, optimalconcentration);
                                    dsTemp.setValue(j, DILUTION_PROP, concRatio);
                                }
                            }
                            result.copyRow(dsTemp, -1, 1);
                        }
                    }
                    if (result != null && result.size() > 0) {
                        PropertyList props = new PropertyList();

                        props.clear();
                        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                        props.setProperty(EditTrackItem.PROPERTY_KEYID1, result.getColumnValues("childsample", ";"));
                        props.setProperty("containertypeid", "Dilution Tube");
//                        props.setProperty("custodialdepartmentid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
//                        props.setProperty("custodialuserid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);


                        loadContentIntoPlate(plates, "Sample");
                        addTestCodeToDilutions(result);
                        assgnDIlutionAndOptimalConc(result);
                        calculateQtyForElusionAndDIlutionTubes(result, SAMPLEID_PROP, "childsample");

                        props.clear();
                        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                        props.setProperty("sampleid", result.getColumnValues("childsample", ";"));
                        if (result.isValidColumn(ANALYTE_PROP))
                            props.setProperty("analyte", result.getColumnValues(ANALYTE_PROP, ";"));
                        props.setProperty("testcodeid", result.getColumnValues(TESTCODE_PROP, ";"));
                        props.setProperty("tagid", result.getColumnValues("seqtag", ";"));
                        props.setProperty("position", result.getColumnValues(POSITION_PROP, ";"));
                        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                    }
                }
            }
        }
    }

    /**
     * This method creates dilution tubes for molecular workflow.
     * Here the samples are created in such a order so that in the reporting page the samples are coming vertically across the plates in which tehy are being placed.
     * Also here for each sample,test,dilution one sample will be created.
     *
     * @param plates
     * @param batchid
     * @throws SapphireException
     */


    private void createDilutionTube(String plates, String batchid) throws SapphireException {
        if (elutionTubeDsArr != null && elutionTubeDsArr.size() > 0) {
            DataSet result = null;
            for (int i = 0; i < elutionTubeDsArr.size(); i++) {
                DataSet dsTemp = elutionTubeDsArr.get(i);
                if (dsTemp != null && dsTemp.size() > 0) {
                    if (!dsTemp.isValidColumn(DILUTION_PROP))
                        dsTemp.addColumn(DILUTION_PROP, DataSet.STRING);
                    for (int j = 0; j < dsTemp.size(); j++) {
                        String existingDilution = dsTemp.getValue(j, DILUTION_PROP, "");
                        if (Util.isNull(existingDilution)) {
                            double optimalconcentration = Double.parseDouble(dsTemp.getValue(j, OPTIMALCONCENTRATION_PROP, "0"));
                            double sampleConc = Double.parseDouble(dsTemp.getValue(j, CONCENTRATION_PROP, "0"));
                            String concRatio = Util.calculateConcentrationRatio(sampleConc, optimalconcentration);
                            dsTemp.setValue(j, DILUTION_PROP, concRatio);
                        }
                    }
                    if (result == null)
                        result = new DataSet();
                    result.copyRow(dsTemp, -1, 1);
                }
            }
            if (result != null && result.size() > 0) {
                PropertyList props = new PropertyList();
                String elusionTubes = "";
                String dilutionTubes = "";
                try {
//Create child samples from the elution tubes
                    if (result != null && result.size() > 0) {
                        DataSet dsCrtHild = result.copy();
                        dsCrtHild.sort(SAMPLEID_PROP + "," + TESTCODE_PROP);
                        ArrayList<DataSet> dsCrtChildArr = dsCrtHild.getGroupedDataSets(SAMPLEID_PROP + "," + TESTCODE_PROP + "," + DILUTION_PROP);
                        if (dsCrtChildArr != null && dsCrtChildArr.size() > 0) {
                            dsCrtHild.clear();
                            dsCrtHild.addColumn("childkeyid1", DataSet.STRING);
                            String disputedExtId = "";
                            DataSet dsExtTubeHvngSmAnalyteMulti = null;
                            LinkedList<String> listExtTubeHvngSmAnalyteMulti = null;
                            for (int i = 0; i < dsCrtChildArr.size(); i++) {
                                DataSet dsTemp = dsCrtChildArr.get(i);
                                if (dsTemp != null && dsTemp.size() > 0) {
                                    dsTemp.sort("plateno,ypos,xpos");
                                    //need to sort by ypos,xpos
                                    String parntSampleId = dsTemp.getValue(0, SAMPLEID_PROP, "");
                                    if (Util.isNull(parntSampleId))
                                        disputedExtId += ";" + dsTemp.getValue(0, CONTENTID_PROP, "");
                                    else {
                                        String testCode = dsTemp.getValue(0, TESTCODE_PROP, "");
                                        String dilution = dsTemp.getValue(0, DILUTION_PROP, "");
                                        String plateno = dsTemp.getValue(0, "plateno", "");
                                        String xpos = dsTemp.getValue(0, "xpos", "");
                                        String ypos = dsTemp.getValue(0, "ypos", "");
                                        String pseudopos = dsTemp.getValue(0, "pseudopos", "");

                                        if (!"Y".equalsIgnoreCase(isMicroArray)) {
                                            DataSet tempDS = dsTemp.copy();
                                            tempDS.sort("direction");
                                            ArrayList<DataSet> tempDSArr = tempDS.getGroupedDataSets("direction");
                                            tempDS.clear();
                                            for (int index1 = 0; index1 < tempDSArr.size(); index1++) {
                                                tempDS = tempDSArr.get(index1);
                                                String analytes = tempDS.getColumnValues(ANALYTE_PROP, ";");
                                                String analytesArr[] = StringUtil.split(analytes, ";");
                                                if (listExtTubeHvngSmAnalyteMulti != null)
                                                    listExtTubeHvngSmAnalyteMulti.clear();
                                                for (int k = 0; k < analytesArr.length - 1; k++) {
                                                    for (int l = k + 1; l < analytesArr.length; l++) {
                                                        if (analytesArr[k].equalsIgnoreCase(analytesArr[l])) {
                                                            if (listExtTubeHvngSmAnalyteMulti == null)
                                                                listExtTubeHvngSmAnalyteMulti = new LinkedList<String>();
                                                            if (dsExtTubeHvngSmAnalyteMulti == null) {
                                                                dsExtTubeHvngSmAnalyteMulti = new DataSet();
                                                                dsExtTubeHvngSmAnalyteMulti.addColumn("extractionid", DataSet.STRING);
                                                                dsExtTubeHvngSmAnalyteMulti.addColumn("analyte", DataSet.STRING);
                                                                dsExtTubeHvngSmAnalyteMulti.addColumn("dilution", DataSet.STRING);
                                                                dsExtTubeHvngSmAnalyteMulti.addColumn("direction", DataSet.STRING);
                                                            }
                                                            if (listExtTubeHvngSmAnalyteMulti != null && !listExtTubeHvngSmAnalyteMulti.contains(analytesArr[k])) {
                                                                int index = dsExtTubeHvngSmAnalyteMulti.addRow();
                                                                dsExtTubeHvngSmAnalyteMulti.setValue(index, "extractionid", dsTemp.getValue(0, CONTENTID_PROP, ""));
                                                                dsExtTubeHvngSmAnalyteMulti.setValue(index, "analyte", analytesArr[k]);
                                                                dsExtTubeHvngSmAnalyteMulti.setValue(index, "dilution", dilution);
                                                                String direction = tempDS.getValue(0, "direction", "");
                                                                if (Util.isNull(direction) || "N".equalsIgnoreCase(direction))
                                                                    direction = "N/A";
                                                                dsExtTubeHvngSmAnalyteMulti.setValue(index, "direction", direction);
                                                                listExtTubeHvngSmAnalyteMulti.push(analytesArr[k]);
                                                            }
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        String childkeyid1 = "";
                                        if (!Util.isNull(plateno) && !Util.isNull(xpos) && !Util.isNull(ypos) && !Util.isNull(pseudopos)) {
                                            if (plateno.length() == 1)
                                                plateno = "0" + plateno;
                                            if (ypos.length() == 1)
                                                ypos = "0" + ypos;
                                            if (xpos.length() == 1)
                                                xpos = "0" + xpos;
                                            if (pseudopos.length() == 1)
                                                pseudopos = "0" + pseudopos;
                                            childkeyid1 = "S" + timeStamp + plateno + ypos + xpos + pseudopos;
                                            if (childkeyid1.length() > 40) {
                                                throw new SapphireException("Sample id for the new dilution tubes cannot be generated.\nReason: keyid1 length is " + childkeyid1.length());
                                            }
                                        }
                                        if (!Util.isNull(parntSampleId) && !Util.isNull(childkeyid1)) {
                                            int index = dsCrtHild.addRow();
                                            dsCrtHild.setValue(index, SAMPLEID_PROP, parntSampleId);
                                            dsCrtHild.setValue(index, "childkeyid1", childkeyid1);
                                            //TODO 1.5.1 CALCULATION QUANTITY FOR TESTCODE
                                            //dsCrtHild.setValue(index, TESTCODE_PROP, testCode);
                                            //dsCrtHild.setValue(index, DILUTION_PROP, dilution);
                                            elusionTubes += ";" + parntSampleId + "@*@" + testCode + "@*@" + dilution;
                                            dilutionTubes += ";" + childkeyid1;
                                        }
                                    }
                                }
                            }
                            if (!Util.isNull(disputedExtId) && disputedExtId.length() > 1) {
                                if (disputedExtId.startsWith(";"))
                                    disputedExtId = disputedExtId.substring(1);
                                throw new SapphireException("Labvantage sampleid(s) are not found for the elusion tube(s) having extraction id(s):\n" + StringUtil.replaceAll(disputedExtId, ";", ","));
                            }
                            if (!"Y".equalsIgnoreCase(isMicroArray) && dsExtTubeHvngSmAnalyteMulti != null && dsExtTubeHvngSmAnalyteMulti.size() > 0) {
                                String msg = "Specimen(s) cannot be loaded into plate(s).\nReason: " +
                                        "Below specimen(s) are getting repeated against the same anayltes for same dilutions in the uploaded excel.\n" +
                                        "<table border=1>" +
                                        "<tr border=1><th>Extraction Id</th><th>Dilution</th><th>Sequencing Analyte</th><th>Analyte</th></tr>";
                                for (int i = 0; i < dsExtTubeHvngSmAnalyteMulti.size(); i++) {
                                    msg += "<tr border=1><td>" + dsExtTubeHvngSmAnalyteMulti.getValue(i, "extractionid", "") + "</td>" +
                                            "<td>" + dsExtTubeHvngSmAnalyteMulti.getValue(i, "dilution", "Default") + "</td>" +
                                            "<td>" + dsExtTubeHvngSmAnalyteMulti.getValue(i, "direction", "") + "</td>" +
                                            "<td>" + dsExtTubeHvngSmAnalyteMulti.getValue(i, "analyte", "") + "</td></tr>";
                                }
                                msg += "</table>";
                                throw new SapphireException(msg);
                            }
                            if (dsCrtHild != null && dsCrtHild.size() > 0) {
//                                props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", dsCrtHild.size(), ";"));
                                props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_pathologycomments;u_extractioncomments");
                                props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, dsCrtHild.getColumnValues(SAMPLEID_PROP, ";"));
                                props.setProperty("childkeyid1", dsCrtHild.getColumnValues("childkeyid1", ";"));
                                //TODO 1.5.1 CALCULATION QUANTITY FOR TESTCODE
                                //props.setProperty("testcode", dsCrtHild.getColumnValues(TESTCODE_PROP, ";"));
                                //props.setProperty("dilution", dsCrtHild.getColumnValues(DILUTION_PROP, ";"));
//                                props.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
//                                props.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
//                                getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, props);
                                createChildSample(props);
                            }
                        }
                    }
                    if (!Util.isNull(dilutionTubes) && dilutionTubes.startsWith(";"))
                        dilutionTubes = dilutionTubes.substring(1);

                    String childSample = dilutionTubes;
//Ends
                    if (!Util.isNull(childSample)) {
                        if (!Util.isNull(elusionTubes)) {
                            if (elusionTubes.startsWith(";"))
                                elusionTubes = elusionTubes.substring(1);
                            if (elusionDilutionMap == null)
                                elusionDilutionMap = new HashMap<String, String>();
                            String elArr[] = StringUtil.split(elusionTubes, ";");
                            String dlArr[] = StringUtil.split(childSample, ";");
                            if (elArr == null || dlArr == null || dlArr.length != elArr.length)
                                throw new SapphireException("Batch cannot be created.\nReason: Error occurs while loading specimen from elusion tubes to the plate.");

                            for (int i = 0; i < dlArr.length; i++) {
                                elusionDilutionMap.put(elArr[i], dlArr[i]);
                            }
                        }

//Mark the child samples as Dilution Tubes in the system
                        props.clear();
                        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childSample);
                        props.setProperty("containertypeid", "Dilution Tube");
//                        props.setProperty("custodialdepartmentid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
//                        props.setProperty("custodialuserid", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
//Ends
                        result.clear();
                        populateChildSampleId(result);
                        /*START-Code for adding cobas instrument related to EGFR COBAS*/
                        this.addDefaultCobasInstrument(result, batchid);//TODO WILL OPEN AFTER COBAS FILE PARSING
                        /*END-Code for adding cobas instrument related to EGFR COBAS*/
                        calculateQtyForElusionAndDIlutionTubes(result, SAMPLEID_PROP, "childkeyid1");
                        assgnDIlutionAndOptimalConc(result);
                        addTestCodeToDilutions(result);
                        loadContentIntoPlate(plates, "Sample");
                        associateDilutionTubesWithBatch(result, batchid);
                        removeFromPendingList(result);
                        copyDSForRptOps(result);
                    }

                } catch (SapphireException e) {
                    throw new SapphireException(getTranslationProcessor().translate("Unable to create child sample.") + "\n" + e.getMessage());
                }
            }
        }
    }

    /*****************************************
     * Adding default instrument for EGFR COBAS
     * @param result
     * @param batchid
     * @throws SapphireException
     ****************************************/
    private void addDefaultCobasInstrument(DataSet result, String batchid) throws SapphireException{
		// TODO Auto-generated method stub
    	HashMap<String, String> hm = new HashMap<>();
    	hm.put("testcode", "4216X");
    	DataSet filteredDS = result.getFilteredDataSet(hm);
    	try{
    		if(filteredDS != null && filteredDS.getRowCount() > 0){
    			PropertyList props = new PropertyList();
    			props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
    			props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
    			props.setProperty("instrumentid", "COBAS Z480 SN#50393");
    			props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");
    			getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
    		}
    	}catch(SapphireException ex){
    		throw new SapphireException("Error occurred while adding default instrument for the EGFR COBAS", ex);
    	}
	}

	private void calculateQtyForElusionAndDIlutionTubes(DataSet result, String prntcolnm, String childcolnm) throws SapphireException {
        if (result != null && result.size() > 0 && !Util.isNull(prntcolnm) && !Util.isNull(childcolnm)) {
            DataSet ds = result.copy();
            DataSet finalDS = new DataSet();
            finalDS.addColumn("sampleid", DataSet.STRING);
            finalDS.addColumn("qtycurrent", DataSet.STRING);
            ds.sort(childcolnm);
            ArrayList<DataSet> childDsArr = ds.getGroupedDataSets(childcolnm);
            if (childDsArr != null && childDsArr.size() > 0) {
                for (int i = 0; i < childDsArr.size(); i++) {
                    DataSet dsPerChild = childDsArr.get(i);
                    if (dsPerChild != null && dsPerChild.size() > 0) {
                        String childsample = dsPerChild.getValue(0, childcolnm, "");
                        if (!Util.isNull(childsample)) {
                            double total = 0;
                            for (int j = 0; j < dsPerChild.size(); j++) {
                                total += Double.parseDouble(dsPerChild.getValue(j, "sampleload", "0"));
                            }
                            if (total > 0) {
                                int rowindex = finalDS.addRow();
                                finalDS.setValue(rowindex, "sampleid", childsample);
                                finalDS.setValue(rowindex, "qtycurrent", Double.toString(total));
                            }
                        }
                    }
                }

            }

            ds = result.copy();
            ds.sort(prntcolnm);
            ArrayList<DataSet> prntdDsArr = ds.getGroupedDataSets(prntcolnm);

            LinkedList<String> list = new LinkedList<String>();

            DataSet dsDisputedPrntSample = new DataSet();
            dsDisputedPrntSample.addColumn(CONTENTID_PROP, DataSet.STRING);
            dsDisputedPrntSample.addColumn("amountleft", DataSet.STRING);
            dsDisputedPrntSample.addColumn("reqamount", DataSet.STRING);

            if (prntdDsArr != null && prntdDsArr.size() > 0) {
                for (int i = 0; i < prntdDsArr.size(); i++) {
                    DataSet dsPerPrnt = prntdDsArr.get(i);
                    if (dsPerPrnt != null && dsPerPrnt.size() > 0) {
                        double total = 0;
                        String prntId = dsPerPrnt.getValue(0, prntcolnm, "");
                        String currentQtyStr = dsPerPrnt.getValue(0, "qtycurrent", "-1");
                        double currentQty = Double.parseDouble(currentQtyStr);
                        if (!Util.isNull(prntId) && currentQty >= 0) {
                            for (int j = 0; j < dsPerPrnt.size(); j++) {
                                String childId = dsPerPrnt.getValue(j, childcolnm, "");
                                if (!list.contains(childId)) {
                                    total += Double.parseDouble(dsPerPrnt.getValue(j, "sampleload", "0"));
                                    list.add(childId);
                                }
                            }
                            if (total > 0) {
                                if (currentQty < total) {
                                    int row = dsDisputedPrntSample.addRow();
                                    dsDisputedPrntSample.setValue(row, CONTENTID_PROP, dsPerPrnt.getValue(0, CONTENTID_PROP, ""));
                                    dsDisputedPrntSample.setValue(row, "amountleft", Double.toString(currentQty));
                                    dsDisputedPrntSample.setValue(row, "reqamount", Double.toString(total));
                                } else {
                                    currentQty -= total;
                                    int rowindex = finalDS.addRow();
                                    finalDS.setValue(rowindex, "sampleid", prntId);
                                    finalDS.setValue(rowindex, "qtycurrent", Double.toString(currentQty));
                                }
                            }
                        }
                    }
                }
            }
            if (dsDisputedPrntSample != null && dsDisputedPrntSample.size() > 0) {
//                String msg = "Specimen(s) cannot be loaded into plate(s).\nReason: " +
//                        "Insufficient sample left in the below elusion tube(s)\n" +
//                        "<table border=1>" +
//                        "<tr border=1><th>Extraction Id</th><th>Amount Left</th><th>Required Amount</th></tr>";
//                for(int i=0;i<dsDisputedPrntSample.size();i++){
//                    msg+="<tr border=1><td>"+dsDisputedPrntSample.getValue(i,CONTENTID_PROP,"")+"</td>" +
//                            "<td>"+dsDisputedPrntSample.getValue(i,"amountleft","")+"</td>" +
//                            "<td>"+dsDisputedPrntSample.getValue(i,"reqamount","")+"</td></tr>";
//                }
//                msg+="</table>";
//                throw new SapphireException(msg);

                String msg = "Insufficient sample left in the below elusion tube(s)\n" +
                        "<table border=1>" +
                        "<tr border=1><th>Extraction Id</th><th>Amount Left</th><th>Required Amount</th></tr>";
                for (int i = 0; i < dsDisputedPrntSample.size(); i++) {
                    msg += "<tr border=1><td>" + dsDisputedPrntSample.getValue(i, CONTENTID_PROP, "") + "</td>" +
                            "<td>" + dsDisputedPrntSample.getValue(i, "amountleft", "") + "</td>" +
                            "<td>" + dsDisputedPrntSample.getValue(i, "reqamount", "") + "</td></tr>";
                }
                msg += "</table>";
                setInfoError("Info", msg);
            }
            if (finalDS != null && finalDS.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, finalDS.getColumnValues("sampleid", ";"));
                props.setProperty("qtycurrent", finalDS.getColumnValues("qtycurrent", ";"));
                //getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);//TODO 1.5.1 OFF AUTOMATIC CALCULATION QUANTITY FROM TESTCODE
            }
        }
    }


    /**
     * This method creates child sample.
     * Here we are not using the OOB child sample creation action because we need to create the sample ID manually
     *
     * @param prop
     * @throws SapphireException
     */


    private void createChildSample(PropertyList prop) throws SapphireException {
        String prntSample = prop.getProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, "");
        String childKeyid1 = prop.getProperty("childkeyid1", "");
        String columnsToCopy = prop.getProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "");
        if (!Util.isNull(prntSample) && !Util.isNull(childKeyid1) && !Util.isNull(columnsToCopy)) {
            String prntSampleTemp = Util.getUniqueList(prntSample, ";", true);
            String sql = "select s_sampleid sourceid," + StringUtil.replaceAll(columnsToCopy, ";", ",") + " " +
                    " from s_sample where s_sampleid in('" + StringUtil.replaceAll(prntSampleTemp, ";", "','") + "')";
            DataSet dsPrntSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsPrntSampleInfo != null && dsPrntSampleInfo.size() > 0) {

                HashMap<String, String> prntChildMap = new HashMap<>();
                String prntArr[] = StringUtil.split(prntSample, ";");
                String childArr[] = StringUtil.split(childKeyid1, ";");
                if (prntArr != null && childArr != null && prntArr.length > 0 && childArr.length > 0) {
                    for (int i = 0; i < prntArr.length; i++) {
                        prntChildMap.put(childArr[i], prntArr[i]);
                    }
                }

                if (prntChildMap.size() > 0) {
                    DataSet result = dsPrntSampleInfo.copy();
                    if (result != null && result.size() > 0) {
                        result.clear();
                        result.addColumn("childkeyid1", DataSet.STRING);
                        HashMap<String, String> hmap = new HashMap<>();
                        for (int i = 0; i < childArr.length; i++) {
                            String tempChildSample = childArr[i];
                            String parentSample = prntChildMap.get(tempChildSample);
                            if (!Util.isNull(tempChildSample) && !Util.isNull(parentSample)) {

                                hmap.clear();
                                hmap.put("sourceid", parentSample);
                                DataSet dsFilter = dsPrntSampleInfo.getFilteredDataSet(hmap);
                                if (dsFilter != null && dsFilter.size() > 0) {
                                    result.copyRow(dsFilter, 0, 1);
                                    if (result.size() > 0)
                                        result.setValue(result.size() - 1, "childkeyid1", tempChildSample);
                                }
                            }
                        }

                        if (result != null && result.size() > 0) {

                            PropertyList propAddSample = new PropertyList();
                            propAddSample.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
                            propAddSample.setProperty(AddSDI.PROPERTY_KEYID1, result.getColumnValues("childkeyid1", ";"));
                            String copyColsArr[] = StringUtil.split(columnsToCopy, ";");
                            if (copyColsArr != null && copyColsArr.length > 0) {
                                for (int i = 0; i < copyColsArr.length; i++) {
                                    propAddSample.setProperty(copyColsArr[i], result.getColumnValues(copyColsArr[i], ";"));
                                }
                                propAddSample.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY, "Y");
                                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, propAddSample);

                                try {
                                    PreparedStatement ps = database.prepareStatement("insert into s_samplemap(sourcesampleid,destsampleid) values(?,?)");
                                    for (int i = 0; i < prntArr.length; i++) {
                                        ps.setString(1, prntArr[i]);
                                        ps.setString(2, childArr[i]);
                                        ps.addBatch();
                                    }
                                    ps.executeBatch();
                                } catch (SQLException e) {
                                    throw new SapphireException(e.getMessage());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * This method populates the dilution tubes corresponding to each extraction id s
     *
     * @param result
     * @throws SapphireException
     */

    private void populateChildSampleId(DataSet result) throws SapphireException {
        if (elutionTubeDsArr != null && elutionTubeDsArr.size() > 0 && result != null && elusionDilutionMap != null && elusionDilutionMap.size() > 0) {
            result.clear();
            for (int i = 0; i < elutionTubeDsArr.size(); i++) {
                DataSet dsTemp = elutionTubeDsArr.get(i);
                if (dsTemp != null && dsTemp.size() > 0) {
                    dsTemp.addColumn("childsample", DataSet.STRING);
                    for (int j = 0; j < dsTemp.size(); j++) {
                        String prntSample = dsTemp.getValue(j, SAMPLEID_PROP, "");
                        String testCode = dsTemp.getValue(j, TESTCODE_PROP, "");
                        String dilution = dsTemp.getValue(j, DILUTION_PROP, "");
                        String position = dsTemp.getValue(j, POSITION_PROP, "");
                        dsTemp.setValue(j, "childsample", elusionDilutionMap.get(prntSample + "@*@" + testCode + "@*@" + dilution));
                        dsTemp.setValue(j, POSITION_PROP, position);
                    }
                    result.copyRow(dsTemp, -1, 1);
                }
            }
        }
    }


    /**
     * This method calculates the dilution and concentrtion of the new dilution tubes
     *
     * @param result
     * @throws SapphireException
     */

    private void assgnDIlutionAndOptimalConc(DataSet result) throws SapphireException {
        if (result != null && result.size() > 0) {
            DataSet dsEditCHild = result.copy();
            dsEditCHild.sort("childsample");
            ArrayList<DataSet> dsEditChildArr = dsEditCHild.getGroupedDataSets("childsample");
            if (dsEditChildArr != null && dsEditChildArr.size() > 0) {
                dsEditCHild.clear();
                for (int i = 0; i < dsEditChildArr.size(); i++) {
                    DataSet dsTemp = dsEditChildArr.get(i);
                    if (dsTemp != null && dsTemp.size() > 0) {
                        String childSampleId = dsTemp.getValue(0, "childsample", "");
                        String dilution = dsTemp.getValue(0, DILUTION_PROP, "");
                        String conc = dsTemp.getValue(0, OPTIMALCONCENTRATION_PROP, "");
                        if (!Util.isNull(childSampleId)) {
                            int index = dsEditCHild.addRow();
                            dsEditCHild.setValue(index, "childsample", childSampleId);
                            dsEditCHild.setValue(index, DILUTION_PROP, dilution);
                            dsEditCHild.setValue(index, OPTIMALCONCENTRATION_PROP, conc);
                        }
                    }
                }
                if (dsEditCHild != null && dsEditCHild.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsEditCHild.getColumnValues("childsample", ";"));
                    props.setProperty("u_concentrationratio", dsEditCHild.getColumnValues(DILUTION_PROP, ";"));
                    props.setProperty("concentration", dsEditCHild.getColumnValues(OPTIMALCONCENTRATION_PROP, ";"));//TODO OPEN FOR LITO's INSTRUCTION
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                }
            }
        }
    }

    /**
     * This method ssign the testcodes to the dilution tubes..
     *
     * @param result
     * @throws SapphireException
     */

    private void addTestCodeToDilutions(DataSet result) throws SapphireException {
        if (result != null && result.size() > 0) {
            DataSet dsAddTstCode = result.copy();
            if (dsAddTstCode != null && dsAddTstCode.size() > 0) {
                dsAddTstCode.sort("childsample");
                ArrayList<DataSet> dsAddTstCodeArr = dsAddTstCode.getGroupedDataSets("childsample");
                if (dsAddTstCodeArr != null && dsAddTstCodeArr.size() > 0) {
                    dsAddTstCode.clear();
                    for (int i = 0; i < dsAddTstCodeArr.size(); i++) {
                        DataSet dsTemp = dsAddTstCodeArr.get(i);
                        if (dsTemp != null && dsTemp.size() > 0) {
                            String childsample = dsTemp.getValue(0, "childsample", "");
                            String testcode = dsTemp.getValue(0, "testcode", "");
                            String ispanel = dsTemp.getValue(0, "ispanel", "");
                            int index = dsAddTstCode.addRow();
                            dsAddTstCode.setValue(index, "childsample", childsample);
                            dsAddTstCode.setValue(index, "testcode", testcode);
                            dsAddTstCode.setValue(index, "ispanel", ispanel);
                        }
                    }
                }
                if (dsAddTstCode.size() > 0) {
                    PropertyList addTestCode = new PropertyList();
                    addTestCode.setProperty("s_sampleid", dsAddTstCode.getColumnValues("childsample", ";"));
                    addTestCode.setProperty("lvtestcode", dsAddTstCode.getColumnValues("testcode", ";"));
                    addTestCode.setProperty("ispanel", dsAddTstCode.getColumnValues("ispanel", ";"));
                    addTestCode.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
                    addTestCode.setProperty("workitemflag", "Y");
                    getActionProcessor().processAction("AddTestCode", "1", addTestCode);

                    addSpec(dsAddTstCode.getColumnValues("childsample", ";"), "Sample");
                }
            }
        }
    }


    /**
     * This method loads the dilution tubes to the plates
     *
     * @param plates
     * @param contenttype
     * @throws SapphireException
     */

    private void loadContentIntoPlate(String plates, String contenttype) throws SapphireException {
        ArrayList<DataSet> resultArr = null;
        if (!Util.isNull(contenttype)) {
            if ("Sample".equalsIgnoreCase(contenttype))
                resultArr = elutionTubeDsArr;
            else if ("Control".equalsIgnoreCase(contenttype))
                resultArr = controlTubeDsArr;
            else if ("MasterMix".equalsIgnoreCase(contenttype))
                resultArr = mmTubeDsArr;
        }
        if (!Util.isNull(plates) && resultArr != null && resultArr.size() > 0) {
            String platesArr[] = StringUtil.split(plates, ";");
            if (platesArr != null && platesArr.length > 0) {
                DataSet result = new DataSet();
                result.addColumn(AddArrayContent.PROPERTY_ARRAYID, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_ARRAYITEMID, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_CONTENTSDCID, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_CONTENTKEYID1, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_CONTENTLABEL, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_VOLUME, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_VOLUMEUNITS, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_CONTENTITEM, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_CONCENTRATION, DataSet.STRING);
                result.addColumn(AddArrayContent.PROPERTY_CONCENTRATIONUNITS, DataSet.STRING);

                String sql = "select a.arrayid,a.arrayitemid,c.zone,a.xpos,a.ypos,a.itemlabel,a.horizontallabel,a.verticallabel,e.contentitem," +
                        "e.volumetarget,e.volumetargetunits,e.concentrationtarget,e.concentrationtargetunits " +
                        "from arrayitem a,arrayitemarrayzone b,arrayzone c,arrayarraymethoditem d,arraymethodcontent e " +
                        "where a.arrayitemid=b.arrayitemid and b.arrayzoneid=c.arrayzoneid and a.arrayid=c.arrayid " +
                        "and a.arrayid=d.arrayid and  d.arraymethodid=e.arraymethodid and d.arraymethodversionid=e.arraymethodversionid and c.zone=e.zone " +
                        "and a.arrayid " +
                        "in('" + StringUtil.replaceAll(plates, ";", "','") + "')";
                DataSet dsArrItmInfo = getQueryProcessor().getSqlDataSet(sql);

                if (dsArrItmInfo != null && dsArrItmInfo.size() > 0) {
                    HashMap<String, String> hmap = new HashMap<String, String>();
                    for (int i = 0; i < resultArr.size(); i++) {
                        DataSet dsTemp = resultArr.get(i);
                        String plateId = "";
                        if (i < platesArr.length)
                            plateId = platesArr[i];
                        if (!Util.isNull(plateId) && dsTemp != null && dsTemp.size() > 0) {
                            for (int j = 0; j < dsTemp.size(); j++) {
                                String label = dsTemp.getValue(j, POSITION_PROP, "");
                                hmap.clear();
                                hmap.put("arrayid", plateId);
                                hmap.put("itemlabel", label);
                                DataSet dsFiltrPltInfo = dsArrItmInfo.getFilteredDataSet(hmap);
                                if (dsFiltrPltInfo != null && dsFiltrPltInfo.size() > 0) {
                                    String arrayitemid = dsFiltrPltInfo.getValue(0, "arrayitemid", "");
                                    if (!Util.isNull(arrayitemid)) {
                                        int index = result.addRow();
                                        result.setValue(index, AddArrayContent.PROPERTY_ARRAYID, plateId);
                                        result.setValue(index, AddArrayContent.PROPERTY_ARRAYITEMID, arrayitemid);
                                        result.setValue(index, AddArrayContent.PROPERTY_CONTENTSDCID, "Sample");
                                        result.setValue(index, AddArrayContent.PROPERTY_CONTENTKEYID1, dsTemp.getValue(j, "childsample", ""));
                                        result.setValue(index, AddArrayContent.PROPERTY_CONTENTLABEL, dsTemp.getValue(j, "childsample", ""));
                                        result.setValue(index, AddArrayContent.PROPERTY_VOLUME, dsFiltrPltInfo.getValue(0, "volumetarget", "1"));
                                        result.setValue(index, AddArrayContent.PROPERTY_CONCENTRATION, dsFiltrPltInfo.getValue(0, "concentrationtarget", "1"));
                                        result.setValue(index, AddArrayContent.PROPERTY_VOLUMEUNITS, dsFiltrPltInfo.getValue(0, "volumetargetunits", "ul"));
                                        result.setValue(index, AddArrayContent.PROPERTY_CONCENTRATIONUNITS, dsFiltrPltInfo.getValue(0, "concentrationtargetunits", "ul"));
                                        result.setValue(index, AddArrayContent.PROPERTY_CONTENTITEM, dsFiltrPltInfo.getValue(0, "contentitem", "Unknown"));
                                    }
                                }
                            }
                        }
                    }
                    if (result != null && result.size() > 0) {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(AddArrayContent.PROPERTY_ARRAYID, result.getColumnValues(AddArrayContent.PROPERTY_ARRAYID, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_ARRAYITEMID, result.getColumnValues(AddArrayContent.PROPERTY_ARRAYITEMID, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_CONTENTSDCID, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTSDCID, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_CONTENTKEYID1, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTKEYID1, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_CONTENTLABEL, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTLABEL, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_VOLUME, result.getColumnValues(AddArrayContent.PROPERTY_VOLUME, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_VOLUMEUNITS, result.getColumnValues(AddArrayContent.PROPERTY_VOLUMEUNITS, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_CONTENTITEM, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTITEM, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_CONCENTRATION, result.getColumnValues(AddArrayContent.PROPERTY_CONCENTRATION, ";"));
                        pl.setProperty(AddArrayContent.PROPERTY_CONCENTRATIONUNITS, result.getColumnValues(AddArrayContent.PROPERTY_CONCENTRATIONUNITS, ";"));
                        getActionProcessor().processAction(AddArrayContent.ID, AddArrayContent.VERSIONID, pl);

                        if ("Sample".equalsIgnoreCase(contenttype)) {
                            PropertyList plEditSDI = new PropertyList();
                            plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, "LV_Array");
                            plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, plates);
                            plEditSDI.setProperty("arraystatus", "Loaded");
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
                        }
                    }
                }
            }
        }
    }

    /**
     * This method associates the dilution tubes with the molecular batch
     *
     * @param result
     * @param batchid
     * @throws SapphireException
     */

    private void associateDilutionTubesWithBatch(DataSet result, String batchid) throws SapphireException {
        if (result != null && result.size() > 0 && !Util.isNull(batchid)) {
            String direction = "";
            String positions = result.getColumnValues(POSITION_PROP, ";");
            if ("Y".equalsIgnoreCase(isMicroArray)) {
                result.sort("childsample," + TESTCODE_PROP + "," + ANALYTE_PROP);
                ArrayList<DataSet> resultArr = result.getGroupedDataSets("childsample," + TESTCODE_PROP + "," + ANALYTE_PROP);
                if (resultArr != null && resultArr.size() > 0) {
                    result.clear();
                    for (int i = 0; i < resultArr.size(); i++) {
                        DataSet tempDs = resultArr.get(i);
                        if (tempDs != null && tempDs.size() > 0) {
                            String childsample = tempDs.getValue(0, "childsample", "");
                            String testcodeid = tempDs.getValue(0, TESTCODE_PROP, "");
                            String analyteid = tempDs.getValue(0, ANALYTE_PROP, "");
                            direction = tempDs.getValue(0, "direction", "N");
                            int index = result.addRow();
                            result.setValue(index, "childsample", childsample);
                            result.setValue(index, TESTCODE_PROP, testcodeid);
                            result.setValue(index, ANALYTE_PROP, analyteid);
                            result.setValue(index, "direction", direction);
                        }
                    }
                    if (result != null && result.size() > 0) {
                        PropertyList props = new PropertyList();
                        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                        props.setProperty("sampleid", result.getColumnValues("childsample", ";"));
                        props.setProperty("analyteid", result.getColumnValues(ANALYTE_PROP, ";"));
                        props.setProperty("direction", result.getColumnValues("direction", ";"));
                        props.setProperty("testcodeid", result.getColumnValues(TESTCODE_PROP, ";"));
                        props.setProperty("position", positions);
                        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_batch_sample_detail_link");
                        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                    }
                }
            } else {
                for (int i = 0; i < result.size(); i++) {
                    direction += ";" + result.getValue(i, "direction", "N");
                }
                if (!Util.isNull(direction)) {
                    if (direction.startsWith(";"))
                        direction = direction.substring(1);
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                    props.setProperty("sampleid", result.getColumnValues("childsample", ";"));
                    props.setProperty("analyteid", result.getColumnValues(ANALYTE_PROP, ";"));
                    props.setProperty("direction", direction);
                    props.setProperty("testcodeid", result.getColumnValues(TESTCODE_PROP, ";"));
                    props.setProperty("position", positions);
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_batch_sample_detail_link");
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                }
            }
        }
    }

    /**
     * THis method creates sample form the controls and load in to the plates. Also it associates the control samples with the molecular batch.
     *
     * @param plates
     * @param batchid
     * @throws SapphireException
     */

    private void createControlSample(String plates, String batchid) throws SapphireException {
        if (controlTubeDsArr != null && controlTubeDsArr.size() > 0 && allControls != null && allControls.size() > 0) {
            createSamplesFromCtrlId();
            allControls.clear();
            if (!allControls.isValidColumn("direction"))
                allControls.addColumn("direction", DataSet.STRING);
            for (int i = 0; i < controlTubeDsArr.size(); i++) {
                DataSet tempDs = controlTubeDsArr.get(i);
                if (tempDs != null && tempDs.size() > 0) {
                    if (!tempDs.isValidColumn("childsample"))
                        tempDs.addColumn("childsample", DataSet.STRING);
                    if (!tempDs.isValidColumn("direction"))
                        tempDs.addColumn("direction", DataSet.STRING);
                    for (int j = 0; j < tempDs.size(); j++) {
                        String ctrlid = tempDs.getValue(j, CONTENTID_PROP, "");
                        String testCode = tempDs.getValue(j, TESTCODE_PROP, "");
                        String direction = tempDs.getValue(j, "direction", "");
                        if (Util.isNull(direction))
                            tempDs.setValue(j, "direction", "N");
                        tempDs.setValue(j, "childsample", ctrlMap.get(ctrlid + "@*@" + testCode));
                    }
                    allControls.copyRow(tempDs, -1, 1);
                }
            }
            if (allControls != null && allControls.size() > 0) {
                PropertyList props = new PropertyList();
                loadContentIntoPlate(plates, "Control");

                if ("Y".equalsIgnoreCase(isMicroArray) || "Y".equalsIgnoreCase(isCOBAS)) {
                    DataSet result = allControls.copy();
                    result.sort("childsample," + TESTCODE_PROP + "," + ANALYTE_PROP);
                    ArrayList<DataSet> allControlsArr = result.getGroupedDataSets("childsample," + TESTCODE_PROP + "," + ANALYTE_PROP);
                    if (allControlsArr != null && allControlsArr.size() > 0) {
                        result.clear();
                        for (int i = 0; i < allControlsArr.size(); i++) {
                            DataSet tempDs = allControlsArr.get(i);
                            if (tempDs != null && tempDs.size() > 0) {
                                String childsample = tempDs.getValue(0, "childsample", "");
                                String testcodeid = tempDs.getValue(0, TESTCODE_PROP, "");
                                String analyteid = tempDs.getValue(0, ANALYTE_PROP, "");
                                String direction = tempDs.getValue(0, "direction", "N");
                                String position = tempDs.getValue(0, POSITION_PROP, "");
                                int index = result.addRow();
                                result.setValue(index, "childsample", childsample);
                                result.setValue(index, TESTCODE_PROP, testcodeid);
                                result.setValue(index, ANALYTE_PROP, analyteid);
                                result.setValue(index, "direction", direction);
                                result.setValue(index, POSITION_PROP, position);
                            }
                        }
                        if (result != null && result.size() > 0) {
                            props.clear();
                            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                            props.setProperty("sampleid", result.getColumnValues("childsample", ";"));
                            props.setProperty("analyte", result.getColumnValues(ANALYTE_PROP, ";"));
                            props.setProperty("testcodeid", result.getColumnValues(TESTCODE_PROP, ";"));
                            props.setProperty("direction", result.getColumnValues("direction", ";"));
                            props.setProperty("position", result.getColumnValues(POSITION_PROP, ";"));
                            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_control_link");
                            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                        }
                    }
                } else {
                    props.clear();
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                    props.setProperty("sampleid", allControls.getColumnValues("childsample", ";"));
                    props.setProperty("analyte", allControls.getColumnValues(ANALYTE_PROP, ";"));
                    props.setProperty("testcodeid", allControls.getColumnValues(TESTCODE_PROP, ";"));
                    props.setProperty("direction", allControls.getColumnValues("direction", ";"));
                    props.setProperty("position", allControls.getColumnValues(POSITION_PROP, ";"));
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_control_link");
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                }
            }
        }
    }


    private void createSamplesFromCtrlId() throws SapphireException {
        if (controlTubeDsArr != null && controlTubeDsArr.size() > 0 && ctrlInputs != null && ctrlInputs.size() > 0) {
            ctrlInputs.clear();
            for (int i = 0; i < controlTubeDsArr.size(); i++) {
                DataSet tempDs = controlTubeDsArr.get(i);
                if (tempDs != null && tempDs.size() > 0) {
                    ctrlInputs.copyRow(tempDs, -1, 1);
                }
            }

            if (ctrlInputs != null && ctrlInputs.size() > 0) {
                DataSet result = new DataSet();
                ctrlInputs.sort(CONTENTID_PROP + "," + TESTCODE_PROP);
                ArrayList<DataSet> dsArr = ctrlInputs.getGroupedDataSets(CONTENTID_PROP + "," + TESTCODE_PROP);
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        if (tempDs != null && tempDs.size() > 0) {
                            tempDs.sort("plateno,ypos,xpos");
                            result.copyRow(tempDs, 0, 1);
                        }
                    }
                }
                if (result != null && result.size() > 0) {
                    result.addColumn("childsample", DataSet.STRING);

                    for (int i = 0; i < result.size(); i++) {
                        String ctrlId = result.getValue(i, CONTENTID_PROP, "");
                        String testCode = result.getValue(i, TESTCODE_PROP, "");
                        String plateno = result.getValue(i, "plateno", "");
                        String xpos = result.getValue(i, "xpos", "");
                        String ypos = result.getValue(i, "ypos", "");
                        String pseudopos = result.getValue(i, "pseudopos", "");
                        if (!Util.isNull(plateno) && !Util.isNull(xpos) && !Util.isNull(ypos) && !Util.isNull(pseudopos)) {
                            if (plateno.length() == 1)
                                plateno = "0" + plateno;
                            if (ypos.length() == 1)
                                ypos = "0" + ypos;
                            if (xpos.length() == 1)
                                xpos = "0" + xpos;
                            if (pseudopos.length() == 1)
                                pseudopos = "0" + pseudopos;
                            if (!Util.isNull(ctrlId)) {
                                String ctrlSampleId = "S" + timeStamp + plateno + ypos + xpos + pseudopos;
                                result.setValue(i, "childsample", ctrlSampleId);
                                if (ctrlMap == null)
                                    ctrlMap = new HashMap<String, String>();
                                ctrlMap.put(ctrlId + "@*@" + testCode, ctrlSampleId);
                            }
                        }
                    }

                    PropertyList props = new PropertyList();
                    String qcsampletype = StringUtil.repeat("Reagent Sample", result.size(), ";");
                    props.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(AddSDI.PROPERTY_KEYID1, result.getColumnValues("childsample", ";"));
                    props.setProperty("reagentlotid", result.getColumnValues(CONTENTID_PROP, ";"));
                    props.setProperty("qcsampletype", qcsampletype);
                    props.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY, "Y");
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);

                    props.clear();

                    if(!"Y".equalsIgnoreCase(isCOBAS)) {
                        props.setProperty("s_sampleid", result.getColumnValues("childsample", ";"));
                        props.setProperty("lvtestcode", result.getColumnValues(TESTCODE_PROP, ";"));
                        props.setProperty("bypass", "Y");
                        getActionProcessor().processAction("AddTestCode", "1", props);

                        addSpec(result.getColumnValues("childsample", ";"), "Control");
                    }
                }
            }
        }
    }


    /**
     * THis method associates the mastermixes with the molecular batch.
     *
     * @param batchid
     * @throws SapphireException
     */
    private void associatingMMToBatch(String batchid) throws SapphireException {
        if (mmTubeDsArr != null && mmTubeDsArr.size() > 0 && !Util.isNull(batchid)) {
            DataSet result = new DataSet();
            DataSet resultTI = new DataSet();
            String direction = "";
            for (int i = 0; i < mmTubeDsArr.size(); i++) {
                DataSet tempDs = mmTubeDsArr.get(i);
                if (tempDs != null && tempDs.size() > 0) {
                    tempDs.sort(CONTENTID_PROP + "," + ANALYTE_PROP);
                    ArrayList<DataSet> tempDsArr = tempDs.getGroupedDataSets(CONTENTID_PROP + "," + ANALYTE_PROP);
                    if (tempDsArr != null && tempDsArr.size() > 0) {
                        for (int j = 0; j < tempDsArr.size(); j++) {
                            DataSet dsTemp = tempDsArr.get(j);
                            if (dsTemp != null && dsTemp.size() > 0) {
                                double avilableqty = Double.parseDouble(dsTemp.getValue(0, "availableqty", "0"));
                                double usedQty = Double.parseDouble(dsTemp.getValue(0, VOLUME_PROP, "0"));
                                direction += ";" + dsTemp.getValue(0, "direction", "N");

//                                if (!dsTemp.isValidColumn("direction")) {
//                                    dsTemp.addColumn("direction", DataSet.STRING);
//                                    dsTemp.setValue(0, "direction", direction);
//                                }

                                avilableqty -= usedQty;
                                if (avilableqty > 0) {
                                    dsTemp.setValue(0, "availableqty", Double.toString(avilableqty));
                                    resultTI.copyRow(dsTemp, 0, 1);
                                }
                                result.copyRow(dsTemp, 0, 1);
                            }
                        }
                    }
                }
            }
            if (result != null && result.size() > 0) {
                if (!Util.isNull(direction) && direction.startsWith(";"))
                    direction = direction.substring(1);
                PropertyList props = new PropertyList();
                if("Y".equalsIgnoreCase(isCOBAS)){
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                    props.setProperty("reagentid", result.getValue(0,CONTENTID_PROP, ""));
                    props.setProperty("reagenttype", result.getValue(0,"reagenttype", ""));
                    props.setProperty("reagenttypeversion", result.getValue(0,"reagenttypeversion", ""));
                    props.setProperty("type", result.getValue(0,"type", ""));
                    props.setProperty("analyte", "All");
                    props.setProperty("testcodeid", result.getValue(0,TESTCODE_PROP, ""));
                    props.setProperty("direction", "N");
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");
                }
                else {
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                    props.setProperty("reagentid", result.getColumnValues(CONTENTID_PROP, ";"));
                    props.setProperty("reagenttype", result.getColumnValues("reagenttype", ";"));
                    props.setProperty("reagenttypeversion", result.getColumnValues("reagenttypeversion", ";"));
                    props.setProperty("type", result.getColumnValues("type", ";"));
                    props.setProperty("analyte", result.getColumnValues(ANALYTE_PROP, ";"));
                    props.setProperty("testcodeid", result.getColumnValues(TESTCODE_PROP, ";"));
                    props.setProperty("direction", direction);
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");
                }
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);

                if (resultTI != null && resultTI.size() > 0) {
                    props.clear();
                    props.setProperty(EditTrackItem.PROPERTY_KEYID1, resultTI.getColumnValues(CONTENTID_PROP, ";"));
                    props.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                    props.setProperty("qtycurrent", resultTI.getColumnValues("availableqty", ";"));
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
                }
            }
        }
    }

    /**
     * THis method associates the new plate created with the molecular batch
     *
     * @param plateid
     * @param batchid
     * @throws SapphireException
     */


    private void associatePlateWithBatch(String plateid, String batchid) throws SapphireException {
        if (!Util.isNull(batchid) && !Util.isNull(plateid)) {
            String platesArr[] = StringUtil.split(plateid, ";");
            String sheetNo = "";
            if (platesArr != null && platesArr.length > 0) {
                for (int i = 0; i < platesArr.length; i++) {
                    sheetNo += ";" + Integer.toString(i + 1);
                }
            }

            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
            props.setProperty("plateid", plateid);
            if (!Util.isNull(sheetNo)) {
                if (sheetNo.startsWith(";"))
                    sheetNo = sheetNo.substring(1);
                props.setProperty("sheetno", sheetNo);
            }
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        }
    }

    /**
     * This method attaches the excel file(used for batch loading) with the molecuar batch as an attachment
     *
     * @param batchid
     * @param file
     * @throws SapphireException
     */

    private void attachPlateMap(String batchid, String file) throws SapphireException {
        if (!Util.isNull(batchid) && !Util.isNull(file)) {
            PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy(FILELOCATIONPOLICY, NODEID);
            if (plCaseFilePolicy == null)
                throw new SapphireException("File Location path can't be found");
            PropertyListCollection plc = plCaseFilePolicy.getCollection(PROPS_LOCATIONS);
            String newfileLocation = "";
            if (plc != null) {
                newfileLocation = plc.getPropertyList(0).getProperty(PROPS_LOCATION);
                //newfileLocation = "C:/abc/Downloads/"; //For local testing
                //CHECK FOLDER
                newfileLocation = Util.createFolderForMolecular(newfileLocation, "PlateMap");
                if (Util.isNull(newfileLocation))
                    throw new SapphireException("Please specify the path for keeping the plate maps in the policy " + FILELOCATIONPOLICY + " under the node " + NODEID);
                String newFile = "";
//                if("Y".equalsIgnoreCase(copyFile))

                newFile = Util.copyFile(file, newfileLocation, (fileTemplateIdentifier + "_"));
//                else
//                    newFile = Util.moveFile(file,newfileLocation);
                if (Util.isNull(newFile))
                    throw new SapphireException("File can't be created in the location " + newfileLocation);

                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
                pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newFile);
                pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(newFile).getName());
                pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
//                pl.setProperty( columnid, columnvalue);
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
            }
        }
    }

    /**
     * THis method removes the repeat pending records fro the db when the batch is loading with the
     * extracion tubes corresponding to the repeat operations(All kind of repeat operation)
     *
     * @param result
     * @throws SapphireException
     */

    private void removeFromPendingList(DataSet result) throws SapphireException {
        if (result != null && result.size() > 0) {
            String extIds = result.getColumnValues(CONTENTID_PROP, ";");
            if (!Util.isNull(extIds)) {
                extIds = Util.getUniqueList(extIds, ";", true);
                String sql = "select u_repeatopsid from u_repeatops where extractionid in('" + StringUtil.replaceAll(extIds, ";", "','") + "') and ispending='Y'";
                DataSet dsRptOpsInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsRptOpsInfo != null && dsRptOpsInfo.size() > 0) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "RepeatOps");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsRptOpsInfo.getColumnValues("u_repeatopsid", ";"));
                    prop.setProperty("ispending", "N");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                }
                sql = "select u_reversemovementid from u_reversemovement where extractionid in('" + StringUtil.replaceAll(extIds, ";", "','") + "') and ispending='Y'";
                DataSet dsBkMvmntInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsBkMvmntInfo != null && dsBkMvmntInfo.size() > 0) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "ReverseMovement");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsBkMvmntInfo.getColumnValues("u_reversemovementid", ";"));
                    prop.setProperty("ispending", "N");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                }
                String prntSampleId = result.getColumnValues(SAMPLEID_PROP, ";");
                if (!Util.isNull(prntSampleId)) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, prntSampleId);
                    prop.setProperty("u_pcrpending", "N");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                }
            }
        }
    }

    /**
     * This method will copy the sdidataitem values from the previous run for repeat,purification,w/o LNA,w LNA
     * Assumption: Extrction id created at repeatops
     *
     * @param result
     * @throws SapphireException
     */

    private void copyDSForRptOps(DataSet result) throws SapphireException {
        if (result != null && result.size() > 0) {
            String extIds = result.getColumnValues(CONTENTID_PROP, ";");
            if (!Util.isNull(extIds)) {
                extIds = Util.getUniqueList(extIds, ";", true);
                String sql = "select extractionid,keyid1,paramlistid,paramlistversionid,variantid,dataset,paramid,paramtype,replicateid,enteredtext,lvtestcodeid " +
                        " from sdidataitem a,u_repeatops b,u_sampletestcodemap c " +
                        "where a.sdcid='Sample' and a.keyid1=b.orgsampleid and b.extractionid in('" + StringUtil.replaceAll(extIds, ";", "','") + "') " +
                        "and c.s_sampleid=a.keyid1 and enteredtext is not null";
                DataSet dsDataSetInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsDataSetInfo != null && dsDataSetInfo.size() > 0) {
                    HashMap<String, String> hmap = new HashMap<String, String>();
                    for (int i = 0; i < dsDataSetInfo.size(); i++) {
                        String tempExtId = dsDataSetInfo.getValue(i, "extractionid", "");
                        String testcodeid = dsDataSetInfo.getValue(i, "lvtestcodeid", "");
                        hmap.clear();
                        hmap.put(CONTENTID_PROP, tempExtId);
                        hmap.put(TESTCODE_PROP, testcodeid);
                        DataSet dsFiltr = result.getFilteredDataSet(hmap);
                        if (dsFiltr != null && dsFiltr.size() > 0) {
                            String dilutionTube = dsFiltr.getValue(0, "childsample", "");
                            dsDataSetInfo.setValue(i, "keyid1", dilutionTube);
                        }
                    }
                    PropertyList plEnterDataItem = new PropertyList();
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_KEYID1, dsDataSetInfo.getColumnValues("keyid1", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsDataSetInfo.getColumnValues("paramlistid", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsDataSetInfo.getColumnValues("paramlistversionid", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsDataSetInfo.getColumnValues("variantid", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_DATASET, dsDataSetInfo.getColumnValues("dataset", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_PARAMID, dsDataSetInfo.getColumnValues("paramid", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsDataSetInfo.getColumnValues("paramtype", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsDataSetInfo.getColumnValues("replicateid", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsDataSetInfo.getColumnValues("enteredtext", ";"));
                    plEnterDataItem.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");

                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, plEnterDataItem);
                }
            }
        }
    }

    /**
     * This method deletes the batch detail records
     *
     * @param batchid
     * @throws SapphireException
     */

    private void deleteBatchDetail(String batchid) throws SapphireException {
        if (!Util.isNull(batchid)) {
            String sql = "select sampleid,analyteid,direction,testcodeid from u_batch_sample_detail where u_ngbatchid='" + batchid + "'";
            DataSet dsDetailIfo = getQueryProcessor().getSqlDataSet(sql);
            PropertyList prop = new PropertyList();
            if (dsDetailIfo != null && dsDetailIfo.size() > 0) {
                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_batch_sample_detail_link");
                prop.setProperty("sampleid", dsDetailIfo.getColumnValues("sampleid", ";"));
                prop.setProperty("analyteid", dsDetailIfo.getColumnValues("analyteid", ";"));
                prop.setProperty("direction", dsDetailIfo.getColumnValues("direction", ";"));
                prop.setProperty("testcodeid", dsDetailIfo.getColumnValues("testcodeid", ";"));
                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
            }

            sql = "select sampleid,analyte,direction,testcodeid from u_ngbatch_control where u_ngbatchid='" + batchid + "'";
            dsDetailIfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsDetailIfo != null && dsDetailIfo.size() > 0) {
                prop.clear();
                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_control_link");
                prop.setProperty("sampleid", dsDetailIfo.getColumnValues("sampleid", ";"));
                prop.setProperty("analyte", dsDetailIfo.getColumnValues("analyte", ";"));
                prop.setProperty("direction", dsDetailIfo.getColumnValues("direction", ";"));
                prop.setProperty("testcodeid", dsDetailIfo.getColumnValues("testcodeid", ";"));
                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
            }

            sql = "select reagentid,analyte,direction,testcodeid from u_ngbatcg_reagent_detail where u_ngbatchid='" + batchid + "'";
            dsDetailIfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsDetailIfo != null && dsDetailIfo.size() > 0) {
                prop.clear();
                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");
                prop.setProperty("reagentid", dsDetailIfo.getColumnValues("reagentid", ";"));
                prop.setProperty("analyte", dsDetailIfo.getColumnValues("analyte", ";"));
                prop.setProperty("direction", dsDetailIfo.getColumnValues("direction", ";"));
                prop.setProperty("testcodeid", dsDetailIfo.getColumnValues("testcodeid", ";"));
                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
            }

            sql = "select plateid from u_ngbatch_plate where u_ngbatchid='" + batchid + "'";
            dsDetailIfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsDetailIfo != null && dsDetailIfo.size() > 0) {
                prop.clear();
                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
                prop.setProperty("plateid", dsDetailIfo.getColumnValues("plateid", ";"));
                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
            }

            sql = "select sampleid from u_ngbatch_sample where u_ngbatchid='" + batchid + "'";
            dsDetailIfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsDetailIfo != null && dsDetailIfo.size() > 0) {
                prop.clear();
                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                prop.setProperty("sampleid", dsDetailIfo.getColumnValues("sampleid", ";"));
                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
            }

            sql = "delete from sdiattachment where sdcid='NGBatch' and keyid1='" + batchid + "'";
            database.executeUpdate(sql);
        }
    }

    private void addSpec(String contentids, String type) throws SapphireException {
        if (!Util.isNull(contentids) && !Util.isNull(type)) {
            String sql = "";
            if ("Sample".equalsIgnoreCase(type))
                sql = "select a.s_sampleid,a.lvtestcodeid,b.specid,b.specversionid from u_sampletestcodemap a,u_testcodespecmap b " +
                        "where a.lvtestcodeid=b.u_testcodeid and b.type='" + type + "' and a.s_sampleid in('" + StringUtil.replaceAll(contentids, ";", "','") + "')";
            else if ("Control".equalsIgnoreCase(type)) {
                sql = "select a.s_sampleid,a.lvtestcodeid,b.specid,b.specversionid " +
                        "from u_sampletestcodemap a,u_testcodespecmap b,s_sample c,REAGENTLOT d " +
                        "where a.lvtestcodeid=b.u_testcodeid and a.s_sampleid=c.s_sampleid and c.reagentlotid=d.REAGENTLOTID " +
                        "and d.reagenttypeid=b.REAGENTTYPE and d.REAGENTTYPEVERSIONID=b.REAGENTTYPEVERION " +
                        "and b.type='" + type + "' and a.s_sampleid in('" + StringUtil.replaceAll(contentids, ";", "','") + "')";
            }

            DataSet dsTestcodeSpecInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTestcodeSpecInfo == null)
                throw new SapphireException("Specification info sis obtained as null from the database. Please check the database connection");
            if (dsTestcodeSpecInfo.size() > 0) {
                PropertyList pl = new PropertyList();
//Here AddSDISpec is being called in the loop because it cannot handle multiple keyid1 and multiple specids in one to one fashion

                for (int i = 0; i < dsTestcodeSpecInfo.size(); i++) {
                    String contentid = dsTestcodeSpecInfo.getValue(i, "s_sampleid", "");
                    String specid = dsTestcodeSpecInfo.getValue(i, "specid", "");
                    String specversionid = dsTestcodeSpecInfo.getValue(i, "specversionid", "");
                    if (!Util.isNull(contentid) && !Util.isNull(specid) && !Util.isNull(specversionid)) {
                        pl.clear();
                        pl.setProperty(AddSDISpec.PROPERTY_SDCID, "Sample");
                        pl.setProperty(AddSDISpec.PROPERTY_KEYID1, contentid);
                        pl.setProperty(AddSDISpec.PROPERTY_SPECID, specid);
                        pl.setProperty(AddSDISpec.PROPERTY_SPECVERSIONID, specversionid);
                        getActionProcessor().processAction(AddSDISpec.ID, AddSDISpec.VERSIONID, pl);
                    }
                }

            }
        }
    }
}
