package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.GenerateLabel;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;
import sapphire.custom.ng.sql.PrintLabel.PrintLabelSql;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * Created by rrmandal on 10/30/2016.
 */
public class PrintLabel extends BaseAction {
    private static final String CONTAINERTYPE = "Block;Unstained Slide(s);Unstained Slide;Slide(s);Stained Slide(s);Stained Slide";
    private static final String EXTRACTIONTPE = "DNA;TNA;RNA;Plasma";
    private static final String PRINTLABEL_POLICY = "PrintLabel";
    private static final String NODEID = "PrintLabelInfo";
    private static final String NODEID_Plate = "PlateLabelsInfo";
    public static final String LABELTYPE_PROP = "labeltypeparam";
    public static final String TRAMLINE_PROP = "tramlineparam";
    public static final String TRAMSTOP_PROP = "tramstopparam";
    public static final String KEYID1_PROP = "keyid1";
    public static final String SDCID_PROP = "sdcid";
    public static final String COPIES = "copies";
    public static final String EXTRACTION_TYPE = "extractiontype";
    public static final String MICROTOMY_PRINT = "microtomyprint";
    public static final String FPFLOW_PRINT = "freshprepflowprint";
    public static final String FLOWPROCESS_TUBELBL = "flowprocessingtubelbl";
    public static final String FLOWPROCESS_LYSINGTUBELBL = "flowprocesslysingtubelbl";
    public static final String LABEL_ACCESSION = "fromaccessionscreen";
    //public static final String PlateID="batchid";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String labeltypeParam = properties.getProperty(LABELTYPE_PROP, "");
        String keyid1 = properties.getProperty(KEYID1_PROP, "");
        String sdcid = properties.getProperty(SDCID_PROP, "");
        String tramline = properties.getProperty(TRAMLINE_PROP, "");
        String tramstop = properties.getProperty(TRAMSTOP_PROP, "");
        String copies = properties.getProperty(COPIES, "1");
        String labelmethodid = properties.getProperty("labelmethodid");
        String extractiontype = properties.getProperty(EXTRACTION_TYPE, "null");
        String microtomyPrint = properties.getProperty(MICROTOMY_PRINT, "");//This is used in microtomy specimen cutting
        String freshPrepFlowPrint = properties.getProperty(FPFLOW_PRINT, "");//This is used in fresh prep tramstop for flow samples label print
        String flowProcessingTubeLbl = properties.getProperty(FLOWPROCESS_TUBELBL, "");//This is used in FLOW 'Processing' tramstop for reprinting tube labels
        String flowProcessLysingTubeLbl = properties.getProperty(FLOWPROCESS_LYSINGTUBELBL, "");//This is used in FLOW 'Processing' tramstop for reprinting tube labels
        String fromAccessionScreen = properties.getProperty(LABEL_ACCESSION, "");//This is used for Label generated from accessioning screen for displaying specimens in order        //String batchid = properties.getProperty(PlateID,"");
        String batchplateArray[] = StringUtil.split(keyid1, ";");
        String printfor = properties.getProperty("printfor", "");
        String printerid = "";

        /*  Bypass 'Pooled Specimen' cases for 'Library Prep', 'Capture Prep' and 'Molarity' under 'Exome SS'   */
        if (!"Pooled Specimen".equalsIgnoreCase(labeltypeParam)){
            keyid1 = specialSamplePrintFromAccession(keyid1);
        }
        if ("Sample".equalsIgnoreCase(sdcid)) {
            String sql = "";
            if ("Y".equalsIgnoreCase(microtomyPrint)) {
                //sql = "select distinct t.linkkeyid1,t.containertypeid, stm.methodology from u_sampletestcodemap stm ,trackitem t " +
                //        "  where t.linksdcid='Sample' and t.linkkeyid1=stm.s_sampleid and t.linkkeyid1 in  ('" + StringUtil.replaceAll(keyid1, ";", "','") + "')";
                sql = Util.parseMessage(PrintLabelSql.GET_Specimens_From_Microtomy, StringUtil.replaceAll(keyid1, ";", "','"));
            } else if ("Y".equalsIgnoreCase(freshPrepFlowPrint)) {  //This functionality is required to manually generate Flow child specimen labels from FreshPrepQC T.S.
                sql = Util.parseMessage(PrintLabelSql.GET_FLOW_ALL_INTERNAL_SAMPLEID, StringUtil.replaceAll(keyid1, ";", "','"), StringUtil.replaceAll(keyid1, ";", "','"));
            } else if ("Y".equalsIgnoreCase(flowProcessingTubeLbl)) {  //This functionality is required to re-print tube labels from Flow 'Processing' T.S.
                sql = Util.parseMessage(PrintLabelSql.GET_FLOW_ONLY_TUBES, StringUtil.replaceAll(keyid1, ";", "','"), StringUtil.replaceAll(keyid1, ";", "','"));
            } else if ("Y".equalsIgnoreCase(flowProcessLysingTubeLbl)) {  //This functionality is required to re-print Lysing Tube labels from Flow 'Processing' T.S.
                sql = Util.parseMessage(PrintLabelSql.GET_FLOW_LYSING_TUBES, StringUtil.replaceAll(keyid1, ";", "','"), StringUtil.replaceAll(keyid1, ";", "','"));
            } else {
                if ("Y".equalsIgnoreCase(fromAccessionScreen)) {
                    /*sql = "select distinct t.linkkeyid1,t.containertypeid,u_molbatchspecimenid, s_sampleid , " +
                            "(select stm.methodology from u_sampletestcodemap stm where stm.s_sampleid in ('" + StringUtil.replaceAll(keyid1, ";", "','") + "') and rownum = 1 ) methodology " +
                            "from trackitem t,s_sample s where t.linksdcid='Sample' and t.linkkeyid1=s.s_sampleid and " +
                            " t.linkkeyid1 in ('" + StringUtil.replaceAll(keyid1, ";", "','") + "') order by u_molbatchspecimenid, s_sampleid"; */
                    sql = Util.parseMessage(PrintLabelSql.GET_Specimens_From_AccessionScreen, StringUtil.replaceAll(keyid1, ";", "','"), StringUtil.replaceAll(keyid1, ";", "','"));
                } else {
                    /*sql = "select distinct t.linkkeyid1,t.containertypeid, " +
                            "(select stm.methodology from u_sampletestcodemap stm where stm.s_sampleid in ('" + StringUtil.replaceAll(keyid1, ";", "','") + "') and rownum = 1 ) methodology " +
                            "from trackitem t where t.linksdcid='Sample' and t.linkkeyid1 in ('" + StringUtil.replaceAll(keyid1, ";", "','") + "')";*/
                    sql = Util.parseMessage(PrintLabelSql.GET_Specimens_From_NonAccessionScreen, StringUtil.replaceAll(keyid1, ";", "','"), StringUtil.replaceAll(keyid1, ";", "','"));
                }
            }
            DataSet dsTrakItemInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTrakItemInfo != null && dsTrakItemInfo.size() > 0) {
                DataSet dsSampleLabelComb = getLabelId(labeltypeParam, tramline, tramstop, dsTrakItemInfo);
//                if(dsSampleLabelComb==null || dsSampleLabelComb.size()==0)
//                    throw new SapphireException("Label Ids cannot be obtained from the policy "+PRINTLABEL_POLICY+". Please configure it properly");
                if (dsSampleLabelComb == null || dsSampleLabelComb.size() == 0)
                    return;
                //if(EXTRACTIONTPE.contains(extractiontype)) {
                if ("DNA".equalsIgnoreCase(extractiontype) || "TNA".equalsIgnoreCase(extractiontype) ||
                        "RNA".equalsIgnoreCase(extractiontype) || "Plasma".equalsIgnoreCase(extractiontype)
                        || "PROTEIN".equalsIgnoreCase(extractiontype) || "CRYO".equalsIgnoreCase(extractiontype)) {
                    printerid = getColorPrinterIdForExtraction(extractiontype);
                } else {
                    printerid = getPrinterId();
                }
                if (Util.isNull(printerid)) {
                    throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                            " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                            "Or the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
                    //return;
                }
                /*  Following logic has been implemented to print Specimens in an order according to the displayed order in Accessioning screen  */
                HashMap<String, String> hmAccessionSample = new HashMap<>();
                DataSet dsFilter = new DataSet();
                String timeinervalSql = Util.parseMessage(PrintLabelSql.GET_PRINT_INTERVAL_FROM_ENVPROP, "lv.printinterval");
                DataSet dsTimeInterval = getQueryProcessor().getSqlDataSet(timeinervalSql);
                int timeInterval = 0;
                if (dsTimeInterval != null && dsTimeInterval.size() > 0) {
                    timeInterval = Integer.parseInt(dsTimeInterval.getValue(0, "propvalue"));
                }
                if ("Y".equalsIgnoreCase(fromAccessionScreen)) {
                    PropertyList prop = new PropertyList();
                    prop.clear();
                    String accessionSampleArr[] = StringUtil.split(keyid1, ";");
                    DataSet dsSampleOrder = new DataSet();
                    dsSampleOrder.addColumn("sampleid", DataSet.STRING);
                    dsSampleOrder.addColumn("labelid", DataSet.STRING);
                    dsSampleOrder.addColumn("versionid", DataSet.STRING);

                    for (int i = 0; i < accessionSampleArr.length; i++) {
                        hmAccessionSample.clear();
                        hmAccessionSample.put("sampleid", accessionSampleArr[i]);
                        dsFilter.clear();
                        dsFilter = dsSampleLabelComb.getFilteredDataSet(hmAccessionSample);
                        if (dsFilter != null && dsFilter.size() > 0) {
                            for (int k = 0; k < dsFilter.size(); k++) {
                                int index = dsSampleOrder.addRow();
                                dsSampleOrder.setValue(index, "sampleid", dsFilter.getValue(k, "sampleid", ""));
                                dsSampleOrder.setValue(index, "labelid", dsFilter.getValue(k, "labelid", ""));
                                dsSampleOrder.setValue(index, "versionid", dsFilter.getValue(k, "versionid", ""));
                            }
                        }
                    }
                    if (dsSampleOrder != null && dsSampleOrder.getRowCount() > 0) {
                        for (int y = 0; y < dsSampleOrder.getRowCount(); y++) {
                            prop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
                            prop.setProperty(GenerateLabel.PROPERTY_KEYID1, dsSampleOrder.getValue(y, "sampleid", ""));
                            prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, dsSampleOrder.getValue(y, "labelid", ""));
                            prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, dsSampleOrder.getValue(y, "versionid", ""));
                            prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
                            prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                            prop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
                            getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, prop);
                            try {
                                Thread.sleep(timeInterval);         /* Time interval added to print labels in an order*/
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                } else {
                    dsSampleLabelComb.sort("labelid,versionid");
                    ArrayList<DataSet> dsSampleLabelCombArr = dsSampleLabelComb.getGroupedDataSets("labelid,versionid");
                    PropertyList prop = new PropertyList();
                    if (dsSampleLabelCombArr != null && dsSampleLabelCombArr.size() > 0) {
                        for (int i = 0; i < dsSampleLabelCombArr.size(); i++) {
                            DataSet dsTemp = dsSampleLabelCombArr.get(i);
                            if (dsTemp != null && dsTemp.size() > 0) {
                                String labelId = dsTemp.getValue(0, "labelid", "");
                                String versionid = dsTemp.getValue(0, "versionid", "");
                                if (!Util.isNull(labelId) && !Util.isNull(versionid)) {
                                    prop.clear();
                                    prop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
                                    prop.setProperty(GenerateLabel.PROPERTY_KEYID1, dsTemp.getColumnValues("sampleid", ";"));
                                    prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, labelId);
                                    prop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, versionid);
                                    prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
                                    prop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                                    prop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
                                    getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, prop);
                                }
                            }
                        }
                    }
                }
            }
        }

        if ("NGBatch".equalsIgnoreCase(sdcid)) {
            DataSet dsLabel = getLabelForMolecular(labeltypeParam, tramline, tramstop, batchplateArray);
            bigDyValidation(dsLabel);
            //String pltprinterid = getPrinterId();
            //if(EXTRACTIONTPE.contains(extractiontype)) {
            if ("DNA".equalsIgnoreCase(extractiontype) || "TNA".equalsIgnoreCase(extractiontype) ||
                    "RNA".equalsIgnoreCase(extractiontype) || "Plasma".equalsIgnoreCase(extractiontype)
                    || "PROTEIN".equalsIgnoreCase(extractiontype)) {
                printerid = getColorPrinterIdForExtraction(extractiontype);
            } else {
                printerid = getPrinterId();
            }
            if (printerid == null || "".equalsIgnoreCase(printerid)) {
                throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                        " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                        "Also the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
            }
            PropertyList pltprop = new PropertyList();
            String pltlabel = dsLabel.getValue(0, "labelid");
            String pltversion = dsLabel.getValue(0, "versionid");
            pltprop.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
            pltprop.setProperty(GenerateLabel.PROPERTY_KEYID1, dsLabel.getColumnValues("batchid", ";"));
            //pltprop.setProperty(GenerateLabel.PROPERTY_KEYID1, "Bat-092016-01542");
            pltprop.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, pltlabel);
            pltprop.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, pltversion);
            pltprop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
            pltprop.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
            pltprop.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
            getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, pltprop);
        }
        if ("LV_ReagentLot".equalsIgnoreCase(sdcid) || "SampleTestCodeMap".equalsIgnoreCase(sdcid) || "Processor".equalsIgnoreCase(sdcid)
                || "Retort".equalsIgnoreCase(sdcid) || "SampleCultureMap".equalsIgnoreCase(sdcid) || "CytoSlides".equalsIgnoreCase(sdcid)) {
            if(("LV_ReagentLot".equalsIgnoreCase(sdcid))&&(("Antibody Label".equalsIgnoreCase(labeltypeParam)))){
                extractiontype=labeltypeParam;
            }
            //String reagentprinter=getPrinterId();
            //if(EXTRACTIONTPE.contains(extractiontype)) {
            if ("DNA".equalsIgnoreCase(extractiontype) || "TNA".equalsIgnoreCase(extractiontype) ||
                    "RNA".equalsIgnoreCase(extractiontype) || "Plasma".equalsIgnoreCase(extractiontype)
                    || "PROTEIN".equalsIgnoreCase(extractiontype)|| "Antibody Label".equalsIgnoreCase(extractiontype)) {
                printerid = getColorPrinterIdForExtraction(extractiontype);
            } else {
                printerid = getPrinterId();
            }
            if (printerid == null || "".equalsIgnoreCase(printerid)) {
                throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                        " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                        "Also the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
            }
            printfor = Util.getUniqueList(printfor, ";", true);
            if ("MOReagent".equalsIgnoreCase(printfor)) {
                String molottype = properties.getProperty("molottype", "");
                String molottypeArray[] = StringUtil.split(molottype, ";");
                DataSet dsMo = reagentPrintForMO(batchplateArray, molottypeArray);
                dsMo.sort("moletype");
                ArrayList alDs = dsMo.getGroupedDataSets("moletype");
                for (int j = 0; j < alDs.size(); j++) {
                    DataSet dsEachMoleType = (DataSet) alDs.get(j);
                    PropertyList plMo = new PropertyList();
                    plMo.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
                    plMo.setProperty(GenerateLabel.PROPERTY_KEYID1, dsEachMoleType.getColumnValues("lot", ";"));
                    plMo.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, Util.getUniqueList(dsEachMoleType.getColumnValues("labelid", ";"), ";", true));
                    plMo.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, Util.getUniqueList(dsEachMoleType.getColumnValues("versionid", ";"), ";", true));
                    plMo.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
                    plMo.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                    plMo.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
                    getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, plMo);
                }
            } else {
                if("LV_ReagentLot".equalsIgnoreCase(sdcid)){
                    if("".equalsIgnoreCase(labelmethodid)) {
                        DataSet reagentResult = getReagentLabelMethod(labeltypeParam);
                        if (reagentResult != null || reagentResult.size() > 0)
                            labelmethodid = reagentResult.getColumnValues("labelmethod", ";");
                    }
                }
                PropertyList reagent = new PropertyList();

                reagent.setProperty(GenerateLabel.PROPERTY_LABELSDCID, sdcid);
                reagent.setProperty(GenerateLabel.PROPERTY_KEYID1, keyid1);
                reagent.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, labelmethodid);
                reagent.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
                reagent.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
                reagent.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                reagent.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, copies);
                getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, reagent);
            }
        }
    }

    /**
     * This is for checking whether batch have plate or not.if batch does not have plate it will throw exception.
     *
     * @param dsLabel
     * @throws SapphireException
     */
    private void bigDyValidation(DataSet dsLabel) throws SapphireException {
        HashMap hmFilter = new HashMap();
        hmFilter.put("labelid", "MolBigDye");
        DataSet dsFilter = dsLabel.getFilteredDataSet(hmFilter);
        if (dsFilter.size() > 0) {
            /*
            String sql = "select u_ngbatchid,batchname,(select plateid from u_ngbatch_plate where u_ngbatchid in ( '" + StringUtil.replaceAll(dsFilter.getColumnValues("batchid", ";"), ";", "','") + "' )) as plateid " +
                    "from u_ngbatch where u_ngbatchid in ( '" + StringUtil.replaceAll(dsFilter.getColumnValues("batchid", ";"), ";", "','") + "' )"; */
            String sql = Util.parseMessage(PrintLabelSql.GET_Batch_Plate_BigDye, StringUtil.replaceAll(dsFilter.getColumnValues("batchid", ";"), ";", "','"), StringUtil.replaceAll(dsFilter.getColumnValues("batchid", ";"), ";", "','"));

            DataSet dsPlt = getQueryProcessor().getSqlDataSet(sql);
            if (dsPlt == null)
                throw new SapphireException("Error in SQL.Please contact your admin.");
            String batch = "";
            for (int i = 0; i < dsPlt.size(); i++) {
                if (Util.isNull(dsPlt.getValue(i, "plateid", "")))
                    batch = batch + ";" + dsPlt.getValue(i, "batchname", "");
            }
            if (batch.length() > 0) {
                batch = batch.substring(1);
                throw new SapphireException("You can't print this batch(" + batch + ") because batch does not have any plate.");
            }
        }
    }

    private DataSet getLabelForMolecular(String pltlabeltypeParam, String plttramLineParam, String plttramSTopParam, String batchplateArray[]) throws SapphireException {
        DataSet labelresult = new DataSet();
        labelresult.addColumn("batchid", DataSet.STRING);
        labelresult.addColumn("labelid", DataSet.STRING);
        labelresult.addColumn("versionid", DataSet.STRING);

        PropertyList pltPrintLabelPolicy = getConfigurationProcessor().getPolicy(PRINTLABEL_POLICY, NODEID_Plate);
        if (pltPrintLabelPolicy != null && pltPrintLabelPolicy.size() > 0) {
            PropertyListCollection pltlabelselectioninfocollection = pltPrintLabelPolicy.getCollection("labelselectioninfo");
            if (pltlabelselectioninfocollection != null && pltlabelselectioninfocollection.size() > 0) {
                PropertyList pltlabelselectioninfo = pltlabelselectioninfocollection.getPropertyList(0);
                if (pltlabelselectioninfo != null && pltlabelselectioninfo.size() > 0) {
                    PropertyListCollection pltselectlabelsCollection = pltlabelselectioninfo.getCollection("selectlabels");
                    if (pltselectlabelsCollection != null && pltselectlabelsCollection.size() > 0) {
                        for (int i = 0; i < pltselectlabelsCollection.size(); i++) {
                            PropertyList plTemp = pltselectlabelsCollection.getPropertyList(i);
                            if (plTemp != null && plTemp.size() > 0) {
                                String labeltype = plTemp.getProperty("labeltype", "");
                                //String transporttype = plTemp.getProperty("transporttype", "");
                                String tramline = plTemp.getProperty("tramline", "");
                                String tramstop = plTemp.getProperty("tramstop", "");
                                String labelmethod = plTemp.getProperty("labelmethod", "");
                                String labelmethodversionid = plTemp.getProperty("labelmethodversionid", "");
                                //String methodologyFrmPollicy = plTemp.getProperty("methodology", "");
                                if (pltlabeltypeParam.equalsIgnoreCase(labeltype) && plttramLineParam.equalsIgnoreCase(tramline)) {
                                    if (plttramSTopParam.equalsIgnoreCase(tramstop)) {
                                        labelresult.clear();
                                        for (int k = 0; k < batchplateArray.length; k++) {
                                            int index = labelresult.addRow();
                                            labelresult.setValue(index, "batchid", batchplateArray[k]);
                                            labelresult.setValue(index, "labelid", labelmethod);
                                            labelresult.setValue(index, "versionid", labelmethodversionid);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return labelresult;
    }

    private DataSet getLabelId(String labeltypeParam, String tramLineParam, String tramSTopParam, DataSet dsTrakItemInfo) throws SapphireException {

        DataSet result = new DataSet();
        result.addColumn("sampleid", DataSet.STRING);
        result.addColumn("labelid", DataSet.STRING);
        result.addColumn("versionid", DataSet.STRING);
        HashMap<String, String> hmap = new HashMap<String, String>();
        //LinkedList<String> linkedList = new LinkedList<String>();

        if (!Util.isNull(labeltypeParam) && dsTrakItemInfo != null && dsTrakItemInfo.size() > 0) {
            //String methodology=dsTrakItemInfo.getColumnValues("methodology", ";");

            PropertyList plPrintLabelPolicy = getConfigurationProcessor().getPolicy(PRINTLABEL_POLICY, NODEID);

            if (plPrintLabelPolicy != null && plPrintLabelPolicy.size() > 0) {
                PropertyListCollection labelselectioninfocollection = plPrintLabelPolicy.getCollection("labelselectioninfo");
                if (labelselectioninfocollection != null && labelselectioninfocollection.size() > 0) {
                    PropertyList labelselectioninfo = labelselectioninfocollection.getPropertyList(0);
                    if (labelselectioninfo != null && labelselectioninfo.size() > 0) {
                        PropertyListCollection selectlabelsCollection = labelselectioninfo.getCollection("selectlabels");
                        if (selectlabelsCollection != null && selectlabelsCollection.size() > 0) {
                            for (int i = 0; i < selectlabelsCollection.size(); i++) {
                                PropertyList plTemp = selectlabelsCollection.getPropertyList(i);
                                if (plTemp != null && plTemp.size() > 0) {
                                    String labeltype = plTemp.getProperty("labeltype", "");
                                    String transporttype = plTemp.getProperty("transporttype", "");
                                    String tramline = plTemp.getProperty("tramline", "");
                                    String tramstop = plTemp.getProperty("tramstop", "");
                                    String labelmethod = plTemp.getProperty("labelmethod", "");
                                    String labelmethodversionid = plTemp.getProperty("labelmethodversionid", "");
                                    String methodologyFrmPollicy = plTemp.getProperty("methodology", "");

                                    if (labeltypeParam.equalsIgnoreCase(labeltype)) {
                                        if (!Util.isNull(tramLineParam) && tramLineParam.equalsIgnoreCase(tramline) &&
                                                !Util.isNull(tramSTopParam) && tramSTopParam.equalsIgnoreCase(tramstop)) {
                                            result.clear();
                                            for (int k = 0; k < dsTrakItemInfo.size(); k++) {
                                                int index = result.addRow();
                                                result.setValue(index, "sampleid", dsTrakItemInfo.getValue(k, "linkkeyid1", ""));
                                                result.setValue(index, "labelid", labelmethod);
                                                result.setValue(index, "versionid", labelmethodversionid);
                                                //linkedList.add(dsTrakItemInfo.getValue(k, "linkkeyid1", ""));
                                            }
                                            break;
                                        } else if (!Util.isNull(methodologyFrmPollicy)) {
                                            hmap.clear();
                                            hmap.put("methodology", methodologyFrmPollicy);
                                            DataSet dsFiltr = dsTrakItemInfo.getFilteredDataSet(hmap);
                                            if (dsFiltr != null && dsFiltr.size() > 0) {
                                                for (int k = 0; k < dsFiltr.size(); k++) {
                                                    int index = result.addRow();
                                                    result.setValue(index, "sampleid", dsFiltr.getValue(k, "linkkeyid1", ""));
                                                    result.setValue(index, "labelid", labelmethod);
                                                    result.setValue(index, "versionid", labelmethodversionid);
                                                    //linkedList.add(dsTrakItemInfo.getValue(k, "linkkeyid1", ""));
                                                }
                                            }
                                        } else if (!Util.isNull(transporttype) && !CONTAINERTYPE.contains(transporttype)) {
                                            for (int k = 0; k < dsTrakItemInfo.size(); k++) {
                                                //if(!linkedList.contains(dsTrakItemInfo.getValue(k, "linkkeyid1", ""))) {
                                                if (!CONTAINERTYPE.contains(dsTrakItemInfo.getValue(k, "containertypeid", ""))) {
                                                    int index = result.addRow();
                                                    result.setValue(index, "sampleid", dsTrakItemInfo.getValue(k, "linkkeyid1", ""));
                                                    result.setValue(index, "labelid", labelmethod);
                                                    result.setValue(index, "versionid", labelmethodversionid);
                                                    // }
                                                }
                                            }
                                        } else {
                                            hmap.clear();
                                            hmap.put("containertypeid", transporttype);
                                            DataSet dsFiltr = dsTrakItemInfo.getFilteredDataSet(hmap);
                                            if (dsFiltr != null && dsFiltr.size() > 0) {
                                                for (int k = 0; k < dsFiltr.size(); k++) {
                                                    int index = result.addRow();
                                                    result.setValue(index, "sampleid", dsFiltr.getValue(k, "linkkeyid1", ""));
                                                    result.setValue(index, "labelid", labelmethod);
                                                    result.setValue(index, "versionid", labelmethodversionid);
                                                    //linkedList.add(dsTrakItemInfo.getValue(k, "linkkeyid1", ""));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * Description : This is for getting user's printer and department's default printer.
     *
     * @return
     * @throws SapphireException
     */
    private String getPrinterId() throws SapphireException {
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
        /* String sql = "select " +
                " (select a.printerid from u_userdefaultprinter a " +
                " where a.sysuserid='" + userId + "' and a.departmentid= '" + depratmentId + "' and a.extractiontype is null) as userprinter," +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '" + depratmentId + "' " +
                "  and nvl(isdefault,'N')='Y' and extractiontype is null) as deptprinter " +
                "  from dual"; */
        String sql = Util.parseMessage(PrintLabelSql.GET_Normal_Printer, userId, depratmentId, depratmentId);

        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo != null && dsInfo.size() > 0) {
            String userprinter = dsInfo.getValue(0, "userprinter", "");
            String deptprinter = dsInfo.getValue(0, "deptprinter", "");
            if (!Util.isNull(userprinter)) {
                printerId = userprinter;
            } else if (!Util.isNull(deptprinter)) {
                printerId = deptprinter;
                // assignDeptDefaultPrinterToUser(userId, depratmentId, printerId);
            }
        }
        return printerId;
    }

    /**
     * Description : If user printer not found it will set department printer to user.THIS NOT REQUIRED FOR new implementation.
     *
     * @param user
     * @param userDepartment
     * @param printerid
     * @throws SapphireException
     */
    private void assignDeptDefaultPrinterToUser(String user, String userDepartment, String printerid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "User");
        props.setProperty("sysuserid", user);
        props.setProperty("departmentid", userDepartment);
        props.setProperty("printerid", printerid);
        props.setProperty("printertype", "Device");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "userdefaultprinter_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in change printer.Error:" + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /**
     * Description : This is for getting user's color printer and department's default color printer.
     *
     * @param extractiontype
     * @return
     * @throws SapphireException
     */
    private String getColorPrinterIdForExtraction(String extractiontype) throws SapphireException {
        String printerId = "";
        String userId = connectionInfo.getSysuserId();
        String depratmentId = connectionInfo.getDefaultDepartment();
        /*String sql = "select " +
                " (select a.printerid from u_userdefaultprinter a " +
                " where a.sysuserid='" + userId + "' and a.departmentid='" + depratmentId + "' and a.extractiontype ='" + extractiontype + "') as userprinter, " +
                " (select printerid from u_departmentprinters where u_departmentprinters.departmentid = '" + depratmentId + "' " +
                " and nvl(isdefault,'N')='Y' and extractiontype ='" + extractiontype + "') as deptprinter from dual"; */
        String sql = Util.parseMessage(PrintLabelSql.GET_Colour_Printer, userId, depratmentId, extractiontype, depratmentId, extractiontype);

        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo == null) {
            throw new SapphireException("Please contact your admin.Query failed.Sql:" + sql);
        }
        if (dsInfo.size() > 0) {
            //String deptprinter = dsInfo.getValue(0,"addressid",""); old
            String userprinter = dsInfo.getValue(0, "userprinter", "");
            String deptprinter = dsInfo.getValue(0, "deptprinter", "");
            if (!Util.isNull(userprinter)) {
                printerId = userprinter;
            } else if (!Util.isNull(deptprinter)) {
                printerId = deptprinter;
            } else {
                throw new SapphireException("Default " + extractiontype + " Printer is not defined for " + userId + " user in " + depratmentId + " department.");
            }
        } else {
            throw new SapphireException("Default " + extractiontype + " Printer is not defined for " + userId + " user in " + depratmentId + " department.");
        }
        return printerId;
    }

    /**
     * Description: Label print for elution tube from accession data entry page
     *
     * @param sample
     * @return
     * @throws SapphireException
     */
    private String specialSamplePrintFromAccession(String sample) throws SapphireException {
        String samples = "";
        if (Util.isNull(sample)) {
            throw new SapphireException("Please select first to print.");
        }
       /* String sqlExtType = "select s.s_sampleid,st.u_extractiontype, s.u_molbatchspecimenid from s_sample s,s_sampletype st " +
                " where s.sampletypeid=st.s_sampletypeid and s.s_sampleid in ('" + StringUtil.replaceAll(sample, ";", "','") + "') order by u_molbatchspecimenid, s_sampleid";  */

        String sqlExtType = Util.parseMessage(PrintLabelSql.GET_Accession_ElutionTube, StringUtil.replaceAll(sample, ";", "','"));

        DataSet dsExtType = getQueryProcessor().getSqlDataSet(sqlExtType);
        if (dsExtType == null) {
            throw new SapphireException("Please contact your admin.Query failed.Sql:" + sqlExtType);
        }
        if (dsExtType.size() > 0) {
            DataSet dsNormal = new DataSet();
            dsNormal.addColumn("sample", DataSet.STRING);
            DataSet dsEluPrint = new DataSet();
            dsEluPrint.addColumn("sampleid", DataSet.STRING);
            dsEluPrint.addColumn("printerid", DataSet.STRING);
            int inr = 0;
            int inrElu = 0;
            for (int i = 0; i < dsExtType.size(); i++) {
                String sampleid = dsExtType.getString(i, "s_sampleid", "");
                String extractiontype = dsExtType.getString(i, "u_extractiontype", "");
                if (!Util.isNull(extractiontype)) {
                    String printerid = "";
                    if ("DNA".equalsIgnoreCase(extractiontype) || "TNA".equalsIgnoreCase(extractiontype) ||
                            "RNA".equalsIgnoreCase(extractiontype) || "Plasma".equalsIgnoreCase(extractiontype)
                            || "PROTEIN".equalsIgnoreCase(extractiontype)) {
                        printerid = getColorPrinterIdForExtraction(extractiontype);
                    } else {
                        printerid = getPrinterId();
                    }
                    if (printerid == null || "".equalsIgnoreCase(printerid)) {
                        throw new SapphireException("Default printer is not defined for the user " + connectionInfo.getSysuserId() + "." +
                                " corresponding to the department " + connectionInfo.getDefaultDepartment() + ". " +
                                "Also the department " + connectionInfo.getDefaultDepartment() + " doesn't have any default department.");
                    }
                    inrElu = dsEluPrint.addRow();
                    dsEluPrint.setValue(inrElu, "sampleid", sampleid);
                    dsEluPrint.setValue(inrElu, "printerid", printerid);
                } else {
                    inr = dsNormal.addRow();
                    dsNormal.setValue(inr, "sample", sampleid);
                }
            }
            if (dsEluPrint.size() > 0) {
                String allPrinter = dsEluPrint.getColumnValues("printerid", ";");
                String uniquePrinter = Util.getUniqueList(allPrinter, ";", true);
                String[] printerArr = StringUtil.split(uniquePrinter, ";");
                for (int p = 0; p < printerArr.length; p++) {
                    String printer = printerArr[p];
                    HashMap<String, String> hmPrinterFilter = new HashMap<>();
                    hmPrinterFilter.clear();
                    hmPrinterFilter.put("printerid", printer);
                    DataSet DiffPrinter = dsEluPrint.getFilteredDataSet(hmPrinterFilter);
                    PropertyList eluPrint = new PropertyList();
                    eluPrint.setProperty(GenerateLabel.PROPERTY_LABELSDCID, "Sample");
                    eluPrint.setProperty(GenerateLabel.PROPERTY_KEYID1, DiffPrinter.getColumnValues("sampleid", ";"));
                    eluPrint.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, "AccessionElutionTube");
                    eluPrint.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
                    eluPrint.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printer);
                    eluPrint.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
                    eluPrint.setProperty(GenerateLabel.PROPERTY_NUMCOPIES, "1");

                    try {
                        getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, eluPrint);
                    } catch (ActionException ex) {
                        String error = getTranslationProcessor().translate("Error in print.Error:" + ex.getMessage());
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                    }
                }
            }
            if (dsNormal.size() > 0) {
                sample = dsNormal.getColumnValues("sample", ";");
                samples = sample;
            }
        } else {
            samples = sample;
        }
        return samples;
    }

    private DataSet reagentPrintForMO(String batchplateArray[], String molottypeArray[]) throws SapphireException {
        DataSet labelresult = new DataSet();
        labelresult.addColumn("lot", DataSet.STRING);
        labelresult.addColumn("labelid", DataSet.STRING);
        labelresult.addColumn("versionid", DataSet.STRING);
        labelresult.addColumn("moletype", DataSet.STRING);

        DataSet pllicyDs = new DataSet();
        pllicyDs.addColumn("labeltype", DataSet.STRING);
        pllicyDs.addColumn("labelmethod", DataSet.STRING);
        pllicyDs.addColumn("labelmethodversionid", DataSet.STRING);
        pllicyDs.addColumn("methodologyfrmpollicy", DataSet.STRING);


        PropertyList pltPrintLabelPolicy = getConfigurationProcessor().getPolicy(PRINTLABEL_POLICY, "MOReagent");
        if (pltPrintLabelPolicy != null && pltPrintLabelPolicy.size() > 0) {
            PropertyListCollection pltlabelselectioninfocollection = pltPrintLabelPolicy.getCollection("labelselectioninfo");
            if (pltlabelselectioninfocollection != null && pltlabelselectioninfocollection.size() > 0) {
                PropertyList pltlabelselectioninfo = pltlabelselectioninfocollection.getPropertyList(0);
                if (pltlabelselectioninfo != null && pltlabelselectioninfo.size() > 0) {
                    PropertyListCollection pltselectlabelsCollection = pltlabelselectioninfo.getCollection("selectlabels");
                    if (pltselectlabelsCollection != null && pltselectlabelsCollection.size() > 0) {
                        for (int i = 0; i < pltselectlabelsCollection.size(); i++) {
                            PropertyList plTemp = pltselectlabelsCollection.getPropertyList(i);
                            if (plTemp != null && plTemp.size() > 0) {
                                String labeltype = plTemp.getProperty("labeltype", "");
                                if (Util.isNull(labeltype)) {
                                    String error = getTranslationProcessor().translate("Please define labeltype in MOReagent node in PrintLabel policy");
                                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                                }
                                String labelmethod = plTemp.getProperty("labelmethod", "");
                                if (Util.isNull(labelmethod)) {
                                    String error = getTranslationProcessor().translate("Please define labelmethod in MOReagent node in PrintLabel policy");
                                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                                }
                                String labelmethodversionid = plTemp.getProperty("labelmethodversionid", "");
                                if (Util.isNull(labelmethodversionid)) {
                                    String error = getTranslationProcessor().translate("Please define labelmethodversionid in MOReagent node in PrintLabel policy");
                                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                                }
                                String methodologyFrmPollicy = plTemp.getProperty("methodology", "");
                                if (Util.isNull(methodologyFrmPollicy)) {
                                    String error = getTranslationProcessor().translate("Please define Moletype as methodology in MOReagent node in PrintLabel policy");
                                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                                }

                                int index = pllicyDs.addRow();
                                pllicyDs.setValue(index, "labeltype", labeltype);
                                pllicyDs.setValue(index, "labelmethod", labelmethod);
                                pllicyDs.setValue(index, "labelmethodversionid", labelmethodversionid);
                                pllicyDs.setValue(index, "methodologyfrmpollicy", methodologyFrmPollicy);
                            }
                        }
                    }
                }
            }
        }

        for (int k = 0; k < batchplateArray.length; k++) {
            int index = labelresult.addRow();
            labelresult.setValue(index, "lot", batchplateArray[k]);
            String moletyp = molottypeArray[k];
            if (Util.isNull(moletyp)) {
                String error = getTranslationProcessor().translate("Label print is not possible as Mole Type is null for lot id:" + batchplateArray[k]);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }

            HashMap<String, String> hm = new HashMap<String, String>();
            hm.clear();
            hm.put("methodologyfrmpollicy", moletyp);
            DataSet dsFilter = pllicyDs.getFilteredDataSet(hm);
            if (Util.isNull(dsFilter.getValue(0, "labelmethod"))) {
                String error = getTranslationProcessor().translate("Label method is not define in policy for type:" + moletyp + ".Uncheck " + moletyp + " or contact Admin to print.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
            labelresult.setValue(index, "labelid", dsFilter.getValue(0, "labelmethod"));
            labelresult.setValue(index, "versionid", dsFilter.getValue(0, "labelmethodversionid"));
            labelresult.setValue(index, "moletype", dsFilter.getValue(0, "methodologyfrmpollicy"));
        }
        return labelresult;
    }

    private DataSet getReagentLabelMethod(String labelType) throws SapphireException{
        DataSet reagentResult= new DataSet();
        reagentResult.addColumn("labeltype",DataSet.STRING);
        reagentResult.addColumn("labelmethod",DataSet.STRING);
        reagentResult.addColumn("labelmethodversionid",DataSet.STRING);

        PropertyList plReagentPolicy=getConfigurationProcessor().getPolicy(PRINTLABEL_POLICY,"ReagentLabelInfo");
        if(plReagentPolicy != null || plReagentPolicy.size()>0){
            PropertyListCollection plReagentCollection=plReagentPolicy.getCollection("labelselectioninfo");
            if(plReagentCollection !=null || plReagentCollection.size()>0){
                PropertyList plReagentSelectioninfo = plReagentCollection.getPropertyList(0);
                if(plReagentSelectioninfo != null || plReagentSelectioninfo.size()>0){
                    PropertyListCollection plReagentSelection=plReagentSelectioninfo.getCollection("selectlabels");
                    if(plReagentSelection != null || plReagentSelection.size()>0){
                        for(int i=0;i<plReagentSelection.size();i++){
                            PropertyList plReagent=plReagentSelection.getPropertyList(i);
                            if(plReagent !=null || plReagent.size()>0){
                                String labeltype= plReagent.getProperty("labeltype","");
                                String labelmethod= plReagent.getProperty("labelmethod","");
                                String labelmethodversionid=plReagent.getProperty("labelmethodversionid","");
                                if(labeltype.equalsIgnoreCase(labelType)){
                                    reagentResult.clear();
                                    int row=reagentResult.addRow();
                                    reagentResult.setValue(row,"labeltype",labeltype);
                                    reagentResult.setValue(row,"labelmethod",labelmethod);
                                    reagentResult.setValue(row,"labelmethodversionid",labelmethodversionid);
                                }
                            }
                        }

                    }
                }
            }
        }
        return reagentResult;
    }
}