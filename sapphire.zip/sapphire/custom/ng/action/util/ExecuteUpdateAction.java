package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DBAccess;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ExecuteUpdateAction extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid2 = properties.getProperty("keyid2");
        String sdidataid = properties.getProperty("sdidataid", "");
        String sdidataitemid = properties.getProperty("sdidataitemid", "");

        /*String sqlUpdate = "update sdidata set keyid2='" + keyid2 + "' where sdidataid='" + sdidataid + "'" +
                " and sdcid='Accession'";*/
        String sqlUpdate = Util.parseMessage(AccessionPageSql.UPDATE_SDIDATA, keyid2, sdidataid);
        database.executeUpdate(sqlUpdate);
        /*sqlUpdate = "update sdidataitem set keyid2='" + keyid2 + "'" +
                " where sdidataitemid in('" + StringUtil.replaceAll(sdidataitemid, ";", "','") + "')" +
                " and sdcid='Accession'"*/
        sqlUpdate = Util.parseMessage(AccessionPageSql.UPDATE_SDIDATAITEM, keyid2, StringUtil.replaceAll(sdidataitemid, ";", "','"));
        database.executeUpdate(sqlUpdate);
    }
}
