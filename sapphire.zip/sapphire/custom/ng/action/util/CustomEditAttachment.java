package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

/**
 * Created by rrmandal on 5/13/2017.
 */
public class CustomEditAttachment extends BaseAction {


    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sdcid=properties.getProperty("sdcid","");
        String keyid1=properties.getProperty("keyid1","");
        String keyid2=properties.getProperty("keyid2","");
        String keyid3=properties.getProperty("keyid3","");
        String attachmentnum=properties.getProperty("attachmentnum","");
        String attachmentdesc=properties.getProperty("attachmentdesc","");
        String attachmenttype=properties.getProperty("attachmenttype","");

        String sql = "update sdiattachment set ";
        boolean flag1=false;
        boolean flag2=false;
        if(!Util.isNull(attachmentdesc)) {
            sql += "attachmentdesc = '" + attachmentdesc + "' ";
            flag1=true;
        }
        if(!Util.isNull(attachmenttype)) {
            if(flag1)
                sql += ",u_attachmenttype='"+attachmenttype+"'";
            else
                sql += "u_attachmenttype='"+attachmenttype+"'";
            flag2=true;
        }
        if(flag1 || flag2) {
            sql += " where sdcid = '" + sdcid + "' and keyid1='" + keyid1 + "' and keyid2='" + keyid2 + "' and keyid3='" + keyid3 + "' and attachmentnum='" + attachmentnum + "'";
            int succs = getQueryProcessor().execSQL(sql);
            if (succs != 1) {
                throw new SapphireException("Attachment info cannot be modified");
            }
        }
    }
}
