package sapphire.custom.ng.action.util;

import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.MultiSampleChild;
import sapphire.error.ErrorDetail;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by tsahoo on 6/11/2016.
 */
public class CreateChildSamples extends BaseAction {

    public static final String PROPERTY_PARENT_SAMPLEID = MultiSampleChild.PROPERTY_PARENT_SAMPLEID;
    public static final String PROPERTY_CHILD_COPIES = MultiSampleChild.PROPERTY_CHILD_COPIES;
    public static final String PROPERTY_MODE = MultiSampleChild.PROPERTY_MODE;
    public static final String PROPERTY_CHILD_QUANTITY = MultiSampleChild.PROPERTY_CHILD_QUANTITY;
    public static final String PROPERTY_CHILD_UNIT = MultiSampleChild.PROPERTY_CHILD_UNIT;
    public static final String PROPERTY_CHILD_SAMPLETYPEID = MultiSampleChild.PROPERTY_CHILD_SAMPLETYPEID;
    public static final String PROPERTY_CHILD_CONTAINERTYPEID = "containertypeid";
    public static final String PROPERTY_COPYDOWNCOLUMNS = MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS;
    public static final String PROPERTY_SYNCPARENT = MultiSampleChild.PROPERTY_SYNCPARENT;


    public static final String ID = "CreateChildSamples";
    public static final String VERSIONID = "1";


    public static final String DEFAULT_COPY_DOWN = "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;" +
            "u_collectiontime;collectiondt;u_receivetime;receiveddt;u_biosampleorigin;u_fixationmethod;u_additionalbodysite;u_aliquotinfo";
    public static final String PROPERTY_MODE_DERIVATIVE = "derivative";
    public static final String PROPERTY_MODE_ALIQUOT = "aliquot";
    /* Changed By Subhendu  - 31/01/2018 - Adding extra column +*/
    public static final String PROPERTY_ADD_EXTRA_PROPERTY = "addextraproperty";
    /* Changed By Subhendu  - 31/01/2018 - Adding extra column -*/

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        //input Properties here
        validateMandatoryInputs(properties);

        //String copyDownColums = DEFAULT_COPY_DOWN;
        String copyDownColums = addExtraCopyDown(properties.getProperty(PROPERTY_COPYDOWNCOLUMNS));
        copyDownColums = removeFromCopyDown(properties, copyDownColums); // Remove copy down if user sends in propertylist

        // properties.setProperty("__trackitem_custodialdepartmentid", connectionInfo.getDefaultDepartment());
        properties.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, copyDownColums);

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, properties);
            /* Changed By Subhendu  - 31/01/2018 - Adding extra column +*/
            addExtraProperty(properties);
            /* Changed By Subhendu  - 31/01/2018 - Adding extra column -*/
        } catch (
                SapphireException e) {
            throw new SapphireException(getTranslationProcessor().translate("Unable to create child sample.") + "\n" + e.getMessage());
        }
    }

    private String addExtraCopyDown(String addonColumns) throws SapphireException {
        String newColumns = "";
        String addonColumnsArr[] = StringUtil.split(addonColumns, ";");
        for (String item : addonColumnsArr) {
            if (!DEFAULT_COPY_DOWN.contains(item)) {
                newColumns += ";" + item;
            }
        }

        return DEFAULT_COPY_DOWN + newColumns;
    }

    private String removeFromCopyDown(PropertyList properties, String copyDownColumns) throws SapphireException {
        String finalCopyDown = "";
        String copyDownColumsArr[] = StringUtil.split(copyDownColumns, ";");
        for (String item : copyDownColumsArr) {
            String itemP = properties.getProperty(item, "");
            if ("".equalsIgnoreCase(itemP)) {
                finalCopyDown += ";" + item;
            }
        }
        if (finalCopyDown.startsWith(";")) {
            finalCopyDown = finalCopyDown.substring(1);
        }


        return finalCopyDown;
    }

    private void validateMandatoryInputs(PropertyList properties) throws SapphireException {

        String input_parentsamples = properties.getProperty(PROPERTY_PARENT_SAMPLEID, "").trim();
        String input_childcopies = properties.getProperty(PROPERTY_CHILD_COPIES, "1").trim();
        String input_childquantity = properties.getProperty(PROPERTY_CHILD_QUANTITY, "").trim();
        String input_childunit = properties.getProperty(PROPERTY_CHILD_UNIT, "").trim();
        String input_childsampletypeid = properties.getProperty(PROPERTY_CHILD_SAMPLETYPEID, "").trim();
        String input_containertypeid = properties.getProperty(PROPERTY_CHILD_CONTAINERTYPEID, "").trim();

        if ("".equalsIgnoreCase(input_parentsamples)) {
            String err = "Parent Sample is Missing.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
    }
    /* Changed By Subhendu  - 31/01/2018 - Adding extra column +*/
    private void addExtraProperty(PropertyList properties) throws SapphireException{
    	String addExtraProperty = properties.getProperty(PROPERTY_ADD_EXTRA_PROPERTY,"");
    	String[] tempAddExtraProperty = StringUtil.split(addExtraProperty, ";");
    	String newKeyId1 = properties.getProperty("newkeyid1","");
    	PropertyList pl = new PropertyList();
    	
	    	if(!"".equals(addExtraProperty) && !"".equals(newKeyId1)){
	    		pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
	    		pl.setProperty(EditSDI.PROPERTY_KEYID1, newKeyId1);
		    	for(int i =0;i< tempAddExtraProperty.length;i++){
		    		pl.setProperty(tempAddExtraProperty[i], properties.getProperty(tempAddExtraProperty[i],""));
		    	}
		    	getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	    	}
    }
    /* Changed By Subhendu  - 31/01/2018 - Adding extra column -*/

}
