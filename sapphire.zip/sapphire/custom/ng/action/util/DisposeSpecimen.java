package sapphire.custom.ng.action.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class DisposeSpecimen extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1");
        String eventtype = properties.getProperty("eventtype", "");
        String currentstep = properties.getProperty("currentstep", "");
        String evntreason = properties.getProperty("evntreason", "");
        if (Util.isNull(keyid1))
            throw new SapphireException("Specimen can't be blank.");
        PropertyList prop = new PropertyList();
        prop.setProperty("keyid1", keyid1);
        prop.setProperty("eventtype", eventtype);
        prop.setProperty("currentstep", currentstep);
        prop.setProperty("evntreason", evntreason);
        try {
            getActionProcessor().processAction("SpecimenOperation", "1", prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to perform Specimen Operation." + ex.getMessage());
        }
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
        prop.setProperty("storagestatus", "Disposed");
        prop.setProperty("storagedisposalstatus", "Disposed");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to perform EditSDI." + ex.getMessage());
        }
    }
}
