package sapphire.custom.ng.action;

import java.io.File;

import com.labvantage.sapphire.actions.sdi.DeleteSDIDetail;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditSDIDetail;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

public class CopyNanoBatch extends BaseAction {

    public static String ID = "CopyNanoBatch";
    public static String VERSIONID = "1";

    private static final String FILELOCATIONPOLICY = "FileLocationPolicy";
    //private static final String NODEID = "NanoCopyFileForBatch";
    private static final String NODEID = "MolecularDefaultLocation";
    private static final String PROPS_LOCATION = "location";
    private static final String PROPS_LOCATIONS = "locations";

    public void processAction(PropertyList properties) throws SapphireException {
        String parentbatchid = properties.getProperty("parentbatchid");
        String origin = properties.getProperty("origin");
        String batchtype = properties.getProperty("batchtype");
        String batchmovestatus = properties.getProperty("batchmovestatus", "");

        if (parentbatchid == null || parentbatchid.equalsIgnoreCase("")) {
            throw new SapphireException("Batch id is not selected.");
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(AddSDI.PROPERTY_TEMPLATEKEYID1, parentbatchid);
        prop.setProperty("batchtype", batchtype);
        prop.setProperty("batchstatusview", "(null)");
        prop.setProperty("batchmovestatus", batchmovestatus);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (SapphireException s) {
            throw new SapphireException("Something went wrong.Batch can not be copied");
        }
        String newbatchid = prop.getProperty("newkeyid1");
        if (!Util.isNull(newbatchid)) {
            updateBatch(parentbatchid, newbatchid, origin);
            updateBatchDetail(newbatchid);
            addAttachmentToChild(parentbatchid, newbatchid);
            deleteReagentInstrument(newbatchid);
        }
        properties.setProperty("childbatchid", newbatchid);
    }

    private void updateBatch(String parentbatch, String batch, String origin) throws SapphireException {
        String sql = "select parentbatchid from u_ngbatch where u_ngbatchid='" + parentbatch + "'";
        DataSet dsParentBatch = getQueryProcessor().getSqlDataSet(sql);
        String runparentbatch = dsParentBatch.getValue(0, "parentbatchid", "");
        PropertyList editbatch = new PropertyList();
        editbatch.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        editbatch.setProperty(EditSDI.PROPERTY_KEYID1, batch);
        editbatch.setProperty("origin", origin);
        if (Util.isNull(runparentbatch)) {
            editbatch.setProperty("parentbatchid", parentbatch);
        } else {
            editbatch.setProperty("parentbatchid", runparentbatch);
        }
        editbatch.setProperty("batchcompletedts", "(null)");
        editbatch.setProperty("batchmovestatus", "");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editbatch);
        } catch (SapphireException se) {
            throw new SapphireException("Can not update Batch");
        }
        //throw new SapphireException("Can not update Batch");
    }

    private void updateBatchDetail(String newbatch) throws SapphireException {
        String removetag = "select sampleid from u_ngbatch_sample where u_ngbatchid='" + newbatch + "'";
        DataSet dsremovetag = getQueryProcessor().getSqlDataSet(removetag);
        PropertyList proptag = new PropertyList();
        proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
        proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, newbatch);
        proptag.setProperty("sampleid", dsremovetag.getColumnValues("sampleid", ";"));
        proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        // proptag.setProperty("tagid",
        // StringUtil.repeat("(null)",dsremovetag.size(),";"));
        proptag.setProperty("tagid", "(null)");
        proptag.setProperty("rulebypass", "Y");
        try {
            getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail");
        }
    }

    private void addAttachmentToChild(String parentbatchid, String newbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.COPY_ATTACHMENT_BY_BATCHID,
                StringUtil.replaceAll(parentbatchid, ";", "','"));
        DataSet dsDetails = getQueryProcessor().getSqlDataSet(sql);
        PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy(FILELOCATIONPOLICY, NODEID);
        if (plCaseFilePolicy == null)
            throw new SapphireException("File Location path can't be found");
        PropertyListCollection plc = plCaseFilePolicy.getCollection(PROPS_LOCATIONS);
        String newfileLocation = "";
        if (plc != null) {
            newfileLocation = plc.getPropertyList(0).getProperty(PROPS_LOCATION);
            //CHECK FOLDER
            newfileLocation = Util.createFolderForMolecular(newfileLocation, "NanoString");

            if (Util.isNull(newfileLocation))
                throw new SapphireException("Please specify the path for keeping the plate maps in the policy "
                        + FILELOCATIONPOLICY + " under the node " + NODEID);
        }
        String newFile = "";
        if (dsDetails != null && dsDetails.size() > 0) {
            for (int i = 0; i < dsDetails.size(); i++) {
                newFile = Util.copyFile(dsDetails.getValue(i, "filename", ""), newfileLocation);
                PropertyList plAttachment = new PropertyList();
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newbatchid);
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newFile);
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(newFile).getName());
                plAttachment.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, plAttachment);
                } catch (SapphireException se) {
                    throw new SapphireException("File is not attached to a batch");
                }
            }

        }
    }

    private void deleteReagentInstrument(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_REAGENT_BY_BATCHID, batchid);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("reagentid", dsReagents.getColumnValues("reagentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }

        sql = Util.parseMessage(MolecularSql.GET_INSTRUMENT_BY_BATCHID, batchid);
        DataSet dsInstruments = getQueryProcessor().getSqlDataSet(sql);
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("instrumentid", dsInstruments.getColumnValues("instrumentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

}
