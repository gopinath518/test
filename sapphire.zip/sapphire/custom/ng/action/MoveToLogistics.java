package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by dkundu on 11/4/2016.
 */
public class MoveToLogistics extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        if(properties == null || properties.size()==0)
            throw new SapphireException("PropertyList does not contain any property");
        String currenttramstop = properties.getProperty("u_currentmovementstep");
        String sampleid = properties.getProperty("keyid1");

        if(sampleid == null || currenttramstop == null)
            throw new SapphireException("Error: Insufficient values in PropertyList");

        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0,department.lastIndexOf('-'));
        String destination = site + "-Accessioning";//"-Logistic";
        if(!Util.validateDepartment(destination , getQueryProcessor(), getTranslationProcessor()))
            throw new SapphireException("Error: Unable to route sample. Department: "+destination+" does not exist");

        try{
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty("keyid1", sampleid);
            props.setProperty("u_currentmovementstep", currenttramstop);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
            props.setProperty("u_currenttramstop", currenttramstop);
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("custodialdepartmentid", destination);
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }
        catch (SapphireException e){
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += e.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
