package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

/**
 * Created by aritra.banerjee on 3/28/2017.
 */
public class AssignInstrument extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String instrument = properties.getProperty("instrument");
        String protocolname = properties.getProperty("protocolname");
        String sampleid = properties.getProperty("sampleid");
        String testcode = properties.getProperty("testcode");

        String sql = "select u_sampletestcodemapid from u_sampletestcodemap where s_sampleid='"+sampleid+"' and lvtestcodeid='"+testcode+"'";

        try {
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            if(ds == null)
                throw new SapphireException("Error: Unable to Execute Query in SampleTestCodeMap.");
            if(ds.size() == 0)
                throw new SapphireException("Error: No Entry in SampleTestCodeMap for Sample - "+sampleid+" and Test Code -"+testcode+".");

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampletestcodemapid",";"));
            pl.setProperty("instrumenttype", instrument);
            pl.setProperty("ihcprotocol", protocolname);


            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

        } catch (Exception ex) {
            throw new SapphireException("Error: Unable to Process Update Value in SampleTestCodeMap ");

        }


    }


}
