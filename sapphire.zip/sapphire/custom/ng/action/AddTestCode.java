package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;


/**
 * Created by Mayank Pandey on 3/23/2016.
 * This Action is adding multiple test and testpanel to multiple samples simultaneously  .
 * Updated tables are u_sample_testcode_map and u_sample_testcode_steps_map
 * Rectified for NEW SDC SampleTestcodeStpMap
 */
public class AddTestCode extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {
       /* String sampleids = properties.getProperty("s_sampleid", "");
        String lvtestcodes = properties.getProperty("lvtestcode", "");
        String meth = properties.getProperty(AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, "");

        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, sampleids);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, lvtestcodes);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, meth);
        getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);*/
        getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, properties);
        properties.setProperty("msg", properties.getProperty("msg", ""));
    }


}
