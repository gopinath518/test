package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by smitra on 5/20/2016.
 * @desc : This action is used to update how many pieces are required for a samples
 * Mandatory Input:
 * @param1 : Sample Id
 * @param2 : Number of pieces
 * @throws : SapphireException
 */
public class NumOfPieces extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String numofpieces = properties.getProperty("numofpieces");
        updateNumOfPieces(sampleid,numofpieces);
    }

    /**
     * @desc :This method updated the value of column"numofpieces" into Sample table
     * @param sampleid
     * @param numofpieces
     * @throws SapphireException
     */
    private void updateNumOfPieces(String sampleid, String numofpieces) throws SapphireException {

        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("u_numofpieces", numofpieces);


            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += ae.getMessage();
            throw new SapphireException( ErrorDetail.TYPE_VALIDATION, error);
        }
    }

}
