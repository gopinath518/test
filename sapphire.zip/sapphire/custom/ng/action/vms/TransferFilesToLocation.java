package sapphire.custom.ng.action.vms;

import org.apache.tools.ant.util.FileUtils;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class TransferFilesToLocation extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String choosepath = properties.getProperty("choosepath", "");
        String keyid1 = properties.getProperty("keyid1", "");
        if (Util.isNull(keyid1))
            throw new SapphireException("Please select file(s).");
        if (Util.isNull(choosepath))
            throw new SapphireException("Please choose path where to copy/transfer.");
        String sql = Util.parseMessage(ApSql.GET_IMAGES_VMS, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsGetFOldersInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsGetFOldersInfo.size() == 0)
            throw new SapphireException("No records found.");
        for (int i = 0; i < dsGetFOldersInfo.size(); i++) {
            String rootpath = dsGetFOldersInfo.getValue(i, "rootfolder", "");
            String folderpath = dsGetFOldersInfo.getValue(i, "folderpath", "");
            String finalpath = StringUtil.replaceAll(folderpath, rootpath, choosepath);
            if (Util.isNull(finalpath))
                throw new SapphireException("Copy path can't be blank.");
            File source = new File(folderpath);
            File dest = new File(finalpath);

            //copy source to target using Files Class
            try {
                copyFileUsingJava7Files(source, dest);
            } catch (IOException ex) {
                throw new SapphireException("Unable to meove" + ex.getMessage());
            }

        }
        properties.setProperty("msg", "Images has been copied to " + choosepath);
    }

    private void copyFileUsingJava7Files(File source, File dest) throws IOException {
        Files.copy(source.toPath(), dest.toPath());
    }
}
