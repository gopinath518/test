package sapphire.custom.ng.action.vms;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public class DeleteVMSSubFolder extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String folderid = properties.getProperty("u_vmsfolderid", "");
        String sql = Util.parseMessage(ApSql.GET_DETAILS_BY_FOLDERID, folderid);
        DataSet dsFolderInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsFolderInfo == null || dsFolderInfo.size() == 0) {
            String errMsg = getTranslationProcessor().translate("This folder doesn't exist into the system.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String rootpath = dsFolderInfo.getValue(0, "rootfolder", "");
        String methodology = Util.getUniqueList(dsFolderInfo.getColumnValues("methodology", ";"), ";", true);
        DataSet dsMountedPath = getMountedPath(methodology);
        HashMap hm = new HashMap();
        hm.clear();
        /*hm.put("windowspath", rootpath);
        DataSet dsMountFolderFilter = dsMountedPath.getFilteredDataSet(hm);
        if (dsMountFolderFilter.size() == 0) {
            String errMsg = getTranslationProcessor().translate(rootpath + " directory not found.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }*/
        String serverpath = dsMountedPath.getValue(0, "mounteddrive");
        if (Util.isNull(rootpath)) {
            String errMsg = getTranslationProcessor().translate("Root path can't be null.Please contact to Admin to provide a root path in configaration.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        hm.clear();
        hm.put("u_vmsfolderid", folderid);
        hm.put("type", "FLD");
        DataSet dsFolderFilter = dsFolderInfo.getFilteredDataSet(hm);
        if (dsFolderFilter == null || dsFolderFilter.size() == 0) {
            String errMsg = getTranslationProcessor().translate("This is not valid folder. You can delete only folder.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String folderpath = dsFolderInfo.getValue(0, "folderpath", "");
        if (!Util.isNull(folderid)) {
            if (Util.isNull(folderpath)) {
                String errMsg = getTranslationProcessor().translate("Folder path can't be null for the folder Id:" + folderid);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            String finalserverfolderpath = StringUtil.split(folderpath, rootpath)[1];
            finalserverfolderpath = StringUtil.replaceAll(finalserverfolderpath, "\\", "/");
            String servdir = serverpath + "" + finalserverfolderpath;
            File existingDir = new File(servdir);
            //TODO WILL OPEN FOR SERVER
            if (!existingDir.isDirectory()) {
                String errMsg = getTranslationProcessor().translate(folderpath + " This is not valid directory.You can't create any subfolder here.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            sql = Util.parseMessage(ApSql.GET_OTEHRS_FILES_EXIST_BY_FOLDERID, folderid);
            DataSet dsSubFolderDetails = getQueryProcessor().getSqlDataSet(sql);
            if (dsSubFolderDetails.size() == 0) {
                delete(existingDir);
            } else {
                String errMsg = getTranslationProcessor().translate("Images(s) found into <b><u>" + folderpath + "</u></b> folder. You can't proceed.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "VMSFolder");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, folderid);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Can't delete folder.");
            }
        }
        //throw new SapphireException("test");
    }

    public static void delete(File file) throws SapphireException {

        if (file.isDirectory()) {
            //directory is empty, then delete it
            if (file.list().length == 0) {

                file.delete();
                System.out.println("Directory is deleted : "
                        + file.getAbsolutePath());
            } else {
                //list all the directory contents
                String files[] = file.list();
                for (String temp : files) {
                    //construct the file structure
                    File fileDelete = new File(file, temp);

                    //recursive delete
                    delete(fileDelete);
                }

                //check the directory again, if empty then delete it
                if (file.list().length == 0) {
                    file.delete();
                    System.out.println("Directory is deleted : "
                            + file.getAbsolutePath());
                }
            }

        } else {
            //if file, then delete it
            file.delete();
            System.out.println("File is deleted : " + file.getAbsolutePath());
        }
    }

    private DataSet getMountedPath(String methodology) throws SapphireException {
        DataSet dsMountedPath = null;
        /*String sql = ApSql.GET_WINDOWS_MAPPING_PATH;
        dsMountedPath = getQueryProcessor().getSqlDataSet(sql);*/
        String crrntdept = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(crrntdept, "-")[0];
        //String sql = ApSql.GET_WINDOWS_MAPPING_PATH;
        String sql = Util.parseMessage(ApSql.GET_WINDOWS_MAPPING_PATH, site, methodology);

        if (dsMountedPath == null)
            throw new SapphireException("Network path and mounted drive mapping info cannot be obtained from database.");
        if (dsMountedPath.size() == 0)
            throw new SapphireException("The Query:\n" + sql + "\n is returning no row.");
        if (dsMountedPath.size() > 1)
            throw new SapphireException(site + " site has more than one mounted path to scan image(s).");

        return dsMountedPath;
    }
}
