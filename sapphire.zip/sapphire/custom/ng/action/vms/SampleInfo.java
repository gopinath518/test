package sapphire.custom.ng.action.vms;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class SampleInfo extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid", "");
        logger.info("SampleInfo:", "Scanned Sampleid: " + sampleid);
        try {
            if (Util.isNull(sampleid)) {
                logger.info("SampleInfo:", "Scanned Specimen ID can't be blank");
                throw new SapphireException("Specimen ID can't be blank.");
            }
            logger.info("SampleInfo:", "Scanned input is not blank");
            String sql = Util.parseMessage(ApSql.GET_SPONSOR_PROJECT_INFO_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsInfo == null || dsInfo.size() == 0) {
                logger.info("SampleInfo:", "Invalid specimen. No Sponsor, Project data found.");
                throw new SapphireException("Invalid specimen.");
            }
            logger.info("SampleInfo:", "Valid specimen. Sponsor, Project data found.");
            sql = Util.parseMessage(ApSql.GET_TESTNAME_BY_SAMPLEID, sampleid);
            DataSet dsTestInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTestInfo.size() == 0) {
                logger.info("SampleInfo:", "No Test found into the specimen.");
            }
            dsTestInfo.showData();
            String sponsorname = dsInfo.getColumnValues("sponsorname", ";");
            String projectprotocolid = dsInfo.getColumnValues("projectprotocolid", ";");
            String u_sponsorid = dsInfo.getColumnValues("u_sponsorid", ";");
            String u_bioprojectsid = dsInfo.getColumnValues("u_bioprojectsid", ";");
            String u_accessionid = dsInfo.getColumnValues("u_accessionid", ";");
            String u_clientspecimenid = dsInfo.getColumnValues("u_clientspecimenid", ";");
            String testname = "";
            String subjectid = "";
            if (dsTestInfo != null || dsTestInfo.size() > 0) {
                testname = dsTestInfo.getValue(0, "testname", "");
                logger.info("SampleInfo:", "Test found into the specimen.");
                dsTestInfo.showData();
            }
            sql = Util.parseMessage(ApSql.GET_SUBJECT_BY_SAMPLEID, sampleid);
            DataSet dsSubjectInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsSubjectInfo != null || dsSubjectInfo.size() > 0) {
                subjectid = dsSubjectInfo.getValue(0, "subjectid", "");
                logger.info("SampleInfo:", "Subject found into the specimen.");
                dsSubjectInfo.showData();
            }
            if (dsSubjectInfo.size() == 0) {
                logger.info("SampleInfo:", "No Subject found into the specimen.");
            }
            properties.setProperty("sponsor", sponsorname);
            properties.setProperty("study", projectprotocolid);
            properties.setProperty("u_sponsorid", u_sponsorid);
            properties.setProperty("u_bioprojectsid", u_bioprojectsid);
            properties.setProperty("AccessionID", u_accessionid);
            properties.setProperty("TestName", testname);
            properties.setProperty("SubjectID", subjectid);
            properties.setProperty("ClientSpecimenID", u_clientspecimenid);
            logger.info("Valid Information GET:", properties.toJSONString());
            logger.info("SampleInfo:", "Execution Exit");
        } catch (Exception ex) {
            logger.info("SampleInfo", "Exception:: " + ex.getMessage());
            throw new SapphireException("Exception:" + ex.getMessage());
        }
        logger.info("SampleInfo:", "Exit" + sampleid);
    }
}
