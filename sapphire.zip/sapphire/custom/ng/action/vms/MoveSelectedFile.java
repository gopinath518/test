package sapphire.custom.ng.action.vms;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.HashMap;

public class MoveSelectedFile extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1", "");
        String choosefolderid = properties.getProperty("choosefolderid", "");
        String sql = Util.parseMessage(ApSql.GET_IMAGEDETAILS_BY_ID, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsFolderInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsFolderInfo == null || dsFolderInfo.size() == 0) {
            String errMsg = getTranslationProcessor().translate("This image doesn't exist into the system.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String rootpath = dsFolderInfo.getValue(0, "rootfolder", "");
        String presentfolder = dsFolderInfo.getValue(0, "presentfolder", "");
        String sponsorname = "", projectprotocolid = "";
        String sponsorid = dsFolderInfo.getValue(0, "sponsorid", "");
        String projectid = dsFolderInfo.getValue(0, "projectid", "");
        //GET SPONSOR INFORMATION
        sql = Util.parseMessage(ApSql.GET_SPONSOR_PROJECT_INFO_BY_SPON, sponsorid);
        DataSet dsSponsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSponsInfo.size() > 0) {
            sponsorname = dsSponsInfo.getValue(0, "sponsorname", "");
        }
        //GET PROJECT INFORMATION
        sql = Util.parseMessage(ApSql.GET_SPONSOR_PROJECT_INFO_BY_PROJCT, projectid);
        DataSet dsProjectInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsProjectInfo.size() > 0) {
            projectprotocolid = dsProjectInfo.getValue(0, "projectprotocolid", "");
        }
        //CHECK PRESENT FOLDER IS SAME WITH CHOOSE FOLDER
        if (presentfolder.equalsIgnoreCase(choosefolderid)) {
            return;
        }
        //CHECK ROOT PATH IS NOT BLACK FOR SELECTED FILE
        if (Util.isNull(rootpath)) {
            String errMsg = getTranslationProcessor().translate("Root path can't be null.Please contact to Admin to provide a root path in configaration.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        //GET MOUNTED PATH FROM ENVIRONMENT PROPS
        String methodology = Util.getUniqueList(dsFolderInfo.getColumnValues("methodology", ";"), ";", true);
        DataSet dsMountedPath = getMountedPath(methodology);
        HashMap hm = new HashMap();
        hm.clear();
        //GET SERVER PATH
        String serverpath = dsMountedPath.getValue(0, "mounteddrive");
        for (int i = 0; i < dsFolderInfo.size(); i++) {
            String keyid1id = dsFolderInfo.getValue(i, "u_vmsfolderid", "");
            hm.clear();
            //hm.put("u_vmsfolderid", keyid1);
            hm.put("u_vmsfolderid", keyid1id);
            hm.put("type", "IMG");
            DataSet dsImageFilter = dsFolderInfo.getFilteredDataSet(hm);
            if (dsImageFilter == null || dsImageFilter.size() == 0) {
                String errMsg = getTranslationProcessor().translate("This is not valid image. You can move only image.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
        }
        //GET CHOOSE FOLDER DETAILS
        sql = Util.parseMessage(ApSql.GET_DETAILS_BY_FOLDERID, choosefolderid);
        DataSet dsChooseFolderInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsChooseFolderInfo == null || dsChooseFolderInfo.size() == 0) {
            String errMsg = getTranslationProcessor().translate("This choose folder doesn't exist into the system.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        if (dsChooseFolderInfo.size() > 1) {
            String errMsg = getTranslationProcessor().translate("File can't movable multiple folders at a time");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        //CHECK CHOOSE FOLDER IS VALID FOLDER OR NOT
        hm.clear();
        hm.put("u_vmsfolderid", choosefolderid);
        hm.put("type", "FLD");
        DataSet dsFolderFilter = dsChooseFolderInfo.getFilteredDataSet(hm);
        if (dsFolderFilter == null || dsFolderFilter.size() == 0) {
            String errMsg = getTranslationProcessor().translate("This is not valid folder.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        //CHOOSE FOLDER DETAILS
        rootpath = dsChooseFolderInfo.getValue(0, "rootfolder", "");
        String choosefoldername = dsChooseFolderInfo.getValue(0, "foldername", "");
        String choosefolderpath = dsChooseFolderInfo.getValue(0, "folderpath", "");
        String choosevmsfolderid = dsChooseFolderInfo.getValue(0, "u_vmsfolderid", "");
        //VALIDATE CHOOSE FOLDER PATH VALID
        /*if (!existingDir.isDirectory()) {
            String errMsg = getTranslationProcessor().translate(choosefolderpath + " Choose folder is not exist.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }*/
        //CREATE FINAL DATASET TO MANIPULATE
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("vmsfolderid", DataSet.STRING);
        dsFinal.addColumn("aperioid", DataSet.STRING);
        dsFinal.addColumn("currentvmsfolderid", DataSet.STRING);
        dsFinal.addColumn("filepath", DataSet.STRING);
        dsFinal.addColumn("aperiopath", DataSet.STRING);
        dsFinal.addColumn("aperiofilename", DataSet.STRING);
        for (int i = 0; i < dsFolderInfo.size(); i++) {
            String u_vmsfolderid = dsFolderInfo.getValue(i, "u_vmsfolderid", "");
            String u_vmsimgmapid = dsFolderInfo.getValue(i, "u_vmsimgmapid", "");
            String foldername = dsFolderInfo.getValue(i, "foldername", "");
            String folderpath = dsFolderInfo.getValue(i, "folderpath", "");
            String finalpathmodify = "";
            if (choosefolderpath.endsWith("\\") || choosefolderpath.endsWith("/")) {
                finalpathmodify = choosefolderpath + foldername;
            } else {
                finalpathmodify = choosefolderpath + File.separator + foldername;
            }
            //CREATE SERVER PATH TO MOVE AND DELETE FILE
            String finalchooseserverfolderpath = StringUtil.replaceAll(finalpathmodify, rootpath, serverpath);
            finalchooseserverfolderpath = StringUtil.replaceAll(finalchooseserverfolderpath, "\\", "/");

            String movablefileserverpath = StringUtil.replaceAll(folderpath, rootpath, serverpath);
            movablefileserverpath = StringUtil.replaceAll(movablefileserverpath, "\\", "/");
            //MOVE FILE INTO DIRECTORY
            moveFile(movablefileserverpath, finalchooseserverfolderpath);
            //VALIDATE EXISTING PATH TO DELETE
            File existingDir = new File(movablefileserverpath);
            delete(existingDir);
            existingDir = new File(finalchooseserverfolderpath);
            if (!existingDir.isFile()) {
                String errMsg = getTranslationProcessor().translate(finalpathmodify + " This is not valid file.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            int rowID = dsFinal.addRow();
            dsFinal.setValue(rowID, "vmsfolderid", u_vmsfolderid);
            dsFinal.setValue(rowID, "aperioid", u_vmsimgmapid);
            dsFinal.setValue(rowID, "currentvmsfolderid", choosevmsfolderid);
            dsFinal.setValue(rowID, "filepath", finalpathmodify);
            dsFinal.setValue(rowID, "aperiopath", choosefolderpath);
            dsFinal.setValue(rowID, "aperiofilename", foldername);
        }
        if (dsFinal != null && dsFinal.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "VMSFolder");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("vmsfolderid", ";"));
            props.setProperty("folderpath", dsFinal.getColumnValues("filepath", ";"));
            props.setProperty("vmsfolderparentid", dsFinal.getColumnValues("currentvmsfolderid", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update VMSFolder." + ex.getMessage());
            }
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "AperioStatus");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("aperioid", ";"));
            props.setProperty("filepath", dsFinal.getColumnValues("aperiopath", ";"));
            props.setProperty("filename", dsFinal.getColumnValues("aperiofilename", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update Aperio Status." + ex.getMessage());
            }
        }
        String foldername = choosefoldername;
        properties.setProperty("msg", "<b>File has been moved to " + foldername + "</b>");
        //throw new SapphireException("test");
    }

    private String moveFile(String filepath, String movetopath) throws SapphireException {
        String fileName = "";
        File inputFile = new File(filepath);
        fileName = inputFile.getName();
        //TODO WILL OPEN FOR SERVER
        if (inputFile.renameTo(new File(movetopath))) {
            System.out.println("File is moved successful!");
            logger.info("MoveSelectedFile>>>", "Successfully moved file from " + filepath + " to " + movetopath);
        } else {
            //System.out.println("File is failed to move!");
            logger.info("MoveSelectedFile>>>", "Unable to move file from " + filepath + " to " + movetopath);
            throw new SapphireException("File is failed to move!");
        }
        return fileName;
    }

    private DataSet getMountedPath(String methodology) throws SapphireException {
        DataSet dsMountedPath = null;
        /*String sql = ApSql.GET_WINDOWS_MAPPING_PATH;
        dsMountedPath = getQueryProcessor().getSqlDataSet(sql);*/
        String crrntdept = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(crrntdept, "-")[0];
        //String sql = ApSql.GET_WINDOWS_MAPPING_PATH;
        String sql = Util.parseMessage(ApSql.GET_WINDOWS_MAPPING_PATH, site, methodology);

        if (dsMountedPath == null)
            throw new SapphireException("Network path and mounted drive mapping info cannot be obtained from database.");
        if (dsMountedPath.size() == 0)
            throw new SapphireException("The Query:\n" + sql + "\n is returning no row.");
        if (dsMountedPath.size() > 1)
            throw new SapphireException(site + " site has more than one mounted path to scan image(s).");

        return dsMountedPath;
    }

    private void delete(File file) throws SapphireException {
        //FILE DELETED
        if (!file.isDirectory()) {
            file.delete();
            logger.info("Duplicate file delete>>>", "directory is deleted " + file.getAbsolutePath());
        }
    }
}
