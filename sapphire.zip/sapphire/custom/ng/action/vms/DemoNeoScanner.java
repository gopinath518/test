package sapphire.custom.ng.action.vms;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class DemoNeoScanner extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("scanslideidval", "");
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Specimen ID can't be blank.");
        }
        PropertyList props = new PropertyList();
        props.setProperty("sampleid", sampleid);
        getActionProcessor().processAction("SampleInfo", "1", props);
        String sponsor = props.getProperty("sponsor");
        String study = props.getProperty("study");
        String u_sponsorid = props.getProperty("u_sponsorid");
        String u_bioprojectsid = props.getProperty("u_bioprojectsid");
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(defaultdepartment, "-")[0];

        getRootPathFromPolicy();
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("site", site);
        DataSet dsImagePathFilter = dsFolderPath.getFilteredDataSet(hm);
        if (dsImagePathFilter == null || dsImagePathFilter.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Root path can't defined according to the site.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String rootpath = dsImagePathFilter.getValue(0, "imagepath", "");
        if (Util.isNull(rootpath)) {
            String errMsg = getTranslationProcessor().translate("Root path can't be null.Please contact to Admin to provide a root path in configuration.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        File theDir = new File(rootpath);
        if (!theDir.canWrite()) {
            String errMsg = getTranslationProcessor().translate("Unable to proceed. <b><u>" + rootpath + "</u></b>" + " directory doesn't have write permission.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String sponsorpath = rootpath + File.separator + sponsor;
        theDir = new File(sponsorpath);
        if (!theDir.exists()/* && theDir.isDirectory()*/) {
            boolean successful = theDir.mkdir();
            if (!successful) {
                String errMsg = getTranslationProcessor().translate("Failed to create the directory.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
        }
        String studypath = rootpath + File.separator + sponsor + File.separator + study;
        theDir = new File(studypath);
        if (!theDir.exists() /*&& theDir.isDirectory()*/) {
            boolean successful = theDir.mkdir();
            if (!successful) {
                String errMsg = getTranslationProcessor().translate("Failed to create the directory.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }

            props.clear();
            props.setProperty(AddSDI.PROPERTY_SDCID, "VMSFolder");
            props.setProperty(AddSDI.PROPERTY_COPIES, "1");
            props.setProperty("rootfolder", rootpath);
            props.setProperty("foldername", study);
            props.setProperty("folderpath", studypath);
            props.setProperty("sponsorid", u_sponsorid);
            props.setProperty("projectid", u_bioprojectsid);
            props.setProperty("type", "FLD");
            props.setProperty("isrootfolder", "Y");
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Can't create project folder.");
            }

        }
        String filename = createFile(studypath, sampleid);
        String scanfilepath = studypath + File.separator + filename;
        String gsql = Util.parseMessage(ApSql.GET_VMSFOLDERID_BY_PATH, u_sponsorid, u_bioprojectsid);
        DataSet dsVMSinfo = getQueryProcessor().getSqlDataSet(gsql);
        if (dsVMSinfo == null || dsVMSinfo.size() == 0) {
            throw new SapphireException("No folder found for this specimen.");
        }
        props.clear();
        props.setProperty(AddSDI.PROPERTY_SDCID, "VMSFolder");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props.setProperty("vmsfolderparentid", dsVMSinfo.getValue(0, "u_vmsfolderid", ""));
        props.setProperty("rootfolder", rootpath);
        props.setProperty("foldername", filename);
        props.setProperty("folderpath", scanfilepath);
        props.setProperty("sponsorid", u_sponsorid);
        props.setProperty("projectid", u_bioprojectsid);
        props.setProperty("type", "IMG");
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Can't create folder.");
        }
        String imgname = props.getProperty("newkeyid1");
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
        Date date = new Date();
        System.out.println(dateFormat.format(date));
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "AperioStatus");
        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
        prop.setProperty("barcode", sampleid);
        prop.setProperty("filepath", studypath);
        prop.setProperty("filename", filename);
        prop.setProperty("statuscode", "0");
        prop.setProperty("statusmessage", "OK");
        prop.setProperty("scanner", "");
        prop.setProperty("scanstarttime", dateFormat.format(date));
        prop.setProperty("siteid", site);
        prop.setProperty("scanendtime", "n");
        prop.setProperty("currentfolderid", imgname);
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        /*props.clear();
        props.setProperty(AddSDI.PROPERTY_SDCID, "VMSImgMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props.setProperty("sampleid", sampleid);
        props.setProperty("currentfolderid", imgname);
        props.setProperty("imagename", filename);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Can't create folder.");
        }*/
        //throw new SapphireException("Test");
    }

    private void getRootPathFromPolicy() throws SapphireException {
        if (dsFolderPath == null) {
            dsFolderPath = new DataSet();
            dsFolderPath.addColumn("imagepath", DataSet.STRING);
            dsFolderPath.addColumn("site", DataSet.STRING);
            PropertyList plVMSaperioPolicy = getConfigurationProcessor().getPolicy("VMSAperioIntegrationPolicy", "VMSAperioIntegration");
            if (plVMSaperioPolicy == null)
                throw new SapphireException("VMS Aperio folder path policy is not define in System Admin-> Policy.");
            PropertyListCollection plclosmap = plVMSaperioPolicy.getCollection("imagesitepathlist");
            for (int i = 0; i < plclosmap.size(); i++) {
                String imagepath = plclosmap.getPropertyList(i).getProperty("imagepath");
                String site = plclosmap.getPropertyList(i).getProperty("site");
                int rowID = dsFolderPath.addRow();
                dsFolderPath.setValue(rowID, "imagepath", imagepath);
                dsFolderPath.setValue(rowID, "site", site);
            }
        }
    }

    private String createFile(String path, String sampleid) throws SapphireException {
        String filename = sampleid + ".jpg";
        try {

            File file = new File(path + File.separator + filename);
            boolean fvar = file.createNewFile();
            if (fvar) {
                System.out.println("File has been created successfully");
            } else {
                System.out.println("File already present at the specified location");
            }
        } catch (IOException e) {
            System.out.println("Exception Occurred:");
            e.printStackTrace();
        }
        return filename;
    }

    private DataSet dsFolderPath = null;
}
