package sapphire.custom.ng.action;


import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by msubhra on 6/9/2016.
 *
 * This Action is for creating Dilution Tube from Input Elution Tubes
 *
 */


public class NormalizationDilutionTube extends BaseAction {



    public void processAction(PropertyList properties) throws SapphireException {

        String sampleids = properties.getProperty("s_sampleid");

        String newsampleids = StringUtil.replaceAll(sampleids,";","','");
        String lvtestcode = properties.getProperty("lvtestcodeid");
        String currentuser = connectionInfo.getSysuserId();
        String custodialdepartmentid = connectionInfo.getDefaultDepartment();

        /**
         * createDilutionTube method is for create daughter tube from illution tube, this method takes multiple
         * sampleids as input and create one daughter tube for each samples
         */
        String dilutiontubeid = createDilutionTube(sampleids);
        properties.setProperty("newkeyid1", dilutiontubeid);

        /**
         * updateTrackitem method is for update the created dillution tubes in trackitem. This method takes
         * the newly created dilution tube,the current user and the custodil department as input
         */

        String trackitem = updateTrackitem(dilutiontubeid, currentuser, custodialdepartmentid);

        /**
         * addTestCodeOnDilutionTube method is for add test in the dilution tube. This method takes the dilution tubes and
         * the selected testcode id as input
         */

        addTestCodeOnDilutionTube(newsampleids,dilutiontubeid,lvtestcode);
        dtLoadingCal(dilutiontubeid);
        String returnmessage = "Dilution Tube" +dilutiontubeid+" has been created successfully";
        properties.setProperty("msg",returnmessage);


    }

    /**
     * This method will create aliquot(Dilution Tubes) from input sampleids and returns newly created dilution tubes
     * @param sampleids input Elution Tubes
     * @return newkeyid newly created dilution tubes from the input elution tubes
     * @throws SapphireException
     */

    private String createDilutionTube(String sampleids) throws SapphireException {

        PropertyList prop = new PropertyList();
        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, sampleids);
        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "1");
        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");

        try {
            getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot Create Aliquot.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }


        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

    /**
     * This method is used for update contained typeid in trackitem SDC
     * @param dilutionTubes dilution tubes
     * @param currentuser UserID of the current user
     * @param custodialdepartmentid Department ID of the current user
     * @return success message Success messgae for the execution the method
     * @throws SapphireException
     */

    private String updateTrackitem(String dilutionTubes, String currentuser,  String custodialdepartmentid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutionTubes);
        props.setProperty("containertypeid", "Dilution Tube");
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", custodialdepartmentid);
        props.setProperty("custodytakendt", "n");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for Dilution Tube.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
        String msg = "Trackeitem Updated for sampleids"+dilutionTubes;
        return msg;
    }


    /**
     * This methods calculates the amount of the Dilution as well as Elution tubes at the time of Dilution Tube creation.
     * @param dtids dilutiontubeid
     * @throws SapphireException
     */

    private void dtLoadingCal(String dtids) throws SapphireException{
        if(!Util.isNull(dtids)){
            String sql = "select a.sourcesampleid,a.destsampleid,b.sampleload,b.testcode,c.qtycurrent sourceqty,c.qtyunits sourceunits " +
                    "from s_samplemap a,u_sampletestcodemap b,trackitem c " +
                    "where a.destsampleid=b.s_sampleid and c.linksdcid='Sample' and a.sourcesampleid=c.linkkeyid1 " +
                    "and a.destsampleid in ('"+StringUtil.replaceAll(dtids,";","','")+"')";

            DataSet dsDtLdCalInfo = getQueryProcessor().getSqlDataSet(sql);
            if(dsDtLdCalInfo!=null && dsDtLdCalInfo.size()>0){
                DataSet result = new DataSet();
                result.addColumn(EditTrackItem.PROPERTY_KEYID1,DataSet.STRING);
                result.addColumn("qtycurrent",DataSet.STRING);
                result.addColumn("qtyunits",DataSet.STRING);
                ArrayList<DataSet> dsArr = dsDtLdCalInfo.getGroupedDataSets("sourcesampleid");
                if(dsArr!=null && dsArr.size()>0){
                    int totalQtyToDeduct = 0;
                    for(int i=0;i<dsArr.size();i++){
                        DataSet tempDs = dsArr.get(i);

                        if(tempDs!=null && tempDs.size()>0){
                            String elTubeId = tempDs.getValue(0,"sourcesampleid","");
                            String sourceunits= tempDs.getValue(0,"sourceunits","");
                            int sourceqty=0;
                            try {
                                sourceqty = tempDs.getInt(0, "sourceqty", 0);
                            }
                            catch (Exception exp){
                                throw  new SapphireException("Quantity for the Elution Tube "+elTubeId+" is not found in the trackitem");
                            }
                            totalQtyToDeduct = 0;
                            if(!Util.isNull(elTubeId) && sourceqty>0){
                                for(int j=0;j<tempDs.size();j++) {
                                    int sampleload = 0;
                                    String dlTubeId= tempDs.getValue(j,"destsampleid","");
                                    String testcode= tempDs.getValue(j,"testcode","");
                                    try {
                                        sampleload = tempDs.getInt(j,"sampleload",0);
                                    } catch (Exception exp) {
                                        throw new SapphireException("Invalid data found for the column sampleload in u_sampletestcodemap for the " +
                                                "Dilution Tube "+dlTubeId+" and Testcode "+testcode);
                                    }
                                    totalQtyToDeduct+=sampleload;
                                    if(sampleload>0) {
                                        int rownum = result.addRow();
                                        result.setValue(rownum, EditTrackItem.PROPERTY_KEYID1, dlTubeId);
                                        result.setValue(rownum, "qtycurrent", Integer.toString(sampleload));
                                        result.setValue(rownum, "qtyunits", sourceunits);
                                    }
                                }
                                if(totalQtyToDeduct>sourceqty)
                                    throw new SapphireException("Available quantity for the elution tube "+elTubeId+" is "+sourceqty+" "+sourceunits+"." +
                                            " So dilution tube(s) having total size "+totalQtyToDeduct+" "+sourceunits+" can not be created.");
                                int ressultElQty = sourceqty-totalQtyToDeduct;
                                if(totalQtyToDeduct>0 && ressultElQty>0) {
                                    int rownum = result.addRow();
                                    result.setValue(rownum, EditTrackItem.PROPERTY_KEYID1, elTubeId);
                                    result.setValue(rownum, "qtycurrent", Integer.toString(ressultElQty));
                                    result.setValue(rownum, "qtyunits", sourceunits);
                                }
                            }
                            else if(sourceqty<=0)
                                logger.debug("No amount calculation has been performed while creating dilution tubes from the elution tube "+elTubeId+"," +
                                        "as the elution tube is not having the quantity defined in the trackitem.");
                        }
                    }
                }
                if(result!=null && result.size()>0){
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditTrackItem.PROPERTY_SDCID,"Sample");
                    prop.setProperty(EditTrackItem.PROPERTY_KEYID1,result.getColumnValues(EditTrackItem.PROPERTY_KEYID1,";"));
                    prop.setProperty("qtycurrent",result.getColumnValues("qtycurrent",";"));
                    prop.setProperty("qtyunits",result.getColumnValues("qtyunits",";"));
                    getActionProcessor().processAction(EditTrackItem.ID,EditTrackItem.VERSIONID,prop);
                }
            }
        }
    }


    /**
     * This method will add testcode to the Dilution Tubes.It will take the input as parentsampleids, newly created dilution tubes and testcode id
     * @param parentSample Elution tubes
     * @param aliquotid Dilution Tubes
     * @throws SapphireException
     */

    private void addTestCodeOnDilutionTube(String parentSample, String aliquotid,String testcodeid) throws SapphireException {
        double optimalconcentration = 0;

        String[] testcode = StringUtil.split(testcodeid,";");
        String ss_parentTest = "select distinct lvtestcodeid,testcode,testname,methodology,ispanel,los," +
                "(select optimalconcentration from u_testcode where u_testcodeid ='"+testcode[0]+"') as optimalconcentration "+
                "from u_sampletestcodemap where lvtestcodeid = '"+testcode[0]+"'";

        DataSet dsParentTest = getQueryProcessor().getSqlDataSet(ss_parentTest);
        String[] samparr = StringUtil.split(aliquotid, ";");

        if (dsParentTest == null) {
            String error = getTranslationProcessor().translate("Query failed");
            error += ss_parentTest;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsParentTest.size() == 0) {//todo
            String e=getTranslationProcessor().translate("No Test is assigned to the Parent");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,e);
        }

        if(dsParentTest.getDouble(0,"optimalconcentration",0)== 0) {
            String e=getTranslationProcessor().translate("Optimal Concentration is null");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,e);
        }
        else{
            optimalconcentration = dsParentTest.getDouble(0,"optimalconcentration");
        }
        String sqlConcentration="select concentration from s_sample where s_sampleid in ('"+parentSample+"')";

        DataSet dsConcentration = getQueryProcessor().getSqlDataSet(sqlConcentration);
        //String []concentrationRatio = new String[0];
        //int len = StringUtil.split(aliquotid,";").length;
        String []concentrationRatio = new String[dsConcentration.getRowCount()];

        /**
         * calculating optimal concentration
         */
        for(int i=0;i<dsConcentration.getRowCount();i++)
        {

            if(dsConcentration.getDouble(i,"concentration",0) == 0)
            {
                String e=getTranslationProcessor().translate("Sample Concentration is null");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE,e);
            }
            else {
                concentrationRatio[i] = Util.calculateConcentrationRatio(dsConcentration.getDouble(i, "concentration", 0), optimalconcentration);
            }
        }
        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc
        dsSamplefinal.addColumn("concentrationratio",DataSet.STRING);

        for (String currentsamp : samparr) {
            for (int j = 0; j < dsParentTest.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dsParentTest.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dsParentTest.getValue(j, "ispanel", ""));
                dsSamplefinal.setValue(rowID,"concentrationratio",concentrationRatio[j]);

            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        hsAddTestCode.setProperty("concentrationratio",dsSamplefinal.getColumnValues("concentrationratio",";"));
        hsAddTestCode.setProperty("bypassvalidation", "Y");
        hsAddTestCode.setProperty("workitemflag", "Y");
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }

    }


   }





