package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class IHCFlowBackStep extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("sampleid", "");
        String fromStepName = properties.getProperty("fromstepname", "");
        String toStepName = properties.getProperty("tostepname", "");
        if (toStepName.contains("&")) {
            toStepName = StringUtil.replaceAll(toStepName, "&", "&'||'");
        }
        if ("".equals(sampleId) || "".equals(fromStepName) || "".equals(toStepName))
            throw new SapphireException("Insuffent Data: SampleId/From Step/To Step missing");

        String sql = Util.parseMessage(ApSql.GET_LOS_BYSAMPELID, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsLos = getQueryProcessor().getSqlDataSet(sql);
        if (dsLos == null) {
            throw new SapphireException("Query failed: Please contact your administrator." + sql);
        }
        if (dsLos.size() == 0) {
            throw new SapphireException("No LOS found for the specimen(s)");
        }
        String sqlStepName = Util.parseMessage(ApSql.GET_UNIQUE_STEP_SAMPLE, StringUtil.replaceAll(sampleId, ";", "','"), fromStepName);
        DataSet dsStepName = getQueryProcessor().getSqlDataSet(sqlStepName);
        //TODO CHECKING ELIGIBILITY
        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("accession_id", DataSet.STRING);
        dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
        dsDisplayMsg.addColumn("level_of_service", DataSet.STRING);
        dsDisplayMsg.addColumn("tramstop", DataSet.STRING);
        dsDisplayMsg.addColumn("doctor_name", DataSet.STRING);
        for (int i = 0; i < dsLos.size(); i++) {
            String specimen_id = dsLos.getValue(i, "specimen_id", "");
            String accession_id = dsLos.getValue(i, "accession_id", "");
            String los = dsLos.getValue(i, "los", "");
            String doctor_name = dsLos.getValue(i, "doctor_name", "");
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("s_sampleid", specimen_id);
            hm.put("stepname", toStepName);
            DataSet dsMoveFilter = dsStepName.getFilteredDataSet(hm);
            if (dsMoveFilter.size() == 0) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "accession_id", accession_id);
                dsDisplayMsg.setValue(rowID, "specimen_id", specimen_id);
                dsDisplayMsg.setValue(rowID, "level_of_service", los);
                dsDisplayMsg.setValue(rowID, "doctor_name", doctor_name);
                dsDisplayMsg.setValue(rowID, "tramstop", toStepName);
            }
        }
        if (dsDisplayMsg.size() > 0) {
            String errCode = Util.getDisplayMessage("Below specimen(s) is/are not eligible to move back to " + toStepName + " tramstop: ", dsDisplayMsg);
            throw new SapphireException(errCode);
        }
        //TODO SUCCESS ROUTING MESSAGE
        DataSet dsSuccessMsg = new DataSet();
        dsSuccessMsg.addColumn("accession_id", DataSet.STRING);
        dsSuccessMsg.addColumn("specimen_id", DataSet.STRING);
        dsSuccessMsg.addColumn("level_of_service", DataSet.STRING);
        dsSuccessMsg.addColumn("tramstop", DataSet.STRING);
        dsSuccessMsg.addColumn("doctor_name", DataSet.STRING);
        for (int i = 0; i < dsLos.size(); i++) {
            String specimen_id = dsLos.getValue(i, "specimen_id", "");
            String accession_id = dsLos.getValue(i, "accession_id", "");
            String los = dsLos.getValue(i, "los", "");
            String doctor_name = dsLos.getValue(i, "doctor_name", "");
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("s_sampleid", specimen_id);
            hm.put("stepname", toStepName);
            DataSet dsMoveFilter = dsStepName.getFilteredDataSet(hm);
            if (dsMoveFilter.size() == 0)
                throw new SapphireException(specimen_id + " is not eligible to move back to " + toStepName + " tramstop.");

            processIHCBackStep(specimen_id, fromStepName, toStepName);

            if (toStepName.contains("&'||'")) {
                toStepName = StringUtil.replaceAll(toStepName, "&'||'", "&");
            }
            if (toStepName.contains("H&E")) {
                toStepName = StringUtil.replaceAll(toStepName, "H&E", "H&E ");
            }
            if (toStepName.contains("Imaging")) {
                toStepName = StringUtil.replaceAll(toStepName, "Imaging", "IHC Imaging");
            }
            int rowIDD = dsSuccessMsg.addRow();
            dsSuccessMsg.setValue(rowIDD, "accession_id", accession_id);
            dsSuccessMsg.setValue(rowIDD, "specimen_id", specimen_id);
            dsSuccessMsg.setValue(rowIDD, "level_of_service", los);
            dsSuccessMsg.setValue(rowIDD, "doctor_name", doctor_name);
            dsSuccessMsg.setValue(rowIDD, "tramstop", toStepName);
        }
        String successCode = "";
        if (dsSuccessMsg.size() > 0) {
            successCode += Util.getDisplayMessage("Operation Successful. Specimen(s) is/are routed to below tramstop: ", dsSuccessMsg);
        }
        //properties.setProperty("msg", StringUtil.replaceAll(sampleId, ";", ",") + "- has/have been moved to <b>" + toStepName + "</b> tramstop.");
        properties.setProperty("msg", successCode);
        //throw new SapphireException("test");
    }

    public void processIHCBackStep(String sampleId, String fromStepName, String toStepName) throws ActionException {

        if (!Util.isNull(sampleId)) {
            sampleId = Util.getUniqueList(sampleId, ";", true);
            String sampleIdArr[] = StringUtil.split(sampleId, ";", true);
            if (sampleIdArr != null && sampleIdArr.length > 0) {
                for (int i = 0; i < sampleIdArr.length; i++) {
                    String tempSampleArr[] = StringUtil.split(sampleIdArr[i], ";");
                    String sql = Util.parseMessage(ApSql.IHC_GET_BACK_STEP_INFO_SQL, toStepName, tempSampleArr[0], fromStepName, tempSampleArr[0], StringUtil.replaceAll(sampleIdArr[i], ";", "','"));

                    DataSet ds = getQueryProcessor().getSqlDataSet(sql);
                    if (ds != null && ds.size() > 0) {
                        setPendingStep(ds.getColumnValues("u_sampletestcodestpmapid", ";"));
                        setBackWardStep(sampleIdArr[i], toStepName);
                    }
                }
            }
        }
    }

    public void setPendingStep(String sampletestcodestpmapid) throws ActionException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodestpmapid);
        pl.setProperty("status", "Pending");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    public void setBackWardStep(String sampleId, String toStepName) throws ActionException {
        String sql = Util.parseMessage(ApSql.IHC_GET_BACK_CURRENT_STEP, toStepName);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0) {

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
            pl.setProperty("u_currentmovementstep", ds.getValue(0, "currentmovementstep", ""));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            String workingDepartment = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0] + "-" + ds.getValue(0, "workingdepartment", "");

            pl.clear();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
            pl.setProperty("custodialuserid", "(null)");
            pl.setProperty("custodialdepartmentid", workingDepartment);
            pl.setProperty("u_currenttramstop", ds.getValue(0, "workingtramstop", ""));

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }

    }
}

