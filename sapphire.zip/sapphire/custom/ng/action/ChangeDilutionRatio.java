package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 8/17/2016.
 * @desc: Changes the concentration and dilutionratio of the sample in the batch.
 *Inputs Required Batchid,contration and dilutionratio.
 */
public class ChangeDilutionRatio extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid=properties.getProperty("ngbatch");
        String samples=properties.getProperty("sampleids");
        //String sql="select distinct sampleid from u_batch_sample_detail where u_ngbatchid='"+batchid+"'";
        //DataSet dssample=getQueryProcessor().getSqlDataSet(sql);
       // String samples=dssample.getColumnValues("sampleid",";");
        String dilutionratio=properties.getProperty("dilutionratio");
        String concentration=properties.getProperty("concentration");
        //if(dssample==null){
        if(samples==null){
        String err=getTranslationProcessor().translate("No samples selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,err);
        }
        if(samples.length()==0){
            String error=getTranslationProcessor().translate("No samples selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,error);
        }
        PropertyList prop=new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1,samples);
        if(!dilutionratio.equalsIgnoreCase(""))
        prop.setProperty("u_concentrationratio",dilutionratio);
        if(!concentration.equalsIgnoreCase(""))
        prop.setProperty("concentration",concentration);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }catch(SapphireException se){
            throw new SapphireException(se.getMessage());
        }

    }
}
