
package sapphire.custom.ng.action;

//import com.labvantage.sapphire.actions.storage.EditTrackItem;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.util.CalcUtil;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * Created by Ashish Kumar on 4/15/2016.
 * todo please provide action details
 *
 * 
 */
public class CalcCellCount extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String volume = properties.getProperty("volume");
        String volumeunit = properties.getProperty("volumeunit");
        String cellcount = properties.getProperty("cellcount");
        String cellcountunit = properties.getProperty("cellcountunit");
        String s_sampleid = properties.getProperty("s_sampleid");
        String[] sampleArray = s_sampleid.split(";");
        
        final DecimalFormat df = new DecimalFormat(".#");

        CalcUtil cu = new CalcUtil(connectionInfo);

        DataSet ds = new DataSet();
        ds.addColumnValues("s_sampleid", DataSet.STRING, s_sampleid, ";");
        ds.addColumnValues("volume", DataSet.NUMBER, volume, ";");
        ds.addColumnValues("volumeunit", DataSet.STRING, volumeunit, ";");
        ds.addColumnValues("cellcount", DataSet.NUMBER, cellcount, ";");
        ds.addColumnValues("cellcountunit", DataSet.STRING, cellcountunit, ";");

        for (int i = 0; i < ds.size(); i++) {
            try {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getValue(i, "s_sampleid"));
                BigDecimal conversion = cu.convertUnits(new BigDecimal(ds.getValue(i, "volume")), ds.getValue(i, "volumeunit"), ds.getValue(i, "cellcountunit"));
                double conversionval = conversion.doubleValue();
                double noofcell = Double.parseDouble(ds.getValue(i, "cellcount","0")) * conversionval;
                prop.setProperty("u_noofcellspersample", df.format(noofcell));

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                properties.setProperty("u_noofcellspersample", df.format(noofcell));


            } catch (SapphireException s) {
                String error = getTranslationProcessor().translate("Can not count cell per sample volume");
                error += s.getMessage();
                throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
            }
        }
    }

}


