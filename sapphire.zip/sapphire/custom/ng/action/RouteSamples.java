package sapphire.custom.ng.action;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by DMondal on 4/17/2017.
 * This action will route sample to required department of same site.
 */
public class RouteSamples extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleid");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid");
        if (Util.isNull(sampleids)) {
            throw new SapphireException("Error:Sample(s) can't be null.Please contact your admin.");
        }
        if (Util.isNull(u_currentmovementstep)) {
            throw new SapphireException("Error:u_currentmovementstep can't be null.Please contact your admin.");
        }
        if (Util.isNull(custodialdepartmentid)) {
            throw new SapphireException("Error:custodialdepartmentid can't be null.Please contact your admin.");
        }
       
        DataSet ds = new DataSet();
        ds.addColumn("sample", DataSet.STRING);
        ds.addColumn("currentmovementstep", DataSet.STRING);
        ds.addColumn("destination", DataSet.STRING);
        String[] sampleArr = StringUtil.split(sampleids, ";");
        int incr = 0;
        for (int i = 0; i < sampleArr.length; i++) {
            incr = ds.addRow();
            ds.setValue(incr, "sample", sampleArr[i]);
            ds.setValue(incr, "currentmovementstep", u_currentmovementstep);
            ds.setValue(incr, "destination", custodialdepartmentid);
        }
        updateTrackItemSdc(ds);
    }

    /**
     * Description : This is for update track item
     *
     * @param ds
     * @throws SapphireException
     */
    private void updateTrackItemSdc(DataSet ds) throws SapphireException {

        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        for (int i = 0; i < ds.size(); i++) {
            String tramstop = ds.getValue(i, "destination", "");
            String destination = site + "-" + tramstop;
            if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor()))
                throw new SapphireException("Error: Unable to route sample. Department: " + destination + " does not exist");
            ds.setValue(i, "destination", destination);
        }
        if("AV".equalsIgnoreCase(site)){
        	noAVPreExtraction(ds);
        }

        try {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
            props.setProperty("u_currentmovementstep", ds.getColumnValues("currentmovementstep", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
            props.setProperty("u_currenttramstop", ds.getColumnValues("currentmovementstep", ";"));
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("custodialdepartmentid", ds.getColumnValues("destination", ";"));
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += e.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
    /**
     * Description : validation for sending sample to AV-Pre-Extraction
     * @param ds
     * @throws SapphireException
     */
    private void noAVPreExtraction(DataSet ds) throws SapphireException {
    	String sampleForPreEx="";
    	for (int i = 0; i < ds.size(); i++) {
            String sample = ds.getValue(i, "sample", "");
            String totramstop = ds.getValue(i, "currentmovementstep", "");
            if("Pre-Extraction".equalsIgnoreCase(totramstop)){
            	sampleForPreEx=sampleForPreEx+";"+sample;
            }
        }
    	if(sampleForPreEx.length()>1){
    		sampleForPreEx=sampleForPreEx.substring(1);
            throw new SapphireException("Error: Unable to route sample(s)-"+sampleForPreEx+". Because department Pre-Extraction does not exist in AV site.");
    	}
    }
}
