package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 5/9/2017.
 */
public class MoveToPathRecon extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String department = connectionInfo.getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        String destination = site + "-Accessioning";
//        String destination = site + "-PathSupport";
        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty("keyid1", sampleid);
            props.setProperty("u_currentmovementstep", "PathIHCCompleted");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
            props.setProperty("u_currenttramstop", "PathIHCCompleted");
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("custodialdepartmentid", destination);
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Can't update custodial domain for sample");
            error += e.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
