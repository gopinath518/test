package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.HashMap;

/**
 * Created by DMondal on 1/19/2017. Modified by kshahbaz on 29/05/2017
 * batchmovestatus and currentmovestep is added. Description : This action is
 * used to complete batch.
 * 
 * @param1 : batchid
 * @param2 : batchtype
 * @param3 : tramstop
 * @param4 : batchmovestatus
 * @param5 : currentmovestep
 */
public class SpecPrepCompleteBatch extends BaseAction {
	public void processAction(PropertyList properties) throws SapphireException {
		String batchid = properties.getProperty("spfishbatchid");
		if (Util.isNull(batchid)) {
			throw new SapphireException("FISH bach id can't be null.Please contact to admin.");
		}
		String batchtype = properties.getProperty("batchtype");
		if (Util.isNull(batchtype)) {
			throw new SapphireException("FISH bach type can't be null.");
		}
		String tramstop = properties.getProperty("tramstop");
		if (Util.isNull(tramstop)) {
			throw new SapphireException("Current Tramstop is null.Please contact to admin.");
		}
		String batchmovestatus = properties.getProperty("batchmovestatus");
		if (Util.isNull(batchmovestatus)) {
			throw new SapphireException("Batch movement status can't be null.");
		}
		
		DataSet dsSample = getSamplesFromBatch(batchid);
		dataEntered(dsSample, tramstop, batchtype);
		String currentmovestep="";
		if("specimenprep".equalsIgnoreCase(tramstop)){
			DataSet dsPolicy = getMovementPolicy();
			currentmovestep = getCurrentmovestep(dsSample, dsPolicy);
			/*if(getParent(dsSample)){
				//sampleMove(dsSample);
			}*/
		}else{
			currentmovestep=properties.getProperty("currentmovestep");
	        if (Util.isNull(currentmovestep)) {
	            throw new SapphireException("Current movement step can't be null.");
	        }
		}
		
		if(("Heme".equalsIgnoreCase(batchtype))||("Heme PCE".equalsIgnoreCase(batchtype))){
			volumeCheck(dsSample);
		}
		editBatchStatus(batchid, batchmovestatus);
		editSampleStatus(dsSample, currentmovestep);
		
	}
	
	/**
	 * 
	 * @param dsSample
	 * @return
	 * @throws SapphireException
	 */
	private boolean getParent(DataSet dsSample) throws SapphireException {
		String samples = dsSample.getColumnValues("sampleid", "','");
		String sqlParent = Util.parseMessage(FishSqls.GET_PARENT, samples);
		DataSet dsParent = getQueryProcessor().getSqlDataSet(sqlParent);
		if (dsParent == null) {
			String err = "Something wrong happened. Contact your administrator.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		if (dsParent.size() > 0) {
			return true;
		}
		return false;
	}
	/**
	 * Description : This method will check volume must be there for a sample
	 * prior to batch complete.
	 * 
	 * @param dsSample
	 * @return
	 * @throws SapphireException
	 */
	private void volumeCheck(DataSet dsSample) throws SapphireException {
		String samples = dsSample.getColumnValues("sampleid", "','");
		String sqlVol = Util.parseMessage(FishSqls.GET_CHECKVOL, samples);
		DataSet dsVol = getQueryProcessor().getSqlDataSet(sqlVol);
		if (dsVol == null) {
			String err = "Something wrong happened. Contact your administrator.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		if (dsVol.size() == 0) {
			String err = "Please fill attribute first.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		StringBuffer sampleids = new StringBuffer();
		for (int i = 0; i < dsVol.size(); i++) {
			String linkkeyid1 = dsVol.getValue(i, "linkkeyid1", "");
			String qtycurrent = dsVol.getValue(i, "qtycurrent", "");
			if (Util.isNull(qtycurrent)) {
				// sampleids = sampleids + ";" + linkkeyid1;
				sampleids.append(";").append(linkkeyid1);
			}
		}
		
		if (!Util.isNull(sampleids.toString()) &&  sampleids.length() > 0) {
			String err = "You can't complete batch as volume is null for the sample(s):" + sampleids.substring(1);
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
	}

	/**
	 * Description : This method will find samples of a selected batch.
	 * 
	 * @param batchid
	 * @return
	 * @throws SapphireException
	 */
	private DataSet getSamplesFromBatch(String batchid) throws SapphireException {
		String sqlSample = Util.parseMessage(FishSqls.GET_SAMPLES, batchid);
		DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
		if (dsSample == null) {
			String err = "Something wrong happened. Contact your administrator.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		if (dsSample.size() == 0) {
			String err = "No sample found in Batch.You can not complete the batch.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		String sample = dsSample.getColumnValues("sampleid", ";");
		if (Util.isNull(sample)) {
			String err = "No sample found in Batch.You can not complete the batch.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		return dsSample;
	}

	/**
	 * Description This method will check all attributes are entered or not
	 * 
	 * @param dsSamples
	 * @param tramstop
	 * @param batchtype
	 * @throws SapphireException
	 */
	private void dataEntered(DataSet dsSamples, String tramstop, String batchtype) throws SapphireException {
		String samples = dsSamples.getColumnValues("sampleid", "','");
		String sqlDataEntry = Util.parseMessage(FishSqls.VALIDATE_ENTERTEXT, samples, tramstop, batchtype);
		DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlDataEntry);
		if (dsSample == null) {
			String err = "Something wrong happened. Contact your administrator.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		if (dsSample.size() == 0) {
			String err = "Please fill attribute first.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		StringBuffer sampleids = new StringBuffer();
		StringBuffer allparam = new StringBuffer();
		DataSet dsEmptyMsg = new DataSet();
		dsEmptyMsg.addColumn("sampleid", DataSet.STRING);
		dsEmptyMsg.addColumn("attributename", DataSet.STRING);
		for (int i = 0; i < dsSample.size(); i++) {
			String sample = dsSample.getValue(i, "sampleid", "");
			String paramid = dsSample.getValue(i, "attributename", "");
			String enteredtext = dsSample.getValue(i, "enteredvalue", "");
			if (Util.isNull(enteredtext)) {
				// sampleids=sampleids+";"+ sample;
				// sampleids.append(";").append(sample);
				// allparam=allparam+";"+paramid;
				// allparam.append(";").append(paramid);
				int rowID = dsEmptyMsg.addRow();
				dsEmptyMsg.setValue(rowID, "sampleid", sample);
				dsEmptyMsg.setValue(rowID, "attributename", paramid);
			}
		}

		/*
		 * if (sampleids.length()>0) { String err = "Please fill attribute(s):"+
		 * allparam.substring(1)+",for the sample(s):"+ sampleids.substring(1);
		 * throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err); }
		 */
		if (dsEmptyMsg.size() > 0) {
			String emptyParam = Util.getDisplayMessage(dsEmptyMsg);
			throw new SapphireException("Please fill attribute(s) for Specimen(s)." + emptyParam);
		}
	}

	/**
	 * Description : This method will update the batch
	 * batchstate,batchmovestatus and completedt.
	 * 
	 * @param batchid
	 * @throws SapphireException
	 */
	public void editBatchStatus(String batchid, String batchmovestatus) throws SapphireException {
		String completedby = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
		String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
		PropertyList props = new PropertyList();
		props.setProperty(EditSDI.PROPERTY_SDCID, "FISHBatch");
		props.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
		props.setProperty("completedt", "n");
		props.setProperty("batchstate", "Closed");
		props.setProperty("batchmovestatus", batchmovestatus);
		// props.setProperty("batchmovestatus","specimenprepbatchcomplete");
		props.setProperty("completeby", completedby);
		props.setProperty("department", department);
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
		} catch (SapphireException se) {
			throw new SapphireException("Batch can not be completed.Error:" + se.getMessage());
		}
	}

	/**
	 *
	 * @param dsSamples
	 * @throws SapphireException
	 */
	private void editSampleStatus(DataSet dsSamples, String currentmovestep) throws SapphireException {
		String samples = dsSamples.getColumnValues("sampleid", ";");
		PropertyList props = new PropertyList();
		props.setProperty("sampleid", samples);
		props.setProperty("u_currentmovementstep", currentmovestep);
		// props.setProperty("u_currentmovementstep", "slidedropsample");
		props.setProperty("custodialdepartmentid", "FISH");
		try {
			getActionProcessor().processAction("AssignToMySite", "1", props);
		} catch (SapphireException e) {
			String errMsg = getTranslationProcessor().translate("Error in AssignToMySite.");
			errMsg += "\nError Detail:" + e.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
	}

	/**
	 * Description : Sample will move back to freshprep after batch completed.
	 * 
	 * @param dsSamples
	 * @throws SapphireException
	 */
	private void sampleMove(DataSet dsSamples) throws SapphireException {
		String sample = dsSamples.getColumnValues("sampleid", "','");
		String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
		String site = department.substring(0, department.lastIndexOf('-'));
		String destination = site + "-" + "Fresh Prep";
		if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor())) {
			throw new SapphireException(
					"Error: Unable to route sample. Department: " + destination + " does not exist");
		}

		String sql = Util.parseMessage(FishSqls.GET_PARENTSAMPLE_TESTSTATUS, sample);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		String parentId = ds.getColumnValues("s_sampleid", ";");
		if (ds.size() == 0) {
			String err = "There is no parent sample";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("teststatus", "Not Completed");
		DataSet dsFinalFilter = ds.getFilteredDataSet(hm);
		if (dsFinalFilter.size() == 0) {
			try {
				PropertyList props = new PropertyList();
				props.clear();
				props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
				props.setProperty(EditSDI.PROPERTY_KEYID1, parentId);
				props.setProperty("u_currentmovementstep", "FreshPrep");
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
				props.clear();
				props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
				props.setProperty(EditTrackItem.PROPERTY_KEYID1, parentId);
				props.setProperty("u_currenttramstop", "FreshPrep");
				props.setProperty("custodialuserid", "(null)");
				props.setProperty("custodialdepartmentid", destination);
				getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
			} catch (SapphireException e) {
				String error = getTranslationProcessor().translate("Can't update movement step in sample");
				error += e.getMessage();
				throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
			}
		} else {
			String err = "TestStatus is not completed for parent specimen of the selected Batch";
			// throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
			logger.logInfo("Error:", err);
		}
	}

	/**
	 * Get protocol and movement step value from policy
	 * 
	 * @return
	 * @throws SapphireException
	 */
	private DataSet getMovementPolicy() throws SapphireException {
		DataSet dsPloicy = new DataSet();
		int incr = 0;
		dsPloicy.addColumn("protocol", DataSet.STRING);
		dsPloicy.addColumn("currentmovementstep", DataSet.STRING);
		PropertyList slideDropMovementPolicy = getConfigurationProcessor().getPolicy("SlideDropSampleMovement",
				"SampleMovementStep");
		PropertyListCollection movementStepPolicyCollection = slideDropMovementPolicy.getCollection("movementstep");
		for (int i = 0; i < movementStepPolicyCollection.size(); i++) {
			incr = dsPloicy.addRow();
			PropertyList protocolProps = movementStepPolicyCollection.getPropertyList(i).getPropertyList("protocolmovementstep"); 
			String protocol=protocolProps.getProperty("protocol");
			String currentmovementstep=protocolProps.getProperty("currentmovestep");
			dsPloicy.setValue(incr, "protocol", protocol);
			dsPloicy.setValue(incr, "currentmovementstep", currentmovementstep);
		}
		return dsPloicy;
	}

	/**
	 * Get next movement step from the policy
	 * 
	 * @param dsSamples
	 * @param daPolicy
	 * @return
	 * @throws SapphireException
	 */
	private String getCurrentmovestep(DataSet dsSamples, DataSet daPolicy) throws SapphireException {
		String currentmovestep = "";
		String batchtype = Util.getUniqueList(dsSamples.getColumnValues("batchtype", ";"), ";", true);
		if (Util.isNull(batchtype)) {
			throw new SapphireException("Batch Type can't be null.");
		}
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("protocol", batchtype);
		DataSet dsFilter = daPolicy.getFilteredDataSet(hm);
		if (dsFilter.size() > 0) {
			currentmovestep = dsFilter.getValue(0, "currentmovementstep", "");
		} else {
			throw new SapphireException("Plese define currentmovementstep for " + batchtype
					+ " protocol in SlideDropSampleMovement policy.");
		}
		return currentmovestep;
	}
}
