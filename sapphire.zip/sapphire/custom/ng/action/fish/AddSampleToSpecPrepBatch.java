package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.*;

/**
 * This will add sample to batch
 * @author debasis.mondal
 *
 */
public class AddSampleToSpecPrepBatch extends BaseAction {
    public static final String DATASET_PROPERTY_BATCHID = "batchid";
    public static final String DATASET_PROPERTY_PROTOCOL = "protocol";
    public static final String DATASET_PROPERTY_SAMPLES = "sampleid";
    public static final String DATASET_PROPERTY_MOVEMENTSTEP = "tramstop";
    public static final String DATASET_PROPERTY_CHILD_SAMPLES = "childsampleid";
    public static final String DATASET_PROPERTY_CHILD_CONTAINTYPE = "childcontainertypeid";
    public static final String DATASET_PROPERTY_CHILD_QUANTITY = "quantity";
    public static final String DATASET_PROPERTY_CHILD_UNIT = "unit";
    private String errmsg = "";

    //private DataSet dsHemeSample = null;

    public void processAction(PropertyList properties) throws SapphireException {
        String fishbatch = properties.getProperty(DATASET_PROPERTY_BATCHID);
        String protocol = properties.getProperty(DATASET_PROPERTY_PROTOCOL);
        String sampleid = properties.getProperty(DATASET_PROPERTY_SAMPLES);
        String movementstep = properties.getProperty(DATASET_PROPERTY_MOVEMENTSTEP);

        if (Util.isNull(fishbatch)) {
            errmsg = getTranslationProcessor().translate("Batch Id can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (Util.isNull(sampleid)) {
            errmsg = getTranslationProcessor().translate("No Mother Tube is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (Util.isNull(protocol)) {
            errmsg = getTranslationProcessor().translate("Batch Type can't be null");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        String validateStorageSamples = Util.parseMessage(FishSqls.GET_STORAGE_SAMPLES, StringUtil.replaceAll(sampleid,";","','"));
        DataSet dsStorageSamples = getQueryProcessor().getSqlDataSet(validateStorageSamples);
        String errorSampleid=dsStorageSamples.getColumnValues("linkkeyid1",",");
        if(!"".equalsIgnoreCase(errorSampleid)){
            throw new SapphireException("Please checkout the specimen "+errorSampleid+" from storage.");
        }
        String validateRepeatTest = Util.parseMessage(FishSqls.GET_REPEATTEST_SAMPLES, StringUtil.replaceAll(sampleid,";","','"));
        DataSet dsValidateRepeat = getQueryProcessor().getSqlDataSet(validateRepeatTest);
        String repeatSamples=dsValidateRepeat.getColumnValues("s_sampleid",",");
        if(!"".equalsIgnoreCase(repeatSamples)){
            throw new SapphireException(repeatSamples+" specimen have repeat test. please unselect the specimen. ");
        }
        String validateCurrentMovement = Util.parseMessage(FishSqls.GET_MOVEMENTSTEP, StringUtil.replaceAll(sampleid,";","','"));
        DataSet dsValidateMovement = getQueryProcessor().getSqlDataSet(validateCurrentMovement);
        String currentMovementstep=dsValidateMovement.getColumnValues("u_currentmovementstep",",");
        if((!movementstep.equalsIgnoreCase(currentMovementstep))|| dsValidateMovement.size()>1){
            throw new SapphireException("Specimen(s) doesn't belong to "+movementstep);
        }

        validateSpecimen(sampleid,fishbatch);
        validateProtocol(protocol,sampleid);
        specimenAlreadyInBatch(sampleid,fishbatch,properties);
        if(("PET".equalsIgnoreCase(protocol))||("FFPE".equalsIgnoreCase(protocol))){
            String sample = sampleid.replaceAll(";", "','");
            String fishtestcode = Util.parseMessage(FishSqls.GET_TEST, sample);
            DataSet dsFishTest = getQueryProcessor().getSqlDataSet(fishtestcode);
            if (dsFishTest == null || dsFishTest.size() == 0)
            {
                errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            String volume=null;
            updateTestStatus(dsFishTest, protocol);
            associateSamplesToFishBatch(fishbatch, sampleid,volume);
            properties.setProperty("centrifugeid", sampleid);
        }else if ("Heme".equalsIgnoreCase(protocol) || "Heme PCE".equalsIgnoreCase(protocol)){

            DataSet dsHemeSample = populateMainDataSet(protocol, properties);
            // 1. Create centrifuge tube
            DataSet dsSample = createChildSamples(dsHemeSample);
            //2. associate centrifuge tubes to the batch..
            associateSamplesToFishBatch(dsSample.getColumnValues(DATASET_PROPERTY_BATCHID,";"),
                    dsSample.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLES,";"),dsSample.getColumnValues(DATASET_PROPERTY_CHILD_QUANTITY,";"));

            // 3. Apply test from mother tube
            Util.copyTestCodeFromParent(dsSample.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLES,";"),
                    getQueryProcessor(), getActionProcessor(), "FISH");

            //4. Apply attributes here
            for(int i=0;i<dsSample.getRowCount(); i++) {
            //5. Update the volume for parent Sample
                updateParentVolume(protocol,sampleid,dsHemeSample);
            }

        }
    }

    private void validateSpecimen(String sample, String batchid) throws SapphireException{
        String validateSql = Util.parseMessage(FishSqls.VALIDATE_MOTHER_TUBE,batchid);
        DataSet dsCount = getQueryProcessor().getSqlDataSet(validateSql);
        String existSamples="";

        if (dsCount != null || dsCount.size() >= 0) {
            for( int i=0;i<dsCount.size();i++) {
                String samplefromQuery = dsCount.getValue(i, "u_rootsample", "");
                if (sample.contains(samplefromQuery)) {
                    existSamples += ";" + samplefromQuery;
                }
            }
            if(!"".equalsIgnoreCase(existSamples)) {
                existSamples = existSamples.substring(1);
                String err = "Mother tube " + existSamples + " is already been aliquoted.";
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

            }

        }
    }
    /**
     * To check specimen is already in batch or not.
     * @param sample
     * @throws SapphireException
     */
    private void specimenAlreadyInBatch(String sample,String fishbatch,PropertyList properties) throws SapphireException{
        String specimenSql = Util.parseMessage(FishSqls.ALREADY_IN_BATCH,fishbatch,sample);
        DataSet DsSpecimen = getQueryProcessor().getSqlDataSet(specimenSql);
        if (DsSpecimen == null) {
            throw new SapphireException("SQL failed,DataSet is coming null.Please contact your administrator for recheck SQL.");
        }
        if (DsSpecimen.size() >0) {           
            properties.setAttribute("msg", "Error:Specimen("+DsSpecimen.getValue(0, "sampleid","")+") already in "+DsSpecimen.getValue(0, "batchname","")+" batch.");
            throw new SapphireException("Error:Specimen("+DsSpecimen.getValue(0, "sampleid","")+") already in "+DsSpecimen.getValue(0, "batchname","")+" batch.");
        }
    }
    
    private DataSet createChildSamples(DataSet dsSample)throws SapphireException{

        //Note: Create child sample does not work on for multiple sample. So here I am firing the action in loop
        for(int i=0;i<dsSample.getRowCount(); i++){
            String parentSample = dsSample.getValue(i, DATASET_PROPERTY_SAMPLES, "");

            PropertyList props = new PropertyList();
            props.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, parentSample);
            props.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "1" );
            props.setProperty(CreateChildSamples.PROPERTY_MODE, "derivative");
            props.setProperty(CreateChildSamples.PROPERTY_CHILD_QUANTITY, dsSample.getValue(i, DATASET_PROPERTY_CHILD_QUANTITY));
            props.setProperty(CreateChildSamples.PROPERTY_CHILD_UNIT, dsSample.getValue(i, DATASET_PROPERTY_CHILD_UNIT));

            props.setProperty("__trackitem_custodialdepartmentid", connectionInfo.getDefaultDepartment());

            try {
                getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException(
                        getTranslationProcessor().translate("Unable to create centrifuge tube.") + "\n" + e.getMessage());
            }

            String newChild = props.getProperty("newkeyid1", "");
            dsSample.setValue(i,DATASET_PROPERTY_CHILD_SAMPLES,newChild);

        }

        // Populate container-type id for the child.
        String allParentSample = dsSample.getColumnValues( DATASET_PROPERTY_SAMPLES, ";");
        String sqlParent = Util.parseMessage(FishSqls.SAMPLE_INFO, StringUtil.replaceAll(allParentSample,";","','"));
        DataSet dsParent = getQueryProcessor().getSqlDataSet(sqlParent);
        if (dsParent == null || dsParent.size() == 0) {
            String err = "Something wrong happened. Contact your administrator.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        HashMap hm = new HashMap();
        for(int i=0;i<dsSample.getRowCount(); i++){
            hm.clear();
            hm.put("s_sampleid",dsSample.getValue(i,DATASET_PROPERTY_SAMPLES));

            DataSet dsFilter = dsParent.getFilteredDataSet(hm);
            if(dsFilter!=null && dsFilter.size()>0){
                dsSample.setValue(i,DATASET_PROPERTY_CHILD_CONTAINTYPE,dsFilter.getValue(0,"containertypeid",""));
            }

        }

        PropertyList pl = new PropertyList();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1,
                dsSample.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLES, ";"));
        pl.setProperty("containertypeid", dsSample.getColumnValues(DATASET_PROPERTY_CHILD_CONTAINTYPE, ";"));
        pl.setProperty("u_currenttramstop",
                StringUtil.repeat("Specimen Prep", dsSample.getRowCount(), ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        } catch (Exception ex) {
            throw new SapphireException("General Error", SapphireException.TYPE_FAILURE, getTranslationProcessor()
                    .translate("Failed to update trackitem.Please contact Administrator." + ex.getMessage()));
        }

        return dsSample;
    }

    private DataSet populateMainDataSet(String protocol,PropertyList properties)throws SapphireException{

        String fishbatchArg = properties.getProperty(DATASET_PROPERTY_BATCHID,"");
        String protocolArg = properties.getProperty(DATASET_PROPERTY_PROTOCOL,"");
        DataSet dsHemeSample = new DataSet();

        if("Heme".equalsIgnoreCase(protocol) || "Heme PCE".equalsIgnoreCase(protocol)){
            dsHemeSample.addColumn(DATASET_PROPERTY_BATCHID,DataSet.STRING);
            dsHemeSample.addColumn(DATASET_PROPERTY_PROTOCOL,DataSet.STRING);
            dsHemeSample.addColumn(DATASET_PROPERTY_SAMPLES,DataSet.STRING);
            dsHemeSample.addColumn(DATASET_PROPERTY_CHILD_SAMPLES,DataSet.STRING);
            dsHemeSample.addColumn(DATASET_PROPERTY_CHILD_CONTAINTYPE,DataSet.STRING);
            dsHemeSample.addColumn(DATASET_PROPERTY_CHILD_QUANTITY,DataSet.STRING);
            dsHemeSample.addColumn(DATASET_PROPERTY_CHILD_UNIT,DataSet.STRING);

            String sampleid=properties.getProperty(DATASET_PROPERTY_SAMPLES,";");
            String volsql = Util.parseMessage(FishSqls.GET_SAMPLE_VOLUME,protocol, sampleid.replaceAll(";", "','"));
            DataSet volds = getQueryProcessor().getSqlDataSet(volsql);
            if (volds == null) {
                errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            if (volds.size() == 0) {
                errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            ArrayList<DataSet> al_volds = volds.getGroupedDataSets("s_sampleid");
            for (DataSet currds : al_volds) {
                currds.sort("fishdaughtertubevol");
                int size = currds.size();
                String currsampleid = currds.getValue(size - 1, "s_sampleid", "");
                String parentvol = currds.getValue(size - 1, "qtycurrent", "0");
                String aliquotvol = currds.getValue(size - 1, "fishdaughtertubevol", "1");
                String units = currds.getValue(size - 1, "qtyunits", "ml");

                if (Double.parseDouble(parentvol) < Double.parseDouble(aliquotvol)) {
                    aliquotvol = parentvol;
                }
                String sampletype=currds.getValue(size - 1, "sampletypeid", "");
                if(("Bone Marrow Clot".equalsIgnoreCase(sampletype))|| ("Bone Marrow Core".equalsIgnoreCase(sampletype))||("Bone Marrow Aspirate".equalsIgnoreCase(sampletype)))
                {
                    double value=0.5;
                    aliquotvol=String.valueOf(value);
                }
                int rowID = dsHemeSample.addRow();
                dsHemeSample.setValue(rowID,DATASET_PROPERTY_BATCHID,fishbatchArg);
                dsHemeSample.setValue(rowID,DATASET_PROPERTY_PROTOCOL,protocolArg);
                dsHemeSample.setValue(rowID,DATASET_PROPERTY_SAMPLES,currsampleid);
                dsHemeSample.setValue(rowID,DATASET_PROPERTY_CHILD_QUANTITY,aliquotvol);
                dsHemeSample.setValue(rowID,DATASET_PROPERTY_CHILD_UNIT,units);
            }
        }

        return dsHemeSample;

    }
    /**
     * This method is used to apply the Attributes to Centrifuge Tubes.
     *
     * @param centrifugeid, protocol
     * @throws SapphireException
     */
    private void applyAttributes(String centrifugeid, String protocol) throws SapphireException {

        String sqlwi = Util.parseMessage(FishSqls.GET_PROTOCOL_WORKITEM, protocol);
        DataSet dswi = getQueryProcessor().getSqlDataSet(sqlwi);
        if (dswi.size() > 0) {

            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Sample");
            propswi.setProperty("keyid1", centrifugeid);
            propswi.setProperty("applyworkitem", "Y");
            propswi.setProperty("workitemid", dswi.getValue(0, "workitemid"));
            propswi.setProperty("workitemversionid", dswi.getValue(0, "workitemversionid"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                errmsg = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
        }
    }

    /**
     * @param batchid      :FishBatch ID to which the samples will be assigned
     * @param centrifugeid :DataSet    which has the information of mother tube,centrifuge tube,protocol,tests assigned on them.
     * @throws SapphireException
     * @desc :Associates the centrifuge tube in the batch which are eligible for the specified protocol of a batch.
     */
    private void associateSamplesToFishBatch(String batchid, String centrifugeid,String volume) throws SapphireException {
        PropertyList fishbatchdeatil = new PropertyList();
        fishbatchdeatil.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatchSample");
        fishbatchdeatil.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(centrifugeid.split(";").length));
        fishbatchdeatil.setProperty("batchid", batchid);
        fishbatchdeatil.setProperty("sampleid", centrifugeid);
        fishbatchdeatil.setProperty("volume", volume);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, fishbatchdeatil);
        } catch (SapphireException se) {
            errmsg = "Unable to associate samples to batch.";
            throw new SapphireException(errmsg);
        }
    }

    /**
     * @param dsFishTest
     * @param protocol
     * @throws ActionException
     */
    private void updateTestStatus(DataSet dsFishTest, String protocol) throws ActionException {
       /* HashMap filter = new HashMap();
        filter.put("fishprotocol", protocol);
        DataSet filteredds = dsFishTest.getFilteredDataSet(filter);
        String u_sampletestcodemapid = Util.getUniqueList(filteredds.getColumnValues("u_sampletestcodemapid", ";"), ";", true);*/
        String u_sampletestcodemapid = Util.getUniqueList(dsFishTest.getColumnValues("u_sampletestcodemapid", ";"), ";", true);
        PropertyList property = new PropertyList();
        property.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        property.setProperty(EditSDI.PROPERTY_KEYID1, u_sampletestcodemapid);
        property.setProperty("teststatus", "Completed");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, property);
    }

    /**
     * Description : For calculating parent sample's volume.
     * @param parentsample
     * @param dsChildVol
     * @throws SapphireException
     */
    private void updateParentVolume(String protocol,String parentsample,DataSet dsChildVol) throws SapphireException {
        DataSet dsParentVol=new DataSet();
        dsParentVol.addColumn("parentsample",DataSet.STRING);
        dsParentVol.addColumn("parentvol",DataSet.NUMBER);
        DataSet childVol=new DataSet();
        childVol.addColumn("sampleid",DataSet.STRING);
        childVol.addColumn("childquantity",DataSet.NUMBER);
        for(int i=0;i<dsChildVol.size();i++)
        {
            int rowId = childVol.addRow();
            childVol.setValue(rowId, "sampleid", dsChildVol.getValue(i,DATASET_PROPERTY_SAMPLES));
            childVol.setValue(rowId, "childquantity", dsChildVol.getValue(i,DATASET_PROPERTY_CHILD_QUANTITY));
        }
        String volsql = Util.parseMessage(FishSqls.GET_SAMPLE_VOLUME,protocol, parentsample.replaceAll(";", "','"));
        DataSet volds = getQueryProcessor().getSqlDataSet(volsql);
        if (volds == null) {
            errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (volds.size() == 0) {
            errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        HashMap<String, String> hmFilter=new HashMap<>();
        int incrVol=0;
        for(int i=0;i<volds.size();i++){
            incrVol=dsParentVol.addRow();
            String currsampleid = volds.getValue(i, "s_sampleid", "");
            hmFilter.clear();
            hmFilter.put("sampleid", currsampleid);
            DataSet dsFilter=childVol.getFilteredDataSet(hmFilter);
            String childVolume=dsFilter.getValue(0,"childquantity", "");

            String parentvol = volds.getValue(i, "qtycurrent", "0");
            Double parentVol=(Double.parseDouble(parentvol)-Double.parseDouble(childVolume));
            dsParentVol.setValue(incrVol, "parentsample", currsampleid);
            dsParentVol.setValue(incrVol, "parentvol", String.valueOf(parentVol));
        }
        PropertyList trackitem = new PropertyList();
        trackitem.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        trackitem.setProperty(EditTrackItem.PROPERTY_KEYID1, dsParentVol.getColumnValues("parentsample", ";"));
        trackitem.setProperty("qtycurrent", dsParentVol.getColumnValues("parentvol", ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, trackitem);
        } catch (ActionException e) {
            throw new ActionException(e.getMessage());
        }
    }
    /**
     * Batch type and protocol must be same except EB type specimen.
     * @param protocol
     * @param sampleid
     * @throws SapphireException
     */
    private void validateProtocol(String protocol,String sampleid) throws SapphireException {
        String protocolSql = Util.parseMessage(FishSqls.GET_PROTOCOL_TYPE, sampleid.replaceAll(";", "','"));
        DataSet protocolDs = getQueryProcessor().getSqlDataSet(protocolSql);
        if (protocolDs == null) {
            errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (protocolDs.size() == 0) {
        	return;//Note: This is for client Uss.
        }
        for(int i=0;i<protocolDs.size();i++)
        {
            String fishprotocol=protocolDs.getValue(i,"fishprotocol", "");
            String type = protocolDs.getValue(i,"u_type", "");
            if("EB".equalsIgnoreCase(type)){
            	continue;
            }else{
            	if(!protocol.equalsIgnoreCase(fishprotocol)){
            		errmsg = getTranslationProcessor().translate("Applied test code has "+fishprotocol+" protocol but you have selected "+protocol+" batch type that must be same with applied test's protocol.");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            	}
            }
        }
    }
}
