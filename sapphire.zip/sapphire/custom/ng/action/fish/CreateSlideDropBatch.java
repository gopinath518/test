package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.MultiSampleChild;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by kshahbaz on 5/26/2017.
 * <p>
 * param : fishspecbatchtype .Protocol type.
 * param : sampleid . Samples which will become part of batch.
 * Desc : This action creates specimenprep batch based upon protocol.
 */

public class CreateSlideDropBatch extends BaseAction {
    public static final String ID = "CreateSlideDropBatch";
    public static final String VERSION_ID = "1";
    public static final String PROPERTY_BATCHTYPE = "batchtype";
    public static final String PROPERTY_CENTRIFUGETUBEID = "centrifugetubeid";
    public static final String PROPERTY_LAYOUTID = "layoutid";
    public static final String PROPERTY_PROTOCOL = "protocol";
    public static final String PROPERTY_ROWPOS = "rowpos";
    public static final String PROPERTY_COLUMNPOS = "columnpos";
    public static final String PROPERTY_TESTCODEID = "testcode";
    public static final String PROPERTY_PANELID = "panelid";
    public static final String PROPERTY_ISPANEL = "ispanel";
    private static final String SLIDEID = "slideid";
    private static final String DROPID = "dropid";
    private static final String COPYDOWNCOLUMNS = "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;concentration;u_pathologycomments";
    private static final String BATCHSEQ = "%06d";
    private static final String STATUS = "Open";
    private static final String NEWKEYID1 = "newkeyid1";

    public void processAction(PropertyList properties) throws SapphireException {
        String batchtype = properties.getProperty(PROPERTY_BATCHTYPE);
        String protocol = properties.getProperty(PROPERTY_PROTOCOL, "Heme PCE");

        if (Util.isNull(batchtype) || Util.isNull(protocol)) {
            throw new SapphireException(TYPE_VALIDATION, "Input properties is null.");
        }
        DataSet dsproperties = createInputDataset(properties);
        if (dsproperties.size() > 0) {
            String newbatchid = createBatch(batchtype);
            if (newbatchid.length() > 0) {
                dsproperties = createSlides(dsproperties);
                updateDetails(newbatchid, dsproperties, protocol);
            } else {
                throw new SapphireException(TYPE_FAILURE, "Action failed,unable to create batch.");
            }

            properties.setProperty("newkeyid1", newbatchid);
        } else {
            throw new SapphireException(TYPE_FAILURE, "Action failed,unable to create batch.");
        }
    }

    /**
     * @param newbatchid
     * @param dsproperties
     * @param protocol
     * @throws SapphireException
     */
    private void updateDetails(String newbatchid, DataSet dsproperties, String protocol) throws SapphireException {
        dsproperties = updateSlideDrop(newbatchid, dsproperties);
        addSlidesToBatch(newbatchid, dsproperties);
        addTestToSlides(dsproperties);
        applyAttributes(dsproperties, protocol);
        updateSampleTestcodeMap(dsproperties);

    }

    /**
     * @param dsproperties
     */
    private void updateSampleTestcodeMap(DataSet dsproperties) throws SapphireException {
    /*    DataSet dstestdropinfo = new DataSet();
        dstestdropinfo.addColumn("u_sampletestcodemapid", DataSet.STRING);
        dstestdropinfo.addColumn(DROPID, DataSet.STRING);
        int rownum = 0;

        String sqlstm = "select u_sampletestcodemapid,s_sampleid,lvtestcodeid,lvtestpanelid,dropid   " +
                "from u_sampletestcodemap where s_sampleid in('" + dsproperties.getColumnValues("slideid", "','") + "')";
        DataSet dsstm = getQueryProcessor().getSqlDataSet(sqlstm);

        String sqldrop = "select u_slidedropid,childsampleid,rowpos,columnpos from u_slidedrop where sampleid in ('" + dsproperties.getColumnValues("slideid", "','") + "')";
        DataSet dsslidedrop = getQueryProcessor().getSqlDataSet(sqldrop);

        HashMap filter = new HashMap();
        for (int i = 0; i < dsslidedrop.size(); i++) {
            String curdropid = dsslidedrop.getValue(i, "u_slidedropid");
            String u_sampletestcodemapid = "";
            filter.clear();
            filter.put(SLIDEID, dsslidedrop.getValue(i, "s_sampleid"));
            filter.put(PROPERTY_ROWPOS, dsslidedrop.getValue(i, "rowpos"));
            filter.put(PROPERTY_COLUMNPOS, dsslidedrop.getValue(i, "columnpos"));
            DataSet dspropertiesfiltered = dsproperties.getFilteredDataSet(filter);
            String currtestcode = dspropertiesfiltered.getValue(0, "testcode");
            String arrtestcode[] = StringUtil.split(currtestcode, ",");
            for (String temptcode : arrtestcode) {
                dstestdropinfo.addRow();
                filter.clear();
                filter.put("lvtestcodeid", temptcode);
                filter.put("s_sampleid", dsslidedrop.getValue(i, "s_sampleid"));
                DataSet dsstmfiltered = dsstm.getFilteredDataSet(filter);
                u_sampletestcodemapid = dsstmfiltered.getValue(0, "u_sampletestcodemapid");

                dstestdropinfo.setValue(rownum, "u_sampletestcodemapid", u_sampletestcodemapid);
                dstestdropinfo.setValue(rownum, DROPID, curdropid);

            }
        }
*/
        String slideid = dsproperties.getColumnValues("slideid", "','");
        String sqldrop_sampletestcodemap = Util.parseMessage(FishSqls.GET_DROPID_SAMPLETESTCODEMAPID, slideid);
        DataSet ds = getQueryProcessor().getSqlDataSet(sqldrop_sampletestcodemap);
        if (ds == null || ds.size() == 0) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);

        }
        PropertyList property = new PropertyList();
        property.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        property.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampletestcodemapid", ";"));
        property.setProperty(DROPID, ds.getColumnValues("u_slidedropid", ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, property);
        } catch (ActionException e) {
            e.printStackTrace();

        }


    }

    /**
     * @param dsproperties
     * @param protocol
     * @throws SapphireException
     */
    private void applyAttributes(DataSet dsproperties, String protocol) throws SapphireException {

        String sqlwi = Util.parseMessage(FishSqls.GET_PROTOCOL_WORKITEM_SLIDEDROP, protocol);
        DataSet dswi = getQueryProcessor().getSqlDataSet(sqlwi);
        if (dswi.size() > 0) {

            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Sample");
            propswi.setProperty("keyid1", Util.getUniqueList(dsproperties.getColumnValues(SLIDEID, ";"), ";", true));
            propswi.setProperty("applyworkitem", "Y");
            propswi.setProperty("workitemid", dswi.getValue(0, "workitemid"));
            propswi.setProperty("workitemversionid", dswi.getValue(0, "workitemversionid"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                String errmsg = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
        }
    }

    /**
     * @param dsproperties
     * @throws SapphireException
     */
    private DataSet addTestToSlides(DataSet dsproperties) throws SapphireException {
        DataSet dssamptest = new DataSet();
        dssamptest.addColumn("sampleid", DataSet.STRING);
        dssamptest.addColumn("testcode", DataSet.STRING);
        dssamptest.addColumn("ispanel", DataSet.STRING);
        int rownum = 0;
        for (int i = 0; i < dsproperties.size(); i++) {
            String currsample = dsproperties.getValue(i, SLIDEID);
            String currtestcode = dsproperties.getValue(i, PROPERTY_TESTCODEID);
            String ispanel = dsproperties.getValue(i, PROPERTY_ISPANEL);
            String arrcurrtestcode[] = StringUtil.split(currtestcode, "|");
            for (String tcode : arrcurrtestcode) {
                dssamptest.addRow();
                dssamptest.setValue(rownum, "sampleid", currsample);
                dssamptest.setValue(rownum, "testcode", tcode);
                dssamptest.setValue(rownum, "ispanel", ispanel);
                rownum++;
            }
        }


        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dssamptest.getColumnValues("sampleid", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dssamptest.getColumnValues("testcode", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL, dssamptest.getColumnValues("ispanel", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
        props.setProperty(AssignTestCode.INPUT_PROPERTY_APPLY_WI, "Y");

        try {
            getActionProcessor().processAction("AssignTestCode", "1", props);

        } catch (SapphireException se) {
            throw new SapphireException("Unable to add a Test on a pool Sample" + se.getMessage());

        }
        return dssamptest;
    }

    /**
     * @param newbatchid
     * @param dsproperties
     * @throws SapphireException
     */
    private void addSlidesToBatch(String newbatchid, DataSet dsproperties) throws SapphireException {
        String slideid = dsproperties.getColumnValues(SLIDEID, ";");
        slideid = Util.getUniqueList(slideid, ";", true);

        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatchSample");
        prop.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(slideid.split(";").length));
        prop.setProperty("batchid", newbatchid);
        prop.setProperty("sampleid", slideid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (SapphireException se) {
            String errmsg = "Unable to associate samples to batch.";
            throw new SapphireException(errmsg);
        }
    }

    /**
     * @param newbatchid
     * @param dsproperties
     * @return
     * @throws SapphireException
     */
    private DataSet updateSlideDrop(String newbatchid, DataSet dsproperties) throws SapphireException {
        // dsproperties.addColumn(DROPID, DataSet.STRING);
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "SlideDrop");
        prop.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsproperties.getColumnValues(PROPERTY_CENTRIFUGETUBEID, ";").split(";").length));
        prop.setProperty("fishbatchid", StringUtil.repeat(newbatchid, dsproperties.getColumnValues(PROPERTY_CENTRIFUGETUBEID, ";").split(";").length, ";"));
        prop.setProperty("parentsampleid", dsproperties.getColumnValues(PROPERTY_CENTRIFUGETUBEID, ";"));
        prop.setProperty("childsampleid", dsproperties.getColumnValues(SLIDEID, ";"));
        prop.setProperty("rowpos", dsproperties.getColumnValues(PROPERTY_ROWPOS, ";"));
        prop.setProperty("columnpos", dsproperties.getColumnValues(PROPERTY_COLUMNPOS, ";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
            throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
        }
        String dropid = prop.getProperty(NEWKEYID1, "");
        dsproperties.addColumnValues(DROPID, DataSet.STRING, dropid, ";");
      /*  String dropids=dropid.replaceAll(";", "','");
        String sqldrop =Util.parseMessage(FishSqls.GET_SLIDEDROPID, dropids);
                //"select childsampleid,layoutid,rowpos,columnpos,u_slidedropid from u_slidedrop where u_slidedropid in('" + dropid.replaceAll(";", "','") + "')";
        DataSet dsdrop = getQueryProcessor().getSqlDataSet(sqldrop);

        HashMap filterds = new HashMap();
        for (int i = 0; i < dsproperties.size(); i++) {
            filterds.clear();
            filterds.put("childsampleid", dsproperties.getValue(i, SLIDEID));
            filterds.put("rowpos", dsproperties.getValue(i, PROPERTY_ROWPOS));
            filterds.put("columnpos", dsproperties.getValue(i, PROPERTY_COLUMNPOS));
            DataSet dsdropfiltered = dsdrop.getFilteredDataSet(filterds,false);
            if (dsdropfiltered.size() > 0) {
                String currdropid = dsdropfiltered.getValue(0, "u_slidedropid", "");
                dsproperties.setValue(i, DROPID, currdropid);

            } else
                throw new SapphireException(TYPE_FAILURE, "Action failed ,unable to find data in SlideDrop SDC.");
        }*/


        return dsproperties;
    }

    /**
     * @param dsproperties
     * @return
     * @throws SapphireException
     */
    private DataSet createSlides(DataSet dsproperties) throws SapphireException {

        dsproperties.addColumn(SLIDEID, DataSet.STRING);
        ArrayList<DataSet> alsampleds = dsproperties.getGroupedDataSets(PROPERTY_CENTRIFUGETUBEID);
        for (DataSet tempsampds : alsampleds) {        //MultiSampleChild action does not support multiple  values.
            ArrayList<DataSet> allayout = tempsampds.getGroupedDataSets(PROPERTY_LAYOUTID);
            for (DataSet templayoutds : allayout) {
                PropertyList prop = new PropertyList();
                prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, COPYDOWNCOLUMNS);
                prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, templayoutds.getValue(0, PROPERTY_CENTRIFUGETUBEID));
                prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
                prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
                prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
                try {
                    getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
                } catch (SapphireException se) {
                    String errmsg = getTranslationProcessor().translate("Unable to create slide.") + se.getMessage();
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
                }
                String slideid = prop.getProperty(NEWKEYID1);
                for (int i = 0; i < dsproperties.size(); i++) {
                    if (dsproperties.getValue(i, PROPERTY_CENTRIFUGETUBEID).equalsIgnoreCase(templayoutds.getValue(0, PROPERTY_CENTRIFUGETUBEID)) && dsproperties.getValue(i, PROPERTY_LAYOUTID).equalsIgnoreCase(templayoutds.getValue(0, PROPERTY_LAYOUTID))) {
                        dsproperties.setValue(i, SLIDEID, slideid);
                    }
                    // dsproperties.setValue(i, SLIDEID, slideid);
                }


            }
        }
        return dsproperties;
    }

    /**
     * @param properties
     * @return
     * @throws SapphireException
     */
    private DataSet createInputDataset(PropertyList properties) throws SapphireException {
        String centrifugetubeid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
        String testcodeid = properties.getProperty(PROPERTY_TESTCODEID);
        String panelid = properties.getProperty(PROPERTY_PANELID);
        String rowpos = properties.getProperty(PROPERTY_ROWPOS);
        String columnpos = properties.getProperty(PROPERTY_COLUMNPOS);
        String layoutid = properties.getProperty(PROPERTY_LAYOUTID);
        String ispanel = properties.getProperty(PROPERTY_ISPANEL);
        if (Util.isNull(centrifugetubeid) || Util.isNull(rowpos) || Util.isNull(columnpos)) {
            throw new SapphireException(TYPE_VALIDATION, "Input properties is null.");
        }
        DataSet dsproperties = new DataSet();
        dsproperties.addColumnValues(PROPERTY_CENTRIFUGETUBEID, DataSet.STRING, centrifugetubeid, ";", "");
        dsproperties.addColumnValues(PROPERTY_LAYOUTID, DataSet.STRING, layoutid, ";", "");
        dsproperties.addColumnValues(PROPERTY_ROWPOS, DataSet.STRING, rowpos, ";", "");
        dsproperties.addColumnValues(PROPERTY_COLUMNPOS, DataSet.STRING, columnpos, ";", "");
        dsproperties.addColumnValues(PROPERTY_TESTCODEID, DataSet.STRING, testcodeid, ";", "");
        dsproperties.addColumnValues(PROPERTY_PANELID, DataSet.STRING, panelid, ";", "");
        dsproperties.addColumnValues(PROPERTY_ISPANEL, DataSet.STRING, ispanel, ";", "");

        return dsproperties;
    }

    /**
     * @param batchtype
     * @return
     * @throws SapphireException
     */
    private String createBatch(String batchtype) throws SapphireException {
        String newbatchid = "";
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = dept.substring(0, dept.lastIndexOf('-'));
        String sqlloc = Util.parseMessage(FishSqls.GET_LOCATION_OFUSER, dept);
        DataSet dsloc = getQueryProcessor().getSqlDataSet(sqlloc);
        String batchlocation = dsloc.getValue(0, "u_site");
        String sql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, site + "-%-" + batchtype);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String batchname = createBatchName(ds, batchtype, site);
        if (batchname.length() > 0) {
            String checksql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, batchname);
            DataSet dscheck = getQueryProcessor().getSqlDataSet(checksql);
            try {
                if (dscheck.size() > 0)
                    throw new SapphireException("Duplicate BatchName Present in Batch Table");
                else {
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatch");
                    props.setProperty("batchname", batchname);
                    props.setProperty("batchtype", batchtype);
                    props.setProperty("batchlocation", batchlocation);
                    props.setProperty("batchstate", STATUS);
                    props.setProperty("batchmovestatus", "slidedrop");
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                    newbatchid = props.getProperty(NEWKEYID1, "");
                }


            } catch (Exception e) {
                String error = getTranslationProcessor().translate("Could not create new Batch: " + e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }

        return newbatchid;
    }

    /**
     * @param ds
     * @param type
     * @param site
     * @return
     * @throws SapphireException
     * @Desc This function creates Unique identifier for batch based upon
     * protocol type and site.
     */
    private String createBatchName(DataSet ds, String type, String site) throws SapphireException {
        Integer max = Integer.MIN_VALUE;
        String CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String batchname = "";
        if (ds.size() == 0) {
            batchname = site + "-" + CURRENT_YEAR + "-" + "0000001" + "-" + type;
        } else {
            for (int i = 0; i < ds.size(); i++) {
                String querybatch = ds.getValue(i, "batchname");
                String value = querybatch.substring(querybatch.indexOf('-') + 6, querybatch.lastIndexOf('-'));
                int batchnm = Integer.parseInt(value);
                if (batchnm > max) {
                    max = batchnm;
                }
            }
            max++;
            int maxlength = max.toString().length();
            if (maxlength > 6)
                throw new SapphireException("Maximum limit of Batch sequence is exceed.New batch could not created.Please contact to Administrator");
            String seq = String.format(BATCHSEQ, max);
            batchname = site + "-" + CURRENT_YEAR + "-" + seq + "-" + type;
        }
        return batchname;
    }
}