package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import java.util.Calendar;
import java.util.HashMap;

import com.labvantage.sapphire.gwt.shared.util.StringUtil;

/**
 * This action will be used for creation of fish batch.
 * @author gopinath.pandi
 *
 */
public class CreateWashBatch extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String tramstop = properties.getProperty("tramstop");
        if (Util.isNull(tramstop)) {
            throw new SapphireException("Tramstop can't be null.Please contact to admin.");
        }
        String sampleid = properties.getProperty("keyid1");
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Sampleid can't be null.Please contact to admin.");
        }
        String type = properties.getProperty("protocol");
        if (Util.isNull(type)) {
            throw new SapphireException("Protocol can't be null.Please contact to admin.");
        }
        type = Util.getUniqueList(type, ";", true);
        String[] typeArr = StringUtil.split(type, ";");
        if (typeArr.length > 1) {
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Please select specimen with same protocol.");
        }
        try {
            String batchname = getBatchName(type);
            String batchId = createFishBatch(type, batchname);
            associateSamplesToFishBatch(batchId, sampleid, "1");// volume is 1.
            // that need to
            // discuss
            //applyAttributes(sampleid, type);
            properties.setProperty("batchid", batchId);
        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Error: ");
            error += e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        } finally {
        }
    }

    /**
     * @Desc This method is used to get batch name.
     * @param type
     * @throws SapphireException
     */
    private String getBatchName(String type) throws SapphireException {
        if (Util.isNull(type)) {
            throw new SapphireException("Batch Type Should not be Blank.");
        }
        String presentyear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        if (Util.isNull(dept)) {
            throw new SapphireException("Department can't be null.");
        }
        String site = dept.substring(0, dept.lastIndexOf('-'));
        String sqlLoc = Util.parseMessage(FishSqls.GET_LOCATION_OFUSER, dept);
        DataSet dsLoc = getQueryProcessor().getSqlDataSet(sqlLoc);
        if (dsLoc.size() == 0) {
            throw new SapphireException("Department's site can't be null.");
        }
        String sqlfishval = Util.parseMessage(FishSqls.GET_FISHBATCHVALUE);
        DataSet fishtype = getQueryProcessor().getSqlDataSet(sqlfishval);
        HashMap<String, String> hm = new HashMap<>();
        for (int i = 0; i < fishtype.size(); i++) {
            String refvalueid = fishtype.getValue(i, "refvalueid");
            String refvaluedesc = fishtype.getValue(i, "refvaluedesc");
            hm.put(refvalueid, refvaluedesc);
        }
        String typecode = hm.get(type);
        String sqlBatchName = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE,
                site + "-" + presentyear + "-%-" + typecode);
        DataSet dsBatchName = getQueryProcessor().getSqlDataSet(sqlBatchName);
        String batchname = createBatchName(dsBatchName, typecode, site);

        return batchname;
    }

    /**
     * This method is used for create batch name
     * @param ds
     * @param type
     * @param site
     * @return
     * @throws SapphireException
     */
    public String createBatchName(DataSet ds, String type, String site) throws SapphireException {
        String batchseq = "%06d";
        Integer max = Integer.MIN_VALUE;
        String CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String batchname = "";
        if (ds.size() == 0) {
            batchname = site + "-" + CURRENT_YEAR + "-" + "000001" + "-" + type;
        } else {
            for (int i = 0; i < ds.size(); i++) {
                String querybatch = ds.getValue(i, "batchname");
                String value = querybatch.substring(querybatch.indexOf('-') + 6, querybatch.lastIndexOf('-'));
                int batchnm = Integer.parseInt(value);
                if (batchnm > max) {
                    max = batchnm;
                }
            }
            max++;
            int maxlength = max.toString().length();
            if (maxlength > 6)
                throw new SapphireException(
                        "Maximum limit of Batch sequence is exceed.New batch could not created.Please contact to Administrator");
            String seq = String.format(batchseq, max);
            batchname = site + "-" + CURRENT_YEAR + "-" + seq + "-" + type;
        }
        return batchname;
    }
    /**
     * This method will create batch.
     * @param type
     * @param newbatchname
     * @return
     * @throws SapphireException
     */
    public String createFishBatch(String type, String newbatchname) throws SapphireException {
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        if (Util.isNull(dept)) {
            throw new SapphireException("Department can't be null.");
        }
        String sqlLoc = Util.parseMessage(FishSqls.GET_LOCATION_OFUSER, dept);
        DataSet dsLoc = getQueryProcessor().getSqlDataSet(sqlLoc);
        if (dsLoc.size() == 0) {
            throw new SapphireException("Department's site can't be null.");
        }
        String batchlocation = dsLoc.getValue(0, "u_site");
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatch");
        props.setProperty("batchname", newbatchname);
        props.setProperty("batchtype", type);
        props.setProperty("batchstate", "Open");
        props.setProperty("batchlocation", batchlocation);
        props.setProperty("batchmovestatus", "washbatch");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        String newkeyid = props.getProperty("newkeyid1", "");
        return newkeyid;
    }

    /**
     * This method is used for associate sample to the batch
     * @param batchid
     * @param samples
     * @param volume
     * @throws SapphireException
     */
    private void associateSamplesToFishBatch(String batchid, String samples, String volume) throws SapphireException {
        PropertyList fishbatchdeatil = new PropertyList();
        fishbatchdeatil.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatchSample");
        fishbatchdeatil.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(samples.split(";").length));
        fishbatchdeatil.setProperty("batchid", batchid);
        fishbatchdeatil.setProperty("sampleid", samples);
        fishbatchdeatil.setProperty("volume", volume);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, fishbatchdeatil);
        } catch (SapphireException se) {
            String errmsg = "Unable to associate samples to batch.";
            throw new SapphireException(errmsg);
        }
    }

    /**
     * This method is used for apply protocol workitem
     * @param samples
     * @param protocol
     * @throws SapphireException
     */
    private void applyAttributes(String samples, String protocol) throws SapphireException {
        String sqlwi = Util.parseMessage(FishSqls.GET_PROTOCOL_WORKITEM_WASH, protocol);
        DataSet dswi = getQueryProcessor().getSqlDataSet(sqlwi);
        if (dswi.size() > 0) {
            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Sample");
            propswi.setProperty("keyid1", samples);
            propswi.setProperty("applyworkitem", "Y");
            propswi.setProperty("workitemid", dswi.getValue(0, "workitemid"));
            propswi.setProperty("workitemversionid", dswi.getValue(0, "workitemversionid"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                String errmsg = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
        }
    }
}
