package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/*
 * This action is used for validation entered data of FISH attribute.
 */
public class AttributeEnteredDataValidate extends BaseAction {
	public void processAction(PropertyList properties) throws SapphireException {
		String instrumentid = properties.getProperty("instrumentid").trim();
		String expectedvalue = properties.getProperty("expectedvalue").trim();
		instrumentValidation(instrumentid,expectedvalue, properties);
	}

	/*
	 * This method is used for validate instrument.
	 */
	private void instrumentValidation(String instrumentid,String expectedvalue, PropertyList properties) throws SapphireException {
		String sqlInstrument = Util.parseMessage(FishSqls.GET_INSTRUMENTID, instrumentid,expectedvalue);
		DataSet dsInstrument = getQueryProcessor().getSqlDataSet(sqlInstrument);
		if (dsInstrument == null) {
			String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sqlInstrument;
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
		if (dsInstrument.size() > 0) {
			String instru = dsInstrument.getColumnValues("instrumentid", ";");
			properties.setProperty("instrument", instru);
		} else {
			properties.setProperty("instrument", "");
			String err = "Either this instrument is not registered in LV system or is not a valid "+expectedvalue+" instrument.";
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
		}
	}
}