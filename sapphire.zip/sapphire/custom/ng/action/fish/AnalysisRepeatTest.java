package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * This is used for repeat test from analysis. and it send specimen to recon
 * 
 * @author debasis.mondal
 *
 */
public class AnalysisRepeatTest extends BaseAction {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleids = properties.getProperty("s_sampleid");
		String currentstep = properties.getProperty("currentstep");
		String status = properties.getProperty("status");
		String testdesc = properties.getProperty("testdesc");
		if (Util.isNull(sampleids)) {
			throw new SapphireException("Specimen(s) are comming as null.");
		}
		if("labanalytics".equalsIgnoreCase(currentstep)) {
			validateRepeatCondition(sampleids,status,testdesc);
			DataSet ds = populateDataSet(sampleids);
			modifiTeststatus(ds);
		}
		else{
			DataSet ds = populateDataSet(sampleids);
			modifiTeststatus(ds);
		}
		//CallMoveToSlideReconActin(sampleids);
	}

	private DataSet populateDataSet(String sampleids) throws SapphireException{
		String sqlSample = Util.parseMessage(FishSqls.GET_TESTSAMPLE_DETAILS,sampleids.replaceAll(";", "','"));
		DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
		if (dsSample.size() == 0) {
			String errmsg = getTranslationProcessor().translate("Selected Specimens doesn't have Test Status.");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
		}
		DataSet ds = new DataSet();
		ds.addColumn("sample", DataSet.STRING);
		ds.addColumn("teststatus", DataSet.STRING);
		ds.addColumn("sampletestcodemapid", DataSet.STRING);
		int incr = 0;
		for (int i = 0; i < dsSample.size(); i++) {
			incr = ds.addRow();
			String status = dsSample.getValue(i,"teststatus");
			ds.setValue(incr, "sample", dsSample.getValue(i, "s_sampleid",""));
			ds.setValue(incr, "sampletestcodemapid", dsSample.getValue(i, "u_sampletestcodemapid",""));
			if("In Progress".equalsIgnoreCase(status)||"Completed".equalsIgnoreCase((status))){
				ds.setValue(incr, "teststatus", "Repeat Test");
			}
			else if("Repeat Test".equalsIgnoreCase(status)){
				ds.setValue(incr, "teststatus", "In Progress");
			}
		}
		return ds;
	}
	/*
	 * This will modify test status
	 */
	private void modifiTeststatus(DataSet dsMain) throws SapphireException {
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, dsMain.getColumnValues("sampletestcodemapid",";"));
		pl.setProperty("teststatus", dsMain.getColumnValues("teststatus",";"));
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		} catch (Exception ex) {
			String err = "Can not delete tests :" + ex.getMessage();
			throw new SapphireException(err);
		}
	}

	/*
	 * This is used to move specimen to recon
	 */
	public void CallMoveToSlideReconActin(String sampleid) throws SapphireException {

		PropertyList props = new PropertyList();
		props.setProperty("s_sampleid", sampleid);
		try {
			getActionProcessor().processAction("MoveToSlideRecon", "1", props);
		} catch (Exception e) {
			throw new SapphireException(e.getMessage());
		}
	}
	private void validateRepeatCondition(String sampleid,String status,String testdesc) throws SapphireException{
		sampleid=sampleid.replaceAll(";", "','");
		String sqlValid = Util.parseMessage(FishSqls.GET_VALIDATE_REPEATSAMPLES,testdesc,sampleid,sampleid);
		DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlValid);
		if("Repeat Test".equalsIgnoreCase(status)){
			if (dsSample.size() > 0) {
				String errmsg = getTranslationProcessor().translate("Undo repeat is not applicable because another slide already available for repeat test");
				throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
			}
		}
	}
}
