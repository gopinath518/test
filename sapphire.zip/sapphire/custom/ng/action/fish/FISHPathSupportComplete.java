package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Soumen Mitra on 23/03/2018. Description: Complete H&E from Path
 * support
 */
public class FISHPathSupportComplete extends BaseAction {

	public static String ID = "FISHPathSupportComplete";
	public static String VERSIONID = "1";

	public void processAction(PropertyList properties) throws SapphireException {
		String sampleids = properties.getProperty("keyid1");
		if (Util.isNull(sampleids)) {
			String errMsg = getTranslationProcessor().translate("Please select at least one sample.");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
		//For check methodology FISH
		String sqlMetho = Util.parseMessage(FishSqls.GET_METHODOLOGY, StringUtil.replaceAll(sampleids, ";", "','"));
		DataSet dsMetho = getQueryProcessor().getSqlDataSet(sqlMetho);
		if (dsMetho == null) {
			String errMsg = getTranslationProcessor()
					.translate("Something wrong happened. Contact your Administrator.");
			errMsg += "\nQuery returns null, Query failed:" + sqlMetho;
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
		if (dsMetho.size() == 0) {
			String errMsg = getTranslationProcessor().translate("No methodology found for the sample:" + sampleids);
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
		}
		for(String meth:StringUtil.split(dsMetho.getColumnValues("methodology", ";"), ";")){
			if(!"FISH".equalsIgnoreCase(meth)){
				String errMsg = getTranslationProcessor().translate("Please select FISH methodology obly.");
				throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
			}
		}
		//For get u_type H =H&E Slide, SH = Shared H&E slide
		String sqlType = Util.parseMessage(FishSqls.GET_TYPE, StringUtil.replaceAll(sampleids, ";", "','"));
		DataSet dsType = getQueryProcessor().getSqlDataSet(sqlType);
		if (dsType == null) {
			String errMsg = getTranslationProcessor()
					.translate("Something wrong happened. Contact your Administrator.");
			errMsg += "\nQuery returns null, Query failed:" + sqlType;
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
		if (dsType.size() == 0) {
			String errMsg = getTranslationProcessor().translate("No u_type found for the sample:" + sampleids);
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
		}

		DataSet dsSampleInfo = new DataSet();
		dsSampleInfo.addColumn("sampleid", DataSet.STRING);
		dsSampleInfo.addColumn("type", DataSet.STRING);
		dsSampleInfo.addColumn("nextmovementstep", DataSet.STRING);
		dsSampleInfo.addColumn("custodialdept", DataSet.STRING);

		for (int i = 0; i < dsType.size(); i++) {
			int rowId = dsSampleInfo.addRow();
			dsSampleInfo.setValue(rowId, "sampleid", dsType.getValue(i, "s_sampleid"));
			if ("H".equalsIgnoreCase(dsType.getValue(i, "u_type")) || "CH".equalsIgnoreCase(dsType.getValue(i, "u_type"))) {
				dsSampleInfo.setValue(rowId, "type", dsType.getValue(i, "u_type"));
			} else {
				String errMsg = getTranslationProcessor().translate(
						"Please select only H&E sample. " + dsType.getValue(i, "s_sampleid") + " is not H&E sample.");
				throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
			}
		}

		DataSet dsHNEReviewPolicy = getPolicyForFish();
		transferSamples(dsSampleInfo, dsHNEReviewPolicy);

	}

	/**
	 * This method is for updating Sample and trackitem SDC after getting site
	 * from logged used.
	 * 
	 * @param sampleInfo
	 * @param dsPolicy
	 * @throws SapphireException
	 */
	private void transferSamples(DataSet sampleInfo, DataSet dsPolicy) throws SapphireException {

		HashMap<String, String> hm = new HashMap<String, String>();
		for (int i = 0; i < sampleInfo.getRowCount(); i++) {
			hm.clear();
			hm.put("type", sampleInfo.getValue(i, "type", ""));

			DataSet dsSubPolicy = dsPolicy.getFilteredDataSet(hm);
			String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
			String site = department.substring(0, department.lastIndexOf('-'));
			if (dsSubPolicy.size() > 0) {
				sampleInfo.setValue(i, "nextmovementstep", dsSubPolicy.getValue(0, "nextmovementstep", ""));
				String cust = dsSubPolicy.getValue(0, "custodialdept", "");
				String destination = site + "-" + cust;
				if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor())) {
					throw new SapphireException(
							"Error: Unable to route specimen. Department: " + destination + " does not exist");
				}
				sampleInfo.setValue(i, "custodialdept", destination);
			}
		}

		PropertyList prop = new PropertyList();
		prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleInfo.getColumnValues("sampleid", ";"));
		prop.setProperty("u_currentmovementstep", sampleInfo.getColumnValues("nextmovementstep", ";"));
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Error in edit sample");
			error += ae.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
		}
		prop.clear();
		prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		prop.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleInfo.getColumnValues("sampleid", ";"));
		prop.setProperty("u_currenttramstop", sampleInfo.getColumnValues("nextmovementstep", ";"));
		prop.setProperty("custodialuserid", StringUtil.repeat("(null)", sampleInfo.size(), ";"));
		prop.setProperty("custodytakendt", StringUtil.repeat("n", sampleInfo.size(), ";"));
		prop.setProperty("custodialdepartmentid", sampleInfo.getColumnValues("custodialdept", ";"));

		try {
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Error in edit track item.");
			error += ae.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
		}

	}

	/**
	 * Description: This is to get Exraction type details from the policy
	 *
	 * @return dsPolicy
	 * @throws SapphireException
	 */
	private DataSet getPolicyForFish() throws SapphireException {
		DataSet dsPloicy = new DataSet();
		int incr = 0;
		dsPloicy.addColumn("type", DataSet.STRING);
		dsPloicy.addColumn("methodology", DataSet.STRING);
		dsPloicy.addColumn("currentmovementstep", DataSet.STRING);
		dsPloicy.addColumn("currenttramstop", DataSet.STRING);
		dsPloicy.addColumn("nextmovementstep", DataSet.STRING);
		dsPloicy.addColumn("nexttramstop", DataSet.STRING);
		dsPloicy.addColumn("custodialdept", DataSet.STRING);
		PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("HNEReviewCompletePolicy",
				"FISHPathSupportComplete");
		PropertyListCollection plcRoutingrules = plMicroPolicy.getCollection("routingrules");
		for (int i = 0; i < plcRoutingrules.size(); i++) {
			incr = dsPloicy.addRow();
			PropertyListCollection plcConditions = plcRoutingrules.getPropertyList(i).getCollection("conditions");
			PropertyListCollection plcColumnvaluepair = plcConditions.getPropertyList(0)
					.getCollection("columnvaluepair");
			for (int j = 0; j < plcColumnvaluepair.size(); j++) {
				String column = plcColumnvaluepair.getPropertyList(j).getProperty("column");
				String value = plcColumnvaluepair.getPropertyList(j).getProperty("value");
				if (column.equalsIgnoreCase("u_type")) {
					dsPloicy.setValue(incr, "type", value);
				} else {
					dsPloicy.setValue(incr, "methodology", value);
				}
			}
			String currentmovementstep = plcConditions.getPropertyList(0).getProperty("currentmovementstep");
			String currenttramstop = plcConditions.getPropertyList(0).getProperty("currenttram");
			String nextmovementstep = plcConditions.getPropertyList(0).getProperty("nextmovementstep");
			String nexttramstop = plcConditions.getPropertyList(0).getProperty("nexttramstop");
			String custodiandept = plcConditions.getPropertyList(0).getProperty("custodiandept");

			dsPloicy.setValue(incr, "currentmovementstep", currentmovementstep);
			dsPloicy.setValue(incr, "currenttramstop", currenttramstop);
			dsPloicy.setValue(incr, "nextmovementstep", nextmovementstep);
			dsPloicy.setValue(incr, "nexttramstop", nexttramstop);
			dsPloicy.setValue(incr, "custodialdept", custodiandept);
		}
		return dsPloicy;
	}

	/**
	 * Description: This is used to build a dataset to manupulate rule for
	 * scanned specimens.
	 *
	 * @param dsInput
	 * @param dsPolicy
	 * @param macrodissectionrule
	 * @param properties
	 * @return dsFinal
	 * @throws SapphireException
	 */
	private DataSet createMainDataSet(DataSet dsInput, DataSet dsPolicy, String macrodissectionrule,
			PropertyList properties) throws SapphireException {
		DataSet dsFinal = new DataSet();
		dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_TYPE, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_CURRENTTRAMSTOP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_CURRENTMOVEMENTSTEP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_NEXT_MOVEMENTSTEP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_NEXT_TRAMSTOP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_HNE_REV, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_REV_BY, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_REV_DT, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_PARENTSAMPLE, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
		dsFinal.addColumn("clientspecimenid", DataSet.STRING);

		String defaultdepartment = connectionInfo.getDefaultDepartment();
		String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));

		String sqlType = Util.parseMessage(MolecularSql.GET_METHODOLOGY_BY_SAMPLEIDS,
				StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "','"));
		DataSet dsSlidesInfo = getQueryProcessor().getSqlDataSet(sqlType);
		if (dsSlidesInfo == null || dsSlidesInfo.size() == 0) {
			throw new SapphireException("No Testcode(s) are associated with the sample(s): "
					+ StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "', '"));
		}
		HashMap<String, String> hm = new HashMap<String, String>();
		for (int i = 0; i < dsSlidesInfo.size(); i++) {
			String s_sampleid = dsSlidesInfo.getValue(i, "s_sampleid", "");
			String methodology = dsSlidesInfo.getValue(i, "methodology", "");
			String u_type = dsSlidesInfo.getValue(i, "u_type", "");
			String u_tumorcircled = dsSlidesInfo.getValue(i, "u_tumorcircled", "");
			String parentsampleid = dsSlidesInfo.getValue(i, "parentsampleid", "");
			String lvtestcodeid = dsSlidesInfo.getValue(i, "lvtestcodeid", "");
			String clientspecimenid = dsSlidesInfo.getValue(i, "u_clientspecimenid", "");
			hm.clear();
			hm.put("type", u_type);
			hm.put("methodology", methodology);
			DataSet dsfilter = dsPolicy.getFilteredDataSet(hm);
			if (dsfilter != null && dsfilter.size() > 0) {
				int rowID = dsFinal.addRow();
				dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, s_sampleid);
				dsFinal.setValue(rowID, DATASET_PROPERTY_TYPE, u_type);
				dsFinal.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsfilter.getValue(0, "methodology", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTTRAMSTOP, dsfilter.getValue(0, "currenttramstop", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT,
						deptValidate(departmentSite + "-" + dsfilter.getValue(0, "custodialdept", "")));
				dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTMOVEMENTSTEP,
						dsfilter.getValue(0, "currentmovementstep", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_MOVEMENTSTEP,
						dsfilter.getValue(0, "nextmovementstep", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_TRAMSTOP, dsfilter.getValue(0, "nexttramstop", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_HNE_REV, "");
				dsFinal.setValue(rowID, DATASET_PROPERTY_REV_DT, "");
				dsFinal.setValue(rowID, DATASET_PROPERTY_REV_BY, "");
				dsFinal.setValue(rowID, DATASET_PROPERTY_TUMORCIRCLED, u_tumorcircled);
				dsFinal.setValue(rowID, DATASET_PROPERTY_PARENTSAMPLE, parentsampleid);
				dsFinal.setValue(rowID, DATASET_PROPERTY_LVTESTCODEID, lvtestcodeid);
				dsFinal.setValue(rowID, "clientspecimenid", clientspecimenid);
			}
		}
		DataSet dsFinalFinal = new DataSet();
		dsFinalFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
		dsFinalFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
		dsFinalFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
		if (dsFinal != null && dsFinal.size() > 0) {
			String parentsampls = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_PARENTSAMPLE, ";"), ";",
					true);
			String arryParent[] = StringUtil.split(parentsampls, ";");
			for (int i = 0; i < arryParent.length; i++) {
				double dmacrodissectionrule = 0.0, u_tumorcircled = 0.0;
				String tumorcircledval = "";
				HashMap hmp = new HashMap();
				hmp.clear();
				hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
				hmp.put(DATASET_PROPERTY_TYPE, "H");
				// hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
				DataSet dsHNEFilter = dsFinal.getFilteredDataSet(hmp);
				if (dsHNEFilter != null && dsHNEFilter.size() > 0) {
					for (int j = 0; j < dsHNEFilter.size(); j++) {
						// int rowId = dsFinal.g
						int RowID = dsFinalFinal.addRow();
						tumorcircledval = dsHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "N");
						if (!"N".equalsIgnoreCase(tumorcircledval)) {
							u_tumorcircled = Double
									.parseDouble(dsHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
							dmacrodissectionrule = Double.parseDouble(macrodissectionrule);
							if (u_tumorcircled < dmacrodissectionrule) {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
							} else {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
							}
						} else {
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
									dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
									dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
									dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
						}
					}
				} else {
					for (int j = 0; j < dsHNEFilter.size(); j++) {
						int RowID = dsFinalFinal.addRow();
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
								dsHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
								dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
								dsHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
					}
				}

				hmp.clear();
				hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
				hmp.put(DATASET_PROPERTY_TYPE, "U");
				// hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
				DataSet dsUnstainedFilter = dsFinal.getFilteredDataSet(hmp);
				if (dsUnstainedFilter != null && dsUnstainedFilter.size() > 0) {
					for (int j = 0; j < dsUnstainedFilter.size(); j++) {
						int RowID = dsFinalFinal.addRow();
						if (!"N".equalsIgnoreCase(tumorcircledval)) {
							if (u_tumorcircled < dmacrodissectionrule) {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_TRAMSTOP, ""));
							} else {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
							}
						} else {
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
									dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
									dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
									dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
						}
					}
				} else {
					for (int j = 0; j < dsUnstainedFilter.size(); j++) {
						int RowID = dsFinalFinal.addRow();
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
								dsUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
								dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
								dsUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
					}
				}

				hmp.clear();
				hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
				hmp.put(DATASET_PROPERTY_TYPE, "CH");
				// hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
				DataSet dsCHNEFilter = dsFinal.getFilteredDataSet(hmp);
				if (dsCHNEFilter != null && dsCHNEFilter.size() > 0) {
					for (int j = 0; j < dsCHNEFilter.size(); j++) {
						// int rowId = dsFinal.g
						int RowID = dsFinalFinal.addRow();
						tumorcircledval = dsCHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "N");
						if (!"N".equalsIgnoreCase(tumorcircledval)) {
							u_tumorcircled = Double
									.parseDouble(dsCHNEFilter.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
							dmacrodissectionrule = Double.parseDouble(macrodissectionrule);
							if (u_tumorcircled < dmacrodissectionrule) {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsCHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsCHNEFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
							} else {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
							}
						} else {
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
									dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
									dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
									dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
						}
					}
				} else {
					for (int j = 0; j < dsCHNEFilter.size(); j++) {
						int RowID = dsFinalFinal.addRow();
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
								dsCHNEFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
								dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
								dsCHNEFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
					}
				}

				hmp.clear();
				hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
				hmp.put(DATASET_PROPERTY_TYPE, "CU");
				// hmp.put(DATASET_PROPERTY_LVTESTCODEID, "4047X");
				DataSet dsCUnstainedFilter = dsFinal.getFilteredDataSet(hmp);
				if (dsCUnstainedFilter != null && dsCUnstainedFilter.size() > 0) {
					for (int j = 0; j < dsCUnstainedFilter.size(); j++) {
						int RowID = dsFinalFinal.addRow();
						if (!"N".equalsIgnoreCase(tumorcircledval)) {
							if (u_tumorcircled < dmacrodissectionrule) {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_NEXT_TRAMSTOP, ""));
							} else {
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
										dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
										dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
								dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
										dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
							}
						} else {
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
									dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
									dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
							dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
									dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
						}
					}
				} else {
					for (int j = 0; j < dsCUnstainedFilter.size(); j++) {
						int RowID = dsFinalFinal.addRow();
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_SAMPLEID,
								dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
								dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
						dsFinalFinal.setValue(RowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
								dsCUnstainedFilter.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
					}
				}

				hmp.clear();
				hmp.put(DATASET_PROPERTY_PARENTSAMPLE, arryParent[i]);
				hmp.put(DATASET_PROPERTY_TYPE, "");
				DataSet dsLiquidFilter = dsFinal.getFilteredDataSet(hmp);
				if (dsLiquidFilter != null && dsLiquidFilter.size() > 0) {
					dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP,
							dsLiquidFilter.getValue(0, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
					dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
							dsLiquidFilter.getValue(0, DATASET_PROPERTY_NEXT_TRAMSTOP, ""));
				}
			}
		}
		if (dsFinal.size() == dsFinalFinal.size()) {
			for (int i = 0; i < dsFinal.size(); i++) {
				String sampleid = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
				HashMap hmo = new HashMap();
				hmo.clear();
				hmo.put(DATASET_PROPERTY_SAMPLEID, sampleid);
				DataSet dsFilter = dsFinalFinal.getFilteredDataSet(hmo);

				dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP,
						dsFilter.getValue(0, DATASET_PROPERTY_FINAL_MOMENTSTEP, ""));
				dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
						dsFilter.getValue(0, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, ""));
			}
		} else {
			for (int i = 0; i < dsFinal.size(); i++) {
				dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP,
						dsFinal.getValue(i, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
				dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
						dsFinal.getValue(i, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
			}
		}
		return dsFinal;
	}

	/**
	 * Description: This is used to takeing care for client slides
	 *
	 * @param dsInput
	 * @param dsPolicy
	 * @param microdissectionrule
	 * @param properties
	 * @return dsFinal
	 * @throws SapphireException
	 */
	private DataSet createClientSlideDataSet(DataSet dsInput, DataSet dsPolicy, String microdissectionrule,
			PropertyList properties) throws SapphireException {
		DataSet dsFinal = new DataSet();
		dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_TYPE, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_CURRENTTRAMSTOP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_CURRENTMOVEMENTSTEP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_NEXT_MOVEMENTSTEP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_NEXT_TRAMSTOP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_HNE_REV, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_REV_BY, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_REV_DT, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_PARENTSAMPLE, DataSet.STRING);
		dsFinal.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
		dsFinal.addColumn("accessionid", DataSet.STRING);
		dsFinal.addColumn("clientspecimenid", DataSet.STRING);

		String defaultdepartment = connectionInfo.getDefaultDepartment();
		String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));

		String sqlType = Util.parseMessage(MolecularSql.GET_METHODOLOGY_BY_SAMPLEIDS,
				StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "','"));
		DataSet dsSlidesInfo = getQueryProcessor().getSqlDataSet(sqlType);
		if (dsSlidesInfo == null || dsSlidesInfo.size() == 0) {
			throw new SapphireException("No Testcode(s) are associated with the sample(s): "
					+ StringUtil.replaceAll(dsInput.getColumnValues("sampleid", ";"), ";", "', '"));
		}
		HashMap<String, String> hm = new HashMap<String, String>();
		for (int i = 0; i < dsSlidesInfo.size(); i++) {
			String s_sampleid = dsSlidesInfo.getValue(i, "s_sampleid", "");
			String methodology = dsSlidesInfo.getValue(i, "methodology", "");
			String u_type = dsSlidesInfo.getValue(i, "u_type", "");
			String u_tumorcircled = dsSlidesInfo.getValue(i, "u_tumorcircled", "");
			String parentsampleid = dsSlidesInfo.getValue(i, "parentsampleid", "");
			String lvtestcodeid = dsSlidesInfo.getValue(i, "lvtestcodeid", "");
			String u_accessionid = dsSlidesInfo.getValue(i, "u_accessionid", "");
			String u_clientspecimenid = dsSlidesInfo.getValue(i, "u_clientspecimenid", "");
			hm.clear();
			hm.put("type", u_type);
			hm.put("methodology", methodology);
			DataSet dsfilter = dsPolicy.getFilteredDataSet(hm);
			if (dsfilter != null && dsfilter.size() > 0) {
				int rowID = dsFinal.addRow();
				dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, s_sampleid);
				dsFinal.setValue(rowID, DATASET_PROPERTY_TYPE, u_type);
				dsFinal.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsfilter.getValue(0, "methodology", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTTRAMSTOP, dsfilter.getValue(0, "currenttramstop", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT,
						deptValidate(departmentSite + "-" + dsfilter.getValue(0, "custodialdept", "")));
				dsFinal.setValue(rowID, DATASET_PROPERTY_CURRENTMOVEMENTSTEP,
						dsfilter.getValue(0, "currentmovementstep", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_MOVEMENTSTEP,
						dsfilter.getValue(0, "nextmovementstep", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_NEXT_TRAMSTOP, dsfilter.getValue(0, "nexttramstop", ""));
				dsFinal.setValue(rowID, DATASET_PROPERTY_HNE_REV, "");
				dsFinal.setValue(rowID, DATASET_PROPERTY_REV_DT, "");
				dsFinal.setValue(rowID, DATASET_PROPERTY_REV_BY, "");
				dsFinal.setValue(rowID, DATASET_PROPERTY_TUMORCIRCLED, u_tumorcircled);
				dsFinal.setValue(rowID, DATASET_PROPERTY_PARENTSAMPLE, parentsampleid);
				dsFinal.setValue(rowID, DATASET_PROPERTY_LVTESTCODEID, lvtestcodeid);
				dsFinal.setValue(rowID, "accessionid", u_accessionid);
				dsFinal.setValue(rowID, "clientspecimenid", u_clientspecimenid);
				// dsFinal.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
				// dsfilter.getValue(0, "currentmovementstep", ""));
				// dsFinal.setValue(rowID,
				// DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, dsfilter.getValue(0,
				// "currenttramstop", ""));
			}

		}
		if (dsFinal != null && dsFinal.size() > 0) {
			hm.clear();
			hm.put(DATASET_PROPERTY_TYPE, "CH");
			DataSet dsFilter = dsFinal.getFilteredDataSet(hm);
			if (dsFilter.size() > 0) {
				hm.clear();
				hm.put(DATASET_PROPERTY_TUMORCIRCLED, null);
				DataSet dsTumorFilter = dsFilter.getFilteredDataSet(hm);
				if (dsTumorFilter.size() > 0) {
					throw new SapphireException(
							"Tumor Circled can not be blank. Please complete H&E review for specimen(s): "
									+ dsTumorFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ","));
				}
				// String tumorcircled = dsFilter.getValue(0,
				// DATASET_PROPERTY_TUMORCIRCLED, "");
				// dsFinal.addColumnValues(DATASET_PROPERTY_TUMORCIRCLED,
				// DataSet.STRING, StringUtil.repeat(tumorcircled,
				// dsFinal.size(), ";"), ";");
			}
			DataSet dsFinalMov = new DataSet();
			dsFinalMov.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
			dsFinalMov.addColumn(DATASET_PROPERTY_FINAL_MOMENTSTEP, DataSet.STRING);
			dsFinalMov.addColumn(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, DataSet.STRING);
			dsFinal.sort("accessionid,clientspecimenid");
			ArrayList<DataSet> dsFinalArr = dsFinal.getGroupedDataSets("accessionid,clientspecimenid");
			for (int i = 0; i < dsFinalArr.size(); i++) {
				DataSet dsEach = dsFinalArr.get(i);
				hm.clear();
				hm.put(DATASET_PROPERTY_TYPE, "CH");
				DataSet dsHNEFilter = dsEach.getFilteredDataSet(hm);
				if (dsHNEFilter.size() > 0) {
					hm.clear();
					hm.put(DATASET_PROPERTY_TUMORCIRCLED, null);
					DataSet dsTumorFilter = dsHNEFilter.getFilteredDataSet(hm);
					if (dsTumorFilter.size() > 0) {
						throw new SapphireException(
								"Tumor Circled can not be blank. Please complete H&E review for specimen(s): "
										+ dsTumorFilter.getColumnValues(DATASET_PROPERTY_SAMPLEID, ","));
					}
					String tumorcircled = dsHNEFilter.getValue(0, DATASET_PROPERTY_TUMORCIRCLED, "");
					dsEach.addColumnValues(DATASET_PROPERTY_TUMORCIRCLED, DataSet.STRING,
							StringUtil.repeat(tumorcircled, dsEach.size(), ";"), ";");
				}
				for (int j = 0; j < dsEach.size(); j++) {
					double u_tumorcircled = Double
							.parseDouble(dsEach.getValue(j, DATASET_PROPERTY_TUMORCIRCLED, "0.0"));
					double u_microdissectionrule = Double.parseDouble(microdissectionrule);
					int rowID = dsFinalMov.addRow();
					if (u_tumorcircled < u_microdissectionrule) {

						dsFinalMov.setValue(rowID, DATASET_PROPERTY_SAMPLEID,
								dsEach.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
						dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
								dsEach.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
						dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
								dsEach.getValue(j, DATASET_PROPERTY_NEXT_MOVEMENTSTEP, ""));
					} else {
						dsFinalMov.setValue(rowID, DATASET_PROPERTY_SAMPLEID,
								dsEach.getValue(j, DATASET_PROPERTY_SAMPLEID, ""));
						dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTSTEP,
								dsEach.getValue(j, DATASET_PROPERTY_CURRENTMOVEMENTSTEP, ""));
						dsFinalMov.setValue(rowID, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP,
								dsEach.getValue(j, DATASET_PROPERTY_CURRENTTRAMSTOP, ""));
					}
				}
			}
			if (dsFinal.size() == dsFinalMov.size()) {
				for (int i = 0; i < dsFinal.size(); i++) {
					String sampleid = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
					hm.clear();
					hm.put(DATASET_PROPERTY_SAMPLEID, sampleid);
					DataSet dsFil = dsFinalMov.getFilteredDataSet(hm);
					if (dsFil.size() > 0) {
						String finalmovementtramstop = dsFil.getValue(0, DATASET_PROPERTY_FINAL_MOMENTSTEP, "");
						String finalmovestep = dsFil.getValue(0, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, "");

						dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTSTEP, finalmovementtramstop);
						dsFinal.setValue(i, DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, finalmovestep);
					}
				}
			}

		}

		return dsFinal;
	}

	/**
	 * Description: This is used to validate department
	 *
	 * @param siteDept
	 * @return department
	 * @throws SapphireException
	 */
	private String deptValidate(String siteDept) throws SapphireException {
		String site = siteDept.substring(0, siteDept.indexOf("-"));
		String targetDept = siteDept.substring(siteDept.indexOf("-") + 1, siteDept.length());
		String department = "";
		String dept = "select departmentid from department where departmentid='" + siteDept + "'";
		DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
		if (dsdept == null) {
			String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
			errStr += "\n Query failed: " + dept;
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
		}
		if (dsdept.size() == 0) {
			String errStr = getTranslationProcessor().translate(targetDept + " Department not found in site " + site);
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
		} else {
			department = dsdept.getValue(0, "departmentid");
		}
		return department;
	}

	/**
	 * Description: This is to take lab details from policy
	 *
	 * @return null
	 * @throws SapphireException
	 */
	private DataSet getLabPolicy() throws SapphireException {
		DataSet dsLab = new DataSet();
		dsLab.addColumn("methodology", DataSet.STRING);
		dsLab.addColumn("department", DataSet.STRING);
		dsLab.addColumn("fullsitename", DataSet.STRING);
		dsLab.addColumn("siteinitials", DataSet.STRING);
		PropertyList plLabPolicy = getConfigurationProcessor().getPolicy("LabLocationPolicy", "LabDetails");
		if (plLabPolicy == null) {
			throw new SapphireException("Performing Lab is not created into Policy: LabLocationPolicy > LabDetails");
		}
		PropertyListCollection plcLabDetailsCollection = plLabPolicy.getCollection("labdetails");
		if (plcLabDetailsCollection == null || plcLabDetailsCollection.size() == 0) {
			throw new SapphireException("Performing Lab is not defined into Policy: LabLocationPolicy > LabDetails");
		}
		if (plcLabDetailsCollection.size() > 0) {
			for (int i = 0; i < plcLabDetailsCollection.size(); i++) {
				String methodology = plcLabDetailsCollection.getPropertyList(i).getProperty("methodology");
				String department = plcLabDetailsCollection.getPropertyList(i).getProperty("department");
				String fullsitename = plcLabDetailsCollection.getPropertyList(i).getProperty("fullsitename");
				String siteinitials = plcLabDetailsCollection.getPropertyList(i).getProperty("siteinitials");
				int rowID = dsLab.addRow();
				dsLab.setValue(rowID, "methodology", methodology);
				dsLab.setValue(rowID, "department", department);
				dsLab.setValue(rowID, "fullsitename", fullsitename);
				dsLab.setValue(rowID, "siteinitials", siteinitials);
			}
		}
		return dsLab;
	}

	/**
	 * Description: This is used to update movement step for the specimens
	 *
	 * @param dsFinal
	 * @return null
	 * @throws SapphireException
	 */
	private void updateSpecimensMovement(DataSet dsFinal) throws SapphireException {
		PropertyList prop = new PropertyList();
		prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
		prop.setProperty("u_currentmovementstep", dsFinal.getColumnValues(DATASET_PROPERTY_FINAL_MOMENTSTEP, ";"));
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Error in edit sample");
			error += ae.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
		}
		prop.clear();
		prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
		prop.setProperty("u_currenttramstop", dsFinal.getColumnValues(DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP, ";"));
		prop.setProperty("custodialuserid", StringUtil.repeat("(null)", dsFinal.size(), ";"));
		prop.setProperty("custodytakendt", StringUtil.repeat("n", dsFinal.size(), ";"));
		prop.setProperty("custodialdepartmentid", dsFinal.getColumnValues(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, ";"));

		try {
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
		} catch (ActionException ae) {
			String error = getTranslationProcessor().translate("Error in edit track item.");
			error += ae.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
		}
	}

	private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
	private static final String DATASET_PROPERTY_TYPE = "type";
	private static final String DATASET_PROPERTY_METHODOLOGY = "methodology";
	private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";
	private static final String DATASET_PROPERTY_CURRENTTRAMSTOP = "currenttramstop";
	private static final String DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT = "custodialdepartmentid";
	private static final String DATASET_PROPERTY_CURRENTMOVEMENTSTEP = "currentmovementstep";
	private static final String DATASET_PROPERTY_NEXT_MOVEMENTSTEP = "nextmovementstep";
	private static final String DATASET_PROPERTY_NEXT_TRAMSTOP = "nexttramstop";
	private static final String DATASET_PROPERTY_FINAL_MOMENTSTEP = "finalmovementtramstop";
	private static final String DATASET_PROPERTY_FINAL_MOMENTTRAMSTOP = "finalmovementstep";
	private static final String DATASET_PROPERTY_HNE_REV = "hnebatchreview";
	private static final String DATASET_PROPERTY_REV_BY = "pathreviewedby";
	private static final String DATASET_PROPERTY_REV_DT = "pathreviewdts";
	private static final String DATASET_PROPERTY_TUMORCIRCLED = "u_tumorcircled";
	private static final String DATASET_PROPERTY_PARENTSAMPLE = "parentsampleid";
}
