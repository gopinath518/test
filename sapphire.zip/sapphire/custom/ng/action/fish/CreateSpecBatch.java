package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.custom.ng.sql.fish.FishSqls;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Properties;

/**
 * Created by ssen on 12/28/2016.
 * @Desc : This action creates specimenprep batch based upon protocol.
 * Also create and associate centrifuge tube in batch.
 * @param : fishspecbatchtype .Protocol type.
 * @param : sampleid . Samples which will become part of batch.
 *
 */

public class CreateSpecBatch extends BaseAction {
    String batchseq = "%06d";
    String status = "Open";
    String newkeyid = "";

    public void processAction(PropertyList properties) throws SapphireException {
        String type = properties.getProperty("fishspecbatchtype");
        String sampleid = properties.getProperty("sampleid");
        String presentyear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = dept.substring(0, dept.lastIndexOf('-'));
        String sqlloc = Util.parseMessage(FishSqls.GET_LOCATION_OFUSER, dept);
        DataSet dsloc = getQueryProcessor().getSqlDataSet(sqlloc);
        String batchlocation = dsloc.getValue(0, "u_site");
        String sqlfishval = Util.parseMessage(FishSqls.GET_FISHBATCHVALUE);
        DataSet fishtype = getQueryProcessor().getSqlDataSet(sqlfishval);
        HashMap<String, String> hm = new HashMap<>();
        for (int i = 0; i < fishtype.size(); i++) {
            String refvalueid = fishtype.getValue(i, "refvalueid");
            String refvaluedesc = fishtype.getValue(i, "refvaluedesc");
            hm.put(refvalueid, refvaluedesc);
        }
        String typecode = "";

        if (Util.isNull(type)) {
            throw new SapphireException("Batch Type Should not Blank");
        }
        typecode = hm.get(type);
       /* if(type.equalsIgnoreCase("PET"))
            typecode="PET";
        else if(type.equalsIgnoreCase("HEME PCE"))
            typecode="HMEPCE";
        else if(type.equalsIgnoreCase("HEME"))
            typecode="HME";
        else if(type.equalsIgnoreCase("Process and Hold"))
            typecode="PRHLD";
        else
            throw  new SapphireException("Batch Type Should not Blank");*/
        String sql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, site +"-" + presentyear + "-%-" + typecode);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String batchname = createBatchName(ds, typecode, site);
        cerateBatch(batchname, type, batchlocation);
       String centrifugeid= createCentrifugeTube(newkeyid, sampleid, type);
        if(centrifugeid.length()>0) {
            properties.setProperty("fishbatchid", newkeyid);
        }
    }

    /**
     * @Desc This fuction calls CreateCentrifugeTube action in order to create centrifuge tube
     * from input samples.
     * @param newkeyid
     * @param sampleid
     * @param type
     */
    private String createCentrifugeTube(String newkeyid, String sampleid, String type) {
        String centrifugeid="";
        PropertyList prop = new PropertyList();
        prop.clear();
        prop.setProperty("batchid", newkeyid);
        prop.setProperty("protocol", type);
        prop.setProperty("sampleid", sampleid);
        try {
            getActionProcessor().processAction("CreateCentrifugeTube", "1", prop);
            centrifugeid=prop.getProperty("centrifugeid","");
        } catch (ActionException e) {

            e.printStackTrace();
        }
        return centrifugeid;
    }

    /**
     * @Desc This function creates Unique identifier for batch based upon
     *  protocol type and site.
     * @param ds
     * @param type
     * @param site
     * @return
     * @throws SapphireException
     */
    public String createBatchName(DataSet ds, String type, String site) throws SapphireException {
        Integer max = Integer.MIN_VALUE;
        String CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String batchname = "";
        if (ds.size() == 0) {
            batchname = site + "-" + CURRENT_YEAR + "-" + "000001" + "-" + type;
        } else {
            for (int i = 0; i < ds.size(); i++) {
                String querybatch = ds.getValue(i, "batchname");
                String value = querybatch.substring(querybatch.indexOf('-') + 6, querybatch.lastIndexOf('-'));
                int batchnm = Integer.parseInt(value);
                if (batchnm > max) {
                    max = batchnm;
                }
            }
            max++;
            int maxlength = max.toString().length();
            if (maxlength > 6)
                throw new SapphireException("Maximum limit of Batch sequence is exceed.New batch could not created.Please contact to Administrator");

            /*int maxlength = max.toString().length();
            String seq="";
            for(int i=0;i<5-maxlength;i++){
                seq = seq+"0";
            }
            seq += max;*/
            String seq = String.format(batchseq, max);
            batchname = site + "-"  + CURRENT_YEAR + "-" + seq + "-" + type;
        }
        return batchname;
    }

    /**
     * @Desc This function creates Specimenprep batch.
     * @param batchname
     * @param type
     * @param batchlocation
     * @throws SapphireException
     */
    public void cerateBatch(String batchname, String type, String batchlocation) throws SapphireException {
        String checksql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, batchname);
        DataSet dscheck = getQueryProcessor().getSqlDataSet(checksql);
        try {
            if (dscheck.size() > 0)
                throw new SapphireException("Duplicate BatchName Present in Batch Table");
            else {
                PropertyList props = new PropertyList();
                props.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatch");
                props.setProperty("batchname", batchname);
                props.setProperty("batchtype", type);
                props.setProperty("batchlocation", batchlocation);
                props.setProperty("batchstate", status);
                props.setProperty("batchmovestatus", "specimenprep");
                props.setProperty("origin", "specimenprep");
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                newkeyid = props.getProperty("newkeyid1", "");
            }


        } catch (Exception e) {
            String error = getTranslationProcessor().translate("Could not create new Batch: " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }


}
