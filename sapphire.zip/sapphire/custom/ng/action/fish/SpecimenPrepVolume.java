package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/*
 * Description : If centrifused tube is not required, centrifused tube's volume will be added with parent sample's volume.
 * @author debasis.mondal
 *
 */
public class SpecimenPrepVolume  extends BaseAction {
    
    public void processAction(PropertyList properties) throws SapphireException {
       
        String sampleid = properties.getProperty("sampleid");
        String updateflag = properties.getProperty("updateflag");
        if("removetube".equalsIgnoreCase(updateflag)){
        	parentVolumnUpdate(sampleid);
        }else if("getback".equalsIgnoreCase(updateflag)){
        	childVolumnUpdate(sampleid);
        }
    }
    
    /**
     * Descripton : Update parent volume by adding child volume with parent volume, as child is not required.
     * @param parent
     * @throws SapphireException
     */
    private void parentVolumnUpdate(String parent) throws SapphireException {
        String sql= Util.parseMessage(FishSqls.GET_PARENTVOLUME,parent);
        DataSet dsVol=getQueryProcessor().getSqlDataSet(sql);
        if (dsVol == null) {
            String errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsVol.size() == 0) {
        	return;
        }
        String sourcesampleid=dsVol.getValue(0,"sourcesampleid","");
        Double parentqnt=dsVol.getDouble(0,"parentqnt",0);
        String destsampleid=dsVol.getValue(0,"destsampleid","");
        Double childqnt=dsVol.getDouble(0,"childqnt",0);
        
        parentqnt=parentqnt+childqnt;
        childqnt=0.0;
	        
		 PropertyList trackitem = new PropertyList();
		 trackitem.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		 trackitem.setProperty(EditTrackItem.PROPERTY_KEYID1, sourcesampleid+";"+destsampleid);
		 trackitem.setProperty("qtycurrent", String.valueOf(parentqnt)+";"+String.valueOf(childqnt));
		
		 try {
		     getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, trackitem);
		 } catch (ActionException e) {
		     throw new ActionException(e.getMessage());
		 }
		    
    }
    /**
     * Descripton : Update child volume from parent if parent is not required .
     * @param  child     * @throws SapphireException
     */
    private void childVolumnUpdate(String child) throws SapphireException {
        String sql=Util.parseMessage(FishSqls.GET_CHILDVOLUME,child);
        DataSet dsVol=getQueryProcessor().getSqlDataSet(sql);
        if (dsVol == null) {
            String errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsVol.size() == 0) {
        	return;
        }
        String sourcesampleid=dsVol.getValue(0,"sourcesampleid","");
        Double parentqnt=dsVol.getDouble(0,"parentqnt",0);
        String destsampleid=dsVol.getValue(0,"destsampleid","");
        Double childqnt=dsVol.getDouble(0,"childqnt",0);
        if(parentqnt>1){
        	childqnt=1.0;
        	parentqnt=parentqnt-childqnt;
        }else{
        	childqnt=parentqnt;
        	parentqnt=0.0;
        }
		 PropertyList trackitem = new PropertyList();
		 trackitem.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		 trackitem.setProperty(EditTrackItem.PROPERTY_KEYID1, sourcesampleid+";"+destsampleid);
		 trackitem.setProperty("qtycurrent", String.valueOf(parentqnt)+";"+String.valueOf(childqnt));
		
		 try {
		     getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, trackitem);
		 } catch (ActionException e) {
		     throw new ActionException(e.getMessage());
		 }
		    
    }
}
