package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.DeleteSDI;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
/**
 * Created by gpandi on 5/31/2017.
 * * @Desc : This action removes the sample slides from SlideDropBatch.
 * @param : batchid .fishsampleid . fishsamplebatchid
 */
public class RemoveSlideDropSamples extends BaseAction{
    public void processAction(PropertyList prop) throws SapphireException {
        String batchid = prop.getProperty("fishbatchid");
        String fishsampleid = prop.getProperty("fishsampleid");
        String fishsamplebatchid = prop.getProperty("fishbatchsampleid");
        String sqlData= Util.parseMessage(FishSqls.GET_FISHSLIDEDROP_STATUS, batchid);
        DataSet dSql= getQueryProcessor().getSqlDataSet(sqlData);
        String batchstatus=dSql.getValue(0,"batchstate");
        if("Approved".equalsIgnoreCase(batchstatus))
        {
            String err = "Cannot remove the slides from Layout as the selectd Batch was already Approved";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        else{
            deleteSlideDropSample(fishsamplebatchid);
            String sqlDelete = Util.parseMessage(FishSqls.DELETE_SAMPLE_BATCH,fishsampleid);
            database.executeUpdate(sqlDelete);
            fishSampleEdit(fishsampleid);
        }

    }
    /**
     * @Desc This method used to edit the sample and update the samplestatus
     * from input samples.
     * @param Samples
     */
    private void fishSampleEdit(String Samples) throws SapphireException{
        PropertyList sampProp = new PropertyList();
        sampProp.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        sampProp.setProperty(EditSDI.PROPERTY_KEYID1, Samples);
        sampProp.setProperty("samplestatus", "Disposed");
        sampProp.setProperty("disposalstatus", "Disposed");
        try{
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, sampProp);
        }
        catch (SapphireException se){
            String errName = getTranslationProcessor().translate("Error while Sample EditSDI" + se.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errName);
        }
    }

    /**
     * @Desc This method used to delete the samples from FISHBAtchSample SDC.
     * @param batchsample
     */
    private void deleteSlideDropSample(String batchsample) throws SapphireException{
        PropertyList slidedropProp = new PropertyList();
        slidedropProp.setProperty(DeleteSDI.PROPERTY_SDCID,"FISHBatchSample");
        slidedropProp.setProperty(DeleteSDI.PROPERTY_KEYID1, batchsample);
        try{
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, slidedropProp);
        }
        catch (SapphireException se){
            String errName = getTranslationProcessor().translate("Error while SlideDropSample DeleteSDI" + se.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errName);
        }
    }
}
