package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.*;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;

/**
 * Created by akumar on 1/5/2017.
 * This action is responsible for making centrifuge tube from a mother tube inside a batch.
 * All the fish test are assigned to the centrifuge tube which are already assigned on the
 * mother tube based on the protocol of a batch.
 */
public class CreateCentrifugeTube extends BaseAction {
    public static final String DATASET_PROPERTY_BATCHID = "batchid";
    public static final String DATASET_PROPERTY_PROTOCOL = "protocol";
    public static final String DATASET_PROPERTY_SAMPLES = "sampleid";
    private static final String DATASET_PROPERTY_CENTRIFUGETUBES = "newkeyid1";
    private String errmsg = "";

    public void processAction(PropertyList properties) throws SapphireException {
        String fishbatch = properties.getProperty(DATASET_PROPERTY_BATCHID);
        String protocol = properties.getProperty(DATASET_PROPERTY_PROTOCOL);
        String sampleid = properties.getProperty(DATASET_PROPERTY_SAMPLES);

        if (Util.isNull(fishbatch)) {
            errmsg = getTranslationProcessor().translate("No Batch is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (Util.isNull(sampleid)) {
            errmsg = getTranslationProcessor().translate("No Mother Tube is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        
        if("PET".equalsIgnoreCase(protocol)){
            String sample = sampleid.replaceAll(";", "','");
            String fishtestcode = Util.parseMessage(FishSqls.GET_TEST, sample);
            DataSet dsFishTest = getQueryProcessor().getSqlDataSet(fishtestcode);
            if (dsFishTest == null || dsFishTest.size() == 0)
            {
                errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            updateTestStatus(dsFishTest, protocol);
            associateSamplesToFishBatch(fishbatch, sampleid);
            applyAttributes(sampleid, protocol);
            properties.setProperty("centrifugeid", sampleid);
        }else{
        	DataSet sample_volds = applyVolumeProtocol(protocol,sampleid);
            String centrifugeid  = createAliquot(sample_volds);
            updateParentVolumn(protocol,sampleid,sample_volds);
            String sqlparam = centrifugeid.replaceAll(";", "','");
            String fishtestcode = Util.parseMessage(FishSqls.TESTCODE_FOR_CENTRIFUGE_TUBE_SQL, sqlparam);
            DataSet dsFishTest = getQueryProcessor().getSqlDataSet(fishtestcode);
            if (dsFishTest == null || dsFishTest.size() == 0)
            {
                errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            addFishTests(dsFishTest, protocol);
            updateTestStatus(dsFishTest, protocol);
            associateSamplesToFishBatch(fishbatch, centrifugeid);
            applyAttributes(centrifugeid, protocol);
            properties.setProperty("centrifugeid", centrifugeid);
        }
    }
   
    /**
     * This method is used to create Centrifuge Tubes for a particular Specimen.
     * To create a multiple child of each individual parent sample this loop has been written
     * @param sample_volds
     * @return
     * @throws SapphireException
     */

    private String createAliquot(DataSet sample_volds) throws SapphireException {
        StringBuffer centrifugeid = new StringBuffer();
        for (int i = 0; i < sample_volds.size(); i++) {
            PropertyList prop = new PropertyList();
            prop.setProperty(CreateChildSamples.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;concentration;u_pathologycomments");
            prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, sample_volds.getValue(i, "sampleid"));
            prop.setProperty(CreateChildSamples.PROPERTY_MODE, "Aliquot");
            prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "1");
            prop.setProperty(CreateChildSamples.PROPERTY_CHILD_QUANTITY, sample_volds.getValue(i, "childquantity"));
            prop.setProperty(CreateChildSamples.PROPERTY_CHILD_UNIT, sample_volds.getValue(i, "childunit"));
            prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");
            try {
                getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
            } catch (SapphireException se) {
                errmsg = getTranslationProcessor().translate("Centrifuge Tubes are not created.") + se.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            centrifugeid.append(";").append(prop.getProperty(DATASET_PROPERTY_CENTRIFUGETUBES));
        }
        return centrifugeid.substring(1);
    }

    /**
     * This method is used to apply the volume for a particular Specimen(Centrifuge Tube).
     *
     * @param sampleid
     */
    private DataSet applyVolumeProtocol(String protocol,String sampleid) throws SapphireException {
        String volsql = Util.parseMessage(FishSqls.GET_SAMPLE_VOLUME,protocol, sampleid.replaceAll(";", "','"));
        DataSet volds = getQueryProcessor().getSqlDataSet(volsql);
        if (volds == null) {
            errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (volds.size() == 0) {
            errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        DataSet sample_volume = new DataSet();
        sample_volume.addColumn("sampleid", DataSet.STRING);
        sample_volume.addColumn("childquantity", DataSet.STRING);
        sample_volume.addColumn("childunit", DataSet.STRING);

        sample_volume.addColumn("accession", DataSet.STRING);
        sample_volume.addColumn("clientspecimen", DataSet.STRING);
        ArrayList<DataSet> al_volds = volds.getGroupedDataSets("s_sampleid");
        for (DataSet currds : al_volds) {
            currds.sort("fishdaughtertubevol");
            int size = currds.size();
            String currsampleid = currds.getValue(size - 1, "s_sampleid", "");
            String parentvol = currds.getValue(size - 1, "qtycurrent", "0");
            String aliquotvol = currds.getValue(size - 1, "fishdaughtertubevol", "1");
            String units = currds.getValue(size - 1, "qtyunits", "ml");

            String accession = currds.getValue(size - 1, "u_accessionid", "ml");
            String clientspecimen = currds.getValue(size - 1, "u_clientspecimenid", "ml");
            if (Double.parseDouble(parentvol) < Double.parseDouble(aliquotvol)){
                aliquotvol = parentvol;
            }

            int rowId = sample_volume.addRow();
            sample_volume.setValue(rowId, "sampleid", currsampleid);
            sample_volume.setValue(rowId, "childquantity", aliquotvol);
            sample_volume.setValue(rowId, "childunit", units);

            sample_volume.setValue(rowId, "accession", accession);
            sample_volume.setValue(rowId, "clientspecimen", clientspecimen);
        }
        return sample_volume;
    }

    /**
     * This method is used to apply the Attributes to Centrifuge Tubes.
     *
     * @param centrifugeid, protocol
     * @throws SapphireException
     */
    private void applyAttributes(String centrifugeid, String protocol) throws SapphireException {

        String sqlwi = Util.parseMessage(FishSqls.GET_PROTOCOL_WORKITEM, protocol);
        DataSet dswi = getQueryProcessor().getSqlDataSet(sqlwi);
        if (dswi.size() > 0) {

            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Sample");
            propswi.setProperty("keyid1", centrifugeid);
            propswi.setProperty("applyworkitem", "Y");
            propswi.setProperty("workitemid", dswi.getValue(0, "workitemid"));
            propswi.setProperty("workitemversionid", dswi.getValue(0, "workitemversionid"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                errmsg = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
        }
    }

    /**
     * @param dsFishTest :DataSet which stores the information of mother tube ,centrifugetube ,protocol and number of fish tests assigned on it
     * @param protocol
     * @throws SapphireException
     * @desc: Assigns only the fish testcode to the centrifuge tube .
     * @desc: This method assigns the fish test on the centrifuge tubes.
     */

    private void addFishTests(DataSet dsFishTest, String protocol) throws SapphireException {
        HashMap dsprotocolfilter = new HashMap();
        dsprotocolfilter.put("fishprotocol", protocol);
        DataSet dsfilteredprotocol = dsFishTest.getFilteredDataSet(dsprotocolfilter);
        DataSet dsFishTestfinal = new DataSet();
        dsFishTestfinal.addColumn("s_sampleid", DataSet.STRING);
        dsFishTestfinal.addColumn("lvtestcode", DataSet.STRING);
        dsFishTestfinal.addColumn("ispanel", DataSet.STRING);

      /*  for (int i = 0; i < filteredds.getRowCount(); i++) {
            int rowIndex = dsFishTestfinal.addRow();
            dsFishTestfinal.setValue(rowIndex, "s_sampleid", filteredds.getValue(i, "destsampleid"));
            dsFishTestfinal.setValue(rowIndex, "lvtestcode", filteredds.getValue(i, "lvtestcodeid"));
            dsFishTestfinal.setValue(rowIndex, "ispanel", filteredds.getValue(i, "ispanel"));

        }*/
        HashMap hmpanelfilter = new HashMap();
        hmpanelfilter.put("ispanel", "Y");
        DataSet dsfilteredpanel = dsfilteredprotocol.getFilteredDataSet(hmpanelfilter);

        if (dsfilteredpanel.size() > 0) {

            ArrayList<DataSet> aldstestsamp = dsfilteredpanel.getGroupedDataSets("lvtestpanelid");
            for (DataSet currdstest : aldstestsamp) {
                ArrayList<DataSet> aldssamp = currdstest.getGroupedDataSets("s_sampleid");
                for (DataSet currdssamp : aldssamp) {
                    int rowIndex = dsFishTestfinal.addRow();
                    dsFishTestfinal.setValue(rowIndex, "s_sampleid", currdssamp.getValue(0, "destsampleid"));
                    dsFishTestfinal.setValue(rowIndex, "lvtestcode", currdssamp.getValue(0, "lvtestpanelid"));
                    dsFishTestfinal.setValue(rowIndex, "ispanel", currdssamp.getValue(0, "ispanel"));
                }
            }
        }

        hmpanelfilter.clear();
        hmpanelfilter.put("ispanel", "N");
        dsfilteredpanel.clear();
        dsfilteredpanel = dsfilteredprotocol.getFilteredDataSet(hmpanelfilter);
        if (dsfilteredpanel.size() > 0) {
            for (int i = 0; i < dsfilteredpanel.size(); i++) {
                int rowIndex = dsFishTestfinal.addRow();
                dsFishTestfinal.setValue(rowIndex, "s_sampleid", dsfilteredpanel.getValue(i, "destsampleid"));
                dsFishTestfinal.setValue(rowIndex, "lvtestcode", dsfilteredpanel.getValue(i, "lvtestcodeid"));
                dsFishTestfinal.setValue(rowIndex, "ispanel", dsfilteredpanel.getValue(i, "ispanel"));
            }
        }
        PropertyList props = new PropertyList();
        //props.setProperty("s_sampleid", dsFishTestfinal.getColumnValues("s_sampleid", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsFishTestfinal.getColumnValues("s_sampleid", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsFishTestfinal.getColumnValues("lvtestcode", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL, dsFishTestfinal.getColumnValues("ispanel", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");

        try {
            getActionProcessor().processAction("AssignTestCode", "1", props);

        } catch (SapphireException se) {
            errmsg = "Unable to add a Test on a pool Sample" + se.getMessage();
            throw new SapphireException("Unable to add a Test on a pool Sample" + se.getMessage());

        }

    }

    /**
     * @param batchid      :FishBatch ID to which the samples will be assigned
     * @param centrifugeid :DataSet    which has the information of mother tube,centrifuge tube,protocol,tests assigned on them.
     * @throws SapphireException
     * @desc :Associates the centrifuge tube in the batch which are eligible for the specified protocol of a batch.
     */
    private void associateSamplesToFishBatch(String batchid, String centrifugeid) throws SapphireException {
        PropertyList fishbatchdeatil = new PropertyList();
        fishbatchdeatil.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatchSample");
        fishbatchdeatil.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(centrifugeid.split(";").length));
        fishbatchdeatil.setProperty("batchid", batchid);
        fishbatchdeatil.setProperty("sampleid", centrifugeid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, fishbatchdeatil);
        } catch (SapphireException se) {
            errmsg = "Unable to associate samples to batch.";
            throw new SapphireException(errmsg);
        }
    }

    /**
     * @param dsFishTest
     * @param protocol
     * @throws ActionException
     */
    private void updateTestStatus(DataSet dsFishTest, String protocol) throws ActionException {
        HashMap filter = new HashMap();
        filter.put("fishprotocol", protocol);
        DataSet filteredds = dsFishTest.getFilteredDataSet(filter);
        String u_sampletestcodemapid = Util.getUniqueList(filteredds.getColumnValues("u_sampletestcodemapid", ";"), ";", true);
        PropertyList property = new PropertyList();
        property.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        property.setProperty(EditSDI.PROPERTY_KEYID1, u_sampletestcodemapid);
        property.setProperty("teststatus", "Completed");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, property);
    }

    /**
     * Description : For calculating parent sample's volume.
     * @param parentsample
     * @param childVol
     * @throws SapphireException
     */
    private void updateParentVolumn(String protocol,String parentsample,DataSet childVol) throws SapphireException {
        DataSet dsParentVol=new DataSet();
        dsParentVol.addColumn("parentsample",DataSet.STRING);
        dsParentVol.addColumn("parentvol",DataSet.NUMBER);
        String volsql = Util.parseMessage(FishSqls.GET_SAMPLE_VOLUME,protocol, parentsample.replaceAll(";", "','"));
        DataSet volds = getQueryProcessor().getSqlDataSet(volsql);
        if (volds == null) {
            errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (volds.size() == 0) {
            errmsg = getTranslationProcessor().translate("No DataSet found for the selected samples.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        HashMap<String, String> hmFilter=new HashMap<>();
        int incrVol=0;
        for(int i=0;i<volds.size();i++){
            incrVol=dsParentVol.addRow();
            String currsampleid = volds.getValue(i, "s_sampleid", "");
            hmFilter.clear();
            hmFilter.put("sampleid", currsampleid);
            DataSet dsFilter=childVol.getFilteredDataSet(hmFilter);
            String childVolume=dsFilter.getValue(0,"childquantity", "");

            String parentvol = volds.getValue(i, "qtycurrent", "0");
            Double parentVol=(Double.parseDouble(parentvol)-Double.parseDouble(childVolume));
            dsParentVol.setValue(incrVol, "parentsample", currsampleid);
            dsParentVol.setValue(incrVol, "parentvol", String.valueOf(parentVol));
        }
        PropertyList trackitem = new PropertyList();
        trackitem.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        trackitem.setProperty(EditTrackItem.PROPERTY_KEYID1, dsParentVol.getColumnValues("parentsample", ";"));
        trackitem.setProperty("qtycurrent", dsParentVol.getColumnValues("parentvol", ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, trackitem);
        } catch (ActionException e) {
            throw new ActionException(e.getMessage());
        }
    }
}
