package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by DMondal on 1/19/2017.
 */
public class CompleteBatch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid=properties.getProperty("batchid");
        String batchtype=properties.getProperty("batchtype");
        String tramstop=properties.getProperty("tramstop");
        String samples =getSamplesFromBatch(batchid);
        addFishTests(samples,tramstop,batchtype);
    }
    private String getSamplesFromBatch(String batchid ) throws SapphireException {
        String sql= Util.parseMessage(FishSqls.GET_FISHBATCHID,batchid);
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsSample.size() == 0) {
            String err = "No sample found in Batch.You can not complete the batch.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String sample=dsSample.getColumnValues("sampleid","','");
        if (Util.isNull(sample)) {
            String err = "No sample found in Batch.You can not complete the batch.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        return sample;
    }

    private void addFishTests(String samples,String tramstop,String batchtype) throws SapphireException {
        String sql=Util.parseMessage(FishSqls.GET_PARAMLISTDETAILS,samples,tramstop,batchtype);
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsSample.size() == 0) {
            String err = "Please fill attribute first.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        for(int i=0;i<dsSample.size();i++){
            String keyis=dsSample.getValue(i,"keyid1","");
            String paramid=dsSample.getValue(i,"paramid","");
            String enteredtext=dsSample.getValue(i,"enteredtext","");
            if (Util.isNull(enteredtext)) {
                String err = paramid+" can not be null for sample "+keyis+" Please fill "+paramid+" first.";
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
        }
    }
}
