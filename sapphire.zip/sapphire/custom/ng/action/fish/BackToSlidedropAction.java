package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
/*
 * This is used for send back centrifuged tube to slide drop sample list page by selecting slide from prob list page for a particular batch.
 *
 * @author debasis.mondal
 *
 */
public class BackToSlidedropAction extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
    	String samples = properties.getProperty("samples");
        backToSlidedrop(samples);
    }
    /*
     * This method is used for remove all slide from particular batch.Delete batch from FISHBatch SDC.
     */
    private void backToSlidedrop(String samples) throws SapphireException {
		String slideid = StringUtil.replaceAll(samples, ";", "','");
		String sqlSlideid = Util.parseMessage(FishSqls.GET_SLIDE_INFO, slideid);
		DataSet dsSlideInfo = getQueryProcessor().getSqlDataSet(sqlSlideid);
		if (dsSlideInfo == null) {
			String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
		}
		if (dsSlideInfo.size() == 0) {
			String errmsg = getTranslationProcessor().translate("No centrifuged tube found for selected slide.");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
		}
		String sqlBatchSampleid = Util.parseMessage(FishSqls.GET_BATCH_SAMLEID, Util.getUniqueList(dsSlideInfo.getColumnValues("u_fishbatchid", "','"), "','", true));
		DataSet dsBatchSampleid = getQueryProcessor().getSqlDataSet(sqlBatchSampleid);
		if (dsBatchSampleid == null) {
			String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
		}
		if (dsBatchSampleid.size() == 0) {
			String errmsg = getTranslationProcessor().translate("Slide is not attached with the batch.");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
		}
		PropertyList props = new PropertyList();
		props.setProperty(EditSDI.PROPERTY_SDCID, "SlideDrop");
		props.setProperty(EditSDI.PROPERTY_KEYID1,
				Util.getUniqueList(dsSlideInfo.getColumnValues("u_slidedropid", ";"), ";", true));
		props.setProperty("fishbatchid", "(null)");
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
		} catch (ActionException e) {
			e.printStackTrace();
			throw new SapphireException(ErrorDetail.TYPE_FAILURE,
					"Action failed , unable to add SDI in SlideDrop SDC.");
		}
		props.clear();
		props.setProperty(DeleteSDI.PROPERTY_SDCID, "FISHBatch");
		props.setProperty(DeleteSDI.PROPERTY_KEYID1,
				Util.getUniqueList(dsSlideInfo.getColumnValues("u_fishbatchid", ";"), ";", true));
		try {
			getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
		} catch (ActionException e) {
			e.printStackTrace();
			throw new SapphireException(ErrorDetail.TYPE_FAILURE,
					"Action failed , unable to add SDI in SlideDrop SDC.");
		}
		props.clear();
		props.setProperty(DeleteSDI.PROPERTY_SDCID, "FISHBatchSample");
		props.setProperty(DeleteSDI.PROPERTY_KEYID1,
				Util.getUniqueList(dsBatchSampleid.getColumnValues("u_fishbatchsampleid", ";"), ";", true));
		try {
			getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
		} catch (ActionException e) {
			e.printStackTrace();
			throw new SapphireException(ErrorDetail.TYPE_FAILURE,
					"Action failed , unable to add SDI in SlideDrop SDC.");
		}

		props.clear();
		props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		props.setProperty(EditSDI.PROPERTY_KEYID1,
				Util.getUniqueList(dsSlideInfo.getColumnValues("slideid", ";"), ";", true));
		props.setProperty("u_currentmovementstep", StringUtil.repeat("(null)",
				Util.getUniqueList(dsSlideInfo.getColumnValues("slideid", ";"), ";", true).split(";").length,
				";"));
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
		} catch (SapphireException e) {
			String error = getTranslationProcessor().translate("Can't update movement step in specimen");
			error += e.getMessage();
			throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
		}
		props.clear();
		props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		props.setProperty(EditTrackItem.PROPERTY_KEYID1,
				Util.getUniqueList(dsSlideInfo.getColumnValues("slideid", ";"), ";", true));
		props.setProperty("u_currenttramstop", StringUtil.repeat("(null)",
				Util.getUniqueList(dsSlideInfo.getColumnValues("slideid", ";"), ";", true).split(";").length,
				";"));
		props.setProperty("custodialuserid", StringUtil.repeat("(null)",
				Util.getUniqueList(dsSlideInfo.getColumnValues("slideid", ";"), ";", true).split(";").length,
				";"));
		props.setProperty("custodialdepartmentid", StringUtil.repeat("(null)",
				Util.getUniqueList(dsSlideInfo.getColumnValues("slideid", ";"), ";", true).split(";").length,
				";"));
		try {
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
		} catch (SapphireException e) {
			String error = getTranslationProcessor().translate("Can't update movement step in specimen");
			error += e.getMessage();
			throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
		}
	}
}