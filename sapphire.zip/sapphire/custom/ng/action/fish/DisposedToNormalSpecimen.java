package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * This is used for get normal specimen from Disposed specimen
 * 
 * @author debasis.mondal
 *
 */
public class DisposedToNormalSpecimen extends BaseAction {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleids = properties.getProperty("sampleid");
		if (Util.isNull(sampleids)) {
			throw new SapphireException("No specimen(s) are provided.");
		}
		DataSet ds = getDataSet(sampleids);
		updateSampleSdc(ds);
	}

	/**
	 * For create main dataset
	 * @param sampleids
	 * @return
	 * @throws SapphireException
	 */
	private DataSet getDataSet(String sampleids) throws SapphireException {
		String sqlSample = Util.parseMessage(FishSqls.GET_DISPOSED_SAMPLE,sampleids.replaceAll(";", "','"));
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
        if (dsSample == null) {
           String errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsSample.size() == 0) {
           String errmsg = getTranslationProcessor().translate("Please select disposed specimen only.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
		DataSet ds = new DataSet();
		ds.addColumn("sample", DataSet.STRING);
		ds.addColumn("storagedisposalstatus", DataSet.STRING);
		ds.addColumn("disposalstatus", DataSet.STRING); 
		ds.addColumn("samplestatus", DataSet.STRING);
		int incr = 0;
		String disposedSamples="";
		for (int i = 0; i < dsSample.size(); i++) {
			if("Disposed".equalsIgnoreCase(dsSample.getValue(i, "disposalstatus",""))){
				incr = ds.addRow();
				ds.setValue(incr, "sample", dsSample.getValue(i, "s_sampleid",""));
				ds.setValue(incr, "storagedisposalstatus", "");
				ds.setValue(incr, "disposalstatus", "");
				ds.setValue(incr, "samplestatus", "Received");
			}else{
				disposedSamples=disposedSamples+";"+dsSample.getValue(i, "s_sampleid","");
			}
		}
		if(disposedSamples.length()>1){
			String errmsg = getTranslationProcessor().translate(disposedSamples.substring(1)+" this is not Disposed specimen.Please select disposed specimen only.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
		}
		return ds;
	}

	/**
	 * Description : This is for update track item
	 * @param ds
	 * @throws SapphireException
	 */
	private void updateSampleSdc(DataSet ds) throws SapphireException {
		try {
			PropertyList props = new PropertyList();
			props.clear();
			props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
			props.setProperty("samplestatus", ds.getColumnValues("samplestatus", ";"));
			props.setProperty("storagedisposalstatus", ds.getColumnValues("storagedisposalstatus", ";"));
			props.setProperty("disposalstatus", ds.getColumnValues("disposalstatus", ";"));
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
		} catch (SapphireException e) {
			String error = getTranslationProcessor().translate("Error in update trackitem.");
			error += e.getMessage();
			throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
		}
	}
}
