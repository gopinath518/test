package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.custom.ng.sql.fish.FishSqls;

/**
* Created by gpandi on 03/12/2018.
*
* @Desc This action is used to add testCode for Parent Samples in FishCheckInQC.
* Mandatory Input.
* s_sampleid (sampleid)
*/
public class FishAddTestCode extends BaseAction {
    private String errmsg = "";
    private DataSet dsSamples = null;

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String testcode = properties.getProperty("testcodeid");
        String ispanel = properties.getProperty("panel");
        String operation = properties.getProperty("operation");

        if (Util.isNull(sampleid)) {
            errmsg = getTranslationProcessor().translate("No Specimen found");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (Util.isNull(testcode)) {
            errmsg = getTranslationProcessor().translate("No Testcode is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        if("FFPE".equalsIgnoreCase(operation)) {
            String sql = Util.parseMessage(FishSqls.GET_ROOTSAMPLE,sampleid);
            DataSet dsRootSample = getQueryProcessor().getSqlDataSet(sql);
            if(dsRootSample==null && dsRootSample.size()==0){
                String errmsg = getTranslationProcessor().translate("Root Specimen not found");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            String rootSample = dsRootSample.getColumnValues("u_rootsample", ";");
            deleteTestcodes(rootSample);
            populateDataSet(rootSample, testcode, ispanel);
            addTestCodeToRoot(dsSamples, rootSample);
            modifyTestsforChildSamples(dsSamples,rootSample);
        }
        else if("NonFFPE".equalsIgnoreCase(operation)){
           // deleteTestcodes(sampleid);
            populateDataSet(sampleid, testcode, ispanel);
            addTestCodeToRoot(dsSamples, sampleid);
        }
    }

    /**
     * This method is used to delete the rows from SampleTestCodeMap which are not needed or blank.
     * <p>
     * param sampleid
     * throws SapphireException
     */
    private void deleteTestcodes(String sampleid) throws SapphireException {
        String sql = Util.parseMessage(FishSqls.GET_KEYID1_DELETE_TESTS, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsSampleTestCodeMap = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleTestCodeMap == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsSampleTestCodeMap.size() == 0) {
            return;
        }

        String allKeyid1SampleTestcodeMap = dsSampleTestCodeMap.getColumnValues("u_sampletestcodemapid", ";");
        PropertyList props = new PropertyList();
        props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        props.setProperty(DeleteSDI.PROPERTY_KEYID1, allKeyid1SampleTestcodeMap);
        try {
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
        } catch (Exception ex) {
            String err = "Can not delete  tests :" + ex.getMessage();
            throw new SapphireException(err);
        }

    }

    /**
     * This method is used for populate the dataset.
     * <p>
     * param sampleid,testcode
     * throws SapphireException
     */

    private void populateDataSet(String sampleid, String testcode, String panel) throws SapphireException {

        if (dsSamples == null) {
            dsSamples = new DataSet();
            dsSamples.addColumn("sampleid", DataSet.STRING);
            dsSamples.addColumn("lvtestcode", DataSet.STRING);
            dsSamples.addColumn("ispanel", DataSet.STRING);
        }
        String testcodeArr[] = StringUtil.split(testcode, ";");
        String panelArr[] = StringUtil.split(panel, ";");

        int rowID = 0;
        for (int i = 0; i < testcodeArr.length; i++) {
            rowID = dsSamples.addRow();
            dsSamples.setValue(rowID, "sampleid", sampleid);
            dsSamples.setValue(rowID, "lvtestcode", testcodeArr[i]);
            dsSamples.setValue(rowID, "ispanel", panelArr[i]);
        }
    }
    /**
     * This method is used to add testcode for Root Sample in FISHCheckInQC.
     * <p>
     * param dsFinal
     * throws SapphireException
     */
    private void addTestCodeToRoot(DataSet dsFinal,String rootsampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsFinal.getColumnValues("sampleid", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsFinal.getColumnValues("lvtestcode", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL, dsFinal.getColumnValues("ispanel", ";"));

        try {
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);

        } catch (SapphireException se) {
            throw new SapphireException("Unable to add a Test on a pool Sample" + se.getMessage());
        }
    }

    // TODO test name blank out for all the child samples and populate the panel id if assigning the panel.//
    /**
     * This method is used to blank out for all the child samples and populate the panel id if assigning the panel.
     * <p>
     * param dssample
     * throws SapphireException
     */
    private void modifyTestsforChildSamples(DataSet dsSample,String rootsampleid) throws SapphireException{
        String sql=Util.parseMessage(FishSqls.GET_CHILDSAMPLE_ROOT, rootsampleid);
        DataSet dsChildSamTestmap = getQueryProcessor().getSqlDataSet(sql);
        if (dsChildSamTestmap == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        String delSampleKeyid = dsChildSamTestmap.getColumnValues("u_sampletestcodemapid", ";");
        String addedPanel = dsSample.getValue(0,"lvtestcode","");
        String isPanel = dsSample.getValue(0,"ispanel","");

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, delSampleKeyid);
        pl.setProperty("lvtestcodeid", StringUtil.repeat("",dsChildSamTestmap.getRowCount(),";"));
        if("Y".equalsIgnoreCase(isPanel)){
            pl.setProperty("lvtestpanelid", StringUtil.repeat(addedPanel,dsChildSamTestmap.getRowCount(),";"));
        }
        else{
            pl.setProperty("lvtestpanelid", StringUtil.repeat("",dsChildSamTestmap.getRowCount(),";"));
        }
        pl.setProperty("testname", StringUtil.repeat("",dsChildSamTestmap.getRowCount(),";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (Exception ex) {
            String err = "Can not delete tests :" + ex.getMessage();
            throw new SapphireException(err);
        }
    }
}