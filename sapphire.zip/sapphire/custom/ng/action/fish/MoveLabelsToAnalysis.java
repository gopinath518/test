package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * This is used for Labels moves to Analysis.
 * 
 * @author debasis.mondal
 *
 */
public class MoveLabelsToAnalysis extends BaseAction {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleids = properties.getProperty("sampleid");
		if (Util.isNull(sampleids)) {
			throw new SapphireException("Specimen(s) are not correctly assigned.");
		}
		String currentmovementstep = properties.getProperty("u_currentmovementstep");
		if (Util.isNull(currentmovementstep)) {
			throw new SapphireException("currentmovementstep(s) are not correctly assigned.");
		}
		String noTestcodeSamples = Util.parseMessage(FishSqls.GET_SAMPLES_TESTCODE_NULL, StringUtil.replaceAll(sampleids,";","','"));
		DataSet dsTestcodeSamples = getQueryProcessor().getSqlDataSet(noTestcodeSamples);
		String errorSampleid=dsTestcodeSamples.getColumnValues("s_sampleid",",");
		if(!"".equalsIgnoreCase(errorSampleid)){
			throw new SapphireException(""+errorSampleid+"  Specimen doesn't have any testcode. please assign some test to specimen.");
		}
		DataSet ds = getDataSet(sampleids,currentmovementstep);
		updateTrackItemSdc(ds);
	}

	/**
	 * For create main dataset
	 * @param sampleids
	 * @return
	 * @throws SapphireException
	 */
	private DataSet getDataSet(String sampleids,String currentmovementstep) throws SapphireException {
		String sqlSample = Util.parseMessage(FishSqls.GET_LABLE_SAMPLE,sampleids.replaceAll(";", "','"));
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
        if (dsSample == null) {
           String errmsg = getTranslationProcessor().translate("Query failed .Contact Administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsSample.size() == 0) {
           String errmsg = getTranslationProcessor().translate("This functionality is valid for physical slide(s).");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
		DataSet ds = new DataSet();
		ds.addColumn("sample", DataSet.STRING);
		ds.addColumn("currentmovementstep", DataSet.STRING);
		ds.addColumn("destination", DataSet.STRING);
		int incr = 0;
		for (int i = 0; i < dsSample.size(); i++) {
			incr = ds.addRow();
			ds.setValue(incr, "sample", dsSample.getValue(i, "s_sampleid",""));
			ds.setValue(incr, "currentmovementstep", currentmovementstep);
			ds.setValue(incr, "destination", "FISH");
		}
		return ds;
	}

	/**
	 * Description : This is for update track item
	 * @param ds
	 * @throws SapphireException
	 */
	private void updateTrackItemSdc(DataSet ds) throws SapphireException {

		String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
		String site = department.substring(0, department.lastIndexOf('-'));
		for (int i = 0; i < ds.size(); i++) {
			String tramstop = ds.getValue(i, "destination", "");
			String destination = site + "-" + tramstop;
			if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor()))
				throw new SapphireException(
						"Error: Unable to route specimen. Department: " + destination + " does not exist");
			ds.setValue(i, "destination", destination);
		}

		try {
			PropertyList props = new PropertyList();
			props.clear();
			props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
			props.setProperty("u_currentmovementstep", ds.getColumnValues("currentmovementstep", ";"));
			props.setProperty("u_analysisstartdate", StringUtil.repeat("n",ds.size(),";"));
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
			props.clear();
			props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
			props.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("sample", ";"));
			props.setProperty("u_currenttramstop", ds.getColumnValues("currentmovementstep", ";"));
			props.setProperty("custodialuserid", "(null)");
			props.setProperty("custodialdepartmentid", ds.getColumnValues("destination", ";"));
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
		} catch (SapphireException e) {
			String error = getTranslationProcessor().translate("Error in update trackitem.");
			error += e.getMessage();
			throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
		}
	}
}
