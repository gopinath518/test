package sapphire.custom.ng.action.fish;

import com.labvantage.sapphire.actions.sdi.AddSDI;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FISHAnalysisPerform extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid", "");
        String methodology = properties.getProperty("methodology", "");
        String los = properties.getProperty("los", "");
        String sampleids = properties.getProperty("sampleids", "");
        String reporttype = properties.getProperty("reporttype", "");
        if (!Util.isNull(sampleids)) {
            sampleids = Util.getUniqueList(sampleids, ",", true);
            sampleids = StringUtil.replaceAll(sampleids, ",", "','");
        }
        String rootsample = "", reportoptionid = "";
        String sql = Util.parseMessage(FishSqls.GET_SAMPLE_BY_SAMPLEID, sampleids);
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleInfo.size() > 0) {
            rootsample = dsSampleInfo.getColumnValues("u_rootsample", "#");
            rootsample=Util.getUniqueList(rootsample, "#", true);
        }
        String sqlReportOptionid="";
        if("Individual".equalsIgnoreCase(reporttype)){
        	sqlReportOptionid= Util.parseMessage(FishSqls.GET_REPORTOPTNID_INDIVIDUAL, accessionid, methodology, los, rootsample, StringUtil.replaceAll(sampleids, "','", "#"), reporttype);
        }else{
        	sqlReportOptionid = Util.parseMessage(FishSqls.GET_REPORTOPTNID_CONSOLIDATE, accessionid, methodology, los, rootsample, reporttype);
        }
        DataSet dsReportOption = getQueryProcessor().getSqlDataSet(sqlReportOptionid);
        if (dsReportOption.size() == 0) {
            PropertyList props = new PropertyList();
            props.setProperty(AddSDI.PROPERTY_SDCID, "ReportOption");
            props.setProperty(AddSDI.PROPERTY_COPIES, "1");
            props.setProperty("accessionid", accessionid);
            props.setProperty("methodologyid", methodology);
            props.setProperty("los", los);
            props.setProperty("rootsampleid", rootsample);
            props.setProperty("leafsampleid", StringUtil.replaceAll(sampleids, "','", "#"));
            props.setProperty("reporttype", reporttype);
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to create Report Option" + ex.getMessage());
            }
            reportoptionid = props.getProperty("newkeyid1");
        }
        if (dsReportOption.size() > 0) {
            reportoptionid = dsReportOption.getValue(0, "u_reportoptionid", "");
        }
        properties.setProperty("reportoptionid", reportoptionid);
    }
}
