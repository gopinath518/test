package sapphire.custom.ng.action.fish;

import java.util.Calendar;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class SlideDropBatchCreation extends BaseAction {
    public static final String PROPERTY_BATCHTYPE = "batchtype";
    private static final String STATUS = "Open";
    private static final String NEWKEYID1 = "newkeyid1";
    private static final String BATCHSEQ = "%06d";

    public void processAction(PropertyList properties) throws SapphireException {
        String batchtype = properties.getProperty(PROPERTY_BATCHTYPE);
        if (Util.isNull(batchtype)) {
            throw new SapphireException(TYPE_VALIDATION, "Input properties is null.");
        }
        String newbatchid = createBatch(batchtype);
        // String outScript="<script>sapphire.page.navigate" +
        //       "('rc?command=page&page=SlideDropSampleImportList&mode=List&sdcid=Sample&newbatchid="+newbatchid+"')</script>";
        properties.setProperty("outscript", newbatchid);
    }

    /**
     * @param batchtype
     * @return
     * @throws SapphireException
     */
    private String createBatch(String batchtype) throws SapphireException {
        String newbatchid = "";
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = dept.substring(0, dept.lastIndexOf('-'));
        String sqlloc = Util.parseMessage(FishSqls.GET_LOCATION_OFUSER, dept);
        DataSet dsloc = getQueryProcessor().getSqlDataSet(sqlloc);
        String batchlocation = dsloc.getValue(0, "u_site");
        String sql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, site + "-%-" + batchtype);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String batchname = createBatchName(ds, batchtype, site);
        if (batchname.length() > 0) {
            String checksql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, batchname);
            DataSet dscheck = getQueryProcessor().getSqlDataSet(checksql);
            try {
                if (dscheck.size() > 0)
                    throw new SapphireException("Duplicate BatchName Present in Batch Table");
                else {
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatch");
                    props.setProperty("batchname", batchname);
                    props.setProperty("batchtype", batchtype);
                    props.setProperty("batchlocation", batchlocation);
                    props.setProperty("batchstate", STATUS);
                    props.setProperty("batchmovestatus", "slidedrop");
                    props.setProperty("origin", "slidedrop");
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                    //newbatchid = props.getProperty(NEWKEYID1, "");
                }
            } catch (Exception e) {
                String error = getTranslationProcessor().translate("Could not create new Batch: " + e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
        //return newbatchid;
        return batchname;
    }

    /**
     * @param ds
     * @param type
     * @param site
     * @return
     * @throws SapphireException
     * @Desc This function creates Unique identifier for batch based upon
     * protocol type and site.
     */
    private String createBatchName(DataSet ds, String type, String site) throws SapphireException {
        Integer max = Integer.MIN_VALUE;
        String CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String batchname = "";
        if (ds.size() == 0) {
            batchname = site + "-" + CURRENT_YEAR + "-" + "0000001" + "-" + type;
        } else {
            for (int i = 0; i < ds.size(); i++) {
                String querybatch = ds.getValue(i, "batchname");
                String value = querybatch.substring(querybatch.indexOf('-') + 6, querybatch.lastIndexOf('-'));
                int batchnm = Integer.parseInt(value);
                if (batchnm > max) {
                    max = batchnm;
                }
            }
            max++;
            int maxlength = max.toString().length();
            if (maxlength > 6)
                throw new SapphireException("Maximum limit of Batch sequence is exceed.New batch could not created.Please contact to Administrator");
            String seq = String.format(BATCHSEQ, max);
            batchname = site + "-" + CURRENT_YEAR + "-" + seq + "-" + type;
        }
        return batchname;
    }
}