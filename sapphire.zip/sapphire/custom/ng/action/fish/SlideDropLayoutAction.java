package sapphire.custom.ng.action.fish;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.DeleteSDIWorkItem;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Used for updating data into database based on function call.This will be used
 * for addSlides,removeSlides,addDrop,removeDrop,addTest,removeTest
 *
 * @author debasis.mondal
 */
public class SlideDropLayoutAction extends BaseAction {
    public static final String PROPERTY_EVENTNAME = "eventname";
    private static final String PROPERTY_CENTRIFUGETUBEID = "centrifugetubeid";
    private static final String PROPERTY_LAYOUTID = "layoutid";
    private static final String PROPERTY_ROWPOS = "rowpos";
    private static final String PROPERTY_TESTCODEID = "testcode";
    private static final String SLIDEID = "slideid";
    private static final String DROPID = "dropid";
    private static final String PROPERTY_DROP_SAMPLE = "dropsampleid";
    private static final String COPYDOWNCOLUMNS = "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;concentration;u_pathologycomments";
    private static final String BATCHSEQ = "%06d";
    private static final String STATUS = "Open";
    private static final String NEWKEYID1 = "newkeyid1";
    private static final String BATCH_TYPE = "batchtype";
    private static final String BATCH_NAME = "batchname";
    private static final String PROPERTY_PARENTSAMPLE = "parentsampleid";
    private static final String PROPERTY_NOOFDROP = "noofdrop";
    private static final String PROPERTY_NOOFSLIDES = "noofslides";
    private static final String PROPERTY_QNSTEST="qnstest";
    private static final String MODE="mode";
    private static final String BATCHID="batchid";

    public void processAction(PropertyList properties) throws SapphireException {
        String eventname = properties.getProperty(PROPERTY_EVENTNAME);
        if (Util.isNull(eventname)) {
            throw new SapphireException(TYPE_VALIDATION, "Eventname input properties is null.");
        }
        if ("addSlides".equalsIgnoreCase(eventname)) {
            addSlides(properties);
        }
        if ("removeSlides".equalsIgnoreCase(eventname)) {
            removeSlides(properties);
        }
        if ("addDrop".equalsIgnoreCase(eventname)) {
            addDrop(properties);
        }
        if ("removeDrop".equalsIgnoreCase(eventname)) {
            removeDrop(properties);
        }
        if ("addTest".equalsIgnoreCase(eventname)) {
            addTest(properties);
        }
        if ("removeTest".equalsIgnoreCase(eventname)) {
            String s_sampleid = properties.getProperty(PROPERTY_DROP_SAMPLE, "");
            if (Util.isNull(s_sampleid)) {
                String err = getTranslationProcessor().translate("Drop sample can't be null.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
            String lvtestorpanelid = properties.getProperty(PROPERTY_TESTCODEID, "");
            if (Util.isNull(lvtestorpanelid)) {
                String err = getTranslationProcessor().translate(" lvtestid/lvpanelid can't be null.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
            initializeDataSet();
            DataSet dsSampleDetails = getSampleDetails(s_sampleid, lvtestorpanelid);
            addDataToDsMain(dsSampleDetails);
            removeTest();
        }
        if ("createBatchName".equalsIgnoreCase(eventname)) {
            createBatchName(properties);
        }
        if ("createBatch".equalsIgnoreCase(eventname)) {
        	if(Util.isNull(properties.getProperty("forcebatchreason", ""))){
	            //checkSlideReviewed(properties);
        		String slide=allowIfAllTestQNS(properties);
        		if(!Util.isNull(slide)){
        			String errMsg = getTranslationProcessor()
                            .translate("Please validate slides/Check QNS before create batch. " + slide + " is/are not validated yet.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
	            qnsTestValidation(properties);
	            String batchid = createBatch(properties);
	            String slideid=getSlide(properties);
	            addSlidesToBatch(batchid, slideid);
	            editSlideDrop(batchid, slideid);
        	}else{
        		allowIfAllTestQNS(properties);
        		String batchid = createBatch(properties);
        		String slideid=getSlideForForcedBatch(properties);
	            addSlidesToBatch(batchid, slideid);
	            editSlideDrop(batchid, slideid);
        	}
        }
        if ("reviewSlide".equalsIgnoreCase(eventname)) {
            reviewSlide(properties);
        }
        if ("checkUncheckQNS".equalsIgnoreCase(eventname)) {
        	checkUncheckQNS(properties);
        }
        if("editComplete".equalsIgnoreCase(eventname)){
        	editComplete(properties);
        }
    }

    /**
     * Used for add Slide
     *
     * @param properties
     * @throws SapphireException
     */
    private void addSlides(PropertyList properties) throws SapphireException {
        String s_sampleid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID, "");
        if (Util.isNull(s_sampleid)) {
            String err = getTranslationProcessor().translate("Parent sample can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String noofdrop = properties.getProperty(PROPERTY_NOOFDROP, "");
        if (Util.isNull(noofdrop)) {
            String err = getTranslationProcessor().translate("No of drop can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String noofslide = properties.getProperty(PROPERTY_NOOFSLIDES, "");
        if (Util.isNull(noofslide)) {
            String err = getTranslationProcessor().translate("No of slide can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        String rowpos = properties.getProperty(PROPERTY_ROWPOS, "");
        if (Util.isNull(rowpos)) {
            String err = getTranslationProcessor().translate("Position can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if ("2".equalsIgnoreCase(noofdrop)) {
            rowpos = "1;2";
        }
        // For Slide add
        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, COPYDOWNCOLUMNS);
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, s_sampleid);
        prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, noofslide);
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException se) {
            String errmsg = getTranslationProcessor().translate("Unable to create slide.") + se.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        String slide = prop.getProperty("newkeyid1");
        String[] slideArr = StringUtil.split(slide, ";");

        prop.clear();
        // For Drop Add
        String allSlide = "";
        String drop = "";
        for (String slideid : slideArr) {
            prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, COPYDOWNCOLUMNS);
            prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, slideid);
            prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
            prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, noofdrop);
            prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
            try {
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
            } catch (SapphireException se) {
                String errmsg = getTranslationProcessor().translate("Unable to create slide.") + se.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
            }
            String dropPerSlide = prop.getProperty("newkeyid1");
            drop = drop + ";" + dropPerSlide;
            String repeatSlide = StringUtil.repeat(slideid, Integer.parseInt(noofdrop), ";");
            allSlide = allSlide + ";" + repeatSlide;
        }
        if (allSlide.startsWith(";")) {
            allSlide = allSlide.substring(1);
        }
        if (drop.startsWith(";")) {
            drop = drop.substring(1);
        }
        String[] dropArr = StringUtil.split(drop, ";");

        prop.clear();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "SlideDrop");
        prop.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dropArr.length));
        prop.setProperty("parentsampleid", properties.getProperty(PROPERTY_CENTRIFUGETUBEID));
        prop.setProperty("childsampleid", drop);
        prop.setProperty("slideid", allSlide);
        if ("2".equalsIgnoreCase(noofdrop)) {
            prop.setProperty("rowpos", StringUtil.repeat(rowpos, slideArr.length, ";"));
        } else {
            prop.setProperty("rowpos", StringUtil.repeat(rowpos, dropArr.length, ";"));
        }

        prop.setProperty("columnpos", StringUtil.repeat("1", dropArr.length, ";"));
        String mode = properties.getProperty(MODE, "");
        if("edit".equalsIgnoreCase(mode)){
        	String batchid = properties.getProperty(BATCHID, "");
        	if (Util.isNull(batchid)) {
                String err = getTranslationProcessor().translate("Batch ID id null.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
        	prop.setProperty("fishbatchid", StringUtil.repeat(batchid, dropArr.length, ";"));
        }
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
            throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
        }
    }

    /**
     * Used for remove slide
     *
     * @param properties
     * @throws SapphireException
     */
    private void removeSlides(PropertyList properties) throws SapphireException {
        if (Util.isNull(properties.getProperty(PROPERTY_LAYOUTID))) {
            String errmsg = getTranslationProcessor().translate("Slide Id can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        String sqlDropId = Util.parseMessage(FishSqls.GET_DROPID, properties.getProperty(PROPERTY_LAYOUTID));
        DataSet dsDropId = getQueryProcessor().getSqlDataSet(sqlDropId);
        if (dsDropId == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        PropertyList prop = new PropertyList();
        if (dsDropId.size() > 0) {
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "SlideDrop");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, dsDropId.getColumnValues("u_slidedropid", ";"));
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
            } catch (ActionException e) {
                e.printStackTrace();
                throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
            }
        }
        // get test info of drop to delete
        String sqlSampleDetails = Util.parseMessage(FishSqls.GET_SAMPLE_DETAILS,
                StringUtil.replaceAll(dsDropId.getColumnValues("childsampleid", ";"), ";", "','"));
        DataSet dssqlSampleDetails = getQueryProcessor().getSqlDataSet(sqlSampleDetails);
        if (dssqlSampleDetails == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dssqlSampleDetails.size() > 0) {
            initializeDataSet();
            addDataToDsMain(dssqlSampleDetails);
            removeTest();
        }
        // delete from from sample slide id and drop ip
        String slideIdDropId = "";
        if (dsDropId.getColumnValues("childsampleid", ";").length() > 1) {
            slideIdDropId = properties.getProperty(PROPERTY_LAYOUTID) + ";"
                    + dsDropId.getColumnValues("childsampleid", ";");
        } else {
            slideIdDropId = properties.getProperty(PROPERTY_LAYOUTID);
        }
        try {
            prop.clear();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, slideIdDropId);
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from Sample.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * Used for add drop in a slide
     *
     * @param properties
     * @throws SapphireException
     */
    private void addDrop(PropertyList properties) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, COPYDOWNCOLUMNS);
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, properties.getProperty(SLIDEID));
        prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException se) {
            String errmsg = getTranslationProcessor().translate("Unable to create slide.") + se.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        String drop = prop.getProperty("newkeyid1");

        prop.clear();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "SlideDrop");
        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
        prop.setProperty("parentsampleid", properties.getProperty(PROPERTY_CENTRIFUGETUBEID));
        prop.setProperty("childsampleid", drop);
        prop.setProperty("slideid", properties.getProperty(SLIDEID));
        String row = properties.getProperty(PROPERTY_ROWPOS);
        if (Util.isNull(row)) {
            row = "1";
        }
        prop.setProperty("rowpos", row);
        prop.setProperty("columnpos", "1");
        String mode = properties.getProperty(MODE, "");
        if("edit".equalsIgnoreCase(mode)){
        	String batchid = properties.getProperty(BATCHID, "");
        	if (Util.isNull(batchid)) {
                String err = getTranslationProcessor().translate("Batch ID id null.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
        	prop.setProperty("fishbatchid", batchid);
        }
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
            throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
        }
    }

    /**
     * Used for remove drop from Slide drop SDC
     *
     * @param properties
     * @throws SapphireException
     */
    private void removeDrop(PropertyList properties) throws SapphireException {
        String sqlDropSample = Util.parseMessage(FishSqls.GET_DROP_SAMPLE, properties.getProperty(DROPID));
        DataSet dsDropSample = getQueryProcessor().getSqlDataSet(sqlDropSample);
        if (dsDropSample == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsDropSample.size() == 0) {
            String errmsg = getTranslationProcessor().translate("Drop sample Id can't be blank.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        // Set dropstatus=Drop Deleted and childsampleid is blank in slidedrop
        // sdc
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "SlideDrop");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, properties.getProperty(DROPID));
        prop.setProperty("dropstatus", "Drop Deleted");
        prop.setProperty("childsampleid", "(null)");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
            throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
        }
        // get test info of drop to delete
        String sqlSampleDetails = Util.parseMessage(FishSqls.GET_SAMPLE_DETAILS,
                dsDropSample.getValue(0, "childsampleid"));
        DataSet dssqlSampleDetails = getQueryProcessor().getSqlDataSet(sqlSampleDetails);
        if (dssqlSampleDetails == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dssqlSampleDetails.size() > 0) {
            initializeDataSet();
            addDataToDsMain(dssqlSampleDetails);
            removeTest();
        }
        // delete from from sample
        try {
            prop.clear();
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, dsDropSample.getValue(0, "childsampleid"));
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from SampleTestCodeMap.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * Used for adding test to the drop
     *
     * @param properties
     * @throws SapphireException
     */
    private void addTest(PropertyList properties) throws SapphireException {
        String sqlDropSample = Util.parseMessage(FishSqls.GET_DROP_SAMPLE, properties.getProperty(DROPID));
        DataSet dsDropSample = getQueryProcessor().getSqlDataSet(sqlDropSample);
        if (dsDropSample == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsDropSample.size() == 0) {
            String errmsg = getTranslationProcessor().translate("Drop sample Id can't be blank.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsDropSample.getColumnValues("childsampleid", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, properties.getProperty(PROPERTY_TESTCODEID));
        // props.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL,
        // dsproperties.getColumnValues(PROPERTY_ISPANEL, ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
        props.setProperty(AssignTestCode.INPUT_PROPERTY_APPLY_WI, "Y");

        try {
            getActionProcessor().processAction("AssignTestCode", "1", props);

        } catch (SapphireException se) {
            throw new SapphireException("Unable to add a Test on a pool Sample" + se.getMessage());

        }

        PropertyList property = new PropertyList();
        property.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        property.setProperty(EditSDI.PROPERTY_KEYID1, props.getProperty("sampletestcodemapid"));
        property.setProperty("dropid", properties.getProperty(DROPID));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, property);
        } catch (ActionException e) {
            e.printStackTrace();

        }
    }

    /**
     * Used for removing test from drop
     *
     * @throws SapphireException
     */
    public void removeTest() throws SapphireException {

        PropertyList props = new PropertyList();
        try {
            props.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1,
                    dsRemoveTest.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID,
                    dsRemoveTest.getColumnValues(DATASET_PROPERTY_WORKITEMID, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE,
                    dsRemoveTest.getColumnValues(DATASET_PROPERTY_WORKITEMINSTANCE, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES,
                    StringUtil.repeat("Y", dsRemoveTest.size(), ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, StringUtil.repeat("Y", dsRemoveTest.size(), ";"));
            getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor()
                    .translate("Error occurred: Can't delete from SDIWorkItem and related tables.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
        props.clear();
        try {
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1,
                    dsRemoveTest.getColumnValues(DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, ";"));
            props.setProperty("lvtestcodeid", dsRemoveTest.getColumnValues(DATASET_PROPERTY_LVTESTCODEID, ";"));
            props.setProperty("lvtestpanelid", dsRemoveTest.getColumnValues(DATASET_PROPERTY_LVTESTPANELID, ";"));
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from SampleTestCodeMap.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * This method will search all required information related to the given
     * sampleid and testcode id.
     *
     * @param s_sampleid
     * @param lvtestorpanelid
     * @throws SapphireException
     */
    private DataSet getSampleDetails(String s_sampleid, String lvtestorpanelid) throws SapphireException {
        String sqlSampleDetails = Util.parseMessage(FishSqls.GET_SAMPLETEST_DETAILS, s_sampleid, lvtestorpanelid,
                lvtestorpanelid);
        DataSet dssqlSampleDetails = getQueryProcessor().getSqlDataSet(sqlSampleDetails);
        if (dssqlSampleDetails == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dssqlSampleDetails.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Detail can't be null.");
            errMsg += "\nQuery retuns no rows:" + sqlSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        return dssqlSampleDetails;
    }

    /**
     * Description : This method is used for setting all searched data to the
     * main dataset and if found null data it will throw an exception with
     * proper message.
     *
     * @param dsSamples
     * @throws SapphireException
     */
    private void addDataToDsMain(DataSet dsSamples) throws SapphireException {
        int rowInc = 0;
        for (int i = 0; i < dsSamples.size(); i++) {
            rowInc = dsRemoveTest.addRow();
            dsRemoveTest.setValue(rowInc, DATASET_PROPERTY_SAMPLE_ID, dsSamples.getValue(i, "s_sampleid", ""));
            dsRemoveTest.setValue(rowInc, DATASET_PROPERTY_WORKITEMID, dsSamples.getValue(i, "workitemid", ""));
            dsRemoveTest.setValue(rowInc, DATASET_PROPERTY_WORKITEMINSTANCE,
                    dsSamples.getValue(i, "workiteminstance", ""));
            dsRemoveTest.setValue(rowInc, DATASET_PROPERTY_LVTESTPANELID, dsSamples.getValue(i, "lvtestpanelid", ""));
            dsRemoveTest.setValue(rowInc, DATASET_PROPERTY_LVTESTCODEID, dsSamples.getValue(i, "lvtestcodeid", ""));
            dsRemoveTest.setValue(rowInc, DATASET_PROPERTY_SAMPLETESTCODEMAP_ID,
                    dsSamples.getValue(i, "u_sampletestcodemapid", ""));
        }
    }

    /**
     * Used for creating batch based on given input batchtype and batchname
     *
     * @param batchtype
     * @return
     * @throws SapphireException
     */
    private String createBatch(PropertyList properties) throws SapphireException {
        String batchtype = properties.getProperty(BATCH_TYPE);
        if (Util.isNull(batchtype)) {
            String error = getTranslationProcessor().translate("Please select batch type.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String batchname = properties.getProperty(BATCH_NAME);
        if (Util.isNull(batchname)) {
            String error = getTranslationProcessor().translate("Please select batch name.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String newbatchid = "";
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String sqlloc = Util.parseMessage(FishSqls.GET_LOCATION_OFUSER, dept);
        DataSet dsloc = getQueryProcessor().getSqlDataSet(sqlloc);
        if (dsloc == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlloc;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsloc.size() == 0) {
            String errMsg = getTranslationProcessor().translate("User location can't be null.");
            errMsg += "\nQuery retuns no rows:" + sqlloc;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String batchlocation = dsloc.getValue(0, "u_site");
        if (batchname.length() > 0) {
            String sqlBatch = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, batchname);
            DataSet dsBatch = getQueryProcessor().getSqlDataSet(sqlBatch);
            try {
                if (dsBatch.size() > 0)
                    throw new SapphireException(
                            "Duplicate BatchName Present in Batch Table.Please provide another name.");
                else {
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatch");
                    props.setProperty("batchname", batchname);
                    props.setProperty("batchtype", batchtype);
                    props.setProperty("batchlocation", batchlocation);
                    props.setProperty("batchstate", STATUS);
                    props.setProperty("batchmovestatus", "slidedrop");
                    if(!Util.isNull(properties.getProperty("forcebatchreason", ""))){
                    	props.setProperty("forcebatchreason", properties.getProperty("forcebatchreason", ""));
                    }
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                    newbatchid = props.getProperty(NEWKEYID1, "");
                    properties.setProperty("batchid", newbatchid);
                    properties.setProperty("batchname", batchname);
                }
            } catch (Exception e) {
                String error = getTranslationProcessor().translate("Could not create new Batch: " + e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }
        }
        return newbatchid;
    }

    /**
     * For attaching slide to batch
     *
     * @param newbatchid
     * @param properties
     * @throws SapphireException
     */
    private void addSlidesToBatch(String newbatchid, String slideid) throws SapphireException {
        slideid = Util.getUniqueList(slideid, ";", true);
        if (Util.isNull(slideid)) {
            String errMsg = getTranslationProcessor().translate("Slide Id is null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "FISHBatchSample");
        prop.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(slideid.split(";").length));
        prop.setProperty("batchid", newbatchid);
        prop.setProperty("sampleid", slideid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (SapphireException se) {
            String errmsg = "Unable to associate samples to batch.";
            throw new SapphireException(errmsg);
        }
    }

    /**
     * Used for get slide id by centrifuged id
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String getSlide(PropertyList properties) throws SapphireException {
        String centrifugedid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
        if (Util.isNull(centrifugedid) || centrifugedid == null || "null".equalsIgnoreCase(centrifugedid)) {
            String errMsg = getTranslationProcessor().translate("Please scan Centrifuge Tube.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String sqlSlide = Util.parseMessage(FishSqls.GET_SLIDE, centrifugedid);
        DataSet dsSlide = getQueryProcessor().getSqlDataSet(sqlSlide);
        if (dsSlide == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSlide;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsSlide.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("No slide found for the centrifuged tube:" + centrifugedid);
            errMsg += "\nQuery retuns no rows:" + sqlSlide;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String slideid = dsSlide.getColumnValues("slideid", ";");
        return slideid;
    }
    
    /**
     * Used for get slide id by centrifuged id
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String getSlideForForcedBatch(PropertyList properties) throws SapphireException {
        String centrifugedid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
        if (Util.isNull(centrifugedid) || centrifugedid == null || "null".equalsIgnoreCase(centrifugedid)) {
            String errMsg = getTranslationProcessor().translate("Please scan Centrifuge Tube.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String sqlSlide = Util.parseMessage(FishSqls.GET_FORCED_BATCH_SLIDE, centrifugedid);
        DataSet dsSlide = getQueryProcessor().getSqlDataSet(sqlSlide);
        if (dsSlide == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSlide;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsSlide.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("No slide found for the centrifuged tube:" + centrifugedid);
            errMsg += "\nQuery retuns no rows:" + sqlSlide;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String slideid = dsSlide.getColumnValues("slideid", ";");
        return slideid;
    }

    /**
     * Used for Edit batchid in Slidedrop sdc
     *
     * @param newbatchid
     * @throws SapphireException
     */
    private void editSlideDrop(String newbatchid, String slideid) throws SapphireException {
    	slideid=StringUtil.replaceAll(slideid, ";", "','");
        String sqlDropId = Util.parseMessage(FishSqls.GET_DROPID_BYCT, slideid);
        DataSet dsDropId = getQueryProcessor().getSqlDataSet(sqlDropId);
        if (dsDropId == null) {
            String errmsg = getTranslationProcessor().translate("System error.Please contact to Admin.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsDropId.size() == 0) {
            String errmsg = getTranslationProcessor().translate("Drop Id can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "SlideDrop");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsDropId.getColumnValues("u_slidedropid", ";"));
        prop.setProperty("fishbatchid", newbatchid);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
            throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
        }
        routDrop(dsDropId);
    }
    
    /**
     * This method is used for route slideid to next tramstop.
     * @param ds
     * @throws SapphireException
     */
    private void routDrop(DataSet ds) throws SapphireException {
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        String destination = site + "-" + "FISH";
        if (!Util.validateDepartment(destination, getQueryProcessor(), getTranslationProcessor())){
        	throw new SapphireException("Error: Unable to route specimen. Department: " + destination + " does not exist");
        }
        try {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("slideid", ";"));
            props.setProperty("u_currentmovementstep", StringUtil.repeat("prob", ds.getColumnValues("slideid",";").split(";").length, ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("slideid", ";"));
            props.setProperty("u_currenttramstop", StringUtil.repeat("prob", ds.getColumnValues("slideid",";").split(";").length, ";"));
            props.setProperty("custodialuserid", StringUtil.repeat("(null)", ds.getColumnValues("slideid",";").split(";").length, ";"));
            props.setProperty("custodialdepartmentid", StringUtil.repeat(destination, ds.getColumnValues("slideid",";").split(";").length, ";"));
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Can't update movement step in specimen");
            error += e.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    /**
     * This method is used for create batch name.
     * @param type
     * @return
     * @throws SapphireException
     */
    private void createBatchName(PropertyList properties) throws SapphireException {
        String type = properties.getProperty(BATCH_TYPE);
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = dept.substring(0, dept.lastIndexOf('-'));
        String sql = Util.parseMessage(FishSqls.GET_BATCHNAME_BASEDONSITE, site + "-%-" + type);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        Integer max = Integer.MIN_VALUE;
        String CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String batchname = "";
        if (ds.size() == 0) {
            batchname = site + "-" + CURRENT_YEAR + "-" + "0000001" + "-" + type;
        } else {
            for (int i = 0; i < ds.size(); i++) {
                String querybatch = ds.getValue(i, "batchname");
                String value = querybatch.substring(querybatch.indexOf('-') + 6, querybatch.lastIndexOf('-'));
                int batchnm = Integer.parseInt(value);
                if (batchnm > max) {
                    max = batchnm;
                }
            }
            max++;
            int maxlength = max.toString().length();
            if (maxlength > 6)
                throw new SapphireException(
                        "Maximum limit of Batch sequence is exceed.New batch could not created.Please contact to Administrator");
            String seq = String.format(BATCHSEQ, max);
            batchname = site + "-" + CURRENT_YEAR + "-" + seq + "-" + type;
        }
        properties.setProperty("batchname", batchname);
        properties.setProperty("batchtype", type);
    }

    /**
     * For review scan slide
     *
     * @param properties
     * @throws SapphireException
     */
    private void reviewSlide(PropertyList properties) throws SapphireException {
        String slide = properties.getProperty(SLIDEID);
        String parent = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
        if (Util.isNull(slide)) {
            String errMsg = getTranslationProcessor()
                    .translate("Please scan a valid slide.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        if (Util.isNull(parent)) {
            String errMsg = getTranslationProcessor()
                    .translate("Tube can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String sqlSlide = Util.parseMessage(FishSqls.SLIDE_REVIEW, slide);
        DataSet dsSlide = getQueryProcessor().getSqlDataSet(sqlSlide);
        if (dsSlide == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSlide;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsSlide.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("You can't validate this slide as slide does not have any drop/test.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        for(int i=0;i<dsSlide.size();i++){
        	if(Util.isNull(dsSlide.getValue(i,"lvtestcodeid", ""))){
        		String errMsg = getTranslationProcessor()
                        .translate("You can't validate this slide as there are no test present in one drop.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        	}
        }
        String status="";
        if("Y".equalsIgnoreCase(Util.getUniqueList(dsSlide.getColumnValues("slidereview", ";"), ";", true))){
        	status="N";
        }else{
        	status="Y";
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "SlideDrop");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsSlide.getColumnValues("u_slidedropid", ";"));
        prop.setProperty("slidereview", status);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
            throw new SapphireException(TYPE_FAILURE, "Action failed , unable to add SDI in SlideDrop SDC.");
        }
    }

    /**
     * Validation to check all slides are reviewed or not before creating batch.
     *
     * @param properties
     * @throws SapphireException
     */
    private void checkSlideReviewed(PropertyList properties) throws SapphireException {
        String centrifugedid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
        if (Util.isNull(centrifugedid)) {
            String errMsg = getTranslationProcessor()
                    .translate("Tube can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String sqlSlideReview = Util.parseMessage(FishSqls.CHECK_SLIDEREVIEW, centrifugedid);
        DataSet dsSlideReview = getQueryProcessor().getSqlDataSet(sqlSlideReview);
        if (dsSlideReview == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSlideReview;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsSlideReview.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("No slide present for this tube:" + centrifugedid);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        HashMap<String, String> hmFilter = new HashMap<String, String>();
        hmFilter.put("slidereview", "N");
        DataSet dsFilter = dsSlideReview.getFilteredDataSet(hmFilter);
        if (dsFilter.size() > 0) {
            String slide = dsFilter.getColumnValues("slideid", ",");
            String errMsg = getTranslationProcessor()
                    .translate("Please validate all slides before create batch. " + slide + " is/are not validated yet.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
    }
    /**
     * This is used for allowing to create batch although slide is not reviewed but all test must be checked as QNS for the drop(s) of non reviewed slide.
     * @param properties
     * @throws SapphireException
     */
    private String allowIfAllTestQNS(PropertyList properties) throws SapphireException {
    	String slideids="";
    	String centrifugedid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
    	String sqlNotReview = Util.parseMessage(FishSqls.NOT_REVIEWSLIDE_QNS, centrifugedid);
        DataSet dsNotReview = getQueryProcessor().getSqlDataSet(sqlNotReview);
        if (dsNotReview == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlNotReview;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsNotReview.size() > 0) {
            dsNotReview.sort("slideid");
            ArrayList<DataSet> arrySlides = dsNotReview.getGroupedDataSets("slideid");
            for (int i = 0; i < arrySlides.size(); i++) {
                DataSet dsEach = arrySlides.get(i);
                String slideid= Util.getUniqueList(dsEach.getColumnValues("slideid", ";"), ";", true);
                String fishqns=Util.getUniqueList(dsEach.getColumnValues("fishqns", ";"), ";", true);
                if(!"Y".equalsIgnoreCase(fishqns)){
                	slideids=slideids+","+slideid;
                }
            }
            if(slideids.startsWith(",")){
            	slideids=slideids.substring(1);
            }
        }
        return slideids;
    }
    /**
     * This will check all ordered test has been assigned or not to drop.If not all test assigned then it will search qns checked or not.
     * @param properties
     * @throws SapphireException
     */
    private void qnsTestValidation(PropertyList properties) throws SapphireException{
    	String centrifugedid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
    	String qnstest = properties.getProperty(PROPERTY_QNSTEST);
    	String[] qnsTestArr=StringUtil.split(qnstest, ";");
    	HashSet<String> qnsTestHash=new HashSet<>(Arrays.asList(qnsTestArr));
    	String sqlOrderTest = Util.parseMessage(FishSqls.GET_ORDEREDTEST, centrifugedid);
        DataSet dsOrderTest = getQueryProcessor().getSqlDataSet(sqlOrderTest);
    	if (dsOrderTest == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlOrderTest;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsOrderTest.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("Test has not been ordered for this tube.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String sqlAllDropTest = Util.parseMessage(FishSqls.GET_ALLDROPTEST, centrifugedid);
        DataSet dsAllDropTest= getQueryProcessor().getSqlDataSet(sqlAllDropTest);
    	if (dsAllDropTest == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlAllDropTest;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsAllDropTest.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("Test has not been ordered for Drop.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String[] orderedTestArr=StringUtil.split(dsOrderTest.getColumnValues("u_testcodeid", ";"), ";");
        String[] allDropTestArr=StringUtil.split(dsAllDropTest.getColumnValues("u_testcodeid", ";"), ";");
        HashSet<String> orderTestHash=new HashSet<>(Arrays.asList(orderedTestArr));
        HashSet<String> allDropTestHash=new HashSet<>(Arrays.asList(allDropTestArr));
        if(!orderTestHash.equals(allDropTestHash)){
        	if(qnsTestHash.size()>0){
        		allDropTestHash.addAll(qnsTestHash);
        	}
        	if(!orderTestHash.equals(allDropTestHash)){
        		String errMsg = getTranslationProcessor().translate("Please assign all ordered test to Drop or check unused test as QNS.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        	}
        }
    }
    /**
     * If QNS is checked it will update fishqns as 'Y' in sampletestcodemap for topparent and drop sample.If unchecked it will be null/N  
     * @param properties
     * @throws SapphireException
     */
    private void checkUncheckQNS(PropertyList properties) throws SapphireException{
    	String topparent = properties.getProperty(PROPERTY_PARENTSAMPLE);
    	if (Util.isNull(topparent)) {
            String errMsg = getTranslationProcessor().translate("Top Prent Sample can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    	String centrifugedid = properties.getProperty(PROPERTY_CENTRIFUGETUBEID);
    	if (Util.isNull(centrifugedid)) {
            String errMsg = getTranslationProcessor().translate("Tube Id can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    	String test = properties.getProperty(PROPERTY_TESTCODEID);
    	if (Util.isNull(test)) {
            String errMsg = getTranslationProcessor().translate("Test can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    	String checked = properties.getProperty("checked");
    	if (Util.isNull(checked)) {
            String errMsg = getTranslationProcessor().translate("Checked status can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    	//Get stm Id for top parent
    	String stmid="";
    	String sqlForTopParent = Util.parseMessage(FishSqls.GET_STM_ID_TOPPARENT, topparent,test);
        DataSet dsForTopParent= getQueryProcessor().getSqlDataSet(sqlForTopParent);
     	if (dsForTopParent == null) {
             String errMsg = getTranslationProcessor()
                     .translate("Something wrong happened. Contact your Administrator.");
             errMsg += "\nQuery returns null, Query failed:" + sqlForTopParent;
             throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
         }
         if (dsForTopParent.size() == 0) {
        	 String errMsg = getTranslationProcessor()
                    .translate("Sample Test Code Map Id ca't be null.");
        	 throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        stmid=dsForTopParent.getValue(0, "u_sampletestcodemapid","");
         //Get stm Id for top Drop
    	String sqlForDrop = Util.parseMessage(FishSqls.GET_STM_ID_DROP, centrifugedid,test);
        DataSet dsForDrop= getQueryProcessor().getSqlDataSet(sqlForDrop);
        
     	if (dsForDrop == null) {
             String errMsg = getTranslationProcessor()
                     .translate("Something wrong happened. Contact your Administrator.");
             errMsg += "\nQuery returns null, Query failed:" + sqlForDrop;
             throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
         }
         if (dsForDrop.size() > 0) {
        	 stmid=stmid+";"+dsForDrop.getColumnValues("u_sampletestcodemapid", ";");
         }
         PropertyList props=new PropertyList();
         try {
             props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
             props.setProperty(EditSDI.PROPERTY_KEYID1,stmid);
             props.setProperty("fishqns", StringUtil.repeat(checked, stmid.split(";").length, ";"));
             getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
         } catch (ActionException ae) {
             String error = getTranslationProcessor().translate("Error occurred: Can't Edit from SampleTestCodeMap.");
             error += ae.getMessage();
             throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
         }
    }
    /**
     * Validate all slide after edit batch
     * @param properties
     * @throws SapphireException
     */
    private void editComplete(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty(BATCHID);
        if (Util.isNull(batchid)) {
            String errMsg = getTranslationProcessor()
                    .translate("Batch can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String sqlEditSlideReview = Util.parseMessage(FishSqls.CHECK_EDIT_SLIDEREVIEW, batchid);
        DataSet dsEditSlideReview = getQueryProcessor().getSqlDataSet(sqlEditSlideReview);
        if (dsEditSlideReview == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlEditSlideReview;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsEditSlideReview.size() == 0) {
            String errMsg = getTranslationProcessor()
                    .translate("No slide present for this batch:" + batchid);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        HashMap<String, String> hmFilter = new HashMap<String, String>();
        hmFilter.put("slidereview", "N");
        DataSet dsFilter = dsEditSlideReview.getFilteredDataSet(hmFilter);
        if (dsFilter.size() > 0) {
            String slide = Util.getUniqueList(dsFilter.getColumnValues("slideid", ","), ",", true);
            String errMsg = getTranslationProcessor()
                    .translate("Please validate all slides before proceed. " + slide + " is/are not validated yet.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        routDrop(dsEditSlideReview);
    }

    /*****************
     * BASE DESIGN ***********DO NOT CHANGE THIS
     *****************************/
    private DataSet dsRemoveTest = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "s_sampleid";
    private static final String DATASET_PROPERTY_WORKITEMID = "workitemid";
    private static final String DATASET_PROPERTY_WORKITEMINSTANCE = "workiteminstance";
    private static final String DATASET_PROPERTY_SAMPLETESTCODEMAP_ID = "sampletestcodemapid";
    private static final String DATASET_PROPERTY_LVTESTPANELID = "lvtestpanelid";
    private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsRemoveTest == null) {
            dsRemoveTest = new DataSet();
            dsRemoveTest.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsRemoveTest.addColumn(DATASET_PROPERTY_WORKITEMID, DataSet.STRING);
            dsRemoveTest.addColumn(DATASET_PROPERTY_WORKITEMINSTANCE, DataSet.STRING);
            dsRemoveTest.addColumn(DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, DataSet.STRING);
            dsRemoveTest.addColumn(DATASET_PROPERTY_LVTESTPANELID, DataSet.STRING);
            dsRemoveTest.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
        }
    }
}
