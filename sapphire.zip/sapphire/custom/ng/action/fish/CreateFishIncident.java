package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.RecordIncident;
import sapphire.action.SubmitSDIForApproval;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by gpandi on 12/12/2016.
 *
 * @Desc This action creates incident for input samples.
 * Mandatory Input.
 * s_sampleid (sampleid)
 */
public class CreateFishIncident extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("s_sampleid");
        if (Util.isNull(sampleids)) {
            String errName = getTranslationProcessor().translate("SampleId not found");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errName);
        }
        String incidentId = fishRecordIncident(sampleids);
        fishSubmitApproval(incidentId);
        properties.setProperty("incidentId", incidentId);
    }

    /** This method is used to RecordIncident for a particular Sample.
     * @param samples
     * @return
     * @throws SapphireException
     */
    private String fishRecordIncident(String samples) throws SapphireException {
        String incidentId = "";
        String user = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String dept = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        PropertyList recordFishprop = new PropertyList();
        recordFishprop.setProperty("sourcesdcid", "Sample");
        recordFishprop.setProperty("sourcekeyid1", samples);
        recordFishprop.setProperty("incidentcategory", "UnPlanned");
        recordFishprop.setProperty("activeflag", "Y");
        recordFishprop.setProperty("woreqflag", "Y");
        recordFishprop.setProperty("incidentstatus", "Approved");
        recordFishprop.setProperty("incidenttype", "OOS");
        recordFishprop.setProperty("incidentdt", "n");
        recordFishprop.setProperty("reportedby", user);
        recordFishprop.setProperty("u_fromdepartment", dept);
        try {
            getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordFishprop);
        } catch (SapphireException se) {
            String errName = getTranslationProcessor().translate("Error in create incident." + se.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errName);
        }
        incidentId = recordFishprop.getProperty("newkeyid1");
        return incidentId;
    }

    /** This method is used to update the Incident status.
     * @param incidentid
     * @throws SapphireException
     */
    private void fishSubmitApproval(String incidentid) throws SapphireException {
        PropertyList submitFishApproval = new PropertyList();
        submitFishApproval.setProperty("sdcid", "LV_Incdt");
        submitFishApproval.setProperty("keyid1", incidentid);
        submitFishApproval.setProperty("pendingapprovalstatus", "PendingApproval");
        submitFishApproval.setProperty("approvalstatus", "Approved");
        submitFishApproval.setProperty("approvalstatuscolumn", "incidentstatus");
        try {
            getActionProcessor().processAction(SubmitSDIForApproval.ID, SubmitSDIForApproval.VERSIONID, submitFishApproval);
        } catch (SapphireException se) {
            String errName = getTranslationProcessor().translate("Error in incident approval." + se.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errName);
        }

    }
}

