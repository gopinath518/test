package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by Gopinath pandi on 07/06/2018.
 * Description: Action used to route Specimens from Slide recon to Fish.
 */

public class MoveToFish extends BaseAction{
    String errmsg="";
    private DataSet dsSamples = null;

    public void processAction(PropertyList properties) throws SapphireException{
        String sampleid = properties.getProperty("s_sampleid");
        String methodology = properties.getProperty("methodology");
        String method= Util.getUniqueList(methodology,";",true);
        String methodArr[] = StringUtil.split(method, ";");
        if(methodArr.length>1){
            errmsg = getTranslationProcessor().translate("Selected Specimens doesn't belong to FISH methodology");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (sampleid.contains(";"))
            sampleid = StringUtil.replaceAll(sampleid, ";", "','");
        String sql=Util.parseMessage(FishSqls.GET_UTYPE,sampleid);
        DataSet dsResult = getQueryProcessor().getSqlDataSet(sql);
        if (dsResult == null || dsResult.getRowCount() == 0) {
            throw new SapphireException("Scanned Item is not a valid Specimen.");
        }
        String type=dsResult.getColumnValues("u_type",";");
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        String custdepartment = site + "-FISH" ;
        if (Util.isNull(sampleid)) {
            errmsg = getTranslationProcessor().translate("No Specimen is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        if(!"FISH".equalsIgnoreCase(method)){
            errmsg = getTranslationProcessor().translate("Please select the Specimen with FISH Methodology");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        else {
            populateDataSet(sampleid,type);
            changeMovementStep(dsSamples);
            changeCustodian(dsSamples, custdepartment);
        }
    }
    private void populateDataSet(String sampleid, String type) throws SapphireException {

        if (dsSamples == null) {
            dsSamples = new DataSet();
            dsSamples.addColumn("sampleid", DataSet.STRING);
            dsSamples.addColumn("type", DataSet.STRING);
            dsSamples.addColumn("movementstep", DataSet.STRING);
        }


        String sampleArr[] = StringUtil.split(sampleid, "','");
        String typeArr[] = StringUtil.split(type, ";");

        int rowID = 0;
        for (int i = 0; i < sampleArr.length; i++) {
            rowID = dsSamples.addRow();
            dsSamples.setValue(rowID, "sampleid", sampleArr[i]);
            dsSamples.setValue(rowID, "type", typeArr[i]);
            if(("U".equalsIgnoreCase(typeArr[i]))||("CU".equalsIgnoreCase(typeArr[i]))) {
                dsSamples.setValue(rowID, "movementstep", "FISHQC");
            }
            else if(("H".equalsIgnoreCase(typeArr[i])||("SH".equalsIgnoreCase(typeArr[i]))||("PH".equalsIgnoreCase(typeArr[i]))||("CH".equalsIgnoreCase(typeArr[i])))) {
                dsSamples.setValue(rowID, "movementstep", "FISHReceiveHNE");
            }
        }

    }
    private void changeMovementStep(DataSet dsSamples) throws SapphireException{
        PropertyList props=new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1,dsSamples.getColumnValues("sampleid",";"));
        props.setProperty("u_currentmovementstep",dsSamples.getColumnValues("movementstep",";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
        catch (SapphireException e) {
            throw new SapphireException(
                    getTranslationProcessor().translate("Unable to perform EditSDI.") + "\n" + e.getMessage());
        }
    }
    private void changeCustodian(DataSet dsSamples,String department) throws SapphireException{
        PropertyList prop=new PropertyList();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSamples.getColumnValues("sampleid",";"));
        prop.setProperty("custodialdepartmentid", department);
        prop.setProperty("custodialuserid", "");
        prop.setProperty("u_currenttramstop", dsSamples.getColumnValues("movementstep", ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }
}
