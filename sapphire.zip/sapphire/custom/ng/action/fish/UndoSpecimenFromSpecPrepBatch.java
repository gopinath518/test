package sapphire.custom.ng.action.fish;


import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by gopinath on 04/24/2018.
 *  This Action is used to delete the Specimens from Specimen Prep batch
 */
public class UndoSpecimenFromSpecPrepBatch extends BaseAction {
    public static final String DATASET_PROPERTY_BATCHID = "batchid";
    public static final String DATASET_PROPERTY_SAMPLEBATCHID = "fishsamplebatchid";
    public static final String DATASET_PROPERTY_SAMPLES = "sampleid";
    private String errmsg = "";
    private DataSet dsSamples = null;

    public void processAction(PropertyList properties) throws SapphireException {
        String fishbatch = properties.getProperty(DATASET_PROPERTY_BATCHID);
        String fishsamplebatchid = properties.getProperty(DATASET_PROPERTY_SAMPLEBATCHID);
        String sampleid = properties.getProperty(DATASET_PROPERTY_SAMPLES);

        if (Util.isNull(fishbatch)) {
            errmsg = getTranslationProcessor().translate("Batch Id can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (Util.isNull(fishsamplebatchid)) {
            errmsg = getTranslationProcessor().translate("Specimen Batch Id can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (Util.isNull(sampleid)) {
            errmsg = getTranslationProcessor().translate("No Mother Tube is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        populateDataset(sampleid,fishsamplebatchid);
        undoSamplefromBatch(dsSamples);
        updateStatusRootSample(sampleid);
    }

    private void populateDataset(String samples, String samplebatchid) throws SapphireException{

        if(dsSamples==null) {
            dsSamples = new DataSet();
            dsSamples.addColumn("sampleid", DataSet.STRING);
            dsSamples.addColumn("samplebatchid", DataSet.STRING);
        }

        String sampleArr[] = StringUtil.split(samples, ";");
        String samplebatchArr[] = StringUtil.split(samplebatchid, ";");

        int rowID = 0;
        for (int i = 0; i < sampleArr.length; i++) {
            rowID = dsSamples.addRow();
            dsSamples.setValue(rowID, "sampleid", sampleArr[i]);
            dsSamples.setValue(rowID, "samplebatchid", samplebatchArr[i]);
        }

    }
    /**
     * This method is used to delete the specimen ffrom Batch using DeleteSDI.
     *
     * @param dsSamples
     * @throws SapphireException
     */
    private void undoSamplefromBatch(DataSet dsSamples )throws SapphireException{
        PropertyList delSamplefromBatch= new PropertyList();
        delSamplefromBatch.setProperty(DeleteSDI.PROPERTY_SDCID, "FISHBatchSample");
        delSamplefromBatch.setProperty(DeleteSDI.PROPERTY_KEYID1, dsSamples.getColumnValues("samplebatchid",";"));
        delSamplefromBatch.setProperty("sampleid",  dsSamples.getColumnValues("sampleid",";"));
        try {
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, delSamplefromBatch);
        } catch (Exception ex) {
            String err = "Can not delete Specimen :" + ex.getMessage();
            throw new SapphireException(err);
        }
    }
    /**
     * This method is used to edit the parent specimen to pending state.
     *
     * @param sample
     * @throws SapphireException
     */
    private void updateStatusRootSample(String sample) throws SapphireException{
        String samples = sample.replaceAll(";","','");
        String sql=Util.parseMessage(FishSqls.GET_ROOTSAMPLE,samples);
        DataSet dsParent = getQueryProcessor().getSqlDataSet(sql);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsParent.getColumnValues("u_rootsample", ";"));
        prop.setProperty("u_currentmovementstep", "SpecimenPrepSample");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit sample");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

    }
}
