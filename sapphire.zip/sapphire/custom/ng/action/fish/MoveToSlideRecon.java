package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.fish.FishSqls;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by Gopinath pandi on 07/06/2018.
 * Description: Action used to send the Hne Specimen from Fish to Slide Recon.
 */
public class MoveToSlideRecon extends BaseAction{
    String errmsg="";

    public void processAction(PropertyList properties) throws SapphireException{
        String sampleid = properties.getProperty("s_sampleid");
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        String custdepartment = site + "-Accessioning" ;
        if (Util.isNull(sampleid)) {
            errmsg = getTranslationProcessor().translate("No Specimen is selected");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        String sqlSample = Util.parseMessage(FishSqls.GET_ISCUT_SAMPLES,sampleid.replaceAll(";", "','"));
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
        if(dsSample.size()==0){
            String errorSample= dsSample.getColumnValues("s_sampleid",",");
            String errmsg = getTranslationProcessor().translate( " Below specimen are not valid. \n"+errorSample);
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        String isCut= dsSample.getColumnValues("u_iscut",";");
        if (isCut.contains("N")) {
            String errmsg = getTranslationProcessor().translate(" Below specimen(s) are not physical slides. Cannot move to Recon. "
                    +dsSample.getColumnValues("s_sampleid",","));
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        changeMovementStep(sampleid);
        changeCustodian(sampleid,custdepartment);
    }
    private void changeMovementStep(String sample) throws SapphireException{
        PropertyList props=new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1,sample);
        props.setProperty("u_currentmovementstep","IHCSlideRecon");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
        catch (SapphireException e) {
            throw new SapphireException(
                    getTranslationProcessor().translate("Unable to perform EditSDI.") + "\n" + e.getMessage());
        }
    }
    private void changeCustodian(String sample,String department) throws SapphireException{
        PropertyList prop=new PropertyList();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, sample);
        prop.setProperty("custodialdepartmentid", department);
        prop.setProperty("u_currenttramstop", "IHCSlideRecon");
        prop.setProperty("custodialuserid", "");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }
}
