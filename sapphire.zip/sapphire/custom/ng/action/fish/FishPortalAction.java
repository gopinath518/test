package sapphire.custom.ng.action.fish;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.fish.FishPortalSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

public class FishPortalAction extends BaseAction {
    public static final String ID = "FishPortalAction";
    public static final String VERSION_ID = "1";


    public static final String PROP_SAVE_SCORE_OPERATION = "savescore";
    public static final String PROP_SAVE_SCORE_SAMPLE_ID = "sampleid";
    public static final String PROP_SAVE_SCORE_TECHNOLOGIST = "technologist";
    public static final String PROP_SAVE_SCORE_LV_TESTCODE_ID = "lvtestcode";
    public static final String PROP_SAVE_SCORE_PARAM_ID = "paramid";
    public static final String PROP_SAVE_SCORE_ENTERED_TEXT = "enteredtext";

    public static final String PROP_ADD_NEW_CLASSIFICATION_OPERATION = "addnewclasificaion";
    public static final String PROP_ADD_TECHNOLOGIST_OPERATION = "addtechnologist";
    public static final String PROP_ADD_REMOVE_TECHNOLOGIST_SCORE_OPERATION = "addremoveflag"; //--Y/N
    public static final String PROP_ADD_ISCN_RESULT = "addiscnresult";


    public void processAction(PropertyList properties) throws SapphireException {
        String actionName = properties.getProperty("actionname");

        if (PROP_ADD_NEW_CLASSIFICATION_OPERATION.equalsIgnoreCase(actionName)) {
            addParamInDataSet(properties);
        } else if (PROP_ADD_TECHNOLOGIST_OPERATION.equalsIgnoreCase(actionName)) {
            assignTechnologist(properties);
        } else if (PROP_SAVE_SCORE_OPERATION.equalsIgnoreCase(actionName)) {
            saveScore(properties);
        } else if (PROP_ADD_ISCN_RESULT.equalsIgnoreCase(actionName)) {
            saveISCNResult(properties);
        } else if (PROP_ADD_REMOVE_TECHNOLOGIST_SCORE_OPERATION.equalsIgnoreCase(actionName)) {
            addRemoveTechnologistFlag(properties);
        }
    }

    /**
     * @param properties
     * @throws SapphireException Example:
     *                           paramid:        1R1G1F; 2F ; <2F ; >2F
     *                           enteredtext:    23;33;43;53
     *                           sampleid:        S1;S1;S1;S1
     *                           tchnologist:     mohamed.kadar;mohamed.kadar;mohamed.kadar;mohamed.kadar
     *                           lvtestcode:      FISHBPG63;FISHBPG63;FISHBPG63;FISHBPG63
     */
    private void saveScore(PropertyList properties) throws SapphireException {

        DataSet dsInput = getInputDataSet(properties);

        String sampleId = Util.getUniqueList(dsInput.getColumnValues(PROP_SAVE_SCORE_SAMPLE_ID, ";"), ";", true);
        String technologistId = Util.getUniqueList(dsInput.getColumnValues(PROP_SAVE_SCORE_TECHNOLOGIST, ";"), ";", true);
        String lvTestCodeId = Util.getUniqueList(dsInput.getColumnValues(PROP_SAVE_SCORE_LV_TESTCODE_ID, ";"), ";", true);

        String sql = Util.parseMessage(FishPortalSql.TECHNOLOGIST_DATASET_ASSIGNMENT, sampleId, technologistId, lvTestCodeId);
        DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sql);
        if (dsSqlEnterData.getRowCount() == 0) {
            logger.error("Technologist data not found. SQL failed: " + sql);
            throw new SapphireException("Technologist data not found.");

        }

        compareAndAddEnteredText(dsInput, dsSqlEnterData);


        PropertyList props = new PropertyList();
        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("keyid1", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
        props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("enteredtext", ";"));

        try {
            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
        } catch (SapphireException e) {
            throw new SapphireException("Initial or Repeat rule not performed." + e.getMessage());
        }
    }

    private void compareAndAddEnteredText(DataSet dsInput, DataSet dsSqlEnterData) throws SapphireException {
        dsSqlEnterData.addColumn("enteredtext", DataSet.STRING);

        HashMap hm = new HashMap();

        for (int i = 0; i < dsSqlEnterData.getRowCount(); i++) {
            hm.clear();
            hm.put(PROP_SAVE_SCORE_SAMPLE_ID, dsSqlEnterData.getValue(i, "keyid1", ""));
            hm.put(PROP_SAVE_SCORE_PARAM_ID, dsSqlEnterData.getValue(i, "paramid", ""));

            DataSet dsFilter = dsInput.getFilteredDataSet(hm);
            if (dsFilter.getRowCount() > 0) {
                dsSqlEnterData.setValue(i, "enteredtext", dsFilter.getValue(0, PROP_SAVE_SCORE_ENTERED_TEXT, ""));
            }
        }
    }


    private DataSet getInputDataSet(PropertyList properties) throws SapphireException {

        DataSet ds = new DataSet();
        ds.addColumn(PROP_SAVE_SCORE_SAMPLE_ID, DataSet.STRING);
        ds.addColumn(PROP_SAVE_SCORE_TECHNOLOGIST, DataSet.STRING);
        ds.addColumn(PROP_SAVE_SCORE_LV_TESTCODE_ID, DataSet.STRING);
        ds.addColumn(PROP_SAVE_SCORE_PARAM_ID, DataSet.STRING);
        ds.addColumn(PROP_SAVE_SCORE_ENTERED_TEXT, DataSet.STRING);

        String sampleid = properties.getProperty(PROP_SAVE_SCORE_SAMPLE_ID, "");
        String technologist = properties.getProperty(PROP_SAVE_SCORE_TECHNOLOGIST, "");
        String lvtestcodeid = properties.getProperty(PROP_SAVE_SCORE_LV_TESTCODE_ID, "");
        String paramid = properties.getProperty(PROP_SAVE_SCORE_PARAM_ID, "");
        String enteredtext = properties.getProperty(PROP_SAVE_SCORE_ENTERED_TEXT, "");

        String sampleIdArr[] = StringUtil.split(sampleid, ";");
        String technologistArr[] = StringUtil.split(technologist, ";");
        String lvtestcodeidArr[] = StringUtil.split(lvtestcodeid, ";");
        String paramidArr[] = StringUtil.split(paramid, ";");
        String enteredtextArr[] = StringUtil.split(enteredtext, ";");

        for (int i = 0; i < sampleIdArr.length; i++) {
            int rowID = ds.addRow();

            ds.setValue(rowID, PROP_SAVE_SCORE_SAMPLE_ID, sampleIdArr[i]);
            ds.setValue(rowID, PROP_SAVE_SCORE_TECHNOLOGIST, technologistArr[i]);
            ds.setValue(rowID, PROP_SAVE_SCORE_LV_TESTCODE_ID, lvtestcodeidArr[i]);
            ds.setValue(rowID, PROP_SAVE_SCORE_PARAM_ID, paramidArr[i]);
            ds.setValue(rowID, PROP_SAVE_SCORE_ENTERED_TEXT, enteredtextArr[i]);
        }

        return ds;

    }

    private void addRemoveTechnologistFlag(PropertyList properties) throws SapphireException {

        String sampleID = properties.getProperty("sampleid", "");
        String technologist = properties.getProperty("technologist", "");
        String lvtestcodeid = properties.getProperty("lvtestcodeid", "");
        String ischecked = properties.getProperty("ischecked", "");

        String sql = Util.parseMessage(FishPortalSql.TECHNOLOGIST_SAMPLE_ASSIGNMENT, sampleID, technologist, lvtestcodeid);

        DataSet dsTechnologist = getQueryProcessor().getSqlDataSet(sql);
        if (dsTechnologist.getRowCount() == 0) {
            throw new SapphireException("No specimen assignment found with the technologist :" + technologist);
        }

        String flag = "";
        if (ischecked.equalsIgnoreCase("Y")) {
            flag = "Y";
        } else if (ischecked.equalsIgnoreCase("N")) {
            flag = "N";
        } else {
            flag = "";
        }

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "TechnologistMap");
        pl.setProperty("keyid1", dsTechnologist.getValue(0, "u_technologistmapid", ""));
        pl.setProperty("reportflag", flag);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);


    }

    private void assignTechnologist(PropertyList properties) throws SapphireException {

        String sampleID = properties.getProperty("sampleid", "");
        String technologist = properties.getProperty("technologist", "");

        String sql = Util.parseMessage(FishPortalSql.GET_DATASET_BY_SAMPLEID_WITH_MAX_REPLICATE, StringUtil.replaceAll(sampleID, ";", "','"));
        DataSet dsDataItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsDataItem.getRowCount() == 0) {
            throw new SapphireException("No test code is associated with the Specimen.");
        }

        String sdidataid = Util.getUniqueList(dsDataItem.getColumnValues("sdidataid", ";"), ";", true);
        String replicates = Util.getUniqueList(dsDataItem.getColumnValues("replicateid", ";"), ";", true);
        String lvtestcodeid = Util.getUniqueList(dsDataItem.getColumnValues("lvtestcodeid", ";"), ";", true);

        String sql2 = Util.parseMessage(FishPortalSql.GET_TECHNOLOGIST_BY_DATASET_ID, StringUtil.replaceAll(sdidataid, ";", "','"));
        DataSet dsTechData = getQueryProcessor().getSqlDataSet(sql2);
        if (dsTechData.getRowCount() == 0) {
            //No technologist are assigned..
            addTechnologist(dsDataItem, technologist);
            return;
        }

        //Check same techonologist added or not
        //if not then add DataSet with appropriate replicate id
        String techPersonFromDb = dsTechData.getColumnValues("technologistid", ";");
        String uniqueTechPersonFromDB = Util.getUniqueList(techPersonFromDb, ";", true);

        if (uniqueTechPersonFromDB.contains(technologist)) {
            throw new SapphireException("Error: " + technologist + " already added in the list.");
        }


        DataSet dsNewSdiDataItem = addReplicate(sampleID, replicates);
        if (dsNewSdiDataItem != null && dsNewSdiDataItem.size() > 0) {
            addTechnologist(dsNewSdiDataItem, technologist);// with new replicate id
        }

    }


    private DataSet addReplicate(String sampleID, String maxReplicateID) throws SapphireException {

        String sql = Util.parseMessage(FishPortalSql.GET_DATASET_BY_KEYID1, StringUtil.replaceAll(sampleID, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.getRowCount() == 0) {
            throw new SapphireException("No DataSet found..");
        }


        PropertyList pl = new PropertyList();
        pl.setProperty(AddReplicate.PROPERTY_SDCID, "Sample");
        pl.setProperty(AddReplicate.PROPERTY_KEYID1, ds.getColumnValues("keyid1", ";"));
        pl.setProperty(AddReplicate.PROPERTY_PARAMLISTID, ds.getColumnValues("paramlistid", ";"));
        pl.setProperty(AddReplicate.PROPERTY_PARAMLISTVERSIONID, ds.getColumnValues("paramlistversionid", ";"));
        pl.setProperty(AddReplicate.PROPERTY_VARIANTID, ds.getColumnValues("variantid", ";"));
        pl.setProperty(AddReplicate.PROPERTY_PARAMID, ds.getColumnValues("paramid", ";"));
        pl.setProperty(AddReplicate.PROPERTY_PARAMTYPE, ds.getColumnValues("paramtype", ";"));
        pl.setProperty(AddReplicate.PROPERTY_DATASET, ds.getColumnValues("dataset", ";"));

        pl.setProperty(AddReplicate.PROPERTY_NUMREPLICATE, StringUtil.repeat("1", ds.getRowCount(), ";"));
        pl.setProperty(AddReplicate.PROPERTY_PROPSMATCH, "Y");

        try {

            getActionProcessor().processAction(AddReplicate.ID, AddReplicate.VERSIONID, pl);

        } catch (SapphireException e) {
            throw new SapphireException("can't add new technologist:" + e.getMessage());
        }

        //return new DataSet with new replicate id
        sql =
                Util.parseMessage(FishPortalSql.GET_DATASET_WITH_LATEST_REPLICATE, StringUtil.replaceAll(sampleID, ";", "','"),
                        (Integer.parseInt(maxReplicateID) + 1));

        DataSet dsDataItem = getQueryProcessor().getSqlDataSet(sql);
        return dsDataItem;
    }

    private void addTechnologist(DataSet dsDataItem, String technologist) throws SapphireException {
        if (dsDataItem == null && dsDataItem.getRowCount() == 0) {
            return;
        }

        DataSet dsTechnologist = new DataSet();
        dsTechnologist.addColumn("sdidataid", DataSet.STRING);
        dsTechnologist.addColumn("technologistid", DataSet.STRING);
        dsTechnologist.addColumn("lvtestcodeid", DataSet.STRING);
        dsTechnologist.addColumn("replicateid", DataSet.STRING);
        dsTechnologist.addColumn("accessionid", DataSet.STRING);
        dsTechnologist.addColumn("reportflag", DataSet.STRING);

        //For each dataitem we will assign the technologist
        dsDataItem.sort("sdidataid");
        ArrayList<DataSet> dsDataItemGroup = dsDataItem.getGroupedDataSets("sdidataid");
        for (int i = 0; i < dsDataItemGroup.size(); i++) {

            DataSet dsIndividualGroup = (DataSet) dsDataItemGroup.get(i);
            if (dsIndividualGroup == null || dsIndividualGroup.size() == 0) {
                logger.info(i + "th rows don't have any methodology");
                continue;
            }
            int rowid = dsTechnologist.addRow();
            dsTechnologist.setValue(rowid, "sdidataid", dsIndividualGroup.getValue(0, "sdidataid", ""));
            dsTechnologist.setValue(rowid, "technologistid", technologist);
            dsTechnologist.setValue(rowid, "lvtestcodeid", dsIndividualGroup.getValue(0, "lvtestcodeid", ""));
            dsTechnologist.setValue(rowid, "replicateid", dsIndividualGroup.getValue(0, "replicateid", ""));
            dsTechnologist.setValue(rowid, "accessionid", dsIndividualGroup.getValue(0, "u_accessionid", ""));
            dsTechnologist.setValue(rowid, "reportflag", "Y");
        }

        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "TechnologistMap");
        prop.setProperty("sdidataid", dsTechnologist.getColumnValues("sdidataid", ";"));
        prop.setProperty("technologistid", dsTechnologist.getColumnValues("technologistid", ";"));
        prop.setProperty("lvtestcodeid", dsTechnologist.getColumnValues("lvtestcodeid", ";"));
        prop.setProperty("replicateid", dsTechnologist.getColumnValues("replicateid", ";"));
        prop.setProperty("accessionid", dsTechnologist.getColumnValues("accessionid", ";"));
        prop.setProperty("reportflag", dsTechnologist.getColumnValues("reportflag", ";"));
        prop.setProperty(AddSDI.PROPERTY_COPIES, "" + dsTechnologist.getRowCount());
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);


    }

    private void addParamInDataSet(PropertyList properties) throws SapphireException {


        String sampleID = properties.getProperty("sampleid", "");
        String lvtestCodeID = properties.getProperty("lvtestcodeid", "");
        String paramID = properties.getProperty("clasificationid", "");
        String paramDesc = properties.getProperty("clasificationdesc", "");

        String sql = Util.parseMessage(FishPortalSql.GET_PARAM_ID, paramID);
        DataSet dsParam = getQueryProcessor().getSqlDataSet(sql);
        PropertyList pl = new PropertyList();

        if (dsParam.getRowCount() > 0) {
            //if Param id already exists change the the description and return
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Param");
            pl.setProperty("keyid1", paramID);
            pl.setProperty("paramdesc", paramDesc);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            return;
        }

        pl.clear();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "Param");
        pl.setProperty(AddSDI.PROPERTY_KEYID1, paramID);
        pl.setProperty("paramdesc", paramDesc);
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        pl.setProperty("createtool", "fish_portal");
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add param. Error: " + ex.getMessage());
        }

        sql = Util.parseMessage(FishPortalSql.GET_DATAITEM, sampleID, lvtestCodeID);
        DataSet dsSdiData = getQueryProcessor().getSqlDataSet(sql);
        if (dsSdiData.getRowCount() == 0) {
            throw new SapphireException("No DataSet found. please add test.");
        }

        String replicates = Util.getUniqueList(dsSdiData.getColumnValues("replicateid", ";"), ";", true);
        String paramListID = Util.getUniqueList(dsSdiData.getColumnValues("paramlistid", ";"), ";", true);
        String replicateArr[] = StringUtil.split(replicates, ";");

        PropertyList plExtendDataSet = new PropertyList();
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_SDCID, "Sample");
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_KEYID1, sampleID);
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_PARAMLISTID, paramListID);
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_PARAMID, paramID);
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_VARIANTID, "1");
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_DATASET, "1");
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_PARAMTYPE, "Standard");
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_NUMREPLICATE, "" + replicateArr.length);
        plExtendDataSet.setProperty(ExtendDataSet.PROPERTY_PROPSMATCH, "Y");
        try {
            getActionProcessor().processAction(ExtendDataSet.ID, ExtendDataSet.VERSIONID, plExtendDataSet);
        } catch (ActionException e) {
            throw new SapphireException("Error Occured While adding extended dataset:: " + e.getMessage());
        }

    }


    private void saveISCNResult(PropertyList properties) throws SapphireException {
        String sampleID = properties.getProperty("sampleid", "");
        String lvtestcode = properties.getProperty("lvtestcodeid", "");
        String iscnresult = properties.getProperty("iscnresult", "");
        String result = properties.getProperty("result", "");
        String scoringmethod = properties.getProperty("scoringmethod", "");
        String probeinterpretation = properties.getProperty("probeinterpretation", "");
        String displayscoreinreport = properties.getProperty("displayscoreinreport", "");

        String sampleIDArr[] = StringUtil.split(sampleID, ";");

        String sql = Util.parseMessage(FishPortalSql.GET_KEYID1_ISCN_RESULT, sampleID, lvtestcode);
        DataSet dsISCNResult = getQueryProcessor().getSqlDataSet(sql);
        PropertyList prop1 = new PropertyList();

        if (dsISCNResult.getRowCount() > 0) {
            //if ISCNResult id already existsthen update the data
            prop1.clear();
            prop1.setProperty(EditSDI.PROPERTY_SDCID, "ISCNResult");
            prop1.setProperty("keyid1", dsISCNResult.getValue(0, "u_iscnresultid", ""));
            prop1.setProperty("iscnresult", iscnresult);
            prop1.setProperty("result", result);
            prop1.setProperty("scoringmethod", scoringmethod);
            prop1.setProperty("probeinterpretation", probeinterpretation);
            prop1.setProperty("displayscoreinreport", displayscoreinreport);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop1);
            return;
        }


        prop1.setProperty(AddSDI.PROPERTY_SDCID, "ISCNResult");
        prop1.setProperty(AddSDI.PROPERTY_COPIES, "" + sampleIDArr.length);
        prop1.setProperty("sampleid", sampleID);
        prop1.setProperty("lvtestcodeid", lvtestcode);
        prop1.setProperty("iscnresult", iscnresult);
        prop1.setProperty("result", result);
        prop1.setProperty("scoringmethod", scoringmethod);
        prop1.setProperty("probeinterpretation", probeinterpretation);
        prop1.setProperty("displayscoreinreport", displayscoreinreport);

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop1);

    }
}
