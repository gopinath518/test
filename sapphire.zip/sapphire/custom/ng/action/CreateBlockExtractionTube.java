package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Action Name- CreateBlockExtractionTube
 * Description: This Action is use create extraction tube for blocks
 * input :-
 * param1-hnesample
 * param2-testslide
 * throws SapphireException
 * Created by mpandey on 9/12/2016.
 * Modified by surajit
 */
public class CreateBlockExtractionTube extends BaseAction {
    String input_requestID = "";
    String input_hneSampleId = "";
    String input_unStainedSlide = "";
    DataSet dsTestSlides = null;
    String extractionType = "";
    String sampleType = "";
    String sampleInfo = "";
    String allUnstainSlide = "";
    String ffpeextractiontype = "";
    String isHNEScanned = "";
    Boolean isclienthne = false;
    public static final String MSITESTCODE = "4047X";
    public static final String CHIMERISMTESTCODE = "4079X";

    public void processAction(PropertyList properties) throws SapphireException {

        ffpeextractiontype = properties.getProperty("ffpeextractiontype", "");
        input_hneSampleId = properties.getProperty("hnesample", "");
        input_unStainedSlide = properties.getProperty("testslide", "");
        isHNEScanned = properties.getProperty("ishnescanned", "");
        isclienthne = Boolean.valueOf(properties.getProperty("isclienthne", "false"));
        //if (!Util.isNull(input_hneSampleId) && !Util.isNull(input_unStainedSlide)) {
        if (("Y".equalsIgnoreCase(isHNEScanned) && !Util.isNull(input_hneSampleId)) && !Util.isNull(input_unStainedSlide)) {
            dsTestSlides = getAllSlidesNInfo(input_hneSampleId, input_unStainedSlide);
            validateInput(dsTestSlides);
            if (allUnstainSlide.length() > 0)
                checkForRequestId(allUnstainSlide);

        } else if (!"Y".equalsIgnoreCase(isHNEScanned) && !Util.isNull(input_unStainedSlide)) {
            dsTestSlides = getAllSlidesNWOHNEInfo(input_unStainedSlide);
            validateInput(dsTestSlides);
            if (allUnstainSlide.length() > 0)
                checkForRequestId(allUnstainSlide);
        } else {
            String error = getTranslationProcessor().translate("Blank input found.Please provide some value.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        //Checking Conditions to route flow
        String newsampleid = routingFlow();
        //updateTrackitem(newsampleid);

        if (!Util.isNull(input_hneSampleId)) {
            copyDownPathologyProperty(newsampleid, input_hneSampleId);
        }
        //if (!Util.isNull(ffpeextractiontype)) {//TODO IMPLEMENTING TNA WORKFLOW
        if (!"TNA".equalsIgnoreCase(ffpeextractiontype)) {
            String allExtslide = StringUtil.replaceAll(newsampleid, ";", "','");
            String sql = Util.parseMessage(MolecularSql.GETSAMPLETESTCODEMAPINFO_BY_SAMPLEID, allExtslide);
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampletestcodemapid", ";"));
            prop.setProperty("extractiontype", StringUtil.repeat(ffpeextractiontype, ds.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }
        labelPrint(newsampleid);
        properties.put("newkeyid1", newsampleid);

    }

    /**
     * This method is use to check for request id if any for a sample.
     *
     * @param dsTestSlides
     * @throws SapphireException
     */
    private void checkForRequestId(String dsTestSlides) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.REPEATOPSINFO_BY_SAMPLEID, allUnstainSlide.replaceAll(";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null) {
            String error = "Something error occured. Please contact your Administrator.";
            error += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (ds.size() > 1)
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Multiple requestId found in Extraction Tube to Re-Extract.");
        input_requestID = ds.getValue(0, "incidentrequestid", "");
    }

    /**
     * This method is use to validate inputs .
     *
     * @param dsTestSlides
     * @throws SapphireException
     */
    private void validateInput(DataSet dsTestSlides) throws SapphireException {

        HashMap hmFilter = new HashMap();
        if (isclienthne)
            hmFilter.put("u_type", "CH");
        else
            hmFilter.put("u_type", "H");
        DataSet dsFiltered = dsTestSlides.getFilteredDataSet(hmFilter);

        //if (dsFiltered.size() == 0 || !dsFiltered.getValue(0, "s_sampleid").equalsIgnoreCase(input_hneSampleId)) {
        if ("Y".equalsIgnoreCase(isHNEScanned) && (dsFiltered.size() == 0 || !dsFiltered.getColumnValues("s_sampleid", ";").contains(input_hneSampleId))) {
            String error = getTranslationProcessor().translate("H&E can't be blank/You have scanned a wrong H&E.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        hmFilter.clear();
        if (isclienthne)
            hmFilter.put("u_type", "CU");
        else
            hmFilter.put("u_type", "U");
        dsFiltered.clear();
        dsFiltered = dsTestSlides.getFilteredDataSet(hmFilter);
        allUnstainSlide = dsFiltered.getColumnValues("s_sampleid", ";");
        if (allUnstainSlide.length() == 0) {
            hmFilter.clear();
            hmFilter.put("u_type", "FB");
            dsFiltered.clear();
            dsFiltered = dsTestSlides.getFilteredDataSet(hmFilter);
            allUnstainSlide = dsFiltered.getColumnValues("s_sampleid", ";");
        }
        allUnstainSlide = Util.getUniqueList(allUnstainSlide, ";", true);

        //extractionType = dsTestSlides.getColumnValues("extractiontype", ";");
        extractionType = getExtractionTypeFromUSS();
        extractionType = Util.getUniqueList(extractionType, ";", true);

        /*if (extractionType.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Samples have more than one extraction type ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }*/
        if (extractionType.length() == 0) {
            String error = getTranslationProcessor().translate("Extraction type is not defined for Samples");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        sampleType = dsTestSlides.getColumnValues("sampletypeid", ";");
        sampleType = Util.getUniqueList(sampleType, ";", true);
        if (sampleType.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Sample have more then one sample type ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        sampleInfo = dsTestSlides.getColumnValues("u_sampleinformation", ";");
        sampleInfo = Util.getUniqueList(sampleInfo, ";", true);
        if (sampleInfo.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Samples have more then one sample information");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }


    }

    private String getExtractionTypeFromUSS() throws SapphireException {
        String extractiontyep = "";//input_unStainedSlide
        String sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_TYPE_BY_USS, input_unStainedSlide);
        DataSet dsExt = getQueryProcessor().getSqlDataSet(sql);
        extractiontyep = Util.getUniqueList(dsExt.getColumnValues("extractiontype", ";"), ";", true);
        return extractiontyep;
    }

    /**
     * This method is use to update track item .
     *
     * @param childsampleid
     * @throws SapphireException
     */
    private void updateTrackitem(String childsampleid) throws SapphireException {

        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        /*String site = defaultdepartment.substring(0,defaultdepartment.indexOf("-"));
        String custodialDepartment = site + "-Molecular";*/

        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", "Extraction Tube");
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", defaultdepartment);
        props.setProperty("u_currenttramstop", "MolecularExtraction");
        // props.setProperty("custodytakendt", "n");
        // props.setProperty("qtycurrent", volume);
        // props.setProperty("qtyunits", units);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }


    /**
     * This function is use to update the pathology property of hne to extraction tube .
     *
     * @param extractionTubeSampleID
     * @param hneSampleID
     * @throws SapphireException
     */

    private void copyDownPathologyProperty(String extractionTubeSampleID, String hneSampleID) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLEINFO_BY_SAMPLEID_MANULA, StringUtil.replaceAll(hneSampleID, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null) {
            String error = "Something error occured. Please contact your Administrator.";
            error += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        if (ds.getRowCount() == 0) {
            return;
        }

        PropertyList props = new PropertyList();
        props.setProperty("sdcid", "Sample");
        props.setProperty("keyid1", extractionTubeSampleID);
        props.setProperty("u_tumorcircled", ds.getValue(0, "u_tumorcircled", ""));
        props.setProperty("u_totaltumor", ds.getValue(0, "u_totaltumor", ""));
        props.setProperty("u_pathologycomments", ds.getValue(0, "u_pathologycomments", ""));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException e) {
            String error = getTranslationProcessor().translate("Cannot update %tumor circled ");
            error += "\n" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

    }

    /**
     * This method redirect the flow depending on sample information.
     *
     * @return
     * @throws SapphireException
     */
    private String routingFlow() throws SapphireException {
        String newsampleid = "";

        if (sampleInfo.equalsIgnoreCase("Tumor/Normal"))
            newsampleid = createExtractionForNormalTumor(allUnstainSlide, extractionType, sampleInfo);
        else if (sampleInfo.equalsIgnoreCase("Normal") || sampleInfo.equalsIgnoreCase("Tumor") || sampleInfo.equalsIgnoreCase("Donor") || sampleInfo.equalsIgnoreCase("Recipient"))
            newsampleid = createSampleInfoExtractionTube(allUnstainSlide, extractionType, sampleInfo);
        else
            newsampleid = createExtractionTube(allUnstainSlide, extractionType, sampleInfo);

        return newsampleid;
    }

    /**
     * This method is use to create extraction tube .
     *
     * @param parentsampleid
     * @param extractionType
     * @param sampleInfo
     * @return
     * @throws SapphireException
     */
    private String createExtractionTube(String parentsampleid, String extractionType, String sampleInfo) throws SapphireException {
        int poolcopies = 1;
        String newsampleid = "";
        newsampleid = createPoolSample(parentsampleid, poolcopies, extractionType);
        editSampleSDI(newsampleid, parentsampleid, sampleInfo);
        updateTrackitem(newsampleid);
        //if (!Util.isNull(ffpeextractiontype)) {
        if (!"TNA".equalsIgnoreCase(ffpeextractiontype)) {
            Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor(), "Molecular");
        } else {
            copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor(), extractionType);//TODO IT WAS BEFORE
        }

        String extractionid = "";
        if (input_requestID.length() > 0) {
            extractionid = getReExtractExtractionId(input_requestID);
            if (extractionid.length() > 0)
                updateExtractionID(newsampleid, extractionid);
            closeRequest(input_requestID, extractionid);
        } else {
            createExtractionID(newsampleid, extractionType, "");
        }
        return newsampleid;
    }

    public static void copyTestCodeFromParent(String childSampleID, QueryProcessor qp, ActionProcessor ap, String extractiontype) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.COPY_TC_FROM_PARENT, StringUtil.replaceAll(childSampleID, ";", "','"), extractiontype);
        DataSet dsChildTestCode = qp.getSqlDataSet(sql);
        if (dsChildTestCode == null || dsChildTestCode.size() == 0) {
            return;
        }
        DataSet dsAddTestCodes = new DataSet();
        dsAddTestCodes.addColumn("childsampleid", DataSet.STRING);
        dsAddTestCodes.addColumn("testcodeid", DataSet.STRING);//This can be panelcode/testcode
        dsAddTestCodes.addColumn("testpanelcodeid", DataSet.STRING);// this is panel code if above is testcode

        dsChildTestCode.sort("childsampleid");
        ArrayList groupByChildArray = dsChildTestCode.getGroupedDataSets("childsampleid");

        HashMap hmFilter = new HashMap();
        String abc = "";
        for (int i = 0; i < groupByChildArray.size(); i++) {
            DataSet dsEach = (DataSet) groupByChildArray.get(i); // This can be mix of panel & testcode

            String eachChildSampleForPanel = "";
            String lvTestPanelCode = "";
            String lvTestCode = "";
            String lvPanelForTestCode = "";
            String eachChildSampleForTestCode = "";

            if (dsEach != null && dsEach.size() > 0) {
                eachChildSampleForTestCode = Util.getUniqueList(dsEach.getColumnValues("childsampleid", ";"), ";", true);//This will be only one test code
                lvTestCode = Util.getUniqueList(dsEach.getColumnValues("lvtestcodeid", ";"), ";", true);
                int noOfTestCodes = StringUtil.split(lvTestCode, ";").length;

                lvPanelForTestCode = StringUtil.repeat(Util.getUniqueList(dsEach.getColumnValues("lvtestpanelid", ";"), ";", true), noOfTestCodes, ";");
                eachChildSampleForTestCode = StringUtil.repeat(eachChildSampleForTestCode, noOfTestCodes, ";");
            }

            int rowID = dsAddTestCodes.addRow();
            dsAddTestCodes.setValue(rowID, "childsampleid", eachChildSampleForTestCode);
            dsAddTestCodes.setValue(rowID, "testcodeid", lvTestCode);
            dsAddTestCodes.setValue(rowID, "testpanelcodeid", lvPanelForTestCode);

        }


        String aSample = "";
        String aTestCodes = "";
        String aTestPanelCodes = "";
        for (int i = 0; i < dsAddTestCodes.getRowCount(); i++) {
            aSample += ";" + dsAddTestCodes.getValue(i, "childsampleid");
            aTestCodes += ";" + dsAddTestCodes.getValue(i, "testcodeid");
            aTestPanelCodes += ";" + dsAddTestCodes.getValue(i, "testpanelcodeid");
        }
        aSample = aSample.substring(1);
        aTestCodes = aTestCodes.substring(1);
        aTestPanelCodes = aTestPanelCodes.substring(1);

        PropertyList pl = new PropertyList();
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, aSample);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, aTestCodes);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, aTestPanelCodes);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
        ap.processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);


    }

    /**
     * This fuction is use to create extraction tube if sample information have some value.
     *
     * @param parentsampleid
     * @param extractionType
     * @param sampleInfo
     * @return
     * @throws SapphireException
     */

    private String createSampleInfoExtractionTube(String parentsampleid, String extractionType, String sampleInfo) throws SapphireException {
        int poolcopies = 1;
        String newsampleid = "";
        String extractionid = "";
        newsampleid = createPoolSample(parentsampleid, poolcopies, extractionType);
        editSampleSDI(newsampleid, parentsampleid, sampleInfo);
        updateTrackitem(newsampleid);
        Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor(), "Molecular");
        // isSacraped(parentsampleid);

        if (input_requestID.length() > 0) {
            extractionid = getReExtractExtractionId(input_requestID);
            if (extractionid.length() > 0) {
                updateExtractionID(newsampleid, extractionid);
                closeRequest(input_requestID, extractionid);
            }
        } else {
            String extractionIdOnCond = getExtIdOnSpecialCond(newsampleid, extractionType, sampleInfo);
            if (extractionIdOnCond.length() == 0)
                createExtractionID(newsampleid, extractionType, "");
        }

        return newsampleid;
    }

    /**
     * This method is use to close a open request if request has been  catered.
     *
     * @param input_requestID
     * @param extractionid
     * @throws SapphireException
     */
    private void closeRequest(String input_requestID, String extractionid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.REPEATOPS_BY_REQUESTID, input_requestID);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "RepeatOps");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getValue(0, "u_repeatopsid"));
            pl.setProperty("extractionid", extractionid);//todo for reextraction
            pl.setProperty("ispending", "N");

            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (SapphireException ex) {
                String error = getTranslationProcessor().translate("Ispending id not updated for reuestid: " + input_requestID);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }

        }
    }

    /**
     * This method is use to create extraction tube for a sample with information "Normal/Tumor".
     *
     * @param parentsampleid
     * @param extractionType
     * @param sampleInfo
     * @return
     * @throws SapphireException
     */
    private String createExtractionForNormalTumor(String parentsampleid, String extractionType, String sampleInfo) throws SapphireException {
        int poolcopies = 2;
        String newsampleid = "";
        newsampleid = createPoolSample(parentsampleid, poolcopies, extractionType);
        editSampleSDI(newsampleid, parentsampleid, sampleInfo.replace("/", ";"));
        //TODO AS PER LITO,ONLY MSI WILL BE ADDED FOR NORMAL SAMPLE, AND TESTCODE(S) OF PARENT WILL BE ADDED INTO TUMOR SAMPLE
        boolean checkMSI = checkMSIValidation(parentsampleid);
        if (checkMSI) {
            String tumorsample = StringUtil.split(newsampleid, ";")[0];
            String normalsample = StringUtil.split(newsampleid, ";")[1];
            updateTrackitem(newsampleid);
            Util.copyTestCodeFromParent(tumorsample, getQueryProcessor(), getActionProcessor(), "Molecular");
            PropertyList pl = new PropertyList();
            pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, normalsample);
            pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, "4047X");
            pl.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
        } else {
            updateTrackitem(newsampleid);
            Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor(), "Molecular");
        }
        //Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor());
        // isSacraped(parentsampleid);
        String reExtractionid = "";
        if (input_requestID.length() > 0) {
            reExtractionid = getReExtractExtractionId(input_requestID);
            if (reExtractionid.length() > 0) {
                updateExtractionID(newsampleid, StringUtil.repeat(reExtractionid, 2, ";"));
                closeRequest(input_requestID, reExtractionid);
            }
        } else {
            String newExtractionId = createExtractionID(newsampleid.split(";")[0], extractionType, "T");
            // String extractionIdOnCond = getExtIdOnSpecialCond(newsampleid.split(";")[1], "Tumor/Normal");
            String extractionIdOnCond = newExtractionId.substring(0, newExtractionId.length() - 1) + "N";
            if (extractionIdOnCond.length() > 0)
                updateExtractionID(newsampleid.split(";")[1], extractionIdOnCond);
        }
        return newsampleid;
    }

    private boolean checkMSIValidation(String parentsampleid) throws SapphireException {
        //TODO MST TESTCODE (4047X)
        String sql = Util.parseMessage(MolecularSql.GET_TESTS_BY_ELUTIONTUBE, StringUtil.replaceAll(parentsampleid, ";", "','"));
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample != null && dsSample.size() > 0) {
            HashMap hm = new HashMap();
            hm.put("lvtestcodeid", "4047X");
            DataSet dsFilter = dsSample.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method is use to create extraction id for a tube.
     *
     * @param newsampleid
     * @param extractionType
     * @param sampleInfo
     * @return
     * @throws SapphireException
     */
    private String createExtractionID(String newsampleid, String extractionType, String sampleInfo) throws SapphireException {

        PropertyList hsCreateExtractionID = new PropertyList();
        hsCreateExtractionID.clear();
        hsCreateExtractionID.setProperty("sampleid", newsampleid);
        hsCreateExtractionID.setProperty("extractiontype", extractionType);
        hsCreateExtractionID.setProperty("suffix", sampleInfo);

        try {
            getActionProcessor().processAction("CreateExtractionID", "1", hsCreateExtractionID);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed CreateExtractionID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        return hsCreateExtractionID.getProperty("extractionid", "");
    }

    /**
     * This method is use get extraction id on some special conditions.
     *
     * @param newsampleid
     * @param extractiontype
     * @param sampleInfo
     * @return
     * @throws SapphireException
     */
    private String getExtIdOnSpecialCond(String newsampleid, String extractiontype, String sampleInfo) throws SapphireException {
        String newExtractionId = "";
        String tail = "";
        String lvtestcode = "";
        String pairSampleInfo = "";
        if (sampleInfo.equalsIgnoreCase("Normal")) {
            tail = "N";
            lvtestcode = MSITESTCODE;
            pairSampleInfo = "Tumor";
        } else if (sampleInfo.equalsIgnoreCase("Tumor")) {
            tail = "T";
            lvtestcode = MSITESTCODE;
            pairSampleInfo = "Normal";
        } else if (sampleInfo.equalsIgnoreCase("Donor")) {
            tail = "D";
            lvtestcode = CHIMERISMTESTCODE;
            pairSampleInfo = "Recipient";
        } else if (sampleInfo.equalsIgnoreCase("Recipient")) {
            tail = "RC";
            lvtestcode = CHIMERISMTESTCODE;
            pairSampleInfo = "Donor";
        }
        String sql = Util.parseMessage(MolecularSql.SAMPLETESTCODEMAPCOUNT, lvtestcode, newsampleid);
        DataSet dsTest = getQueryProcessor().getSqlDataSet(sql);
        if (dsTest == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String s_sql = Util.parseMessage(MolecularSql.GET_SAMPLEINFO_BY_SAMPLEID_CRT_EXT, lvtestcode, newsampleid, pairSampleInfo, lvtestcode);
        DataSet dsext = getQueryProcessor().getSqlDataSet(s_sql);
        if (dsext == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + s_sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        if (dsext.size() > 0 && Integer.parseInt(dsTest.getValue(0, "testcount", "0")) > 0) {
            String[] arrExtId = dsext.getValue(0, "u_extractionid", "").split("-");
            if (arrExtId.length > 1)
                newExtractionId = arrExtId[0] + "-" + arrExtId[1] + "-" + tail;
            updateExtractionID(newsampleid, newExtractionId);
            return newExtractionId;
        } else if (dsext.size() == 0 && Integer.parseInt(dsTest.getValue(0, "testcount", "0")) > 0) {
            newExtractionId = createExtractionID(newsampleid, extractiontype, tail);
            return newExtractionId;
        }
        return "";
    }

    /**
     * This Function is use to update Extraction id in sample sdi.
     *
     * @param sample
     * @param extractionid
     * @throws SapphireException
     */
    private void updateExtractionID(String sample, String extractionid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sample);
        pl.setProperty("u_extractionid", extractionid);
        pl.setProperty("u_currentmovementstep", "MolecularExtraction");

        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Extraction id not updated for " + sample);
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

    }

    /**
     * This function is use mark a sample as re Extracted
     * by updating its extractionid
     *
     * @param requestid
     * @return
     */
    private String getReExtractExtractionId(String requestid) throws SapphireException {
        String ExtractionId = "";
        String rxSuffix = "RX";
        String reExtractCount = "";
        String sql = Util.parseMessage(MolecularSql.REPEATOPS_DETAIL_INFO, requestid);
        DataSet dsRepeat = getQueryProcessor().getSqlDataSet(sql);
        if (dsRepeat == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsRepeat.size() == 0) {
            String error = getTranslationProcessor().translate("Invalid Request Id. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        if (dsRepeat.size() > 0 && dsRepeat != null) {
            ExtractionId = dsRepeat.getValue(0, "orgextractionid");
            reExtractCount = String.valueOf(dsRepeat.getRowCount());
            if (dsRepeat.size() == 1)
                ExtractionId = ExtractionId + "-" + rxSuffix;
            else
                ExtractionId = ExtractionId + "-" + reExtractCount + rxSuffix;
        }
        return ExtractionId;
    }

    /**
     * This fuction is use to mark a sample as scrapped .
     *
     * @param parentsampleid
     * @throws SapphireException
     */

    private void isSacraped(String parentsampleid) throws SapphireException {
        PropertyList propEditSDI = new PropertyList();
        propEditSDI.setProperty("sdcid", "Sample");
        propEditSDI.setProperty("keyid1", parentsampleid);
        propEditSDI.setProperty("u_isscrap", "Y");


        try {
            getActionProcessor().processAction("EditSDI", "1", propEditSDI);
        } catch (ActionException e) {
            String error = getTranslationProcessor().translate("Please select atleast a sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /**
     * This function is use to update information of newly created sample.
     *
     * @param newsampleid
     * @param parentsampleid
     * @param sampleinfo
     * @throws SapphireException
     */
    private void editSampleSDI(String newsampleid, String parentsampleid, String sampleinfo) throws SapphireException {
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = Util.parseMessage(MolecularSql.SAMPLE_INFO_BY_SAMPLEID, qrsample);
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sql);

        if (dsSamp.size() == 0) {
            String error = getTranslationProcessor().translate("Sample must belongs to same accesion ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, newsampleid);
        editProp.setProperty("u_accessionid", StringUtil.repeat(dsSamp.getValue(0, "u_accessionid", ""), newsampleid.split(";").length, ";"));
        editProp.setProperty("u_sampleinformation", sampleinfo);
        editProp.setProperty("u_clientspecimenid", StringUtil.repeat(dsSamp.getValue(0, "u_clientspecimenid", ""), newsampleid.split(";").length, ";"));
        //TODO AS EXTRACTION TUBE WILL BE LISTED INTO EXTRACTION LIST PAGE
        editProp.setProperty("u_currentmovementstep", StringUtil.repeat(dsSamp.getValue(0, "u_currentmovementstep", ""), newsampleid.split(";").length, ";"));
        //editProp.setProperty("u_currentmovementstep", StringUtil.repeat("MolecularExtraction", newsampleid.split(";").length, ";"));

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This function is use to create pool sample
     *
     * @param parentsampleid
     * @param poolcopies
     * @return
     * @throws SapphireException
     */

    private String createPoolSample(String parentsampleid, int poolcopies, String extractionType) throws SapphireException {

        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "";
        if (isclienthne) {
            sql = Util.parseMessage(MolecularSql.TI_INFO_BY_SAMPLEID, qrsample);
        } else {
            sql = Util.parseMessage(MolecularSql.TRACKITEM_INFO_BY_SAMPLEID, qrsample);
        }
        DataSet dstrack = getQueryProcessor().getSqlDataSet(sql);

        if (dstrack.size() == 0) {
            String error = getTranslationProcessor().translate("Trackitem is not defined for sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (!isclienthne) {
            parentsampleid = Util.getUniqueList(dstrack.getColumnValues("sourcesampleid", ";"), ";", true);
        }
        PropertyList props = new PropertyList();
        String newkeyid1;
        props.setProperty("sampleid", parentsampleid);

        DataSet dsExtractionPrefix = Util.getExtractionPrefix(getConfigurationProcessor());
        if (dsExtractionPrefix == null || dsExtractionPrefix.size() == 0) {
            throw new SapphireException("Extraction Prefix Policy not define into system.");
        }
        HashMap hmprefix = new HashMap();
        hmprefix.clear();
        hmprefix.put("extractiontype", extractionType);
        DataSet dsExtractionFilter = dsExtractionPrefix.getFilteredDataSet(hmprefix);
        String samplevolume = dsExtractionFilter.getValue(0, "samplevolume", "10");
        props.setProperty("poolquantity", samplevolume);
        props.setProperty("poolcopies", String.valueOf(poolcopies));
        //props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        //props.setProperty("poolcustodialdepartmentid", connectionInfo.getDefaultDepartment()); //todo

        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        newkeyid1 = props.getProperty("newkeyid1", "");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        if (!isclienthne)
            Util.setRootForPoolSample(newkeyid1, parentsampleid, getTranslationProcessor(), getActionProcessor());
        else
            Util.setRootForClientSampleChildren(newkeyid1, parentsampleid, getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        return newkeyid1;
    }

    /**
     * This function is use to get all siblings test slides of
     * provided hne and a unstained slides
     *
     * @param hneSampleID
     * @param testSlide
     * @return
     * @throws SapphireException
     */
    private DataSet getAllSlidesNInfo(String hneSampleID, String testSlide) throws SapphireException {
        String sql = "";
        if (isclienthne) {
            sql = Util.parseMessage(MolecularSql.GET_CLIENT_SLD_INFO_CRT_EXT, hneSampleID, testSlide);
        } else {
            sql = Util.parseMessage(MolecularSql.GET_BLOCK_SLD_INFOCRT_EXT, hneSampleID);
        }
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = " Something wrong happened. Contact your Administrator.";
            err += "\n Sql Failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.getRowCount() == 0) {
            String err = "Provided Samples does not exists";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        return ds;
    }

    private DataSet getAllSlidesNWOHNEInfo(String testSlide) throws SapphireException {
        String sql = "";
        if (isclienthne) {
            sql = Util.parseMessage(MolecularSql.GET_CLIENT_SLD_INFO_CRT_EXT_WOH, testSlide);
        } else {
            sql = Util.parseMessage(MolecularSql.GET_BLOCK_SLD_INFOCRT_EXT_WOH, testSlide);
        }

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = " Something wrong happened. Contact your Administrator.";
            err += "\n Sql Failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.getRowCount() == 0) {
            String err = "Provided Samples does not exists";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        return ds;
    }

    /**
     * Description : Added for lable print.
     *
     * @param newkeyid1
     * @throws SapphireException
     */
    private void labelPrint(String newkeyid1) throws SapphireException {
        String sqlExTube = Util.parseMessage(MolecularSql.LABEL_PRINT_CRT_EXT, StringUtil.replaceAll(newkeyid1, ";", "','"));
        DataSet dsExTube = getQueryProcessor().getSqlDataSet(sqlExTube);
        if (dsExTube == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlExTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsExTube.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample Type not found.");
            errMsg += "\nQuery returns zero rows:" + sqlExTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        for (int i = 0; i < dsExTube.size(); i++) {
            String sample = dsExTube.getValue(i, "s_sampleid", "");
            if (Util.isNull(sample)) {
                String errMsg = getTranslationProcessor().translate("Sample id not found.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }

            String extractiontype = dsExTube.getValue(i, "extractiontype", "");
            if (Util.isNull(extractiontype)) {
                String errMsg = getTranslationProcessor().translate("Extraction type not found for sample:" + sample);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
        }
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, dsExTube.getColumnValues("s_sampleid", ";"));
        props.setProperty(PrintLabel.EXTRACTION_TYPE, Util.getUniqueList(dsExTube.getColumnValues("extractiontype", ";"), ";", true));//added
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Molecular");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, "ExtractionTube");
        props.setProperty(PrintLabel.TRAMLINE_PROP, "Extraction");
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }
}
