package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.RecordIncident;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by aritra.banerjee on 7/19/2017.
 * Input Props : Fresh prep sample ID & client testcode ID as TestCode.
 */
public class AddReflexTest extends BaseAction {

    private static final String FRESH_PREP_SAMPLE = "sampleid";
    private static final String TEST_CODE_PROP= "clienttestcodeid";

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty(FRESH_PREP_SAMPLE);
        String testcode = properties.getProperty(TEST_CODE_PROP);
        /**
         * PARENT_INFO_OF_ORGSAMPLE query provides the Original/Patient sampleid of the input sampleids
         */
        String sql = Util.parseMessage(CytoSqls.PARENT_INFO_OF_ORGSAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null)
            throw new SapphireException("Error: Unable to execute sql..: "+sql);
        else if (ds.size() == 0)
            throw new SapphireException("Error: Unable to fetch Patient Sample information.. ");
        else
            sampleid = Util.getUniqueList(ds.getColumnValues("sampleid",";"), ";", true);


        if(!Util.isNull(sampleid) && !Util.isNull(testcode) ){

            /**
             * Below DataSet creates the combination of Test codes and Sample ids for AssignTestCode Action input
             */
            DataSet dssmplTCodeComb = new DataSet();
            dssmplTCodeComb.addColumn("sampleid", DataSet.STRING);
            dssmplTCodeComb.addColumn("tcode", DataSet.STRING);

            String[] sampleArr = StringUtil.split(sampleid,";");
            String[] tCodeArr = StringUtil.split(testcode,";");

            for(int i=0; i<tCodeArr.length; i++){
                for(int j=0; j<sampleArr.length; j++){
                    int rowId = dssmplTCodeComb.addRow();
                    dssmplTCodeComb.setValue(rowId, "sampleid", sampleArr[j]);
                    dssmplTCodeComb.setValue(rowId, "tcode", tCodeArr[i]);
                }
            }
            if( Util.isNull(dssmplTCodeComb.getColumnValues("sampleid",";")) || Util.isNull(dssmplTCodeComb.getColumnValues("tcode",";")) )
                throw new SapphireException("Error: Unable to create Sample TestCode combination..");

            PropertyList props = new PropertyList();
            props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dssmplTCodeComb.getColumnValues("sampleid",";"));
            props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dssmplTCodeComb.getColumnValues("tcode",";"));
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
            String sampletestcodemapid = props.getProperty("sampletestcodemapid");

            if (!Util.isNull(sampletestcodemapid)) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
                pl.setProperty("testaddonflag", "Y");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                createIncidentRequest(sampleid, testcode);

            } else
                throw new SapphireException("Error: SampleTestCodeMap Id not found..");

        } else {
            throw new SapphireException("Error: Sample Id(s) or Reflex Test code(s) are not found..");

        }
    }

    private void createIncidentRequest(String sampleid, String testcode) throws SapphireException {
        // needs to implement
        String currentUserDepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String toFinalDept = "";

        String sql = Util.parseMessage(CytoSqls.GET_TODEPT_BY_ORGSAMPLEID_FOR_INCDT_REQ, StringUtil.replaceAll(sampleid, ";", "','"));   // Getting To Dept to whom Incident Req will be generated
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds != null && ds.size() > 0){
            toFinalDept = ds.getColumnValues("todept", ";");
            sampleid = ds.getColumnValues("s_sampleid", ";");
        } else
            throw new SapphireException("Error: Unable to execute sql..: "+sql);

        if (!Util.isNull(toFinalDept) && !Util.isNull(testcode) && !Util.isNull(currentUserDepartment)) {
            PropertyList prop = new PropertyList();

            String message = "The testCode(s) " + StringUtil.replaceAll(testcode, ";", ",") + " have been added as Reflex Test to the sample(s) " + StringUtil.replaceAll(sampleid, ";", ",");

            prop.setProperty("sourcesdcid", "Sample");
            prop.setProperty("sourcekeyid1", sampleid);
            prop.setProperty("incidentcategory", "UnPlanned");
            prop.setProperty("incidentdesc", StringUtil.replaceAll(testcode, ";", ",")+" -test code(s) Has been added to Sample(s) "+StringUtil.replaceAll(sampleid, ";", ","));
            prop.setProperty("u_message", message);
            prop.setProperty("u_fromdepartment", currentUserDepartment);
            prop.setProperty("incidentstatus", "InProgress");
            prop.setProperty("reportedby", connectionInfo.getSysuserId());
            prop.setProperty("departmentid", toFinalDept);

            try {
                getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, prop); // Calling Record Incident out of box action to generate incident & whole data will be populated on incident table.

            } catch (Exception e) {
                throw new SapphireException("Error: Unable to create indicident for selected samples as TestCode(s) or Destination/Current User Department not found..");
            }
        }

    }



}
