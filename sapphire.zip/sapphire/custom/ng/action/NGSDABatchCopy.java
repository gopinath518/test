package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 9/25/2016.
 */
public class NGSDABatchCopy extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String batchname = properties.getProperty("batchname");
        String pageid=properties.getProperty("pageid");
        String returntolistPage=properties.getProperty("returntolistPage");
        String origin=properties.getProperty("origin");
        String batchmovestatus=properties.getProperty("batchmovestatus");
        String str = "select sampleid from u_ngbatch_sample where u_ngbatchid='" + batchid + "'";
        String plate="select plateid from u_ngbatch_plate where u_ngbatchid='"+batchid+"'";
        String attachment="select filename,typeflag,attachmentdesc from sdiattachment where sdcid='NGBatch'" +
                " and keyid1='"+batchid+"'";
        DataSet dsbatch = getQueryProcessor().getSqlDataSet(str);
        DataSet dsplate=getQueryProcessor().getSqlDataSet(plate);
        DataSet dsattachment=getQueryProcessor().getSqlDataSet(attachment);
        PropertyList prop = new PropertyList();
        try {

            prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("batchname", batchname);
            prop.setProperty("parentbatchid", batchid);
            prop.setProperty("batchmovestatus","");
            prop.setProperty("origin",origin);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);

        } catch (SapphireException e) {
            String er = getTranslationProcessor().translate(batchname + "  Batch is not created " );
            throw new SapphireException(er + e.getMessage());
        }
        String newbatchid=prop.getProperty("newkeyid1",";");
        if(dsbatch==null || dsbatch.size()==0){
            throw new SapphireException("No Samples present in Batch");
        }
        if(dsplate==null || dsplate.size()==0){
            throw new SapphireException("No Samples present in Batch");
        }
        String sampleids=dsbatch.getColumnValues("sampleid",";");
        String plateids=dsplate.getColumnValues("plateid",";");
        associateSamples(newbatchid,sampleids);
        associatePlate(newbatchid,plateids);

        PropertyList plAttachment = new PropertyList();
        plAttachment.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
        plAttachment.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newbatchid);
        plAttachment.setProperty(AddSDIAttachment.PROPERTY_FILENAME,dsattachment.getColumnValues("filename",";"));
        plAttachment.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION,dsattachment.getColumnValues("attachmentdesc",";"));
        plAttachment.setProperty(AddSDIAttachment.PROPERTY_TYPE,dsattachment.getColumnValues("typeflag",";"));
        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, plAttachment);
        }catch(SapphireException se){
            throw new SapphireException("File is not attached to a batch");
        }

        String url = "<script>sapphire.page.navigate('rc?command=page&page="+pageid+"&sdcid=NGBatch&mode=Edit&keyid1=" + newbatchid + "&returntolistpage="+returntolistPage+"', 'Y', '_top')</script>";
        properties.setProperty("msg", url);
    }

    private void associateSamples(String ngbatchid,String sampleid) throws SapphireException{
        PropertyList sampprop=new PropertyList();
        PropertyList sampleprop = new PropertyList();
        sampleprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        sampleprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        sampleprop.setProperty("sampleid", sampleid);
        sampleprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleprop);
        }catch(SapphireException se){
            throw new SapphireException("Samples is not associated");
        }
    }
    private void associatePlate(String ngbatchid,String plateid) throws SapphireException{
        PropertyList plateprop=new PropertyList();
        plateprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        plateprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        plateprop.setProperty("plateid", plateid);
        plateprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plateprop);
        }catch(SapphireException se){
            throw new SapphireException("Plate is not associated in Batch");
        }
    }
}
