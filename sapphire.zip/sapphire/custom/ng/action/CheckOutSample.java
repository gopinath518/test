package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by mpandey on 11/7/2016.
 */
public class CheckOutSample extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String departmentid = properties.getProperty("departmentid");
        String currentuserid = properties.getProperty("currentuserid");
        /*** IN BIO-QA, there has no base department, so Check-OUt slide is not working by base department.(SURAJIT) 05-MAY-2017 STARTS ***/
        if (Util.isNull(departmentid)) {
            departmentid = connectionInfo.getDefaultDepartment();
        }
        /*** IN BIO-QA, there has no base department, so Check-OUt slide is not working by base department.(SURAJIT) 05-MAY-2017 ENDS ***/

        updateTrackItem(sampleid, departmentid, currentuserid);

    }

    /**
     * This method is use to update currentstorageunitid of sample
     * in order to check out from storage.
     *
     * @param sampleid
     * @param departmentid
     * @throws SapphireException
     */
    private void updateTrackItem(String sampleid, String departmentid, String currentuserid) throws SapphireException {
        String quesample = StringUtil.replaceAll(sampleid, ";", "','");
        String sql = "select linkkeyid1,trackitemid,currentstorageunitid,custodialdepartmentid from TRACKITEM where linkkeyid1 in ('" + quesample + "') ";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String trackitemid = ds.getColumnValues("trackitemid", ";");
        PropertyList props = new PropertyList();
        String checkedOutSample = "";
        for (int i = 0; i < ds.size(); i++) {
            String linkkeyid1 = ds.getValue(i, "linkkeyid1", "");
            String currentstorageunitid = ds.getValue(i, "currentstorageunitid", "");
            if ("".equalsIgnoreCase(currentstorageunitid)) {
                checkedOutSample = checkedOutSample + ";" + linkkeyid1;
            }
        }
        if (checkedOutSample.length() > 0) {
            checkedOutSample = checkedOutSample.substring(1);
            String error = getTranslationProcessor().translate("Specimenid:" + checkedOutSample + " already checked out.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("currentstorageunitid", "");
            props.setProperty("custodialdepartmentid", departmentid);
            props.setProperty("custodialuserid", currentuserid);
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }
}
