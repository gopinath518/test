package sapphire.custom.ng.action;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIAttachment;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.GenerateReport;
import sapphire.custom.ng.action.util.NGSendMail;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 9/28/2016.
 *
 * @desc :This is the generic action to create report.It creates the report
 * based on the input paramaters provided to action.It requires
 * reportid,reportversionid,parameters of the report,values of the parameters,
 * sdcid,keyid1 of the sdc,permanentflag,filetype to create a report
 * properties to generate a report
 */
public class GeneratePortalReport extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sdcid = properties.getProperty("sdcid", "");
        String filetype = properties.getProperty("filetype", "");
        String parameterid = properties.getProperty("parameter", "");
        String keyid1 = properties.getProperty("keyid1", "");
        String keyid2 = properties.getProperty("keyid2", "");
        String keyid3 = properties.getProperty("keyid3", "");
        String methodology = properties.getProperty("methodology", "IHC");
        String previewreport = properties.getProperty("PreviewReport");
        ArrayList<String> param = new ArrayList<String>(Arrays.asList(parameterid.split(";")));
        String value = properties.getProperty("parametervalue", "");
        ArrayList<String> val = new ArrayList<String>(Arrays.asList(value.split(";")));
        String attachmentflag = properties.getProperty("permanentflag", "");
        String reportid = properties.getProperty("reportid", "");
        String reportversionid = properties.getProperty("reportversionid", "");
        if (parameterid.equalsIgnoreCase("") || value.equalsIgnoreCase(""))
            throw new SapphireException("Please check the parameter and their values");
        if (reportid.equalsIgnoreCase("") || reportversionid.equalsIgnoreCase("")) {
            throw new SapphireException("Report Id/Version may be blank or not correct ");
        }
        if (parameterid.equalsIgnoreCase("")) {
            throw new SapphireException("Parameter to Report is blank/not correct");
        }
        if (Util.isNull(previewreport)) {
            throw new SapphireException("Parameter to PreviewReport is blank/not correct");
        }
        
        /* Changed by subhendu - 21st April 2017 - E-SIG Validation + */
        String reportRevisionId = properties.getProperty("reportrevisionid", "");
        String revisionTypeId = properties.getProperty("revisiontypeid", "");
        String revisionComment = properties.getProperty("revisioncomment", "");

        if (attachmentflag.equalsIgnoreCase("Y")) {
            String userName = properties.getProperty("username", "");
            String password = properties.getProperty("password", "");
            String reason = properties.getProperty("reason", "");
            if (userName.equalsIgnoreCase("") || password.equalsIgnoreCase("")) {
                logger.info("GeneratePortalReport>", "User Name/Password cannot be blank!!");
                properties.setProperty("ErrorGeneratePortalReport", "User Name/Password cannot be blank!!");
                return;
            } else {
                logger.info("GeneratePortalReport>", "User Name/Password not blank!!");
                if (!getConnectionProcessor().checkUser(userName, password)) {
                    logger.info("GeneratePortalReport>", "Invalid User Name/Password \n Note: More than 3 invalid attempts will temporarily lock your account");
                    properties.setProperty("ErrorGeneratePortalReport", "Invalid User Name/Password \n Note: More than 3 invalid attempts will temporarily lock your account");
                    return;
                } else {
                    logger.info("GeneratePortalReport>", "Valid user");
                    PropertyList auditProp = new PropertyList();
                    auditProp.setProperty(EditSDI.PROPERTY_SDCID, "ReportOption");
                    auditProp.setProperty(EditSDI.PROPERTY_KEYID1, reportid);
                    auditProp.setProperty(EditSDI.PROPERTY_AUDITREASON, reason);
                    auditProp.setProperty(EditSDI.PROPERTY_AUDITDT, "n");
                    auditProp.setProperty(EditSDI.PROPERTY_AUDITACTIVITY, "Y");
                    auditProp.setProperty(EditSDI.PROPERTY_AUDITSIGNEDFLAG, "Y");

                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, auditProp);
                }
            }
        }
        /* Changed by subhendu - 21st April 2017 - E-SIG Validation - */

        String loc = getFileLocation(keyid1, methodology);
        String file = "";
        if (attachmentflag.equalsIgnoreCase("Y")) {
            saveReportComments(keyid1, reportRevisionId, revisionTypeId, revisionComment, keyid2);
            //TODO FINAL REPORT GENERATION
            file = generateReport(reportid, reportversionid, val, loc, param, filetype, previewreport);
            addAttachment(sdcid, keyid1, keyid2, keyid3, file);
            populateSampleReportDate(keyid1);
            //TODO REPEAT TESTING SCENARIO
            String sqlsdiinfo = Util.parseMessage(CommonSql.GET_INFO_FROM_SDIDATAITEM_BY_REPORTOPTIONID, StringUtil.replaceAll(keyid1, ";", "','"));
            DataSet dsSdiInfo = getQueryProcessor().getSqlDataSet(sqlsdiinfo);
            if ("IHC".equalsIgnoreCase(methodology) && dsSdiInfo.size() == 0) {
                logger.info("GeneratePortalReport>", "Except IHC Sent mail.");
                sendEmailNotificationForBioPharma(keyid1, file);
                updateReportOption(keyid1);
                moveIHCSamplesToNextStep(keyid1);
            } else if (!"IHC".equalsIgnoreCase(methodology)) {
                logger.info("GeneratePortalReport>", "Except IHC Sent mail.");
                if (("Flow".equalsIgnoreCase(methodology) && "FlowQCReport".equalsIgnoreCase(reportid))
                        || ("Fish".equalsIgnoreCase(methodology) && "FishQCReport".equalsIgnoreCase(reportid)))
                    logger.info("GeneratePortalReport>", "Mail will not be sent to for generating QC report.");
                else {
                    sendEmailNotificationForBioPharma(keyid1, file);
                    updateReportOption(keyid1);
                    performMethodologyBaseJob(keyid1, methodology);
                }
            } else if ("IHC".equalsIgnoreCase(methodology) && dsSdiInfo.size() > 0) {
                logger.info("GeneratePortalReport>", "Only IHC Repeat Testing logic.");
                String accessionid = Util.getUniqueList(dsSdiInfo.getColumnValues("u_accessionid", ";"), ";", true);
                String s_sampleid = dsSdiInfo.getColumnValues("s_sampleid", ", ");
                String testcodedesc = dsSdiInfo.getColumnValues("testcodedesc", ";");
                String defaultdepartment = connectionInfo.getDefaultDepartment();
                String currentuser = connectionInfo.getSysuserId();
                String site = StringUtil.split(defaultdepartment, "-")[0]; //AV
                String assigndept = site + "-Accessioning";
                DataSet dsUsers = getAPUsers(site + "-Accessioning");
                DataSet dsDisplayMsg = new DataSet();
                dsDisplayMsg.addColumn("accession_id", DataSet.STRING);
                dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
                dsDisplayMsg.addColumn("test_name", DataSet.STRING);
                for (int i = 0; i < dsSdiInfo.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "accession_id", dsSdiInfo.getValue(i, "u_accessionid", ""));
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsSdiInfo.getValue(i, "s_sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "test_name", dsSdiInfo.getValue(i, "testcodedesc", ""));
                }
                String disMsg = "";
                if (dsDisplayMsg.size() > 0) {
                    //disMsg = Util.getDisplayMessage("Below specimen(s) need to be retest.", dsDisplayMsg);
                    String repeatsample = StringUtil.replaceAll(dsDisplayMsg.getColumnValues("specimen_id", ";"), ";", "','");
                    String sql = Util.parseMessage(ApSql.GET_COMMUNICATION_BY_SAMPLEID, repeatsample);
                    DataSet dsCommunication = getQueryProcessor().getSqlDataSet(sql);
                    if (dsCommunication != null && dsCommunication.size() > 0) {
                        DataSet dsSendComm = new DataSet();
                        dsSendComm.addColumn("sampleid", DataSet.STRING);
                        dsSendComm.addColumn("accessionid", DataSet.STRING);
                        dsSendComm.addColumn("testname", DataSet.STRING);
                        for (int i = 0; i < dsDisplayMsg.size(); i++) {
                            String sampleid = dsDisplayMsg.getValue(i, "specimen_id", "");
                            HashMap hm = new HashMap();
                            hm.clear();
                            hm.put("linkkeyid1", sampleid);
                            DataSet dsFilter = dsCommunication.getFilteredDataSet(hm);
                            if (dsFilter.size() == 0) {
                                int rowID = dsSendComm.addRow();
                                dsSendComm.setValue(rowID, "sampleid", sampleid);
                                dsSendComm.setValue(rowID, "accessionid", dsDisplayMsg.getValue(i, "accession_id", ""));
                                dsSendComm.setValue(rowID, "testname", dsDisplayMsg.getValue(i, "test_name", ""));
                            }
                        }
                        if (dsSendComm != null && dsSendComm.size() > 0) {
                            PropertyList props = new PropertyList();
                            props.setProperty(AddSDI.PROPERTY_SDCID, "Communication");
                            props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsSendComm.size()));
                            props.setProperty("createbydepartment", StringUtil.repeat(defaultdepartment, dsSendComm.size(), ";"));
                            props.setProperty("communicationdesc", StringUtil.repeat("Repeat Testing Requested from " + currentuser + ".", dsSendComm.size(), ";"));
                            props.setProperty("linkkeyid1", dsSendComm.getColumnValues("sampleid", ";"));
                            props.setProperty("linkkeyid2", dsSendComm.getColumnValues("accessionid", ";"));
                            props.setProperty("linkkeyid3", dsSendComm.getColumnValues("testname", ";"));
                            props.setProperty("assigneddepartment", StringUtil.repeat(assigndept, dsSendComm.size(), ";"));
                            props.setProperty("status", StringUtil.repeat("Initial", dsSendComm.size(), ";"));
                            try {
                                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                            } catch (Exception ex) {
                                logger.info("Generatereport>", "unable to add into communication");
                            }
                        }
                    }
                    if (dsCommunication.size() == 0) {
                        PropertyList props = new PropertyList();
                        props.setProperty(AddSDI.PROPERTY_SDCID, "Communication");
                        props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsDisplayMsg.size()));
                        props.setProperty("createbydepartment", StringUtil.repeat(defaultdepartment, dsDisplayMsg.size(), ";"));
                        props.setProperty("communicationdesc", StringUtil.repeat("Repeat Testing Requested from " + currentuser + ".", dsDisplayMsg.size(), ";"));
                        props.setProperty("linkkeyid1", dsDisplayMsg.getColumnValues("specimen_id", ";"));
                        props.setProperty("linkkeyid2", dsDisplayMsg.getColumnValues("accession_id", ";"));
                        props.setProperty("linkkeyid3", dsDisplayMsg.getColumnValues("test_name", ";"));
                        props.setProperty("assigneddepartment", StringUtil.repeat(assigndept, dsDisplayMsg.size(), ";"));
                        props.setProperty("status", StringUtil.repeat("Initial", dsDisplayMsg.size(), ";"));
                        try {
                            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                        } catch (Exception ex) {
                            logger.info("Generatereport>", "unable to add into communication");
                        }
                    }
                }
                logger.info("Bullettine Message", disMsg);
                /*PropertyList props = new PropertyList();
                props.setProperty(SendBulletin.PROPERTY_USER, dsUsers.getValue(0, "sysuserid", ""));
                props.setProperty(SendBulletin.PROPERTY_DESCRIPTION, "Repeat Testing Requested from <b>" + currentuser + "</b>.");
                props.setProperty(SendBulletin.PROPERTY_BODY, disMsg);
                props.setProperty(SendBulletin.PROPERTY_SOURCE, "System");
                getActionProcessor().processAction(SendBulletin.ID, SendBulletin.VERSIONID, props);*/
            }
            // sendEmailNotificationForBioPharma(keyid1, file);
            try {
                copyFileSFTPPath(file, keyid1);
            } catch (Exception e) {
                Logger.logError("Error occued in Generating portal Report:: " + e.getMessage());
            }
        } else {
            //TODO PREVIEW REPORT GENERATION
            file = generateReport(reportid, reportversionid, val, loc, param, filetype, previewreport);
        }
        String attachnum = Util.parseMessage(ApSql.ATTACHMENT_BY_REPORT, sdcid, keyid1, keyid2, file);
        //String attachnum = "select attachmentnum from sdiattachment where sdcid='" + sdcid + "' and keyid1='" + keyid1 + "' and keyid2='" + keyid2 + "' and filename='" + file + "'";
        DataSet dsattachnum = getQueryProcessor().getSqlDataSet(attachnum);
        String attachmentno = dsattachnum.getColumnValues("attachmentnum", ";");
        properties.setProperty("filename", file);
        if (attachmentflag.equalsIgnoreCase("Y"))
            properties.setProperty("attachmentnum", attachmentno);


    }

    private DataSet getAPUsers(String deparmentid) throws SapphireException {
        String userSQL = Util.parseMessage(CommonSql.GET_USER_BY_DEPARTMENT, deparmentid);
        DataSet dsuser = getQueryProcessor().getSqlDataSet(userSQL);
        if (dsuser == null || dsuser.size() == 0) {
            return null;
        }
        return dsuser;
    }

    /* Changed by subhendu - 21st May 2017 - E-SIG Validation + */
    public void saveReportComments(String reportOptionId, String reportRevisionId, String revisionTypeId, String revisionComment, String reportid) throws SapphireException {

        /*PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "ReportOption");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, reportOptionId);
        props.setProperty("reportrevisionid", reportRevisionId);
        props.setProperty("reportid", reportid);
        props.setProperty("revisiontypeid", revisionTypeId);
        props.setProperty("revisioncomment", revisionComment);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "reportrevision_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (SapphireException se) {
            throw new SapphireException("Failed to update Report Version comments ::" + se.getMessage());
        }*/

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "ReportOptionDtl");
        props.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props.setProperty("u_reportoptionid", reportOptionId);
        props.setProperty("reportid", reportid);
        props.setProperty("reportrevisionid", reportRevisionId);
        props.setProperty("revisiontypeid", revisionTypeId);
        props.setProperty("revisioncomment", revisionComment);

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);


    }
    /* Changed by subhendu - 21st May 2017 - E-SIG Validation - */

    /**
     * Description : This method will call CopyFile action using AddToDoListEntry.This will copy generated file to
     * given location.
     *
     * @param sourceFile
     * @param rptopsid
     * @throws SapphireException
     * @throws IOException
     */
    private void copyFileSFTPPath(String sourceFile, String rptopsid) throws SapphireException, IOException {
        PropertyList prop = new PropertyList();
        prop.setProperty("sourcefile", sourceFile);
        prop.setProperty("rptopsid", rptopsid);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, CopyFile.ID);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, CopyFile.VERSIONID);
        prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
        prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
    }

    private void populateSampleReportDate(String keyid1) throws SapphireException {
        if (Util.isNull(keyid1))
            throw new SapphireException("Error: No reporting id(s) found in input");

        StringBuilder sb = new StringBuilder();
        sb.append("select u_reportoptionid,accessionid,methodologyid,los from u_reportoption where u_reportoptionid in('");
        sb.append(StringUtil.replaceAll(keyid1, ";", "','"));
        sb.append("')");
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sb.toString());
        if (dsSql == null)
            throw new SapphireException("Error: Unable to perform query in database");
        if (dsSql.size() == 0)
            throw new SapphireException("Error: All reporting ids are invalid");

        String[] arrUniqueInputs = Util.getUniqueList(keyid1, ";", true).split(";");
        String[] arrUniqueDbValues = Util.getUniqueList(dsSql.getColumnValues("u_reportoptionid", ";"), ";", true).split(";");
        if (arrUniqueDbValues.length != arrUniqueInputs.length)
            throw new SapphireException("Error: One or more reporting id(s) are invalid");

        dsSql.addColumn("querycol", DataSet.STRING);
        for (int i = 0; i < dsSql.size(); i++) {
            String queryString = dsSql.getValue(i, "accessionid") + "#" + dsSql.getValue(i, "methodologyid");
            //+ "#" + dsSql.getValue(i , "los");TODO CHANGED FOR CONSOLIDATED REPORTING
            dsSql.setValue(i, "querycol", queryString);
        }

        sb = new StringBuilder();
        sb.append("select s.s_sampleid from s_sample s, u_sampletestcodemap stm ");
        sb.append("where s.s_sampleid = stm.s_sampleid ");// and s.u_accessioningcomplete = 'Y' ");
        //sb.append("and s.u_accessionid || '#' || stm.methodology || '#' || stm.los in ('");TODO CHANGED FOR CONSOLIDATED REPORTING
        sb.append("and s.u_accessionid || '#' || stm.methodology in ('");
        sb.append(dsSql.getColumnValues("querycol", "','"));
        sb.append("')");

        DataSet ds = getQueryProcessor().getSqlDataSet(sb.toString());
        if (ds == null)
            throw new SapphireException("Error: Unable to perform query in database");
        else if (ds.size() == 0)
            throw new SapphireException("Error: No accessioning samples found with matching Accessionid, Methodolody, LOS combination");
        else {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_reportingdts", "n");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (ActionException ae) {
                throw new SapphireException("Error: Unable to update reporting date of following samples: " + ds.getColumnValues("s_sampleid", ";"));
            }
        }

    }

    /**
     * @return
     * @throws SapphireException
     * @desc: This method gets the path from the policy
     * where report needs to be saved
     */
    private String getFileLocation(String reportoptionid, String methodology) throws SapphireException {
        String fileLocation = "";
        String sql = Util.parseMessage(CommonSql.GET_ACCESSION_INFO, StringUtil.replaceAll(reportoptionid, ";", "','"));
        DataSet dsAccessionIfo = getQueryProcessor().getSqlDataSet(sql);
        String sponsornumber = "", projectprotocolid = "";
        if (dsAccessionIfo.size() > 0) {
            sponsornumber = dsAccessionIfo.getValue(0, "sponsornumber");
            projectprotocolid = dsAccessionIfo.getValue(0, "projectprotocolid");
        }
        sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        fileLocation = Util.generateIHCLocPath(baseloc, sponsornumber, projectprotocolid, methodology, "Report");
        logger.info("GeneratePortalReport>>Report Path>>>", fileLocation);
        /*PropertyList filelocprop = getConfigurationProcessor().getPolicy("FileLocationPolicy", "Report");
        PropertyListCollection plc = filelocprop.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        if (fileLocation.equalsIgnoreCase("")) {
            throw new SapphireException("Location is not found");
        }*/

        return fileLocation;
    }


    /**
     * @param reportid-The      id of the report which you want to run.
     * @param versionid-The     versionid of the report
     * @param val-Values        of the parameters
     * @param location
     * @param param-Parameters  defined for the report
     * @param filetype-Filetype of the report(pdf/xls)
     * @return It returns
     * @throws SapphireException
     */
    private String generateReport(String reportid, String versionid, ArrayList<String> val, String location, ArrayList<String> param, String filetype, String previewreport) throws SapphireException {
        logger.info("GeneratePortalReport>>Report Path FOr report>>>", location);
        SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyyhmmssa");
        Date date = new Date();
        String datetime = sdf.format(date);
        //String filename = location +"\\"+datetime +"."+filetype;
        String filename = location + File.separator + datetime + "." + filetype;
        PropertyList prop = new PropertyList();
        prop.setProperty(GenerateReport.PROPERTY_REPORTID, reportid);
        prop.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID, versionid);
        for (int i = 0; i < param.size(); i++) {
            prop.setProperty(param.get(i), val.get(i));
        }
        prop.setProperty("PreviewReport", previewreport);
        prop.setProperty(GenerateReport.PROPERTY_DESTINATION, "file");
        prop.setProperty(GenerateReport.PROPERTY_DEBUGLOG, "N");
        prop.setProperty(GenerateReport.PROPERTY_FILENAME, filename);
        prop.setProperty(GenerateReport.PROPERTY_FILETYPE, filetype);

        try {
            getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Report not generated. " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        logger.info("GeneratePortalReport>>Report File Name>>>", filename);
        return filename;
    }

    private void addAttachment(String sdcid, String keyid1, String keyid2, String keyid3, String file) throws SapphireException {
        PropertyList pattach = new PropertyList();
        pattach.setProperty(AddSDIAttachment.PROPERTY_SDCID, sdcid);
        pattach.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1);
        pattach.setProperty(AddSDIAttachment.PROPERTY_KEYID2, keyid2);
        pattach.setProperty(AddSDIAttachment.PROPERTY_KEYID3, keyid3);
        pattach.setProperty(AddSDIAttachment.PROPERTY_FILENAME, file);
        pattach.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");

        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pattach);
        } catch (SapphireException ex) {
            throw new SapphireException("File is not attached successfully");
        }
        logger.info("GeneratePortalReport>", "File attached successfully");
    }

    private void sendEmailNotificationForBioPharma(String reportopsId, String filename) throws SapphireException {
        if (!Util.isNull(reportopsId)) {
            String sql = Util.parseMessage(CommonSql.GET_INFO_FROM_SITE_LABEL_BY_REPORTOPTIONID, StringUtil.replaceAll(reportopsId, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            sql = Util.parseMessage(CommonSql.GET_INFO_FROM_PROJECT_LABEL_BYREPORTOPTIONID, StringUtil.replaceAll(reportopsId, ";", "','"));
            DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
            ds.copyRow(dsProject, -1, 1);

            if (ds == null || ds.size() == 0)
                logger.info("The SQL: " + sql + " is not returning any value.");

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                String nodeId = "";
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("type", "Email");
                            hmap.put("event", "Result Notification");
                            DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Result Notification");
                            DataSet tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ResultNotification";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, nodeId, "SendMail", "");

                            hmap.clear();
                            hmap.put("type", "Email");
                            hmap.put("event", "Report Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Report Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ReportDistribution";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, nodeId, "AttachReport", filename);

                            hmap.clear();
                            hmap.put("type", "Fax");
                            hmap.put("event", "Fax Distribution");

                            hmap.clear();
                            hmap.put("projtype", "Fax");
                            hmap.put("projevent", "Fax Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ReportDistribution";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, nodeId, "AttachReport", filename);
                        }
                    }
                }
            }
        }
    }

    private void sendEmailNotificationForBioPharma_old(String reportopsId, String filename) throws SapphireException {
        if (!Util.isNull(reportopsId)) {
            String sql = "select ac.u_accessionid,ac.patientid,ac.bioprojectname,ac.biositeid siteid,bio.invesitagtorname,bio.projectid,bio.sitename, biomail.email,biomail.event," +
                    "biomail.type,s.s_sampleid,subject.u_biopharmasubjectid,bioproject.projectprotocolid,s.u_rootsample " +
                    "from u_accession ac,u_biosite bio,s_sample s,u_biositeemail biomail,s_subject subject,u_bioprojects bioproject,u_reportoption rops " +
                    "where rops.u_reportoptionid in ('" + StringUtil.replaceAll(reportopsId, ";", "','") + "') " +
                    "and s.u_accessionid = ac.u_accessionid " +
                    "and ac.biositeid = bio.u_biositeid " +
                    "and bio.u_biositeid=biomail.biositeid " +
                    "and ac.patientid=subject.s_subjectid " +
                    "and bio.projectid=bioproject.u_bioprojectsid " +
                    "and ac.u_accessionid=rops.accessionid " +
                    "order by ac.u_accessionid";

            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            sql = Util.parseMessage(CommonSql.PROJECT_REPORT_EMAIL, StringUtil.replaceAll(reportopsId, ";", "','"));
            DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
            ds.copyRow(dsProject, -1, 1);

            if (ds == null || ds.size() == 0)
                logger.info("The SQL: " + sql + " is not returning any value.");

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                String nodeId = "";
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("type", "Email");
                            hmap.put("event", "Result Notification");
                            DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Result Notification");
                            DataSet tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0)
                                nodeId = "ResultNotification";
                            else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0)
                                nodeId = "ClinicalAccession";

//                            if(tempDsFiltr==null || tempDsFiltr.size()==0)
//                                logger.info("Filter Type=Email and Event=Result Notification is not returning any row.");
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, nodeId, "SendMail", "");


                            hmap.clear();
                            hmap.put("type", "Email");
                            hmap.put("event", "Report Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Report Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0)
                                nodeId = "ReportDistribution";
                            else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0)
                                nodeId = "ClinicalAccession";

                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, nodeId, "AttachReport", filename);

                            hmap.clear();
                            hmap.put("type", "Fax");
                            hmap.put("event", "Fax Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
//                            if(tempDsFiltr==null || tempDsFiltr.size()==0)
//                                logger.info("Filter Type=Fax and Event=Fax Distribution is not returning any row.");
                            hmap.clear();
                            hmap.put("projtype", "Fax");
                            hmap.put("projevent", "Fax Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0)
                                nodeId = "ReportDistribution";
                            else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0)
                                nodeId = "ClinicalAccession";
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, nodeId, "AttachReport", filename);
                        }
                    }
                }

            }
        }
    }

    private void sendNotification(DataSet tempDsFiltr, DataSet tempDsFiltrProjectLevel, String nodeid, String mode, String filename) throws SapphireException {
        String toList = "";
        PropertyList prop = new PropertyList();
        prop.setProperty(NGSendMail.NODE_ID, nodeid);
        prop.setProperty(NGSendMail.MODE, mode);
        //TODO TAKEN FROM INVESTIGATOR SITE LABEL
        if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
            toList = tempDsFiltr.getColumnValues("email", ";");
            if (!Util.isNull(toList)) {
                toList = Util.getUniqueList(toList, ";", true);
                String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                if (!Util.isNull(invistigatoName))
                    invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                prop.setProperty(NGSendMail.NODE_ID, nodeid);
                prop.setProperty(NGSendMail.MODE, mode);
                prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_rootsample", ";"), ";", true));
                prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                prop.setProperty(NGSendMail.FILENAME, filename);
            }
        }
        //TODO TAKEN FROM PROJECT LABEL
        if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
            toList = tempDsFiltrProjectLevel.getColumnValues("email", ";") + ";" + toList;
            if (!Util.isNull(toList))
                toList = Util.getUniqueList(toList, ";", true);

            String sponcerName = tempDsFiltrProjectLevel.getColumnValues("sponsername", ";");
            if (!Util.isNull(sponcerName)) {
                sponcerName = Util.getUniqueList(sponcerName, ";", true);
            }
            String invistigatoName = tempDsFiltrProjectLevel.getColumnValues("investigatorname", ";");
            if (!Util.isNull(invistigatoName)) {
                invistigatoName = Util.getUniqueList(invistigatoName, ";", true);
            }
            prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_rootsample", ";"), ";", true));
            prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", ";"), ";", true));
            prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", "','"), ";", true));
            prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("investigatorsiteid", ";"), ";", true));
            prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
            prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
            //PROJEC LABEL
            prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
            prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("projectprotocolid", ";"), ";", true));
            prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
            if (!Util.isNull(filename))
                prop.setProperty(NGSendMail.FILENAME, filename);
        }
        if (toList != null && !"".equals(toList.trim())) {
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }

    private void sendNotification_old(DataSet tempDsFiltr, DataSet tempDsFiltrProjectLevel, String nodeid, String mode, String filename) throws SapphireException {
        String toList = "";
        PropertyList prop = new PropertyList();
        prop.setProperty(NGSendMail.NODE_ID, nodeid);
        prop.setProperty(NGSendMail.MODE, mode);
        if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
            toList = tempDsFiltr.getColumnValues("email", ";");
            if (!Util.isNull(toList)) {
                toList = Util.getUniqueList(toList, ";", true);
                String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                if (!Util.isNull(invistigatoName))
                    invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                prop.setProperty(NGSendMail.NODE_ID, nodeid);
                prop.setProperty(NGSendMail.MODE, mode);
                prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_rootsample", ";"), ";", true));
                prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                prop.setProperty(NGSendMail.FILENAME, filename);
            }
        }
        if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
            toList = tempDsFiltr.getColumnValues("email", ";") + ";" + toList;
            if (!Util.isNull(toList))
                toList = Util.getUniqueList(toList, ";", true);

            String sponcerName = tempDsFiltrProjectLevel.getColumnValues("sponcername", ";");
            if (!Util.isNull(sponcerName))
                sponcerName = Util.getUniqueList(sponcerName, ";", true);
            prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
            prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
            prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
            if (!Util.isNull(filename))
                prop.setProperty(NGSendMail.FILENAME, filename);
        }
        if (toList != null && !"".equals(toList.trim())) {
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }

    private void updateReportOption(String reportoptionid) throws SapphireException {
        logger.info("Generatereport>", "report option update method entry");
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "ReportOption");
        props.setProperty(EditSDI.PROPERTY_KEYID1, reportoptionid);
        props.setProperty("reportingstatus", "Completed");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            logger.info("Generatereport>", "unable to update report option");
        }
    }

    private void moveIHCSamplesToNextStep(String keyid1) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_SAMPLE_BY_REOP, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsIHCSamples = getQueryProcessor().getSqlDataSet(sql);
        if (dsIHCSamples.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.clear();
            prop.setProperty("sampleid", dsIHCSamples.getColumnValues("s_sampleid", ";"));
            prop.setProperty("pathologycompleteflag", "Y");
            try {
                getActionProcessor().processAction("IHCFlowCompleteStep", "1", prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to route automatically." + ex.getMessage());
            }
        }
    }

    private void performMethodologyBaseJob(String reportoptionid, String methodology) throws SapphireException {
        logger.info("Generatereport>", "performMethodologyBaseJob method entry reportoptionid:" + reportoptionid + ":methodology:" + methodology);
        if ("Flow".equalsIgnoreCase(methodology)) {
            flowFinalReportRule(reportoptionid);
            this.flowCompleteSample(reportoptionid);
        }

    }

    private void flowFinalReportRule(String reportoptionid) throws SapphireException {
        String sql = Util.parseMessage(FlowSql.FLOW_GIEMSA_AND_CYTO_SAMPLE, reportoptionid);
        DataSet giemsaDS = getQueryProcessor().getSqlDataSet(sql);
        PropertyList props = new PropertyList();
        try {
            if (giemsaDS != null && giemsaDS.size() > 0) {
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, giemsaDS.getColumnValues("s_sampleid", ";"));
                props.setProperty("u_currentmovementstep", "FlowSlideRecon");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

                props.clear();

                String currentUsrdepartment = connectionInfo.getDefaultDepartment();
                String destDept = "";
                if (!Util.isNull(currentUsrdepartment)) {
                    String site = StringUtil.split(currentUsrdepartment, "-")[0];
                    if (!Util.isNull(site)) {
                        destDept = site + "-" + "Accessioning";
                    }
                }

                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, giemsaDS.getColumnValues("s_sampleid", ";"));
                props.setProperty("u_currenttramstop", "Path Support Recon");
                props.setProperty("custodialuserid", "(null)");
                props.setProperty("custodialdepartmentid", destDept);
                props.setProperty("u_flowsamplereceivedt", "n");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.info("Generatereport>", "error in flowFinalReportRule::" + ex.getMessage());
            throw new SapphireException("Generatereport>", "error in flowFinalReportRule::" + ex.getMessage());
        }
    }

    private void flowCompleteSample(String reportoptionid) throws SapphireException {
        // TODO Auto-generated method stub
        String query = Util.parseMessage(FlowSql.GET_SDITESTCODEID_FROM_REPORTOPTIONID, reportoptionid);
        DataSet ds = getQueryProcessor().getSqlDataSet(query);
        PropertyList pl = new PropertyList();
        if (ds != null && ds.getRowCount() > 0) {
            pl.setProperty(EditSDI.PROPERTY_SDCID, "SDITestCode");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sditestcodeid", ";"));
            pl.setProperty("teststatus", "Completed");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

        String sql = Util.parseMessage(FlowSql.GET_STMID_FROM_REPORTOPTIONID, reportoptionid);
        DataSet rs = getQueryProcessor().getSqlDataSet(sql);
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("methodology", "Flow");
        DataSet filteredDS = rs.getFilteredDataSet(hm);
        if (filteredDS != null && filteredDS.getRowCount() > 0) {
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, filteredDS.getColumnValues("u_sampletestcodemapid", ";"));
            pl.setProperty("teststatus", StringUtil.repeat("Completed", filteredDS.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

		
		/*if(rs != null && filteredDS != null 
                && (rs.getRowCount() == filteredDS.getRowCount())){
			pl.clear();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, Util.getUniqueList(rs.getColumnValues("u_accessionid", ";"), ";", true));
			pl.setProperty("status", "Completed");
		}*/
    }
}
