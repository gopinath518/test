package sapphire.custom.ng.action;

import org.json.JSONArray;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by DMondal on 9/14/2016.
 * Description:This action is used for reverse movement.Depending on selected PCR analyte,Sequenceing analyte in jsp this action will create a row for
 * each individual analyte and each row will be saved in Reverse Movement SDC with to tramstop,comments etc.You can see all pending
 * movement list in Molicular Lab-->Pending Sample List tramstop.
 * Updated table: u_reversemovement
 */
public class ReverseMovement extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        //String mainData = "[{\"sampleids\":\"S-160812-00290\",\"extractionid\":\"D16-000275\",\"accessionid\":\"acc1\",\"fromBatch\":\"batch1\",\"fromTramstop\":\"tramstop1\",\"pcranalytes\":\"E18|E19\",\"sequenceanalyte\":\"R;F|R\"},{\"sampleids\":\"S-160815-00156\",\"extractionid\":\"D16-000287\",\"accessionid\":\"acc2\",\"fromBatch\":\"batch2\",\"fromTramstop\":\"tramstop2\",\"pcranalytes\":\"E20|E21\",\"sequenceanalyte\":\"R|R;F\"}]";
        String mainData = properties.getProperty("inputvalue");
        if (Util.isNull(mainData)) {
            String error = getTranslationProcessor().translate("Please select something before press Save button.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        initializeDataSet();
        validateData(mainData);
        getLvSampleid();
        getTestCodeFormInputSample();
        addSDIReverseMovement();
        properties.setProperty("totramstopval",dsMain.getColumnValues(DATASET_PROPERTY_TO_TRAMSTOP,";"));
    }

    /**
     * Description: This method will be deleted.
     * @param mainData
     * @throws SapphireException
     */
    private void validateData_old(String mainData) throws SapphireException {
        String[] allData = StringUtil.split(mainData, "`");
        if (allData.length == 1 || allData.length == 0) {
            String error = getTranslationProcessor().translate("Data is not valid");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        int rowIncrement = 0;
        for (int i = 1; i < allData.length; i++) {
            String[] allColData = StringUtil.split(allData[i], "|");
            String PrntSampleid = allColData[0];
            if (PrntSampleid.length() == 0) {
                String error = getTranslationProcessor().translate("Sample Id not valid");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String PrntExtractionid = allColData[1];
            if (PrntExtractionid.length() == 0) {
                String error = getTranslationProcessor().translate("Extraction Id not valid");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String analyte = allColData[2];
            if (analyte.length() == 0) {
                String error = getTranslationProcessor().translate("Please select an Analyte.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String comments = allColData[5];
            if (comments.length() == 0) {
                String error = getTranslationProcessor().translate("Please insert a comments.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String[] singlPcrAnalyteArr = StringUtil.split(analyte, ";");
            String selectedDropDwnVal = allColData[3];
            String[] dropdownVal = StringUtil.split(selectedDropDwnVal, ";");
            if (dropdownVal.length == 1 || dropdownVal.length == 0) {
                String error = getTranslationProcessor().translate("Please select from dropdown");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            for (int pcr = 0; pcr < singlPcrAnalyteArr.length; pcr++) {
                if (dropdownVal.length > 2) {
                    String error = getTranslationProcessor().translate("Please select only one tramstop");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                } else {
                    rowIncrement = dsMain.addRow();
                    //one sample
                    addToDataSet(rowIncrement, PrntSampleid, PrntExtractionid, "Testbatch", "testTramstop", "Y", singlPcrAnalyteArr[pcr], "",dropdownVal[1],comments);
                }

            }

        }
    }
    /**
     * Description: validateData() method used for checking valid input data format that is coming from jsp and creating a main data set
     * with that values.
     * @return ds dataset
     * @throws SapphireException
     */
    private void validateData(String mainData) throws SapphireException {
        if (mainData.length() == 0) {
            String error = getTranslationProcessor().translate("Data coming from jsp page is not valid");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        try {
            JSONArray json = new JSONArray(mainData);
            int rowIncrement = 0;
            for (int i = 0; i < json.length(); i++) {
                JSONObject jObj = (JSONObject) json.getJSONObject(i);
                String inputSampleids = jObj.getString("sampleids");
                if (inputSampleids.length() == 0) {
                    String error = getTranslationProcessor().translate("Extractionid Id not valid");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String extractionid = jObj.getString("extractionid");
                if (extractionid.length() == 0) {
                    String error = getTranslationProcessor().translate("Extractionid Id not valid");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String accessionid = jObj.getString("accessionid");
                if (accessionid.length() == 0) {
                    String error = getTranslationProcessor().translate("Accessionid Id not valid");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String fromBatch = jObj.getString("fromBatch");
                if (fromBatch.length() == 0) {
                    String error = getTranslationProcessor().translate("Source Batch Id not valid");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String toTramstop = jObj.getString("totramstop");
                if (toTramstop.length() == 0) {
                    String error = getTranslationProcessor().translate("Destination Tramstop not valid");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String fromTramstop = jObj.getString("fromTramstop");
                if (fromTramstop.length() == 0) {
                    String error = getTranslationProcessor().translate("Source Tramstop Id not valid");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String comments = jObj.getString("comments");

                String pcranalytes = jObj.getString("pcranalytes");//All PCR analyte with pipe separated.
                if (pcranalytes.length() == 0) {
                    String error = getTranslationProcessor().translate("Please select an PCR analyte");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }
                String[] pcrAnalyteArr = StringUtil.split(pcranalytes, "|");
                /*Bellow line will return Sequenceing analyte with pipe separated for all PCR analyte accordingly.And again each column
                is divided with semicolon seperated for individual PCR analyte accordingly.
                 */
                String sequenceanalytes = jObj.getString("sequenceanalyte");
                String[] multiSecAnalyteArr = null;
                if (!Util.isNull(sequenceanalytes)) {
                    multiSecAnalyteArr = StringUtil.split(sequenceanalytes, "|");//R;F R
                }
                /*
                Bellow length check for data validation that is coming from jsp.Length should be same for PCR analyte
                 with pipe seperated and Sequenceing analyte with pipe separated.
                 */
                /*if(pcrAnalyteArr.length!=multiSecAnalyteArr.length){
                    String error = getTranslationProcessor().translate("PCR analye and Sequencing analye length not same.Data send from jsp to action is not valid.Contact with administrator");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                }*/
                for (int m = 0; m < pcrAnalyteArr.length; m++) {
                    //if (multiSecAnalyteArr.length > 0) {
                    if (!Util.isNull(sequenceanalytes)) {
                        if (!Util.isNull(multiSecAnalyteArr[m])) {
                            String[] singlSecAnalyteArr = StringUtil.split(multiSecAnalyteArr[m], ";");//R F
                            for (int k = 0; k < singlSecAnalyteArr.length; k++) {
                                rowIncrement = dsMain.addRow();
                                addToDataSet(rowIncrement, inputSampleids, extractionid, fromBatch, fromTramstop, "Y", pcrAnalyteArr[m], singlSecAnalyteArr[k],toTramstop,comments);
                            }
                        } else {
                            rowIncrement = dsMain.addRow();
                            addToDataSet(rowIncrement, inputSampleids, extractionid, fromBatch, fromTramstop, "Y", pcrAnalyteArr[m], "",toTramstop,comments);
                        }
                    } else {
                        rowIncrement = dsMain.addRow();
                        addToDataSet(rowIncrement, inputSampleids, extractionid, fromBatch, fromTramstop, "Y", pcrAnalyteArr[m], "",toTramstop,comments);
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method used for only setting data to the dataset
     * @param rowIncrement
     * @param inputSampleids
     * @param extractionid
     * @param fromBatch
     * @param fromTramstop
     * @param ispending
     * @param pcrAnalyte
     * @param secAnalyte
     * @param totramstop
     * @param comments
     */
    private void addToDataSet(Integer rowIncrement, String inputSampleids, String extractionid, String fromBatch, String fromTramstop, String ispending, String pcrAnalyte, String secAnalyte,String totramstop,String comments) {
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_INPUTSAMPLE_ID, inputSampleids);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, extractionid);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_FROMBATCH, fromBatch);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_FROM_TRAMSTOP, fromTramstop);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_ISPENDING, ispending);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_PCR_ANALYTE, pcrAnalyte);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_SEQUENCING_ANALYTE, secAnalyte);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_TO_TRAMSTOP, totramstop);
        dsMain.setValue(rowIncrement, DATASET_PROPERTY_TO_COMMENTS, comments);
    }

    /**
     * Description:This method is used for getting Lvsample id for individual extraction id and adding to the dsMain dataset for
     * saving data in Reverse Movement SDC.
     * @throws SapphireException
     */
    private void getLvSampleid() throws SapphireException {
        String extractionids = dsMain.getColumnValues(DATASET_PROPERTY_EXTRACTION_ID, ";");
        //1 Get Lv_sample id
        String sqlLvSampleids = "select s.s_sampleid lvsampleid,s.u_extractionid extraction from s_sample s,trackitem t where s.s_sampleid=t.linkkeyid1 and t.containertypeid='Ellution Tube' and s.u_extractionid in ('" + StringUtil.replaceAll(extractionids, ";", "','") + "')";
        DataSet dsLvSampleids = getQueryProcessor().getSqlDataSet(sqlLvSampleids);
        if (dsLvSampleids == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlLvSampleids;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsLvSampleids.size() == 0) {
            String errStr = getTranslationProcessor().translate("LvSample ids not found.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        //2. filter testcode by parent and assign to child in main dataset
        HashMap hm = new HashMap();
        for (int i = 0; i < dsMain.getRowCount(); i++) {
            String extractionid = dsMain.getValue(i, DATASET_PROPERTY_EXTRACTION_ID, "");
            hm.clear();
            hm.put("extraction", extractionid);
            DataSet dsFilter = dsLvSampleids.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                dsMain.setValue(i, DATASET_PROPERTY_LV_SAMPLE_ID, dsFilter.getColumnValues("lvsampleid", ";"));
            }
        }

    }

    /**
     * Description: This method is used for getting test code of Input sample and will add to the main data set for
     * saving testcode or panel to Reverse Movement SDC for each input sample .
     * @throws SapphireException
     */
    private void getTestCodeFormInputSample() throws SapphireException {
        String parentSample = dsMain.getColumnValues(DATASET_PROPERTY_INPUTSAMPLE_ID, ";");
        //1 Get parents test code
        String sqlTestCode = "select lvtestcodeid,lvtestpanelid,nvl(ispanel,'N') as ispanel,s_sampleid from u_sampletestcodemap where s_sampleid in ('" + StringUtil.replaceAll(parentSample, ";", "','") + "')";
        DataSet dsTestCode = getQueryProcessor().getSqlDataSet(sqlTestCode);
        if (dsTestCode == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlTestCode;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsTestCode.size() == 0) {
            String errStr = getTranslationProcessor().translate("No test code found for the parent sample");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        //2. filter testcode by parent and assign to child in main dataset
        HashMap hm = new HashMap();
        for (int i = 0; i < dsMain.getRowCount(); i++) {
            String parentSample1 = dsMain.getValue(i, DATASET_PROPERTY_INPUTSAMPLE_ID, "");
            hm.clear();
            hm.put("s_sampleid", parentSample1);
            DataSet dsFilter = dsTestCode.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                String isPanelExists = Util.getUniqueList(dsFilter.getColumnValues("ispanel", ";"), ";", true); // This will be either Y or N // if mixmatch then logic will be change
                if ("Y".equalsIgnoreCase(isPanelExists)) {
                    //Test panel block
                    dsMain.setValue(i, DATASET_PROPERTY_TESTCODE, dsFilter.getColumnValues("lvtestpanelid", ";"));
                } else {
                    //Test code block
                    dsMain.setValue(i, DATASET_PROPERTY_TESTCODE, dsFilter.getColumnValues("lvtestcodeid", ";"));
                }
            }
        }
    }
/**
 * Description: This method is used for AddSDI in ReverseMovement sdc.
 * @throws SapphireException
 */
    private void addSDIReverseMovement() throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "ReverseMovement");
        props.setProperty("sampleid", dsMain.getColumnValues(DATASET_PROPERTY_LV_SAMPLE_ID, ";"));
        props.setProperty("extractionid", dsMain.getColumnValues(DATASET_PROPERTY_EXTRACTION_ID, ";"));
        props.setProperty("fromtramstop", dsMain.getColumnValues(DATASET_PROPERTY_FROM_TRAMSTOP, ";"));
        props.setProperty("pcranalyte", dsMain.getColumnValues(DATASET_PROPERTY_PCR_ANALYTE, ";"));
        props.setProperty("sequencinganalyte", dsMain.getColumnValues(DATASET_PROPERTY_SEQUENCING_ANALYTE, ";"));
        props.setProperty("testcode", dsMain.getColumnValues(DATASET_PROPERTY_TESTCODE, ";"));
        props.setProperty("frombatch", dsMain.getColumnValues(DATASET_PROPERTY_FROMBATCH, ";"));
        props.setProperty("ispending", dsMain.getColumnValues(DATASET_PROPERTY_ISPENDING, ";"));
        props.setProperty("totramstop", dsMain.getColumnValues(DATASET_PROPERTY_TO_TRAMSTOP, ";"));
        props.setProperty("notes", dsMain.getColumnValues(DATASET_PROPERTY_TO_COMMENTS, ";"));
        props.setProperty("copies", String.valueOf(dsMain.size()));

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        }catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Data submission is not successfully done in ReverseMovement SDC.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /*****************
     * BASE DESIGN ***********DO NOT CHANGE THIS
     *****************************/
    private DataSet dsMain = null;

    private static final String DATASET_PROPERTY_INPUTSAMPLE_ID = "inputsampleid";
    private static final String DATASET_PROPERTY_EXTRACTION_ID = "extractionid";
    private static final String DATASET_PROPERTY_LV_SAMPLE_ID = "lvsampleid";
    private static final String DATASET_PROPERTY_TESTCODE = "testcode";
    private static final String DATASET_PROPERTY_FROM_TRAMSTOP = "fromtramstop";
    private static final String DATASET_PROPERTY_TO_TRAMSTOP = "totramstop";
    private static final String DATASET_PROPERTY_PCR_ANALYTE = "pcranalyte";
    private static final String DATASET_PROPERTY_SEQUENCING_ANALYTE = "seqanalyte";
    private static final String DATASET_PROPERTY_ISPENDING = "ispending";
    private static final String DATASET_PROPERTY_TOBATCH = "tobatch";
    private static final String DATASET_PROPERTY_FROMBATCH = "frombatch";
    private static final String DATASET_PROPERTY_TO_COMMENTS = "comments";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_INPUTSAMPLE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_EXTRACTION_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LV_SAMPLE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TESTCODE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_FROM_TRAMSTOP, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TO_TRAMSTOP, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_PCR_ANALYTE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_SEQUENCING_ANALYTE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_ISPENDING, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TOBATCH, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_FROMBATCH, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TO_COMMENTS, DataSet.STRING);

        }
    }
}
