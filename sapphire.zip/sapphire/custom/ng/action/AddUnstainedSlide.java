package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;


/**
 * Created by msubhra on 5/18/2016.
 * Modified by sbaitalik
 * This action is used for creating unstained slides. Samples should be tissue and container type of the sample should be Block.
 * A user can select multiple samples and for each sample one unstained slides will be created.
 * Here on new requirement now unstained slide will be created but no test code will be associate with it.
 */
public class AddUnstainedSlide extends BaseAction {
    public String MANDATORY_INPUT_SAMPLE_ID = "";
    public static String PROPERTY_UNSTAINED_SLIDE_FLAG = "U";
    private final String Property_UnstainedSlides = "copies";
    private String Property_FromTramstop = "";

    public void processAction(PropertyList properties) throws SapphireException {

        MANDATORY_INPUT_SAMPLE_ID = properties.getProperty("s_sampleid");
        String copies = properties.getProperty(Property_UnstainedSlides);
        Property_FromTramstop = properties.getProperty("fromtramstop", "");
        if (Util.isNull(MANDATORY_INPUT_SAMPLE_ID)) {
            throw new SapphireException("Speciment cannot be null/blank.");
        }
        if (MANDATORY_INPUT_SAMPLE_ID.contains(";")) {
            throw new SapphireException("Select only one specimen.");
        }
        validateBackUp(MANDATORY_INPUT_SAMPLE_ID);
        String currentUser = connectionInfo.getSysuserId();
        String newsampleids = StringUtil.replaceAll(MANDATORY_INPUT_SAMPLE_ID, ";", "','");

       /* String sql = "select  distinct s.sampletypeid,t.containertypeid from trackitem t,s_sample s" +
                " where s.s_sampleid = t.linkkeyid1 and s.s_sampleid in ('" + newsampleids + "')";*/

        String sql =
                "select m.s_sampleid,m.lvtestcodeid,m.methodology,m.los,s.sampletypeid,t.containertypeid,s.u_type" +
                        " from s_sample s, trackitem t, u_sampletestcodemap m" +
                        " where s.s_sampleid=m.s_sampleid and s.s_sampleid= t.linkkeyid1 and s.s_sampleid='" + newsampleids + "'";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String errMsg = getTranslationProcessor().translate("Something Wrong. Please contact system administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (ds.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Please select correct sample");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }

        String sampletypeid1 = ds.getValue(0, "sampletypeid", "");
        String containertypeid1 = ds.getValue(0, "containertypeid", "");
        String type = ds.getValue(0, "u_type", "");
        /*if (!Util.isNull(type)) {
            String errorMsg = "Unstained slide(s) can only be created from patient sample or block";
            throw new SapphireException(errorMsg);
        }*/


        String unstainedChildSampleID = createChildSample(MANDATORY_INPUT_SAMPLE_ID, sampletypeid1, copies);

        String microtomySQL = "select u_microtomystn from sysuser where sysuserid = '" + currentUser + "'";
        DataSet dsMicrotomyStn = getQueryProcessor().getSqlDataSet(microtomySQL);
        if (dsMicrotomyStn == null) {
            String errMsg = getTranslationProcessor().translate("Something Wrong. Please contact system administrator.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsMicrotomyStn.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No Microtomy station is added with the user.\n" + microtomySQL);
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String microtomyStation = dsMicrotomyStn.getValue(0, "u_microtomystn");
        markAsUnstainedSlide(unstainedChildSampleID, microtomyStation);
        editTransportType(unstainedChildSampleID, containertypeid1);

        //addTestCode(newsampleids, unstainedChildSampleID); //Parent's Unstained Slide will not be associate with it
        //String msg = "Unstained Slide " + unstainedChildSampleID + " created successfully.";

        String allunstainde = getAllChildsAssociatedWithBlock(newsampleids);
        updateSlideSectiondt(unstainedChildSampleID);
        if (allunstainde.length() > 0)
            allunstainde = allunstainde + ";" + newsampleids;
        //String msg = unstainedChildSampleID;
        String msg = allunstainde;
        properties.setProperty("outmsg", msg);


    }

    private String getAllChildsAssociatedWithBlock(String sampleid) throws SapphireException {
        String newSlideIDs = "";
        String slides = Util.parseMessage(ApSql.GET_ALL_SPECIMENS_BY_BLOCK, sampleid);
        DataSet dsSlides = getQueryProcessor().getSqlDataSet(slides);
        if (dsSlides != null && dsSlides.size() > 0) {
            newSlideIDs = dsSlides.getColumnValues("s_sampleid", ";");
        }
        return newSlideIDs;
    }


    /**
     * @param sampleId     Input samples of the class
     * @param sampleTypeId Sampletype of the Input samples
     * @return newkeyid
     * @throws SapphireException
     * @desc This method is used for creating aliquot from selected sampleid. Input for this method is sampleid and sampletypeid.
     */

    private String createChildSample(String sampleId, String sampleTypeId, String copies) throws SapphireException {

        //Creating Unstained child Sample
        PropertyList prop = new PropertyList();
        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, sampleId);
        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, copies);
        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");
        prop.setProperty("sampletypeid", sampleTypeId);


        try {
            getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot Create Unstained Slides.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }


        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

    /**
     * This method is used for mark the newly created sampleids as U. This method takes input as the newly created sampleid and
     * change the u_type as 'U' in s_sample table.
     *
     * @param unstainedslides Child samples of Input samples of the class
     * @throws SapphireException
     */

    public void markAsUnstainedSlide(String unstainedslides, String microtomyStation) throws SapphireException {

        if (!Util.isNull(unstainedslides)) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, unstainedslides);
            props.setProperty("u_microtomystation", microtomyStation);
            props.setProperty("u_type", PROPERTY_UNSTAINED_SLIDE_FLAG);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception e) {
                throw new SapphireException("Unstained Flag not created");
            }

        }
    }

    /**
     * This method is used for updating the container type id of the newly created sampleids.
     *
     * @param unstainedChildSampleId Child samples of Input samples of the class
     * @param containertypeid        Container type ID of Input samples
     * @throws SapphireException
     */

    private void editTransportType(String unstainedChildSampleId, String containertypeid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, unstainedChildSampleId);
        props.setProperty("containertypeid", containertypeid);
        if (!Util.isNull(Property_FromTramstop)) {
            props.setProperty("u_currenttramstop", Property_FromTramstop);
        }
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot updated containertype in trackitem.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    /**
     * @param parentsample    Input samples of the class
     * @param unstainedslides Child samples of Input samples of the class
     * @throws SapphireException
     * @desc This method is used for addtest code to the newly created sampleids.
     */

    public void addTestCode(String parentsample, String unstainedslides) throws SapphireException {

        if (!Util.isNull(parentsample)) {
            if (!Util.isNull(unstainedslides)) {
                String psample = StringUtil.replaceAll(parentsample, ";", "','");
                String[] newSampleArr = StringUtil.split(unstainedslides, ";");
                String tc_sql = "select lvtestcodeid,NVL(ispanel,'N') as ispanel from u_sampletestcodemap where lvtestpanelid is null  and NVL(ispanel,'N') = 'N' and s_sampleid in('" + psample + "')"; // Modified By msubhra
                DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
                String tp_sql = "select unique lvtestpanelid,ispanel from u_sampletestcodemap where lvtestpanelid is not null and s_sampleid in ('" + psample + "')";
                DataSet dstespanel = getQueryProcessor().getSqlDataSet(tp_sql);
                if (tc_sql == null || tp_sql == null) {
                    String errMsg = getTranslationProcessor().translate("Something wrong! Please contact system administrator");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }
                if (dstestcode.size() == 0 && dstespanel.size() == 0) {
                    String error = getTranslationProcessor().translate("SampleID " + parentsample + " doesn't have any Test !" + tc_sql + tp_sql);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }

                DataSet dsSamplefinal = new DataSet();
                dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
                dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
                dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

                for (String currentsamp : newSampleArr) {
                    for (int j = 0; j < dstestcode.getRowCount(); j++) {
                        int rowID = dsSamplefinal.addRow();
                        dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                        dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                        dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));

                    }
                }

                for (String currentsamp : newSampleArr) {
                    for (int j = 0; j < dstespanel.getRowCount(); j++) {
                        int rowID = dsSamplefinal.addRow();
                        dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                        dsSamplefinal.setValue(rowID, "lvtestcode", dstespanel.getValue(j, "lvtestpanelid"));
                        dsSamplefinal.setValue(rowID, "ispanel", dstespanel.getValue(j, "ispanel", ""));

                    }
                }
                if (dsSamplefinal == null) {
                    String errMsg = getTranslationProcessor().translate("Something wrong! Please contact system administrator");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }
                if (dsSamplefinal.size() > 0) {
                    PropertyList hsAddTestCode = new PropertyList();
                    hsAddTestCode.clear();
                    hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
                    hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
                    hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
                    try {
                        getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
                    } catch (ActionException e) {
                        String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                    }
                }
            }


        }

    }

    private void validateBackUp(String sampleid) throws SapphireException {
        //String sql = "select u_type,u_currentmovementstep,s_sampleid from s_sample where s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "') and u_type is not null";
        String sql = "select u_type,u_currentmovementstep,s_sampleid from s_sample where s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
        DataSet dsSlideType = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();

        hm.clear();
        hm.put("u_type", "B");
        DataSet dsBackupTypeFilter = dsSlideType.getFilteredDataSet(hm);

        hm.clear();
        hm.put("u_type", "H");
        DataSet dsHNETypeFilter = dsSlideType.getFilteredDataSet(hm);

        hm.clear();
        hm.put("u_type", "NC");
        DataSet dsNCTypeFilter = dsSlideType.getFilteredDataSet(hm);

        hm.clear();
        hm.put("u_type", "PC");
        DataSet dsPCTypeFilter = dsSlideType.getFilteredDataSet(hm);

        hm.clear();
        hm.put("u_type", "U");
        DataSet dsUTypeFilter = dsSlideType.getFilteredDataSet(hm);

        if (dsBackupTypeFilter != null && dsBackupTypeFilter.size() > 0) {
            throw new SapphireException("Unstained slide can not be created from Backup Slide(s).");
        } else if (dsHNETypeFilter != null && dsHNETypeFilter.size() > 0) {
            throw new SapphireException("Unstained slide can not be created from HNE Slide(s).");
        } else if (dsNCTypeFilter != null && dsNCTypeFilter.size() > 0) {
            throw new SapphireException("Unstained slide can not be created from Control Slide(s).");
        } else if (dsPCTypeFilter != null && dsPCTypeFilter.size() > 0) {
            throw new SapphireException("Unstained slide can not be created from Control Slide(s).");
        } else if (dsUTypeFilter != null && dsUTypeFilter.size() > 0) {
            throw new SapphireException("Unstained slide can not be created from Unstained Slide(s).");
        } else {
            return;
        }

    }

    private void updateSlideSectiondt(String newkeyid1) throws SapphireException {
        String[] childsArry = StringUtil.split(newkeyid1, ";");
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid1);
        props.setProperty("u_slidesectiondate", StringUtil.repeat("n", childsArry.length, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update slide section date." + ex.getMessage());
        }
    }
}

