
package sapphire.custom.ng.action;

import org.tempuri.vms.startvmsws.StartVMSws;
import org.tempuri.vms.startvmsws.StartVMSwsSoap;
import org.w3c.dom.CharacterData;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.FilenameFilter;
import java.io.StringReader;

/**
 * Created by dgupta on 6/23/2016.
 */
public class CallVMSWebService extends BaseAction {


    /*
    *   This si OOB method povided to override as per requirement
    *   this method calls VMS webserive and pass input xml as input parameter
    *   if input xml is not provided it uses hardcoded example xml and passes
    *   back it with input properties
    *
    * */
    public void processAction(PropertyList properties) throws SapphireException {

        String inXml = "<VMSSession Version=\"1.0\" Accessor=\"{226D4CB8-C5FD-4f68-A8B8-B7E4756F7B0A}\" UserID=\"iUserLastName\" UserDisplayName=\"UserLastName, UserFirstName\">\n" +
                "  <MenuItems>\n" +
                "    <MenuItem Id=\"mnuPrevious\" Type=\"Button\" OnClick=\"PreviousImage();\" Img=\"images/Previous.jpg\" ImgOver=\"images/Previous.jpg\" Text=\"Previous\" />\n" +
                "    <MenuItem Id=\"mnuNext\" Type=\"Button\" OnClick=\"NextImage();\" Img=\"images/Next.jpg\" ImgOver=\"images/Next.jpg\" Text=\"Next\" />\n" +
                "  </MenuItems>\n" +
                "  <MetaData>\n" +
                "    <DataItem Name=\"LISPlugIn\" Value=\"LabVantage\" />\n" +
                "    <DataItem Name=\"SSN\" Value=\"000-00-0000\" />\n" +
                "    <DataItem Name=\"User\" Value=\"UserLastName, UserFirstName\" />\n" +
                "    <DataItem Name=\"Level of Service\" Value=\"Technical\" />\n" +
                "  </MetaData>\n" +
                "  <Images>\n" +
                "    <Image ExternalIdentifier=\"388505\" ImageSource=\"APERIO\" DefaultImage=\"true\" AllowEdit=\"false\" TitleBar=\"Niethammer, William - ER - 388505 - Case# HIA16-000104\" Description=\"Niethammer, William - ER\">\n" +
                "      <MenuItems>\n" +
                "        <MenuItem Id=\"mnuQCStatusUpdate\" Type=\"Parent\" OnClick=\"\" Img=\"images/GreenBall_Over.gif\" ImgOver=\"images/GreenBall_Over.gif\" Text=\"QC Status Update\">\n" +
                "          <SubItem Id=\"mnuQCStatusUpdate1\" Type=\"Button\" OnClick=\"QCStatusUpdate('pass',true);\" Img=\"images/GreenBall_Over.gif\" ImgOver=\"images/GreenBall_Over.gif\" Text=\"Pass\" />\n" +
                "          <SubItem Id=\"mnuQCStatusUpdate2\" Type=\"Button\" OnClick=\"QCStatusUpdate('fail',true);\" Img=\"images/QCFail.gif\" ImgOver=\"images/QCFail.gif\" Text=\"Fail\" />\n" +
                "          <SubItem Id=\"mnuQCStatusUpdate3\" Type=\"Button\" OnClick=\"QCStatusUpdate('suboptimal',true);\" Img=\"images/Delete_Over.gif\" ImgOver=\"images/Delete_Over.gif\" Text=\"Suboptimal\" />\n" +
                "        </MenuItem>\n" +
                "      </MenuItems>\n" +
                "      <MetaData>\n" +
                "        <DataItem Name=\"Date Slide Run\" Value=\"7/4/2016 2:35:31 PM\" />\n" +
                "        <DataItem Name=\"Test Name\" Value=\"ER\" />\n" +
                "        <DataItem Name=\"Specimen Barcode\" Value=\"HIA16-000104\" />\n" +
                "        <DataItem Name=\"Parent Specimen\" Value=\"S16-TEST2\" />\n" +
                "        <DataItem Name=\"Patient Name\" Value=\"Niethammer, William\" />\n" +
                "      </MetaData>\n" +
                "      <ImageDetails>\n" +
                "        <ImageDetail Name=\"FilePath\" Value=\"\\\\usavhnas2.chromavision.int\\IT_Developement\\QA\\Aperio\\Images\\388505.tif\" />\n" +
                "        <ImageDetail Name=\"PerformAnalysis\" Value=\"0\" />\n" +
                "        <ImageDetail Name=\"TestCode\" Value=\"3093X\" />\n" +
                "      </ImageDetails>\n" +
                "    </Image>\n" +
                "    <Image ExternalIdentifier=\"388506\" ImageSource=\"APERIO\" DefaultImage=\"false\" AllowEdit=\"false\" TitleBar=\"Niethammer, William - PgR - 388506 - Case# HIA16-000104\" Description=\"Niethammer, William - PgR\">\n" +
                "      <MenuItems>\n" +
                "        <MenuItem Id=\"mnuQCStatusUpdate\" Type=\"Parent\" OnClick=\"\" Img=\"images/GreenBall_Over.gif\" ImgOver=\"images/GreenBall_Over.gif\" Text=\"QC Status Update\">\n" +
                "          <SubItem Id=\"mnuQCStatusUpdate1\" Type=\"Button\" OnClick=\"QCStatusUpdate('pass',false);\" Img=\"images/GreenBall_Over.gif\" ImgOver=\"images/GreenBall_Over.gif\" Text=\"Pass\" />\n" +
                "          <SubItem Id=\"mnuQCStatusUpdate2\" Type=\"Button\" OnClick=\"QCStatusUpdate('fail',false);\" Img=\"images/QCFail.gif\" ImgOver=\"images/QCFail.gif\" Text=\"Fail\" />\n" +
                "          <SubItem Id=\"mnuQCStatusUpdate3\" Type=\"Button\" OnClick=\"QCStatusUpdate('suboptimal',false);\" Img=\"images/Delete_Over.gif\" ImgOver=\"images/Delete_Over.gif\" Text=\"Suboptimal\" />\n" +
                "        </MenuItem>\n" +
                "      </MenuItems>\n" +
                "      <MetaData>\n" +
                "        <DataItem Name=\"Date Slide Run\" Value=\"7/4/2016 2:35:31 PM\" />\n" +
                "        <DataItem Name=\"Test Name\" Value=\"PgR\" />\n" +
                "        <DataItem Name=\"Specimen Barcode\" Value=\"HIA16-000104\" />\n" +
                "        <DataItem Name=\"Parent Specimen\" Value=\"S16-TEST2\" />\n" +
                "        <DataItem Name=\"Patient Name\" Value=\"Niethammer, William\" />\n" +
                "      </MetaData>\n" +
                "      <ImageDetails>\n" +
                "        <ImageDetail Name=\"FilePath\" Value=\"\\\\usavhnas2.chromavision.int\\IT_Developement\\QA\\Aperio\\Images\\388506.tif\" />\n" +
                "        <ImageDetail Name=\"PerformAnalysis\" Value=\"0\" />\n" +
                "        <ImageDetail Name=\"TestCode\" Value=\"3097X\" />\n" +
                "      </ImageDetails>\n" +
                "    </Image>\n" +
                "  </Images>\n" +
                "</VMSSession>";

        try {
            String inputXml = properties.getProperty("inputXml");
            if (0 == inputXml.length()) inputXml = inXml;
            StartVMSws vmsWs = new StartVMSws();
            StartVMSwsSoap vmsSoap = vmsWs.getStartVMSwsSoap();
            String vmsResponce = vmsSoap.startVMS(inputXml);
            System.out.println(vmsResponce);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(vmsResponce));

            Document doc = db.parse(is);
            NodeList nodes = doc.getElementsByTagName("URL");
            Element element = (Element) nodes.item(0);
            String responce = element.getAttribute("Success");
            if (responce.equalsIgnoreCase("true")) {
                Node child = element.getFirstChild();
                if (child instanceof CharacterData) {
                    responce = ((CharacterData) child).getData();
                    System.out.println(responce);
                }
                String jsresponce = "<script language=\"JavaScript\" > sapphire.ui.dialog.open('VMS', " + responce + ",false, 900,700,null, null, false) </script>";
                String openvms = "sapphire.ui.dialog.open('VMS', \" + responce +\",false, 900,700,null, null, false)";
                properties.setProperty("status", "Success");
                properties.setProperty("url", responce);
                properties.setProperty("jsurl", jsresponce);
                properties.setProperty("openvms", openvms);
            } else {
                properties.setProperty("status", "Fail");
                properties.setProperty("url", "Could not open vms url");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /*
    *   Main method is used to test code independently 
    * */
    public static void main(String[] args) {

        String inputXml = "<VMSSession Version='1.0' Accessor='{226D4CB8-C5FD-4f68-A8B8-B7E4756F7B0A}'>\n" +
                "  <MenuItems />\n" +
                "  <Images>\n" +
                "    <Image ExternalIdentifier='62443356' ImageSource='Aperio' DefaultImage='true' AllowEdit='true' TitleBar='Definiens RTS_Blue_Brown IA Validation Slide 62443356' Description='IA Validation Slide 62443356 - uses Definiens RTS_Blue_Brown Algorithm' Icon='images/PatientSlide.gif'>\n" +
                "      <ImageDetails>\n" +
                "        <ImageDetail Name='FilePath' Value='\\\\usavhnas2\\IT_Developement\\DEV\\Aperio\\Quantitative\\Images\\01\\62443356.tif' />\n" +
                "        <ImageDetail Name='SnapshotPath' Value='\\\\usavhnas2\\IT_Developement\\DEV\\Aperio\\Quantitative\\TempWorkingFolder\\' />\n" +
                "        <ImageDetail Name='SnapshotBaseFileName' Value='62443356' />\n" +
                "        <ImageDetail Name='SpecimenScanUID' Value='f86f2ee3-8153-411f-8c5e-93404f122854' />\n" +
                "        <ImageDetail Name='SpecimenUID' Value='d150688e-3d75-487e-a07c-06874badf5c8' />\n" +
                "        <ImageDetail Name='SpecimenName' Value='Her2' />\n" +
                "        <ImageDetail Name='CaseID' Value='123TestCaseID' />\n" +
                "        <ImageDetail Name='Instrument' Value='Aperio' />\n" +
                "        <ImageDetail Name='PerformAnalysis' Value='1' />\n" +
                "        <ImageDetail Name='TestCode' Value='IH00172' />\n" +
                "        <ImageDetail Name='AlgorithmVendor' Value='Definiens' />\n" +
                "        <ImageDetail Name='AlgorithmName' Value='RTS_Blue_Brown' />\n" +
                "        <ImageDetail Name='AlgorithmPlugInAssembly' Value='DefiniensImageAnalyzer' />\n" +
                "        <ImageDetail Name='AlgorithmParameterSet' Value='\\\\usavhnas2\\IT_Developement\\DEV\\Aperio\\Quantitative\\Ruleset\\Version14\\RTS_Blue_Brown.dcp' />\n" +
                "      </ImageDetails>\n" +
                "      <MetaData>\n" +
                "        <DataItem Name='Date Slide Run' Value='6/15/2016 3:40:51 PM' />\n" +
                "        <DataItem Name='Validation Slide' Value='62443356' />\n" +
                "      </MetaData>\n" +
                "      <MenuItems>\n" +
                "        <MenuItem Id=\"mnuPass\" Type=\"Button\" OnClick=\"window.location.href='Internal/Validation.aspx';\" Img=\"images/Previous.jpg\" ImgOver=\"images/Previous.jpg\" Text=\"Back To Validation Slide List\" />\n" +
                "      </MenuItems>\n" +
                "    </Image>\n" +
                "  </Images>\n" +
                "</VMSSession>";

        try {

            File[] f = new File("\\\\usavhnas2\\IT_Developement\\QA\\Aperio\\Images\\").listFiles();
            int i = (int) (Math.random() * 100);
            System.out.println("random double      " + f[i].getName());
            System.out.println("random double      " + f[i].getName().substring(0, f[i].getName().indexOf(".tif")));

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
