package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by kshahbaz on 7/6/2016.
 */
public class MolecularAddBatch  extends BaseAction

    {
        public void processAction(PropertyList properties) throws SapphireException {

        String reginfo = properties.getProperty("reginfo","");
        String sampinfo = properties.getProperty("sampinfo","");
        String batchname = properties.getProperty("batchname","");
        String batchtype = properties.getProperty("batchtype","");
        String origin = properties.getProperty("origin","");
        String batchmovestatus = properties.getProperty("batchmovestatus","");

        String batchid = createBatch(batchname,batchtype,origin,batchmovestatus);
        if(!Util.isNull(batchid)){
            addReagent(batchid,reginfo);
            addSample(batchid,sampinfo);

        }
    }


    private String createBatch(String batchname,String batchtype,String origin,String batchmovestatus) throws SapphireException {
        String ngbatchid = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype",batchtype);
        pl.setProperty("batchname",batchname);
        pl.setProperty("origin",origin);
        pl.setProperty("batchmovestatus",batchmovestatus);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid=pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return  ngbatchid;
    }

    private void addReagent(String batchid,String reginfo) throws SapphireException{
        if(!Util.isNull(batchid) && !Util.isNull(reginfo)){
            DataSet result = null;
            String reginfoArr[]= StringUtil.split(reginfo,";");
            if(reginfoArr!=null && reginfoArr.length>0){
                result = new DataSet();
                result.addColumn("reagentid",DataSet.STRING);
                result.addColumn("reagenttype",DataSet.STRING);
                result.addColumn("reagenttypeversion",DataSet.STRING);
                for (int i = 0; i < reginfoArr.length; i++) {
                    String comb = reginfoArr[i];
                    if (!Util.isNull(comb)) {
                        String combArr[]= StringUtil.split(comb,"@*@");
                        if(combArr!=null && combArr.length>0) {
                            int rownum = result.addRow();
                            result.setValue(rownum, "reagentid",combArr[0]);
                            result.setValue(rownum, "reagenttype",combArr[1]);
                            result.setValue(rownum, "reagenttypeversion",combArr[2]);
                        }
                    }
                }
                if(result!=null && result.size()>0){
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
                    props.setProperty("reagentid",result.getColumnValues("reagentid",";"));
                    props.setProperty("reagenttype",result.getColumnValues("reagenttype",";"));
                    props.setProperty("reagenttypeversion",result.getColumnValues("reagenttypeversion",";"));
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_reagent_link");
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                }
            }
        }
    }


    private void addSample(String batchid,String sampinfo) throws SapphireException{
        if(!Util.isNull(batchid) && !Util.isNull(sampinfo)){
            DataSet result = null;
            String sampinfoArr[]= StringUtil.split(sampinfo,";");
            if(sampinfoArr!=null && sampinfoArr.length>0){
                result = new DataSet();
                result.addColumn("sampleid",DataSet.STRING);
                result.addColumn("analyte",DataSet.STRING);

                for (int i = 0; i < sampinfoArr.length; i++) {
                    String comb = sampinfoArr[i];
                    if (!Util.isNull(comb)) {
                        String combArr[]= StringUtil.split(comb,"@*@");
                        if(combArr!=null && combArr.length>0) {
                            int rownum = result.addRow();
                            result.setValue(rownum, "sampleid",combArr[0]);
                            result.setValue(rownum, "analyte",combArr[1]);
                        }
                    }
                }

                if(result!=null && result.size()>0){
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
                    props.setProperty("sampleid",result.getColumnValues("sampleid",";"));
                    props.setProperty("analyte",result.getColumnValues("analyte",";"));
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_sample_link");
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                }
            }
        }
    }



}
