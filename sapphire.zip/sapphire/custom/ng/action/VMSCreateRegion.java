package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdidata.AddDataSet;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by dgupta on 7/25/2016.
 */
    public class VMSCreateRegion extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("externalimageidentifier");
        String regionid = properties.getProperty("regionid");
        String analysisRegion = properties.getProperty("analysisregion");
        String displayid = properties.getProperty("displayid");
        String regionimagepath = properties.getProperty("regionimagepath");
        DataSet dsFirstRegion = null;
        DataSet dsRegion = null;
        HashMap<String, String> hmRegion = new HashMap<>();

        DataSet dsWorkitem = getQueryProcessor().getSqlDataSet("select keyid1, workitemid, workiteminstance, sdiworkitemid from sdiworkitem where sdcid='Sample'" +
                "  and keyid1='" + sampleid + "'");
        if(dsWorkitem == null || dsWorkitem.getRowCount() ==0)
            properties.setProperty("Testcode", "Test code not applied to sample, workitem not found");

        // accomadate edit option that is a region is created but later on rigion is moved from original position
        // so for same region id new set of data get created
         dsFirstRegion= getQueryProcessor().getSqlDataSet("select distinct dataset, paramid,  enteredtext from sdidataitem where paramlistid ='RegionCreated' and sdcid='Sample' " +
                "  and keyid1='" +sampleid+ "'");       //and paramid='Regionid'  and ENTEREDTEXT='" + regionid + "'"

        if(dsFirstRegion == null || dsFirstRegion.getRowCount() ==0){
            applyNewRegion(sampleid,  properties, dsWorkitem);
            markReportImage(sampleid);
        }else {
            hmRegion.put("paramid", "Regionid");
            hmRegion.put("enteredtext", regionid);
            dsRegion = dsFirstRegion.getFilteredDataSet(hmRegion);
            if(dsRegion == null || dsRegion.getRowCount() ==0) {
                applyNewRegion(sampleid,  properties, dsWorkitem);
            }else{
                editRegion(properties, dsRegion);
            }
        }
    }

    private void editRegion(PropertyList properties, DataSet dsRegion) throws ActionException  {
        String dataset;
        String paramName="";
        PropertyList props = new PropertyList();
        dataset = dsRegion.getBigDecimal(0,"dataset").intValue()+"";
        String sampleid = properties.getProperty("externalimageidentifier");
        DataSet dsParam = getQueryProcessor().getSqlDataSet("select paramid, paramtype, numreplicates, usersequence, displayunderparamname, u_show, ' ' entertext from PARAMLISTITEM " +
                "  where paramlistid='RegionCreated'  order by usersequence") ;

        DataSet dsPlCopy = dsParam.copy();
        for(int i=0 ; i< dsParam.getRowCount(); i++){
            if(dsPlCopy.getRowCount()>0)
                dsPlCopy.deleteRow(0);
        }
        for(int i=0 ; i< dsParam.getRowCount(); i++){
            paramName = dsParam.getString(i, "displayunderparamname") ;
            if(properties.containsKey(paramName)) {
                dsParam.setString(i, "entertext", properties.getProperty(paramName));
                dsPlCopy.copyRow(dsParam,i,1 );
            }
        }

        props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, "RegionCreated");
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset );
        props.setProperty(EnterDataSet.PROPERTY_PARAMS, ""+dsPlCopy.getRowCount());

        if(dsPlCopy.getRowCount()>0) {
            for (int i = 1; i <= dsPlCopy.getRowCount(); i++) {
                props.setProperty("paramid" + i, dsPlCopy.getString(i - 1, "paramid"));
                props.setProperty("paramtype" + i, dsPlCopy.getString(i - 1, "paramtype"));
                props.setProperty("replicateid" + i, "" + dsPlCopy.getBigDecimal(i - 1, "numreplicates").intValue());
                props.setProperty("enteredtext" + i, dsPlCopy.getString(i - 1, "entertext"));
            }
            props.setProperty("matchusersequence", "Y");
            getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, props);
        }else{
            throw new ActionException("no analyet found to update");
        }

    }

    private void applyNewRegion(String sampleid, PropertyList properties, DataSet dsWorkitem) throws ActionException {
        String dataset;
        String paramName="";

        DataSet dsParam = getQueryProcessor().getSqlDataSet("select paramid, paramtype, numreplicates, usersequence, displayunderparamname, u_show, ' ' entertext from PARAMLISTITEM " +
                "  where paramlistid='RegionCreated'  order by usersequence") ;

        PropertyList props = new PropertyList();
        props.setProperty(AddDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(AddDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(AddDataSet.PROPERTY_PARAMLISTID, "RegionCreated");
        props.setProperty(AddDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(AddDataSet.PROPERTY_VARIANTID, "1");
        if (dsWorkitem == null || dsWorkitem.getRowCount() == 0) {
        } else {
            props.setProperty("sourceworkitemid", dsWorkitem.getString(0, "workitemid", ""));
            props.setProperty("sourceworkiteminstance", "" + dsWorkitem.getBigDecimal(0, "workiteminstance").longValue());
        }
        getActionProcessor().processAction(AddDataSet.ID, AddDataSet.VERSIONID, props);

        DataSet dsPl = new DataSet(props.getProperty("newdatasetinstancexml"));
        dataset = dsPl.getString(0, "dataset");

        props = new PropertyList();
        dsPl.clear();
        dsPl = dsParam.copy();
        for(int i=0 ; i< dsParam.getRowCount(); i++){
            if(dsPl.getRowCount()>0)
            dsPl.deleteRow(0);
        }
        for(int i=0 ; i< dsParam.getRowCount(); i++){
            paramName = dsParam.getString(i, "displayunderparamname") ;
            if(properties.containsKey(paramName.trim())) {
                dsParam.setString(i, "entertext", properties.getProperty(paramName));
                dsPl.copyRow(dsParam,i,1 );
            }
        }

        props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, "RegionCreated");
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset );
        props.setProperty(EnterDataSet.PROPERTY_PARAMS, ""+dsPl.getRowCount());
        if(dsPl.getRowCount()>0) {
            for (int i = 1; i <= dsPl.getRowCount(); i++) {
                props.setProperty("paramid" + i, dsPl.getString(i - 1, "paramid"));
                props.setProperty("paramtype" + i, dsPl.getString(i - 1, "paramtype"));
                props.setProperty("replicateid" + i, "" + dsPl.getBigDecimal(i - 1, "numreplicates").intValue());
                props.setProperty("enteredtext" + i, dsPl.getString(i - 1, "entertext"));
            }
            props.setProperty("matchusersequence", "Y");
            getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, props);
        }else{
            throw  new ActionException("no input analyet found ");
        }

        String makeDefaul = properties.getProperty("analysisregion");
        if(makeDefaul != null && makeDefaul.equalsIgnoreCase("False")){
            DataSet dsDefault= getQueryProcessor().getSqlDataSet("select keyid1,  paramlistid, paramlistversionid, variantid, dataset, " +
                    " case when  dataset = '" + dataset +"' THEN 'Y' ELSE 'N' End   rpt" +
                    " from sdidata where sdcid='Sample' " +
                    " and paramlistid='RegionCreated'  and keyid1='" + sampleid + "'")  ;
            PropertyList propsEdit = new PropertyList();
            if(dsDefault != null && dsDefault.getRowCount()>0) {
                propsEdit.setProperty(EditDataSet.PROPERTY_SDCID, "Sample");
                propsEdit.setProperty(EditDataSet.PROPERTY_KEYID1, sampleid);
                propsEdit.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsDefault.getColumnValues("paramlistid", ";"));
                propsEdit.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsDefault.getColumnValues("paramlistversionid", ";"));
                propsEdit.setProperty(EditDataSet.PROPERTY_VARIANTID, dsDefault.getColumnValues("variantid", ";"));
                propsEdit.setProperty(EditDataSet.PROPERTY_DATASET, dsDefault.getColumnValues("dataset", ";"));
                propsEdit.setProperty("u_showonreport", dsDefault.getColumnValues("rpt", ";"));

                getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, propsEdit);
            }
        }

      /*  props = new PropertyList();
        props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, "RegionCreated");
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset);
        props.setProperty("paramid" ,dsPl.getColumnValues("paramid", ";") );
        props.setProperty("paramtype" ,dsPl.getColumnValues( "paramtype", ";") );
        props.setProperty("replicateid" ,  dsPl.getColumnValues("numreplicates", ";") );
        props.setProperty("u_show" , dsPl.getColumnValues( "u_show", ";") );

        getActionProcessor().processAction(EditDataItem.ID, EditDataItem.VERSIONID, props);*/

    }

    private void markReportImage(String sampleid) throws SapphireException{
        PropertyList propsEdit = new PropertyList();
        propsEdit.setProperty(EditDataSet.PROPERTY_SDCID, "Sample");
        propsEdit.setProperty(EditDataSet.PROPERTY_KEYID1, sampleid);
        propsEdit.setProperty(EditDataSet.PROPERTY_PARAMLISTID, "RegionCreated");
        propsEdit.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        propsEdit.setProperty(EditDataSet.PROPERTY_VARIANTID, "1");
        propsEdit.setProperty(EditDataSet.PROPERTY_DATASET, "1" );
        propsEdit.setProperty("u_showonreport","Y");

        getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, propsEdit);


    }
}
