package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.MannualSampleRouting;
import sapphire.custom.ng.action.util.NGSendMail;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import static sapphire.custom.ng.util.Util.getUniqueList;

/**
 * Created by akumar on 5/4/2016.
 *
 * @desc :This Action moves the samples to the corresponding tramstops which is
 * defined in the sampletype and containertype of the sample.When we
 * generate accession all the samples automatically moves to its defined
 * tramstop. The movement is driven by sampletype and container type of
 * the samples chosen.
 */
public class SampleMovement extends BaseAction {

    public static final String ID = "SampleMovement";
    public static final String VERSION_ID = "1";
    String message = "Operation Successful.";

    /*
     * Note: Any changes made in samplemovement.java file, the same changes
     * should also be made in the ReceiveQCPendingSample except any label
     * changes
     */
    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid", "");
        String sampleForLabel = "";
        HashMap<String, String> hm = new HashMap<String, String>();

        if (accessionid.equalsIgnoreCase("")) {
            throw new SapphireException("<b>Accessionid is blank.</b>");
        }
        // CHECK ACCESSION IS GENERATED OR NOT STARTS(SURAJIT)
        // String sqlVal = "select s_sampleid,u_accessioningcomplete from
        // s_sample where u_accessionid='" + accessionid + "'";
        String sqlVal = Util.parseMessage(ApSql.GET_SAMPLE_BY_ACCESSIONID, accessionid);
        DataSet dsVal = getQueryProcessor().getSqlDataSet(sqlVal);
        if (dsVal != null && dsVal.size() == 0) {
            throw new SapphireException("<b>Accession does not found any specimen(s).</b>");
        }
        HashMap hmv = new HashMap();
        hmv.put("u_accessioningcomplete", "N");
        DataSet dsFilV = dsVal.getFilteredDataSet(hmv);
        if (dsFilV != null && dsFilV.size() == 0) {
            //throw new SapphireException("<b>There is no specimen(s) pending to generate accession further.</b>");TODO NOT REQUIRED
            return;
        }
        // CHECK ACCESSION IS GENERATED OR NOT ENDS(SURAJIT)
        /*
         * String sql =
		 * "select s.u_type,s.s_sampleid,s.sampletypeid,t.containertypeid,sc.u_movementstep,sc.u_methodology,sc.u_los, sc.u_nextmovementstep, "
		 * + " s.u_performingsite,stm.methodology testmethodology, stm.los, " +
		 * " case when sc.u_methodology is null then 'NA' when stm.methodology = sc.u_methodology then 'true' else 'false' end as methodologyresult, "
		 * +
		 * " case when sc.u_los is null then 'NA' when stm.los = sc.u_los then 'true' else 'false' end as losresult"
		 * +
		 * " from s_sample s,trackitem t,s_sampletypecontainertype sc,U_ACCESSION ac, u_sampletestcodemap stm  "
		 * + " where s.u_accessionid=ac.U_ACCESSIONid and " +
		 * " s.s_sampleid=t.linkkeyid1 and ac.U_ACCESSIONid ='" + accessionid +
		 * "' and s.s_sampleid = stm.s_sampleid(+) " +
		 * " and sc.s_sampletypeid=s.sampletypeid and sc.containertypeid=t.containertypeid and s.u_accessioningcomplete='N'"
		 * ;
		 */
        String sql = Util.parseMessage(ApSql.GET_SAMPLE_MOVEMENT_BY_ACCESSIONID, accessionid);
        DataSet dsMove = getQueryProcessor().getSqlDataSet(sql);
        if (dsMove == null) {
            String err = getTranslationProcessor().translate("Contact you Administrator. SQL failed:");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
        if (dsMove.size() == 0) {
            String errmsg = getTranslationProcessor().translate("Steps is not defined in master data. SQL failed:");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

        sql = Util.parseMessage(ApSql.GET_SITE_BY_DEPARTMENT, connectionInfo.getDefaultDepartment());
        DataSet dsDefaultSiteInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsDefaultSiteInfo == null)
            throw new SapphireException("The below query cannot be executed.\n" + sql);
        if (dsDefaultSiteInfo.size() == 0)
            throw new SapphireException("Current logged in department doesn't have site info.");
        String defaultSite = dsDefaultSiteInfo.getValue(0, "u_site", "");

        DataSet dsMoveFinal = new DataSet();
        dsMoveFinal.addColumn("sampleid", DataSet.STRING);
        dsMoveFinal.addColumn("u_movementstep", DataSet.STRING);
        dsMoveFinal.addColumn("newmovement", DataSet.STRING);
        dsMoveFinal.addColumn("currentmovementstep", DataSet.STRING);
        dsMoveFinal.addColumn("u_type", DataSet.STRING);// TODO BACKUP WILL GO
        dsMoveFinal.addColumn("normalroute", DataSet.STRING);// TODO BACKUP WILL GO
        // DIRECTLY HIRTOLOGY
        // ARCHIVE(SURAJIT
        // 08/19/2017)
        /* Change By Subhendu for Performing Site in Sample 4th Mar 2017 + */
        dsMoveFinal.addColumn("performingsite", DataSet.STRING);
        String uniqueSampleId = Util.getUniqueList(dsMove.getColumnValues("s_sampleid", ";"), ";", true);
        String[] tempUniqueSampleId = uniqueSampleId.split(";");
        String nxtMovementStep = "";
        for (int i = 0; i < tempUniqueSampleId.length; i++) {

            hm.clear();
            hm.put("s_sampleid", tempUniqueSampleId[i]);
            DataSet filterDS = dsMove.getFilteredDataSet(hm);

            int row = dsMoveFinal.addRow();
            dsMoveFinal.setValue(row, "sampleid", filterDS.getValue(0, "s_sampleid"));
            dsMoveFinal.setValue(row, "u_movementstep", filterDS.getValue(0, "u_movementstep"));
            dsMoveFinal.setValue(row, "performingsite", filterDS.getValue(0, "u_performingsite"));
            dsMoveFinal.setValue(row, "u_type", filterDS.getValue(0, "u_type"));// TODO
            // BACKUP
            // WILL
            // GO
            // DIRECTLY
            // HIRTOLOGY
            // ARCHIVE(SURAJIT
            // 08/19/2017)
            boolean flagNormalRoute = true;
            for (int j = 0; j < filterDS.size(); j++) {
                String methodology = filterDS.getValue(j,"testmethodology");
                if (!Util.isNull(filterDS.getValue(j, "u_performingsite"))) {
                    String performingdeptsite = filterDS.getValue(j, "performingdeptsite", "");
                    if (!Util.isNull(defaultSite) && defaultSite.equalsIgnoreCase(performingdeptsite) && !filterDS.getValue(j, "u_performingsite").endsWith("-Accessioning")) {
                        flagNormalRoute = false;
                    } else {
                        nxtMovementStep = "LogisticCOC";
                    }
                    break;
                } else if ("B".equalsIgnoreCase(filterDS.getValue(j, "u_type"))) {
                    nxtMovementStep = "HistologyArchieve";// TODO BACKUP WILL GO
                    // DIRECTLY
                    // HIRTOLOGY
                    // ARCHIVE(SURAJIT
                    // 08/19/2017)
                    break;
                } else if ("EU".equalsIgnoreCase(filterDS.getValue(j, "u_type"))) {
                    nxtMovementStep = "QuantPending";// TODO ELUSION TUBE WILL
                    // GO TO
                    // QUANTIFICATION(SURAJIT
                    // 13/10/2017)
                    break;
                }
                else if ("true".equalsIgnoreCase(filterDS.getValue(j, "methodologyresult"))
                        && ("true".equalsIgnoreCase(filterDS.getValue(j, "losresult"))
                        || "NA".equalsIgnoreCase(filterDS.getValue(j, "losresult")))) {
                    nxtMovementStep = filterDS.getValue(j, "u_nextmovementstep");
                    break;
                } else if ("true".equalsIgnoreCase(filterDS.getValue(j, "methodologyresult"))
                        && "NA".equalsIgnoreCase(filterDS.getValue(j, "losresult"))) {
                    nxtMovementStep = filterDS.getValue(j, "u_nextmovementstep");
                    break;
                }
                /*FOR MULTIOMYX  */
                else if ("Multiomyx".equalsIgnoreCase(methodology)){
                    if(("CU".equalsIgnoreCase(filterDS.getValue(j, "u_type"))) || ("CST".equalsIgnoreCase(filterDS.getValue(j, "u_type")))){
                        nxtMovementStep = "PathSupport";
                    }
                    else
                        nxtMovementStep = filterDS.getValue(j, "u_movementstep");

                }
                else
                    nxtMovementStep = filterDS.getValue(j, "u_movementstep");
            }
            dsMoveFinal.setValue(i, "newmovement", nxtMovementStep);
            if (flagNormalRoute) {
                dsMoveFinal.setValue(row, "normalroute", "Y");
            } else {
                dsMoveFinal.setValue(row, "normalroute", "N");
            }

        }
        /* Change By Subhendu for Performing Site in Sample 4th Mar 2017 - */

        /*********************
         * SAMPLE ROUTING FOR Esophageal Brushing,Unstained Slide(s),IHC
         ***************************/
        /*
         * IF ( Sample is having sampletype = Esophageal Brushing and
		 * Containertype= Unstained Slide(s) and testcode methodology is only
		 * IHC ) THEN Route the sample to Histo-Setup ELSE Route the sample to
		 * Fresh Prep
		 */
        hm.clear();
        hm.put("sampletypeid", "Esophageal Brushing");
        hm.put("containertypeid", "Unstained Slide(s)");
        hm.put("u_performingsite", null);
        DataSet dsFilter = dsMove.getFilteredDataSet(hm);

        if (dsFilter != null && dsFilter.size() > 0) {
            sql = "select distinct stm.methodology t_methodology,s.s_sampleid,s.sampletypeid,t.containertypeid,sc.u_movementstep,sc.u_methodology,sc.u_los,sc.u_nextmovementstep"
                    + " from s_sample s,trackitem t,s_sampletypecontainertype sc,u_accession ac, u_sampletestcodemap stm"
                    + " where s.u_accessionid=ac.u_accessionid and" + " s.s_sampleid=t.linkkeyid1"
                    + " and s.s_sampleid in('"
                    + StringUtil.replaceAll(Util.getUniqueList(dsMove.getColumnValues("s_sampleid", ";"), ";", true),
                    ";", "','")
                    + "')" + " and sc.s_sampletypeid=s.sampletypeid" + " and stm.s_sampleid=s.s_sampleid"
                    + " and sc.containertypeid=t.containertypeid and s.u_accessioningcomplete='N'";
            DataSet dsResults = getQueryProcessor().getSqlDataSet(sql);
            for (int i = 0; i < dsResults.size(); i++) {
                String nextmovementstep = dsResults.getValue(i, "u_nextmovementstep", "");
                String los = dsResults.getValue(i, "u_los", "");
                String sc_methodology = dsResults.getValue(i, "u_methodology", "");
                String t_methodology = dsResults.getValue(i, "t_methodology", "");
                String sampleid = dsResults.getValue(i, "s_sampleid", "");
                String movementstep = dsResults.getValue(i, "u_movementstep", "");

                // FILTERED SAMPLE FROM u_movementstep
                for (int j = 0; j < dsMoveFinal.size(); j++) {
                    if (sampleid.equalsIgnoreCase(dsMoveFinal.getValue(j, "sampleid", ""))) {
                        if ((!Util.isNull(nextmovementstep) && !Util.isNull(sc_methodology))
                                && t_methodology.equalsIgnoreCase(sc_methodology)) {
                            dsMoveFinal.setValue(j, "newmovement", nextmovementstep);
                        } else {
                            dsMoveFinal.setValue(j, "newmovement", movementstep);
                        }
                    }
                }
            }
        }
        // CHECK TEST CODE ASSOCIATE WITH SAMPLE OR NOT
        String sampleWOTocdes = "";
        sql = "select s.s_sampleid,ac.u_accessionid from s_sample s, u_accession ac where"
                + " s.u_accessionid = ac.u_accessionid and" + " s.u_accessionid='" + accessionid
                + "' and s.u_accessioningcomplete='N'";
        DataSet dsAllSamplesByAccession = getQueryProcessor().getSqlDataSet(sql);
        sql = "select distinct stm.methodology t_methodology,s.s_sampleid,s.sampletypeid,t.containertypeid,s.u_performingsite,sc.u_movementstep,stm.methodology,stm.los,sc.u_nextmovementstep"
                + " from s_sample s,trackitem t,s_sampletypecontainertype sc,u_accession ac, u_sampletestcodemap stm"
                + " where s.u_accessionid=ac.u_accessionid and" + " s.s_sampleid=t.linkkeyid1"
                + " and s.u_accessionid in('" + accessionid + "')" + " and sc.s_sampletypeid=s.sampletypeid"
                + " and stm.s_sampleid=s.s_sampleid"
                + " and sc.containertypeid=t.containertypeid and s.u_accessioningcomplete='N'";
        DataSet dsTestCodeMap = getQueryProcessor().getSqlDataSet(sql);
        for (int i = 0; i < dsAllSamplesByAccession.size(); i++) {
            String sampleidWOTcode = dsAllSamplesByAccession.getValue(i, "s_sampleid", "");
            // CHECK REST SAMPLES WHICH HAVE NO TESTCODE(S) ASSOCIATE
            hm.clear();
            hm.put("s_sampleid", sampleidWOTcode);
            DataSet dsFilterRest = dsTestCodeMap.getFilteredDataSet(hm);
            if (dsFilterRest.size() == 0) {
                sampleWOTocdes += ";" + dsAllSamplesByAccession.getValue(i, "s_sampleid", "");
            }
        }

        /***** Set first step for Consult ****/
        hm.clear();
        hm.put("methodology", "IHC");
        hm.put("los", "Consult");
        /* Change By Subhendu for Performing Site in Sample 4th Mar 2017 + */
        hm.put("u_performingsite", null);
        /* Change By Subhendu for Performing Site in Sample 4th Mar 2017 - */
        DataSet dsFilterConsult = dsTestCodeMap.getFilteredDataSet(hm);
        if (dsFilterConsult != null && dsFilterConsult.size() > 0) {
            String allConsultSampleToProcess = Util.getUniqueList(dsFilterConsult.getColumnValues("s_sampleid", ";"),
                    ";", true);
            // String allConsultSampleArray[]
            // =StringUtil.split(allConsultSample,";");
            for (int h = 0; h < dsMoveFinal.getRowCount(); h++) {
                if (allConsultSampleToProcess.contains(dsMoveFinal.getValue(h, "sampleid", ""))) {
                    dsMoveFinal.setValue(h, "newmovement", "PathSupport");
                }
            }
        }

        if (!Util.isNull(sampleWOTocdes)) {
            sampleWOTocdes = sampleWOTocdes.substring(1);
            message += "\nBelow sample(s) have no testcode(s): " + StringUtil.replaceAll(sampleWOTocdes, ";", ",");

        }
        properties.setProperty("msg", message);
        /************************************************************************************************************/

        if (dsMoveFinal == null) {
            throw new SapphireException("DataSet containing Sample information is null");
        }
        if (dsMoveFinal.size() == 0) {
            throw new SapphireException("Sample movement step is not defined in master data");
        }
        //CHECK TRANSFER TO DATE VALIDATION FOR EMBEDDING BLOCK//TODO WILL OPEN WHEN TRANSFER TO DATE VALIDATION WILL GO TO RELEASE
        hm.clear();
        hm.put("newmovement", "Embedding");
        DataSet dsEmbeddingFilter = dsMoveFinal.getFilteredDataSet(hm);
        if (dsEmbeddingFilter.size() > 0) {
            DataSet dsError = new DataSet();
            dsError.addColumn("sampleid", DataSet.STRING);
            dsError.addColumn("transfertodt", DataSet.STRING);
            sql = Util.parseMessage(ApSql.GET_TRANSFER_TO_DATE_BY_SAMPLEID,
                    StringUtil.replaceAll(dsEmbeddingFilter.getColumnValues("sampleid", ";"), ";", "','"));
            DataSet dsTransferToDt = getQueryProcessor().getSqlDataSet(sql);
            for (int i = 0; i < dsEmbeddingFilter.size(); i++) {
                String sampleid = dsEmbeddingFilter.getValue(i, "sampleid", "");
                hm.clear();
                hm.put("s_sampleid", sampleid);
                DataSet dsFilterTransferTodt = dsTransferToDt.getFilteredDataSet(hm);
                String transfertodt = dsFilterTransferTodt.getValue(0, "u_transfertodate", "");
                if (Util.isNull(transfertodt)) {
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "sampleid", sampleid);
                    dsError.setValue(rowID, "transfertodt", transfertodt);
                }
            }
            if (dsError != null && dsError.size() > 0) {
                String error = "Please provide <b>Transfer To</b> date for below Specimen(s):";
                DataSet dsDisplayMsg = new DataSet();
                dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
                dsDisplayMsg.addColumn("transfer_to_date", DataSet.STRING);
                for (int i = 0; i < dsError.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsError.getValue(i, "sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "transfer_to_date", dsError.getValue(i, "transfertodt", "N/A"));
                }
                String errCodes = Util.getDisplayMessage(dsDisplayMsg);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error + errCodes);
            }
        }
        // Changed By Subhendu  - 8th Jan 2017 Email checkin for Accession Complete +
        sql = Util.parseMessage(CommonSql.GET_SAMPLE_BY_ACCESION_COMPLETE, accessionid);
        DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);
        // Changed By Subhendu  - 8th Jan 2017 Email checkin for Accession Complete -

        HashMap<String, String> hmap = new HashMap<String, String>();
        hmap.clear();
        hmap.put("normalroute", "Y");
        DataSet dsMoveFinalNormalRoute = dsMoveFinal.getFilteredDataSet(hmap);
        PropertyList prop = new PropertyList();
        if (dsMoveFinalNormalRoute != null && dsMoveFinalNormalRoute.size() > 0) {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsMoveFinalNormalRoute.getColumnValues("sampleid", ";"));
            prop.setProperty("u_currentmovementstep", dsMoveFinalNormalRoute.getColumnValues("newmovement", ";"));
            prop.setProperty("u_accessioningcomplete", "Y");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            DataSet dsCurrntMove = getCurrentMovementStep(dsMoveFinalNormalRoute);
            updateTrackItem(dsCurrntMove);
        }
        hmap.clear();
        hmap.clear();
        hmap.put("normalroute", "N");
        DataSet dsInternalDeptRoute = dsMoveFinal.getFilteredDataSet(hmap);
        if (dsInternalDeptRoute != null && dsInternalDeptRoute.size() > 0) {
            prop.clear();
            prop.setProperty(MannualSampleRouting.PROPERTY_SAMPLEID, dsInternalDeptRoute.getColumnValues("sampleid", ";"));
            prop.setProperty(MannualSampleRouting.PROPERTY_DEPARTMENTID, dsInternalDeptRoute.getColumnValues("performingsite", ";"));
            prop.setProperty(MannualSampleRouting.PROPERTY_SAMPLE_COL_TO_BE_MODIFIED, "u_accessioningcomplete");
            prop.setProperty("u_accessioningcomplete", StringUtil.repeat("Y", dsInternalDeptRoute.size(), ";"));
            getActionProcessor().processAction("MannualSampleRouting", "1", prop);
        }
        try {
            //TODO WILL OPEN TO ROUTE EMBEDDED BLOCK TO SETUP
            updateMovementForEmbeddedBlock(dsMoveFinal);
            // createSampleMovementSteps(dsMoveFinal);
            sampleForLabel = dsMoveFinal.getColumnValues("sampleid", ";");
            // printNGLabel(sampleForLabel); //ToDO List for Generate Print
            // Label
            // labelPrint(sampleForLabel);//TODO LABEL WILL PRINT MANUALLY

            // Changed By Subhendu  - 8th Jan 2017 Email checkin for Accession Complete +
            if (tempDS != null && tempDS.size() == 0)
                sendEmailNotificationForBioPharma(dsMoveFinal.getColumnValues("sampleid", ";"));
            // Changed By Subhendu  - 8th Jan 2017 Email checkin for Accession Complete -

            /**
             * POPULATE SLIDE SECTIONED DATE FOR SPECIAL TESTCODE(S) ON SLIDE(S)
             */
            //DataSet dsTestCodePolicy = getTestCodePolicy();
            DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
            if (dsTestCodePolicy.size() > 0) {
                enterDataForAmgen(accessionid, dsTestCodePolicy);
            }
            /**
             * POPULATE SINITIAL OR REPEAT FOR SPECIAL TESTCODE(S) ON SLIDE(S)
             */
            autoMarkInitialRepeat(accessionid);
            //throw new SapphireException("Test");
        } catch (SapphireException ex) {
            throw ex;
        }

        

    }

    private void autoMarkInitialRepeat(String accessionid) throws SapphireException {

        DataSet dsSpecialTestCodes = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "Initial or Repeat");
        if (dsSpecialTestCodes.size() > 0) {
            String specialtestcodes = dsSpecialTestCodes.getColumnValues("testcode", ";");
            String sql = Util.parseMessage(ApSql.GET_TESTCODES_BYACCESSIONID, accessionid);
            DataSet dsAllSamplesInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsAllSamplesInfo != null && dsAllSamplesInfo.size() > 0) {
                String sampleid = dsAllSamplesInfo.getColumnValues("s_sampleid", ";");
                sql = Util.parseMessage(ApSql.GET_SPECIMENS_BY_SPECIMEN_TESTCODE,
                        StringUtil.replaceAll(sampleid, ";", "','"),
                        StringUtil.replaceAll(specialtestcodes, ";", "','"));
                DataSet dsSpecialTCInfo = getQueryProcessor().getSqlDataSet(sql);

                DataSet dsInitialRepeat = new DataSet();
                dsInitialRepeat.addColumn("s_sampleid", DataSet.STRING);
                dsInitialRepeat.addColumn("testname", DataSet.STRING);
                dsInitialRepeat.addColumn("markername", DataSet.STRING);
                for (int i = 0; i < dsAllSamplesInfo.size(); i++) {
                    HashMap hm = new HashMap();
                    hm.clear();
                    hm.put("s_sampleid", dsAllSamplesInfo.getValue(i, "s_sampleid"));
                    hm.put("lvtestcodeid", dsAllSamplesInfo.getValue(i, "lvtestcodeid"));
                    DataSet dsSpecialTcFilter = dsSpecialTCInfo.getFilteredDataSet(hm);
                    if (dsSpecialTcFilter != null && dsSpecialTcFilter.size() > 0) {
                        int rowId = dsInitialRepeat.addRow();
                        dsInitialRepeat.setValue(rowId, "s_sampleid", dsAllSamplesInfo.getValue(i, "s_sampleid"));
                        dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                        dsInitialRepeat.setValue(rowId, "markername", "Initial");
                    }

                }
                if (dsInitialRepeat != null && dsInitialRepeat.size() > 0) {
                    String inirepeatsample = Util.getUniqueList(dsInitialRepeat.getColumnValues("s_sampleid", ";"), ";", true);
                    inirepeatsample = StringUtil.replaceAll(inirepeatsample, ";", "','");
                    String inirepeatparamlistid = Util.getUniqueList(dsInitialRepeat.getColumnValues("testname", ";"), ";", true);
                    inirepeatparamlistid = StringUtil.replaceAll(inirepeatparamlistid, ";", "','");
                    String sqlenterdata = Util.parseMessage(ApSql.GET_ANALYTE_BY_SAMPLE_PARAM, inirepeatsample, inirepeatparamlistid);
                    DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
                    if (dsSqlEnterData.size() > 0) {
                        for (int i = 0; i < dsSqlEnterData.size(); i++) {
                            String entsampleid = dsSqlEnterData.getValue(i, "childsampleid", "");
                            String entparamid = dsSqlEnterData.getValue(i, "paramlistid", "");
                            HashMap hm = new HashMap();
                            hm.clear();
                            hm.put("s_sampleid", entsampleid);
                            hm.put("testname", entparamid);
                            DataSet dsSpecialTcFilter = dsInitialRepeat.getFilteredDataSet(hm);
                            if (dsSpecialTcFilter != null && dsSpecialTcFilter.size() > 0) {
                                dsSqlEnterData.setValue(i, "enteredtext", dsSpecialTcFilter.getValue(0, "markername"));
                                dsSqlEnterData.setValue(i, "displayvalue", dsSpecialTcFilter.getValue(0, "markername"));
                            }
                        }

                        PropertyList props = new PropertyList();
                        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                        props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                        props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("enteredtext", ";"));
                        props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("displayvalue", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                        try {
                            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                        } catch (SapphireException e) {
                            throw new SapphireException("Initial or Repeat rule not performed." + e.getMessage());
                        }
                    }
                }
            }
        }
    }

    /**
     * Description: Update SLide sectioning date for slide(s) based on TestCode(s) rule from the system.
     *
     * @param accessionid
     * @param dsTestCodePolicy
     * @throws SapphireException
     */
    private void enterDataForAmgen(String accessionid, DataSet dsTestCodePolicy) throws SapphireException {
        String testcodePolicy = dsTestCodePolicy.getColumnValues("testcode", "','");
        String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES, accessionid, testcodePolicy);
        DataSet dsTestAmgen = getQueryProcessor().getSqlDataSet(sampleTestAmgen);
        if (dsTestAmgen != null && dsTestAmgen.size() > 0) {
            String testname = StringUtil.replaceAll(dsTestAmgen.getColumnValues("testname", ";"), ";", "','");
            String slides = StringUtil.replaceAll(dsTestAmgen.getColumnValues("s_sampleid", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_PARAMIDS, slides, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                for (int i = 0; i < dsSqlEnterData.size(); i++) {
                    String slidesectiondt = dsSqlEnterData.getValue(i, "u_slidesectiondate", "");
                    if (!Util.isNull(slidesectiondt)) {
                        try {
                            //input date format
                            SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyyy");
                            //output date format
                            SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd-MMM-yyyy");
                            Date date = dFormat.parse(slidesectiondt);
                            String formtSlideSectndt = dFormatFinal.format(date);
                            dsSqlEnterData.setValue(i, "u_slidesectiondate", formtSlideSectndt.toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }

    private void sendEmailNotificationForBioPharma(String sampleid) throws SapphireException {
        // method for email notification whenever user generating the accession  for bio pharma.
        if (!Util.isNull(sampleid)) {
            
        	/* Code Block for Project having email at project level site  ++*/
            String sql = Util.parseMessage(CommonSql.PROJECT_EMAIL, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            PropertyList prop = new PropertyList();
            String toList = "";
            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Accession Notification");
                            DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            toList = tempDsFiltr.getColumnValues("emailorsftp", ";");
                            if (!Util.isNull(toList)) {
                                toList = Util.getUniqueList(toList, ";", true);
                                String sponcerName = tempDsFiltr.getColumnValues("sponcername", ";");
                                if (!Util.isNull(sponcerName))
                                    sponcerName = Util.getUniqueList(sponcerName, ";", true);

                                if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Non-Clinical"))
                                    prop.setProperty(NGSendMail.NODE_ID, "ProjectAccessionMail");
                                else if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Clinical")) {
                                    prop.setProperty(NGSendMail.NODE_ID, "ClinicalAccession");
                                    prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                                    prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                                }

                                prop.setProperty(NGSendMail.MODE, "SendMail");
                                prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
                                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                                prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("investigatorsiteid", ";"), ";", true));
                                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                            }
                        }
                    }
                }
            } 
            /* Code Block for Project having email at project level   --*/
            /* Code Block for Project having email at Investigator level  ++*/
            sql = Util.parseMessage(CommonSql.INVESTIGATOR_LEVEL_EMAIL, StringUtil.replaceAll(sampleid, ";", "','"));
            ds = getQueryProcessor().getSqlDataSet(sql);

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("type", "Email");
                            hmap.put("event", "Accession Notification");
                            DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                toList = tempDsFiltr.getColumnValues("email", ";") + ";" + toList;
                                if (!Util.isNull(toList)) {
                                    toList = Util.getUniqueList(toList, ";", true);
                                    String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                                    if (!Util.isNull(invistigatoName))
                                        invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                                    String sponcerName = tempDsFiltr.getColumnValues("sponcername", ";");
                                    if (!Util.isNull(sponcerName))
                                        sponcerName = Util.getUniqueList(sponcerName, ";", true);

//                                    PropertyList prop = new PropertyList();
                                    if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Non-Clinical")) {
                                        prop.setProperty(NGSendMail.NODE_ID, "ProjectAccessionMail");
                                        prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
                                    } else if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Clinical"))
                                        prop.setProperty(NGSendMail.NODE_ID, "Accession");

                                    prop.setProperty(NGSendMail.MODE, "SendMail");
                                    prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(tempDsFiltr.getColumnValues("s_sampleid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                                    prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                                    prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                                    prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());

                                }
                            }
                        }
                    }
                }
            }
            if (toList != null && !"".equals(toList)) {
                prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
                prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
                prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
                prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
                getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
            }
            /* Code Block for Project having email at Investigator level  --*/
        }
    }

    /**
     * Not Required. As per current requirement direct insert not necessary on
     * SampleMovementSteps
     *
     * @param dsMoveFinal :Contains Samples ,currentmovementstep and new movementstep
     * @throws SapphireException
     * @desc: This method sets the completedstep as 'AccessioningCompleted' and
     * also sets completedby and completed date after Generate Accession
     * is completed
     */
    private void createSampleMovementSteps(DataSet dsMoveFinal) throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String sample = dsMoveFinal.getColumnValues("sampleid", ";");
        String sampleid[] = StringUtil.split(sample, ";");
        int copies = sampleid.length;
        PropertyList prop1 = new PropertyList();
        prop1.setProperty(AddSDI.PROPERTY_SDCID, "SampleMovementSteps");
        prop1.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copies));
        prop1.setProperty("sampleid", sample);
        prop1.setProperty("completedstep", "AccessioningCompleted");
        prop1.setProperty("completedby", currentuser);
        prop1.setProperty("completeddt", "n");

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop1);
    }

    private DataSet getCurrentMovementStep(DataSet dsMoveFinal) throws SapphireException {
        /*
         * String sql =
		 * "select u_type,s_sampleid,u_currentmovementstep,u_performingsite from s_sample where s_sampleid in('"
		 * + StringUtil.replaceAll(dsMoveFinal.getColumnValues("sampleid", ";"),
		 * ";", "','") + "')";
		 */

        String sqlArg = StringUtil.replaceAll(dsMoveFinal.getColumnValues("sampleid", ";"), ";", "','");
        String sql = Util.parseMessage(ApSql.GET_SAMPLE_INFO_BY_SAMPLEID, sqlArg);

        DataSet dsCurrentMovement = getQueryProcessor().getSqlDataSet(sql);
        if (dsCurrentMovement == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsCurrentMovement.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample id not found");
            errMsg += "\nQuery retuns no rows:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsMoveFinal.size(); i++) {
            String sample = dsMoveFinal.getValue(i, "sampleid", "");
            hm.clear();
            hm.put("s_sampleid", sample);
            /*
             * Change By Subhendu for Performing Site in Sample 4th Mar 2017 +
			 */
            hm.put("u_performingsite", null);
            /*
             * Change By Subhendu for Performing Site in Sample 4th Mar 2017 -
			 */
            DataSet dsFilter = dsCurrentMovement.getFilteredDataSet(hm);
            String currentmovementstep = dsFilter.getValue(0, "u_currentmovementstep");
            /*
             * if (Util.isNull(currentmovementstep)) { String errMsg =
			 * getTranslationProcessor().
			 * translate("Currentmovementstep not found in for sample id:" +
			 * sample); throw new SapphireException(ErrorDetail.TYPE_FAILURE,
			 * errMsg); }
			 */
            dsMoveFinal.setValue(i, "currentmovementstep", currentmovementstep);
        }
        return dsMoveFinal;
    }

    private void updateTrackItem(DataSet dsMoveFinal) throws SapphireException {
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String site = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));
        dsMoveFinal.addColumn("custodialdepartmentid", DataSet.STRING);
        for (int i = 0; i < dsMoveFinal.size(); i++) {
            String currentmovementstep = dsMoveFinal.getValue(i, "currentmovementstep");
            String u_type = dsMoveFinal.getValue(i, "u_type");// TODO BACKUP
            // WILL GO
            // DIRECTLY
            // HIRTOLOGY
            // ARCHIVE(SURAJIT
            // 08/19/2017)
            /*
             * Change By Subhendu for Performing Site in Sample 4th Mar 2017 +
			 */
            if (!Util.isNull(dsMoveFinal.getValue(i, "performingsite", ""))) {
                String destDeptCheck = site + "-Accessioning";//"-Logistic";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            }
            /*
             * Change By Subhendu for Performing Site in Sample 4th Mar 2017 -
			 */
            else if ("fresh prep".equalsIgnoreCase(currentmovementstep)
                    || "freshprep".equalsIgnoreCase(currentmovementstep)) {
                String destDeptCheck = site + "-Fresh Prep";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            } else if ("B".equalsIgnoreCase(u_type)) {
                // String destDeptCheck = site + "-AP";//TODO CHANGED FOR 1.2.2
                // Release As HistologyArchieve is only accessable by
                // PathSupport user.
//				String destDeptCheck = site + "-PathSupport";
                String destDeptCheck = site + "-Accessioning";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            } else if ("EU".equalsIgnoreCase(u_type) || "Quantification".equalsIgnoreCase(currentmovementstep)) {
                // String destDeptCheck = site + "-AP";//TODO CHANGED FOR 1.3.1
                // Release As Elusion Tube will go to molecular.
                String destDeptCheck = site + "-Molecular";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            }
            else if ("Pathsupport".equalsIgnoreCase(currentmovementstep)){
                String destDeptCheck = site + "-Accessioning";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            }
            else {
                String destDeptCheck = site + "-AP";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            }
        }
        PropertyList editTIProps = new PropertyList();
        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsMoveFinal.getColumnValues("sampleid", ";"));
        editTIProps.setProperty("u_currenttramstop", dsMoveFinal.getColumnValues("currentmovementstep", ";"));
        editTIProps.setProperty("custodialuserid", StringUtil.repeat("(null)", dsMoveFinal.size(), ";"));
        editTIProps.setProperty("custodialdepartmentid", dsMoveFinal.getColumnValues("custodialdepartmentid", ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

    }

    /**
     * Description: This method is used for generating print label of the
     * samples during 'Generate Accession'. It will take all the samples as an
     * input and call PrintLabel action to print the label of the input samples.
     *
     * @param sampleForLabel
     * @throws SapphireException
     */
    private void labelPrint(String sampleForLabel) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, sampleForLabel);
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Accession");
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    /**
     * Description : This method will check department is valid or not.
     *
     * @param destinationDepartment
     * @return
     * @throws SapphireException
     */
    private void deptValidate(String destinationDepartment) throws SapphireException {
        // destinationDepartment = destinationDepartment.substring(0,
        // destinationDepartment.length() - 1);
        String department = "";
        String dept = "select departmentid from department where departmentid='" + destinationDepartment + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor()
                    .translate(destinationDepartment + " is not valid destination Department.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
            if (Util.isNull(department)) {
                String errStr = getTranslationProcessor()
                        .translate("Destination Department can't be null.Please contact your Administrator. ");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }

    }

    private void validateAccessionGenerate(String accessionid) throws SapphireException {
        String sql = "select s_sampleid from labvantage.s_sample where u_accessionid='" + accessionid
                + "' and u_accessioningcomplete='N'";
    }

    private void updateMovementForEmbeddedBlock(DataSet dsMoveFinal) throws SapphireException {
        DataSet dsEB = new DataSet();
        dsEB.addColumn("sampleid", DataSet.STRING);
        dsEB.addColumn("movementstep", DataSet.STRING);
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("u_type", "EB");
        DataSet dsEBFilter = dsMoveFinal.getFilteredDataSet(hm);
        if (dsEBFilter != null && dsEBFilter.size() > 0) {
            //dsEB.addColumnValues("sampleid", DataSet.STRING, dsEBFilter.getColumnValues("sampleid", ";"), ";");
            for (int i = 0; i < dsEBFilter.size(); i++) {
                int rowID = dsEB.addRow();
                dsEB.setValue(rowID, "sampleid", dsEBFilter.getValue(i, "sampleid", ""));
                dsEB.setValue(rowID, "movementstep", "Setup");
            }
            String sampleid = StringUtil.replaceAll(Util.getUniqueList(dsEBFilter.getColumnValues("sampleid", ";"), ";", true),
                    ";", "','");
            String sql = "select s_sampleid,u_type,u_currentmovementstep,u_rootsample from s_sample where u_rootsample in('" + sampleid + "') and u_type='H' and u_isbesthne='Y'";
            DataSet dsSamples = getQueryProcessor().getSqlDataSet(sql);
            if (dsSamples != null && dsSamples.size() > 0) {
                for (int i = 0; i < dsSamples.size(); i++) {
                    int rowID = dsEB.addRow();
                    dsEB.setValue(rowID, "sampleid", dsSamples.getValue(i, "s_sampleid", ""));
                    dsEB.setValue(rowID, "movementstep", "Setup");
                }
            }
            if (dsEB != null && dsEB.size() > 0) {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsEB.getColumnValues("sampleid", ";"));
                prop.setProperty("u_currentmovementstep", dsEB.getColumnValues("movementstep", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            }
        }
    }
}
