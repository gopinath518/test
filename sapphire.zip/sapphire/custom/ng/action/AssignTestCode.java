package sapphire.custom.ng.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.action.accession.MolAutoCreateBatchSample;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.cyto.CytoSqls;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

/**
 * Created by Mayank Pandey on 3/23/2016. This Action is adding multiple test
 * Modified by surajit.baitalik
 * and testpanel to multiple samples simultaneously . Updated tables are
 * u_sample_testcode_map and u_sample_testcode_steps_map modified by SBaitalik,Soumen Mitra
 * <p>
 * Examples 1: Add one test t1 to the sample s1 and s2
 * Properties: s_sampleid: s1;s2
 * ispanel: N;N
 * lvtestcode: t1;t1
 * <p>
 * Examples 2: Add one panel P1 to the sample s1 and s2( expectation: all the testcode would be associated to s1 and s2
 * Properties: s_sampleid: s1;s2
 * ispanel: Y;Y
 * lvtestcode: P1;P1
 * <p>
 * Examples 3: Add some tests from a panel P1 to the sample s1 and s2( assume: Panel P1 have two tests t1,t2)
 * Properties: s_sampleid: s1;s2
 * ispanel: N;N
 * lvtestcode: t1;t2
 * panelassociatedwithtestcode: P1;P1
 */
public class AssignTestCode extends BaseAction {

    public static final String ID = "AssignTestCode";
    public static final String VERSION_ID = "1";
    public static String message = "";

    /**********************************************************
     * ADDED POLICY FOR APSlideType (07-05-2017 SURAJIT) STARTS
     *********************************************************/
    private final String POLICY_NAME = "ChangeSlideTypePolicy";
    private final String POLICY_NODE = "APSlideType";

    /*********************************************************
     * ADDED POLICY FOR APSlideType (07-05-2017 SURAJIT) ENDS
     ********************************************************/

    public void processAction(PropertyList properties) throws SapphireException {

        String isInitialRepeatBypas = properties.getProperty(INPUT_PROPERTY_BYPASS_INITIAL_REPEAT, "N");
        String isMolRepeatFlag = properties.getProperty("ismolrepeatflag", "N");
        String isapplyinitialrep = properties.getProperty("isapplyinitialrep", "Y");
        String isBypas = properties.getProperty(INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "N");
        String changeBackupToUSS = Util.getUniqueList(properties.getProperty(INPUT_PROPERTY_CHANGE_BACKUP_TO_USS, "Y"),
                ";", true);

        DataSet dsInput = validateInputs(properties);
        initializeDataSet(dsInput);
        replaceTestFromSlide();
        // nyClientValidation();//TODO IN BIO-Pharma, we don't have NY flag
        // validation
        if (!"Y".equalsIgnoreCase(isBypas)) {
            validateSampleTypeTransportType();
        }

        // Make backup slide to USS when testcode added to backup slides.
        DataSet dsIHCBackupSlide = new DataSet();
        if ("Y".equalsIgnoreCase(changeBackupToUSS)) {
            dsIHCBackupSlide = markRepeatForIHCBackup();
            updateSampleSlideType();
        }
        updateUSSToBackup();
        DataSet dsInstr = validateInstrument();
        updateSlideType();
        String sampletestcodemapid = addTestCodes();
        if (dsInstr != null && dsInstr.size() > 0) {
            setInstrument(dsInstr);
        }
        applyWorkItem();
        addIHCSteps();
        checkSampleTypeContainerType(properties);
        autoBatchCreation();
        /*------------ Added by Subhendu - 23/01/2018 + ------------*/
        String flowTubeSample = properties.getProperty("flowtubesample", "");
        if (!"Y".equals(flowTubeSample))
            generateInternalIdForFlow();
        /*------------ Added by Subhendu - 23/01/2018 - ------------*/
        copyMoProperty(properties, sampletestcodemapid);
        updateExtractionTypeForExtractedMetirial(properties.getProperty(INPUT_PROPERTY_SAMPLE_ID));
        validateCytoProperty(properties);
        populateAndModifyCytoData(properties);
        applyPanelWorkItemSolid();
        applyPanelWithSlide();//TODO APPLY PANEL WITH SLIDE(S) FOR IHC REEQ.
        validateTestcodeOnSlide();//TODO VALIDATE MORE THAN ONE TEST(S) INTO THE SLIDE[IHC]
        //TODO AUTOMATED REPEAT OR INITAILS RULE APPLYED
        if (!"Y".equalsIgnoreCase(isInitialRepeatBypas))
            autoMarkInitialRepeat();
        /***************************TODO RELEASE 1.6.1 COBAS REPEAT ANALYTE**********************/
        if (!"Y".equalsIgnoreCase(isapplyinitialrep)) {
            markedInitialOrRepeatMolecular(isMolRepeatFlag);
        }

        sharedHnE();
        if ("Y".equalsIgnoreCase(changeBackupToUSS)) {
            updateSlideSectionDate();
        }

        if (dsIHCBackupSlide.size() > 0) {
            applyRepeatForIHCBackup(dsIHCBackupSlide);
        }
        properties.setProperty("msg", message);
        properties.setProperty("sampletestcodemapid", sampletestcodemapid);
        //throw new SapphireException("test");
    }

    /**
     * If accession is generated initially, back up slide is marked as �Initial�
     * If the  IHC test code is repeated on this this back up, then its slide status should be changed from �Initial� to �Repeat.�
     * author debasis.mondal
     * tfs id    5504 1.7.1 release
     *
     * @throws SapphireException
     */
    private DataSet markRepeatForIHCBackup() throws SapphireException {
        String sampleids = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        sampleids = StringUtil.replaceAll(sampleids, ";", "','");
        String sqlBackup = Util.parseMessage(CommonSql.GET_BACKUP_DETAILS, sampleids);
        DataSet dsIHCBackup = getQueryProcessor().getSqlDataSet(sqlBackup);
        if (dsIHCBackup == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sqlBackup;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        return dsIHCBackup;
    }

    private void applyRepeatForIHCBackup(DataSet dsIHCBackupSlide) throws SapphireException {
        String sqlenterdata = Util.parseMessage(ApSql.GET_ANALYTE_BY_SAMPLE, StringUtil.replaceAll(dsIHCBackupSlide.getColumnValues("s_sampleid", ";"), ";", "','"));
        DataSet dsIHCRepeatEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
        if (dsIHCRepeatEnterData.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsIHCRepeatEnterData.getColumnValues("s_sampleid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsIHCRepeatEnterData.getColumnValues("paramlistid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsIHCRepeatEnterData.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsIHCRepeatEnterData.getColumnValues("paramid", ";"));
            props.setProperty("enteredtext", StringUtil.repeat("Repeat", dsIHCRepeatEnterData.size(), ";"));
            props.setProperty("displayvalue", StringUtil.repeat("Repeat", dsIHCRepeatEnterData.size(), ";"));
            props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsIHCRepeatEnterData.getColumnValues("variantid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsIHCRepeatEnterData.getColumnValues("paramtype", ";"));
            props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsIHCRepeatEnterData.getColumnValues("replicateid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_DATASET, dsIHCRepeatEnterData.getColumnValues("dataset", ";"));
            try {
                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException("EnterDataItem not performed." + e.getMessage());
            }
        }
    }

    /**
     * This is used for replace old test code/panel by new assign test code for IHC and MO
     * author debasis.mondal
     * tfs id    5461 1.7.1 release
     *
     * @throws SapphireException
     */
    private void replaceTestFromSlide() throws SapphireException {
        String sampleids = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        sampleids = StringUtil.replaceAll(sampleids, ";", "','");
        String sqlSlide = Util.parseMessage(CommonSql.GET_SLIDE_TO_REPLACE_TEST, sampleids);
        DataSet dsSlide = getQueryProcessor().getSqlDataSet(sqlSlide);
        if (dsSlide.size() > 0) {
            dsSlide.sort("methodology");
            ArrayList<DataSet> dsBasedOnMethodologyArr = dsSlide.getGroupedDataSets("methodology");
            PropertyList props = new PropertyList();
            for (int i = 0; i < dsBasedOnMethodologyArr.size(); i++) {
                DataSet dsBasedOnMethodology = (DataSet) dsBasedOnMethodologyArr.get(i);
                if (dsBasedOnMethodology.size() > 0) {
                    props.clear();
                    if ("Multiomyx".equalsIgnoreCase(dsBasedOnMethodology.getValue(0, "methodology"))) {
                        multiomyxValidation(dsBasedOnMethodology);
                        props.setProperty("sampleid", dsBasedOnMethodology.getColumnValues("s_sampleid", ";"));
                        props.setProperty("panelid", dsBasedOnMethodology.getColumnValues("lvtestpanelid", ";"));
                        try {
                            getActionProcessor().processAction("MOPanelDeletion", "1", props);
                        } catch (SapphireException e) {
                            throw new SapphireException("Error in MOPanelDeletion Action:" + e.getMessage());
                        }
                    } else if ("IHC".equalsIgnoreCase(dsBasedOnMethodology.getValue(0, "methodology"))) {
                        ihcValidation(dsBasedOnMethodology);
                        props.setProperty("keyid1", dsBasedOnMethodology.getColumnValues("u_sampletestcodemapid", ";"));
                        props.setProperty("eventtype", "delete");
                        props.setProperty("evntreason", "Replace current assign test(Single or multiple) by new assign test");
                        try {
                            getActionProcessor().processAction("PerformTestcodeDel", "1", props);
                        } catch (SapphireException e) {
                            throw new SapphireException("Error in PerformTestcodeDel Action:" + e.getMessage());
                        }
                    }
                }
            }
        }
    }

    /*
     * MO test replace validation
     */
    private void multiomyxValidation(DataSet dsBasedOnMethodology) throws SapphireException {
        if (dsBasedOnMethodology.size() > 0) {
            String noDeleteSpecimen = "";
            for (int i = 0; i < dsBasedOnMethodology.size(); i++) {
                String sampleid = dsBasedOnMethodology.getValue(i, "s_sampleid", "");
                String moprotocolid = dsBasedOnMethodology.getValue(i, "u_moprotocolid", "");
                if (!"".equalsIgnoreCase(moprotocolid)) {
                    noDeleteSpecimen = noDeleteSpecimen + ";" + sampleid;
                }
            }
            if (noDeleteSpecimen.length() > 1) {
                if (noDeleteSpecimen.startsWith(";")) {
                    noDeleteSpecimen = noDeleteSpecimen.substring(1);
                }
                String errStr = getTranslationProcessor().translate("MO protocol already generated,You can't replace test for the specimen:" + noDeleteSpecimen);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
    }

    /*
     * IHC test replace validation
     */
    private void ihcValidation(DataSet dsBasedOnMethodology) throws SapphireException {
        if (dsBasedOnMethodology.size() > 0) {
            String noDeleteSpecimen = "";
            for (int i = 0; i < dsBasedOnMethodology.size(); i++) {
                String sampleid = dsBasedOnMethodology.getValue(i, "s_sampleid", "");
                String staincompletedt = dsBasedOnMethodology.getValue(i, "u_staincompletedt", "");
                if (!"".equalsIgnoreCase(staincompletedt)) {
                    noDeleteSpecimen = noDeleteSpecimen + ";" + sampleid;
                }
            }
            if (noDeleteSpecimen.length() > 1) {
                if (noDeleteSpecimen.startsWith(";")) {
                    noDeleteSpecimen = noDeleteSpecimen.substring(1);
                }
                String errStr = getTranslationProcessor().translate("Stain already completed,You can't replace test for the specimen:" + noDeleteSpecimen);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
    }

    /**
     * This is used for opening portal of B to U type specimen
     *
     * @throws SapphireException
     */
    private void updateSlideSectionDate() throws SapphireException {
        try {
            // String accessionid = properties.getProperty("accessionid");
            String sampleids = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
            String sqlAccession = Util.parseMessage(ApSql.GET_ACCESSIONID_BY_SAMPLEID, sampleids);
            DataSet dsAccession = getQueryProcessor().getSqlDataSet(sqlAccession);
            String accessionid = StringUtil.replaceAll(dsAccession.getColumnValues("u_accessionid", ";"), ";", "','");
            //DataSet dsTestCodePolicy = getTestCodePolicy();
            DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
            if (dsTestCodePolicy.size() > 0) {
                enterDataForAmgen(accessionid, dsTestCodePolicy);
            }
            // getResponse(ajaxResponse, "Success", tabletype, accessionid);
        } catch (Exception ex) {
            throw new SapphireException("Error in updateSlideSectionDate method.\n" + ex.getMessage());
            //getResponse(ajaxResponse, "Failed", tabletype, accessionid);
        }
    }

    private void enterDataForAmgen(String accessionid, DataSet dsTestCodePolicy) throws SapphireException {
        String testcodePolicy = dsTestCodePolicy.getColumnValues("testcode", "','");
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES, accessionid, testcodePolicy);
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES, accessionid, testcodePolicy);
        String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES_PORTAL, accessionid, testcodePolicy);
        DataSet dsTestAmgen = getQueryProcessor().getSqlDataSet(sampleTestAmgen);
        if (dsTestAmgen != null && dsTestAmgen.size() > 0) {
            String testname = StringUtil.replaceAll(dsTestAmgen.getColumnValues("testname", ";"), ";", "','");
            String slides = StringUtil.replaceAll(dsTestAmgen.getColumnValues("s_sampleid", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_PARAMIDS, slides, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                for (int i = 0; i < dsSqlEnterData.size(); i++) {
                    String slidesectiondt = dsSqlEnterData.getValue(i, "u_slidesectiondate", "");
                    if (!Util.isNull(slidesectiondt)) {
                        try {
                            //input date format
                            SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyyy");
                            //output date format
                            SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd-MMM-yyyy");
                            Date date = dFormat.parse(slidesectiondt);
                            String formtSlideSectndt = dFormatFinal.format(date);
                            dsSqlEnterData.setValue(i, "u_slidesectiondate", formtSlideSectndt.toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }

    private void sharedHnE() throws SapphireException {
        HashMap hm = new HashMap();
        hm.put(DATASET_PROPERTY_METHODOLOGY, "Generic");
        DataSet dsSharedHE = dsFinal.getFilteredDataSet(hm);
        if (dsSharedHE == null && dsSharedHE.size() == 0) {
            return;
        }
        String genericTestcodes = Util.getUniqueList(dsSharedHE.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true);

        String sql = "select lvtestcodeid, methodology from u_sharedhne where lvtestcodeid in('" + StringUtil.replaceAll(genericTestcodes, ";", "','") + "')";
        DataSet dsSharedMaster = getQueryProcessor().getSqlDataSet(sql);
        if (dsSharedMaster == null || dsSharedMaster.size() == 0) {
            return;
        }

        dsSharedHE.addColumn("sampleid", DataSet.STRING);

        DataSet dsSharedTransactonal = new DataSet();
        dsSharedTransactonal.addColumn("sampleid", DataSet.STRING);
        dsSharedTransactonal.addColumn("lvtestcodeid", DataSet.STRING);
        dsSharedTransactonal.addColumn("methodology", DataSet.STRING);
        for (int i = 0; i < dsSharedHE.size(); i++) {
            String sampleId = dsSharedHE.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String testcodeId = dsSharedHE.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            hm.clear();
            hm.put("lvtestcodeid", testcodeId);

            DataSet ds = dsSharedMaster.getFilteredDataSet(hm);
            if (ds.size() > 0) {
                for (int j = 0; j < dsSharedMaster.size(); j++) {
                    //put all into a new dataset...
                    int rowId = dsSharedTransactonal.addRow();
                    dsSharedTransactonal.setValue(rowId, "sampleid", sampleId);
                    dsSharedTransactonal.setValue(rowId, "lvtestcodeid", dsSharedMaster.getValue(j, "lvtestcodeid", ""));
                    dsSharedTransactonal.setValue(rowId, "methodology", dsSharedMaster.getValue(j, "methodology", ""));
                }
            }
        }
        //Add sdi to sharedH&EMap -----------------------
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "SharedHnEMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, "" + dsSharedTransactonal.size());
        props.setProperty("sampleid", dsSharedTransactonal.getColumnValues("sampleid", ";"));
        props.setProperty("lvtestcodeid", dsSharedTransactonal.getColumnValues("lvtestcodeid", ";"));
        props.setProperty("methodology", dsSharedTransactonal.getColumnValues("methodology", ";"));

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);

    }

    private void applyPanelWithSlide() throws SapphireException {
        if (dsFinal.size() > 0) {
            if (!dsFinal.isValidColumn("isslide"))
                dsFinal.addColumn("isslide", DataSet.STRING);
            for (int i = 0; i < dsFinal.size(); i++) {
                String u_type = dsFinal.getValue(i, "u_type", "");
                if (Util.isNull(u_type) || "EB".equalsIgnoreCase(u_type))
                    dsFinal.setValue(i, "isslide", "N");
                else
                    dsFinal.setValue(i, "isslide", "Y");
            }
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("isslide", "Y");
            hm.put("ispanel", "Y");
            hm.put("methodology", "IHC");
            DataSet dsPanelFilter = dsFinal.getFilteredDataSet(hm);
            if (dsPanelFilter != null && dsPanelFilter.size() > 0) {
                String slides = Util.getUniqueList(dsPanelFilter.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
                PropertyList prop = new PropertyList();
                prop.setProperty("sampleids", slides);
                try {
                    getActionProcessor().processAction("AssignTestcodeOnSlides", "1", prop);
                } catch (Exception ex) {
                    throw new SapphireException(ex.getMessage());
                }
            }
        }
    }

    private void updateExtractionTypeForExtractedMetirial(String sampleids) throws SapphireException {
        sampleids = StringUtil.replaceAll(sampleids, ";", "','");
        String sql = Util.parseMessage(MolecularSql.GET_EXTRACTIONTYPE_BY_SAMPLEID, sampleids);
        DataSet dsNano = getQueryProcessor().getSqlDataSet(sql);
        if (dsNano != null && dsNano.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsNano.getColumnValues("u_sampletestcodemapid", ";"));
            prop.setProperty("extractiontype", dsNano.getColumnValues("u_extractiontype", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update extraction type.");
            }
        }
    }

    private void autoBatchCreation() throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_SPONSOR_ABBRE_BY_SAMPLEID,
                StringUtil.replaceAll(dsFinal.getColumnValues("s_sampleid", ";"), ";", "','"));
        DataSet dsSampleinfo = getQueryProcessor().getSqlDataSet(sql);
        String accessionid = Util.getUniqueList(dsSampleinfo.getColumnValues("u_accessionid", ";"), ";", true);
        sql = Util.parseMessage(MolecularSql.GET_BATCH_FLAG, StringUtil.replaceAll(accessionid, ";", "','"));
        DataSet dsBatchFlag = getQueryProcessor().getSqlDataSet(sql);
        String molbatchflag = dsBatchFlag.getValue(0, "molbatchflag", "N");
        if ("N".equalsIgnoreCase(molbatchflag)) {
            return;
        }
        HashMap hm = new HashMap();
        hm.clear();
        hm.put(DATASET_PROPERTY_METHODOLOGY, "Molecular");
        DataSet dsFilterMol = dsFinal.getFilteredDataSet(hm);
        if (dsFilterMol != null && dsFilterMol.size() > 0) {
            String sampleids = dsFilterMol.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";");
            String lvtestcodeid = dsFilterMol.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";");
            PropertyList props = new PropertyList();
            props.setProperty("sampleids", sampleids);
            props.setProperty("lvtestcodeid", lvtestcodeid);
            getActionProcessor().processAction(MolAutoCreateBatchSample.ID, MolAutoCreateBatchSample.VERSIONID, props);
        }
        //throw new SapphireException("new batch creation");
    }

    /**
     * This will validate sampletype & transport type of test code(s) but not
     * panels. and add the sampletype, transport type to dsFinal
     *
     * @throws SapphireException
     */

    private HashMap<String, String> getAPSlideType() throws SapphireException {
        HashMap<String, String> hm = new HashMap<String, String>();
        PropertyList policyProps = getConfigurationProcessor().getPolicy(POLICY_NAME, POLICY_NODE);
        if (policyProps == null) {
            String errMsg = getTranslationProcessor().translate("Unable to retrieve Policy properties.");
            errMsg += POLICY_NAME;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        PropertyListCollection plclosmap = policyProps.getCollection("TestSlideColl");
        if (plclosmap != null) {
            for (int i = 0; i < plclosmap.size(); i++) {
                PropertyList plChildLOS = plclosmap.getPropertyList(i).getPropertyList("keyvalue");
                String testcode = plChildLOS.getProperty("testcode");
                String slidetype = plChildLOS.getProperty("slidetype");
                hm.put(testcode, slidetype);
            }
        }
        return hm;
    }

    private void validateSampleTypeTransportType() throws SapphireException {

        // TODO recheck yr logic for panel
        String sampleids = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);

        // No need to validate for control sample(s) >> provided control samples
        // and patient sample will not come together.
        String controlSampleSql = "select reagentlotid,qcsampletype from s_sample where reagentlotid is not null and  qcsampletype is not null"
                + " and  s_sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        DataSet dsControlSample = getQueryProcessor().getSqlDataSet(controlSampleSql);
        if (dsControlSample != null && dsControlSample.size() > 0) {
            return;
        }

        String sql = "select s.s_sampleid,s.sampletypeid specimentype,t.containertypeid transporttype from s_sample s,trackitem t"
                + " where s.s_sampleid = t.linkkeyid1 and t.linksdcid='Sample'" + " and s.s_sampleid in ('"
                + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        DataSet dsSampleContainer = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleContainer == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsSampleContainer.size() == 0) {
            String err = "No sample id found in LV system \n" + sampleids;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        // GET SITE FROM DEPARTMENT
        sql = "select u_site from department where departmentid='" + connectionInfo.getDefaultDepartment() + "'";
        DataSet dsSite = getQueryProcessor().getSqlDataSet(sql);
        String site = dsSite.getValue(0, "u_site", "");
        // 2. inserting sampletype, transport type to dsFinal from sample,
        // trackitem table
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_SAMPLE_TYPE_ID)) {
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLE_TYPE_ID, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_TRANSPORT_TYPE_ID)) {
            dsFinal.addColumn(DATASET_PROPERTY_TRANSPORT_TYPE_ID, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_RECEIVING_LOCATION)) {
            dsFinal.addColumn(DATASET_PROPERTY_RECEIVING_LOCATION, DataSet.STRING);
        }

        String testCodes = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true);
        // Query for Backup testcodes
        String sqlBackup = Util.parseMessage(MolecularSql.GET_BACKUPFLAG, StringUtil.replaceAll(testCodes, ";", "','"));
        DataSet dsBackupTestCodes = getQueryProcessor().getSqlDataSet(sqlBackup);

        HashMap<String, String> hm = new HashMap();
        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            String dsFinalSampleID = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String dsFinalLVTestCodeId = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            hm.clear();
            hm.put(DATASET_PROPERTY_SAMPLE_ID, dsFinalSampleID);

            DataSet dsFilter = dsSampleContainer.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                dsFinal.setValue(i, DATASET_PROPERTY_SAMPLE_TYPE_ID, dsFilter.getValue(0, "specimentype", ""));
                dsFinal.setValue(i, DATASET_PROPERTY_TRANSPORT_TYPE_ID, dsFilter.getValue(0, "transporttype", ""));
                // dsFinal.setValue(i, DATASET_PROPERTY_RECEIVING_LOCATION,
                // connectionInfo.getDefaultDepartment());//TODO CHANGED, DEPEND
                // ON RECEIVING SITE
                dsFinal.setValue(i, DATASET_PROPERTY_RECEIVING_LOCATION, site);
            }

            // By passing tansport type validation for backup tests
            if (dsBackupTestCodes != null && dsBackupTestCodes.size() > 0) {
                hm.clear();
                hm.put("u_testcodeid", dsFinalLVTestCodeId);
                DataSet dsFilterBackupTest = dsBackupTestCodes.getFilteredDataSet(hm);
                if (dsFilterBackupTest != null && dsFilterBackupTest.size() > 0) {
                    dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
                }
            }
        }

        // 2. Logic for getting testcode
        // TODO change Query -- SB
        sql = "select u_testcodeid,receivingloc,performingloc,sampletypeid,transporttypeid"
                + " from u_st_ct_loc_dtl where u_testcodeid in ('" + StringUtil.replaceAll(testCodes, ";", "','")
                + "')";

        DataSet dsTestCodes = getQueryProcessor().getSqlDataSet(sql);

        if (dsTestCodes == null && dsBackupTestCodes == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsTestCodes.size() == 0) {
            // TODo change msg -- SB
            /*
             * String err =
			 * "Specimentype, Transporttype, Receiving Location, Performing Location) combination does not found for below Testcode(s) \n"
			 * + testCodes; throw new
			 * SapphireException(ErrorDetail.TYPE_VALIDATION, err);
			 */
        }
        // Query to get methodology for test codes
        sql = Util.parseMessage(MolecularSql.GET_BACKUPMETHOLOGY, StringUtil.replaceAll(testCodes, ";", "','"));
        DataSet dsMethodology = getQueryProcessor().getSqlDataSet(sql);
        String methodology = dsMethodology.getValue(0, "methodology", "");
        // String backupFlag = dsMethodology.getValue(0, "backupflag", "");
        if (dsMethodology == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsMethodology.size() == 0) {
            String err = "Methodology does not found into the system for below Testcode(s)\n" + testCodes;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsTestCodes.size() > 0) {
            // SET BYPASS FLAG 'N' WHEN METHODOLOGY OF TEST CODE IS IHC OR FISH
            // OR MOLECULAR
            for (int i = 0; i < dsFinal.getRowCount(); i++) {
                String testCodeFromDsFinall = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
                if (testCodeFromDsFinall.equalsIgnoreCase(testCodes)) {
                    String byPassValueEarlier = dsFinal.getValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "");
                    if (byPassValueEarlier.equalsIgnoreCase("Y")) {
                        continue; // for backup already "Y" has been set so dont
                        // consider them
                    }
                    if ("IHC".equalsIgnoreCase(methodology)) {
                        dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "N");
                    } else if ("FISH".equalsIgnoreCase(methodology)) {
                        dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "N");
                    } else if ("Molecular".equalsIgnoreCase(methodology)) {
                        dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "N");
                    } else if ("Cytogenetics".equalsIgnoreCase(methodology)) {
                        dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "N");
                    } else if ("Flow".equalsIgnoreCase(methodology)) {
                        dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "N");
                    } else {
                        dsFinal.setValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
                    }
                }
            }
        }

        DataSet dsError = new DataSet();
        dsError.addColumn("u_testcodeid", DataSet.STRING);
        dsError.addColumn("sampletypeid", DataSet.STRING);
        dsError.addColumn("transporttypeid", DataSet.STRING);
        dsError.addColumn("receivingloc", DataSet.STRING);

        // dsTestCodes.sort("u_testcodeid,sampletypeid,transporttypeid,receivingloc");
        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            String sampleID = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String testCodeFromDsFinal = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            String sampleTypeFromDsFinal = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_TYPE_ID, "");
            String transportType = dsFinal.getValue(i, DATASET_PROPERTY_TRANSPORT_TYPE_ID, "");
            String receivingLoc = dsFinal.getValue(i, DATASET_PROPERTY_RECEIVING_LOCATION, "");
            String byPassFromDsfinal = dsFinal.getValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "");
            if (byPassFromDsfinal.equalsIgnoreCase("Y")) {
                continue;
            }

            hm.clear();
            hm.put("u_testcodeid", testCodeFromDsFinal);
            hm.put("sampletypeid", sampleTypeFromDsFinal);// TODO DO NOT REMOVE
            // THIS, WHEN DATA
            // WILL BE AVAILABLE
            // WE WILL TEST THIS
            hm.put("receivingloc", receivingLoc);
            hm.put("transporttypeid", transportType);// TODO REAL DATA MISMATCH
            // FROM DATABASE (HAVE
            // SPACE)

            DataSet dsFilter = dsTestCodes.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                dsFinal.setValue(i, DATASET_PROPERTY_PERFORMING_LOCATION, dsFilter.getValue(0, "performingloc", ""));
            } else { /// Throw exception path..
                if ("IHC".equalsIgnoreCase(dsMethodology.getValue(0, "methodology", ""))) {
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "u_testcodeid", testCodeFromDsFinal);
                    dsError.setValue(rowID, "sampletypeid", sampleTypeFromDsFinal);
                    dsError.setValue(rowID, "transporttypeid", transportType);
                    dsError.setValue(rowID, "receivingloc", receivingLoc);
                } else if ("FISH".equalsIgnoreCase(dsMethodology.getValue(0, "methodology", ""))) {
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "u_testcodeid", testCodeFromDsFinal);
                    dsError.setValue(rowID, "sampletypeid", sampleTypeFromDsFinal);
                    dsError.setValue(rowID, "transporttypeid", transportType);
                    dsError.setValue(rowID, "receivingloc", receivingLoc);
                } else if ("Molecular".equalsIgnoreCase(dsMethodology.getValue(0, "methodology", ""))) {
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "u_testcodeid", testCodeFromDsFinal);
                    dsError.setValue(rowID, "sampletypeid", sampleTypeFromDsFinal);
                    dsError.setValue(rowID, "transporttypeid", transportType);
                    dsError.setValue(rowID, "receivingloc", receivingLoc);
                } else if ("Cytogenetics".equalsIgnoreCase(dsMethodology.getValue(0, "methodology", ""))) {
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "u_testcodeid", testCodeFromDsFinal);
                    dsError.setValue(rowID, "sampletypeid", sampleTypeFromDsFinal);
                    dsError.setValue(rowID, "transporttypeid", transportType);
                    dsError.setValue(rowID, "receivingloc", receivingLoc);
                } else {
                    dsFinal.setValue(i, DATASET_PROPERTY_PERFORMING_LOCATION,
                            dsFilter.getValue(0, "performingloc", ""));
                }
            }
        }

        // Validation of receiving location, transporttype and specimentype
        // combination
        // TODO: Bloock this section if error occurs due inavailability of
        // master data.
        if (dsError.getRowCount() > 0) {
            String error = "( Specimen Type, Transport Type, Receiving Site) combination does not exists for below TestCode(s):";
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("testcode_id", DataSet.STRING);
            dsDisplayMsg.addColumn("specimen_type", DataSet.STRING);
            dsDisplayMsg.addColumn("transport_type", DataSet.STRING);
            dsDisplayMsg.addColumn("receiving_site", DataSet.STRING);
            for (int i = 0; i < dsError.size(); i++) {
                String transprt = dsError.getValue(i, "transporttypeid", "");
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "testcode_id", dsError.getValue(i, "u_testcodeid", ""));
                dsDisplayMsg.setValue(rowID, "specimen_type", dsError.getValue(i, "sampletypeid", ""));
                //dsDisplayMsg.setValue(rowID, "transport_type", dsError.getValue(i, "transporttypeid", ""));
                if (transprt.contains("&"))
                    transprt = StringUtil.replaceAll(transprt, "&", "%26");
                dsDisplayMsg.setValue(rowID, "transport_type", transprt);
                dsDisplayMsg.setValue(rowID, "receiving_site", dsError.getValue(i, "receivingloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error + errCodes);
        }

    }

    /**
     * Description: This method is used for checking SampleType and
     * ContainerType of given samples.
     *
     * @param properties
     * @throws SapphireException
     * @author SB
     */
    private void checkSampleTypeContainerType(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");
        String lvtestcodes = properties.getProperty(INPUT_PROPERTY_LV_TEST_CODE, "");
        String sql = "select s.sampletypeid,t.containertypeid,s.u_type,s.s_sampleid from s_sample s, trackitem t,u_st_ct_loc_dtl tsd"
                + " where t.linkkeyid1 = s.s_sampleid" + " and tsd.sampletypeid=s.sampletypeid"
                + " and tsd.transporttypeid=t.containertypeid" + " and s.s_sampleid in ('"
                + StringUtil.replaceAll(sampleids, ";", "','") + "')" + " and tsd.u_testcodeid in ('"
                + StringUtil.replaceAll(lvtestcodes, ";", "','") + "')";
        DataSet dsCheck = getQueryProcessor().getSqlDataSet(sql);
        if (dsCheck == null || dsCheck.size() == 0) {
            message = "Test(s) successfully added..\n"
                    + "Warning: Specimen Type or Transport Type has not been validated for test(s).";
        } else {
            message = "Test(s) successfully added..";
        }
    }

    /**
     * This will validate Samplesids, testcodes and test addon flag
     *
     * @param properties
     * @throws SapphireException
     */
    private DataSet validateInputs(PropertyList properties) throws SapphireException {

        String sampleids[] = StringUtil.split(properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, ""), ";");
        String lvtestcodes[] = StringUtil.split(properties.getProperty(INPUT_PROPERTY_LV_TEST_CODE, ""), ";");// This
        // is
        // both
        // Panel
        // &
        // Test
        // Codes
        /*
         * Note: when panels are associated with sample then only we need
		 * methodology. Suppose a panel have 3 methodology: FISH, Molecular, IHC
		 * and we only want to add FISH & IHC but not Molecular then provide
		 * below as param. Sample:s1;s2 TestCode: P1;P2 methodology:
		 * FISH#IHC;Molecular
		 */

        mandatoryInputCheck(sampleids, lvtestcodes);
        existanceOfMandatoryInput(properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, ""),
                properties.getProperty(INPUT_PROPERTY_LV_TEST_CODE, ""));

        DataSet dsInput = new DataSet();
        dsInput.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING); // 1.
        // Sample
        // ID
        dsInput.addColumn(DATASET_PROPERTY_LV_TEST_CODE, DataSet.STRING); // 2.
        // This
        // can
        // be
        // a
        // testcode
        // or
        // a
        // panel
        dsInput.addColumn(DATASET_PROPERTY_IS_PANEL, DataSet.STRING); // 3. Make
        // ispanel
        // ='Y'
        // if
        // no. 2
        // is a
        // panel
        dsInput.addColumn(DATASET_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, DataSet.STRING); // 4.
        // IF
        // no.
        // 2
        // is
        // a
        // panel
        // code
        // having
        // multiple
        // methodology.
        // &
        // you
        // want
        // to
        // add
        // only
        // one
        // methdology's
        // testcode
        dsInput.addColumn(INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, DataSet.STRING); // 5.
        // if
        // no.
        // 2
        // is
        // a
        // testcode
        // which
        // is
        // a
        // part
        // of
        // panel
        // &
        // you
        // want
        // to
        // add
        // only
        // one
        // testcode
        // +
        // panel

        dsInput.addColumn(DATASET_PROPERTY_APPLY_WI, DataSet.STRING);
        dsInput.addColumn(DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, DataSet.STRING);
        dsInput.addColumn(DATASET_PROPERTY_ADDON_TEST, DataSet.STRING);

        // CHECK FLAG IF SAMPLE HAVE 'Y' FLAG OR NOT
        String sql = "SELECT U_ACCESSIONINGCOMPLETE FROM S_SAMPLE WHERE S_SAMPLEID IN ('"
                + StringUtil.replaceAll(properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, ""), ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.size() == 0) {
            String err = "Accessioning Complete Flag not found for below Sample(s).\n "
                    + properties.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String isTestAddOnP = ds.getColumnValues("U_ACCESSIONINGCOMPLETE", ";");
        // String isTestAddOnP =
        // properties.getProperty(INPUT_PROPERTY_IS_TEST_ADDON, "");
        String isTestAddOn[] = null;
        if ("".equalsIgnoreCase(isTestAddOnP)) {
            isTestAddOn = StringUtil.split(StringUtil.repeat("N", sampleids.length, ";"), ";");
        } else {
            isTestAddOn = StringUtil.split(setDefaultValueForNULL(isTestAddOnP, "N", sampleids.length), ";");
        }

        String applyWIP = properties.getProperty(INPUT_PROPERTY_APPLY_WI, "");
        String applyWI[] = null;
        if ("".equalsIgnoreCase(applyWIP)) {
            applyWI = StringUtil.split(StringUtil.repeat("Y", sampleids.length, ";"), ";"); // By
            // default
            // ApplyWi
            // is
            // Yes
        } else {
            applyWI = StringUtil.split(
                    setDefaultValueForNULL(properties.getProperty(INPUT_PROPERTY_APPLY_WI, ""), "Y", sampleids.length),
                    ";");
        }

        String byPassP = properties.getProperty(INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "");
        String byPass[] = null;
        if ("".equalsIgnoreCase(byPassP)) {
            byPass = StringUtil.split(StringUtil.repeat("N", sampleids.length, ";"), ";");
        } else {
            byPass = StringUtil.split(setDefaultValueForNULL(
                    properties.getProperty(INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, ""), "N", sampleids.length), ";");
        }

        String applyMethodologyP = properties.getProperty(INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, "");
        String applyMethodology[] = null;
        if ("".equalsIgnoreCase(applyMethodologyP)) {
            applyMethodology = StringUtil.split(StringUtil.repeat("", sampleids.length, ";"), ";");
        } else {
            applyMethodology = StringUtil.split(setDefaultValueForNULL(applyMethodologyP, "", sampleids.length), ";");
        }

        // TODO this section will be effective if Testcodeid is only testcode(
        // not paneldoce). better to put in datset if testcode ordered
        String associatePanelP = properties.getProperty(INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, "");
        String associatePanel[] = null;
        if ("".equalsIgnoreCase(associatePanelP)) {
            associatePanel = StringUtil.split(StringUtil.repeat("", sampleids.length, ";"), ";");
        } else {
            associatePanel = StringUtil.split(setDefaultValueForNULL(associatePanelP, "", sampleids.length), ";");
        }

        if (sampleids.length != lvtestcodes.length) {
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "No of input parameter not matching.");
        }
        // TODO Check if sampleid, lvtestcodes are blank
        for (int i = 0; i < sampleids.length; i++) {
            int rowID = dsInput.addRow();
            dsInput.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID, sampleids[i]);
            dsInput.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE, lvtestcodes[i]);// This
            // can
            // be
            // testcode/panel
            // dsInput.setValue(rowID, DATASET_PROPERTY_IS_PANEL, isPanel[i]);
            dsInput.setValue(rowID, DATASET_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, applyMethodology[i]);
            dsInput.setValue(rowID, INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, associatePanel[i]);
            dsInput.setValue(rowID, DATASET_PROPERTY_APPLY_WI, applyWI[i]);
            dsInput.setValue(rowID, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, byPass[i]);
            dsInput.setValue(rowID, DATASET_PROPERTY_ADDON_TEST, isTestAddOn[i]);
        }

        return dsInput;
    }

    /**
     * This will validate check mandatory Inputs.
     *
     * @param sampleids, lvtestcodes and isTestAddOnP
     * @throws SapphireException
     * @author SB
     */
    private void mandatoryInputCheck(String sampleids[], String lvtestcodes[]) throws SapphireException {
        if (sampleids == null) {
            String errStr = getTranslationProcessor().translate("Mandatory field (Sample) can not be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (lvtestcodes == null) {
            String errStr = getTranslationProcessor().translate("Mandatory field ( Test Codes) can not be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }

        int sampleidsLength = sampleids.length;
        int lvtestcodesLength = lvtestcodes.length;
        if (sampleidsLength <= 0 || lvtestcodesLength <= 0) {
            String errStr = getTranslationProcessor()
                    .translate("Mandatory field( sample | test codes | Add On Tests ) can not be null");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        for (int i = 0; i < sampleidsLength; i++) {
            if (sampleids[i] == null || "".equals(sampleids[i])) {
                String errStr = getTranslationProcessor().translate("One of the sample Id is empty.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
        for (int i = 0; i < lvtestcodesLength; i++) {
            if (lvtestcodes[i] == null || "".equals(lvtestcodes[i])) {
                String errStr = getTranslationProcessor().translate("One of the test code Id is empty");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
    }

    /**
     * Description: This method is used for checking mandatory input.
     *
     * @param sampleids
     * @param lvtestcodes
     * @throws SapphireException
     * @author SB
     */
    private void existanceOfMandatoryInput(String sampleids, String lvtestcodes) throws SapphireException {

        String sql = "select s_sampleid from s_sample where s_sampleid in ( '"
                + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.size() == 0) {
            String err = "One or multiple sample(s) from below samples are not found in LV system \n" + sampleids;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String sqlTestcode = "select u_testcodeid from u_testcode where u_testcodeid in ( '"
                + StringUtil.replaceAll(lvtestcodes, ";", "','") + "')";
        DataSet dsTestcode = getQueryProcessor().getSqlDataSet(sqlTestcode);
        if (dsTestcode == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sqlTestcode;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsTestcode.size() == 0) {
            String err = "No Test code id found in LV system \n" + lvtestcodes;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

    }

    /**
     * Description: This method is used for adding testcodes to Final Dataset.
     *
     * @param dsFilter
     * @throws SapphireException
     * @author SB
     */
    private void addTestCodesToFinalDataSet(DataSet dsFilter) throws SapphireException {
        if (dsFilter == null || dsFilter.size() == 0) {
            return;
        }

        for (int i = 0; i < dsFilter.size(); i++) {
            int rowID = dsFinal.addRow();
            dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID, dsFilter.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE,
                    dsFilter.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_LV_PANEL_CODE,
                    dsFilter.getValue(i, INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_IS_PANEL, dsFilter.getValue(i, DATASET_PROPERTY_IS_PANEL, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_APPLY_WI, dsFilter.getValue(i, DATASET_PROPERTY_APPLY_WI, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE,
                    dsFilter.getValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_ADDON_TEST, dsFilter.getValue(i, DATASET_PROPERTY_ADDON_TEST, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsFilter.getValue(i, DATASET_PROPERTY_METHODOLOGY, ""));
        }

    }

    /**
     * Description: This method is used to validate dummy test panel for
     * multiomyx only
     *
     * @param dsFilter
     * @throws SapphireException
     */
    private void addTestCodesToFinalDataSetForMultiomnyx(DataSet dsFilter) throws SapphireException {
        if (dsFilter == null || dsFilter.size() == 0) {
            return;
        }

        for (int i = 0; i < dsFilter.size(); i++) {
            int rowID = dsFinal.addRow();
            dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID, dsFilter.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE,
                    dsFilter.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_LV_PANEL_CODE,
                    dsFilter.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
            // dsFinal.setValue(rowID, DATASET_PROPERTY_LV_PANEL_CODE,
            // dsFilter.getValue(i,
            // INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_IS_PANEL, dsFilter.getValue(i, DATASET_PROPERTY_IS_PANEL, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_APPLY_WI, dsFilter.getValue(i, DATASET_PROPERTY_APPLY_WI, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE,
                    dsFilter.getValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, ""));
            dsFinal.setValue(rowID, DATASET_PROPERTY_ADDON_TEST, dsFilter.getValue(i, DATASET_PROPERTY_ADDON_TEST, ""));
        }

    }

    /**
     * Description: This method is used for adding panel to Final Dataset.
     *
     * @param dsInputFilter
     * @throws SapphireException
     * @author SB
     */
    private void addPanelCodesToFinalDataSet(DataSet dsInputFilter) throws SapphireException {
        String allLVPanelIDs = dsInputFilter.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";");
        String sql = "select tm.indtestcodeid lvtestcodeid,"
                + " (select inn.methodology from u_testcode inn where inn.u_testcodeid=tm.indtestcodeid)testcodemethodology,"
                + " t.u_testcodeid lvpanelid,nvl(t.isneotypepanel,'N') isneotypepanel,"
                + " tm.confirmatorytestflag,tm.supplementaltestflag,tm.addtionaltestflag"
                + " from u_testcode t, u_testcodepanelmap tm  where t.u_testcodeid = tm.u_testcodeid and t.ispanel='Y' and nvl(confirmatorytestflag,'N')='N'"
                + " and t.u_testcodeid in ( '" + StringUtil.replaceAll(allLVPanelIDs, ";", "','") + "')";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.size() == 0) {
            String err = "\n 1. All tests are confirmatory tests \n" + "2. No test codes found with below panel(s)\n"
                    + allLVPanelIDs;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        HashMap<String, String> hm = new HashMap<String, String>();
        HashMap<String, String> hm2 = new HashMap<String, String>();

        for (int i = 0; i < dsInputFilter.getRowCount(); i++) {
            String panelID = dsInputFilter.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            String sampleID = dsInputFilter.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String applyWI = dsInputFilter.getValue(i, DATASET_PROPERTY_APPLY_WI, "");
            String applyTransType = dsInputFilter.getValue(i, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, "");
            String testAddonFlag = dsInputFilter.getValue(i, DATASET_PROPERTY_ADDON_TEST, "");
            String applyPanelforMethodology = dsInputFilter.getValue(i, DATASET_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY,
                    "");// This can be multiple value with # seperated
            // (FISH#IHC)

            // 1. filter by panel
            hm.clear();
            hm.put("lvpanelid", panelID);

            DataSet dsf = ds.getFilteredDataSet(hm);
            if (dsf != null && dsf.getRowCount() > 0) {

                // 2. filter by different methodology for
                // applyPanelforMethodology.
                if ("".equals(applyPanelforMethodology)) {
                    for (int j = 0; j < dsf.getRowCount(); j++) {
                        int rowID = dsFinal.addRow();
                        dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID, sampleID);
                        dsFinal.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE, dsf.getValue(j, "lvtestcodeid", ""));
                        dsFinal.setValue(rowID, DATASET_PROPERTY_LV_PANEL_CODE, panelID);
                        dsFinal.setValue(rowID, DATASET_PROPERTY_IS_PANEL, "Y");
                        dsFinal.setValue(rowID, DATASET_PROPERTY_APPLY_WI, applyWI);
                        dsFinal.setValue(rowID, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, applyTransType);
                        if (testAddonFlag.equalsIgnoreCase("Y")) {
                            dsFinal.setValue(rowID, DATASET_PROPERTY_ADDON_TEST, "Y");
                        }
                    }
                } else {
                    String applyPanelforMethodologyArray[] = StringUtil.split(applyPanelforMethodology, "#");
                    for (String eachMeth : applyPanelforMethodologyArray) {
                        hm2.clear();
                        hm2.put("testcodemethodology", eachMeth);
                        DataSet dsForEachMeth = dsf.getFilteredDataSet(hm2);
                        if (dsForEachMeth != null && dsForEachMeth.getRowCount() > 0) {
                            for (int j = 0; j < dsForEachMeth.getRowCount(); j++) {
                                int rowID = dsFinal.addRow();
                                dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID, sampleID);
                                dsFinal.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE,
                                        dsForEachMeth.getValue(j, "lvtestcodeid", ""));
                                dsFinal.setValue(rowID, DATASET_PROPERTY_LV_PANEL_CODE, panelID);
                                dsFinal.setValue(rowID, DATASET_PROPERTY_IS_PANEL, "Y");
                                dsFinal.setValue(rowID, DATASET_PROPERTY_APPLY_WI, applyWI);
                                dsFinal.setValue(rowID, DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, applyTransType);
                                if (testAddonFlag.equalsIgnoreCase("Y")) {
                                    dsFinal.setValue(rowID, DATASET_PROPERTY_ADDON_TEST, "Y");
                                }
                            }

                        }
                    }

                }
            }
        }
    }

    /**
     * Description: This method is used for checking samples & testcodes are NY
     * approval or not.
     *
     * @throws SapphireException
     * @author SB
     */
    // private void nyClientValidation() throws SapphireException {
    //
    // String sampleIDs = dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID,
    // ";");
    // String testCodes = dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE,
    // ";");
    //
    // String sql_nyflag = "select distinct cl.nyflag from u_sponsor
    // cl,u_accession ac,s_sample s where s.u_accessionid =ac.u_accessionid" +
    // " and ac.clientid=cl.u_sponsorid and s.s_sampleid in('" +
    // StringUtil.replaceAll(sampleIDs, ";", "','") + "')";
    // String sql_nyapproval = "select nyapproval from u_testcode where
    // u_testcodeid in ('" + StringUtil.replaceAll(testCodes, ";", "','") +
    // "')";
    //
    // DataSet ds = getQueryProcessor().getSqlDataSet(sql_nyflag);
    // String nyflag = ds.getValue(0, "nyflag");
    // DataSet ds1 = getQueryProcessor().getSqlDataSet(sql_nyapproval);
    // String nyapproval = ds1.getValue(0, "nyapproval");
    // if ("Y".equalsIgnoreCase(nyflag) && !"Y".equalsIgnoreCase(nyapproval)) {
    // throw new SapphireException("NY Client can only add test codes which have
    // NY Approval");
    // }
    // }
    private void validateTestcodeOnSlide() throws SapphireException {
        String sampleid = dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";");
        DataSet dsMessage = new DataSet();
        dsMessage.addColumn("sampleid", DataSet.STRING);
        dsMessage.addColumn("testcode", DataSet.STRING);
        DataSet dsSameTCMessage = new DataSet();
        dsSameTCMessage.addColumn("sampleid", DataSet.STRING);
        dsSameTCMessage.addColumn("testcode", DataSet.STRING);
        String sql = Util.parseMessage(AccessionPageSql.GET_VALIDATE_TCODE_BY_SAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsTcode = getQueryProcessor().getSqlDataSet(sql);
        if (dsTcode != null && dsTcode.size() > 0) {
            dsTcode.sort("s_sampleid");
            ArrayList<DataSet> dsFinalArr = dsTcode.getGroupedDataSets("s_sampleid");
            for (int i = 0; i < dsFinalArr.size(); i++) {
                DataSet dsEach = (DataSet) dsFinalArr.get(i);
                if (dsEach.size() > 1) {
                    for (int c = 0; c < dsEach.size(); c++) {
                        int rowid = dsMessage.addRow();
                        dsMessage.setValue(rowid, "sampleid", dsEach.getValue(c, "s_sampleid", ""));
                        dsMessage.setValue(rowid, "testcode", dsEach.getValue(c, "lvtestcodeid", ""));
                    }
                }
            }
        }
        sql = Util.parseMessage(AccessionPageSql.GET_VALIDATE_SAME_TCODE_BY_SAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsTotalTcode = getQueryProcessor().getSqlDataSet(sql);
        if (dsTotalTcode != null && dsTotalTcode.size() > 0) {
            dsTotalTcode.sort("s_sampleid,lvtestcodeid");
            ArrayList<DataSet> dsFinalArr = dsTotalTcode.getGroupedDataSets("s_sampleid,lvtestcodeid");
            for (int i = 0; i < dsFinalArr.size(); i++) {
                DataSet dsEach = (DataSet) dsFinalArr.get(i);
                if (dsEach.size() > 1) {
                    for (int c = 0; c < dsEach.size(); c++) {
                        int rowid = dsSameTCMessage.addRow();
                        dsSameTCMessage.setValue(rowid, "sampleid", dsEach.getValue(c, "s_sampleid", ""));
                        dsSameTCMessage.setValue(rowid, "testcode", dsEach.getValue(c, "lvtestcodeid", ""));
                    }
                }
            }
        }

        if (dsMessage != null && dsMessage.size() > 0) {
            String errCodes = "Duplicate/More than one testcode(s) associated with the below slide(s):";
            errCodes += Util.getDisplayMessage(dsMessage);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errCodes);
        }
        if (dsSameTCMessage != null && dsSameTCMessage.size() > 0) {
            String errCodes = "Already slide(s)/specimen(s) has same cancelled testcode(s). Please undo cancel/delete this test(s):";
            errCodes += Util.getDisplayMessage(dsSameTCMessage);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errCodes);
        }
    }

    /**
     * Description: This method is used for add test codes.
     *
     * @throws SapphireException
     * @author SB
     */
    private String addTestCodes() throws SapphireException {
        String allTestCodes = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";",
                true);
        setCopyDownProperties(allTestCodes);

        String allPanelCodes = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_PANEL_CODE, ";"), ";",
                true);
        setCopyDownPanelProperties(allPanelCodes);

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, "" + dsFinal.size());
        props.setProperty("teststatus", StringUtil.repeat("In Progress", dsFinal.size(), ";"));
        for (int i = 0; i < dsFinal.getColumnCount(); i++) {
            String colID = dsFinal.getColumnId(i);
            props.setProperty(colID, dsFinal.getColumnValues(colID, ";"));
        }

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            updateSlideTypeForSpecial();
            editPerfRcvLoc(props.getProperty("newkeyid1"));
            return props.getProperty("newkeyid1");
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("error >>  ");
            error += ex.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    private void updateSlideTypeForSpecial() throws SapphireException {

			/*
             * Change by Subhendu - 4th April 2017: Negative Control Checkin +
			 */
            /* This piece of code is only for BIO PHARMA */

        DataSet dsUSS = new DataSet();
        dsUSS.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsUSS.addColumn(DATASET_PROPERTY_UTYPE, DataSet.STRING);
        dsUSS.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        // TODO NEED TO MODIFY HERE
        /**
         * THIS IS USED TO CHANGE SLIDE TYPE INTO THE ACCESSION STARTS
         */
        HashMap<String, String> hmslides = new HashMap<String, String>();
        // TODO NEGATIVE CONTROL
        hmslides.clear();
        hmslides.put("transporttypeid", "Unstained Slide");
        hmslides.put(DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG, "Y");
        DataSet dsNegtvControlUnstain = dsFinal.getFilteredDataSet(hmslides);
        if (dsNegtvControlUnstain != null && dsNegtvControlUnstain.size() > 0) {
            for (int nc = 0; nc < dsNegtvControlUnstain.size(); nc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsNegtvControlUnstain.getValue(nc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "NC");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsNegtvControlUnstain.getValue(nc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("specimentypeid", "Paraffin Tissue");
        hmslides.put("transporttypeid", "Stained Slide");
        hmslides.put(DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG, "Y");
        DataSet dsNegtvControlStain = dsFinal.getFilteredDataSet(hmslides);
        if (dsNegtvControlStain != null && dsNegtvControlStain.size() > 0) {
            for (int nc = 0; nc < dsNegtvControlStain.size(); nc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsNegtvControlStain.getValue(nc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "NC");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsNegtvControlStain.getValue(nc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("u_type", "U");
        hmslides.put(DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG, "Y");
        DataSet dsNegtvControlChildUnstain = dsFinal.getFilteredDataSet(hmslides);
        if (dsNegtvControlChildUnstain != null && dsNegtvControlChildUnstain.size() > 0) {
            for (int nc = 0; nc < dsNegtvControlChildUnstain.size(); nc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsNegtvControlChildUnstain.getValue(nc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "NC");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY, dsNegtvControlChildUnstain.getValue(nc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        // TODO POSITIVE CONTROL
        hmslides.clear();
        hmslides.put("transporttypeid", "Unstained Slide");
        hmslides.put(DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG, "Y");
        DataSet dsPositiveControlUnsta = dsFinal.getFilteredDataSet(hmslides);
        if (dsPositiveControlUnsta != null && dsPositiveControlUnsta.size() > 0) {
            for (int pc = 0; pc < dsPositiveControlUnsta.size(); pc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsPositiveControlUnsta.getValue(pc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "PC");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsPositiveControlUnsta.getValue(pc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("specimentypeid", "Paraffin Tissue");
        hmslides.put("transporttypeid", "Stained Slide");
        hmslides.put(DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG, "Y");
        DataSet dsPositiveControlStain = dsFinal.getFilteredDataSet(hmslides);
        if (dsPositiveControlStain != null && dsPositiveControlStain.size() > 0) {
            for (int pc = 0; pc < dsPositiveControlStain.size(); pc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsPositiveControlStain.getValue(pc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "PC");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsPositiveControlStain.getValue(pc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("u_type", "U");
        hmslides.put(DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG, "Y");
        DataSet dsPositiveControlChildStain = dsFinal.getFilteredDataSet(hmslides);
        if (dsPositiveControlChildStain != null && dsPositiveControlChildStain.size() > 0) {
            for (int pc = 0; pc < dsPositiveControlChildStain.size(); pc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsPositiveControlChildStain.getValue(pc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "PC");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsPositiveControlChildStain.getValue(pc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        // TODO CLIENT H&E
        hmslides.clear();
        hmslides.put("transporttypeid", "H&E Slide");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsClientHNE = dsFinal.getFilteredDataSet(hmslides);
        if (dsClientHNE != null && dsClientHNE.size() > 0) {
            for (int ch = 0; ch < dsClientHNE.size(); ch++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsClientHNE.getValue(ch, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "CH");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsClientHNE.getValue(ch, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("transporttypeid", "Client H&E Slide");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsHNE = dsFinal.getFilteredDataSet(hmslides);
        if (dsHNE != null && dsHNE.size() > 0) {
            for (int hn = 0; hn < dsHNE.size(); hn++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsHNE.getValue(hn, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "CH");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsHNE.getValue(hn, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("transporttypeid", "Unstained Slide");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsHNEUnsta = dsFinal.getFilteredDataSet(hmslides);
        if (dsHNEUnsta != null && dsHNEUnsta.size() > 0) {
            for (int pc = 0; pc < dsHNEUnsta.size(); pc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsHNEUnsta.getValue(pc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "H");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsHNEUnsta.getValue(pc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("specimentypeid", "Paraffin Tissue");
        hmslides.put("transporttypeid", "Stained Slide");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsHNEStain = dsFinal.getFilteredDataSet(hmslides);
        if (dsHNEStain != null && dsHNEStain.size() > 0) {
            for (int pc = 0; pc < dsHNEStain.size(); pc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsHNEStain.getValue(pc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "H");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsHNEStain.getValue(pc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("u_type", "U");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsHNEChildStain = dsFinal.getFilteredDataSet(hmslides);
        if (dsHNEChildStain != null && dsHNEChildStain.size() > 0) {
            for (int pc = 0; pc < dsHNEChildStain.size(); pc++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsHNEChildStain.getValue(pc, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "H");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsHNEChildStain.getValue(pc, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        /**
         * THIS IS USED TO CHANGE SLIDE TYPE INTO THE ACCESSION ENDS
         */

        /**
         * MARK H&E WHILE H&E TESTCODE IS ASSOCIATING WITH THE SLIDE(S) INTO
         * MICROTOMY STARTS HERE
         */
        // HashMap<String, String> hmslides = new HashMap<String, String>();
        hmslides.clear();
        hmslides.put("u_type", "U");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsUSSFilter = dsFinal.getFilteredDataSet(hmslides);
        if (dsUSSFilter != null && dsUSSFilter.size() > 0) {
            for (int u = 0; u < dsUSSFilter.size(); u++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsUSSFilter.getValue(u, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "H");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsUSSFilter.getValue(u, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }
        hmslides.clear();
        hmslides.put("u_type", "B");
        hmslides.put(DATASET_PROPERTY_ISHNEFLAG, "Y");
        DataSet dsBackupFilter = dsFinal.getFilteredDataSet(hmslides);
        if (dsBackupFilter != null && dsBackupFilter.size() > 0) {
            for (int u = 0; u < dsBackupFilter.size(); u++) {
                int rowID = dsUSS.addRow();
                dsUSS.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsUSSFilter.getValue(u, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsUSS.setValue(rowID, DATASET_PROPERTY_UTYPE, "B");
                dsUSS.setValue(rowID, DATASET_PROPERTY_METHODOLOGY,
                        dsUSSFilter.getValue(u, DATASET_PROPERTY_METHODOLOGY, ""));
            }
        }

        if (dsUSS != null && dsUSS.size() > 0 /*&& !dsUSS.getColumnValues(DATASET_PROPERTY_METHODOLOGY, ";").contains("FISH")*/) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, dsUSS.getColumnValues("s_sampleid", ";"));
            pl.setProperty("u_type", dsUSS.getColumnValues("u_type", ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
        /**
         * MARK H&E WHILE H&E TESTCODE IS ASSOCIATING WITH THE SLIDE(S) INTO
         * MICROTOMY ENDS HERE
         */

			/*
             * Change by Subhendu - 4th April 2017: Negative Control Checkin -
			 */

        // No need to validate for control sample(s) >> provided control
        // samples and patient sample will not come together.
        String controlSampleSql = "select reagentlotid,qcsampletype from s_sample where reagentlotid is not null and  qcsampletype is not null"
                + " and  s_sampleid in('"
                + StringUtil.replaceAll(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", "','")
                + "')";
        DataSet dsControlSample = getQueryProcessor().getSqlDataSet(controlSampleSql);
        if (dsControlSample != null && dsControlSample.size() > 0) {
            return;
        }
    }

    private void editPerfRcvLoc(String newkeyid1) throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn("s_sampleid", DataSet.STRING);
        ds.addColumn("lvtestcodeid", DataSet.STRING);
        ds.addColumn("performinglocation", DataSet.STRING);
        ds.addColumn("receivinglocation", DataSet.STRING);
        ds.addColumn("u_sampletestcodemapid", DataSet.STRING);
        ds.addColumn("sampletypeid", DataSet.STRING);
        ds.addColumn("transporttypeid", DataSet.STRING);
        String sql = "select u_sampletestcodemapid,receivinglocation,performinglocation,lvtestcodeid,s_sampleid from u_sampletestcodemap "
                + " where u_sampletestcodemapid in('" + StringUtil.replaceAll(newkeyid1, ";", "','") + "')";
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        String sampleids = dsInfo.getColumnValues("s_sampleid", ";");
        String testCodes = dsInfo.getColumnValues("lvtestcodeid", ";");

        sql = "select u_testcodeid,receivingloc,performingloc,sampletypeid,transporttypeid"
                + " from u_st_ct_loc_dtl where u_testcodeid in ('" + StringUtil.replaceAll(testCodes, ";", "','")
                + "')";

        DataSet dsTestCodes = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestCodes == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsTestCodes.size() == 0) {
        }
        sql = "select s.s_sampleid,s.sampletypeid specimentype,t.containertypeid transporttype from s_sample s,trackitem t"
                + " where s.s_sampleid = t.linkkeyid1 and t.linksdcid='Sample'" + " and s.s_sampleid in ('"
                + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        DataSet dsSampleContainer = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleContainer == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsSampleContainer.size() == 0) {
//            String err = "No sample id found in LV system \n" + sampleids;
//            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            return;
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsInfo.size(); i++) {
            hm.clear();
            hm.put("s_sampleid", dsInfo.getValue(i, "s_sampleid", ""));
            DataSet dsSTypeCType = dsSampleContainer.getFilteredDataSet(hm);
            if (dsSTypeCType != null && dsSTypeCType.size() > 0) {
                int rowID = ds.addRow();
                ds.setValue(rowID, "s_sampleid", dsInfo.getValue(i, "s_sampleid", ""));
                ds.setValue(rowID, "lvtestcodeid", dsInfo.getValue(i, "lvtestcodeid", ""));
                ds.setValue(rowID, "u_sampletestcodemapid", dsInfo.getValue(i, "u_sampletestcodemapid", ""));
                ds.setValue(rowID, "sampletypeid", dsSTypeCType.getValue(0, "specimentype", ""));
                ds.setValue(rowID, "transporttypeid", dsSTypeCType.getValue(0, "transporttype", ""));
            }
        }
        // GET SITE FROM DEPARTMENT
        sql = "select u_site from department where departmentid='" + connectionInfo.getDefaultDepartment() + "'";
        DataSet dsSite = getQueryProcessor().getSqlDataSet(sql);
        String site = dsSite.getValue(0, "u_site", "");
        for (int i = 0; i < ds.size(); i++) {
            hm.clear();
            hm.put("u_testcodeid", ds.getValue(i, "lvtestcodeid", ""));
            hm.put("sampletypeid", ds.getValue(i, "sampletypeid", ""));
            hm.put("transporttypeid", ds.getValue(i, "transporttypeid", ""));
            hm.put("receivingloc", site);
            DataSet dsFilter = dsTestCodes.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                ds.setValue(i, "performinglocation", dsFilter.getValue(0, "performingloc", ""));
                ds.setValue(i, "receivinglocation", dsFilter.getValue(0, "receivingloc", ""));
            }
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampletestcodemapid", ";"));
        prop.setProperty("performinglocation", ds.getColumnValues("performinglocation", ";"));
        prop.setProperty("receivinglocation", ds.getColumnValues("receivinglocation", ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
        }

    }

    /**
     * Description: This method is used for add instrument with the sample.
     *
     * @throws SapphireException
     * @author SB
     */
    private DataSet validateInstrument() throws SapphireException {
        // String currentuser = connectionInfo.getSysuserId();
        String defaulydepartment = connectionInfo.getDefaultDepartment();
        String site = StringUtil.split(defaulydepartment, "-")[0];
        String allTestCodes = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";",
                true);
        // String allsampleids =
        // Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID,
        // ";"), ";", true);

        DataSet dsInstrument = new DataSet();
        dsInstrument.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsInstrument.addColumn(DATASET_PROPERTY_LV_TEST_CODE, DataSet.STRING);
        dsInstrument.addColumn(DATASET_PROPERTY_INSTRUMENTTYPE, DataSet.STRING);
        dsInstrument.addColumn(DATASET_PROPERTY_IHCPROTOCOL, DataSet.STRING);
        String sqlSite = "select u_site from department where departmentid='" + defaulydepartment + "'";
        DataSet dsSite = getQueryProcessor().getSqlDataSet(sqlSite);
        site = dsSite.getValue(0, "u_site", "");
        String sql = "select tstsite.lvtestcodeid,tstsite.instrumentid,tstsite.sitename,tstsite.defaultinstrument,tstpr.testinstrusiteid,tstpr.protocolid,tstpr.defaultprotocol"
                + " from u_testinstruprotocol tstpr, u_testinstrusite tstsite where"
                + " tstpr.testinstrusiteid=tstsite.u_testinstrusiteid"
                + " and tstpr.defaultprotocol = tstsite.defaultinstrument" + " and tstsite.lvtestcodeid in('"
                + StringUtil.replaceAll(allTestCodes, ";", "','") + "')" + " and tstsite.sitename='" + site + "'";
        DataSet dsInstrumentDtls = getQueryProcessor().getSqlDataSet(sql);
        if (dsInstrumentDtls == null || dsInstrumentDtls.size() == 0) {
            return dsInstrument;
        }

        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            HashMap<String, String> hmm = new HashMap<String, String>();
            hmm.put("lvtestcodeid", dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
            DataSet dsFilterInstrument = dsInstrumentDtls.getFilteredDataSet(hmm);
            if (dsFilterInstrument.size() > 1) {
                logger.info("Msg", "Multiple default instrument attached with testcode(s): "
                        + dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
                return dsInstrument;
            }
            String instrument = dsFilterInstrument.getValue(0, "instrumentid", "");
            String protocolid = dsFilterInstrument.getValue(0, "protocolid", "");
            String testcodeid = dsFilterInstrument.getValue(0, "lvtestcodeid", "");
            if (dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "").equalsIgnoreCase(testcodeid)) {
                HashMap<String, String> hm = new HashMap<String, String>();
                hm.put(DATASET_PROPERTY_LV_TEST_CODE, testcodeid);
                DataSet dsFilter = dsFinal.getFilteredDataSet(hm);
                if (dsFilter != null && dsFilter.size() > 0) {
                    for (int p = 0; p < dsFilter.size(); p++) {
                        int rowID = dsInstrument.addRow();
                        dsInstrument.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                                dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
                        dsInstrument.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE,
                                dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
                        dsInstrument.setValue(rowID, DATASET_PROPERTY_INSTRUMENTTYPE, instrument);
                        dsInstrument.setValue(rowID, DATASET_PROPERTY_IHCPROTOCOL, protocolid);
                    }
                }
            }
        }

        return dsInstrument;
    }

    private void setInstrument(DataSet dsIntru) throws SapphireException {
        String sampleid = Util.getUniqueList(dsIntru.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        String testcodes = Util.getUniqueList(dsIntru.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true);
        String sql = "select u_sampletestcodemapid from u_sampletestcodemap where s_sampleid in('"
                + StringUtil.replaceAll(sampleid, ";", "','") + "') and lvtestcodeid in" + " ('"
                + StringUtil.replaceAll(testcodes, ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeMap");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sampletestcodemapid", ";"));
        prop.setProperty("instrumenttype", dsIntru.getColumnValues(DATASET_PROPERTY_INSTRUMENTTYPE, ";"));
        prop.setProperty("ihcprotocol", dsIntru.getColumnValues(DATASET_PROPERTY_IHCPROTOCOL, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception es) {
            logger.info("msg", "Failed to add instrument");
            return;
        }

    }

    /**
     * Description: This method is used for add workitem
     *
     * @throws SapphireException
     * @author SB
     */
    private void applyWorkItem() throws SapphireException {
        HashMap<String, String> hmFilter = new HashMap<String, String>();
        hmFilter.put(DATASET_PROPERTY_APPLY_WI, "Y");
        DataSet dsFinalWithApplyWI = dsFinal.getFilteredDataSet(hmFilter);
        if (dsFinalWithApplyWI == null || dsFinalWithApplyWI.size() == 0) {
            return;
        }

        String alltestcodeIDs = Util
                .getUniqueList(dsFinalWithApplyWI.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true);

        String sql = "select t.u_testcodeid,w.workitemid,w.workitemversionid from workitem w, u_testcode t where"
                + " w.workitemid = t.testname and t.u_testcodeid in('"
                + StringUtil.replaceAll(alltestcodeIDs, ";", "','") + "')";
        DataSet dsWorkItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsWorkItem.size() == 0) {
            String errStr = "No work items found for below testcode(s)" + alltestcodeIDs;
            logger.error(errStr);
            return; // don't need to throw error
        }
        // CHECK WORKITEMITEM, PARAMLIST, PARAMLISTITEM
        sql = "select distinct t.u_testcodeid,w.workitemid,w.workitemversionid from workitem w, u_testcode t,workitemitem witm,paramlist pl,paramlistitem plitm where"
                + " w.workitemid = t.testname" + " and w.workitemid = witm.workitemid"
                + " and witm.workitemid = t.testname" + " and pl.paramlistid = witm.workitemid"
                + " and plitm.paramlistid = pl.paramlistid" + " and t.u_testcodeid in('"
                + StringUtil.replaceAll(alltestcodeIDs, ";", "','") + "')";
        DataSet dsWorkItemItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItemItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (!dsFinalWithApplyWI.isValidColumn("workitemidexists")) {
            dsFinalWithApplyWI.addColumn("workitemidexists", DataSet.STRING);//
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsFinalWithApplyWI.getRowCount(); i++) {
            hm.clear();
            hm.put("u_testcodeid", dsFinalWithApplyWI.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));

            DataSet dsFilter = dsWorkItem.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                dsFinalWithApplyWI.setValue(i, DATASET_PROPERTY_WORK_ITEM_ID, dsFilter.getValue(0, "workitemid", ""));
                dsFinalWithApplyWI.setValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID,
                        dsFilter.getValue(0, "workitemversionid", ""));
                dsFinalWithApplyWI.setValue(i, "workitemidexists", "Y");
            }
            hm.clear();
            hm.put("u_testcodeid", dsFinalWithApplyWI.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
            DataSet dsWorkItemItemFilter = dsWorkItemItem.getFilteredDataSet(hm);
            if (dsWorkItemItemFilter != null && dsWorkItemItemFilter.size() > 0) {
                dsFinalWithApplyWI.setValue(i, DATASET_PROPERTY_WORK_ITEM_ID, dsFilter.getValue(0, "workitemid", ""));
                dsFinalWithApplyWI.setValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID,
                        dsFilter.getValue(0, "workitemversionid", ""));
                dsFinalWithApplyWI.setValue(i, "workitemidexists", "Y");
            } else {
                dsFinalWithApplyWI.setValue(i, DATASET_PROPERTY_WORK_ITEM_ID, dsFilter.getValue(0, "workitemid", ""));
                dsFinalWithApplyWI.setValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID,
                        dsFilter.getValue(0, "workitemversionid", ""));
                dsFinalWithApplyWI.setValue(i, "workitemidexists", "N");
            }
        }

        DataSet dsApplyWI = new DataSet();
        dsApplyWI.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsApplyWI.addColumn("workitemidexists", DataSet.STRING);
        dsApplyWI.addColumn(DATASET_PROPERTY_WORK_ITEM_ID, DataSet.STRING);
        dsApplyWI.addColumn(DATASET_PROPERTY_WORK_ITEM_VERSION_ID, DataSet.STRING);
        for (int i = 0; i < dsFinalWithApplyWI.size(); i++) {
            String workitemid = dsFinalWithApplyWI.getValue(i, DATASET_PROPERTY_WORK_ITEM_ID, "");
            if (!Util.isNull(workitemid)) {
                int rowId = dsApplyWI.addRow();
                dsApplyWI.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID, dsFinalWithApplyWI.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsApplyWI.setValue(rowId, "workitemidexists", dsFinalWithApplyWI.getValue(i, "workitemidexists", ""));
                dsApplyWI.setValue(rowId, DATASET_PROPERTY_WORK_ITEM_ID, dsFinalWithApplyWI.getValue(i, DATASET_PROPERTY_WORK_ITEM_ID, ""));
                dsApplyWI.setValue(rowId, DATASET_PROPERTY_WORK_ITEM_VERSION_ID, dsFinalWithApplyWI.getValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID, ""));
            }
        }
        if (dsApplyWI != null && dsApplyWI.size() > 0) {
            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Sample");
            propswi.setProperty("keyid1", dsApplyWI.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
            propswi.setProperty("applyworkitem", dsApplyWI.getColumnValues("workitemidexists", ";"));
            propswi.setProperty("workitemid", dsApplyWI.getColumnValues(DATASET_PROPERTY_WORK_ITEM_ID, ";"));
            propswi.setProperty("workitemversionid", dsApplyWI.getColumnValues(DATASET_PROPERTY_WORK_ITEM_VERSION_ID, ";"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
        // APPLY SPEC WITH SAMPLE
        //addSpecWithSample(dsFinalWithApplyWI);
        addSpecWithSample(dsFinalWithApplyWI);
    }

    private void applyPanelWorkItemSolid() throws SapphireException {
        if (!dsFinal.isValidColumn("isslide"))
            dsFinal.addColumn("isslide", DataSet.STRING);
        for (int i = 0; i < dsFinal.size(); i++) {
            String u_type = dsFinal.getValue(i, "u_type", "");
            if (Util.isNull(u_type) || "EB".equalsIgnoreCase(u_type))
                dsFinal.setValue(i, "isslide", "N");
            else
                dsFinal.setValue(i, "isslide", "Y");
        }
        DataSet dsPanel = new DataSet();
        dsPanel.addColumn("lvtestpanelid", DataSet.STRING);
        dsPanel.addColumn("s_sampleid", DataSet.STRING);
        dsPanel.addColumn("u_clientspecimenid", DataSet.STRING);
        dsPanel.addColumn("u_accessionid", DataSet.STRING);
        HashMap<String, String> hmFilter = new HashMap<String, String>();
        hmFilter.put("isslide", "N");
        hmFilter.put(DATASET_PROPERTY_IS_PANEL, "Y");
        hmFilter.put(DATASET_PROPERTY_METHODOLOGY, "IHC");
        DataSet dsIsPanel = dsFinal.getFilteredDataSet(hmFilter);
        if (dsIsPanel == null || dsIsPanel.size() == 0) {
            return;
        }
        if (!dsIsPanel.isValidColumn("u_rootsampleid"))
            dsIsPanel.addColumn("u_rootsampleid", DataSet.STRING);
        if (!dsIsPanel.isValidColumn("u_clientspecimenid"))
            dsIsPanel.addColumn("u_clientspecimenid", DataSet.STRING);
        if (!dsIsPanel.isValidColumn("u_accessionid"))
            dsIsPanel.addColumn("u_accessionid", DataSet.STRING);

        String allsampleIDs = Util.getUniqueList(dsIsPanel.getColumnValues("s_sampleid", ";"), ";", true);

        String sampleids = StringUtil.replaceAll(allsampleIDs, ";", "','");
        String sql = Util.parseMessage(ApSql.GET_SAMPLEINFO_BY_SAMPLEID, sampleids);
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

        for (int i = 0; i < dsIsPanel.size(); i++) {
            String s_sampleid = dsIsPanel.getValue(i, INPUT_PROPERTY_SAMPLE_ID);
            hmFilter.clear();
            hmFilter.put("s_sampleid", s_sampleid);
            DataSet dsFilter = dsSampleInfo.getFilteredDataSet(hmFilter);
            String rootsample = dsFilter.getValue(0, "u_rootsample");
            String u_clientspecimenid = dsFilter.getValue(0, "u_clientspecimenid");
            String u_accessionid = dsFilter.getValue(0, "u_accessionid");

            dsIsPanel.setValue(i, "u_rootsampleid", rootsample);
            dsIsPanel.setValue(i, "u_clientspecimenid", u_clientspecimenid);
            dsIsPanel.setValue(i, "u_accessionid", u_accessionid);
        }

        dsIsPanel.sort("u_rootsampleid,lvtestpanelid");
        ArrayList<DataSet> dsLVPanel = dsIsPanel.getGroupedDataSets("u_rootsampleid,lvtestpanelid");
        if (dsLVPanel != null && dsLVPanel.size() > 0) {
            for (int i = 0; i < dsLVPanel.size(); i++) {
                DataSet temDs = (DataSet) dsLVPanel.get(i);
                int rowID = dsPanel.addRow();
                dsPanel.setValue(rowID, "s_sampleid", Util.getUniqueList(temDs.getColumnValues("u_rootsampleid", ";"), ";", true));
                dsPanel.setValue(rowID, "u_accessionid", Util.getUniqueList(temDs.getColumnValues("u_accessionid", ";"), ";", true));
                dsPanel.setValue(rowID, "u_clientspecimenid", Util.getUniqueList(temDs.getColumnValues("u_clientspecimenid", ";"), ";", true));
                dsPanel.setValue(rowID, "lvtestpanelid", Util.getUniqueList(temDs.getColumnValues("lvtestpanelid", ";"), ";", true));
            }
        }
        DataSet dsClientSpecError = new DataSet();
        dsClientSpecError.addColumn("accession_id", DataSet.STRING);
        dsClientSpecError.addColumn("specimen_id", DataSet.STRING);
        dsClientSpecError.addColumn("client_specimen_id", DataSet.STRING);
        for (int i = 0; i < dsPanel.size(); i++) {
            String u_accessionid = dsPanel.getValue(i, "u_accessionid", "");
            String u_clientspecimenid = dsPanel.getValue(i, "u_clientspecimenid", "");
            String s_sampleid = dsPanel.getValue(i, "s_sampleid", "");
            if (Util.isNull(u_clientspecimenid)) {
                int rowID = dsClientSpecError.addRow();
                dsClientSpecError.setValue(rowID, "accession_id", u_accessionid);
                dsClientSpecError.setValue(rowID, "specimen_id", s_sampleid);
                dsClientSpecError.setValue(rowID, "client_specimen_id", u_clientspecimenid);
            }
        }
        //TODO VALIDATE CLIENT SPECIMEN ID FOR BLOCK AS WELL
        if (dsClientSpecError != null && dsClientSpecError.size() > 0) {
            String errorCode = Util.getDisplayMessage("Block(s) must have client specimen id.", dsClientSpecError);
            throw new SapphireException(errorCode);
        }
        if (!dsPanel.isValidColumn("panelworkitem"))
            dsPanel.addColumn("panelworkitem", DataSet.STRING);
        String alltestcodeIDs = Util.getUniqueList(dsPanel.getColumnValues("lvtestpanelid", ";"), ";", true);
        sql = Util.parseMessage(ApSql.GET_PANEL_NAME_BY_PANELID, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsLvPanelDetails = getQueryProcessor().getSqlDataSet(sql);
        for (int i = 0; i < dsPanel.size(); i++) {
            String lvpanelid = dsPanel.getValue(i, "lvtestpanelid");
            hmFilter.clear();
            hmFilter.put("u_testcodeid", lvpanelid);
            DataSet dsPanelFilter = dsLvPanelDetails.getFilteredDataSet(hmFilter);
            if (dsPanelFilter.size() > 0) {
                String panelname = dsPanelFilter.getValue(0, "testname", "");
                dsPanel.setValue(i, "panelworkitem", panelname);
            }
        }
        sql = Util.parseMessage(ApSql.GET_WORKITEM_BY_TEST, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsWorkItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsWorkItem.size() == 0) {
            String errStr = "No work items found for below testcode(s)" + alltestcodeIDs;
            logger.error(errStr);
            return; // don't need to throw error
        }
        // CHECK WORKITEMITEM, PARAMLIST, PARAMLISTITEM
        sql = Util.parseMessage(ApSql.GET_WORKITEMITEM_BY_TEST, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsWorkItemItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItemItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (!dsPanel.isValidColumn("isapplyworkitem"))
            dsPanel.addColumn("isapplyworkitem", DataSet.STRING);
        if (!dsPanel.isValidColumn("workitemversionid"))
            dsPanel.addColumn("workitemversionid", DataSet.STRING);

        for (int i = 0; i < dsPanel.size(); i++) {
            hmFilter.clear();
            hmFilter.put("workitemid", dsPanel.getValue(i, "panelworkitem"));
            DataSet dsWorkItemFilter = dsWorkItem.getFilteredDataSet(hmFilter);
            if (dsWorkItemFilter.size() > 0) {
                dsPanel.setValue(i, "workitemversionid", dsWorkItemFilter.getValue(0, "workitemversionid"));
            }
            hmFilter.clear();
            hmFilter.put("workitemid", dsPanel.getValue(i, "panelworkitem"));
            DataSet dsApplyWorkItemFilter = dsWorkItemItem.getFilteredDataSet(hmFilter);
            if (dsApplyWorkItemFilter.size() > 0) {
                dsPanel.setValue(i, "isapplyworkitem", "Y");
            }
        }
        if (dsPanel != null && dsPanel.size() > 0) {
            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Accession");
            propswi.setProperty("keyid1", dsPanel.getColumnValues("u_accessionid", ";"));
            propswi.setProperty("keyid2", dsPanel.getColumnValues("u_clientspecimenid", ";"));
            propswi.setProperty("keyid3", dsPanel.getColumnValues("s_sampleid", ";"));
            propswi.setProperty("applyworkitem", dsPanel.getColumnValues("isapplyworkitem", ";"));
            propswi.setProperty("workitemid", dsPanel.getColumnValues("panelworkitem", ";"));
            propswi.setProperty("workitemversionid", dsPanel.getColumnValues("workitemversionid", ";"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed.AddWorkitem for Solid specimen") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }

    /**
     * Description: This method is used for add steps for IHC only. It will
     * filter final dataset which methodology is IHC.
     *
     * @throws SapphireException
     * @author SB
     */

    private void addIHCSteps() throws SapphireException {
        DataSet dsTestCodeSteps = new DataSet();
        dsTestCodeSteps.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsTestCodeSteps.addColumn(DATASET_PROPERTY_LV_TEST_CODE, DataSet.STRING);
        dsTestCodeSteps.addColumn("stepname", DataSet.STRING);
        dsTestCodeSteps.addColumn("stepno", DataSet.STRING);
        dsTestCodeSteps.addColumn("currentmovementstep", DataSet.STRING);
        dsTestCodeSteps.addColumn("backwardflag", DataSet.STRING);

        HashMap<String, String> hm = new HashMap<String, String>();
        hm.clear();
        hm.put("methodology", "IHC"); // TODO add DATASET_PRPPERTY
        DataSet dsFilterIHCOnly = dsFinal.getFilteredDataSet(hm);
        if (dsFilterIHCOnly == null || dsFilterIHCOnly.size() == 0) {
            hm.clear();
            hm.put("methodology", "Multiomyx");
            dsFilterIHCOnly = dsFinal.getFilteredDataSet(hm);
        }
         /* 20th Dec 2017 - Change by subhendu  Flow Change ++*/
        if (dsFilterIHCOnly == null || dsFilterIHCOnly.size() == 0) {
            hm.clear();
            hm.put("methodology", "Flow");
            dsFilterIHCOnly = dsFinal.getFilteredDataSet(hm);
        }
        if (dsFilterIHCOnly == null || dsFilterIHCOnly.size() == 0) {
            hm.clear();
            hm.put("methodology", "Generic");
            dsFilterIHCOnly = dsFinal.getFilteredDataSet(hm);
        }
         /* 20th Dec 2017 - Change by subhendu  Flow Change --*/
        if (dsFilterIHCOnly == null || dsFilterIHCOnly.size() == 0) {
            return;
        }
        String ihcTestCodes = StringUtil.replaceAll(
                Util.getUniqueList(dsFilterIHCOnly.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true), ";",
                "','");
        String sql = Util.parseMessage(ApSql.GET_IHCTESTCODESTEPS, ihcTestCodes);
        DataSet dsStepDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsStepDetails == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsStepDetails.size() == 0) {
            return;
        }

        if (!dsFilterIHCOnly.isValidColumn("stepexists")) {
            dsFilterIHCOnly.addColumn("stepexists", DataSet.STRING);
        }
        if (!dsFilterIHCOnly.isValidColumn("stepno")) { // This will be #
            // seperated >> never
            // delete this comment
            dsFilterIHCOnly.addColumn("stepno", DataSet.STRING);
        }
        if (!dsFilterIHCOnly.isValidColumn("stepname")) { // This will be #
            // seperated >>
            // never delete this
            // comment
            dsFilterIHCOnly.addColumn("stepname", DataSet.STRING);
        }
        if (!dsFilterIHCOnly.isValidColumn("currentmovementstep")) {
            dsFilterIHCOnly.addColumn("currentmovementstep", DataSet.STRING);
        }
        if (!dsFilterIHCOnly.isValidColumn("backwardflag")) {
            dsFilterIHCOnly.addColumn("backwardflag", DataSet.STRING);
        }

        for (int i = 0; i < dsFilterIHCOnly.getRowCount(); i++) {
            String lvtestcode = dsFilterIHCOnly.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            hm.clear();
            hm.put("u_testcodeid", lvtestcode);

            DataSet dsFilter = dsStepDetails.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                dsFilterIHCOnly.setValue(i, "stepexists", "Y");
                dsFilterIHCOnly.setValue(i, "stepname", dsFilter.getColumnValues("stepname", "#"));
                dsFilterIHCOnly.setValue(i, "stepno", dsFilter.getColumnValues("stepno", "#"));
                dsFilterIHCOnly.setValue(i, "currentmovementstep",
                        dsFilter.getColumnValues("currentmovementstep", "#"));
                dsFilterIHCOnly.setValue(i, "backwardflag", dsFilter.getColumnValues("backwardflag", "#"));
            }
        }
        hm.clear();
        hm.put("stepexists", "Y");
        DataSet dsFinalFilter = dsFilterIHCOnly.getFilteredDataSet(hm);
        for (int i = 0; i < dsFinalFilter.getRowCount(); i++) {
            String stepname[] = StringUtil.split(dsFinalFilter.getValue(i, "stepname", ""), "#");
            String stepno[] = StringUtil.split(dsFinalFilter.getValue(i, "stepno", ""), "#");
            String currentstep[] = StringUtil.split(dsFinalFilter.getValue(i, "currentmovementstep", ""), "#");
            String backwardflag[] = StringUtil.split(dsFinalFilter.getValue(i, "backwardflag", ""), "#");

            for (int j = 0; j < stepname.length; j++) {
                int rowID = dsTestCodeSteps.addRow();
                dsTestCodeSteps.setValue(rowID, DATASET_PROPERTY_SAMPLE_ID,
                        dsFinalFilter.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
                dsTestCodeSteps.setValue(rowID, DATASET_PROPERTY_LV_TEST_CODE,
                        dsFinalFilter.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
                dsTestCodeSteps.setValue(rowID, "stepname", stepname[j]);
                dsTestCodeSteps.setValue(rowID, "stepno", stepno[j]);
                dsTestCodeSteps.setValue(rowID, "currentmovementstep", currentstep[j]);
                dsTestCodeSteps.setValue(rowID, "backwardflag", backwardflag[j]);
            }
        }

        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
        prop.setProperty("s_sampleid", dsTestCodeSteps.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
        prop.setProperty("lvtestcode", dsTestCodeSteps.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"));
        prop.setProperty("stepname", dsTestCodeSteps.getColumnValues("stepname", ";"));
        prop.setProperty("stepno", dsTestCodeSteps.getColumnValues("stepno", ";"));
        prop.setProperty("status", StringUtil.repeat("Pending", dsTestCodeSteps.size(), ";"));
        prop.setProperty("copies", "" + dsTestCodeSteps.size());
        prop.setProperty("currentmovementstep", dsTestCodeSteps.getColumnValues("currentmovementstep", ";"));
        prop.setProperty("isbackwardallowed", dsTestCodeSteps.getColumnValues("backwardflag", ";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("error >>  ");
            error += ex.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * Description: This method is used for adding specification with samples.
     *
     * @param dsFinalWithApplyWI
     * @throws SapphireException
     */
    private void addSpecWithSample(DataSet dsFinalWithApplyWI) throws SapphireException {
        HashMap<String, String> hm = new HashMap<String, String>();
        DataSet dsSpecDetails = new DataSet();
        dsSpecDetails.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsSpecDetails.addColumn(DATASET_PROPERTY_SPEC_ID, DataSet.STRING);
        dsSpecDetails.addColumn(DATASET_PROPERTY_SPEC_VERSION_ID, DataSet.STRING);
        dsSpecDetails.addColumn("isduplicate", DataSet.STRING);

        // ------------------------APPLY SDI SPEC WITH
        // SAMPLE---------------------------/
        String uniqueWorkitemid = Util
                .getUniqueList(dsFinalWithApplyWI.getColumnValues(DATASET_PROPERTY_WORK_ITEM_ID, ";"), ";", true);
        String sql = "select specid,specversionid from spec where specid in('"
                + StringUtil.replaceAll(uniqueWorkitemid, ";", "','") + "')";
        DataSet dsSpec = getQueryProcessor().getSqlDataSet(sql);
        if (dsSpec != null && dsSpec.size() != 0) {
            for (int i = 0; i < dsSpec.size(); i++) {
                String specid = dsSpec.getValue(i, "specid", "");
                String specversionid = dsSpec.getValue(i, "specversionid", "");
                hm.clear();
                hm.put(DATASET_PROPERTY_WORK_ITEM_ID, specid);
                DataSet dsFilter = dsFinalWithApplyWI.getFilteredDataSet(hm);
                if (dsFilter != null && dsFilter.size() != 0) {
                    String uniqueSampleid[] = StringUtil.split(
                            Util.getUniqueList(dsFilter.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true),
                            ";");
                    for (int k = 0; k < uniqueSampleid.length; k++) {
                        hm.clear();
                        hm.put(DATASET_PROPERTY_SAMPLE_ID, uniqueSampleid[k]);
                        hm.put(DATASET_PROPERTY_WORK_ITEM_ID, specid);
                        DataSet dsFilterFinal = dsFilter.getFilteredDataSet(hm);
                        for (int j = 0; j < dsFilterFinal.size(); j++) {
                            int rowId = dsSpecDetails.addRow();
                            if (j == 0) {
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID,
                                        dsFilterFinal.getValue(j, DATASET_PROPERTY_SAMPLE_ID, ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_ID,
                                        dsFilterFinal.getValue(j, DATASET_PROPERTY_WORK_ITEM_ID, ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_VERSION_ID, specversionid);
                                dsSpecDetails.setValue(rowId, "isduplicate", "N");
                            } else {
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID,
                                        dsFilterFinal.getValue(j, DATASET_PROPERTY_SAMPLE_ID, ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_ID,
                                        dsFilterFinal.getValue(j, DATASET_PROPERTY_WORK_ITEM_ID, ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_VERSION_ID, specversionid);
                                dsSpecDetails.setValue(rowId, "isduplicate", "Y");
                            }
                        }
                    }
                }
            }

            hm.clear();
            hm.put("isduplicate", "N");
            DataSet dsFilter = dsSpecDetails.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                PropertyList prop = new PropertyList();
                prop.setProperty(AddSDISpec.PROPERTY_SDCID, "Sample");
                prop.setProperty(AddSDISpec.PROPERTY_KEYID1, dsFilter.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
                prop.setProperty("specid",
                        Util.getUniqueList(dsFilter.getColumnValues(DATASET_PROPERTY_SPEC_ID, ";"), ";", true));
                prop.setProperty("specversionid",
                        Util.getUniqueList(dsFilter.getColumnValues(DATASET_PROPERTY_SPEC_VERSION_ID, ";"), ";", true));
                try {
                    getActionProcessor().processAction(AddSDISpec.ID, AddSDISpec.VERSIONID, prop);
                } catch (ActionException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed.AddSDISpec ") + e.getMessage();
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }
            }
        }
    }

    /**
     * Description: This method is used for update SampleUType from B to U only.
     *
     * @throws SapphireException
     * @author SB
     */
    private void updateSampleSlideType() throws SapphireException {
        DataSet dsBackUpInfo = new DataSet();
        dsBackUpInfo.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsBackUpInfo.addColumn(DATASET_PROPERTY_SAMPLE_TYPE_ID, DataSet.STRING);
        String sampleids = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        String sql = "select stp.u_sampletestcodemapid,s.s_sampleid,s.u_type,s.u_currentmovementstep from s_sample s, u_sampletestcodemap stp where"
                + " s.s_sampleid= stp.s_sampleid and s.u_type='B' and s.s_sampleid in('"
                + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        DataSet dsUType = getQueryProcessor().getSqlDataSet(sql);
        // IF test code added to the backup slide please turn backup slides to
        // unstained slide
        if (dsUType != null && dsUType.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, dsUType.getColumnValues("s_sampleid", ";"));
            pl.setProperty("u_type", StringUtil.repeat("U", dsUType.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            pl.clear();
            pl.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            pl.setProperty(DeleteSDI.PROPERTY_KEYID1, dsUType.getColumnValues("u_sampletestcodemapid", ";"));
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, pl);
        }
    }

    /**
     * This functin will change the USS to backup slide if backup testcode is
     * added.
     *
     * @throws SapphireException
     */
    private void updateUSSToBackup_old_till_1_3_1() throws SapphireException {
        String allTestCode = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true);
        // Query for Backup testcodes
        String sqlBackupTestcode = "select u_testcodeid lvtestcodeid, backupflag"
                + " from u_testcode where backupflag = 'Y' and u_testcodeid in ('"
                + StringUtil.replaceAll(allTestCode, ";", "','") + "')";
        DataSet dsBackupTestCode = getQueryProcessor().getSqlDataSet(sqlBackupTestcode);
        if (dsBackupTestCode.size() == 0) {
            return;
        }
        // if any backup test is there among "allTestCode"
        HashMap<String, String> hmFinal = new HashMap<String, String>();
        DataSet dsNewAllBackup = new DataSet();
        dsNewAllBackup.addColumn("sampleid", DataSet.STRING);
        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            String dsFinalSampleID = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String dsFinalLVTestCodeId = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            hmFinal.clear();
            hmFinal.put(DATASET_PROPERTY_LV_TEST_CODE, dsFinalLVTestCodeId);
            DataSet dsBackupTestExist = dsBackupTestCode.getFilteredDataSet(hmFinal);
            if (dsBackupTestExist != null && dsBackupTestExist.size() > 0) {
                int rowid = dsNewAllBackup.addRow();
                dsNewAllBackup.setValue(rowid, "sampleid", dsFinalSampleID);
            }
        }
        if (dsNewAllBackup != null && dsNewAllBackup.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty("keyid1", dsNewAllBackup.getColumnValues("sampleid", ";"));
            pl.setProperty("u_type", StringUtil.repeat("B", dsNewAllBackup.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
    }

    private void updateUSSToBackup() throws SapphireException {
        String allTestCode = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";", true);
        String allSamples = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        // Query for Backup testcodes
        String sqlBackupTestcode = Util.parseMessage(CommonSql.GET_BACKUP_TESTCODES, StringUtil.replaceAll(allTestCode, ";", "','"));
        DataSet dsBackupTestCode = getQueryProcessor().getSqlDataSet(sqlBackupTestcode);
        if (dsBackupTestCode.size() == 0) {
            return;
        }
        String sqlSlideType = Util.parseMessage(CommonSql.GET_SLIDE_TYPE_BY_SAMPLEID, StringUtil.replaceAll(allSamples, ";", "','"));
        DataSet dsSlideTypes = getQueryProcessor().getSqlDataSet(sqlSlideType);

        // if any backup test is there among "allTestCode"
        HashMap<String, String> hmFinal = new HashMap<String, String>();
        DataSet dsNewAllBackup = new DataSet();
        dsNewAllBackup.addColumn("sampleid", DataSet.STRING);
        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            String dsFinalSampleID = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String dsFinalLVTestCodeId = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            hmFinal.clear();
            hmFinal.put(DATASET_PROPERTY_LV_TEST_CODE, dsFinalLVTestCodeId);
            DataSet dsBackupTestExist = dsBackupTestCode.getFilteredDataSet(hmFinal);
            //TODO BACKUP WILL BE APPLICABLE ONLY FOR SLIDE(S)
            hmFinal.clear();
            hmFinal.put(DATASET_PROPERTY_SAMPLE_ID, dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
            DataSet dsSlideFilter = dsSlideTypes.getFilteredDataSet(hmFinal);
            String u_type = dsSlideFilter.getValue(0, "u_type", "");

            if (dsBackupTestExist != null && dsBackupTestExist.size() > 0 && (!Util.isNull(u_type) && !"EB".equalsIgnoreCase(u_type))) {//TODO WILL OPEN THIS COMMENT SECTION FOR #16942(1.3.1 RELEASE)
                int rowid = dsNewAllBackup.addRow();
                dsNewAllBackup.setValue(rowid, "sampleid", dsFinalSampleID);
            }
        }
        if (dsNewAllBackup != null && dsNewAllBackup.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty("keyid1", dsNewAllBackup.getColumnValues("sampleid", ";"));
            pl.setProperty("u_type", StringUtil.repeat("B", dsNewAllBackup.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
    }

    /**
     * Description: This function used to get slide type and h&e flag of
     * sample(s) and test code(s).
     *
     * @throws SapphireException
     */
    private void updateSlideType() throws SapphireException {
        String allSampleIds = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        String allLVTestCodesIds = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";",
                true);
        // String sql = "select u_type,s_sampleid from s_sample where s_sampleid
        // in('" + StringUtil.replaceAll(allSampleIds, ";", "','") + "')";
        String sql = Util.parseMessage(MolecularSql.GET_U_TYPE_BY_SAMPLEID,
                StringUtil.replaceAll(allSampleIds, ";", "','"));
        DataSet dsSampleTypes = getQueryProcessor().getSqlDataSet(sql);
        // sql = "select u_testcodeid,nvl(hneflag,'N')hneflag from u_testcode
        // where u_testcodeid in('" + StringUtil.replaceAll(allLVTestCodesIds,
        // ";", "','") + "')";
        sql = Util.parseMessage(MolecularSql.GET_HNE_BY_TESTCODEID,
                StringUtil.replaceAll(allLVTestCodesIds, ";", "','"));
        DataSet dsHNEFlag = getQueryProcessor().getSqlDataSet(sql);
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_UTYPE)) {
            dsFinal.addColumn(DATASET_PROPERTY_UTYPE, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_ISHNEFLAG)) {
            dsFinal.addColumn(DATASET_PROPERTY_ISHNEFLAG, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG)) {
            dsFinal.addColumn(DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG)) {
            dsFinal.addColumn(DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG, DataSet.STRING);
        }
        for (int i = 0; i < dsFinal.size(); i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.clear();
            hm.put("s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID, ""));
            DataSet dsFilterSample = dsSampleTypes.getFilteredDataSet(hm);
            if (dsFilterSample != null && dsFilterSample.size() > 0) {
                dsFinal.setValue(i, DATASET_PROPERTY_UTYPE, dsFilterSample.getValue(0, DATASET_PROPERTY_UTYPE, ""));
            }
            hm.clear();
            hm.put("u_testcodeid", dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, ""));
            DataSet dsFilterHneFlag = dsHNEFlag.getFilteredDataSet(hm);
            if (dsFilterHneFlag != null && dsFilterHneFlag.size() > 0) {
                dsFinal.setValue(i, DATASET_PROPERTY_ISHNEFLAG,
                        dsFilterHneFlag.getValue(0, DATASET_PROPERTY_ISHNEFLAG, ""));
                dsFinal.setValue(i, DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG,
                        dsFilterHneFlag.getValue(0, DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG, ""));
                dsFinal.setValue(i, DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG,
                        dsFilterHneFlag.getValue(0, DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG, ""));
            }

        }
    }

    /***
     * Desc: Mark slide(s) as Initail/Repeat applied as per dod
     * @throws SapphireException
     */
    private void autoMarkInitialRepeat_old() throws SapphireException {
        if (dsFinal != null && dsFinal.size() > 0) {
            DataSet dsSpecialTestCodes = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "Initial or Repeat");
            if (dsSpecialTestCodes.size() > 0) {
                String specialtestcodes = dsSpecialTestCodes.getColumnValues("testcode", ";");
                String sampleid = dsFinal.getColumnValues("s_sampleid", ";");
                String sql = Util.parseMessage(ApSql.GET_SPECIMENS_BY_SPECIMEN_TESTCODE, StringUtil.replaceAll(sampleid, ";", "','"),
                        StringUtil.replaceAll(specialtestcodes, ";", "','"));
                DataSet dsSpecialTCInfo = getQueryProcessor().getSqlDataSet(sql);

                DataSet dsInitialRepeat = new DataSet();
                dsInitialRepeat.addColumn("s_sampleid", DataSet.STRING);
                dsInitialRepeat.addColumn("testname", DataSet.STRING);
                dsInitialRepeat.addColumn("markername", DataSet.STRING);
                for (int i = 0; i < dsFinal.size(); i++) {
                    HashMap hm = new HashMap();
                    hm.clear();
                    hm.put("s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                    hm.put("lvtestcodeid", dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE));
                    DataSet dsSpecialTcFilter = dsSpecialTCInfo.getFilteredDataSet(hm);
                    int rowId = dsInitialRepeat.addRow();
                    dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                    dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                    dsInitialRepeat.setValue(rowId, "markername", "Initial");
                }
                if (dsInitialRepeat != null && dsInitialRepeat.size() > 0) {
                    String inirepeatsample = Util.getUniqueList(dsInitialRepeat.getColumnValues("s_sampleid", ";"), ";", true);
                    inirepeatsample = StringUtil.replaceAll(inirepeatsample, ";", "','");
                    String inirepeatparamlistid = Util.getUniqueList(dsInitialRepeat.getColumnValues("testname", ";"), ";", true);
                    inirepeatparamlistid = StringUtil.replaceAll(inirepeatparamlistid, ";", "','");
                    String sqlenterdata = Util.parseMessage(ApSql.GET_ANALYTE_BY_SAMPLE_PARAM, inirepeatsample, inirepeatparamlistid);
                    DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
                    if (dsSqlEnterData.size() > 0) {
                        for (int i = 0; i < dsSqlEnterData.size(); i++) {
                            String entsampleid = dsSqlEnterData.getValue(i, "childsampleid", "");
                            String entparamid = dsSqlEnterData.getValue(i, "paramlistid", "");
                            HashMap hm = new HashMap();
                            hm.clear();
                            hm.put("s_sampleid", entsampleid);
                            hm.put("testname", entparamid);
                            DataSet dsSpecialTcFilter = dsInitialRepeat.getFilteredDataSet(hm);
                            if (dsSpecialTcFilter != null && dsSpecialTcFilter.size() > 0) {
                                dsSqlEnterData.setValue(i, "enteredtext", dsSpecialTcFilter.getValue(0, "markername"));
                                dsSqlEnterData.setValue(i, "displayvalue", dsSpecialTcFilter.getValue(0, "markername"));
                            }
                        }

                        PropertyList props = new PropertyList();
                        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                        props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                        props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("enteredtext", ";"));
                        props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("displayvalue", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                        props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                        try {
                            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                        } catch (SapphireException e) {
                            throw new SapphireException("Initial or Repeat rule not performed." + e.getMessage());
                        }
                    }
                }
            }
        }
    }

    private void autoMarkInitialRepeat_1_5_1() throws SapphireException {
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("methodology", "IHC");
        DataSet dsIHCFilter = dsFinal.getFilteredDataSet(hm);
        if (dsIHCFilter.size() == 0) {
            return;
        }
        if (dsFinal != null && dsFinal.size() > 0) {
            DataSet dsSpecialTestCodes = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "Initial or Repeat");
            if (dsSpecialTestCodes.size() > 0) {
                String specialtestcodes = dsSpecialTestCodes.getColumnValues("testcode", ";");
                String sampleid = dsFinal.getColumnValues("s_sampleid", ";");
                String sql = Util.parseMessage(ApSql.GET_ACCESSIONID_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
                DataSet dsAccession = getQueryProcessor().getSqlDataSet(sql);
                String accessionid = dsAccession.getValue(0, "u_accessionid");
                //String sql = Util.parseMessage(ApSql.GET_SPECIMENS_BY_SPECIMEN_TESTCODE, StringUtil.replaceAll(sampleid, ";", "','"),
                sql = Util.parseMessage(ApSql.GET_SPECIMENS_BY_ACCESSION_TESTCODE, accessionid, StringUtil.replaceAll(specialtestcodes, ";", "','"));
                DataSet dsSpecialTCInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsSpecialTCInfo.size() > 0) {
                    DataSet dsInitialRepeat = new DataSet();
                    dsInitialRepeat.addColumn("s_sampleid", DataSet.STRING);
                    dsInitialRepeat.addColumn("testname", DataSet.STRING);
                    dsInitialRepeat.addColumn("markername", DataSet.STRING);
                    if (dsFinal.size() == 1) {
                        for (int i = 0; i < dsFinal.size(); i++) {
                            hm.clear();
                            //hm.put("s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                            hm.put("u_accessionid", accessionid);
                            hm.put("lvtestcodeid", dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE));
                            DataSet dsSpecialTcFilter = dsSpecialTCInfo.getFilteredDataSet(hm);
                            if (dsSpecialTcFilter.size() == 1) {
                                int rowId = dsInitialRepeat.addRow();
                                dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                dsInitialRepeat.setValue(rowId, "markername", "Initial");
                            }
                            if (dsSpecialTcFilter.size() > 1) {
                                int rowId = dsInitialRepeat.addRow();
                                dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                dsInitialRepeat.setValue(rowId, "markername", "Repeat");
                            }

                        }
                    }
                    if (dsFinal.size() > 1) {
                        int count = 0;
                        for (int i = 0; i < dsFinal.size(); i++) {
                            hm.clear();
                            //hm.put("s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                            hm.put("u_accessionid", accessionid);
                            hm.put("lvtestcodeid", dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE));
                            DataSet dsSpecialTcFilter = dsSpecialTCInfo.getFilteredDataSet(hm);
                            if (dsSpecialTcFilter.size() == 1) {
                                int rowId = dsInitialRepeat.addRow();
                                dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                dsInitialRepeat.setValue(rowId, "markername", "Initial");
                            }
                            if (dsSpecialTcFilter.size() > 1) {
                                int rowId = dsInitialRepeat.addRow();
                                dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                dsInitialRepeat.setValue(rowId, "markername", "Repeat");
                            }
                            /*if (dsSpecialTcFilter.size() == dsFinal.size()) {
                                count++;
                                if (count == 1) {
                                    int rowId = dsInitialRepeat.addRow();
                                    dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                    dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                    dsInitialRepeat.setValue(rowId, "markername", "Initial");
                                } else {
                                    int rowId = dsInitialRepeat.addRow();
                                    dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                    dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                    dsInitialRepeat.setValue(rowId, "markername", "Repeat");
                                }
                            } else {
                                int rowId = dsInitialRepeat.addRow();
                                dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                                dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                                dsInitialRepeat.setValue(rowId, "markername", "Repeat");
                            }*/
                        }
                    }
                    if (dsInitialRepeat != null && dsInitialRepeat.size() > 0) {
                        String inirepeatsample = Util.getUniqueList(dsInitialRepeat.getColumnValues("s_sampleid", ";"), ";", true);
                        inirepeatsample = StringUtil.replaceAll(inirepeatsample, ";", "','");
                        String inirepeatparamlistid = Util.getUniqueList(dsInitialRepeat.getColumnValues("testname", ";"), ";", true);
                        inirepeatparamlistid = StringUtil.replaceAll(inirepeatparamlistid, ";", "','");
                        String sqlenterdata = Util.parseMessage(ApSql.GET_ANALYTE_BY_SAMPLE_PARAM, inirepeatsample, inirepeatparamlistid);
                        DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
                        if (dsSqlEnterData.size() > 0) {
                            for (int i = 0; i < dsSqlEnterData.size(); i++) {
                                String entsampleid = dsSqlEnterData.getValue(i, "childsampleid", "");
                                String entparamid = dsSqlEnterData.getValue(i, "paramlistid", "");
                                hm.clear();
                                hm.put("s_sampleid", entsampleid);
                                hm.put("testname", entparamid);
                                DataSet dsSpecialTcFilter = dsInitialRepeat.getFilteredDataSet(hm);
                                if (dsSpecialTcFilter != null && dsSpecialTcFilter.size() > 0) {
                                    dsSqlEnterData.setValue(i, "enteredtext", dsSpecialTcFilter.getValue(0, "markername"));
                                    dsSqlEnterData.setValue(i, "displayvalue", dsSpecialTcFilter.getValue(0, "markername"));
                                }
                            }

                            PropertyList props = new PropertyList();
                            props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                            props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                            props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("enteredtext", ";"));
                            props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("displayvalue", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                            props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                            try {
                                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                            } catch (SapphireException e) {
                                throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                            }
                        }
                    }
                }
            }
        }
    }

    /****
     * @Desc: This function is used to mark the slide as Initial or Repeat for Molecular.
     * @throws SapphireException
     */
    private void markedInitialOrRepeatMolecular(String ismolrepeatflag) throws SapphireException {
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("methodology", "Molecular");
        DataSet dsMolecularFilter = dsFinal.getFilteredDataSet(hm);
        if (dsMolecularFilter == null || dsMolecularFilter.size() == 0) {
            return;
        }
        if (dsMolecularFilter != null && dsMolecularFilter.size() > 0) {
            String sampleid = dsMolecularFilter.getColumnValues("s_sampleid", ";");
            String sql = Util.parseMessage(MolecularSql.GET_SDIDATA_INFO_BY_SAMPLE_MOLECULAR, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsSampleInfoAll = getQueryProcessor().getSqlDataSet(sql);
            if (dsSampleInfoAll == null || dsSampleInfoAll.size() == 0) {
                return;
            }
            if (dsSampleInfoAll != null && dsSampleInfoAll.size() > 0) {
                if (!dsSampleInfoAll.isValidColumn("molrepeatflag")) {
                    dsSampleInfoAll.addColumn("molrepeatflag", DataSet.STRING);
                }
                for (int i = 0; i < dsSampleInfoAll.size(); i++) {
                    if ("Y".equalsIgnoreCase(ismolrepeatflag)) {
                        dsSampleInfoAll.setValue(i, "molrepeatflag", "Repeat");
                    } else {
                        dsSampleInfoAll.setValue(i, "molrepeatflag", "Initial");
                    }
                }
                //ENTERED DATA
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSampleInfoAll.getColumnValues("s_sampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSampleInfoAll.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSampleInfoAll.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSampleInfoAll.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSampleInfoAll.getColumnValues("molrepeatflag", ";"));
                props.setProperty("displayvalue", dsSampleInfoAll.getColumnValues("molrepeatflag", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSampleInfoAll.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSampleInfoAll.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSampleInfoAll.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSampleInfoAll.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("Molecular EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }

    /***
     * RELEASE 1.6.1
     * @Desc: Same testcode(s) can be use at the time of accession and do microtomy for the block.
     */
    private void autoMarkInitialRepeat() throws SapphireException {
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("methodology", "IHC");
        DataSet dsIHCFilter = dsFinal.getFilteredDataSet(hm);
        if (dsIHCFilter.size() == 0) {
            return;
        }
        if (dsFinal != null && dsFinal.size() > 0) {
            String sampleid = dsFinal.getColumnValues("s_sampleid", ";");
            String sql = Util.parseMessage(ApSql.GET_ACCESSIONID_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsAccession = getQueryProcessor().getSqlDataSet(sql);
            //GET ACCESSION ID
            String accessionid = dsAccession.getValue(0, "u_accessionid");
            String lvtestcodeid = dsFinal.getColumnValues("lvtestcodeid", ";");
            //VALIDATE INITIAL OR REPEAT BY ACCESSION AND ASSOCIATED TESTCODE
            sql = Util.parseMessage(ApSql.GET_INITIAL_REPEAT_BY_ACCESSIONID_TC, accessionid, StringUtil.replaceAll(lvtestcodeid, ";", "','"));
            DataSet dsSpecialTCInfo = getQueryProcessor().getSqlDataSet(sql);
            //CHECK ALREADY VALUE ENTERED OR NOt
            hm.clear();
            hm.put("enteredtext", "Initial");
            DataSet dsChckData = dsSpecialTCInfo.getFilteredDataSet(hm);
            //WILL EXECUTE IF THERE ARE ANY TESTCOED ADDED HAVING INITIAL/REPEAT PARAMETER
            DataSet dsInitialRepeat = new DataSet();
            dsInitialRepeat.addColumn("accessionid", DataSet.STRING);
            dsInitialRepeat.addColumn("s_sampleid", DataSet.STRING);
            dsInitialRepeat.addColumn("testcodeid", DataSet.STRING);
            dsInitialRepeat.addColumn("testname", DataSet.STRING);
            dsInitialRepeat.addColumn("markername", DataSet.STRING);
            dsInitialRepeat.addColumn("hasinitailrepeat", DataSet.STRING);
            if (dsSpecialTCInfo.size() > 0) {
                for (int i = 0; i < dsFinal.size(); i++) {
                    String addedlvtestcodeid = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE);
                    hm.clear();
                    hm.put("u_accessionid", accessionid);
                    hm.put("lvtestcodeid", addedlvtestcodeid);
                    DataSet dsSpecialTcFilter = dsSpecialTCInfo.getFilteredDataSet(hm);
                    if (dsSpecialTcFilter.size() > 0) {
                        int rowId = dsInitialRepeat.addRow();
                        dsInitialRepeat.setValue(rowId, "accessionid", accessionid);
                        dsInitialRepeat.setValue(rowId, "s_sampleid", dsFinal.getValue(i, DATASET_PROPERTY_SAMPLE_ID));
                        dsInitialRepeat.setValue(rowId, "testcodeid", dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE));
                        dsInitialRepeat.setValue(rowId, "testname", dsSpecialTcFilter.getValue(0, "testname"));
                        dsInitialRepeat.setValue(rowId, "hasinitailrepeat", "Y");
                    }
                }
            }
            //FINAL DATASET FOR PERFORMING
            DataSet dsInitialRepeatFinal = new DataSet();
            dsInitialRepeatFinal.addColumn("accessionid", DataSet.STRING);
            dsInitialRepeatFinal.addColumn("s_sampleid", DataSet.STRING);
            dsInitialRepeatFinal.addColumn("testcodeid", DataSet.STRING);
            dsInitialRepeatFinal.addColumn("testname", DataSet.STRING);
            dsInitialRepeatFinal.addColumn("markername", DataSet.STRING);
            if (dsInitialRepeat.size() > 0) {
                hm.clear();
                hm.put("hasinitailrepeat", "Y");
                DataSet dsHasInitailFLag = dsInitialRepeat.getFilteredDataSet(hm);
                if (dsHasInitailFLag.size() > 0) {
                    dsHasInitailFLag.sort("accessionid,testcodeid");
                    ArrayList arraySubParentLos = dsHasInitailFLag.getGroupedDataSets("accessionid,testcodeid");
                    for (int i = 0; i < arraySubParentLos.size(); i++) {
                        DataSet dsEach = (DataSet) arraySubParentLos.get(i);
                        int count = 0;
                        for (int j = 0; j < dsEach.size(); j++) {
                            count++;
                            if (count == 1 && dsChckData.size() == 0) {
                                int rowID = dsInitialRepeatFinal.addRow();
                                dsInitialRepeatFinal.setValue(rowID, "accessionid", dsEach.getValue(j, "accessionid", ""));
                                dsInitialRepeatFinal.setValue(rowID, "s_sampleid", dsEach.getValue(j, "s_sampleid", ""));
                                dsInitialRepeatFinal.setValue(rowID, "testcodeid", dsEach.getValue(j, "testcodeid", ""));
                                dsInitialRepeatFinal.setValue(rowID, "testname", dsEach.getValue(j, "testname", ""));
                                dsInitialRepeatFinal.setValue(rowID, "markername", "Initial");
                            }
                            if ((count == 1 && dsChckData.size() > 0) || (count > 1 && dsChckData.size() == 0) || (count > 1 && dsChckData.size() > 0)) {
                                int rowID = dsInitialRepeatFinal.addRow();
                                dsInitialRepeatFinal.setValue(rowID, "accessionid", dsEach.getValue(j, "accessionid", ""));
                                dsInitialRepeatFinal.setValue(rowID, "s_sampleid", dsEach.getValue(j, "s_sampleid", ""));
                                dsInitialRepeatFinal.setValue(rowID, "testcodeid", dsEach.getValue(j, "testcodeid", ""));
                                dsInitialRepeatFinal.setValue(rowID, "testname", dsEach.getValue(j, "testname", ""));
                                dsInitialRepeatFinal.setValue(rowID, "markername", "Repeat");
                            }
                        }
                    }
                }
            }
            if (dsInitialRepeatFinal.size() > 0) {
                String inirepeatsample = Util.getUniqueList(dsInitialRepeatFinal.getColumnValues("s_sampleid", ";"), ";", true);
                inirepeatsample = StringUtil.replaceAll(inirepeatsample, ";", "','");
                String inirepeatparamlistid = Util.getUniqueList(dsInitialRepeatFinal.getColumnValues("testname", ";"), ";", true);
                inirepeatparamlistid = StringUtil.replaceAll(inirepeatparamlistid, ";", "','");
                String sqlenterdata = Util.parseMessage(ApSql.GET_ANALYTE_BY_SAMPLE_PARAM, inirepeatsample, inirepeatparamlistid);
                DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
                if (dsSqlEnterData.size() > 0) {
                    for (int i = 0; i < dsSqlEnterData.size(); i++) {
                        String entsampleid = dsSqlEnterData.getValue(i, "childsampleid", "");
                        String entparamid = dsSqlEnterData.getValue(i, "paramlistid", "");
                        hm.clear();
                        hm.put("s_sampleid", entsampleid);
                        hm.put("testname", entparamid);
                        DataSet dsSpecialTcFilter = dsInitialRepeatFinal.getFilteredDataSet(hm);
                        if (dsSpecialTcFilter != null && dsSpecialTcFilter.size() > 0) {
                            dsSqlEnterData.setValue(i, "enteredtext", dsSpecialTcFilter.getValue(0, "markername"));
                            dsSqlEnterData.setValue(i, "displayvalue", dsSpecialTcFilter.getValue(0, "markername"));
                        }
                    }

                    PropertyList props = new PropertyList();
                    props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                    props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                    props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("enteredtext", ";"));
                    props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("displayvalue", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                    try {
                        getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                    } catch (SapphireException e) {
                        throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                    }
                }
            }
        }
    }

    String COLUMNS_TEST_CODES = "testname;methodology;los;"
            + "nyapproval;heslides;unstainedslides;backupslides;testversion;clienttestcodeid;chimerismflag;"
            + "extractiontype;molecularsubmethodology;sampleload;concentrationratio;isnormal;isneotypepanel;molecularworkflow;optimalconcentration;fishprotocol";
    String COLUMNS_SAMPLE_TEST_CODES_MAP = "testname;methodology;los;"
            + "nyapproval;heslides;unstainedslides;backupslides;testversion;clienttestcodeid;chimerismflag;"
            + "extractiontype;molecularsubmethodology;sampleload;concentrationratio;isnormal;isneotypepanel;molecularworkflow;optimalconcentration;fishprotocol";

    String COLUMNS_PANEL_TEST_CODES = "isneotypepanel;molecularworkflow";
    String COLUMNS_PANEL_SAMPLE_TEST_CODES_MAP = "isneotypepanel;molecularworkflow";

    /*******************************************************************************************
     * Utilities ******************************
     *******************************************************************************************/
    private void setCopyDownProperties(String allTestCodes) throws SapphireException {
        String sql = "select u_testcodeid, " + StringUtil.replaceAll(COLUMNS_TEST_CODES, ";", ",")
                + " from u_testcode where u_testcodeid in ('" + StringUtil.replaceAll(allTestCodes, ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {

        }

        String[] columnTestCode = StringUtil.split(COLUMNS_TEST_CODES, ";");
        String[] columnTestCodeSampleMap = StringUtil.split(COLUMNS_SAMPLE_TEST_CODES_MAP, ";");
        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            String lvTestCodeID = dsFinal.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("u_testcodeid", lvTestCodeID);
            DataSet dsFilter = ds.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                for (int j = 0; j < columnTestCode.length; j++) {
                    if (!dsFinal.isValidColumn(columnTestCodeSampleMap[j])) {
                        dsFinal.addColumn(columnTestCodeSampleMap[j], DataSet.STRING);
                    }
                    dsFinal.setValue(i, columnTestCodeSampleMap[j], dsFilter.getValue(0, columnTestCode[j], ""));
                }

            }

        }
    }

    private void setCopyDownPanelProperties(String allPanelCodes) throws SapphireException {
        String sql = "select u_testcodeid, " + StringUtil.replaceAll(COLUMNS_PANEL_TEST_CODES, ";", ",")
                + " from u_testcode where u_testcodeid in ('" + StringUtil.replaceAll(allPanelCodes, ";", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {

        }

        String[] columnTestCode = StringUtil.split(COLUMNS_PANEL_TEST_CODES, ";");
        String[] columnTestCodeSampleMap = StringUtil.split(COLUMNS_PANEL_SAMPLE_TEST_CODES_MAP, ";");
        for (int i = 0; i < dsFinal.getRowCount(); i++) {
            String lvTestPanelCodeID = dsFinal.getValue(i, DATASET_PROPERTY_LV_PANEL_CODE, "");
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("u_testcodeid", lvTestPanelCodeID);
            DataSet dsFilter = ds.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                for (int j = 0; j < columnTestCode.length; j++) {
                    if (!dsFinal.isValidColumn(columnTestCodeSampleMap[j])) {
                        dsFinal.addColumn(columnTestCodeSampleMap[j], DataSet.STRING);
                    }
                    dsFinal.setValue(i, columnTestCodeSampleMap[j], dsFilter.getValue(0, columnTestCode[j], ""));
                }

            }

        }
    }

    private String setDefaultValueForNULL(String srcString, String defaultValue, int sampleidslength)
            throws SapphireException {
        String srcStringArray[] = StringUtil.split(srcString, ";");
        String finalStr = "";
        if (srcStringArray.length == sampleidslength) {
            for (String str : srcStringArray) {
                if ("".equalsIgnoreCase(str)) {
                    finalStr += ";" + defaultValue;
                } else {
                    finalStr += ";" + str;
                }
            }
            finalStr = finalStr.substring(1);
        } else {
            int count = 0;
            for (String str : srcStringArray) {
                count++;
                if ("".equalsIgnoreCase(str)) {
                    finalStr += ";" + defaultValue;
                } else {
                    finalStr += ";" + str;
                }
            }
            if (count < sampleidslength) {
                int position = sampleidslength - count;
                for (int i = 0; i < position; i++) {
                    finalStr += ";" + defaultValue;
                }
            }
            finalStr = finalStr.substring(1);
        }

        return finalStr;
    }

    /*******************************************************************************************
     * BASE DESIGN ******************************
     *******************************************************************************************/
    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "s_sampleid";
    private static final String DATASET_PROPERTY_LV_TEST_CODE = "lvtestcodeid";
    private static final String DATASET_PROPERTY_LV_PANEL_CODE = "lvtestpanelid";
    private static final String DATASET_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY = "applymethodology";// methodology
    // specific
    // apply
    // panel
    private static final String DATASET_PROPERTY_IS_PANEL = "ispanel";
    private static final String DATASET_PROPERTY_APPLY_WI = "workitemflag";
    private static final String DATASET_PROPERTY_WORK_ITEM_ID = "workitemid";
    private static final String DATASET_PROPERTY_WORK_ITEM_VERSION_ID = "workitemversionid";
    private static final String DATASET_PROPERTY_BYPASS_TRANSPORTTYPE = "bypass";
    private static final String DATASET_PROPERTY_ADDON_TEST = "testaddonflag"; // This
    // value
    // and
    // column
    // id
    // in
    // SDC
    // are
    // sames
    private static final String DATASET_PROPERTY_SAMPLE_TYPE_ID = "specimentypeid";
    private static final String DATASET_PROPERTY_TRANSPORT_TYPE_ID = "transporttypeid";
    private static final String DATASET_PROPERTY_RECEIVING_LOCATION = "receivinglocs";
    private static final String DATASET_PROPERTY_PERFORMING_LOCATION = "performingloc";
    private static final String DATASET_PROPERTY_INSTRUMENTTYPE = "instrumenttype";
    private static final String DATASET_PROPERTY_IHCPROTOCOL = "ihcprotocol";
    private static final String DATASET_PROPERTY_UTYPE = "u_type";
    private static final String DATASET_PROPERTY_ISHNEFLAG = "hneflag";
    private static final String DATASET_PROPERTY_ISPOSITIVECONTROL_FLAG = "poscontrolflag";
    private static final String DATASET_PROPERTY_ISNEGETIVECONTROL_FLAG = "negcontrolflag";
    private static final String DATASET_PROPERTY_ISDUMMY = "isdummy";
    private static final String DATASET_PROPERTY_METHODOLOGY = "methodology";

    public static final String INPUT_PROPERTY_SAMPLE_ID = "s_sampleid";
    public static final String INPUT_PROPERTY_LV_TEST_CODE = "lvtestcode";
    public static final String INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY = "applymethodology";// methodology
    // specific
    // apply
    // panel
    public static final String INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE = "panelassociatedwithtestcode";// panel
    // for
    // testcode
    public static final String INPUT_PROPERTY_IS_PANEL = DATASET_PROPERTY_IS_PANEL;
    public static final String INPUT_PROPERTY_IS_TEST_ADDON = DATASET_PROPERTY_ADDON_TEST;
    public static final String INPUT_PROPERTY_APPLY_WI = DATASET_PROPERTY_APPLY_WI;
    public static final String INPUT_PROPERTY_BYPASS_TRANSPORTTYPE = DATASET_PROPERTY_BYPASS_TRANSPORTTYPE;
    public static final String INPUT_PROPERTY_CHANGE_BACKUP_TO_USS = "backuptouss";
    public static final String INPUT_PROPERTY_BYPASS_INITIAL_REPEAT = "initialrepeatbypass";

    private static final String DATASET_PROPERTY_SPEC_ID = "specid";
    private static final String DATASET_PROPERTY_SPEC_VERSION_ID = "specversionid";

    private void initializeDataSet(DataSet dsInput) throws SapphireException {
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_LV_TEST_CODE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_LV_PANEL_CODE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_IS_PANEL, DataSet.STRING);
            // dsFinal.addColumn(DATASET_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY,
            // DataSet.STRING);//TODO needed?
            dsFinal.addColumn(DATASET_PROPERTY_APPLY_WI, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_WORK_ITEM_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_WORK_ITEM_VERSION_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_BYPASS_TRANSPORTTYPE, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_ADDON_TEST, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLE_TYPE_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_TRANSPORT_TYPE_ID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_RECEIVING_LOCATION, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_PERFORMING_LOCATION, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        }
        String allTestCodes1 = Util.getUniqueList(dsInput.getColumnValues(DATASET_PROPERTY_LV_TEST_CODE, ";"), ";",
                true);
        String sqlPanel = "select u_testcodeid,nvl(ispanel,'N') ispanel,nvl(isneotypepanel,'N') isneotypepanel,nvl(isdummy,'N')isdummy,methodology"
                + " from u_testcode where u_testcodeid in ('" + StringUtil.replaceAll(allTestCodes1, ";", "','") + "')";
        DataSet dsPanel = getQueryProcessor().getSqlDataSet(sqlPanel);
        if (dsPanel == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlPanel;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsPanel.size() == 0) {
            String errStr = getTranslationProcessor()
                    .translate("One or more of the below test code(s) does not exists in LV system");
            errStr += "\n " + allTestCodes1;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (!dsInput.isValidColumn(DATASET_PROPERTY_ISDUMMY)) {
            dsInput.addColumn(DATASET_PROPERTY_ISDUMMY, DataSet.STRING);
        }
        if (!dsInput.isValidColumn(DATASET_PROPERTY_METHODOLOGY)) {
            dsInput.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsInput.getRowCount(); i++) {
            String lvTestCodeId = dsInput.getValue(i, DATASET_PROPERTY_LV_TEST_CODE, "");
            hm.clear();
            hm.put("u_testcodeid", lvTestCodeId);
            DataSet dsFilter = dsPanel.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                String isPanel = dsFilter.getValue(0, "ispanel", "");
                String isNeoTypePanel = dsFilter.getValue(0, "isneotypepanel", "");
                if (isPanel.equalsIgnoreCase("Y") || isNeoTypePanel.equalsIgnoreCase("Y")) {
                    dsInput.setValue(i, DATASET_PROPERTY_IS_PANEL, "Y");
                } else {
                    dsInput.setValue(i, DATASET_PROPERTY_IS_PANEL, "N");
                }
                dsInput.setValue(i, DATASET_PROPERTY_ISDUMMY, dsFilter.getValue(0, DATASET_PROPERTY_ISDUMMY, "N"));
                dsInput.setValue(i, DATASET_PROPERTY_METHODOLOGY,
                        dsFilter.getValue(0, DATASET_PROPERTY_METHODOLOGY, ""));
            }

        }

        hm.clear();
        hm.put(DATASET_PROPERTY_IS_PANEL, "Y");
        hm.put(DATASET_PROPERTY_ISDUMMY, "N");
        DataSet dsFilter = dsInput.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            addPanelCodesToFinalDataSet(dsFilter);
        }

        hm.clear();
        hm.put(DATASET_PROPERTY_IS_PANEL, "N");
        dsFilter = dsInput.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            addTestCodesToFinalDataSet(dsFilter);
        }

        hm.clear();
        hm.put(DATASET_PROPERTY_IS_PANEL, "Y");
        hm.put(DATASET_PROPERTY_ISDUMMY, "Y");
        hm.put(DATASET_PROPERTY_METHODOLOGY, "Multiomyx");
        dsFilter = dsInput.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            addTestCodesToFinalDataSetForMultiomnyx(dsFilter);
        }
    }

    private void copyMoProperty(PropertyList prop, String sampletestcodemapid) throws SapphireException {
        String panelid = prop.getProperty(INPUT_PROPERTY_LV_TEST_CODE, "");
        String sampleid = prop.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");
        if (!Util.isNull(panelid) && !Util.isNull(sampleid)) {
            String sql = Util.parseMessage(MultiomyxSql.TESTCODE_INFO_BY_PANELID, StringUtil.replaceAll(panelid, ";", "','"));
            DataSet dsMoPanelInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsMoPanelInfo != null && dsMoPanelInfo.size() > 0) {
                PropertyList pl = new PropertyList();
                pl.setProperty("sampleid", sampleid);
                pl.setProperty("tcodes", dsMoPanelInfo.getColumnValues("testcodeid", ";"));
                pl.setProperty("panelname", dsMoPanelInfo.getColumnValues("panelid", ";"));
                pl.setProperty("stmid", sampletestcodemapid);
                pl.setProperty("flag", "Y");

                getActionProcessor().processAction("PanelUSSAssociation", "1", pl);
            }
        }
    }

    /*------------ Added by Subhendu - 23/01/2018 + ------------*/
    private void generateInternalIdForFlow() throws SapphireException {
        PropertyList props = new PropertyList();
        HashMap<String, String> hm = new HashMap<String, String>();
        hm.clear();
        hm.put(DATASET_PROPERTY_METHODOLOGY, "Flow");
        DataSet dsFilter = dsFinal.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            String sql = Util.parseMessage(FlowSql.GET_FLOW_SAMPLE_COUNT, dsFilter.getValue(0, "s_sampleid", ""));
            DataSet dsSampleinfo = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(FlowSql.GET_FLOW_PARENT_SAMPLE, Util.getUniqueList(dsFilter.getColumnValues("s_sampleid", "','"), "','", true));
            DataSet tempDS = getQueryProcessor().getSqlDataSet(sql);

            hm.clear();
            hm.put("filterflag", "Y");
            DataSet filterTemp = tempDS.getFilteredDataSet(hm);
            filterTemp = Util.filterNullValue(filterTemp, "u_flowsampleid", "null");

            if (filterTemp != null && filterTemp.size() > 0) {
                int cnt = Integer.parseInt(dsSampleinfo.getValue(0, "parentcnt"));
                String sampleids = Util.getUniqueList(filterTemp.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
                int repeat = StringUtil.split(sampleids, ";").length;

                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
                props.setProperty("u_flowsampleid", Util.generateSequence("S", ++cnt, repeat, ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
            hm.clear();
            hm.put("filterflag", "N");
            filterTemp.clear();
            filterTemp = tempDS.getFilteredDataSet(hm);
            if (filterTemp != null && filterTemp.size() > 0) {
                String sampleids = Util.getUniqueList(filterTemp.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
                int cnt = Integer.parseInt(dsSampleinfo.getValue(0, "childcnt"));
                int repeat = StringUtil.split(sampleids, ";").length;

                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
                props.setProperty("u_flowsampleid", Util.generateSequence(filterTemp.getValue(0, "flowid") + "d", ++cnt, repeat, ";"));
//	             props.setProperty("u_flowsampleid", filterTemp.getColumnValues("u_flowsampleid", "d;"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
//             throw new SapphireException("Test");
        }
    }
    /*------------ Added by Subhendu - 23/01/2018 - ------------*/

    private void validateCytoProperty(PropertyList property) throws SapphireException {
        if (property != null && property.size() > 0) {
            String sampleid = property.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");

            String disputedSamples = "";
            if (!Util.isNull(sampleid)) {
                String sql = Util.parseMessage(CommonSql.TESTCODE_INFO_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
                DataSet dsTestcodeInfo = getQueryProcessor().getSqlDataSet(sql);
                HashMap<String, String> hmap = new HashMap<String, String>();
                if (dsTestcodeInfo != null && dsTestcodeInfo.size() > 0) {
                    dsTestcodeInfo.sort("s_sampleid");
                    ArrayList<DataSet> dsTestcodeInfoArr = dsTestcodeInfo.getGroupedDataSets("s_sampleid");
                    if (dsTestcodeInfoArr != null && dsTestcodeInfoArr.size() > 0) {
                        for (int i = 0; i < dsTestcodeInfoArr.size(); i++) {
                            DataSet tempDs = dsTestcodeInfoArr.get(i);
                            if (tempDs != null && tempDs.size() > 0) {
                                String tempsampleid = tempDs.getValue(0, "s_sampleid", "");
                                if (!Util.isNull(tempsampleid)) {
                                    hmap.clear();
                                    hmap.put("methodology", "Cytogenetics");
                                    DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                                    if (tempDsFiltr != null && tempDsFiltr.size() > 1) {
                                        disputedSamples += ";" + tempsampleid;
                                    }
                                }
                            }
                        }
                        if (!Util.isNull(disputedSamples)) {
                            if (disputedSamples.startsWith(";"))
                                disputedSamples = disputedSamples.substring(1);
                            throw new SapphireException("You have tried to add multiple Cytogenetics testcodes on the below sample(s).\n" + disputedSamples);
                        }
                    }
                }

            }
        }
    }

    private void populateAndModifyCytoData(PropertyList property) throws SapphireException {
        assignTestToCytoDummySample(property);
        editCytoDummySampleInfo(property);
    }

    private void assignTestToCytoDummySample(PropertyList property) throws SapphireException {
        if (property != null && property.size() > 0) {
            String sampleid = property.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");
            String testcodeid = property.getProperty(INPUT_PROPERTY_LV_TEST_CODE, "");
            if (!Util.isNull(sampleid) && !Util.isNull(testcodeid)) {
                String sampleTstComb = "";
                String sampleArr[] = StringUtil.split(sampleid, ";");
                String testcodeidArr[] = StringUtil.split(testcodeid, ";");
                if (sampleArr != null && testcodeidArr != null && sampleArr.length == testcodeidArr.length) {
                    for (int i = 0; i < sampleArr.length; i++) {
                        if (!Util.isNull(sampleArr[i]) && !Util.isNull(testcodeidArr[i])) {
                            sampleTstComb += ";" + sampleArr[i] + "@*@" + testcodeidArr[i];
                        }
                    }
                    if (!Util.isNull(sampleTstComb)) {
                        if (sampleTstComb.startsWith(";"))
                            sampleTstComb = sampleTstComb.substring(1);
                        String sql = Util.parseMessage(CytoSqls.TESTCODE_INFO_BY_SAMPLETESTCODECOMB, StringUtil.replaceAll(sampleTstComb, ";", "','"));
                        DataSet dsTestcodeInfo = getQueryProcessor().getSqlDataSet(sql);
                        if (dsTestcodeInfo != null && dsTestcodeInfo.size() > 0) {
                            PropertyList pl = new PropertyList();
                            pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsTestcodeInfo.getColumnValues("dummysampleid", ";"));
                            pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsTestcodeInfo.getColumnValues("lvtestcodeid", ";"));
                            pl.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
                            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
                        }
                    }
                }
            }
        }
    }

    private void editCytoDummySampleInfo(PropertyList property) {
        if (property != null && property.size() > 0) {
            String sampleid = property.getProperty(INPUT_PROPERTY_SAMPLE_ID, "");
            if (!Util.isNull(sampleid)) {
                String sql = Util.parseMessage(CytoSqls.GET_SAMPLES_WITH_ORIG_OR_DUMMYID, "orgsampleid", "orgsampleid",
                        StringUtil.replaceAll(sampleid, ";", "','"));
                DataSet dsDummySampleInfo = getQueryProcessor().getSqlDataSet(sql);
                if (dsDummySampleInfo != null && dsDummySampleInfo.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsDummySampleInfo.getColumnValues("cytodummysampleid", ";"));
                    props.setProperty("u_cytostatus", "Ready for Setup");
                    props.setProperty("u_iscytoincidentcreated", "N");
                    props.setProperty("u_currentmovementstep", "CytoSetup");
                }
            }
        }
    }
}
