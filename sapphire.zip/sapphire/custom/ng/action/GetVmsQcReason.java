package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Created by dgupta on 7/18/2016.
 */
public class GetVmsQcReason extends BaseAction {

    /*
    *       OOB method override to provide VMS QC reasons stores in ref type data
    * */
    public void processAction(PropertyList properties) throws SapphireException {
        String reftypeid = properties.getProperty("refid", "VmsQcReason");
        logger.info("GetVmsQcReason Input>>>>>>", properties.toJSONString());
        DataSet dsRefValue = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.VMS_QC_REFTYPES, reftypeid));
        if (null == dsRefValue || 0 == dsRefValue.getRowCount()) {
            throw new SapphireException(getTranslationProcessor().translate("ref values not found for refid " + reftypeid));
        }
        for (int i = 0; i < dsRefValue.getRowCount(); i++) {
            properties.setProperty(dsRefValue.getString(i, "refvalueid"), dsRefValue.getString(i, "refdisplayvalue"));
        }
        logger.info("GetVmsQcReason After Execution>>>>>>", properties.toJSONString());
        return;
    }
}
