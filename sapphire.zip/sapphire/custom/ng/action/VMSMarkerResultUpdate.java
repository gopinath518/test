package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdidata.AddDataSet;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditDataItem;
import sapphire.action.EnterDataSet;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Iterator;
import java.util.Set;

/**
 * Created by dgupta on 7/25/2016.
 */
public class VMSMarkerResultUpdate extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("VMSMarkerResult Update START>>>>", properties.toJSONString());
        String sampleid = properties.getProperty("externalimageidentifier");
        String userid = properties.getProperty("userid");
        String version = properties.getProperty("version");
        String paramlistid = properties.getProperty("paramlistid");
        String plversionid = properties.getProperty("plversionid");
        String variantid = properties.getProperty("variantid");
        String dataset = properties.getProperty("dataset");
        String keyid1 = properties.getProperty("keyid1");
        String sdcid = properties.getProperty("sdcid", "Sample");
        //System.out.println("input props \n" + properties.toXMLString());
        sdcid = Util.getUniqueList(sdcid, ";", true);
        DataSet dsRegion = null;
        if ("Accession".equalsIgnoreCase(sdcid)) {
            logger.info("VMSMarkerResult Update Accession>>>>", properties.toJSONString());
            String sql = Util.parseMessage(ApSql.GET_SDIDATA_BY_SAMPLE, sdcid, keyid1, paramlistid, dataset);
            dsRegion = getQueryProcessor().getSqlDataSet(sql);
        } else {
            logger.info("VMSMarkerResult Update Sample>>>>", properties.toJSONString());
            dsRegion = getQueryProcessor().getSqlDataSet("select sdcid, keyid1, paramlistid, paramlistversionid, variantid, dataset, paramid, paramtype, " +
                    " replicateid, enteredtext  from sdidataitem " +
                    " where sdcid='Sample' and keyid1='" + sampleid + "' and paramlistid='" + paramlistid + "' and dataset = '" + dataset + "'");
        }
        // check its new region and result created or region is moved and for the same region new result is created
        /*DataSet dsRegion = getQueryProcessor().getSqlDataSet("select sdcid, keyid1, paramlistid, paramlistversionid, variantid, dataset, paramid, paramtype, " +
                " replicateid, enteredtext  from sdidataitem " +
                " where sdcid='Sample' and keyid1='" + sampleid + "' and paramlistid='" + paramlistid + "' and dataset = '" + dataset + "'");*/


        // check if paramlist exist then update result or throw exception.
        if (dsRegion != null && dsRegion.getRowCount() > 0) {
            editResult(sampleid, properties, dsRegion);
        } else {
            throw new SapphireException("Param list " + paramlistid + " not applied to sepcimen " + sampleid);
        }

    }

    private void editResult(String sampleid, PropertyList properties, DataSet dsRegion) throws ActionException {
        try {
            //DataSet dsCopy = dsRegion.copy();
            DataSet dsCopy = new DataSet();
            dsCopy.addColumn("paramid", DataSet.STRING);
            dsCopy.addColumn("paramtype", DataSet.STRING);
            dsCopy.addColumn("replicateid", DataSet.STRING);
            dsCopy.addColumn("entertext", DataSet.STRING);

            String paramName = "";
            PropertyList props = new PropertyList();
            props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
            props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, properties.getProperty("paramlistid"));
            props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
            props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
            props.setProperty(EnterDataSet.PROPERTY_DATASET, properties.getProperty("dataset"));
            String test = "";
            String analyteFound = "";
            String analyteNotFound = "";
            String analyteNoValue = "";
            String extraAnalyte = "";
            String masterData = "applylock;paramlistid;userid;externalimageidentifier;plversionid;version;dataset;variantid";

            Set propSet = properties.keySet();
            for (int i = 0; i < dsRegion.getRowCount(); i++) {
                paramName = dsRegion.getString(i, "paramid");
                if (properties.containsKey(paramName.trim())) {
                    analyteFound = analyteFound + ";" + paramName;
                    if (paramName.equalsIgnoreCase("ManualHer2/Chr17 Ratio")) {
                        test = properties.getProperty("ManualHer2//Chr17 Ratio");

                    }
                    test = properties.getProperty(paramName.trim());
                    if (test.length() == 0) analyteNoValue = analyteNoValue + ";" + paramName;

                    int j = dsCopy.addRow();
                    dsCopy.setString(j, "paramid", dsRegion.getString(i, "paramid"));
                    dsCopy.setString(j, "paramtype", dsRegion.getString(i, "paramtype"));
                    dsCopy.setString(j, "replicateid", "" + dsRegion.getInt(i, "replicateid"));
                    dsCopy.setString(j, "enteredtext", properties.getProperty(paramName.trim()));
                    propSet.remove(paramName.trim());
                } else
                    analyteNotFound = analyteNotFound + ";" + paramName;
            }
            if (dsCopy.getRowCount() > 0) {
                for (int i = 1; i <= dsCopy.getRowCount(); i++) {
                    props.setProperty("paramid" + i, dsCopy.getString(i - 1, "paramid"));
                    props.setProperty("paramtype" + i, dsCopy.getString(i - 1, "paramtype"));
                    props.setProperty("replicateid" + i, dsCopy.getString(i - 1, "replicateid"));
                    //props.setProperty("enteredtext" + i, dsCopy.getString(i - 1, "enteredtext"));
                    props.setProperty("enteredtext" + i, StringUtil.replaceAll(dsCopy.getString(i - 1, "enteredtext"), "#LV_SEMICOLON#", "#semicolon#"));
                }
                props.setProperty("params", "" + dsCopy.getRowCount());
                props.setProperty("matchusersequence", "Y");

                getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, props);

                if (propSet.size() > 0) {
                    test = "";
                    Iterator it = propSet.iterator();
                    while (it.hasNext()) {
                        test = it.next().toString();
                        extraAnalyte = masterData.contains(test) ? extraAnalyte + "" : extraAnalyte + ";" + test;
                        //extraAnalyte = extraAnalyte + ";" + it.next();
                    }
                }
                properties.setProperty("analyteFound", analyteFound.startsWith(";") ? analyteFound.substring(1) : analyteFound);
                properties.setProperty("analyteNoValue", analyteNoValue.startsWith(";") ? analyteNoValue.substring(1) : analyteNoValue);
                properties.setProperty("analyteNotFound", analyteNotFound.startsWith(";") ? analyteNotFound.substring(1) : analyteNotFound);
                properties.setProperty("extraAnalytes", extraAnalyte.startsWith(";") ? extraAnalyte.substring(1) : extraAnalyte);

            } else {
                throw new ActionException("No analyte found in input  one of these analyte must exist " + dsRegion.getColumnValues("paramid", ";"));
            }

        } catch (Exception ex) {
            throw new ActionException(ex.getMessage());
        }
    }

}
