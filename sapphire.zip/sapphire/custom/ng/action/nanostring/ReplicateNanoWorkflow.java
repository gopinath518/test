package sapphire.custom.ng.action.nanostring;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ReplicateNanoWorkflow extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String extractionid = properties.getProperty("extractionid", "");
        String sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_TUBE, StringUtil.replaceAll(extractionid, ";", "','"));
        DataSet dsExtractionInfo = getQueryProcessor().getSqlDataSet(sql);
        String elTube = "";
        if (dsExtractionInfo.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("exttubeid", dsExtractionInfo.getColumnValues("s_sampleid", ";"));
            pl.setProperty("copies", "1");
            //pl.setProperty("fromtramstop", fromtramstop);
            try {
                getActionProcessor().processAction("CrtElutionTube", "1", pl, false, false);
            } catch (Exception ex) {
                throw new SapphireException("Failed to create Elution tube(s)." + ex.getMessage());
            }
            elTube = pl.getProperty("elTube", "");
            if (Util.isNull(elTube)) {
                throw new SapphireException("Failed to create Elution tube(s).");
            }
            updateSpecimenCurrntMovement(elTube);
        }
        properties.setProperty("msg", "<b>Elution Tube(" + StringUtil.replaceAll(elTube, ";", ", ") + ") has been created to replicate workflow.</b>");
        //throw new SapphireException("test");
    }

    private void updateSpecimenCurrntMovement(String elutiontube) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, elutiontube);
        props.setProperty("u_currentmovementstep", "QuantCompleted");
        props.setProperty("u_replicateflag", "Y");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update specimen step(s)." + ex.getMessage());
        }
        String site = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0];
        String department = site + "-Molecular";
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, elutiontube);
        props.setProperty("u_currenttramstop", "RunDesign Specimen");
        //props.setProperty("u_currenttramstop", "Exome SS Reporting");
        props.setProperty("custodialdepartmentid", department);
        props.setProperty("custodialuserid", "(null)");
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException se) {
            throw new SapphireException("Can not update elution tube" + se.getMessage());
        }
    }
}
