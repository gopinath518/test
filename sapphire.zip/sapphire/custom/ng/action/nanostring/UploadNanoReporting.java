package sapphire.custom.ng.action.nanostring;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.vms.DeleteVMSSubFolder;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;

public class UploadNanoReporting extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String filelocation = properties.getProperty("location");
        String batchid = properties.getProperty("batchid");
        String filetype = properties.getProperty("choosefiletype");
        String defaultfiletype = properties.getProperty("filetype");

        DataSet dsParsingValue = Util.getNanoStringParsingValue(filelocation);
        if (dsParsingValue.size() == 0) {
            throw new SapphireException("No data found into " + new File(filelocation).getName());
        }
        if (dsParsingValue != null && dsParsingValue.size() > 0) {
            CopyOption[] options = new CopyOption[]{
                    StandardCopyOption.REPLACE_EXISTING
            };
            /*String sql = CommonSql.GET_FILE_BASE_PATH;
            DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
            if (dsBasePath == null || dsBasePath.size() == 0) {
                throw new SapphireException("Base path not find into the system");
            }
            String baseloc = dsBasePath.getValue(0, "propvalue");
            String destinationloc = Util.generateMolLocPath(baseloc, "Molecular", "NanoStringReport");//TODO NOT NEEDED.*/
            String destinationloc = getFileLocation();//TODO WILL OPEN AT THE TIME OF UPLOAD INTO SERVER
            //String destinationloc = "C:/TempPermission";
            File sourcefile = new File(filelocation);
            File destfile = null;
            if (destinationloc.endsWith("/") || destinationloc.endsWith("\\")) {
                destfile = new File(destinationloc + sourcefile.getName());
            } else {
                destfile = new File(destinationloc + File.separator + sourcefile.getName());
            }
            try {
                Files.copy(sourcefile.toPath(), destfile.toPath(), options);
            } catch (IOException e) {
                e.printStackTrace();
            }
            String sql = Util.parseMessage(MolecularSql.GET_NANO_SAMPLE_BY_BATCH, batchid);
            DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
            if (dsBatchSample.size() == 0)
                throw new SapphireException("No specimen(s) found for the batch.");
            String batchsample = StringUtil.replaceAll(dsBatchSample.getColumnValues("sampleid", ";"), ";", "','");
            sql = Util.parseMessage(MolecularSql.GET_MOL_BATCH_BY_SAMPLE, batchsample);
            DataSet dsAccession = getQueryProcessor().getSqlDataSet(sql);
            if (!dsParsingValue.isValidColumn("isupload"))
                dsParsingValue.addColumn("isupload", DataSet.STRING);
            if (!dsParsingValue.isValidColumn("filetype"))
                dsParsingValue.addColumn("filetype", DataSet.STRING);
            if (!dsParsingValue.isValidColumn("batchid"))
                dsParsingValue.addColumn("batchid", DataSet.STRING);
            if (!dsParsingValue.isValidColumn("molbatch"))
                dsParsingValue.addColumn("molbatch", DataSet.STRING);
            if (!dsParsingValue.isValidColumn("lvsampleid"))
                dsParsingValue.addColumn("lvsampleid", DataSet.STRING);
            HashMap hm = new HashMap();
            for (int i = 0; i < dsParsingValue.size(); i++) {
                String sampleid = dsParsingValue.getValue(i, "sampleid");
                hm.clear();
                hm.put("u_extractionid", sampleid);
                DataSet dsBatchSMFilter = dsBatchSample.getFilteredDataSet(hm);
                if (dsBatchSMFilter.size() > 0) {
                    dsParsingValue.setValue(i, "isupload", "Y");
                    dsParsingValue.setValue(i, "filetype", filetype);
                    dsParsingValue.setValue(i, "batchid", batchid);
                    dsParsingValue.setValue(i, "lvsampleid", dsBatchSMFilter.getValue(0, "sampleid", ""));
                }
                if (dsBatchSMFilter.size() == 0) {
                    dsParsingValue.setValue(i, "isupload", "N");
                    dsParsingValue.setValue(i, "filetype", filetype);
                    dsParsingValue.setValue(i, "batchid", batchid);
                    dsParsingValue.setValue(i, "lvsampleid", dsBatchSMFilter.getValue(0, "sampleid", ""));
                }
                hm.clear();
                hm.put("u_extractionid", sampleid);
                DataSet dsAccessionFilter = dsAccession.getFilteredDataSet(hm);
                if (dsAccessionFilter.size() > 0) {
                    dsParsingValue.setValue(i, "molbatch", dsAccessionFilter.getValue(0, "batchname", ""));
                }
                if (dsAccessionFilter.size() == 0) {
                    dsParsingValue.setValue(i, "molbatch", "");
                }
            }
            hm.clear();
            hm.put("isupload", "Y");
            DataSet dsUploadFilter = dsParsingValue.getFilteredDataSet(hm);
            if (dsUploadFilter.size() > 0) {
                String extractionids = StringUtil.replaceAll(dsUploadFilter.getColumnValues("sampleid", ";"), ";", "','");
                String nanobatchid = StringUtil.replaceAll(dsUploadFilter.getColumnValues("batchid", ";"), ";", "','");
                //String sampleid = StringUtil.replaceAll(dsUploadFilter.getColumnValues("sampleid", ";"), ";", "','");
                sql = Util.parseMessage(MolecularSql.GET_NANO_REPORTING_SAMPLES, extractionids, nanobatchid);
                DataSet dsNanoReporting = getQueryProcessor().getSqlDataSet(sql);
                sql = MolecularSql.GET_GENE_CLASS_NANO;
                DataSet dsGeneClass = getQueryProcessor().getSqlDataSet(sql);
                if (dsGeneClass == null || dsGeneClass.size() == 0)
                    throw new SapphireException("No Gene Name and Class Name found into the system.");
                if (!dsUploadFilter.isValidColumn("iseditable"))
                    dsUploadFilter.addColumn("iseditable", DataSet.STRING);
                if (!dsUploadFilter.isValidColumn("u_nanoreportingid"))
                    dsUploadFilter.addColumn("u_nanoreportingid", DataSet.STRING);
                if (!dsUploadFilter.isValidColumn("specialflag"))
                    dsUploadFilter.addColumn("specialflag", DataSet.STRING);
                DataSet dsError = new DataSet();
                dsError.addColumn("extraction_id", DataSet.STRING);
                dsError.addColumn("gene_name", DataSet.STRING);
                //dsError.addColumn("class_name", DataSet.STRING);
                for (int i = 0; i < dsUploadFilter.size(); i++) {
                    hm.clear();
                    hm.put("extractionid", dsUploadFilter.getValue(i, "sampleid", ""));
                    hm.put("batchid", dsUploadFilter.getValue(i, "batchid", ""));
                    //hm.put("genename", dsUploadFilter.getValue(i, "genename", ""));//TODO NOT REQUIRED AS IT IS NOT CASE SENCITIVE
                    hm.put("genename", dsUploadFilter.getValue(i, "genename", "").toLowerCase());
                    DataSet dsEditable = dsNanoReporting.getFilteredDataSet(hm);
                    if (dsEditable.size() > 0) {
                        dsUploadFilter.setValue(i, "iseditable", "Y");
                        dsUploadFilter.setValue(i, "u_nanoreportingid", dsEditable.getValue(0, "u_nanoreportingid"));
                    } else {
                        dsUploadFilter.setValue(i, "iseditable", "N");
                        dsUploadFilter.setValue(i, "u_nanoreportingid", "");
                    }
                    //VALIDATE GENE & CLASS
                    /***********************TODO RELEASE 1.6.1 REMOVE AS CLASS & GENE WILL BE CASE INCENSITIVE STARTS********************/
                    hm.clear();
                    hm.put("genename", dsUploadFilter.getValue(i, "genename", "").toLowerCase());
                    hm.put("classname", dsUploadFilter.getValue(i, "classname", "").toLowerCase());
                    DataSet dsGeneFilter = dsGeneClass.getFilteredDataSet(hm);
                    if (dsGeneFilter.size() == 0) {
                        int rowid = dsError.addRow();
                        dsError.setValue(rowid, "extraction_id", dsUploadFilter.getValue(i, "sampleid", ""));
                        dsError.setValue(rowid, "gene_name", dsUploadFilter.getValue(i, "genename", ""));
                    }
                    if (dsGeneFilter.size() > 0) {
                        String specialflag = dsGeneFilter.getValue(0, "specialflag", "");
                        if ("CORFKBP5".equalsIgnoreCase(filetype) && "Y".equalsIgnoreCase(specialflag)) {
                            /*if (i > 21) {
                                dsUploadFilter.remove(i);
                            }*/
                            dsUploadFilter.setValue(i, "specialflag", "Y");
                        } else if ("CORFKBP5".equalsIgnoreCase(filetype) && !"Y".equalsIgnoreCase(specialflag)) {
                            dsUploadFilter.setValue(i, "specialflag", "");
                        }
                    }
                    /*String parsegenename = dsUploadFilter.getValue(i, "genename", "");
                    String parseclassname = dsUploadFilter.getValue(i, "classname", "");
                    for (int m = 0; m < dsGeneClass.size(); m++) {
                        String genename = dsGeneClass.getValue(m, "genename", "");
                        String classname = dsGeneClass.getValue(m, "classname", "");
                        if (!genename.equalsIgnoreCase(parsegenename) || !classname.equalsIgnoreCase(parseclassname)) {
                            int rowid = dsError.addRow();
                            dsError.setValue(rowid, "extraction_id", dsUploadFilter.getValue(i, "sampleid", ""));
                            dsError.setValue(rowid, "gene_name", dsUploadFilter.getValue(i, "genename", ""));
                        } else {
                            String specialflag = dsGeneClass.getValue(m, "specialflag", "");
                            if ("CORFKBP5".equalsIgnoreCase(filetype) && "Y".equalsIgnoreCase(specialflag)) {
                                dsUploadFilter.setValue(i, "specialflag", "Y");
                            } else if ("CORFKBP5".equalsIgnoreCase(filetype) && !"Y".equalsIgnoreCase(specialflag)) {
                                dsUploadFilter.setValue(i, "specialflag", "");
                            }
                        }
                    }*/
                    /***********************TODO RELEASE 1.6.1 REMOVE AS CLASS & GENE WILL BE CASE INCENSITIVE END********************/
                }

                if ("CORFKBP5".equalsIgnoreCase(filetype)) {
                    hm.clear();
                    hm.put("specialflag", "Y");
                    dsUploadFilter = dsUploadFilter.getFilteredDataSet(hm);
                }
                if (dsError != null && dsError.size() > 0) {
                    String errorCode = Util.getDisplayMessage("Below Gene doesn't exist into the system.", dsError);
                    throw new SapphireException(errorCode);
                }

                hm.clear();
                hm.put("iseditable", "N");
                DataSet dsAddFilter = dsUploadFilter.getFilteredDataSet(hm);
                if (dsAddFilter.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDI.PROPERTY_SDCID, "NanoReporting");
                    props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsAddFilter.size()));
                    props.setProperty("extractionid", dsAddFilter.getColumnValues("sampleid", ";"));
                    props.setProperty("sampleid", dsAddFilter.getColumnValues("lvsampleid", ";"));
                    props.setProperty("elutiontubeid", dsAddFilter.getColumnValues("lvsampleid", ";"));
                    props.setProperty("batchid", dsAddFilter.getColumnValues("batchid", ";"));
                    props.setProperty("molbatchid", dsAddFilter.getColumnValues("molbatch", ";"));
                    props.setProperty("genename", dsAddFilter.getColumnValues("genename", ";"));
                    props.setProperty("classname", dsAddFilter.getColumnValues("classname", ";"));
                    if ("Raw Count".equalsIgnoreCase(defaultfiletype))
                        props.setProperty("rawcounts", dsAddFilter.getColumnValues("value", ";"));
                    if ("Normalized Count".equalsIgnoreCase(defaultfiletype))
                        props.setProperty("normalizedcount", dsAddFilter.getColumnValues("value", ";"));
                    props.setProperty("filetemplate", dsAddFilter.getColumnValues("filetype", ";"));
                    try {
                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to add record(s).");
                    }
                }

                hm.clear();
                hm.put("iseditable", "Y");
                DataSet dsEditFilter = dsUploadFilter.getFilteredDataSet(hm);
                if (dsEditFilter.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "NanoReporting");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsEditFilter.getColumnValues("u_nanoreportingid", ";"));
                    props.setProperty("extractionid", dsEditFilter.getColumnValues("sampleid", ";"));
                    props.setProperty("sampleid", dsEditFilter.getColumnValues("lvsampleid", ";"));
                    props.setProperty("elutiontubeid", dsEditFilter.getColumnValues("lvsampleid", ";"));
                    props.setProperty("batchid", dsEditFilter.getColumnValues("batchid", ";"));
                    props.setProperty("molbatchid", dsEditFilter.getColumnValues("molbatch", ";"));
                    props.setProperty("genename", dsEditFilter.getColumnValues("genename", ";"));
                    props.setProperty("classname", dsEditFilter.getColumnValues("classname", ";"));
                    if ("Raw Count".equalsIgnoreCase(defaultfiletype))
                        props.setProperty("rawcounts", dsEditFilter.getColumnValues("value", ";"));
                    if ("Normalized Count".equalsIgnoreCase(defaultfiletype))
                        props.setProperty("normalizedcount", dsEditFilter.getColumnValues("value", ";"));

                    props.setProperty("filetemplate", dsEditFilter.getColumnValues("filetype", ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to add record(s).");
                    }
                }


            }
            if (sourcefile.delete()) {
                System.out.println(sourcefile.getName() + " is deleted!");
            } else {
                System.out.println("Delete operation is failed.");
            }
            //throw new SapphireException("Test");
        }
    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        //CHECK FOLDER
        fileLocation = Util.createFolderForMolecular(fileLocation, "NanoReport");
        return fileLocation;
    }
}
