package sapphire.custom.ng.action;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.FileInputStream;
import java.text.DecimalFormat;
import java.util.HashMap;

import static sapphire.custom.ng.util.Util.parameterNullValidation;


/**
 * Created by Tutu Raj Sahoo on 10/30/2017.
 * Modified by surajit baitalik on 10/05/2018
 * Description : This action used for parse and validate Nanodrop instrument XLSX file.
 * Table Used : s_sample,u_instrumentquantific,sdiattachment,u_ngbatch_sample
 */

public class NanodropParser extends BaseAction {
    private static final String FILELOCATIONPOLICY = "FileLocationPolicy";

    private static final String NODEID = "MolecularDefaultLocation";
    private static final String PROPS_LOCATION = "location";
    private static final String PROPS_LOCATIONS = "locations";
    private String fileTemplateIdentifier = "xlsx";
    private static DecimalFormat TWO_DECIMAL_FORMAT = new DecimalFormat(".##");

    private DataSet dsMain = null;
    private static final String DATASET_PROPERTY_SAMPLE = "sample";
    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_NUCLEICACID = "nucleicacid";
    private static final String DATASET_PROPERTY_A260A280 = "a260/a280";
    private static final String DATASET_PROPERTY_BATCHID = "batchid";
    private static final String DATASET_PROPERTY_INSTRUMENTID = "instrumentid";
    private static final String DATASET_PROPERTY_READ_COUNT = "samplereadcount";
    private static String tramstop = "";

    String bufferSpecimen = "";
    int incr = 0;
    int specCount = 0;

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String file = properties.getProperty("path", "");
        String batchid = properties.getProperty("batchid", "");
        tramstop = properties.getProperty("tramstop", "");
        if (Util.isNull(file)) {
            throw new SapphireException("File is not found. Please upload a valid file.");
        }
        if (Util.isNull(batchid)) {
            throw new SapphireException("Batch Id Can't be null.");
        }
        String fileName = new File(file).getName();
        String fileToLower = fileName.toLowerCase();
        if (!fileToLower.endsWith(".xlsx")) {
            throw new SapphireException("Please upload XLSX file only.");
        }
        //int attachCount = attachedCount(batchid);//TODO IT WILL BE REMOVED FOR 1.4.1 RELEASE
        initializeDataSet();
        parseNanodropXLSXFile(file);
        if ("COBAS".equalsIgnoreCase(tramstop)) {
            extractionCOBASValidation(batchid);
        } else {
            extractionValidation(batchid);
        }
        valiadteSpecimenReadingCount(batchid);//TODO USED FOR 1.4.1Release
        parseValueToDataBase();
        attachFileToDatabase(batchid, file);

        //throw new SapphireException("test");
    }

    /**
     * Description : Parse XLSX file coming from Nanodrop instrument.
     *
     * @param filename
     * @throws SapphireException
     */
    public void parseNanodropXLSXFile(String filename) throws SapphireException {
        if (!parameterNullValidation(filename)) {
            throw new SapphireException("Null value passed as file name.");
        }
        int incr = 0;
        File file = new File(filename);
        if (file.exists()) {
            try {
                FileInputStream fis = new FileInputStream(file);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheetAt(0);
                XSSFRow row = sheet.getRow(0);
                for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                    incr = dsMain.addRow();
                    XSSFRow row1 = sheet.getRow(i);
                    if (row1 == null) {
                        dsMain.deleteRow(incr);
                        continue;
                    }
                    for (int j = 0; j < row.getLastCellNum(); j++) {
                        if (row.getCell(j).getStringCellValue().trim().equals("Sample ID")) {
                            XSSFCell cell = row1.getCell(j);
                            if (cell == null) {
                                dsMain.deleteRow(incr);
                                break;
                            }
                            String value = cell.getStringCellValue();
                            dsMain.setValue(incr, DATASET_PROPERTY_SAMPLEID, value);
                        } else if (row.getCell(j).getStringCellValue().trim().equals("Nucleic Acid")) {
                            XSSFCell cell = row1.getCell(j);
                            Double value = cell.getNumericCellValue();
                            dsMain.setNumber(incr, DATASET_PROPERTY_NUCLEICACID, TWO_DECIMAL_FORMAT.format(value));
                        } else if (row.getCell(j).getStringCellValue().trim().equals("260/280")) {
                            XSSFCell cell = row1.getCell(j);
                            Double value = cell.getNumericCellValue();
                            dsMain.setNumber(incr, DATASET_PROPERTY_A260A280, TWO_DECIMAL_FORMAT.format(value));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                throw new SapphireException("Excel Sheet may contain empty row/junk data. Error: " + e.getMessage());
            }
        } else {
            Logger.logInfo("Invalid input file name given.");
            throw new SapphireException("Input file " + filename + " does not exist.");
        }
    }

    /**
     * Description : This method is used for attached file to Database.
     *
     * @param batchid
     * @param file
     * @throws SapphireException
     */
    private void attachFileToDatabase(String batchid, String file) throws SapphireException {
        if (!Util.isNull(batchid) && !Util.isNull(file)) {
            PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy(FILELOCATIONPOLICY, NODEID);
            if (plCaseFilePolicy == null) {
                throw new SapphireException("File Location path can't be found");
            }
            PropertyListCollection plc = plCaseFilePolicy.getCollection(PROPS_LOCATIONS);
            String newfileLocation = "";
            if (plc != null) {
                newfileLocation = plc.getPropertyList(0).getProperty(PROPS_LOCATION);
                //CHECK FOLDER
                newfileLocation = Util.createFolderForMolecular(newfileLocation, "Instrument");
                if (Util.isNull(newfileLocation)) {
                    throw new SapphireException("Please specify the path in the policy " + FILELOCATIONPOLICY + " under the node " + NODEID);
                }
                String newFile = "";
                newFile = Util.copyFile(file, newfileLocation, (fileTemplateIdentifier + "_"));
                if (Util.isNull(newFile)) {
                    throw new SapphireException("File can't be created in the location " + newfileLocation);
                }

                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
                pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newFile);
                pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(newFile).getName());
                pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                if ("Quantification".equalsIgnoreCase(tramstop)) {
                    pl.setProperty("sourcefilename", "nanodrop");
                } else if ("Day1Quantification".equalsIgnoreCase(tramstop)) {
                    pl.setProperty("sourcefilename", "day1nanodrop");
                } else if ("Day2Quantification".equalsIgnoreCase(tramstop)) {
                    pl.setProperty("sourcefilename", "day1nanodrop");
                }
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
            }
        }
    }

    /**
     * Description : This is used to get and validate specimen reading with the uploaded file
     * and from the database.
     *
     * @param batchid
     * @throws SapphireException
     */
    private void valiadteSpecimenReadingCount(String batchid) throws SapphireException {
        if (dsMain.size() > 0) {
            if (!dsMain.isValidColumn(DATASET_PROPERTY_BATCHID)) {
                dsMain.addColumn(DATASET_PROPERTY_BATCHID, DataSet.STRING);
            }
            if (!dsMain.isValidColumn(DATASET_PROPERTY_INSTRUMENTID)) {
                dsMain.addColumn(DATASET_PROPERTY_INSTRUMENTID, DataSet.STRING);
            }
            if (!dsMain.isValidColumn(DATASET_PROPERTY_READ_COUNT)) {
                dsMain.addColumn(DATASET_PROPERTY_READ_COUNT, DataSet.STRING);
            }
            for (int i = 0; i < dsMain.size(); i++) {
                dsMain.setValue(i, DATASET_PROPERTY_BATCHID, batchid);
                if ("Quantification".equalsIgnoreCase(tramstop) || "COBAS".equalsIgnoreCase(tramstop)) {
                    dsMain.setValue(i, DATASET_PROPERTY_INSTRUMENTID, "Nanodrop");
                } else if ("Day1Quantification".equalsIgnoreCase(tramstop)) {
                    dsMain.setValue(i, DATASET_PROPERTY_INSTRUMENTID, "Day1Nanodrop");
                } else if ("Day2Quantification".equalsIgnoreCase(tramstop)) {
                    dsMain.setValue(i, DATASET_PROPERTY_INSTRUMENTID, "Day2Nanodrop");
                }
            }
            String sampleid = Util.getUniqueList(dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE, ";"), ";", true);
            String extractionid = Util.getUniqueList(dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"), ";", true);
            String parsebatchid = Util.getUniqueList(dsMain.getColumnValues(DATASET_PROPERTY_BATCHID, ";"), ";", true);
            String instrumentid = Util.getUniqueList(dsMain.getColumnValues(DATASET_PROPERTY_INSTRUMENTID, ";"), ";", true);

            String sql = Util.parseMessage(MolecularSql.NanodropPARSER_ATTACHEDCOUNT_BY_COMBINATION, StringUtil.replaceAll(parsebatchid, ";", "','"),
                    StringUtil.replaceAll(instrumentid, ";", "','"), StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsReadingInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsReadingInfo.size() > 0 || dsReadingInfo.size() == 0) {
                String arryExtarction[] = StringUtil.split(extractionid, ";");
                for (int i = 0; i < arryExtarction.length; i++) {
                    HashMap hm = new HashMap();
                    hm.clear();
                    hm.put(DATASET_PROPERTY_SAMPLEID, arryExtarction[i]);
                    DataSet dsFileterMain = dsMain.getFilteredDataSet(hm);
                    int parseSpecimenCount = dsFileterMain.size();
                    hm.clear();
                    hm.put("extractionid", arryExtarction[i]);
                    DataSet dsFileterInstrument = dsReadingInfo.getFilteredDataSet(hm);
                    int dbSpecimenCount = dsFileterInstrument.size();
                    if (!"COBAS".equalsIgnoreCase(tramstop)) {
                        if (parseSpecimenCount > 3) {
                            String errStr = getTranslationProcessor().translate("You can't upload more than 3 records of specimen(s): " + arryExtarction[i]);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                        }
                        if (dbSpecimenCount >= 3) {
                            String errStr = getTranslationProcessor().translate("You can't upload more than 3 records of specimen(s): " + arryExtarction[i]);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                        }
                        int balncReadingCount = 3 - dbSpecimenCount;
                        if (parseSpecimenCount > balncReadingCount) {
                            String errStr = getTranslationProcessor().translate("You can upload reading more " + balncReadingCount + " times of specimen(s): " + arryExtarction[i]);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                        }
                    } else {
                        if (parseSpecimenCount > 4) {
                            String errStr = getTranslationProcessor().translate("You can't upload more than 4 records of specimen(s): " + arryExtarction[i]);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                        }
                        if (dbSpecimenCount >= 4) {
                            String errStr = getTranslationProcessor().translate("You can't upload more than 4 records of specimen(s): " + arryExtarction[i]);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                        }
                        int balncReadingCount = 4 - dbSpecimenCount;
                        if (parseSpecimenCount > balncReadingCount) {
                            String errStr = getTranslationProcessor().translate("You can upload reading more " + balncReadingCount + " times of specimen(s): " + arryExtarction[i]);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                        }
                    }
                }
            }
            for (int i = 0; i < dsMain.size(); i++) {
                String specimenid = dsMain.getValue(i, DATASET_PROPERTY_SAMPLE);
                String ngbatchid = dsMain.getValue(i, DATASET_PROPERTY_BATCHID);
                String instrumentused = dsMain.getValue(i, DATASET_PROPERTY_INSTRUMENTID);

                if (!bufferSpecimen.equalsIgnoreCase(specimenid)) {
                    //incr = 0;
                    specCount = readingCountByCombination(specimenid, ngbatchid, instrumentused);
                } else {
                    //incr = (incr + 1);
                    //specCount = specCount + incr;
                    specCount = specCount + 1;
                }
                dsMain.setValue(i, DATASET_PROPERTY_READ_COUNT, "" + specCount);
            }
        }
    }

    /**
     * Description : Validate extraction ID in XLSX and Database
     *
     * @param batchid
     * @throws SapphireException
     */
    private void extractionValidation(String batchid) throws SapphireException {
        String sqlSample = Util.parseMessage(MolecularSql.QUBITPARSER_BATCHSAMPLE, batchid);
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
        if (dsSample == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        HashMap<String, String> hmFilter = new HashMap<>();
        String extIds = "";
        for (int i = 0; i < dsMain.size(); i++) {
            hmFilter.clear();
            String ext = dsMain.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
            hmFilter.put("u_extractionid", ext);
            DataSet dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.size() == 0) {
                extIds = extIds + ";" + ext;
            }
            if (dsFilter.size() > 0) {
                dsMain.setValue(i, DATASET_PROPERTY_SAMPLE, dsFilter.getValue(0, "s_sampleid"));
            }
            if (!"Quantification".equalsIgnoreCase(tramstop)) {
                hmFilter.clear();
                hmFilter.put("s_sampleid", ext);
                DataSet dsSampleFilter = dsSample.getFilteredDataSet(hmFilter);
                if (dsSampleFilter.size() > 0) {
                    dsMain.setValue(i, DATASET_PROPERTY_SAMPLE, dsSampleFilter.getValue(0, "s_sampleid"));
                    dsMain.setValue(i, DATASET_PROPERTY_SAMPLEID, dsSampleFilter.getValue(0, "u_extractionid"));
                }
            }
        }
        if (extIds.length() > 1 && "Quantification".equalsIgnoreCase(tramstop)) {
            extIds = extIds.substring(1);
            String errStr = getTranslationProcessor().translate(extIds + " Doesn't match with database value. Please check 'Sample ID' coulmn in XLSX file.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
    }

    /**
     * Description : Validate extraction ID in XLSX and Database
     *
     * @param batchid
     * @throws SapphireException
     */
    private void extractionCOBASValidation(String batchid) throws SapphireException {
        String sqlSample = Util.parseMessage(MolecularSql.QUBITPARSER_BATCHSAMPLE_COBAS, batchid);
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
        if (dsSample == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        HashMap<String, String> hmFilter = new HashMap<>();
        String extIds = "";
        for (int i = 0; i < dsMain.size(); i++) {
            hmFilter.clear();
            String ext = dsMain.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
            hmFilter.put("u_extractionid", ext);
            DataSet dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.size() == 0) {
                extIds = extIds + ";" + ext;
            }
            if (dsFilter.size() > 0) {
                dsMain.setValue(i, DATASET_PROPERTY_SAMPLE, dsFilter.getValue(0, "s_sampleid"));
            }
        }
        if (extIds.length() > 1) {
            extIds = extIds.substring(1);
            String errStr = getTranslationProcessor().translate(extIds + " Doesn't match with database value. Please check 'Sample ID' coulmn in XLSX file.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
    }

    /**
     * Description : Insert/update XLSX value to database
     *
     * @throws SapphireException
     */
    private void parseValueToDataBase() throws SapphireException {

        PropertyList propIn = new PropertyList();
        propIn.setProperty(AddSDI.PROPERTY_SDCID, "InstrumentQuantific");
        propIn.setProperty(AddSDI.PROPERTY_COPIES, "" + dsMain.size());
        propIn.setProperty("u_instrumentused", dsMain.getColumnValues(DATASET_PROPERTY_INSTRUMENTID, ";"));
        propIn.setProperty("u_ngbatchid", dsMain.getColumnValues(DATASET_PROPERTY_BATCHID, ";"));
        propIn.setProperty("sampleid", dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE, ";"));
        propIn.setProperty("extractionid", dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
        propIn.setProperty("concentration", dsMain.getColumnValues(DATASET_PROPERTY_NUCLEICACID, ";"));
        propIn.setProperty("a260a280", dsMain.getColumnValues(DATASET_PROPERTY_A260A280, ";"));
        propIn.setProperty("uploadcount", dsMain.getColumnValues(DATASET_PROPERTY_READ_COUNT, ";"));
        if ("COBAS".equalsIgnoreCase(tramstop)) {
            propIn.setProperty("rulebypass", "Y");
        }
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, propIn);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    /**
     * Description: This is used to count and validate specimen reading records.
     *
     * @param sampleid
     * @param batchid
     * @param instrumentid
     * @throws SapphireException
     */
    private int readingCountByCombination(String sampleid, String batchid, String instrumentid) throws SapphireException {
        int count = 0;
        String sql = Util.parseMessage(MolecularSql.NanodropPARSER_ATTACHEDCOUNT_BY_COMBINATION, batchid, instrumentid, sampleid);
        DataSet dsReadingInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsReadingInfo.size() == 0) {
            bufferSpecimen = sampleid;
            count = dsReadingInfo.size();
        }
        if (dsReadingInfo.size() > 0) {
            bufferSpecimen = sampleid;
            count = dsReadingInfo.size();
        }
        return count + 1;
    }

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_SAMPLE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_NUCLEICACID, DataSet.NUMBER);
            dsMain.addColumn(DATASET_PROPERTY_A260A280, DataSet.NUMBER);
        }
    }
}
