package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by mpandey on 5/5/2016.
 * Action Name- CurrentSampleMovementStatus
 * Description: This Action will update next movement step for sample as per dos rule
 *
 * Mandatory inputs
 * param1-sampleid
 * throws SapphireException
  */
public class CurrentSampleMovementStatus extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("s_sampleid");
        String sql = "select u_currentmovementstep from s_sample where  s_sampleid='" + sampleid + "'";
        DataSet dsstep = getQueryProcessor().getSqlDataSet(sql);
        String currentstep = dsstep.getValue(0, "u_currentmovementstep");
        String completedby = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String nextstep = getNextStep(sampleid, currentstep);
        updateStep(nextstep, sampleid);

    }

    /**
     * This maethod is use to get Next movement step of sample .
     * @param sampleid
     * @param currentstep
     * @return
     */
    private String getNextStep(String sampleid, String currentstep) {
        String sql = "select stepname,stepno from U_SAMPLE_TCODE_STP_MAP where s_sampleid='" + sampleid + "' order by stepno;";
        DataSet dssample = getQueryProcessor().getSqlDataSet(sql);
        DataSet sampleFiltered = new DataSet();
        HashMap hmFilter = new HashMap();


        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("stepname", currentstep);
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        int nextstepno = Integer.parseInt(sampleFiltered.getValue(0, "stepno")) + 1;

        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("stepno", nextstepno);
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        String nextstep = sampleFiltered.getValue(0, "stepname");
        return nextstep;
    }

    /**
     * This method is use to update currentmovement step of sample.
     * so that it will route to certain tramstop.
     * @param steps
     * @param sampleid
     * @throws SapphireException
     */
    private void updateStep(String steps, String sampleid) throws SapphireException {

        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("u_currentmovementstep", steps);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
