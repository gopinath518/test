package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Created by akumar on 7/25/2016.
 */
public class CreateMyeloidPoolSample extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("u_ngbatchid");
        String sql = "select ns.sampleid from u_ngbatch_sample ns ,s_sample s \n" +
                " where ns.sampleid=s.s_sampleid and ns.u_ngbatchid='" + batchid + "' and s.pooledflag is null";
        DataSet sample = getQueryProcessor().getSqlDataSet(sql);
        String parentsample = sample.getColumnValues("sampleid", ";");
        String samples = StringUtil.replaceAll(parentsample, ";", "','");

        //String myeloidsample = "select s_sampleid,lvtestcodeid,ispanel,molecularworkflow from u_sampletestcodemap where s_sampleid in('" + samples + "')"+
        // " and molecularworkflow='Myeloid'";
       /* String myeloidsample="select s.s_sampleid,s.lvtestcodeid,s.ispanel from \n" +
                " u_sampletestcodemap s where lvtestcodeid in(select distinct tm.indtestcodeid from u_testcode t,u_testcodepanelmap tm\n" +
                " where t.u_testcodeid=tm.u_testcodeid and (t.molecularworkflow='Myeloid' or t.ngstype='Myeloid') and tm.indtestcodeid in(select sm.lvtestcodeid from u_sampletestcodemap sm \n" +
                " where sm.s_sampleid in('"+samples+"'))) and s.s_sampleid in('"+samples+"') ";*/
        String myeloidsample = "select sm.s_sampleid,sm.lvtestcodeid,sm.ispanel\n" +
                " from u_sampletestcodemap sm,u_testcode t where\n" +
                " t.u_testcodeid=sm.lvtestpanelid and 'Myeloid' in(select molecularworkflow from u_testcode where u_testcodeid in(select sm.lvtestpanelid\n" +
                " from u_sampletestcodemap sm where sm.s_sampleid in('" + samples + "')))\n" +
                " and sm.s_sampleid in('" + samples + "')";

        //String solidsample = "select s_sampleid,lvtestcodeid,ispanel,molecularworkflow from u_sampletestcodemap where s_sampleid in('" + samples + "') and " +
        //" molecularworkflow='Solid'";
       /*String solidsample="select s_sampleid,lvtestcodeid,ispanel from \n" +
                " u_sampletestcodemap where lvtestcodeid in(select distinct tm.indtestcodeid from u_testcode t,u_testcodepanelmap tm\n" +
                " where t.u_testcodeid=tm.u_testcodeid and (t.ngstype='Solid' or t.molecularworkflow='Solid') and tm.indtestcodeid in(select lvtestcodeid from u_sampletestcodemap \n" +
                " where s_sampleid in('"+samples+"'))) and s_sampleid in('"+samples+"') ";*/
        String solidsample = "select sm.s_sampleid,sm.lvtestcodeid,sm.ispanel\n" +
                " from u_sampletestcodemap sm,u_testcode t where\n" +
                " t.u_testcodeid=sm.lvtestpanelid and 'Solid' in(select molecularworkflow from u_testcode where u_testcodeid in(select sm.lvtestpanelid\n" +
                " from u_sampletestcodemap sm where sm.s_sampleid in('" + samples + "')))\n" +
                " and sm.s_sampleid in('" + samples + "')";
        DataSet dsMyeloid = getQueryProcessor().getSqlDataSet(myeloidsample);
        DataSet dsSolid = getQueryProcessor().getSqlDataSet(solidsample);
        /*if(dsMyeloid1==null){
            String myeloidsample1="select s_sampleid,lvtestcodeid,ispanel from \n" +
                    " u_sampletestcodemap where lvtestcodeid in(select distinct tm.indtestcodeid from u_testcode t,u_testcodepanelmap tm\n" +
                    " where t.u_testcodeid=tm.u_testcodeid and (t.ngstype='Solid' or t.molecularworkflow='Myeloid') and tm.indtestcodeid in(select lvtestcodeid from u_sampletestcodemap \n" +
                    " where s_sampleid in('"+samples+"'))) and s_sampleid in('"+samples+"') ";
            DataSet dsMyeloid=getQueryProcessor().getSqlDataSet(myeloidsample1);

        }*/
        if (dsMyeloid == null || dsMyeloid.size() == 0) {
            String myeloid_nonpanel = "select sm.s_sampleid,sm.lvtestcodeid,sm.ispanel from u_sampletestcodemap sm,u_testcode t " +
                    " where t.u_testcodeid=sm.lvtestcodeid and sm.molecularsubmethodology='NGS' and sm.molecularworkflow='Myeloid' and sm.s_sampleid in('" + samples + "')";
            dsMyeloid = getQueryProcessor().getSqlDataSet(myeloid_nonpanel);
        }
        if (dsSolid == null || dsSolid.size() == 0) {
            String solid_nonpanel = "select sm.s_sampleid,sm.lvtestcodeid,sm.ispanel from u_sampletestcodemap sm,u_testcode t " +
                    " where t.u_testcodeid=sm.lvtestcodeid and sm.molecularsubmethodology='NGS' and sm.molecularworkflow='Solid' and sm.s_sampleid in('" + samples + "')";
            dsSolid = getQueryProcessor().getSqlDataSet(solid_nonpanel);
        }
        //BRCA
        String solid_brca = "select sm.s_sampleid,sm.lvtestcodeid,sm.ispanel from u_sampletestcodemap sm,u_testcode t " +
                " where t.u_testcodeid=sm.lvtestcodeid and sm.molecularworkflow='BRCA' and sm.s_sampleid in('" + samples + "')";

        DataSet dsBRCA = getQueryProcessor().getSqlDataSet(solid_brca);
        if (dsBRCA.size() > 0) {
            dsSolid.addAll(dsBRCA);
        }

        if (dsSolid == null && dsMyeloid == null) {
            throw new SapphireException("No Myeloid/Solid Test code assigned on the Samples ");
        }
        if (dsSolid.size() == 0 && dsMyeloid.size() == 0) {
            throw new SapphireException("No Myeloid/Solid Test code assigned on the Samples");
        }
        String myeloidpoolsample = null;
        String solidpoolsample = null;
        //BRCA


        if (dsMyeloid.size() > 0) {
            myeloidpoolsample = createMyeloidPoolSample(dsMyeloid);
            associatePoolSample(batchid, myeloidpoolsample);
            Util.setRootForPoolSample(myeloidpoolsample, dsMyeloid.getColumnValues("s_sampleid", ";"), getTranslationProcessor(), getActionProcessor());
            properties.setProperty("myeloid", myeloidpoolsample);
        }
        if (dsSolid.size() > 0) {
            solidpoolsample = createSolidPoolSample(dsSolid);
            associatePoolSample(batchid, solidpoolsample);
            properties.setProperty("solid", solidpoolsample);
        }
        if (myeloidpoolsample != null && solidpoolsample != null) {
            properties.setProperty("msg", "Myeloid pool sample=" + myeloidpoolsample + "and" + "Solid pool sample=" + solidpoolsample);
        }
        if (myeloidpoolsample != null && solidpoolsample == null) {
            properties.setProperty("msg", "Myeloid pool sample=" + myeloidpoolsample);
        }
        //BRCA pool Sample
        if (solidpoolsample != null && myeloidpoolsample == null) {
            properties.setProperty("msg", "Solid pool sample=" + solidpoolsample);
        }
        if (solidpoolsample != null && myeloidpoolsample == null && dsBRCA.size() > 0) {
            properties.setProperty("msg", "Solid BRCA pool sample=" + solidpoolsample);
        }

        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        //Util.setRootForPoolSample(myeloidpoolsample, dsMyeloid.getColumnValues("s_sampleid", ";"),getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------
        //String solidpoolsample = createSolidPoolSample(dsSolid);
        // String finalpoolsample = myeloidpoolsample + ";" + solidpoolsample;
        //associatePoolSample(batchid, finalpoolsample);
    }

    private String createMyeloidPoolSample(DataSet myeloid) throws SapphireException {
        String parentsample = myeloid.getColumnValues("s_sampleid", ";");
        HashSet<String> parentlist = new HashSet<String>(Arrays.asList(parentsample.split(";")));

        //String sourcesampleid=String.join(";",parentlist);
        String sample1 = "";
        for (String s : parentlist) {
            sample1 = sample1 + ";" + s;
        }
        String sourcesampleid = sample1.substring(1);

        PropertyList prop = new PropertyList();
        //prop.setProperty("sampleid", myeloid.getColumnValues("s_sampleid", ";"));
        prop.setProperty("sampleid", sourcesampleid);
        prop.setProperty("quantity", "10");
        prop.setProperty("poolquantity", "10");
        //props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        // props.setProperty("poolcustodialdepartmentid", dstrack.getValue(0, "custodialdepartmentid"
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, prop);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        String myeloidnewkeyid = prop.getProperty("newkeyid1");


        addTestCode(myeloid, myeloidnewkeyid);
        return myeloidnewkeyid;
    }

    private String createSolidPoolSample(DataSet solid) throws SapphireException {
        String parentsolidsample = solid.getColumnValues("s_sampleid", ";");
        HashSet<String> parentsolidlist = new HashSet<String>(Arrays.asList(parentsolidsample.split(";")));
        // String solidsourceid=String.join(";",parentsolidlist);
        String sample1 = "";
        for (String s : parentsolidlist) {
            sample1 = sample1 + ";" + s;
        }
        String solidsourceid = sample1.substring(1);

        PropertyList prop1 = new PropertyList();
        //prop1.setProperty("sampleid", solid.getColumnValues("s_sampleid", ";"));
        prop1.setProperty("sampleid", solidsourceid);
        prop1.setProperty("quantity", "10");
        prop1.setProperty("poolquantity", "10");
        //props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        // props.setProperty("poolcustodialdepartmentid", dstrack.getValue(0, "custodialdepartmentid"
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, prop1);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        String solidnewkeyid = prop1.getProperty("newkeyid1");


        addTestCode(solid, solidnewkeyid);
        return solidnewkeyid;
    }

    private void addTestCode(DataSet pool, String newkeyid) throws SapphireException {

        if (pool == null) {
            throw new SapphireException("No test is assigned to the Samples");
        }
        if (pool.size() == 0)
            throw new SapphireException("No test is assigned to the Samples");
        PropertyList props = new PropertyList();
        String lvtestcode = pool.getColumnValues("lvtestcodeid", ";");
        String ispanel = pool.getColumnValues("ispanel", ";");

        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);

        for (int j = 0; j < pool.getRowCount(); j++) {
            int rowID = dsSamplefinal.addRow();
            dsSamplefinal.setValue(rowID, "s_sampleid", newkeyid);
            dsSamplefinal.setValue(rowID, "lvtestcode", pool.getValue(j, "lvtestcodeid"));
            dsSamplefinal.setValue(rowID, "ispanel", pool.getValue(j, "ispanel", ""));
        }
        if (dsSamplefinal == null) {
            throw new SapphireException("DataSet containing Sample and test information is null");
        }
        if (dsSamplefinal.size() == 0) {
            throw new SapphireException("No test is assigned on the samples");
        }
        //props.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsSamplefinal.getColumnValues("s_sampleid", ";"));
        //props.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsSamplefinal.getColumnValues("lvtestcode", ";"));
        //props.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL, dsSamplefinal.getColumnValues("ispanel", ";"));
        //props.setProperty("bypassvalidation", "Y");

        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
        try {
            getActionProcessor().processAction("AssignTestCode", "1", props);

        } catch (Exception e) {
            throw new SapphireException("Unable to add a Test on a pool Sample");

        }

    }

    private void associatePoolSample(String ngbatchid, String sampleid) throws SapphireException {
        PropertyList sampleprop = new PropertyList();
        sampleprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        sampleprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        sampleprop.setProperty("sampleid", sampleid);
        sampleprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleprop);
        } catch (SapphireException se) {

            throw new SapphireException("Pool Sample not associated to batch");
        }
    }
}