package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

public class MarkBestHNE extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Please select atleast one specimen.");
        }
        String sql = Util.parseMessage(ApSql.GET_SPECIMEN_INFO, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        sql = Util.parseMessage(ApSql.GET_SPECIMEN_INFO_ALL, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsScannedHnEInfo = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        if (dsScannedHnEInfo.size() > 0) {
            dsScannedHnEInfo.sort("u_accessionid");
            ArrayList groupByAccessionArray = dsScannedHnEInfo.getGroupedDataSets("u_accessionid");
            for (int i = 0; i < groupByAccessionArray.size(); i++) {
                //CHECK BEST H&E SELECTION PER ACCESSION
                DataSet dsEach = (DataSet) groupByAccessionArray.get(i);
                hm.clear();
                hm.put("u_isbesthne", "N");
                DataSet dsBestHNESelctnFiletr = dsEach.getFilteredDataSet(hm);
                if (dsBestHNESelctnFiletr.size() > 1) {
                    throw new SapphireException("Please choose only one Best H&E for an Accession ID: "
                            + Util.getUniqueList(dsEach.getColumnValues("u_accessionid", ","), ",", true));
                }
            }
        }

        if (dsInfo.size() > 0) {
            dsInfo.sort("u_accessionid");
            ArrayList groupByAccessionArray = dsInfo.getGroupedDataSets("u_accessionid");
            for (int i = 0; i < groupByAccessionArray.size(); i++) {
                DataSet dsEach = (DataSet) groupByAccessionArray.get(i);
                hm.clear();
                hm.put("u_isbesthne", "Y");
                DataSet dsBestHNEFiletr = dsEach.getFilteredDataSet(hm);
                if (dsBestHNEFiletr.size() > 0) {
                    throw new SapphireException("Please choose only one Best H&E for an Accession ID: "
                            + Util.getUniqueList(dsEach.getColumnValues("u_accessionid", ","), ",", true));
                }
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_isbesthne", "Y");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ec) {
                throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
            }
        }
    }
}
