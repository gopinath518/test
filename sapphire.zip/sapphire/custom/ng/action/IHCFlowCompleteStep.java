package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Modified by surajit
 * Description: To complete IHC steps
 */
public class IHCFlowCompleteStep extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        //This is only parameter required, everything else will be handled by code dynamically.
        String sampleId = properties.getProperty("sampleid", "");

        /** Required Parameters only if you don't want to follow the dynamic way otherwise only SampleId is required */
        String departmentId = properties.getProperty("transferdepartment", "");
        String toTramstop = properties.getProperty("totramstop", "");
        String currentMovemnetStep = properties.getProperty("currentmovemnetstep", "");
        String imagingcompltstep = properties.getProperty("imagingcompltstep", "N");

        if ("".equals(sampleId))
            throw new SapphireException("Insufficient Data: SampleId missing");

        String pathologycompleteflag = properties.getProperty("pathologycompleteflag", "N");
        String promptvalue = properties.getProperty("promptvalue", "");
        String hneqcflag = properties.getProperty("hneqcflag", ""); // this flag comes from Pathology-IHC tramstop while completing Pathology review.

        if ("Y".equalsIgnoreCase(hneqcflag)) {

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
            pl.setProperty("u_hneqc", promptvalue);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (SapphireException se) {
                throw new SapphireException("Unable to update HNE QC result. Reason : " + se.getMessage());
            }
        }

        String sql = Util.parseMessage(ApSql.GET_LOS_BYSAMPELID, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsLos = getQueryProcessor().getSqlDataSet(sql);
        if (dsLos == null) {
            throw new SapphireException("Query failed: Please contact your administrator." + sql);
        }
        if (dsLos.size() == 0) {
            throw new SapphireException("No LOS found for the specimen(s)");
        }
        if ("Y".equalsIgnoreCase(imagingcompltstep)) {
            //UPDATE IMAGING DATES
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
            prop.setProperty("u_imagingdts", "n");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                logger.info("AperioUpdate::", "Sample status update failed for barcode: " + sampleId + " Error:" + ex.getMessage());
                throw new SapphireException("Sample status update failed for barcode: " + sampleId + " Error:" + ex.getMessage());
            }
            updateImagingDtAnalyte(sampleId);
        }
        if ("Y".equalsIgnoreCase(pathologycompleteflag)) {
            HashMap hmm = new HashMap();
            hmm.clear();
            hmm.put("slidetype", "SH");
            DataSet dsSharedFilter = dsLos.getFilteredDataSet(hmm);
            if (dsSharedFilter.size() > 0) {
                String defaultdepartment = connectionInfo.getDefaultDepartment();
                String currentuser = connectionInfo.getSysuserId();
                String site = StringUtil.split(defaultdepartment, "-")[0]; //AV
                String assigndept = site + "-Accessioning";
                String specimen_id = dsSharedFilter.getColumnValues("specimen_id", ";");
                sql = Util.parseMessage(ApSql.GET_COMMUNICATION_BY_SAMPLEID, specimen_id);
                DataSet dsCommunication = getQueryProcessor().getSqlDataSet(sql);
                if (dsCommunication.size() == 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDI.PROPERTY_SDCID, "Communication");
                    props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsSharedFilter.size()));
                    props.setProperty("createbydepartment", StringUtil.repeat(defaultdepartment, dsSharedFilter.size(), ";"));
                    props.setProperty("communicationdesc", StringUtil.repeat("Pathology H&E Review. ", dsSharedFilter.size(), ";"));
                    props.setProperty("linkkeyid1", dsSharedFilter.getColumnValues("specimen_id", ";"));
                    props.setProperty("linkkeyid2", dsSharedFilter.getColumnValues("accession_id", ";"));
                    props.setProperty("linkkeyid3", StringUtil.repeat("qcpass", dsSharedFilter.size(), ";"));
                    props.setProperty("assigneddepartment", StringUtil.repeat(assigndept, dsSharedFilter.size(), ";"));
                    props.setProperty("status", StringUtil.repeat("Initial", dsSharedFilter.size(), ";"));
                    try {
                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        logger.info("Generatereport>", "unable to add into communication");
                    }
                }
            }
        }
        //TODO FOR 1.6.1 RELEASE
        /*String accessionid[] = StringUtil.split(Util.getUniqueList(dsLos.getColumnValues("accession_id", ";"), ";", true), ";");
        String los[] = StringUtil.split(Util.getUniqueList(dsLos.getColumnValues("los", ";"), ";", true), ";");
        if (accessionid.length > 1) {
            String errorCode = Util.getDisplayMessage(dsLos);
            throw new SapphireException("Multiple accession(s) can not allowed to proceed at a time\n" + errorCode);
        }*/
        /***
         * TODO FOR 1.5.1 RELEASE
         */
        /*String los[] = StringUtil.split(Util.getUniqueList(dsLos.getColumnValues("los", ";"), ";", true), ";");
        if (los.length > 1) {
            String errorCode = Util.getDisplayMessage(dsLos);
            throw new SapphireException("Multiple LOS can not allowed to proceed at a time\n" + errorCode);
        }*/
        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("accession_id", DataSet.STRING);
        dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
        dsDisplayMsg.addColumn("level_of_service", DataSet.STRING);
        dsDisplayMsg.addColumn("tramstop", DataSet.STRING);
        dsDisplayMsg.addColumn("doctor_name", DataSet.STRING);//TODO ADDED ASSIGNED PATHOLOGIST
        dsLos.sort("accession_id,los");
        ArrayList<DataSet> dsMultiLOSArr = dsLos.getGroupedDataSets("accession_id,los");
        for (int i = 0; i < dsMultiLOSArr.size(); i++) {
            DataSet dsEach = (DataSet) dsMultiLOSArr.get(i);
            sampleId = dsEach.getColumnValues("specimen_id", ";");
            if (Util.isNull(currentMovemnetStep)) {
                String nextStep = setNextStep(sampleId);
                if (nextStep.contains("H&E")) {
                    nextStep = StringUtil.replaceAll(nextStep, "H&E", "H&E ");
                } else if (nextStep.contains("Slide Recon")) {
                    nextStep = StringUtil.replaceAll(nextStep, "Slide Recon", "Path Support Recon");
                } else if (nextStep.contains("Pathology- ROI")) {
                    nextStep = StringUtil.replaceAll(nextStep, "Pathology- ROI Review", "Pathology-ROI");
                } else if (nextStep.contains("Imaging")) {
                    nextStep = StringUtil.replaceAll(nextStep, "Imaging", "IHC Imaging");
                } else if (nextStep.contains("Pathology")) {
                    nextStep = StringUtil.replaceAll(nextStep, "Pathology", "Pathology-IHC");
                } else if ("Path Support".equalsIgnoreCase(nextStep)) {
                    nextStep = StringUtil.replaceAll(nextStep, "Path Support", "Path Support COC");
                }
                for (int s = 0; s < dsEach.size(); s++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "accession_id", dsEach.getValue(0, "accession_id"));
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsEach.getValue(s, "specimen_id"));
                    dsDisplayMsg.setValue(rowID, "level_of_service", dsEach.getValue(0, "los"));
                    dsDisplayMsg.setValue(rowID, "tramstop", nextStep);
                    dsDisplayMsg.setValue(rowID, "doctor_name", dsEach.getValue(0, "doctor_name"));
                }
                //properties.setProperty("msg", sampleId + " - has/have been moved to <b>" + nextStep + "</b> tramstop.");
            } else {
                processNextStep(sampleId, currentMovemnetStep, departmentId, toTramstop);
            }
        }
        if (dsDisplayMsg.size() > 0) {
            String displayMsg = Util.getDisplayMessage("Specimen(s) has/have been moved to below tramstop(s):", dsDisplayMsg);
            properties.setProperty("msg", displayMsg);
        }
        //throw new SapphireException("test");
    }

    public String setNextStep(String sampleId) throws SapphireException {

        /*** Same Query is executed twice one for completing the current tramstop pending status and next to get the currentmovement step on next tramstop */

        String sql = Util.parseMessage(ApSql.IHC_GET_NEXT_STEP_KEYID1,
                StringUtil.replaceAll(sampleId, ";", "','"),
                StringUtil.replaceAll(sampleId, ";", "','"),
                StringUtil.replaceAll(sampleId, ";", "','"),
                StringUtil.replaceAll(sampleId, ";", "','"));

        String nextCurrentStep = "";
        String nextStep = "";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0) {
            String keyid1 = ds.getColumnValues("u_sampletestcodestpmapid", ";");
            if (!"".equals(keyid1)) {
                completePreviousStep(sampleId, keyid1);

                ds.clear();
                ds = getQueryProcessor().getSqlDataSet(sql);
                if (ds != null && ds.size() > 0) {
                    nextCurrentStep = ds.getValue(0, "currentmovementstep", "");
                    if ("".equals(nextCurrentStep))
                        throw new SapphireException("Sample next step not found.");

                    nextStep = ds.getValue(0, "stepname", "");
                    if ("Path Support".equalsIgnoreCase(nextStep)) {
                        String workdepartment = ds.getValue(0, "workingdept", "");
                        String worktrsmstop = "Path Support COC";
                        processNextStep(sampleId, "PathSupport", workdepartment, worktrsmstop);
                    } /**FORCE FULLY MOVE TO ANOTHER STEPS*/
                    else if ("QC".equalsIgnoreCase(nextStep)) {
                        keyid1 = ds.getColumnValues("u_sampletestcodestpmapid", ";");
                        if (!"".equals(keyid1)) {
                            completePreviousStep(sampleId, keyid1);
                            ds.clear();
                            ds = getQueryProcessor().getSqlDataSet(sql);
                            if (ds != null && ds.size() > 0) {
                                nextCurrentStep = ds.getValue(0, "currentmovementstep", "");
                                if ("".equals(nextCurrentStep))
                                    throw new SapphireException("Sample next step not found.");

                                nextStep = ds.getValue(0, "stepname", "");
                                String specimentype = ds.getValue(0, "specimentype", "");
                                if ("Imaging".equalsIgnoreCase(nextStep) && "Stained Slide".equalsIgnoreCase(specimentype)) {
                                    String workdepartment = ds.getValue(0, "workingdept", "");
                                    String worktrsmstop = "IHC Imaging";
                                    processNextStep(sampleId, "IHCImaging", workdepartment, worktrsmstop);
                                }
                                if ("Path Support".equalsIgnoreCase(nextStep)) {
                                    String workdepartment = ds.getValue(0, "workingdept", "");
                                    String worktrsmstop = "Path Support COC";
                                    processNextStep(sampleId, "PathSupport", workdepartment, worktrsmstop);
                                }
                            }
                        }
                    } else {
                        processNextStep(sampleId, nextCurrentStep, ds.getValue(0, "workingdept", ""), ds.getValue(0, "workingtramstop", ""));
                    }
                    //nextStep = ds.getValue(0, "stepname", "");
                }
            }
        }

        return nextStep;
    }

    public void completePreviousStep(String sampleId, String sampletestcodestpmapid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodestpmapid);
        pl.setProperty("status", "Completed");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    public void processNextStep(String sampleId, String nextStep, String departmentId, String tramstop) throws
            SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
        pl.setProperty("u_currentmovementstep", nextStep);

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

        String workingDepartment = departmentId;
        if (!departmentId.contains("-"))
            workingDepartment = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0] + "-" + departmentId;

        pl.clear();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
        pl.setProperty("custodialuserid", "(null)");
        pl.setProperty("custodialdepartmentid", workingDepartment);
        pl.setProperty("u_currenttramstop", tramstop);

        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);

    }

    private void updateImagingDtAnalyte(String sampleid) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_PARAMS_IMAGINGDT, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsImagingDt = getQueryProcessor().getSqlDataSet(sql);
        if (dsImagingDt != null && dsImagingDt.size() > 0) {
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
            Date date = new Date();
            String crrntdt = formatter.format(date);
            PropertyList props = new PropertyList();
            props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsImagingDt.getColumnValues("childsampleid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsImagingDt.getColumnValues("paramlistid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsImagingDt.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsImagingDt.getColumnValues("paramid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsImagingDt.getColumnValues("variantid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsImagingDt.getColumnValues("paramtype", ";"));
            props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsImagingDt.getColumnValues("replicateid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_DATASET, dsImagingDt.getColumnValues("dataset", ";"));
            props.setProperty("enteredtext", StringUtil.repeat(crrntdt.toUpperCase(), dsImagingDt.size(), ";"));
            props.setProperty("displayvalue", StringUtil.repeat(crrntdt.toUpperCase(), dsImagingDt.size(), ";"));
            try {
                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException("IHC Imaging date  not performed." + e.getMessage());
            }
        }
    }
}

