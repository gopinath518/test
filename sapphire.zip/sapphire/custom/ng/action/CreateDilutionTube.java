package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;


/**
 * Created by msubhra on 6/9/2016.
 */
public class CreateDilutionTube extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleids = properties.getProperty("s_sampleid");

        String newsampleids = StringUtil.replaceAll(sampleids,";","','");
        String testcode = properties.getProperty("lvtestcodeid");

        String sql = "select distinct testcode from u_sampletestcodemap where s_sampleid in ('"+newsampleids+"')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        //HashMap hm = new HashMap();
        String testCodeID = ds.getColumnValues("testcode",";");

        properties.setProperty("testcode",testCodeID);
        properties.setProperty("sampleids",newsampleids);
        //getServletContext().getRequestDispatcher("/ajax.jsp").forward(request, response);

    }


}
