package sapphire.custom.ng.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by Subhendu on 17/02/2017
 * BlockShippingRule is use to move block from blookroom to readytoship
 * 
 */
public class BlockShippingRule extends BaseAction {
	
	static final long DAY = 24 * 60 * 60 * 1000;
	static HashMap<String, ArrayList<String>> methodologyLosMapping = new HashMap<String, ArrayList<String>>() {
		{
			put("IHC", new ArrayList<String>() {
				{
					add("Consult");
					add("Technical Scan");
					add("Scope");
					add("Technical Scan Qualitative");
					add("Technical Scan Quantitative");
					add("Technical IA");
				}
			});
			put("Molecular", new ArrayList<String>() {
				{
					add("ANY");
				}
			});
		}
	};

    public void processAction(PropertyList properties) throws SapphireException {
    	
    	DataSet ds = getQualifiedBlockSample();
    	sendSampleForShippingRule(ds);

    }
    /* This method will filter all the records that are qualified for Block shipping rule*/
    private DataSet getQualifiedBlockSample( ) throws SapphireException{
    	DataSet ds = null;
		try {
			String sql = "select s_sample.s_sampleid,u_sampletestcodemap.methodology, u_sampletestcodemap.los, s_sample.u_imagingdts, "
					+ " to_char( s_sample.u_reportingdts,'dd-mm-yyyy HH24:mm') reportsigndt "
					+ " from s_sample,u_sampletestcodemap where s_sample.u_currentmovementstep = 'BlockMgmt' "
					+ " and s_sample.s_sampleid = u_sampletestcodemap.s_sampleid and (u_sampletestcodemap.teststatus = 'Completed' or u_sampletestcodemap.teststatus = 'Cancelled') ";

			ds = getQueryProcessor().getSqlDataSet(sql);
			if(ds == null || ds.size() == 0){
				Logger.logInfo("No records qualified for Block shipping Rule:: check getQualifiedBlockSample method for more information.");
				throw new SapphireException("No records qualified for Block shipping Rule", ErrorDetail.TYPE_INFORMATION);
			}
				
		} catch (Exception e) {
			Logger.logError("Error occured while executing:: getQualifiedBlockSample method ::"+e.getMessage());
			throw new SapphireException("Error occured while executing:: getQualifiedBlockSample method ::"+e.getMessage(), ErrorDetail.TYPE_VALIDATION);
		}
		return ds;
    }
    
    /* The filter datatset will be received and corresponding rule will be fired based upon the methodology and los*/ 
    private void sendSampleForShippingRule(DataSet ds) throws SapphireException{
		try {
			HashMap<String, String> hm = new HashMap<>();
			DataSet filterDataSet = new DataSet();
			DataSet finalDS = new DataSet();

			for (Map.Entry<String, ArrayList<String>> entry : methodologyLosMapping.entrySet()) {
				String key = entry.getKey();
				ArrayList<String> value = entry.getValue();
				for (String los : value) {
					hm.clear();
					hm.put("methodology", key);
					if (!"Molecular".equalsIgnoreCase(key))
						hm.put("los", los);
					filterDataSet.clear();
					filterDataSet = ds.getFilteredDataSet(hm);
					if (filterDataSet != null && filterDataSet.size() > 0) {
						if ("IHC".equalsIgnoreCase(key)) {
							if ("Consult".equalsIgnoreCase(los))
								ruleForIHCConsult(finalDS, filterDataSet);
							else if (los.equalsIgnoreCase("Technical Scan Qualitative") || los.equalsIgnoreCase("Technical Scan Quantitative") || los.equalsIgnoreCase("Technical IA"))
								ruleForIHCTechnical(finalDS,filterDataSet);
//							else if ("Scope".equalsIgnoreCase(los))
//								ruleForIHCScope(finalDS, filterDataSet);
							else
								finalDS.copyRow(filterDataSet, -1, 1);
						}else if ("Molecular".equalsIgnoreCase(key)) {
							finalDS.copyRow(filterDataSet, -1, 1);
						}
					}
				}
			}
			if(finalDS != null && finalDS.size()>0)
				sendBlocksToShip(finalDS);
			else
				Logger.logInfo("There is no Sample Data ready to Ship.");
		} catch (Exception e) {
			Logger.logError("Error occured while executing:: sendSampleForShippingRule method ::"+e.getMessage());
			throw new SapphireException("Error occured while executing:: sendSampleForShippingRule method ::"+e.getMessage(), ErrorDetail.TYPE_VALIDATION);
		}
    }
    
    /* Shipping Rule for Methodology: IHC and Los: Consult*/
    private void ruleForIHCConsult(DataSet finalDS, DataSet filterDataSet) throws SapphireException{
		try {
			for (int i = 0; i < filterDataSet.size(); i++) {
				String reportSignDt = filterDataSet.getValue(i, "reportsigndt");
				if (dateDiff(reportSignDt, DAY)) {
					finalDS.copyRow(filterDataSet, i, 1);
				}
			}
		} catch (Exception e) {
			Logger.logError("Error occured while executing:: ruleForIHCConsult method ::" + e.getMessage());
			throw new SapphireException("Error occured while executing:: ruleForIHCConsult method ::" + e.getMessage(),	ErrorDetail.TYPE_VALIDATION);
		}
    }
    
    /* Shipping Rule for Methodology: IHC and Los: Scope::  */
    private void ruleForIHCScope(DataSet finalDS, DataSet filterDataSet) throws SapphireException{
		try {
			for (int i = 0; i < filterDataSet.size(); i++) {
				String reportSignDt = filterDataSet.getValue(i, "reportsigndt");
				if (!dateDiff(reportSignDt, 8 * DAY)) {
					finalDS.copyRow(filterDataSet, i, 1);
				}
			}
		} catch (Exception e) {
			Logger.logError("Error occured while executing:: ruleForIHCTechnical method ::" + e.getMessage());
			throw new SapphireException("Error occured while executing:: ruleForIHCTechnical method ::" + e.getMessage(), ErrorDetail.TYPE_VALIDATION);
		}
    }
    
    /* Shipping Rule for Methodology: IHC and Los: Technical Scan Qualitative, Technical Scan Quantitative, Technical IA */
    private void  ruleForIHCTechnical( DataSet finalDS, DataSet filterDataSet) throws SapphireException{
    	DataSet imgDtDS = new DataSet();
    	DataSet tempDS = new DataSet();
    	try {
    		String rootSampleIds = filterDataSet.getColumnValues("s_sampleid", ";");
			String sql = "select cs.u_rootsample s_sampleid,cs.imgdt from (select u_rootsample,  case when exists "
			+ "(select * FROM s_sample where u_imagingdts IS NULL  and u_rootsample = ss.u_rootsample  and u_type ='U')  then 'F'  ELSE 'T'   END AS imgdt "
			+ " FROM s_sample ss  where u_rootsample IN('"+StringUtil.replaceAll(rootSampleIds, ";", "','")+"')  and u_type ='U') cs group by cs.u_rootsample";
			
			imgDtDS =  getQueryProcessor().getSqlDataSet(sql);
			if(imgDtDS == null || imgDtDS.size() == 0){
				Logger.logError("Error occured while executing:: ruleForIHCTechnical method :: Imaging Date not found" );
				throw new SapphireException("Error occured while executing:: ruleForIHCTechnical method :: Imaging Date not found", ErrorDetail.TYPE_INFORMATION);
			}
			HashMap<String, String> hm = new HashMap<String,String>(){{
				put("imgdt","T"); 
			}};
			tempDS = imgDtDS.getFilteredDataSet(hm);
			finalDS.copyRow(tempDS, -1, 1);
			
		} catch (Exception e) {
			Logger.logError("Error occured while executing:: ruleForIHCTechnical method ::" + e.getMessage());
			throw new SapphireException("Error occured while executing:: ruleForIHCTechnical method ::" + e.getMessage(), ErrorDetail.TYPE_VALIDATION);
		}
//    	return tempDS;
    }
    /* Qualified Block is ready to Ship */ 
    private void sendBlocksToShip(DataSet finalDS) throws SapphireException{
        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", finalDS.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_currentmovementstep", "ReadyToShip");

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception e) {
        	Logger.logError("Error occured while executing:: sendBlocksToShip method in editing Sample ::" + e.getMessage());
			throw new SapphireException("Error occured while executing:: sendBlocksToShip method in editing Sample ::" + e.getMessage(), ErrorDetail.TYPE_VALIDATION);
        }
        //Edit Trackitem
        try {
            prop.clear();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, finalDS.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_currenttramstop", "ReadyToShip");
            prop.setProperty("custodialuserid", "(null)");
//            prop.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (Exception e) {
        	Logger.logError("Error occured while executing:: sendBlocksToShip method in editing TrackItem ::" + e.getMessage());
			throw new SapphireException("Error occured while executing:: sendBlocksToShip method in editing TrackItem ::" + e.getMessage(), ErrorDetail.TYPE_VALIDATION);
        }
    }
    
	private boolean dateDiff(String dt, long val) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm");
			Date theDate = format.parse(dt);
			return (System.currentTimeMillis() - DAY) > theDate.getTime();

		} catch (ParseException e) {
			Logger.logError("Report Date:: "+dt+"::Report Date Parse Exception ::"+ e.getMessage());
			return false;
		}
	}
}
