package sapphire.custom.ng.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class BreastFixation extends BaseAction {

    public static final String ID = "BreastFixation";
    public static final String VERSION_ID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid", "");

        if (accessionid == null || accessionid.equalsIgnoreCase("")) {
            throw new SapphireException("Accessionid is blank");
        }

        validateBreastData(accessionid);
    }

    private void validateBreastData(String accessionid) throws SapphireException {

        String sqlRootSample = "select u_sampletestcodemap.s_sampleid, u_sampletestcodemap.coldischemictime, u_sampletestcodemap.neutralbufferedformalin, "
                + "u_sampletestcodemap.fixationduration, u_testcode.clienttestcodeid "
                + " from u_sampletestcodemap,u_testcode where "
                + " u_sampletestcodemap.lvtestcodeid = u_testcode .u_testcodeid and u_sampletestcodemap.s_sampleid in(select s_sampleid from s_sample where "
                + " u_accessionid='" + accessionid + "' and u_rootsample is null) "
                + " and u_testcode.clienttestcodeid in ('3093X','3094X','3097X') ";

        DataSet dsQuery = getQueryProcessor().getSqlDataSet(sqlRootSample);

        if (dsQuery != null && dsQuery.size() > 0) {
            String resultTestCode = checkTestCode(dsQuery);
            if ("HER2".equals(resultTestCode) || "EPH".equals(resultTestCode)) {

                HashMap<String, String> hm = new HashMap<String, String>();
                hm.put("coldischemictime", null);
                DataSet dsFilter = dsQuery.getFilteredDataSet(hm);

                if (dsFilter.size() > 0)
                    throw new SapphireException("Breast Fixation Rule: Please enter value in Cold Ischemic Time field for the samples - " + Util.getUniqueList(dsFilter.getColumnValues("s_sampleid", ","), ",", true));

                dsFilter.clear();

                hm.clear();
                hm.put("neutralbufferedformalin", null);
                dsFilter = dsQuery.getFilteredDataSet(hm);

                if (dsFilter.size() > 0)
                    throw new SapphireException("Breast Fixation Rule: Please enter value in Neutral Buffered Formalin field for the samples - " + Util.getUniqueList(dsFilter.getColumnValues("s_sampleid", ","), ",", true));

                dsFilter.clear();

                hm.clear();
                hm.put("fixationduration", null);
                dsFilter = dsQuery.getFilteredDataSet(hm);

                if (dsFilter.size() > 0)
                    throw new SapphireException("Breast Fixation Rule: Please enter value in Fixation Duration field for the samples - " + Util.getUniqueList(dsFilter.getColumnValues("s_sampleid", ","), ",", true));

                dsFilter.clear();
            }
        }
    }

    private String checkTestCode(DataSet dsQuery) {
        String testCode = dsQuery.getColumnValues("clienttestcodeid", ";");
        List<String> uniqueTestCodeList = new ArrayList<String>(new HashSet<String>(Arrays.asList(testCode.split(";"))));
        List<String> list = new ArrayList<String>() {
            {
                add("3093X");
                add("3094X");
                add("3097X");
            }
        };

        for (String val : uniqueTestCodeList) {
            if (list.contains(val))
                list.remove(val);
        }
        if (list != null && list.size() == 0)
            return "EPH"; // EP/PR/Her2 test codes are present
        else if (list != null && !list.contains("3094X"))
            return "HER2"; // Only Her2 test code is present
        else
            return "Test Code missing";
    }
}


