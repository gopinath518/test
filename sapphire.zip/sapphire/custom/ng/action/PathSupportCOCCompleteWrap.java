package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.ArrayList;
import java.util.HashMap;

public class PathSupportCOCCompleteWrap extends BaseAction {
    private DataSet dsFish = null;
    private String displayMsg = "";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");
        String custodialuserid = properties.getProperty("custodialuserid");
        String u_currenttramstop = properties.getProperty("u_currenttramstop");
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid");
        if (Util.isNull(custodialdepartmentid)) {
            String currentDepartment = connectionInfo.getDefaultDepartment();
            String site = currentDepartment.substring(0, currentDepartment.indexOf("-"));
            custodialdepartmentid = site + "-Accessioning";
        }
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String losdetail = Util.parseMessage(ApSql.GET_LOS_BY_SPECIMEN, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsLosDetail = getQueryProcessor().getSqlDataSet(losdetail);
        if (dsLosDetail == null || dsLosDetail.size() == 0) {
            throw new SapphireException("No testcode(s) associated with the specimen(s).");
        }
        initializeDataSet();
        HashMap hm = new HashMap();
        //MOLECULAR
        hm.clear();
        hm.put("methodology", "Molecular");
        DataSet dsMolecularFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsMolecularFilter != null && dsMolecularFilter.size() > 0) {
            molecularSpecimenRouting(dsMolecularFilter);
            //properties.setProperty("msg", msg);
        }
        //FISH
        hm.clear();
        hm.put("methodology", "FISH");
        DataSet dsFISHFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsFISHFilter != null && dsFISHFilter.size() > 0) {
            fishMethodology(dsFISHFilter);
            //properties.setProperty("msg", "Operation successful.");
        }
        //CYTOGENETICS
        hm.clear();
        hm.put("methodology", "Cytogenetics");
        DataSet dsCytoFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsCytoFilter != null && dsCytoFilter.size() > 0) {
            //PathSupportCOCComplete
            PropertyList props = new PropertyList();
            props.setProperty("sampleid", dsCytoFilter.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currentmovementstep", u_currentmovementstep);
            props.setProperty("custodialuserid", custodialuserid);
            props.setProperty("u_currenttramstop", u_currenttramstop);
            props.setProperty("custodialdepartmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to perform CYTOGENETICS specimen complete." + ex.getMessage());
            }
            //CYTO DISPLAY MESSAGE
            for (int i = 0; i < dsCytoFilter.size(); i++) {
                int rowwID = dsDisplay.addRow();
                dsDisplay.setValue(rowwID, "specimen_id", dsCytoFilter.getValue(i, "s_sampleid", ""));
                dsDisplay.setValue(rowwID, "methodology", "Cytogenetics");
                dsDisplay.setValue(rowwID, "tramstop", u_currenttramstop);
                dsDisplay.setValue(rowwID, "department", custodialdepartmentid);
            }
            //properties.setProperty("msg", "Operation successful.");
        }
        //Flow
        hm.clear();
        hm.put("methodology", "Flow");
        DataSet dsFlowFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsFlowFilter != null && dsFlowFilter.size() > 0) {
            //PathSupportCOCComplete
            PropertyList props = new PropertyList();
            props.setProperty("sampleid", dsFlowFilter.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currentmovementstep", u_currentmovementstep);
            props.setProperty("custodialuserid", custodialuserid);
            props.setProperty("u_currenttramstop", u_currenttramstop);
            props.setProperty("custodialdepartmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to perform Flow specimen complete." + ex.getMessage());
            }
            //FLOW DISPLAY MESSAGE
            for (int i = 0; i < dsFlowFilter.size(); i++) {
                int rowwID = dsDisplay.addRow();
                dsDisplay.setValue(rowwID, "specimen_id", dsFlowFilter.getValue(i, "s_sampleid", ""));
                dsDisplay.setValue(rowwID, "methodology", "Flow");
                dsDisplay.setValue(rowwID, "tramstop", u_currenttramstop);
                dsDisplay.setValue(rowwID, "department", custodialdepartmentid);
            }
            //properties.setProperty("msg", "Operation successful.");
        }
        //Multiomyx
        hm.clear();
        hm.put("methodology", "Multiomyx");
        DataSet dsMultiomyxFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsMultiomyxFilter != null && dsMultiomyxFilter.size() > 0) {
            //PathSupportCOCComplete
            PropertyList props = new PropertyList();
            props.setProperty("sampleid", dsMultiomyxFilter.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currentmovementstep", u_currentmovementstep);
            props.setProperty("custodialuserid", custodialuserid);
            props.setProperty("u_currenttramstop", u_currenttramstop);
            props.setProperty("custodialdepartmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to perform Multiomyx specimen complete." + ex.getMessage());
            }
            //MO DISPLAY MESSAGE
            for (int i = 0; i < dsMultiomyxFilter.size(); i++) {
                int rowwID = dsDisplay.addRow();
                dsDisplay.setValue(rowwID, "specimen_id", dsMultiomyxFilter.getValue(i, "s_sampleid", ""));
                dsDisplay.setValue(rowwID, "methodology", "Multiomyx");
                dsDisplay.setValue(rowwID, "tramstop", u_currenttramstop);
                dsDisplay.setValue(rowwID, "department", custodialdepartmentid);
            }
            //properties.setProperty("msg", "Operation successful.");
        }
        //Generic
        hm.clear();
        hm.put("methodology", "Generic");
        DataSet dsGenericFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsGenericFilter != null && dsGenericFilter.size() > 0) {
            String gensampleid = dsGenericFilter.getColumnValues("s_sampleid", ";");
            String sql = Util.parseMessage(ApSql.GET_SAMPLESTEPS_ROUTING,
                    StringUtil.replaceAll(gensampleid, ";", "','"),
                    StringUtil.replaceAll(gensampleid, ";", "','"),
                    StringUtil.replaceAll(gensampleid, ";", "','"),
                    StringUtil.replaceAll(gensampleid, ";", "','"));

            DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
            for (int i = 0; i < dsInfo.size(); i++) {
                String stepname = dsInfo.getValue(i, "stepname", "");
                String currentmovementstep = dsInfo.getValue(i, "currentmovementstep", "");
                String u_sampletestcodestpmapid = dsInfo.getValue(i, "u_sampletestcodestpmapid", "");
                String slidetype = dsInfo.getValue(i, "slidetype", "");
                String workingdept = dsInfo.getValue(i, "workingdept", "");
                String workingtramstop = dsInfo.getValue(i, "workingtramstop", "");

                if ("Path Support COC".equalsIgnoreCase(stepname)) {
                    PropertyList props = new PropertyList();
                    props.setProperty("sampleid", gensampleid);
                    try {
                        getActionProcessor().processAction("IHCFlowCompleteStep", "1", props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to perform IHC specimen complete." + ex.getMessage());
                    }
                    int rowwID = dsDisplay.addRow();
                    dsDisplay.setValue(rowwID, "specimen_id", gensampleid);
                    dsDisplay.setValue(rowwID, "methodology", "Generic");
                    dsDisplay.setValue(rowwID, "tramstop", "Molecular COC");
                    dsDisplay.setValue(rowwID, "department", "Molecular");
                } else {
                    PropertyList props = new PropertyList();
                    props.setProperty("sampleid", gensampleid);
                    props.setProperty("u_currentmovementstep", u_currentmovementstep);
                    props.setProperty("custodialuserid", custodialuserid);
                    props.setProperty("u_currenttramstop", u_currenttramstop);
                    props.setProperty("custodialdepartmentid", custodialdepartmentid);
                    try {
                        getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to perform IHC specimen complete." + ex.getMessage());
                    }
                    int rowwID = dsDisplay.addRow();
                    dsDisplay.setValue(rowwID, "specimen_id", gensampleid);
                    dsDisplay.setValue(rowwID, "methodology", "Generic");
                    dsDisplay.setValue(rowwID, "tramstop", u_currenttramstop);
                    dsDisplay.setValue(rowwID, "department", custodialdepartmentid);
                }
            }
            //PathSupportCOCComplete
            /*PropertyList props = new PropertyList();
            props.setProperty("sampleid", dsGenericFilter.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currentmovementstep", u_currentmovementstep);
            props.setProperty("custodialuserid", custodialuserid);
            props.setProperty("u_currenttramstop", u_currenttramstop);
            props.setProperty("custodialdepartmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to perform IHC specimen complete." + ex.getMessage());
            }
            //IHC DISPLAY MESSAGE
            for (int i = 0; i < dsGenericFilter.size(); i++) {
                int rowwID = dsDisplay.addRow();
                dsDisplay.setValue(rowwID, "specimen_id", dsGenericFilter.getValue(i, "s_sampleid", ""));
                dsDisplay.setValue(rowwID, "methodology", "Generic");
                dsDisplay.setValue(rowwID, "tramstop", u_currenttramstop);
                dsDisplay.setValue(rowwID, "department", custodialdepartmentid);
            }*/
            //properties.setProperty("msg", "Operation successful.");
        }
        //IHC
        hm.clear();
        hm.put("methodology", "IHC");
        DataSet dsIHCFilter = dsLosDetail.getFilteredDataSet(hm);
        if (dsIHCFilter != null && dsIHCFilter.size() > 0) {
            //PathSupportCOCComplete
            PropertyList props = new PropertyList();
            props.setProperty("sampleid", dsIHCFilter.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_currentmovementstep", u_currentmovementstep);
            props.setProperty("custodialuserid", custodialuserid);
            props.setProperty("u_currenttramstop", u_currenttramstop);
            props.setProperty("custodialdepartmentid", custodialdepartmentid);
            try {
                getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to perform IHC specimen complete." + ex.getMessage());
            }
            //IHC DISPLAY MESSAGE
            for (int i = 0; i < dsIHCFilter.size(); i++) {
                int rowwID = dsDisplay.addRow();
                dsDisplay.setValue(rowwID, "specimen_id", dsIHCFilter.getValue(i, "s_sampleid", ""));
                dsDisplay.setValue(rowwID, "methodology", "IHC");
                dsDisplay.setValue(rowwID, "tramstop", u_currenttramstop);
                dsDisplay.setValue(rowwID, "department", custodialdepartmentid);
            }
            //properties.setProperty("msg", "Operation successful.");
        }
        if (dsDisplay != null && dsDisplay.size() > 0) {
            displayMsg = Util.getDisplayMessage("Specimen(s) are routed successfully.", dsDisplay);
        }
        properties.setProperty("msg", displayMsg);
        //throw new SapphireException("text");
    }

    private void fishMethodology(DataSet dsFISHFilter) throws SapphireException {
        if (dsFish == null) {
            dsFish = new DataSet();
            dsFish.addColumn("s_sampleid", DataSet.STRING);
            dsFish.addColumn("currentmovementstep", DataSet.STRING);
            dsFish.addColumn("currenttramstop", DataSet.STRING);
        }

        String fishSamples = dsFISHFilter.getColumnValues("s_sampleid", ";");
        String sql = Util.parseMessage(ApSql.GET_U_TYPE, StringUtil.replaceAll(fishSamples, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        if (dsSql == null || dsSql.getRowCount() == 0) {
            throw new SapphireException("Specimens doesn't have Type.");
        }
        int rowID = 0;
        for (int i = 0; i < dsSql.size(); i++) {
            rowID = dsFish.addRow();
            dsFish.setValue(rowID, "s_sampleid", dsSql.getValue(i, "s_sampleid"));
            String type = dsSql.getValue(i, "u_type");
            if (("U".equalsIgnoreCase(type)) || ("CU".equalsIgnoreCase(type))) {
                dsFish.setValue(rowID, "currentmovementstep", "FISHQC");
                dsFish.setValue(rowID, "currenttramstop", "FISHQC");
            } else if (("H".equalsIgnoreCase(type)) || ("CH".equalsIgnoreCase(type))) {
                dsFish.setValue(rowID, "currentmovementstep", "FISHReceiveHNE");
                dsFish.setValue(rowID, "currenttramstop", "FISHReceiveHNE");
            }
        }
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
        String custdepartment = site + "-FISH";
        PropertyList props = new PropertyList();
        props.setProperty("sampleid", dsFish.getColumnValues("s_sampleid", ";"));
        props.setProperty("u_currentmovementstep", dsFish.getColumnValues("currentmovementstep", ";"));
        props.setProperty("custodialuserid", "");
        props.setProperty("u_currenttramstop", dsFish.getColumnValues("currenttramstop", ";"));
        props.setProperty("custodialdepartmentid", custdepartment);
        try {
            getActionProcessor().processAction("PathSupportCOCComplete", "1", props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to perform FISH specimen complete." + ex.getMessage());
        }
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFish.getColumnValues("s_sampleid", ";"));
        //props.setProperty("u_currenttramstop", StringUtil.repeat(u_currenttramstop, dsFilterN.size(), ";"));
        props.setProperty("custodialuserid", "");
        props.setProperty("custodialdepartmentid", StringUtil.repeat(custdepartment, dsFish.size(), ";"));//added
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("EditTrackItem Action failed" + e.getMessage());
        }
        //FISH DISPLAY MESSAGE
        for (int i = 0; i < dsFish.size(); i++) {
            int rowwID = dsDisplay.addRow();
            dsDisplay.setValue(rowwID, "specimen_id", dsFish.getValue(i, "s_sampleid", ""));
            dsDisplay.setValue(rowwID, "methodology", "FISH");
            dsDisplay.setValue(rowwID, "tramstop", dsFish.getValue(i, "currenttramstop", ""));
            dsDisplay.setValue(rowwID, "department", custdepartment);
        }
    }

    private DataSet getMolecularCOCCompletePolicy() throws SapphireException {
        String currentDepartment = connectionInfo.getDefaultDepartment();
        String site = currentDepartment.substring(0, currentDepartment.indexOf("-"));
        DataSet dsPloicy = new DataSet();
        int incr = 0;
        dsPloicy.addColumn("type", DataSet.STRING);
        dsPloicy.addColumn("methodology", DataSet.STRING);
        dsPloicy.addColumn("currentmovementstep", DataSet.STRING);
        dsPloicy.addColumn("currenttramstop", DataSet.STRING);
        dsPloicy.addColumn("custodialdept", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("MicrotomyCompletePolicy", "MolPathSupportCOCComplete");
        PropertyListCollection plcRoutingrules = plMicroPolicy.getCollection("routingrules");
        for (int i = 0; i < plcRoutingrules.size(); i++) {
            incr = dsPloicy.addRow();
            PropertyListCollection plcConditions = plcRoutingrules.getPropertyList(i).getCollection("conditions");
            PropertyListCollection plcColumnvaluepair = plcConditions.getPropertyList(0).getCollection("columnvaluepair");
            for (int j = 0; j < plcColumnvaluepair.size(); j++) {
                String column = plcColumnvaluepair.getPropertyList(j).getProperty("column");
                String value = plcColumnvaluepair.getPropertyList(j).getProperty("value");
                if (column.equalsIgnoreCase("u_type")) {
                    dsPloicy.setValue(incr, "type", value);
                } else {
                    dsPloicy.setValue(incr, "methodology", value);
                }
            }
            String currentmovementstep = plcConditions.getPropertyList(0).getProperty("currentmovementstep");
            String currenttramstop = plcConditions.getPropertyList(0).getProperty("currenttram");
            String custodialdept = plcConditions.getPropertyList(0).getProperty("custodiandept");
            dsPloicy.setValue(incr, "currentmovementstep", currentmovementstep);
            dsPloicy.setValue(incr, "currenttramstop", currenttramstop);
            dsPloicy.setValue(incr, "custodialdept", site + "-" + custodialdept);
        }
        return dsPloicy;
    }

    private void molecularSpecimenRouting(DataSet dsMolecularFilter) throws SapphireException {
        String currentDepartment = connectionInfo.getDefaultDepartment();
        String site = currentDepartment.substring(0, currentDepartment.indexOf("-"));
        String custodialdepartmentid = site + "-Molecular";
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("specimen_id", DataSet.STRING);
        dsFinal.addColumn("methodology", DataSet.STRING);
        dsFinal.addColumn("current_step", DataSet.STRING);
        dsFinal.addColumn("tramstop", DataSet.STRING);
        dsFinal.addColumn("department", DataSet.STRING);
        DataSet dsCOCComplete = getMolecularCOCCompletePolicy();
        HashMap hm = new HashMap();
        for (int i = 0; i < dsMolecularFilter.size(); i++) {
            String methodolgy = dsMolecularFilter.getValue(i, "methodology", "");
            String utype = dsMolecularFilter.getValue(i, "u_type", "");
            String sampletypeid = dsMolecularFilter.getValue(i, "sampletypeid", "");
            hm.clear();
            hm.put("methodology", methodolgy);
            hm.put("type", utype);
            DataSet dsTypeFilter = dsCOCComplete.getFilteredDataSet(hm);
            if (dsTypeFilter.size() > 0 /*&& !"FFPE scrolls".equalsIgnoreCase(sampletypeid)*/) {
                int rowID = dsFinal.addRow();
                dsFinal.setValue(rowID, "specimen_id", dsMolecularFilter.getValue(i, "s_sampleid", ""));
                dsFinal.setValue(rowID, "methodology", dsMolecularFilter.getValue(i, "methodology", ""));
                dsFinal.setValue(rowID, "current_step", dsTypeFilter.getValue(0, "currentmovementstep", ""));
                dsFinal.setValue(rowID, "tramstop", dsTypeFilter.getValue(0, "currenttramstop", ""));
                dsFinal.setValue(rowID, "department", dsTypeFilter.getValue(0, "custodialdept", ""));
            } /*else {
                int rowID = dsFinal.addRow();
                dsFinal.setValue(rowID, "specimen_id", dsMolecularFilter.getValue(i, "s_sampleid", ""));
                dsFinal.setValue(rowID, "methodology", dsMolecularFilter.getValue(i, "methodology", ""));
                dsFinal.setValue(rowID, "current_step", "Pre-Extraction");
                dsFinal.setValue(rowID, "tramstop", "Molecular COC");
                dsFinal.setValue(rowID, "department", custodialdepartmentid);
            }*/
        }
        if (dsFinal != null && dsFinal.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("specimen_id", ";"));
            props.setProperty("u_currentmovementstep", dsFinal.getColumnValues("current_step", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update movement step." + ex.getMessage());
            }
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues("specimen_id", ";"));
            props.setProperty("custodialdepartmentid", dsFinal.getColumnValues("department", ";"));
            props.setProperty("u_currenttramstop", dsFinal.getColumnValues("tramstop", ";"));
            props.setProperty("custodialuserid", "(null)");
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to take custody." + ex.getMessage());
            }
            for (int i = 0; i < dsFinal.size(); i++) {
                int rowID = dsDisplay.addRow();
                dsDisplay.setValue(rowID, "specimen_id", dsFinal.getValue(i, "specimen_id", ""));
                dsDisplay.setValue(rowID, "methodology", dsFinal.getValue(i, "methodology", ""));
                dsDisplay.setValue(rowID, "tramstop", dsFinal.getValue(i, "tramstop", ""));
                dsDisplay.setValue(rowID, "department", dsFinal.getValue(i, "department", ""));
            }
        }
    }

    private DataSet dsDisplay = null;

    private void initializeDataSet() throws SapphireException {
        if (dsDisplay == null) {
            dsDisplay = new DataSet();
            dsDisplay.addColumn("specimen_id", DataSet.STRING);
            dsDisplay.addColumn("methodology", DataSet.STRING);
            dsDisplay.addColumn("tramstop", DataSet.STRING);
            dsDisplay.addColumn("department", DataSet.STRING);
        }
    }
}
