package sapphire.custom.ng.action.exomess;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class ExportDilution extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String tramstop = properties.getProperty("tramstop", "");
        if (Util.isNull(batchid))
            throw new SapphireException("Please choose batch first");
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLE_BY_BATCH, batchid);
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo != null && dsBatchInfo.size() > 0) {
            String filelocation = getFileLocation();
            if (filelocation == null || Util.isNull(filelocation)) {
                throw new SapphireException("Default Location is not defined in molecular.");
            }
            String batchname = dsBatchInfo.getValue(0, "batchname", "");
            if (filelocation.endsWith("/"))
                filelocation = filelocation;
            else
                filelocation = filelocation + File.separator;

            String filenameformat = filelocation + tramstop + "_Dilution_" + batchname + "_" + generateFileName(batchid, batchname) + ".xlsx";
            /*sql = CommonSql.GET_FILE_BASE_PATH;
            DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
            if (dsBasePath == null || dsBasePath.size() == 0) {
                throw new SapphireException("Base path not find into the system");
            }
            String baseloc = dsBasePath.getValue(0, "propvalue");
            String filelocation = Util.generateLocationPath(baseloc, filenameformat, "Molecular", tramstop);*/

            generateCsvFile(filenameformat, dsBatchInfo, tramstop);
            logger.info("XLS has been generated for ExomeSS");
            PropertyList attachprop = new PropertyList();
            attachprop.clear();
            attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Dummy");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "Dilution Calculation");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "Dilution Calculation");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenameformat);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "U");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filenameformat).getName());
            attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");
            attachprop.setProperty("ATTACHMENTCLASS", "SOP");
            attachprop.setProperty("SOURCEFILENAME", filenameformat);
            try {
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. Attachment not added.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
            sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_NANOSTRING_REPORT, batchid);
            DataSet dsAttachmnt = getQueryProcessor().getSqlDataSet(sql);
            int attachnum = Integer.parseInt(dsAttachmnt.getValue(0, "attachmentnum", "0"));
            String url = "rc?command=ViewAttachment&sdcid=Dummy&keyid1=" + batchid + "&keyid2=Dilution Calculation&keyid3=Dilution Calculation&attachmentnum=" + attachnum + "&download=Y";
            String msg = "<script>window.open('" + url + "', '_blank');</script>";
            properties.setProperty("msg", "Operation Successful. File has been downloaded." + msg);
            PropertyList prop = new PropertyList();
            prop.setProperty("id", batchid);
            prop.setProperty("location", filenameformat);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "InventoryReportingTempDeleteAction");
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n+1");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }

    private static void generateCsvFile(String localtionfilename, DataSet dsInputs, String tramstop) {
        int rownum = 0;
        XSSFSheet firstSheet;
        Collection<File> files;
        XSSFWorkbook workbook;
        File exactFile;
        workbook = new XSSFWorkbook();
        //SET CELL STYLE
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        style.setFont(font);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        //SET ALL BORDER
        CellStyle borderStyle = workbook.createCellStyle();
        borderStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        firstSheet = workbook.createSheet(tramstop + " Dilution Calc.");
        Row headerRow = firstSheet.createRow(rownum);
        headerRow.setHeightInPoints(40);
        List<String> headerRoww = new ArrayList<String>();
        headerRoww.add("NeoGenomics ID");
        headerRoww.add("Conc. (ng/µL)");
        headerRoww.add("1:10 Dilution (ng/µL)");
        headerRoww.add("Amt of Specimen to Add (µL)");
        headerRoww.add("Amt of H2O (µL)");
        headerRoww.add("Input (ng)");
        List<List> recordToAdd = new ArrayList<List>();
        recordToAdd.add(headerRoww);
        for (int i = 0; i < dsInputs.size(); i++) {
            String u_extractionid = dsInputs.getValue(i, "u_extractionid");
            String concentration = dsInputs.getValue(i, "concentration", "");
            String sampledilution = dsInputs.getValue(i, "sampledilution");
            String amtofsample = dsInputs.getValue(i, "amtofsample");
            String amtofwater = dsInputs.getValue(i, "amtofwater");
            String sampleinput = dsInputs.getValue(i, "sampleinput");
            List<String> firstRow = new ArrayList<String>();
            firstRow.add(u_extractionid);
            firstRow.add(concentration);
            firstRow.add(sampledilution);
            firstRow.add(amtofsample);
            firstRow.add(amtofwater);
            firstRow.add(sampleinput);
            recordToAdd.add(firstRow);
        }
        FileOutputStream fos = null;
        try {
            for (int j = 0; j < recordToAdd.size(); j++) {
                if (rownum == 0) {
                    Row row = firstSheet.createRow(rownum);
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        Cell cell = row.createCell(k);
                        cell.setCellValue(l2.get(k));
                        cell.setCellStyle(style);
                    }
                } else {
                    Row row = firstSheet.createRow(rownum);
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        Cell cell = row.createCell(k);
                        cell.setCellValue(l2.get(k));
                        cell.setCellStyle(borderStyle);
                    }
                }
                rownum++;
            }
            fos = new FileOutputStream(new File(localtionfilename));
            //AUTO SIZE COLUMN
            int rowcol = 0;
            for (int j = 0; j < recordToAdd.size(); j++) {
                if (rowcol == 0) {
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        firstSheet.autoSizeColumn(k);
                    }
                }
                rowcol++;
            }
            /*firstSheet.autoSizeColumn(0);
            firstSheet.autoSizeColumn(1);
            firstSheet.autoSizeColumn(2);
            firstSheet.autoSizeColumn(3);
            firstSheet.autoSizeColumn(4);
            firstSheet.autoSizeColumn(5);*/
            workbook.write(fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

    }

    private String generateFileName(String batchid, String batchname) throws SapphireException {
        String latestfilename = "";
        String sql = MolecularSql.GET_ATTACHMENT_BY_BATCHID_EXOME;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsAttachmentInfo = getQueryProcessor().getSqlDataSet(sql);
        int attachmentcount = dsAttachmentInfo.size();
        String tails = "A";
        if (attachmentcount == 0) {
            char c = tails.charAt(0);
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        } else {
            int c = tails.charAt(0) + attachmentcount;
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        }
        return latestfilename;
    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        //CHECK FOLDER
        //fileLocation = "C:\\Temp";
        fileLocation = Util.createFolderForMolecular(fileLocation, "ExomeSS");
        return fileLocation;
    }
}
