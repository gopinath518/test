package sapphire.custom.ng.action.exomess;

import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class AddSpecimenToBatch extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String batchid = properties.getProperty("batchid");

        if (Util.isNull(sampleid))
            throw new SapphireException("Please scan specimen(s).");
        if (Util.isNull(batchid))
            throw new SapphireException("Batch ID can not be blank.");
        String sql = Util.parseMessage(MolecularSql.GET_EXOMESS_SAMPLES, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsValidateSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsValidateSample != null && dsValidateSample.size() > 0) {
            sampleid = dsValidateSample.getColumnValues("s_sampleid", ";");
            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
            props.setProperty("sampleid", dsValidateSample.getColumnValues("s_sampleid", ";"));
            props.setProperty("testcodeid", dsValidateSample.getColumnValues("lvtestcodeid", ";"));
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            try {
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to add specimen(s) into the batch.");
            }
            updateSpecimenType(sampleid);
        } else {
            throw new SapphireException("Invalid specimen/does not have Exome SS testcode/Specimen(s) are not in Capture.");
        }
        properties.setProperty("msg", "Specimen(s) is/are successfully added into the batch.");
    }

    private void updateSpecimenType(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("u_currentmovementstep", "CaptureCompleted");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update movement step for the specimen(s)");
            }
        }
    }
}
