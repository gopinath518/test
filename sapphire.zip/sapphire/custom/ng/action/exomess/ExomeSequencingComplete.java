package sapphire.custom.ng.action.exomess;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ExomeSequencingComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sdcid = properties.getProperty("sdcid");
        String keyid1 = properties.getProperty("keyid1");
        String batchcompletedts = properties.getProperty("batchcompletedts");//TODO WORKFLOW TYPE (EXOME SS)
        String batchcompleteflag = properties.getProperty("batchcompleteflag");//TODO WHERE PARENT BATCH TO GO(HISTORICAL BATCH)
        String batchtype = properties.getProperty("batchtype"); //TODO WHERE CHILD BATCH TO GO(NEXT TRAMSTOP)
        String batchmovestatus = properties.getProperty("batchmovestatus");//TODO WHERE PARENT BATCH TO GO(HISTORICAL BATCH)
        String batchstatusview = properties.getProperty("batchstatusview");//TODO WHERE CHILD BATCH TO GO(NEXT TRAMSTOP)

        if (Util.isNull(keyid1)) {
            throw new SapphireException("Batch id is not selected.");
        }

        PropertyList editbatch = new PropertyList();
        editbatch.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
        editbatch.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
        editbatch.setProperty("batchtype", batchtype);
        editbatch.setProperty("batchmovestatus", batchmovestatus);
        editbatch.setProperty("batchstatusview", batchstatusview);
        editbatch.setProperty("batchcompletedts", batchcompletedts);
        editbatch.setProperty("batchcompleteflag", batchcompleteflag);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editbatch);
        } catch (SapphireException se) {
            throw new SapphireException("Can not update Batch");
        }
        String sql = Util.parseMessage(MolecularSql.GET_ELUTIONTUBE_BY_BATCHID, keyid1);
        DataSet dsElutionTube = getQueryProcessor().getSqlDataSet(sql);
        if (dsElutionTube.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsElutionTube.getColumnValues("elutiontube", ";"));
            props.setProperty("u_currentmovementstep", StringUtil.repeat("ExomeSSReporting", dsElutionTube.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not update elution tube");
            }
        }
    }
}
