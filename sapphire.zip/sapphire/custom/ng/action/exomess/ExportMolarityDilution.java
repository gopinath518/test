package sapphire.custom.ng.action.exomess;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ExportMolarityDilution extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String tramstop = properties.getProperty("tramstop", "");
        if (Util.isNull(batchid))
            throw new SapphireException("Please choose batch first");

        String sql = Util.parseMessage(MolecularSql.GET_MOLARITY_CAL_BY_BATCHID, batchid);
        DataSet dsMolarityBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsMolarityBatchInfo != null && dsMolarityBatchInfo.size() > 0) {
            String filelocation = getFileLocation();
            //String filelocation = "C:\\Temp";
            if (filelocation == null || Util.isNull(filelocation)) {
                throw new SapphireException("Default Location is not defined in molecular.");
            }
            String batchname = dsMolarityBatchInfo.getValue(0, "batchname", "");
            if (filelocation.endsWith("/"))
                filelocation = filelocation;
            else
                filelocation = filelocation + File.separator;

            String filenameformat = filelocation + tramstop + "_Dilution_" + batchname + "_" + generateFileName(batchid) + ".xlsx";
            generateCsvFile(filenameformat, dsMolarityBatchInfo, tramstop);
            logger.info("XLS has been generated for ExomeSS");
            PropertyList attachprop = new PropertyList();
            attachprop.clear();
            attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Dummy");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "Molarity Calculation");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "Molarity Calculation");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenameformat);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "U");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filenameformat).getName());
            attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");
            attachprop.setProperty("ATTACHMENTCLASS", "SOP");
            attachprop.setProperty("SOURCEFILENAME", filenameformat);
            try {
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. Attachment not added.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
            //DOWNLOADED EXPORT FILE
            sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_NANOSTRING_REPORT, batchid);
            DataSet dsAttachmnt = getQueryProcessor().getSqlDataSet(sql);
            int attachnum = Integer.parseInt(dsAttachmnt.getValue(0, "attachmentnum", "0"));
            String url = "rc?command=ViewAttachment&sdcid=Dummy&keyid1=" + batchid + "&keyid2=Molarity Calculation&keyid3=Molarity Calculation&attachmentnum=" + attachnum + "&download=Y";
            String msg = "<script>window.open('" + url + "', '_blank');</script>";
            properties.setProperty("msg", "Operation Successful. File has been downloaded." + msg);
            PropertyList prop = new PropertyList();
            prop.setProperty("id", batchid);
            prop.setProperty("location", filenameformat);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "InventoryReportingTempDeleteAction");
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n+1");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }

    private static void generateCsvFile(String localtionfilename, DataSet dsInputs, String tramstop) {
        int rownum = 0;
        XSSFSheet firstSheet;
        Collection<File> files;
        XSSFWorkbook workbook;
        File exactFile;
        workbook = new XSSFWorkbook();
        //SET CELL STYLE
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        style.setFont(font);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        //SET ALL BORDER
        CellStyle borderStyle = workbook.createCellStyle();
        borderStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        firstSheet = workbook.createSheet(tramstop + "-Molarity Calculation");
        Row headerRow = firstSheet.createRow(rownum);
        headerRow.setHeightInPoints(40);
        List<String> headerRoww = new ArrayList<String>();
        headerRoww.add("NeoGenomics ID");
        headerRoww.add("Data Returned Status");
        headerRoww.add("Size on Bioanalyzer(bp)");
        headerRoww.add("Conc. on Bioanalyzer (nmol/L)");
        headerRoww.add("Conc. on Bioanalyzer (ng/ul)");
        headerRoww.add("Quant-iT Conc. (ng/ul)");
        headerRoww.add("Conc. A/C Quant-iT(nmol/L)");
        headerRoww.add("ul stock to dilute");
        headerRoww.add("Conc. Desired (nM)");
        headerRoww.add("ul TE to dilute");
        List<List> recordToAdd = new ArrayList<List>();
        recordToAdd.add(headerRoww);
        for (int i = 0; i < dsInputs.size(); i++) {
            String u_extractionid = dsInputs.getValue(i, "u_extractionid", "");
            String datereturnstatus = dsInputs.getValue(i, "datereturnstatus", "");
            String size_of_bioanalyzer_bp = dsInputs.getValue(i, "size_of_bioanalyzer_bp", "");
            String conc_on_bioanalyzer_nm_l = dsInputs.getValue(i, "conc_on_bioanalyzer_nm_l", "");
            String conc_on_bioanalyzer_ng_ul = dsInputs.getValue(i, "conc_on_bioanalyzer_ng_ul", "");
            String quant_it_con_ng_ul = dsInputs.getValue(i, "quant_it_con_ng_ul", "");
            String nmol_l = dsInputs.getValue(i, "nmol_l", "");
            String conc_desired_nm = dsInputs.getValue(i, "conc_desired_nm", "");
            String ul_slock_to_dilute = dsInputs.getValue(i, "ul_slock_to_dilute", "");
            String ul_te_to_dilute = dsInputs.getValue(i, "ul_te_to_dilute", "");

            List<String> firstRow = new ArrayList<String>();
            firstRow.add(u_extractionid);
            firstRow.add(datereturnstatus);
            firstRow.add(size_of_bioanalyzer_bp);
            firstRow.add(conc_on_bioanalyzer_nm_l);
            firstRow.add(conc_on_bioanalyzer_ng_ul);
            firstRow.add(quant_it_con_ng_ul);
            firstRow.add(nmol_l);
            firstRow.add(conc_desired_nm);
            firstRow.add(ul_slock_to_dilute);
            firstRow.add(ul_te_to_dilute);
            recordToAdd.add(firstRow);
        }
        FileOutputStream fos = null;
        try {
            for (int j = 0; j < recordToAdd.size(); j++) {
                if (rownum == 0) {
                    Row row = firstSheet.createRow(rownum);
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        Cell cell = row.createCell(k);
                        cell.setCellValue(l2.get(k));
                        cell.setCellStyle(style);
                    }
                } else {
                    Row row = firstSheet.createRow(rownum);
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        Cell cell = row.createCell(k);
                        cell.setCellValue(l2.get(k));
                        cell.setCellStyle(borderStyle);
                    }
                }
                rownum++;
            }
            fos = new FileOutputStream(new File(localtionfilename));
            //AUTO SIZE COLUMN
            int rowcol = 0;
            for (int j = 0; j < recordToAdd.size(); j++) {
                if (rowcol == 0) {
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        firstSheet.autoSizeColumn(k);
                    }
                }
                rowcol++;
            }

            workbook.write(fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

    }

    private String generateFileName(String batchid) throws SapphireException {
        String latestfilename = "";
        String sql = MolecularSql.GET_ATTACHMENT_BY_BATCHID_EXOME_MOLARITY;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsAttachmentInfo = getQueryProcessor().getSqlDataSet(sql);
        int attachmentcount = dsAttachmentInfo.size();
        String tails = "A";
        if (attachmentcount == 0) {
            char c = tails.charAt(0);
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        } else {
            int c = tails.charAt(0) + attachmentcount;
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        }
        return latestfilename;
    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        //CHECK FOLDER
        //fileLocation = "C:\\Temp";
        fileLocation = Util.createFolderForMolecular(fileLocation, "ExomeSS");
        return fileLocation;
    }
}
