package sapphire.custom.ng.action.exomess;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ExomeSSMoveBack extends BaseAction {

    String msg = "Operation Successful.\n";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("ngbatchid", "");
        String sampleids = properties.getProperty("sampleid", "");
        String totramstop = properties.getProperty("totramstop", "");
        String currentmovementstep = properties.getProperty("currentmovementstep", "");
        String sql = Util.parseMessage(MolecularSql.GET_ELUTION_BY_DILUTION, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsElution = getQueryProcessor().getSqlDataSet(sql);
        if (dsElution == null || dsElution.size() == 0) {
            throw new SapphireException("System does not found Elution tube for selected Dilution Tube.");
        }
        DataSet dsDisplayMsg = new DataSet();
        dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
        dsDisplayMsg.addColumn("extraction_id", DataSet.STRING);
        dsDisplayMsg.addColumn("specimen_type", DataSet.STRING);
        dsDisplayMsg.addColumn("tramstop", DataSet.STRING);

        PropertyList prop = new PropertyList();
        prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        prop.setProperty("sampleid", sampleids);
        prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
        } catch (SapphireException se) {
            throw new SapphireException("Samples not moved back");
        }
        if ("QuantCompleted".equalsIgnoreCase(totramstop)) {
            PropertyList sample = new PropertyList();
            sample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            sample.setProperty(EditSDI.PROPERTY_KEYID1, dsElution.getColumnValues("s_sampleid", ";"));
            sample.setProperty("u_currentmovementstep", StringUtil.repeat(currentmovementstep, dsElution.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, sample);
            } catch (SapphireException se) {
                throw new SapphireException("Samples not moved back");
            }
            if (dsElution.size() > 0) {
                for (int i = 0; i < dsElution.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsElution.getValue(i, "s_sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "extraction_id", dsElution.getValue(i, "u_extractionid", ""));
                    dsDisplayMsg.setValue(rowID, "specimen_type", "Elution Tube");
                    dsDisplayMsg.setValue(rowID, "tramstop", "Library Prep Specimen");
                }
            }
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
            props.setProperty("u_currentmovementstep", "Disposed");
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("disposaldt", "n");
            props.setProperty("disposedby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canceled specimen(s).");
            }
            if (dsDisplayMsg.size() > 0) {
                msg += Util.getDisplayMessage("Below specimen(s) has/have been routed:", dsDisplayMsg);
            }
            properties.setProperty("msg", msg);
        } else if ("Capture".equalsIgnoreCase(totramstop)) {
            String[] pSampleArry = StringUtil.split(sampleids, ";");
            PropertyList props = new PropertyList();
            props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, sampleids);
            props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", pSampleArry.length, ";"));
            props.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "concentration;u_rootsample;u_molbatchspecimenid;sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;u_pathologycomments;u_extractioncomments");
            props.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
            props.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
            try {
                getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Unable to create dilution tube");
            }
            String dilutionTubes = props.getProperty(AddSDI.RETURN_NEWKEYID1, "");
            PropertyList sample = new PropertyList();
            sample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            sample.setProperty(EditSDI.PROPERTY_KEYID1, dilutionTubes);
            sample.setProperty("u_currentmovementstep", StringUtil.repeat(currentmovementstep, StringUtil.split(dilutionTubes, ";").length, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, sample);
            } catch (SapphireException se) {
                throw new SapphireException("Unable to move specimen(s) to " + totramstop);
            }
            Util.copyTestCodeFromParent(dilutionTubes, getQueryProcessor(), getActionProcessor());
            updateSpecimenType(dilutionTubes);
            sql = Util.parseMessage(MolecularSql.GET_DETAILS_DILUTION, StringUtil.replaceAll(dilutionTubes, ";", "','"));
            DataSet dsDilution = getQueryProcessor().getSqlDataSet(sql);
            if (dsDilution.size() > 0) {
                for (int i = 0; i < dsDilution.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "specimen_id", dsDilution.getValue(i, "s_sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "extraction_id", dsDilution.getValue(i, "u_extractionid", ""));
                    dsDisplayMsg.setValue(rowID, "specimen_type", dsDilution.getValue(i, "specimentype", ""));
                    dsDisplayMsg.setValue(rowID, "tramstop", dsDilution.getValue(i, "u_currentmovementstep", ""));
                }
            }
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
            props.setProperty("u_currentmovementstep", "Disposed");
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("disposaldt", "n");
            props.setProperty("disposedby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canceled specimen(s).");
            }
            if (dsDisplayMsg.size() > 0) {
                msg += Util.getDisplayMessage("Below specimen(s) has/have been routed:", dsDisplayMsg);
            }
            properties.setProperty("msg", msg);
        }
        //throw new SapphireException("Test");
    }

    private void updateSpecimenType(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("containertypeid", "Dilution Tube");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("specimentype", "Dilution Tube");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
    }
}
