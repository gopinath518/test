package sapphire.custom.ng.action.exomess;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDIDetail;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.DecimalFormat;
import java.util.HashMap;

public class ExomeSSConcentration extends BaseAction {

    private static DecimalFormat ONE_DECIMAL_FORMAT = new DecimalFormat(".#");

    public void processAction(PropertyList properties) throws SapphireException {
        String samples = properties.getProperty("sample", "");
        String concentration = properties.getProperty("concentration", "");
        if (Util.isNull(samples)) {
            throw new SapphireException("Specimens can't be null.");
        }
        if (Util.isNull(concentration)) {
            throw new SapphireException("Concentration Values can't be null.");
        }
        initializeDataSet();
        samples = Util.getUniqueList(samples, ";", true);
        String extractionids = StringUtil.replaceAll(samples, ";", "','");
        String sql = Util.parseMessage(MolecularSql.GET_EXOMESS_BY_EXTRACTID, extractionids, extractionids);
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() == 0) {
            String errStr = getTranslationProcessor().translate("Parse specimen(s) does not belongs with any batch. Please check again.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String batchid = Util.getUniqueList(dsBatchInfo.getColumnValues("u_ngbatchid", ";"), ";", true);
        //createDataSet(properties.getProperty("sample"), properties.getProperty("concentration"), batchid, dsBatchInfo);
        createDataSet(dsBatchInfo.getColumnValues("u_extractionid", ";"), properties.getProperty("concentration"), batchid, dsBatchInfo);
        valiadteSpecimenReadingCount();
        saveQuantItValueToDB();
        calculateDilution(batchid);
        //throw new SapphireException("test");
    }

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_EXTARCTIONID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CONCENTRATION, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_BATCHID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_INSTRUMENTID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_READ_COUNT, DataSet.STRING);
        }
    }

    /**
     * Description: This method is only used for create dataset
     *
     * @param concentration
     * @param batchid
     * @throws SapphireException
     */
    private void createDataSet(String extractionids, String concentration, String batchid, DataSet dsBatchInfo) throws SapphireException {
        String extractionidsArr[] = StringUtil.split(extractionids, ";");
        String concentrationArr[] = StringUtil.split(concentration, ";");
        for (int i = 0; i < extractionidsArr.length; i++) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("u_extractionid", extractionidsArr[i]);
            DataSet dsFiletr = dsBatchInfo.getFilteredDataSet(hm);
            String sampleid = dsFiletr.getValue(0, "s_sampleid", "");
            double doblconc = Double.parseDouble(concentrationArr[i]);
            int rowID = dsFinal.addRow();
            dsFinal.setValue(rowID, DATASET_PROPERTY_EXTARCTIONID, extractionidsArr[i]);
            dsFinal.setValue(rowID, DATASET_PROPERTY_CONCENTRATION, ONE_DECIMAL_FORMAT.format(doblconc));
            dsFinal.setValue(rowID, DATASET_PROPERTY_BATCHID, batchid);
            dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, sampleid);
            dsFinal.setValue(rowID, DATASET_PROPERTY_INSTRUMENTID, "Day1Quantit");
        }
    }

    /**
     * Description : This is used to get and validate specimen reading with the uploaded file
     * and from the database.
     *
     * @throws SapphireException
     */
    private void valiadteSpecimenReadingCount() throws SapphireException {
        if (dsFinal.size() > 0) {

            String sampleid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"), ";", true);
            String extractionid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_EXTARCTIONID, ";"), ";", true);
            String parsebatchid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_BATCHID, ";"), ";", true);
            String instrumentid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_INSTRUMENTID, ";"), ";", true);

            String sql = Util.parseMessage(MolecularSql.NanodropPARSER_ATTACHEDCOUNT_BY_COMBINATION, StringUtil.replaceAll(parsebatchid, ";", "','"),
                    StringUtil.replaceAll(instrumentid, ";", "','"), StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsReadingInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsReadingInfo.size() > 0 || dsReadingInfo.size() == 0) {
                String arryExtarction[] = StringUtil.split(extractionid, ";");
                for (int i = 0; i < arryExtarction.length; i++) {
                    HashMap hm = new HashMap();
                    hm.clear();
                    hm.put(DATASET_PROPERTY_EXTARCTIONID, arryExtarction[i]);
                    DataSet dsFileterMain = dsFinal.getFilteredDataSet(hm);
                    int parseSpecimenCount = dsFileterMain.size();
                    hm.clear();
                    hm.put("extractionid", arryExtarction[i]);
                    DataSet dsFileterInstrument = dsReadingInfo.getFilteredDataSet(hm);
                    int dbSpecimenCount = dsFileterInstrument.size();
                    if (parseSpecimenCount > 3) {
                        String errStr = getTranslationProcessor().translate("You can't upload more than 3 records of specimen(s): " + arryExtarction[i]);
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                    }
                    if (dbSpecimenCount >= 3) {
                        String errStr = getTranslationProcessor().translate("<b>You can't upload more than 3 records of specimen(s): " + arryExtarction[i] + "</b>");
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                    }
                    int balncReadingCount = 3 - dbSpecimenCount;
                    if (parseSpecimenCount > balncReadingCount) {
                        String errStr = getTranslationProcessor().translate("<b>You can upload reading " + balncReadingCount + " time(s) more of specimen(s): " + arryExtarction[i] + "</b>");
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                    }
                }
            }
            for (int i = 0; i < dsFinal.size(); i++) {
                String specimenid = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID);
                String ngbatchid = dsFinal.getValue(i, DATASET_PROPERTY_BATCHID);
                String instrumentused = dsFinal.getValue(i, DATASET_PROPERTY_INSTRUMENTID);

                if (!bufferSpecimen.equalsIgnoreCase(specimenid)) {
                    //incr = 0;
                    specCount = readingCountByCombination(specimenid, ngbatchid, instrumentused);
                } else {
                    //incr = (incr + 1);
                    //specCount = specCount + incr;
                    specCount = specCount + 1;
                }
                dsFinal.setValue(i, DATASET_PROPERTY_READ_COUNT, "" + specCount);
            }
        }
    }

    /**
     * Description: This is used to count and validate specimen reading records.
     *
     * @param sampleid
     * @param batchid
     * @param instrumentid
     * @throws SapphireException
     */
    private int readingCountByCombination(String sampleid, String batchid, String instrumentid) throws SapphireException {
        int count = 0;
        String sql = Util.parseMessage(MolecularSql.NanodropPARSER_ATTACHEDCOUNT_BY_COMBINATION, batchid, instrumentid, sampleid);
        DataSet dsReadingInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsReadingInfo.size() == 0) {
            bufferSpecimen = sampleid;
            count = dsReadingInfo.size();
        }
        if (dsReadingInfo.size() > 0) {
            bufferSpecimen = sampleid;
            count = dsReadingInfo.size();
        }
        return count + 1;
    }

    /**
     * Description : Parse XLS file coming from Quant-iT instrument to Database.
     *
     * @throws : SapphireException
     */
    private void saveQuantItValueToDB() throws SapphireException {
        if (dsFinal == null || dsFinal.size() == 0) {
            throw new SapphireException("Main DataSet doesn't have any Values");
        }

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "InstrumentQuantific");
        props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsFinal.size()));
        props.setProperty("u_ngbatchid", dsFinal.getColumnValues(DATASET_PROPERTY_BATCHID, ";"));
        props.setProperty("sampleid", dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
        props.setProperty("extractionid", dsFinal.getColumnValues(DATASET_PROPERTY_EXTARCTIONID, ";"));
        props.setProperty("concentration", dsFinal.getColumnValues(DATASET_PROPERTY_CONCENTRATION, ";"));
        props.setProperty("u_instrumentused", dsFinal.getColumnValues(DATASET_PROPERTY_INSTRUMENTID, ";"));
        props.setProperty("uploadcount", dsFinal.getColumnValues(DATASET_PROPERTY_READ_COUNT, ";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in InstrumentQuantific");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }

    }

    private void calculateDilution(String batchid) throws SapphireException {
        if (dsFinal != null && dsFinal.size() > 0) {
            DataSet dsDilutionCal = new DataSet();
            dsDilutionCal.addColumn("dilutiontube", DataSet.STRING);
            dsDilutionCal.addColumn("concentration", DataSet.STRING);
            dsDilutionCal.addColumn("amntofsample", DataSet.STRING);
            dsDilutionCal.addColumn("amntofwater", DataSet.STRING);
            dsDilutionCal.addColumn("inputvol", DataSet.STRING);
            dsDilutionCal.addColumn("sampledilution", DataSet.STRING);

            String dilutiontube = dsFinal.getColumnValues("sampleid", ";");
            String sql = Util.parseMessage(MolecularSql.GET_SAMPLE_BY_DILUTIONTUBE, StringUtil.replaceAll(dilutiontube, ";", "','"));
            DataSet dsDilutionInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsDilutionInfo.size() > 0) {
                double fxdval = 200.0;
                for (int i = 0; i < dsDilutionInfo.size(); i++) {
                    String dilutube = dsDilutionInfo.getValue(i, "s_sampleid");
                    double dilutionratio = 0.0;
                    double amntofwater = 0.0;
                    double inputvol = 0.0;
                    double concentration = Double.parseDouble(dsDilutionInfo.getValue(i, "concentration", "0.0"));
                    double amntofsample = fxdval / concentration;
                    if (amntofsample < 2) {
                        dilutionratio = concentration / 10;
                        //amntofsample = 200 / dilutionratio;
                        amntofwater = 51.0 - amntofsample;
                        inputvol = dilutionratio * amntofsample;
                    } else {
                        amntofwater = 51.0 - amntofsample;
                        inputvol = concentration * amntofsample;
                    }
                    if (dilutionratio < 0) {
                        dilutionratio = 0.0;
                    } else if (amntofwater < 0) {
                        amntofwater = 0.0;
                    } else if (inputvol < 0) {
                        inputvol = 0.0;
                    } else if (concentration < 0) {
                        concentration = 0.0;
                    } else if (amntofsample < 0) {
                        amntofsample = 0.0;
                    }
                    int rowID = dsDilutionCal.addRow();
                    dsDilutionCal.setValue(rowID, "dilutiontube", dilutube);
                    dsDilutionCal.setValue(rowID, "concentration", String.valueOf(ONE_DECIMAL_FORMAT.format(concentration)));
                    dsDilutionCal.setValue(rowID, "amntofsample", String.valueOf(ONE_DECIMAL_FORMAT.format(amntofsample)));
                    dsDilutionCal.setValue(rowID, "amntofwater", String.valueOf(ONE_DECIMAL_FORMAT.format(amntofwater)));
                    dsDilutionCal.setValue(rowID, "inputvol", String.valueOf(ONE_DECIMAL_FORMAT.format(inputvol)));
                    dsDilutionCal.setValue(rowID, "sampledilution", String.valueOf(ONE_DECIMAL_FORMAT.format(dilutionratio)));
                }
            }
            if (dsDilutionCal != null && dsDilutionCal.size() > 0) {
                PropertyList proptag = new PropertyList();
                proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
                proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, batchid);
                proptag.setProperty("sampleid", dsDilutionCal.getColumnValues("dilutiontube", ";"));
                proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                proptag.setProperty("amtofsample", dsDilutionCal.getColumnValues("amntofsample", ";"));
                proptag.setProperty("amtofwater", dsDilutionCal.getColumnValues("amntofwater", ";"));
                proptag.setProperty("sampleinput", dsDilutionCal.getColumnValues("inputvol", ";"));
                proptag.setProperty("sampledilution", dsDilutionCal.getColumnValues("sampledilution", ";"));
                proptag.setProperty("rulebypass", "Y");

                try {
                    getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
                } catch (SapphireException se) {
                    throw new SapphireException("Can not edit batch detail");
                }
            }
        }
    }

    String bufferSpecimen = "";
    int incr = 0;
    int specCount = 0;
    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_EXTARCTIONID = "extractionid";
    private static final String DATASET_PROPERTY_CONCENTRATION = "concentration";
    private static final String DATASET_PROPERTY_BATCHID = "batchid";
    private static final String DATASET_PROPERTY_INSTRUMENTID = "instrumentid";
    private static final String DATASET_PROPERTY_READ_COUNT = "samplereadcount";
}
