package sapphire.custom.ng.action.exomess;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CreateMolarityBatch extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String dilutiontube = properties.getProperty("sampleid", "");
        String batchname = properties.getProperty("batchname", "");
        String sql = Util.parseMessage(MolecularSql.GET_DATA_BY_SAMPLEID, StringUtil.replaceAll(dilutiontube, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo != null && dsInfo.size() > 0) {
            String batchid = createBatch(batchname);
            //String childdilutiontube = createDilutionTube(dilutiontube, batchid);
            //updateSpecimenType(childdilutiontube);
            updateDilutionCurrentMovement(dilutiontube);
            associateIntoBatch(batchid, dilutiontube);
            updateElutionMovemnetStep(dilutiontube);
            molarityCalculation(batchid);
            createPoolSamplePerBatch(batchid, dilutiontube);

        }
        properties.setProperty("msg", "Molarity batch <b>" + batchname + "</b> has been successfully created.");
        //throw new SapphireException("test");
    }

    private String createBatch(String batchname) throws SapphireException {
        String ngbatchid = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchname", batchname);
        pl.setProperty("origin", "Molarity");
        pl.setProperty("batchmovestatus", "MolarityBatch");
        pl.setProperty("batchstatusview", "MolarityBatch");
        pl.setProperty("batchtype", "ExomeSS");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");
        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }

    private String createDilutionTube(String elutiontube, String batchid) throws SapphireException {
        String[] eliArry = StringUtil.split(elutiontube, ";");
        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, elutiontube);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", eliArry.length, ";"));
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "u_additionalbodysite;u_aliquotinfo;u_molbatchspecimenid;u_rootsample;sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_pathologycomments;u_extractioncomments");
        prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
        prop.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);

        String dilutionTubes = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples/Single parent -------------------
        Util.setRootForPoolSample(dilutionTubes, elutiontube, getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        return dilutionTubes;
    }

    private void updateSpecimenType(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("containertypeid", "Dilution Tube");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("specimentype", "Dilution Tube");
            props.setProperty("u_currentmovementstep", "CaptureCompleted");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
    }

    private void updateDilutionCurrentMovement(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("u_currentmovementstep", "MolarityCompleted");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
    }

    private void updateElutionMovemnetStep(String elutiontube) throws SapphireException {
        if (elutiontube.length() > 0) {
            String sql = Util.parseMessage(MolecularSql.GET_ELU_BY_DILUTE, StringUtil.replaceAll(elutiontube, ";", "','"));
            DataSet dsElution = getQueryProcessor().getSqlDataSet(sql);
            if (dsElution.size() > 0) {
                PropertyList props = new PropertyList();
                props.clear();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsElution.getColumnValues("elutiontube", ";"));
                props.setProperty("u_currentmovementstep", "MolarityCompleted");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
        }
    }

    private void associateIntoBatch(String batchid, String childdilutiontube) throws SapphireException {
        DataSet dsChildDile = calculationDilutions(childdilutiontube, "CaptureBatch");
        PropertyList proptag = new PropertyList();
        proptag.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        proptag.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        proptag.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        proptag.setProperty("sampleid", dsChildDile.getColumnValues("s_sampleid", ";"));
        proptag.setProperty("amtofsample", dsChildDile.getColumnValues("amtofsample", ";"));
        proptag.setProperty("amtofwater", dsChildDile.getColumnValues("amtofwater", ";"));
        proptag.setProperty("sampleinput", dsChildDile.getColumnValues("sampleinput", ";"));
        proptag.setProperty("sampledilution", dsChildDile.getColumnValues("sampledilution", ";"));
        proptag.setProperty("rulebypass", "Y");
        proptag.setProperty("ispooledflag", "N");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, proptag);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail" + se.getMessage());
        }
        String sql = Util.parseMessage(MolecularSql.GET_MOLA_DILU, StringUtil.replaceAll(childdilutiontube, ";", "','"));
        DataSet dsChildParent = getQueryProcessor().getSqlDataSet(sql);
        if (dsChildParent.size() > 0) {
            proptag.clear();
            proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
            proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, batchid);
            proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            proptag.setProperty("sampleid", dsChildParent.getColumnValues("childsample", ";"));
            proptag.setProperty("averagesize", dsChildParent.getColumnValues("childaveragesize", ";"));
            proptag.setProperty("bioanalizerconc1", dsChildParent.getColumnValues("childbioanalizerconc1", ";"));
            proptag.setProperty("stocktodilute", StringUtil.repeat("2.0", dsChildParent.size(), ";"));
            proptag.setProperty("concdesired", StringUtil.repeat("2.0", dsChildParent.size(), ";"));
            proptag.setProperty("rulebypass", "Y");
            try {
                getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
            } catch (SapphireException se) {
                throw new SapphireException("Can not edit batch detail" + se.getMessage());
            }
        }
        /*PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        props.setProperty("sampleid", childdilutiontube);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);*/
    }

    private DataSet calculationDilutions(String childdilutiontube, String tramstopname) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_DILUTION_TUBE_INFO, StringUtil.replaceAll(childdilutiontube, ";", "','"));
        DataSet dsChildParent = getQueryProcessor().getSqlDataSet(sql);
        if (!dsChildParent.isValidColumn("amtofsample"))
            dsChildParent.addColumn("amtofsample", DataSet.STRING);

        if (!dsChildParent.isValidColumn("amtofwater"))
            dsChildParent.addColumn("amtofwater", DataSet.STRING);

        if (!dsChildParent.isValidColumn("sampleinput"))
            dsChildParent.addColumn("sampleinput", DataSet.STRING);

        if (!dsChildParent.isValidColumn("sampledilution"))
            dsChildParent.addColumn("sampledilution", DataSet.STRING);

        if (dsChildParent != null && dsChildParent.size() > 0) {
            for (int i = 0; i < dsChildParent.size(); i++) {
                String parentconc = dsChildParent.getValue(i, "concentration", "0.0");
                String elutionvol = dsChildParent.getValue(i, "elutionvol", "0.0");
                if (!Util.isNull(parentconc)) {
                    //double fxdval = 200.0;//TODO NOT REQUIRED AS THIS IS CONFIGURABLE TRAMSTOP WISE INTO PROJECT LEVEL.
                    double dilutionratio = 0.0;
                    double amntofwater = 0.0;
                    double inputvol = 0.0;
                    double fxdval = 0.0;
                    double fxdstaticval = 0.0;
                    if ("LibraryPrep".equalsIgnoreCase(tramstopname) || "LibraryPrepQuant".equalsIgnoreCase(tramstopname)) {
                        fxdval = 250.0;
                        fxdstaticval = 51.0;
                    } else if ("CaptureBatch".equalsIgnoreCase(tramstopname) || "CaptureBatchQuant".equalsIgnoreCase(tramstopname)
                            || "Molarity".equalsIgnoreCase(tramstopname) || "Sequencing".equalsIgnoreCase(tramstopname)) {
                        fxdval = 750.0;
                        fxdstaticval = 51.0;
                    } else {
                        fxdval = 200.0;
                        fxdstaticval = 51.0;
                    }
                    double concentration = Double.parseDouble(parentconc);
                    double amntofsample = 0.0;
                    if (concentration > 0) {
                        amntofsample = fxdval / concentration;
                        amntofsample = Util.roundAvoid(amntofsample);
                    } else {
                        amntofsample = 0.0;
                    }

                    if (concentration > 0 && amntofsample < 2) {
                        dilutionratio = concentration / 10;
                        dilutionratio = Util.roundAvoid(dilutionratio);

                        amntofsample = fxdval / dilutionratio;
                        amntofsample = Util.roundAvoid(amntofsample);

                        amntofwater = fxdstaticval - amntofsample;
                        amntofwater = Util.roundAvoid(amntofwater);

                        inputvol = dilutionratio * amntofsample;
                        inputvol = Util.roundAvoid(inputvol);
                    } else {
                        amntofwater = Util.roundAvoid(fxdstaticval - amntofsample);
                        inputvol = Util.roundAvoid(concentration * amntofsample);
                    }
                    if (amntofsample > Double.parseDouble(elutionvol)) {
                        amntofsample = Double.parseDouble(elutionvol);

                        amntofwater = fxdstaticval - amntofsample;
                        amntofwater = Util.roundAvoid(amntofwater);

                        inputvol = dilutionratio * amntofsample;
                        inputvol = Util.roundAvoid(inputvol);
                    }
                    if (dilutionratio < 0) {
                        dilutionratio = 0.0;
                    } else if (amntofwater < 0) {
                        amntofwater = 0.0;
                    } else if (inputvol < 0) {
                        inputvol = 0.0;
                    } else if (concentration < 0) {
                        concentration = 0.0;
                    } else if (amntofsample < 0) {
                        amntofsample = 0.0;
                    }
                    if (Double.isInfinite(dilutionratio))
                        dilutionratio = 0.0;
                    if (Double.isInfinite(amntofwater))
                        amntofwater = 0.0;
                    if (Double.isInfinite(inputvol))
                        inputvol = 0.0;
                    if (Double.isInfinite(amntofwater))
                        amntofwater = 0.0;
                    if (Double.isInfinite(inputvol))
                        inputvol = 0.0;
                    //SET VALUE
                    dsChildParent.setValue(i, "amtofsample", String.valueOf(amntofsample));
                    dsChildParent.setValue(i, "amtofwater", String.valueOf(amntofwater));
                    dsChildParent.setValue(i, "sampleinput", String.valueOf(inputvol));
                    dsChildParent.setValue(i, "sampledilution", String.valueOf(dilutionratio));
                }
            }
            //UPDATE DATA
        }
        return dsChildParent;
    }

    private void createPoolSamplePerBatch(String newbatchid, String dilutiontubeid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty("sampleid", dilutiontubeid);
        props.setProperty("quantity", "10");
        props.setProperty("poolquantity", "10");
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);
        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample ." + e.getMessage());
        }
        String newkeyid1 = props.getProperty("newkeyid1", "");
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid1);
        props.setProperty("u_currentmovementstep", "Disposed");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update pool specimen" + ex.getMessage());
        }
        props.clear();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, newbatchid);
        props.setProperty("sampleid", newkeyid1);
        props.setProperty("ispooledflag", "Y");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add pool specimen into the batch" + ex.getMessage());
        }
    }

    private void molarityCalculation(String childbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_FOR_MORTALITY_DETAILS_BY_BATCHID, childbatchid);
        DataSet dsMortalityDetails = getQueryProcessor().getSqlDataSet(sql);
        for (int i = 0; i < dsMortalityDetails.size(); i++) {
            String sampleid = dsMortalityDetails.getValue(i, "s_sampleid", "");
            double averagesize = Double.parseDouble(dsMortalityDetails.getValue(i, "averagesize", ""));
            double bioanalizerconc = Double.parseDouble(dsMortalityDetails.getValue(i, "bioanalizerconc", ""));
            double bioanalizerconc1 = Double.parseDouble(dsMortalityDetails.getValue(i, "bioanalizerconc1", ""));
            double concentration = Double.parseDouble(dsMortalityDetails.getValue(i, "concentration", ""));
            double conacquantid = Double.parseDouble(dsMortalityDetails.getValue(i, "conacquantid", ""));
            double stocktodilute = Double.parseDouble(dsMortalityDetails.getValue(i, "stocktodilute", ""));
            double concdesired = Double.parseDouble(dsMortalityDetails.getValue(i, "concdesired", ""));
            double tetodilute = Double.parseDouble(dsMortalityDetails.getValue(i, "tetodilute", ""));
            if (averagesize > 0) {
                bioanalizerconc = bioanalizerconc1 / (660 * averagesize) * Math.pow(10.0, 6.0);
                bioanalizerconc = Util.roundAvoid(bioanalizerconc);
                if (Double.isInfinite(bioanalizerconc))
                    bioanalizerconc = 0.0;
                conacquantid = concentration / (660 * averagesize) * Math.pow(10.0, 6.0);
                conacquantid = Util.roundAvoid(conacquantid);
                if (Double.isInfinite(conacquantid))
                    conacquantid = 0.0;
            }
            if (conacquantid > 0) {
                tetodilute = (stocktodilute * conacquantid) / concdesired - stocktodilute;
                tetodilute = Util.roundAvoid(tetodilute);
                if (Double.isInfinite(tetodilute))
                    tetodilute = 0.0;
            }
            dsMortalityDetails.setValue(i, "bioanalizerconc", String.valueOf(bioanalizerconc));
            dsMortalityDetails.setValue(i, "conacquantid", String.valueOf(conacquantid));
            dsMortalityDetails.setValue(i, "tetodilute", String.valueOf(tetodilute));
        }
        PropertyList proptag = new PropertyList();
        proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
        proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, childbatchid);
        proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        proptag.setProperty("sampleid", dsMortalityDetails.getColumnValues("s_sampleid", ";"));
        proptag.setProperty("averagesize", dsMortalityDetails.getColumnValues("averagesize", ";"));
        proptag.setProperty("bioanalizerconc", dsMortalityDetails.getColumnValues("bioanalizerconc", ";"));
        proptag.setProperty("bioanalizerconc1", dsMortalityDetails.getColumnValues("bioanalizerconc1", ";"));
        proptag.setProperty("conacquantid", dsMortalityDetails.getColumnValues("conacquantid", ";"));
        proptag.setProperty("stocktodilute", dsMortalityDetails.getColumnValues("stocktodilute", ";"));
        proptag.setProperty("concdesired", dsMortalityDetails.getColumnValues("concdesired", ";"));
        proptag.setProperty("tetodilute", dsMortalityDetails.getColumnValues("tetodilute", ";"));
        proptag.setProperty("rulebypass", "Y");
        try {
            getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
        } catch (SapphireException se) {
            throw new SapphireException("Can not edit batch detail" + se.getMessage());
        }
    }
}
