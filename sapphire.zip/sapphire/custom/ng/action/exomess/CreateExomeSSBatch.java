package sapphire.custom.ng.action.exomess;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;

public class CreateExomeSSBatch extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String elutiontube = properties.getProperty("sampleid", "");
        String batchname = properties.getProperty("batchname", "");
        String tramstopname = properties.getProperty("tramstopname", "LibraryPrep");
        String sql = Util.parseMessage(MolecularSql.GET_DATA_BY_SAMPLEID, StringUtil.replaceAll(elutiontube, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo != null && dsInfo.size() > 0) {
            sql = Util.parseMessage(MolecularSql.GET_TESTS_BY_ELUTIONTUBE, StringUtil.replaceAll(elutiontube, ";", "','"));
            DataSet dsTests = getQueryProcessor().getSqlDataSet(sql);
            String batchid = createBatch(batchname);
            String dilutiontube = createDilutionTube(elutiontube, batchid);
            sql = Util.parseMessage(MolecularSql.GET_SAMPLEMAP_BY_DEST, StringUtil.replaceAll(dilutiontube, ";", "','"));
            DataSet dsDilution = getQueryProcessor().getSqlDataSet(sql);
            updateSpecimenType(dilutiontube);
            performDilutionOperation(dsTests, dsDilution);
            associateIntoBatch(batchid);
            updateElutionMovemnetStep(elutiontube);
            calculateDilution(batchid, tramstopname);
            updateElutionTubeVolume();
            createPoolSamplePerBatch(batchid, dilutiontube);
        }
        properties.setProperty("msg", "Exome- SS batch <b>" + batchname + "</b> has been successfully created.");
        //throw new SapphireException("test");
    }

    private String createBatch(String batchname) throws SapphireException {
        String ngbatchid = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchname", batchname);
        pl.setProperty("origin", "ExomSSDay1");
        pl.setProperty("batchmovestatus", "ExomSSDay1Batch");
        pl.setProperty("batchstatusview", "ExomSSDay1Batch");
        pl.setProperty("batchtype", "ExomeSS");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");
        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }

    private String createDilutionTube(String elutiontube, String batchid) throws SapphireException {
        String[] eliArry = StringUtil.split(elutiontube, ";");
        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, elutiontube);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", eliArry.length, ";"));
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "u_molbatchspecimenid;u_replicateflag;u_additionalbodysite;u_aliquotinfo;sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;concentration;u_pathologycomments;u_extractioncomments");
        prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
        prop.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);

        String dilutionTubes = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples/Single parent -------------------
        Util.setRootForPoolSample(dilutionTubes, elutiontube, getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------
        return dilutionTubes;
    }

    private void updateSpecimenType(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("containertypeid", "Dilution Tube");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("specimentype", "Dilution Tube");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
    }

    private void updateElutionMovemnetStep(String elutiontube) throws SapphireException {
        if (elutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, elutiontube);
            //props.setProperty("u_currentmovementstep", "Day1Completed");
            props.setProperty("u_currentmovementstep", "LibraryPrepBatch");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not update elution tube" + se.getMessage());
            }
            String site = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0];
            String department = site + "-Molecular";
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, elutiontube);
            props.setProperty("u_currenttramstop", "LibraryPrep Batch");
            //props.setProperty("u_currenttramstop", "Exome SS Reporting");
            props.setProperty("custodialdepartmentid", department);
            props.setProperty("custodialuserid", "(null)");
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not update elution tube" + se.getMessage());
            }
        }
    }

    private void performDilutionOperation(DataSet dsElutionTests, DataSet dsDilutionInfo) throws SapphireException {
        dsFinal = new DataSet();
        dsFinal.addColumn("childsampleid", DataSet.STRING);
        dsFinal.addColumn("rootsampleid", DataSet.STRING);
        dsFinal.addColumn("lvtestcodeid", DataSet.STRING);

        if (dsDilutionInfo.size() > 0) {
            for (int i = 0; i < dsDilutionInfo.size(); i++) {
                String elutiontube = dsDilutionInfo.getValue(i, "sourcesampleid");
                String dilutiontube = dsDilutionInfo.getValue(i, "destsampleid");
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("s_sampleid", elutiontube);
                DataSet dsFilter = dsElutionTests.getFilteredDataSet(hm);
                if (dsFilter.size() > 0) {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, "childsampleid", dilutiontube);
                    dsFinal.setValue(rowID, "rootsampleid", elutiontube);
                    dsFinal.setValue(rowID, "lvtestcodeid", dsFilter.getValue(0, "lvtestcodeid", ""));
                }
            }
        }
        if (dsFinal.size() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("childsampleid", ";"));
            props.setProperty("u_rootsample", dsFinal.getColumnValues("rootsampleid", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            PropertyList addTestCode = new PropertyList();
            addTestCode.setProperty("s_sampleid", dsFinal.getColumnValues("childsampleid", ";"));
            addTestCode.setProperty("lvtestcode", dsFinal.getColumnValues("lvtestcodeid", ";"));
            addTestCode.setProperty("ispanel", StringUtil.repeat("N", dsFinal.size(), ";"));
            addTestCode.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
            addTestCode.setProperty("workitemflag", "Y");
            getActionProcessor().processAction("AddTestCode", "1", addTestCode);
        }
    }

    private void associateIntoBatch(String batchid) throws SapphireException {
        if (dsFinal != null && dsFinal.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
            props.setProperty("sampleid", dsFinal.getColumnValues("childsampleid", ";"));
            props.setProperty("testcodeid", dsFinal.getColumnValues("lvtestcodeid", ";"));
            props.setProperty("ispooledflag", "N");
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        }
    }

    private void calculateDilution(String batchid, String tramstopname) throws SapphireException {
        if (dsFinal != null && dsFinal.size() > 0) {
            DataSet dsDilutionCal = new DataSet();
            dsDilutionCal.addColumn("dilutiontube", DataSet.STRING);
            dsDilutionCal.addColumn("concentration", DataSet.STRING);
            dsDilutionCal.addColumn("amntofsample", DataSet.STRING);
            dsDilutionCal.addColumn("amntofwater", DataSet.STRING);
            dsDilutionCal.addColumn("inputvol", DataSet.STRING);
            dsDilutionCal.addColumn("sampledilution", DataSet.STRING);

            String dilutiontube = dsFinal.getColumnValues("childsampleid", ";");
            String sql = Util.parseMessage(MolecularSql.GET_INFO_BY_SPECIMEN, StringUtil.replaceAll(dilutiontube, ";", "','"));
            DataSet dsDilutionInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsDilutionInfo.size() > 0) {
                String projectids = dsDilutionInfo.getColumnValues("projectid", ";");
                DataSet dsExomeVals = Util.getExomeSSTramstopValues(getQueryProcessor(), projectids);
                //double fxdval = 200.0;//TODO NOT REQUIRED AS THIS IS CONFIGURABLE TRAMSTOP WISE INTO PROJECT LEVEL.
                HashMap hm = new HashMap();
                for (int i = 0; i < dsDilutionInfo.size(); i++) {
                    String dilutube = dsDilutionInfo.getValue(i, "s_sampleid");
                    String projectid = dsDilutionInfo.getValue(i, "projectid");
                    String elutionvol = dsDilutionInfo.getValue(i, "elutionvol", "0.0");
                    double dilutionratio = 0.0;
                    double amntofwater = 0.0;
                    double inputvol = 0.0;
                    double fxdval = 0.0;
                    double fxdstaticval = 0.0;
                    if ("LibraryPrep".equalsIgnoreCase(tramstopname) || "LibraryPrepQuant".equalsIgnoreCase(tramstopname)) {
                        fxdval = 250.0;
                        fxdstaticval = 51.0;
                    } else if ("CaptureBatch".equalsIgnoreCase(tramstopname) || "CaptureBatchQuant".equalsIgnoreCase(tramstopname)
                            || "Molarity".equalsIgnoreCase(tramstopname) || "Sequencing".equalsIgnoreCase(tramstopname)) {
                        fxdval = 750.0;
                        fxdstaticval = 51.0;
                    } else {
                        fxdval = 200.0;
                        fxdstaticval = 51.0;
                    }
                    //TODO AS PER INSTRUCTION VALUE WILL BE FIXED
                    /*hm.clear();
                    hm.put("projectid", projectid);
                    hm.put("tramstopname", tramstopname);
                    DataSet dsExomeSSValFilter = dsExomeVals.getFilteredDataSet(hm);
                    if (dsExomeSSValFilter == null || dsExomeSSValFilter.size() == 0) {
                        fxdval = 200.0;
                        fxdstaticval = 51.0;
                    } else {
                        String inputngval = dsExomeSSValFilter.getValue(0, "inputngval", "0.0");
                        String fixedvalue = dsExomeSSValFilter.getValue(0, "fixedvalue", "0.0");
                        fxdval = Double.parseDouble(inputngval);
                        fxdstaticval = Double.parseDouble(fixedvalue);
                    }*/
                    double concentration = Double.parseDouble(dsDilutionInfo.getValue(i, "concentration", "0.0"));
                    double amntofsample = 0.0;
                    if (concentration > 0) {
                        amntofsample = fxdval / concentration;
                        amntofsample = Util.roundAvoid(amntofsample);
                    } else {
                        amntofsample = 0.0;
                    }

                    if (concentration > 0 && amntofsample < 2) {
                        dilutionratio = concentration / 10;
                        dilutionratio = Util.roundAvoid(dilutionratio);

                        amntofsample = fxdval / dilutionratio;
                        amntofsample = Util.roundAvoid(amntofsample);

                        amntofwater = fxdstaticval - amntofsample;
                        amntofwater = Util.roundAvoid(amntofwater);

                        inputvol = dilutionratio * amntofsample;
                        inputvol = Util.roundAvoid(inputvol);
                    } else {
                        amntofwater = Util.roundAvoid(fxdstaticval - amntofsample);
                        inputvol = Util.roundAvoid(concentration * amntofsample);

                    }
                    if (amntofsample > Double.parseDouble(elutionvol)) {
                        amntofsample = Double.parseDouble(elutionvol);

                        amntofwater = fxdstaticval - amntofsample;
                        amntofwater = Util.roundAvoid(amntofwater);

                        inputvol = dilutionratio * amntofsample;
                        inputvol = Util.roundAvoid(inputvol);
                    }
                    if (dilutionratio < 0) {
                        dilutionratio = 0.0;
                    } else if (amntofwater < 0) {
                        amntofwater = 0.0;
                    } else if (inputvol < 0) {
                        inputvol = 0.0;
                    } else if (concentration < 0) {
                        concentration = 0.0;
                    } else if (amntofsample < 0) {
                        amntofsample = 0.0;
                    }
                    if (Double.isInfinite(dilutionratio))
                        dilutionratio = 0.0;
                    if (Double.isInfinite(amntofwater))
                        amntofwater = 0.0;
                    if (Double.isInfinite(inputvol))
                        inputvol = 0.0;
                    if (Double.isInfinite(amntofwater))
                        amntofwater = 0.0;
                    if (Double.isInfinite(inputvol))
                        inputvol = 0.0;
                    int rowID = dsDilutionCal.addRow();
                    dsDilutionCal.setValue(rowID, "dilutiontube", dilutube);
                    dsDilutionCal.setValue(rowID, "concentration", String.valueOf(concentration));
                    dsDilutionCal.setValue(rowID, "amntofsample", String.valueOf(amntofsample));
                    dsDilutionCal.setValue(rowID, "amntofwater", String.valueOf(amntofwater));
                    dsDilutionCal.setValue(rowID, "inputvol", String.valueOf(inputvol));
                    dsDilutionCal.setValue(rowID, "sampledilution", String.valueOf(dilutionratio));
                }
            }
            if (dsDilutionCal != null && dsDilutionCal.size() > 0) {
                PropertyList proptag = new PropertyList();
                proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
                proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, batchid);
                proptag.setProperty("sampleid", dsDilutionCal.getColumnValues("dilutiontube", ";"));
                proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                proptag.setProperty("amtofsample", dsDilutionCal.getColumnValues("amntofsample", ";"));
                proptag.setProperty("amtofwater", dsDilutionCal.getColumnValues("amntofwater", ";"));
                proptag.setProperty("sampleinput", dsDilutionCal.getColumnValues("inputvol", ";"));
                proptag.setProperty("sampledilution", dsDilutionCal.getColumnValues("sampledilution", ";"));
                proptag.setProperty("rulebypass", "Y");

                try {
                    getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
                } catch (SapphireException se) {
                    throw new SapphireException("Can not edit batch detail");
                }
            }
        }
    }

    private void updateElutionTubeVolume() throws SapphireException {
        if (dsFinal.size() > 0) {
            String dilutiontube = dsFinal.getColumnValues("childsampleid", ";");
            String elutiontube = dsFinal.getColumnValues("rootsampleid", ";");
            String sql = Util.parseMessage(MolecularSql.GET_SAMPLEINITIAL_VOL_BY_SAMPLE, StringUtil.replaceAll(dilutiontube, ";", "','"));
            DataSet dsDilutionInfo = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(MolecularSql.GET_FROM_TRACKITEM_BYSAMPLE, StringUtil.replaceAll(elutiontube, ";", "','"));
            DataSet dsElutionInfo = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            if (!dsFinal.isValidColumn("balncqty"))
                dsFinal.addColumn("balncqty", DataSet.STRING);
            for (int i = 0; i < dsFinal.size(); i++) {
                dilutiontube = dsFinal.getValue(i, "childsampleid", "");
                elutiontube = dsFinal.getValue(i, "rootsampleid", "");
                hm.clear();
                hm.put("sampleid", dilutiontube);
                DataSet dsDilutionFiletr = dsDilutionInfo.getFilteredDataSet(hm);
                double amountofsample = 0.0, eluqty = 0.0;
                if (dsDilutionFiletr.size() > 0) {
                    amountofsample = Double.parseDouble(dsDilutionFiletr.getValue(0, "amtofsample", "0.0"));
                    amountofsample = Util.roundAvoid(amountofsample);
                }
                hm.clear();
                hm.put("linkkeyid1", elutiontube);
                DataSet dsElutionFiletr = dsElutionInfo.getFilteredDataSet(hm);
                if (dsElutionFiletr.size() > 0) {
                    eluqty = Util.roundAvoid(Double.parseDouble(dsElutionFiletr.getValue(0, "qtycurrent", "0.0")));
                }
                double balncqtyelu = eluqty - amountofsample;
                balncqtyelu = Util.roundAvoid(balncqtyelu);
                if (balncqtyelu < 0) {
                    balncqtyelu = 0.0;
                }
                dsFinal.setValue(i, "balncqty", String.valueOf(balncqtyelu));
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues("rootsampleid", ";"));
            prop.setProperty("qtycurrent", dsFinal.getColumnValues("balncqty", ";"));
            try {
                //getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);//TODO NO NEED TO UPDATE ELUTION QUANTITY WHILE CREATING
            } catch (Exception ex) {
                throw new SapphireException("Unable to update elution tube volume.");
            }
        }
    }

    private void createPoolSamplePerBatch(String newbatchid, String dilutiontubeid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty("sampleid", dilutiontubeid);
        props.setProperty("quantity", "10");
        props.setProperty("poolquantity", "10");
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);
        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample ." + e.getMessage());
        }
        String newkeyid1 = props.getProperty("newkeyid1", "");
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid1);
        props.setProperty("u_currentmovementstep", "Disposed");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update pool specimen" + ex.getMessage());
        }
        props.clear();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, newbatchid);
        props.setProperty("sampleid", newkeyid1);
        props.setProperty("ispooledflag", "Y");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add pool specimen into the batch" + ex.getMessage());
        }
    }

    private DataSet dsFinal = null;
}
