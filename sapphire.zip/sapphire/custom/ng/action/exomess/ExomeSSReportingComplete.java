package sapphire.custom.ng.action.exomess;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/***
 * @Desc: This is used to complete Exome SS Batch.
 * @createby: surajit.baitalik
 * @date: 08/11/2018
 */
public class ExomeSSReportingComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        if (Util.isNull(batchid))
            throw new SapphireException("Batch ID can't be blank.");

        completeReportingBatch(properties);
        updateElutionTube(batchid);
        updateTestStatus(batchid);

        properties.setProperty("msg", "Batch is successfully completed.");
        //throw new SapphireException("test");
    }

    private void completeReportingBatch(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String batchcompletedts = properties.getProperty("batchcompletedts");
        String batchcompleteflag = properties.getProperty("batchcompleteflag");
        String batchtype = properties.getProperty("batchtype");
        String batchmovestatus = properties.getProperty("batchmovestatus");
        String origin = properties.getProperty("origin");
        String batchstatusview = properties.getProperty("batchstatusview");

        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        props.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        props.setProperty("batchcompletedts", batchcompletedts);
        props.setProperty("batchcompleteflag", batchcompleteflag);
        props.setProperty("batchtype", batchtype);
        props.setProperty("batchmovestatus", batchmovestatus);
        props.setProperty("origin", origin);
        props.setProperty("batchstatusview", batchstatusview);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Batch Complete failed." + ex.getMessage());
        }
    }

    private void updateElutionTube(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_BATCH_SAMPLE_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() == 0) {
            logger.info("ExomeSS Reporting::", "Specimen(s) are not available into the batch.");
        }
        String currentuser = connectionInfo.getSysuserId();
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsBatchInfo.getColumnValues("sampleid", ";"));
        props.setProperty("u_reportflag", StringUtil.repeat("Y", dsBatchInfo.size(), ";"));
        props.setProperty("u_reportingdts", StringUtil.repeat("n", dsBatchInfo.size(), ";"));
        props.setProperty("u_reportingusername", StringUtil.repeat(currentuser, dsBatchInfo.size(), ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update reporting details for batch specimen(s)." + ex.getMessage());
        }
        String site = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0];
        String department = site + "-Molecular";
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsBatchInfo.getColumnValues("sampleid", ";"));
        props.setProperty("u_currenttramstop", "Reporting Complete");
        //props.setProperty("u_currenttramstop", "Exome SS Reporting");
        props.setProperty("custodialdepartmentid", department);
        props.setProperty("custodialuserid", "(null)");
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException se) {
            throw new SapphireException("Can not update elution tube" + se.getMessage());
        }
    }

    private void updateTestStatus(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_BATCH_SAMPLES_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() == 0) {
            logger.info("ExomeSS Reporting::", "Specimen(s) are not available into the batch/Does not have testcode.");
        }
        String mapid = "";
        for (int i = 0; i < dsBatchInfo.size(); i++) {
            String dilutemapid = dsBatchInfo.getValue(i, "dilutemapid", ";");
            String elutionmapid = dsBatchInfo.getValue(i, "elutionmapid", ";");
            String accessionsamplemapid = dsBatchInfo.getValue(i, "accessionsamplemapid", ";");
            mapid = mapid + ";" + dilutemapid + ";" + elutionmapid + ";" + accessionsamplemapid;
        }
        if (mapid.startsWith(";"))
            mapid = mapid.substring(1);
        PropertyList property = new PropertyList();
        property.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        property.setProperty(EditSDI.PROPERTY_KEYID1, mapid);
        property.setProperty("teststatus", "Completed");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, property);
        } catch (Exception ex) {
            throw new SapphireException("Unable to complete test status." + ex.getMessage());
        }
    }
}
