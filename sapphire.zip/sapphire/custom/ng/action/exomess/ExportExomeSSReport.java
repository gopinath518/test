package sapphire.custom.ng.action.exomess;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class ExportExomeSSReport extends BaseAction {

    int rownum = 0;
    XSSFSheet firstSheet;
    Collection<File> files;
    XSSFWorkbook workbook;
    File exactFile;

    public void processAction(PropertyList properties) throws SapphireException {
        String molbatchid = properties.getProperty("molbatchid", "");
        String projectproid = properties.getProperty("projectproid", "");
        String startdate = properties.getProperty("startdate");
        String enddate = properties.getProperty("enddate");
        String searchtype = properties.getProperty("searchtype");
        String keyid1val = "";

        //PARSE INPUT DATE
        Date startdt = null;
        Date enddt = null;
        try {
            startdt = new SimpleDateFormat("MM/dd/yy hh:mm aa").parse(startdate);
            enddt = new SimpleDateFormat("MM/dd/yy hh:mm aa").parse(enddate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss aa");
        String strDate = sdf.format(startdt.getTime());
        logger.info("Start date in String Format: " + strDate);
        String endDate = sdf.format(enddt.getTime());
        logger.info("End date in String Format: " + endDate);

        molbatchid = molbatchid.trim();
        workbook = new XSSFWorkbook();
        //SET CELL STYLE
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        style.setFont(font);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        //SET ALL BORDER
        CellStyle borderStyle = workbook.createCellStyle();
        borderStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        firstSheet = workbook.createSheet("Exome SS");
        Row headerRow = firstSheet.createRow(rownum);
        headerRow.setHeightInPoints(40);
        String sql = "";
        if (!Util.isNull(molbatchid)) {
            sql = Util.parseMessage(MolecularSql.GET_EXOMESS_REPORTING_BY_MOLBATCHID, molbatchid, strDate, endDate);
            keyid1val = molbatchid;
        }
        if (!Util.isNull(projectproid)) {
            sql = Util.parseMessage(MolecularSql.GET_EXOMESS_REPORTING_BY_PROJECTID, projectproid, strDate, endDate);
            keyid1val = projectproid;
        }
        if (!Util.isNull(molbatchid) && !Util.isNull(projectproid)) {
            sql = Util.parseMessage(MolecularSql.GET_EXOMESS_REPORTING_BY_PROJECTID_MOL, projectproid, molbatchid, strDate, endDate);
            keyid1val = molbatchid;
        }
        DataSet dsExomeSSReport = getQueryProcessor().getSqlDataSet(sql);
        if (dsExomeSSReport != null && dsExomeSSReport.size() > 0) {
            String colmns[] = dsExomeSSReport.getColumns();
            List<List> recordToAdd = new ArrayList<List>();
            List<String> headerRowToAdd = new ArrayList<String>();
            for (int c = 0; c < colmns.length; c++) {
                String columnname = colmns[c].toUpperCase();
                if ("neogenomics_total_1".equalsIgnoreCase(columnname))
                    columnname = "Neogenomics Total 1 (ng)";
                else if ("pcr_1_bp".equalsIgnoreCase(columnname))
                    columnname = "PCR1 (bp)";
                else if ("pcr_1_ng".equalsIgnoreCase(columnname))
                    columnname = "PCR1 (ng/ul)";
                else if ("pcr_1_total_ng".equalsIgnoreCase(columnname))
                    columnname = "PCR1 (Total ng)";
                else if ("pcr_2_nmol".equalsIgnoreCase(columnname))
                    columnname = "PCR2 (nmol/L)";
                else if ("concentration_1".equalsIgnoreCase(columnname))
                    columnname = "Concentration1 (ng/ul)";
                else if ("specimen_amount".equalsIgnoreCase(columnname))
                    columnname = "Total Sample Volume (ul)";
                else if ("neo_project_id".equalsIgnoreCase(columnname))
                    columnname = "Neogenomics Project Id";
                else if ("project_id".equalsIgnoreCase(columnname))
                    columnname = "Project/Protocol Id";
                else if ("sample_volumn".equalsIgnoreCase(columnname))
                    columnname = "Volume 1 (ul)";
                else if ("tumor_circled".equalsIgnoreCase(columnname))
                    columnname = "% Tumor Circled";
                else if ("date_return_status".equalsIgnoreCase(columnname))
                    columnname = "Data Returned Status";
                //ADD COLUMN NAME TO LIST
                headerRowToAdd.add(toCamelCase(columnname));
            }
            recordToAdd.add(headerRowToAdd);

            for (int i = 0; i < dsExomeSSReport.size(); i++) {
                List<String> firstRow = new ArrayList<String>();
                for (int c = 0; c < colmns.length; c++) {
                    firstRow.add(dsExomeSSReport.getValue(i, colmns[c], ""));
                }
                recordToAdd.add(firstRow);
            }


            try {
                for (int j = 0; j < recordToAdd.size(); j++) {
                    if (rownum == 0) {
                        Row row = firstSheet.createRow(rownum);
                        List<String> l2 = recordToAdd.get(j);
                        for (int k = 0; k < l2.size(); k++) {
                            Cell cell = row.createCell(k);
                            cell.setCellValue(l2.get(k));
                            cell.setCellStyle(style);
                        }
                    } else {
                        Row row = firstSheet.createRow(rownum);
                        List<String> l2 = recordToAdd.get(j);
                        for (int k = 0; k < l2.size(); k++) {
                            Cell cell = row.createCell(k);
                            cell.setCellValue(l2.get(k));
                            cell.setCellStyle(borderStyle);
                        }
                    }
                    rownum++;
                }
                String location = getFileLocation();
                String timestamp = new java.text.SimpleDateFormat("MMddyyyyhmmssa").format(new Date());
                //String filename = "C:\\Temp\\ExomeSSReport" + timestamp + ".xls";
                String filename = "";
                if (location.endsWith("/"))
                    filename = location + "ExomeSSReport_" + timestamp + ".xlsx";
                else
                    filename = location + File.separator + "ExomeSSReport_" + timestamp + ".xlsx";

                FileOutputStream fos = new FileOutputStream(new File(filename));
                //AUTO SIZE COLUMN
                int rowcol = 0;
                for (int j = 0; j < recordToAdd.size(); j++) {
                    if (rowcol == 0) {
                        List<String> l2 = recordToAdd.get(j);
                        for (int k = 0; k < l2.size(); k++) {
                            firstSheet.autoSizeColumn(k);
                        }
                    }
                    rowcol++;
                }

                workbook.write(fos);
                PropertyList attachprop = new PropertyList();
                attachprop.clear();
                attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Dummy");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1val);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                attachprop.setProperty("ATTACHMENTCLASS", "SOP");
                attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");
                try {
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
                } catch (SapphireException ex) {
                    String msg = getTranslationProcessor().translate("Action failed. Attachment not added");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                }
                sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_NANOSTRING_REPORT, keyid1val);
                DataSet dsAttachmnt = getQueryProcessor().getSqlDataSet(sql);
                int attachnum = Integer.parseInt(dsAttachmnt.getValue(0, "attachmentnum", "0"));
                String url = "rc?command=ViewAttachment&sdcid=Dummy&keyid1=" + keyid1val + "&attachmentnum=" + attachnum + "&download=Y";
                String msg = "<script>window.open('" + url + "', '_blank');</script>";
                properties.setProperty("msg", "Report has been downloaded." + msg);
                PropertyList prop = new PropertyList();
                prop.setProperty("id", molbatchid);
                prop.setProperty("location", filename);
                prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "InventoryReportingTempDeleteAction");
                prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
                prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
                prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n+1");
                getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
            }
        } else {
            properties.setProperty("msg", "No record found into the system.");
        }
    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";
       /* String sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        fileLocation = Util.generateMolLocPath(baseloc, "Molecular", "ExomeSS");*/
        //GETTING DEFAULT LOCATION FROM POLICY
        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        //CHECK FOLDER
        fileLocation = Util.createFolderForMolecular(fileLocation, "ExomeSSReport");
        return fileLocation;
    }

    static String toCamelCase(String s) {
        String camelCaseString = "";
        if (s.contains("_")) {
            String[] parts = s.split("_");
            for (String part : parts) {
                camelCaseString = camelCaseString + " " + toProperCase(part);
            }
        } else {
            camelCaseString = s;
        }
        return camelCaseString;
    }

    static String toProperCase(String s) {
        return s.substring(0, 1).toUpperCase() +
                s.substring(1).toLowerCase();
    }

}

