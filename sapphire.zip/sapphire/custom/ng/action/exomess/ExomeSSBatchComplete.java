package sapphire.custom.ng.action.exomess;

import ca.uhn.hl7v2.model.v21.datatype.ST;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;

public class ExomeSSBatchComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String parentbatchid = properties.getProperty("batchid");
        String origin = properties.getProperty("origin");
        String childbatchtype = properties.getProperty("childbatchtype");//TODO WORKFLOW TYPE (EXOME SS)
        String parentbatchtype = properties.getProperty("parentbatchtype");//TODO WHERE PARENT BATCH TO GO(HISTORICAL BATCH)
        String childbatchmovestatus = properties.getProperty("childbatchmovestatus"); //TODO WHERE CHILD BATCH TO GO(NEXT TRAMSTOP)
        String parentbatchmovestatus = properties.getProperty("parentbatchmovestatus");//TODO WHERE PARENT BATCH TO GO(HISTORICAL BATCH)
        String childbatchstatusview = properties.getProperty("childbatchstatusview");//TODO WHERE CHILD BATCH TO GO(NEXT TRAMSTOP)
        String parentbatchstatusview = properties.getProperty("parentbatchstatusview");//TODO WHERE PARENT BATCH TO GO(HISTORICAL)
        String sourcebatchcomplete = properties.getProperty("sourcebatchcomplete");//TODO WHERE CHILD BATCH TO GO(FROM WHERE COMPLETING)
        String elutionmvmntstep = properties.getProperty("elutionmvmntstep");//TODO WHERE CHILD BATCH TO GO(FROM WHERE COMPLETING)
        String currenttramstop = properties.getProperty("currenttramstop");//TODO WHERE CHILD BATCH TO GO(FROM WHERE COMPLETING)
        String tramstopname = properties.getProperty("tramstopname", "");//TODO NEED TRAMSTOP NAME(DILUTION CALCULATION WILL BE NEEDED)

        if (Util.isNull(parentbatchid)) {
            throw new SapphireException("Batch id is not selected.");
        }
        if ("Reporting".equalsIgnoreCase(tramstopname)) {
            validateLaneForSequencingBatch(parentbatchid);
        }
        if ("Molarity".equalsIgnoreCase(tramstopname)) {
            routedSpecimenToMolaritySpecimen(parentbatchid);
            PropertyList editbatch = new PropertyList();
            editbatch.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
            editbatch.setProperty(EditSDI.PROPERTY_KEYID1, parentbatchid);
            editbatch.setProperty("batchtype", parentbatchtype);
            editbatch.setProperty("batchmovestatus", parentbatchmovestatus);
            editbatch.setProperty("batchstatusview", parentbatchstatusview);
            editbatch.setProperty("batchcompletedts", "n");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editbatch);
            } catch (SapphireException se) {
                throw new SapphireException("Can not update Batch");
            }
            return;
        }
        //UPDATE ELUTION VOLUME AFTER DAY1BATCH COMPLETE BASED ON SAMPLE VOLUME
        if ("Day1Batch".equalsIgnoreCase(sourcebatchcomplete)) {
            DataSet dsElutionUpdate = new DataSet();
            dsElutionUpdate.addColumn("elutiontube", DataSet.STRING);
            dsElutionUpdate.addColumn("currentvol", DataSet.STRING);
            String sql = Util.parseMessage(MolecularSql.GET_FOR_MORTALITY_DETAILS_BY_BATCHID, parentbatchid);
            DataSet dsChildBatchSampleDetails = getQueryProcessor().getSqlDataSet(sql);
            if (dsChildBatchSampleDetails != null && dsChildBatchSampleDetails.size() > 0) {
                String dilutiontube = dsChildBatchSampleDetails.getColumnValues("s_sampleid", ";");
                sql = Util.parseMessage(MolecularSql.GET_ELUTIONTUBE_BY_DILUTION, StringUtil.replaceAll(dilutiontube, ";", "','"));
                DataSet dsElutionDetails = getQueryProcessor().getSqlDataSet(sql);
                for (int i = 0; i < dsChildBatchSampleDetails.size(); i++) {
                    String dilution = dsChildBatchSampleDetails.getValue(i, "s_sampleid", "");
                    double dilutionvol = Double.parseDouble(dsChildBatchSampleDetails.getValue(i, "samplevolmn", "0.0"));
                    HashMap hm = new HashMap();
                    hm.clear();
                    hm.put("dilutiontube", dilution);
                    DataSet dsElutionFIletr = dsElutionDetails.getFilteredDataSet(hm);
                    if (dsElutionFIletr.size() > 0) {
                        String elutiontube = dsElutionFIletr.getValue(0, "elutiontube");
                        double elutionvol = Double.parseDouble(dsElutionFIletr.getValue(0, "elutioncrrntvol", "0.0"));
                        double restamountvol = elutionvol - dilutionvol;
                        restamountvol = Util.roundAvoid(restamountvol);

                        if (Double.isInfinite(restamountvol))
                            restamountvol = 0.0;
                        else if (restamountvol < 0.0)
                            restamountvol = 0.0;

                        int rowid = dsElutionUpdate.addRow();
                        dsElutionUpdate.setValue(rowid, "elutiontube", elutiontube);
                        dsElutionUpdate.setValue(rowid, "currentvol", String.valueOf(restamountvol));
                    }
                }
                if (dsElutionUpdate.size() > 0) {
                    PropertyList editbatch = new PropertyList();
                    editbatch.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    editbatch.setProperty(EditTrackItem.PROPERTY_KEYID1, dsElutionUpdate.getColumnValues("elutiontube", ";"));
                    editbatch.setProperty("qtycurrent", dsElutionUpdate.getColumnValues("currentvol", ";"));
                    try {
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editbatch);
                    } catch (SapphireException se) {
                        throw new SapphireException("Can not update elution volumn");
                    }
                }
            }
        }
        String sql = Util.parseMessage(MolecularSql.GET_BATCH_DETAILS, parentbatchid);
        DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sql);
        String batchname = dsBatchDetails.getValue(0, "batchname", "");
        PropertyList prop = new PropertyList();
        prop.setProperty("batchid", parentbatchid);
        prop.setProperty("origin", origin);
        prop.setProperty("childbatchtype", childbatchtype);
        prop.setProperty("batchmovestatus", childbatchmovestatus);
        prop.setProperty("batchstatusview", childbatchstatusview);
        prop.setProperty("batchname", batchname);
        prop.setProperty("sourcebatchcomplete", sourcebatchcomplete);
        prop.setProperty("tramstopname", tramstopname);
        try {
            getActionProcessor().processAction(CopyExomeSSBatch.ID, CopyExomeSSBatch.VERSION_ID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to create child batch." + ex.getMessage());
        }

        PropertyList editbatch = new PropertyList();
        editbatch.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        editbatch.setProperty(EditSDI.PROPERTY_KEYID1, parentbatchid);
        editbatch.setProperty("batchtype", parentbatchtype);
        editbatch.setProperty("batchmovestatus", parentbatchmovestatus);
        editbatch.setProperty("batchstatusview", parentbatchstatusview);
        editbatch.setProperty("batchcompletedts", "n");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editbatch);
        } catch (SapphireException se) {
            throw new SapphireException("Can not update Batch");
        }

        String childbatchid = prop.getProperty("childbatchid");
        if ("Day2Quant".equalsIgnoreCase(sourcebatchcomplete)) {
            sql = Util.parseMessage(MolecularSql.GET_FOR_MORTALITY_DETAILS_BY_BATCHID, childbatchid);
            DataSet dsMortalityDetails = getQueryProcessor().getSqlDataSet(sql);
            for (int i = 0; i < dsMortalityDetails.size(); i++) {
                String sampleid = dsMortalityDetails.getValue(i, "s_sampleid", "");
                double averagesize = Double.parseDouble(dsMortalityDetails.getValue(i, "averagesize", ""));
                double bioanalizerconc = Double.parseDouble(dsMortalityDetails.getValue(i, "bioanalizerconc", ""));
                double bioanalizerconc1 = Double.parseDouble(dsMortalityDetails.getValue(i, "bioanalizerconc1", ""));
                double concentration = Double.parseDouble(dsMortalityDetails.getValue(i, "concentration", ""));
                double conacquantid = Double.parseDouble(dsMortalityDetails.getValue(i, "conacquantid", ""));
                double stocktodilute = Double.parseDouble(dsMortalityDetails.getValue(i, "stocktodilute", ""));
                double concdesired = Double.parseDouble(dsMortalityDetails.getValue(i, "concdesired", ""));
                double tetodilute = Double.parseDouble(dsMortalityDetails.getValue(i, "tetodilute", ""));
                if (averagesize > 0) {
                    bioanalizerconc = bioanalizerconc1 / (660 * averagesize) * Math.pow(10.0, 6.0);
                    bioanalizerconc = Util.roundAvoid(bioanalizerconc);
                    if (Double.isInfinite(bioanalizerconc))
                        bioanalizerconc = 0.0;
                    conacquantid = concentration / (660 * averagesize) * Math.pow(10.0, 6.0);
                    conacquantid = Util.roundAvoid(conacquantid);
                    if (Double.isInfinite(conacquantid))
                        conacquantid = 0.0;
                }
                if (conacquantid > 0) {
                    tetodilute = (stocktodilute * conacquantid) / concdesired - stocktodilute;
                    tetodilute = Util.roundAvoid(tetodilute);
                    if (Double.isInfinite(tetodilute))
                        tetodilute = 0.0;
                }
                dsMortalityDetails.setValue(i, "bioanalizerconc", String.valueOf(bioanalizerconc));
                dsMortalityDetails.setValue(i, "conacquantid", String.valueOf(conacquantid));
                dsMortalityDetails.setValue(i, "tetodilute", String.valueOf(tetodilute));
            }
            PropertyList proptag = new PropertyList();
            proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
            proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, childbatchid);
            proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            proptag.setProperty("sampleid", dsMortalityDetails.getColumnValues("s_sampleid", ";"));
            proptag.setProperty("averagesize", dsMortalityDetails.getColumnValues("averagesize", ";"));
            proptag.setProperty("bioanalizerconc", dsMortalityDetails.getColumnValues("bioanalizerconc", ";"));
            proptag.setProperty("bioanalizerconc1", dsMortalityDetails.getColumnValues("bioanalizerconc1", ";"));
            proptag.setProperty("conacquantid", dsMortalityDetails.getColumnValues("conacquantid", ";"));
            proptag.setProperty("stocktodilute", dsMortalityDetails.getColumnValues("stocktodilute", ";"));
            proptag.setProperty("concdesired", dsMortalityDetails.getColumnValues("concdesired", ";"));
            proptag.setProperty("tetodilute", dsMortalityDetails.getColumnValues("tetodilute", ";"));
            proptag.setProperty("rulebypass", "Y");
            try {
                getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
            } catch (SapphireException se) {
                throw new SapphireException("Can not edit batch detail" + se.getMessage());
            }
        }
        /*if ("SequencingBatch".equalsIgnoreCase(sourcebatchcomplete)) {
            updateElutionTubeMovemenStep(childbatchid, elutionmvmntstep, currenttramstop);
        }*/
        updateElutionTubeMovemenStep(childbatchid, elutionmvmntstep, currenttramstop);
        //throw new SapphireException("Test");
    }

    private void updateElutionTubeMovemenStep(String keyid1, String elutionmvmntstep, String currenttramstop) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ELUTIONTUBE_BY_BATCHID, keyid1);
        DataSet dsElutionTube = getQueryProcessor().getSqlDataSet(sql);
        if (dsElutionTube.size() > 0) {
            String site = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0];
            String department = site + "-Molecular";
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsElutionTube.getColumnValues("elutiontube", ";"));
            //props.setProperty("u_currentmovementstep", StringUtil.repeat("ExomeSSReporting", dsElutionTube.size(), ";"));
            props.setProperty("u_currentmovementstep", StringUtil.repeat(elutionmvmntstep, dsElutionTube.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not update elution tube" + se.getMessage());
            }
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsElutionTube.getColumnValues("elutiontube", ";"));
            props.setProperty("u_currenttramstop", currenttramstop);
            //props.setProperty("u_currenttramstop", "Exome SS Reporting");
            props.setProperty("custodialdepartmentid", department);
            props.setProperty("custodialuserid", "(null)");
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not update elution tube" + se.getMessage());
            }
        }
    }

    private void routedSpecimenToMolaritySpecimen(String parentbatchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ALL_SAMPLE_BY_BATCHID, parentbatchid);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSample != null && dsBatchSample.size() > 0) {
            String parentbatchsample = dsBatchSample.getColumnValues("s_sampleid", ";");
            String[] pSampleArry = StringUtil.split(parentbatchsample, ";");
            PropertyList prop = new PropertyList();
            prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentbatchsample);
            prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", pSampleArry.length, ";"));
            prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "u_replicateflag;concentration;u_additionalbodysite;u_aliquotinfo;u_rootsample;u_molbatchspecimenid;sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;u_pathologycomments;u_extractioncomments");
            prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
            prop.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
            getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);

            String dilutionTubes = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
            Util.copyTestCodeFromParent(dilutionTubes, getQueryProcessor(), getActionProcessor());
            updateSpecimenInfo(dilutionTubes);
        }
    }

    private void updateSpecimenInfo(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("specimentype", "Dilution Tube");
            props.setProperty("u_currentmovementstep", "MolaritySpecimen");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("containertypeid", "Dilution Tube");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }
    }

    private void validateLaneForSequencingBatch(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_LANE_DETAILS, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsLaneInfo = getQueryProcessor().getSqlDataSet(sql);
        DataSet dsMsg = new DataSet();
        dsMsg.addColumn("lane_name", DataSet.STRING);
        dsMsg.addColumn("lane_desc", DataSet.STRING);
        /*if (dsLaneInfo == null || dsLaneInfo.size() == 0)
            throw new SapphireException("Lane info does not found for sequencing batch.");*/
        if (dsLaneInfo.size() > 0) {
            for (int i = 0; i < dsLaneInfo.size(); i++) {
                String lanename = dsLaneInfo.getValue(i, "laneid", "");
                String lanedesc = dsLaneInfo.getValue(i, "lanedesc", "");
                String islaneused = dsLaneInfo.getValue(i, "islaneused", "N");
                if ("N".equalsIgnoreCase(islaneused) && Util.isNull(lanedesc)) {
                    int rowID = dsMsg.addRow();
                    dsMsg.setValue(rowID, "lane_name", lanename);
                    dsMsg.setValue(rowID, "lane_desc", lanedesc);
                }
            }
            if (dsMsg.size() > 0) {
                String erroCode = Util.getDisplayMessage("Please provide lane details/mark them as Lane Not Used.", dsMsg);
                throw new SapphireException(erroCode);
            }
        }
    }
}
