package sapphire.custom.ng.action.exomess;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.HashMap;

public class CopyExomeSSBatch extends BaseAction {

    public static final String ID = "CopyExomeSSBatch";
    public static final String VERSION_ID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String parentbatchid = properties.getProperty("batchid");
        String origin = properties.getProperty("origin");
        String childbatchtype = properties.getProperty("childbatchtype");
        String batchmovestatus = properties.getProperty("batchmovestatus");
        String batchstatusview = properties.getProperty("batchstatusview");
        String batchname = properties.getProperty("batchname");
        String tramstopname = properties.getProperty("tramstopname", "");
        String sourcebatchcomplete = properties.getProperty("sourcebatchcomplete");//TODO WHERE CHILD BATCH TO GO(FROM WHERE COMPLETING)

        if (Util.isNull(parentbatchid)) {
            throw new SapphireException("Batch id is not selected.");
        }
        //TODO CREATE CHILD BATCH WHICH WILL GO NEXT TRAMSTOP OF EXOME SS
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
        prop.setProperty("origin", origin);
        prop.setProperty("parentbatchid", parentbatchid);
        prop.setProperty("batchmovestatus", batchmovestatus);
        prop.setProperty("batchstatusview", batchstatusview);
        prop.setProperty("batchtype", childbatchtype);
        prop.setProperty("batchname", batchname);
        if ("Day2Batch".equalsIgnoreCase(sourcebatchcomplete) || "MolarityBatch".equalsIgnoreCase(sourcebatchcomplete)) {
            prop.setProperty("additionalinfo", "Paired End");
            prop.setProperty("flowcell", "A");
        }
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (SapphireException s) {
            throw new SapphireException("Something went wrong.Batch can not be copied");
        }
        String childbatchid = prop.getProperty("newkeyid1");
        updateBatch(parentbatchid, childbatchid, sourcebatchcomplete, tramstopname);
        if ("Sequencing".equalsIgnoreCase(tramstopname))
            addSequencingLane(childbatchid);
        //attachPlateMap(parentbatchid, childbatchid);
        properties.setProperty("childbatchid", childbatchid);
        //throw new SapphireException("Test");
    }

    private void updateBatch(String parentbatch, String childbatchid, String sourcebatchcomplete, String tramstopname) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_ALL_SAMPLE_BY_BATCHID, parentbatch);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSample != null && dsBatchSample.size() > 0) {
            String parentbatchsample = dsBatchSample.getColumnValues("s_sampleid", ";");
            String[] pSampleArry = StringUtil.split(parentbatchsample, ";");
            PropertyList prop = new PropertyList();
            prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentbatchsample);
            prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, StringUtil.repeat("1", pSampleArry.length, ";"));
            prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "u_replicateflag;concentration;u_additionalbodysite;u_aliquotinfo;u_rootsample;u_molbatchspecimenid;sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep;u_pathologycomments;u_extractioncomments");
            prop.setProperty(MultiSampleChild.PROPERTY_MODE, "Aliquot");
            prop.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
            getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);

            String dilutionTubes = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
            Util.copyTestCodeFromParent(dilutionTubes, getQueryProcessor(), getActionProcessor());
            updateSpecimenType(dilutionTubes);
            if ("Day1Batch".equalsIgnoreCase(sourcebatchcomplete) || "Day2Batch".equalsIgnoreCase(sourcebatchcomplete)) {
                clearPrePopulatedConcentration(dilutionTubes);
            }
            //TODO CREATED POOL SAMPLE FOR CAPTURE BATCH
            if ("CaptureBatch".equalsIgnoreCase(tramstopname) || "Molarity".equalsIgnoreCase(tramstopname)) {
                createPoolSamplePerBatch(childbatchid, dilutionTubes);
            }
            sql = Util.parseMessage(MolecularSql.GET_ALL_INFO_BY_PARENT_SAMPLE, StringUtil.replaceAll(parentbatchsample, ";", "','"));
            DataSet dsChildParent = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("pooledflag", "N");
            DataSet dsNotPooledFilter = dsChildParent.getFilteredDataSet(hm);
            if (dsNotPooledFilter.size() > 0) {
                dsChildParent.clear();
                dsChildParent = dsNotPooledFilter;
            }
            if (dsChildParent != null && dsChildParent.size() > 0) {

                PropertyList proptag = new PropertyList();
                proptag.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                proptag.setProperty(AddSDIDetail.PROPERTY_KEYID1, childbatchid);
                proptag.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

                //TODO CALCULATION NEEDS TO BE TRAMSTOP SPECIFIC
                for (int i = 0; i < dsChildParent.size(); i++) {
                    String projectid = dsChildParent.getValue(i, "projectid", "");
                    String parentconc = dsChildParent.getValue(i, "parentconc", "0.0");
                    DataSet dsCalDilute = calculateDilution(parentconc, projectid, tramstopname);
                    if (dsCalDilute.size() > 0) {
                        dsChildParent.setValue(i, "amtofsample", dsCalDilute.getValue(0, "amntofsample", ""));
                        dsChildParent.setValue(i, "amtofwater", dsCalDilute.getValue(0, "amntofwater", ""));
                        dsChildParent.setValue(i, "sampleinput", dsCalDilute.getValue(0, "inputvol", ""));
                        dsChildParent.setValue(i, "sampledilution", dsCalDilute.getValue(0, "sampledilution", ""));
                    }
                }
                proptag.setProperty("sampleid", dsChildParent.getColumnValues("childsampleid", ";"));
                proptag.setProperty("amtofsample", dsChildParent.getColumnValues("amtofsample", ";"));
                proptag.setProperty("amtofwater", dsChildParent.getColumnValues("amtofwater", ";"));
                proptag.setProperty("sampleinput", dsChildParent.getColumnValues("sampleinput", ";"));
                proptag.setProperty("sampledilution", dsChildParent.getColumnValues("sampledilution", ";"));
                if ("Day2Quant".equalsIgnoreCase(sourcebatchcomplete)) {
                    proptag.setProperty("averagesize", dsChildParent.getColumnValues("averagesize", ";"));
                    proptag.setProperty("bioanalizerconc1", dsChildParent.getColumnValues("bioanalizerconc1", ";"));
                    proptag.setProperty("stocktodilute", StringUtil.repeat("2.0", dsChildParent.size(), ";"));
                    proptag.setProperty("concdesired", StringUtil.repeat("2.0", dsChildParent.size(), ";"));
                }
                if ("Day2Batch".equalsIgnoreCase(sourcebatchcomplete) || "MolarityBatch".equalsIgnoreCase(sourcebatchcomplete)) {
                    proptag.setProperty("datereturnstatus", dsChildParent.getColumnValues("datereturnstatus", ";"));
                    proptag.setProperty("averagesize", dsChildParent.getColumnValues("averagesize", ";"));
                    proptag.setProperty("bioanalizerconc", dsChildParent.getColumnValues("bioanalizerconc", ";"));
                    proptag.setProperty("bioanalizerconc1", dsChildParent.getColumnValues("bioanalizerconc1", ";"));
                    proptag.setProperty("conacquantid", dsChildParent.getColumnValues("conacquantid", ";"));
                    proptag.setProperty("stocktodilute", dsChildParent.getColumnValues("stocktodilute", ";"));
                    proptag.setProperty("concdesired", dsChildParent.getColumnValues("concdesired", ";"));
                    proptag.setProperty("tetodilute", dsChildParent.getColumnValues("tetodilute", ";"));
                }
                if ("SequencingBatch".equalsIgnoreCase(sourcebatchcomplete)) {
                    proptag.setProperty("datereturnstatus", dsChildParent.getColumnValues("datereturnstatus", ";"));
                    proptag.setProperty("averagesize", dsChildParent.getColumnValues("averagesize", ";"));
                    proptag.setProperty("bioanalizerconc", dsChildParent.getColumnValues("bioanalizerconc", ";"));
                    proptag.setProperty("bioanalizerconc1", dsChildParent.getColumnValues("bioanalizerconc1", ";"));
                    proptag.setProperty("conacquantid", dsChildParent.getColumnValues("conacquantid", ";"));
                    proptag.setProperty("stocktodilute", dsChildParent.getColumnValues("stocktodilute", ";"));
                    proptag.setProperty("concdesired", dsChildParent.getColumnValues("concdesired", ";"));
                    proptag.setProperty("tetodilute", dsChildParent.getColumnValues("tetodilute", ";"));
                }
                proptag.setProperty("ispooledflag", "N");
                proptag.setProperty("rulebypass", "Y");
                try {
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, proptag);
                } catch (SapphireException se) {
                    throw new SapphireException("Can not edit batch detail" + se.getMessage());
                }
            }
        }

    }

    private void attachPlateMap(String batchid, String newbatchid) throws SapphireException {


        String sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_BY_BATCH, batchid);
        DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
        PropertyList platemap = new PropertyList();
        if (dsAttachment != null && dsAttachment.size() > 0) {
            String filename = dsAttachment.getValue(0, "filename", "");
            if (!Util.isNull(filename)) {
                platemap.clear();
                platemap.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                platemap.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newbatchid);
                platemap.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                platemap.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                platemap.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, platemap);
            }
        }
    }

    private void updateSpecimenType(String dilutiontube) throws SapphireException {
        if (dilutiontube.length() > 0) {
            PropertyList props = new PropertyList();
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("containertypeid", "Dilution Tube");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontube);
            props.setProperty("specimentype", "Dilution Tube");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }
    }

    private void clearPrePopulatedConcentration(String dilutiontubes) throws SapphireException {
        if (dilutiontubes.length() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dilutiontubes);
            props.setProperty("concentration", "(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to clear concentration from dilution tube." + ex.getMessage());
            }
        }
    }

    private DataSet calculateDilution(String parentconc, String projectid, String tramstopname) throws SapphireException {
        DataSet dsDilutionCal = new DataSet();
        dsDilutionCal.addColumn("amntofsample", DataSet.STRING);
        dsDilutionCal.addColumn("amntofwater", DataSet.STRING);
        dsDilutionCal.addColumn("inputvol", DataSet.STRING);
        dsDilutionCal.addColumn("sampledilution", DataSet.STRING);
        if (!Util.isNull(parentconc)) {
            DataSet dsExomeVals = Util.getExomeSSTramstopValues(getQueryProcessor(), projectid);
            //double fxdval = 200.0;//TODO NOT REQUIRED AS THIS IS CONFIGURABLE TRAMSTOP WISE INTO PROJECT LEVEL.
            HashMap hm = new HashMap();
            double dilutionratio = 0.0;
            double amntofwater = 0.0;
            double inputvol = 0.0;
            double fxdval = 0.0;
            double fxdstaticval = 0.0;
            if ("LibraryPrep".equalsIgnoreCase(tramstopname) || "LibraryPrepQuant".equalsIgnoreCase(tramstopname)) {
                fxdval = 250.0;
                fxdstaticval = 51.0;
            } else if ("CaptureBatch".equalsIgnoreCase(tramstopname) || "CaptureBatchQuant".equalsIgnoreCase(tramstopname)
                    || "Molarity".equalsIgnoreCase(tramstopname) || "Sequencing".equalsIgnoreCase(tramstopname)) {
                fxdval = 750.0;
                fxdstaticval = 51.0;
            } else {
                fxdval = 200.0;
                fxdstaticval = 51.0;
            }
            /*hm.clear();
            hm.put("projectid", projectid);
            hm.put("tramstopname", tramstopname);
            DataSet dsExomeSSValFilter = dsExomeVals.getFilteredDataSet(hm);
            if (dsExomeSSValFilter == null || dsExomeSSValFilter.size() == 0) {
                fxdval = 200.0;
                fxdstaticval = 51.0;
            } else {
                String inputngval = dsExomeSSValFilter.getValue(0, "inputngval", "0.0");
                String fixedvalue = dsExomeSSValFilter.getValue(0, "fixedvalue", "0.0");
                fxdval = Double.parseDouble(inputngval);
                fxdstaticval = Double.parseDouble(fixedvalue);
            }*/
            double concentration = Double.parseDouble(parentconc);
            double amntofsample = 0.0;
            if (concentration > 0) {
                amntofsample = fxdval / concentration;
                amntofsample = Util.roundAvoid(amntofsample);
            } else {
                amntofsample = 0.0;
            }

            if (concentration > 0 && amntofsample < 2) {
                dilutionratio = concentration / 10;
                dilutionratio = Util.roundAvoid(dilutionratio);

                amntofsample = fxdval / dilutionratio;
                amntofsample = Util.roundAvoid(amntofsample);

                amntofwater = fxdstaticval - amntofsample;
                amntofwater = Util.roundAvoid(amntofwater);

                inputvol = dilutionratio * amntofsample;
                inputvol = Util.roundAvoid(inputvol);
            } else {
                amntofwater = Util.roundAvoid(fxdstaticval - amntofsample);
                inputvol = Util.roundAvoid(concentration * amntofsample);

            }
            if (dilutionratio < 0) {
                dilutionratio = 0.0;
            } else if (amntofwater < 0) {
                amntofwater = 0.0;
            } else if (inputvol < 0) {
                inputvol = 0.0;
            } else if (concentration < 0) {
                concentration = 0.0;
            } else if (amntofsample < 0) {
                amntofsample = 0.0;
            }
            if (Double.isInfinite(dilutionratio))
                dilutionratio = 0.0;
            if (Double.isInfinite(amntofwater))
                amntofwater = 0.0;
            if (Double.isInfinite(inputvol))
                inputvol = 0.0;
            if (Double.isInfinite(amntofwater))
                amntofwater = 0.0;
            if (Double.isInfinite(inputvol))
                inputvol = 0.0;
            //SET VALUE
            int rowID = dsDilutionCal.addRow();
            dsDilutionCal.setValue(rowID, "amntofsample", String.valueOf(amntofsample));
            dsDilutionCal.setValue(rowID, "amntofwater", String.valueOf(amntofwater));
            dsDilutionCal.setValue(rowID, "inputvol", String.valueOf(inputvol));
            dsDilutionCal.setValue(rowID, "sampledilution", String.valueOf(dilutionratio));
        }
        return dsDilutionCal;
    }

    private void createPoolSamplePerBatch(String newbatchid, String dilutiontubeid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty("sampleid", dilutiontubeid);
        props.setProperty("quantity", "10");
        props.setProperty("poolquantity", "10");
        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);
        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample ." + e.getMessage());
        }
        String newkeyid1 = props.getProperty("newkeyid1", "");
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid1);
        props.setProperty("u_currentmovementstep", "Disposed");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update pool specimen" + ex.getMessage());
        }
        props.clear();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, newbatchid);
        props.setProperty("sampleid", newkeyid1);
        props.setProperty("ispooledflag", "Y");
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add pool specimen into the batch" + ex.getMessage());
        }
    }

    private void addSequencingLane(String childbatchid) throws SapphireException {
        String lanes = "";
        String userseq = "";
        for (int i = 0; i < 8; i++) {
            lanes += ";" + "Lane " + (i + 1);
            userseq += ";" + (i + 1);
        }
        if (lanes.startsWith(";"))
            lanes = lanes.substring(1);
        if (userseq.startsWith(";"))
            userseq = userseq.substring(1);
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "BatchLaneMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, "8");
        props.setProperty("u_ngbatchid", childbatchid);
        props.setProperty("laneid", lanes);
        props.setProperty("usersequence", userseq);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add lane." + ex.getMessage());
        }
    }
}
