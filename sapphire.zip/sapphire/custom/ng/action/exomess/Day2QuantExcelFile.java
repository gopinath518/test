package sapphire.custom.ng.action.exomess;

import sapphire.SapphireException;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;

public class Day2QuantExcelFile extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid", "");
        String file = properties.getProperty("path", "");
        if (Util.isNull(file))
            throw new SapphireException("Plate map file is not found. Please upload a valid file.");
        if (file.indexOf(".xls") <= 0)
            throw new SapphireException("Invalid file format obtained. Please upload  Excel file.");

        attachedCount(batchid);
        addAttachment(batchid, file);
    }

    /**
     * Description : Used to validate count of attachment in sdiattachment
     * param  : batchid
     * throws : SapphireException
     */
    private void attachedCount(String batchid) throws SapphireException {

        String sqlCount = Util.parseMessage(MolecularSql.QUANTPARSER_ATTACHCOUNT_EXOM_SS_DAY2, batchid);
        DataSet dsCount = getQueryProcessor().getSqlDataSet(sqlCount);
        if (dsCount.size() == 0) {
            String errStr = getTranslationProcessor().translate("Specimen Attachment Count not found");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        int cnt = dsCount.getInt(0, "attachcount");
        if (cnt >= 3) {
            String errStr = getTranslationProcessor().translate("You can't upload file more than 3 times.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
    }

    /**
     * Description : Attach the Excel File to Molecular Batch.
     * param : batchid, file
     * throws : SapphireException
     */
    private void addAttachment(String batchid, String file) throws SapphireException {
        if (!Util.isNull(batchid) && !Util.isNull(file)) {
            PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
            if (plCaseFilePolicy == null)
                throw new SapphireException("File Location path can't be found");
            PropertyListCollection plc = plCaseFilePolicy.getCollection("locations");
            String fileTemplateIdentifier = "xls";
            if (plc != null) {
                String newfileLocation = plc.getPropertyList(0).getProperty("location");
                //CHECK INSTRUMENT FOLDER
                newfileLocation = Util.createFolderForMolecular(newfileLocation, "Instrument");

                if (Util.isNull(newfileLocation))
                    throw new SapphireException("Respective path is missing, Please contact Administrator. ");
                String newFile = Util.copyFile(file, newfileLocation, (fileTemplateIdentifier + "_"));
                if (Util.isNull(newFile))
                    throw new SapphireException("File can't be created in the location " + newfileLocation);

                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
                pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newFile);
                pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(newFile).getName());
                pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                pl.setProperty("sourcefilename", "Day2Quantit");
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
            }
        }
    }
}
