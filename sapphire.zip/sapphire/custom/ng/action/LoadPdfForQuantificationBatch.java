package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.io.File;

/**
 * Created by Subhashree.dash on 10/17/2017.
 */
public class LoadPdfForQuantificationBatch  extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid", "");
        String file = properties.getProperty("path", "");

        if (Util.isNull(file))
            throw new SapphireException("Plate map file is not found. Please upload a valid file.");
        if (file.indexOf(".pdf") <= 0 )
            throw new SapphireException("Invalid file format obtained. Please upload  pdf file.");
        String fileName = new File(file).getName();
        String filepath = new File(file).getPath();
        System.out.println("FilePath "+filepath+" fileName "+fileName);

        System.out.println("batchid "+batchid);
          /* int num= checkNumberofattachment(batchid);
           //int result = Integer.parseInt(num);
        System.out.println("checkNumberofattachment after in DB. "+num);
           if(num>3){
               throw new SapphireException("File is not attached to a batch.Maximum 3 file can attach for file.");
           }*/
            addAttachment(batchid,file);


        }
      public int checkNumberofattachment(String batchid)throws SapphireException{

          String checkattchment ="select count(*) from sdiattachment where sdcid='NGBatch'" +
                  " and keyid1='"+batchid+"'";
          String attachment="select filename,attachmentdesc from sdiattachment where sdcid='NGBatch'" +
                  " and keyid1='"+batchid+"'";
          DataSet dsattachment=getQueryProcessor().getSqlDataSet(attachment);
          int size=dsattachment.size();
        return size;
      }

    public void addAttachment(String batchid,String file)throws SapphireException{
        PropertyList attachprop = new PropertyList();
       // String description = batchid + time + ".pdf";
        String[] filenamearr = file.split(";");
        attachprop.clear();
        attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenamearr[0]);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION,batchid+".pdf");

        try {
            getActionProcessor().processAction(sapphire.action.AddSDIAttachment.ID, sapphire.action.AddSDIAttachment.VERSIONID, attachprop);
            System.out.println("Storing in DB. ");
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + batchid + "Batchid" + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }
}
