package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by ajha on 5/26/2016.
 * This action is used to Assign department
 * Mandatory Input:
 *
 * @param1 : Department
 * @param2 : Sampleid
 * @throws : SapphireException
 */

public class AssignDept extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String dept = properties.getProperty("department");
        String containertype = properties.getProperty("containertype");
        String currentStep = properties.getProperty("currentstep");
        String sampleid = properties.getProperty("sampleid");
        String slidetype = properties.getProperty("slidetype");
        String sample = StringUtil.replaceAll(sampleid, ";", "','");
        String moveback = properties.getProperty("movetoaccession", "");
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String actualdept = dept.substring(dept.indexOf("-") + 1, dept.length());
        String sql = "select trackitemid from trackitem where linksdcid='Sample' and linkkeyid1 in('" + sample + "')";
        validateEblock(sample, actualdept);
        if (currentStep != null && currentStep.length() > 0) {
            moveIhcSample(sampleid, currentStep);
            return;
        }
        if ("BlockRoom".equalsIgnoreCase(actualdept)) {
            String[] containerarr = StringUtil.split(containertype, ";");
            String[] slidetypearry = StringUtil.split(slidetype, ";");
            for (int i = 0; i < containerarr.length; i++) {
                if (!"Block".equalsIgnoreCase(containerarr[i]) && !"EB".equalsIgnoreCase(slidetypearry[i])) {
                    String errMsg = getTranslationProcessor().translate("You can only send Blocks to Block Room.");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }
            }
        }
        String sql1 = "select u_landingstep from department where departmentid = '" + dept + "'";
        DataSet trackitem = getQueryProcessor().getSqlDataSet(sql);
        DataSet landingstep = getQueryProcessor().getSqlDataSet(sql1);

        if (trackitem == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;

            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);

        }
        if (trackitem.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No TrackItem found for source specimen.");
            errMsg += "\nSampleID:" + sampleid + ", Query retuns no rows:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }

        if (landingstep == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;

            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);

        }
        if (landingstep.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No LandingStep found for source specimen.");
            errMsg += "\nSampleID:" + sampleid + ", Query retuns no rows:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        /*
        PropertyList prop=new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID,"TrackItemSDC");
        prop.setProperty(EditSDI.PROPERTY_KEYID1,trackitem.getColumnValues("trackitemid",";"));
        prop.setProperty("custodialdepartmentid",dept);
        prop.setProperty("custodialuserid","");
        prop.setProperty("u_currenttramstop",landingstep.getValue(0,"u_landingstep"));
        */
        PropertyList prop = new PropertyList();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        prop.setProperty("custodialdepartmentid", dept);
        prop.setProperty("custodialuserid", "");
        if (dept.equalsIgnoreCase("FM-Accessioning")) {
            prop.setProperty("u_currenttramstop", "Accession");
        } else {
            prop.setProperty("u_currenttramstop", landingstep.getValue(0, "u_landingstep"));
        }

       /*
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }*/
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }


        PropertyList p1 = new PropertyList();
        p1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        p1.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        /***
         * [TC33:sample from setup is not visible  to Path Support COC Tramstop]Surajit 05-05-17 STARTS
         ***/
        String landingstepstr = landingstep.getValue(0, "u_landingstep");
        if (Util.isNull(landingstepstr)) {
            landingstepstr = StringUtil.split(dept, "-")[1];
        }
        p1.setProperty("u_currentmovementstep", landingstepstr);
        /***
         * [TC33:sample from setup is not visible  to Path Support COC Tramstop]Surajit 05-05-17 STARTS
         ***/
        //p1.setProperty("u_currentmovementstep", landingstep.getValue(0, "u_landingstep"));

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p1);
        if (dept.equalsIgnoreCase("FM-Accessioning")) {
            moveToAccession(sampleid);
        }

    }

    private void moveToAccession(String sampleid) throws SapphireException {
        PropertyList accession = new PropertyList();
        accession.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        accession.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        accession.setProperty("u_accessioningcomplete", "N");
        accession.setProperty("u_currentmovementstep", "Accession");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, accession);


    }

    public void moveIhcSample(String sampleid, String currentsetp) throws SapphireException {
        String department = connectionInfo.getDefaultDepartment();
        String site = department.substring(0, department.indexOf("-"));
        if (currentsetp.startsWith("PathS"))
//            department = site + "-PathSupport";
            department = site + "-Accessioning";
        else if (currentsetp.startsWith("Logi"))
//            department = site + "-Logistic";
            department = site + "-Accessioning";
        else
            department = site + "-AP";
        try {
            PropertyList p1 = new PropertyList();
            p1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            p1.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            p1.setProperty("u_currentmovementstep", currentsetp);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p1);

            PropertyList prop = new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
            prop.setProperty("custodialdepartmentid", department);
            prop.setProperty("custodialuserid", "");
            //prop.setProperty("u_currenttramstop", "Accession");//TODO CHANGED FOR ROUTING ISSUE
            prop.setProperty("u_currenttramstop", currentsetp);
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }


    }

    /**
     * Description : User can only send Block and embedded block to block room.
     *
     * @param sampleid
     * @param currentsetp
     * @throws SapphireException
     */
    public void validateEblock(String sampleid, String currentsetp) throws SapphireException {
        try {
            String sqlEmbadedBlock = Util.parseMessage(MolecularSql.GET_U_TYPE_BY_SAMPLEID, sampleid);
            DataSet dsEmbadedBlock = getQueryProcessor().getSqlDataSet(sqlEmbadedBlock);
            if (dsEmbadedBlock == null) {
                String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
                errMsg += "\nQuery returns null, Query failed:" + sqlEmbadedBlock;
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            if (dsEmbadedBlock.size() > 0) {
                String sampleList = "";
                for (int i = 0; i < dsEmbadedBlock.size(); i++) {
                    String sample = dsEmbadedBlock.getValue(i, "s_sampleid", "");
                    String type = dsEmbadedBlock.getValue(i, "u_type", "");
                    if ("BlockRoom".equalsIgnoreCase(currentsetp)) {
                        if ("EB".equalsIgnoreCase(type) || "".equalsIgnoreCase(type)) {
                            continue;
                        } else {
                            sampleList = sampleList + "," + sample;
                        }
                    }
                }
                if (sampleList.length() > 1) {
                    sampleList = sampleList.substring(1);
                    String errMsg = getTranslationProcessor().translate("You can only send Block and Embedded Block to Block room.");
                    errMsg += "\n" + sampleList + " is not a Block or Embedded Block.";
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }
            }
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID " + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }
}
