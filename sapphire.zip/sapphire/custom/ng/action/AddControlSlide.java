package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by smitra on 5/4/2016.
 * Modified by msubhra on 8/26/2016
 * Modified by SBaitalik on 9/27/2016
 * <p/>
 * This action is for adding control samples from the Input samples. Input samples should be a child sample.
 */
public class AddControlSlide extends BaseAction {

    private static String MANDATORY_INPUT_SAMPLE_ID = "";
    private static String PROPERTY_CONTROL_SLIDE_FLAG = "C";
    private static String TRAMSTOP_NAME = "";


    @Override
    public void processAction(PropertyList properties) throws SapphireException {


        MANDATORY_INPUT_SAMPLE_ID = properties.getProperty("s_sampleid");
        TRAMSTOP_NAME = properties.getProperty("tramstop");
        String sampleType = properties.getProperty("sampletypeid", "");
        String testcode = properties.getProperty("testcode", "");
        String controltype = properties.getProperty("controltype");
        String slidetype = properties.getProperty("u_type", "");

        String controlSampleID = "";
        if (Util.isNull(sampleType)) {
            sampleType = getSpecimenType(MANDATORY_INPUT_SAMPLE_ID);
        }
        if (Util.isNull(slidetype)) {
            slidetype = getSampleUType(MANDATORY_INPUT_SAMPLE_ID);
        }
        if (SLIDE_TYPE_DATA.contains(slidetype) && !Util.isNull(slidetype)) {
            testcode = getAssociateTestCode(MANDATORY_INPUT_SAMPLE_ID);
            String testcodes[] = StringUtil.split(testcode, ";");
            initilizeDataset();
            for (int i = 0; i < testcodes.length; i++) {
                int rowId = dsInput.addRow();
                dsInput.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID, MANDATORY_INPUT_SAMPLE_ID);
                dsInput.setValue(rowId, DATASET_PROPERTY_SAMPLE_TYPE, sampleType);
                dsInput.setValue(rowId, DATASET_PROPERTY_TESTCODE, testcodes[i]);
                dsInput.setValue(rowId, DATASET_PROPERTY_CONTROLTYPE, "PC");
            }
            String newkeyid1 = createChildSample(dsInput, MANDATORY_INPUT_SAMPLE_ID, sampleType);
            String sql = "select containertypeid,custodialdepartmentid from trackitem where linksdcid='Sample' and linkkeyid1 in ('" + StringUtil.replaceAll(MANDATORY_INPUT_SAMPLE_ID, ";", "','") + "')";
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            updateTrackitem(newkeyid1, ds.getColumnValues("containertypeid", ";"));
            markAsControlSlide("Sample", dsInput);
            addTestCode(dsInput);
            properties.setProperty("newsample", newkeyid1);
            updateCurrentMovement(newkeyid1, "Setup");
            updateTrackItem(newkeyid1);
        } else {
            String testcodes[] = StringUtil.split(testcode, ";");
            String controltypes[] = StringUtil.split(controltype, ";");
            if (testcodes.length != controltypes.length) {
                String errMsg = getTranslationProcessor().translate("Test codes and control type data mismatch.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            initilizeDataset();
            for (int i = 0; i < testcodes.length; i++) {
                int rowId = dsInput.addRow();
                dsInput.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID, MANDATORY_INPUT_SAMPLE_ID);
                dsInput.setValue(rowId, DATASET_PROPERTY_SAMPLE_TYPE, sampleType);
                dsInput.setValue(rowId, DATASET_PROPERTY_TESTCODE, testcodes[i]);
                if ("Negative".equalsIgnoreCase(controltypes[i])) {
                    dsInput.setValue(rowId, DATASET_PROPERTY_CONTROLTYPE, "NC");
                }
                if ("Positive".equalsIgnoreCase(controltypes[i])) {
                    dsInput.setValue(rowId, DATASET_PROPERTY_CONTROLTYPE, "PC");
                }
                //dsInput.setValue(rowId, DATASET_PROPERTY_CONTROLTYPE, controltypes[i]);
            }
            String newkeyid1 = createChildSample(dsInput, MANDATORY_INPUT_SAMPLE_ID, sampleType);
            String sql = "select containertypeid,custodialdepartmentid from trackitem where linksdcid='Sample' and linkkeyid1 in ('" + StringUtil.replaceAll(MANDATORY_INPUT_SAMPLE_ID, ";", "','") + "')";
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            updateTrackitem(newkeyid1, ds.getColumnValues("containertypeid", ";"));
            markAsControlSlide("Sample", dsInput);
            addTestCode(dsInput);
            updateCurrentMovement(newkeyid1, "Setup");
            updateTrackItem(newkeyid1);
            properties.setProperty("newsample", newkeyid1);
        }
        //String url = "<script>top.window.close();sapphire.page.navigate('rc?command=page&page=SetupList&sdcid=Sample&keyid1="+newkeyid1+"', 'Y', '_top')</script>";
        //properties.setProperty("msg", url);
        /*if (TRAMSTOP_NAME.equalsIgnoreCase("SetUp")) {
            controlSampleID = copySample(MANDATORY_INPUT_SAMPLE_ID);
        } else {
            controlSampleID = createChildSample(MANDATORY_INPUT_SAMPLE_ID, sampleType);

        }
        markAsControlSlide("Sample", controlSampleID);
        addTestCode(MANDATORY_INPUT_SAMPLE_ID, controlSampleID);
        String msg = controlSampleID + " child sample with Control flag has been created";
        properties.setProperty("outmsg", msg);*/
    }

    /***
     * START (AS PER JULI's requirement)
     ****/

    /**
     * This method is used for creating child samples from the  Input Samples.
     *
     * @param sampleid   Input Samples(should be a child sample)
     * @param sampletype Sample type of the Input samples
     * @param dsInput    DataSet contains all values
     * @return newkeyid1 New samples which are created under the parent samples of the Input Samples
     * @throws SapphireException
     */
    private String createChildSample(DataSet dsInput, String sampleid, String sampletype) throws SapphireException {
        /*String sql = "select sp.sourcesampleid from s_samplemap sp,s_sample s where sp.destsampleid = s.s_sampleid and s.s_sampleid in ('" + sampleid + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String parentSample = ds.getString(0, "sourcesampleid");
        for (int i = 0; i < dsInput.getRowCount(); i++) {
            dsInput.setValue(i, DATASET_PROPERTY_SAMPLE_ID, sampleid);
        }
        */
        //Creating Control child Sample
        PropertyList props = new PropertyList();
        props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, sampleid);
        props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, String.valueOf(dsInput.getRowCount()));
        props.setProperty(MultiSampleChild.PROPERTY_CHILD_SAMPLETYPEID, sampletype);
        props.setProperty("copydowncolumns", "u_bodysite;sampletypeid;sstudyid;u_accessionid;u_clientspecimenid;specimentype");

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create control sample.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String newkeyid1[] = StringUtil.split(props.getProperty("newkeyid1"), ";");
        for (int i = 0; i < dsInput.getRowCount(); i++) {
            dsInput.setValue(i, DATASET_PROPERTY_SAMPLE_ID, newkeyid1[i]);
        }
        return props.getProperty("newkeyid1");
    }

    private void updateTrackitem(String childsampleid, String containertype) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", containertype);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * This method to add Control flag in u_controlslideflag column of the above created sample in sample table as 'Y'
     *
     * @param sdcid   SDC ID
     * @param dsInput DatSet values
     * @throws SapphireException
     */
    public void markAsControlSlide(String sdcid, DataSet dsInput) throws SapphireException {

        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
        props.setProperty("u_type", dsInput.getColumnValues(DATASET_PROPERTY_CONTROLTYPE, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("u_controlflag not created");
        }

    }

    /**
     * This method is used to add testcode to control samples. This method trackes input as sampleid(parentsample)
     * and childsampleid(newly created sampleid). It will retrive the testcode from and parent sample and add those testcode in the child samples
     *
     * @param dsInput DataSet values
     * @throws SapphireException
     */
    public void addTestCode(DataSet dsInput) throws SapphireException {

        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsInput.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsInput.getColumnValues(DATASET_PROPERTY_TESTCODE, ";"));

        try {
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Test Code not associate.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    /**
     * This method is used to get specimentype of parent sample
     *
     * @param sampleId Sample as input
     * @throws SapphireException
     */
    public String getSpecimenType(String sampleId) throws SapphireException {
        String sql = "select specimentype from s_sample where s_sampleid ='" + sampleId + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String specimentype = ds.getString(0, "specimentype");

        return specimentype;
    }

    public String getSampleUType(String sampleId) throws SapphireException {
        String sql = "select u_type from s_sample where s_sampleid ='" + sampleId + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String u_type = ds.getColumnValues("u_type", ";");

        return u_type;
    }

    public String getAssociateTestCode(String sampleid) throws SapphireException {
        String sql = "select t.u_testcodeid,t.testname,t.los,t.specimentype,t.methodology " +
                "from s_sample s, u_testcode t,u_sampletestcodemap m " +
                "where s.s_sampleid = m.s_sampleid and m.lvtestcodeid = t.u_testcodeid " +
                "and nvl(t.hneflag,'n') ='n' and t.methodology !='Molecular' and (m.teststatus is null or m.teststatus='In Progress') " +
                "and s.s_sampleid =?";
        DataSet dsResult = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{sampleid});
        if (dsResult.getRowCount() == 0) {
            throw new SapphireException("Testcode(s) not associate with the Sample id:" + sampleid);
        }
        String testcodes = dsResult.getColumnValues("u_testcodeid", ";");
        String testnames = dsResult.getColumnValues("testname", ";");
        String methodology = dsResult.getColumnValues("methodology", ";");
        return testcodes;
    }

    public void updateCurrentMovement(String childsampleids, String currentmovement) throws SapphireException {
        String childsampleid[] = StringUtil.split(childsampleids, ";");
        PropertyList propUpdateSampleMap = new PropertyList();
        propUpdateSampleMap.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        propUpdateSampleMap.setProperty(EditSDI.PROPERTY_KEYID1, childsampleids);
        propUpdateSampleMap.setProperty("u_currentmovementstep", StringUtil.repeat(currentmovement, childsampleid.length, ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propUpdateSampleMap);
    }

    public void updateTrackItem(String childsampleids) throws SapphireException {
        String sql = "select trackitemid from trackitem where linkkeyid1 in('" + StringUtil.replaceAll(childsampleids, ";", "','") + "')";
        DataSet dsTrackItem = getQueryProcessor().getSqlDataSet(sql);
        PropertyList propUpdateTrackitem = new PropertyList();
        propUpdateTrackitem.setProperty(EditTrackItem.PROPERTY_SDCID, "TrackItemSDC");
        propUpdateTrackitem.setProperty(EditTrackItem.PROPERTY_KEYID1, dsTrackItem.getColumnValues("trackitemid", ";"));
        propUpdateTrackitem.setProperty("containertypeid", "Slide(s)");
        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, propUpdateTrackitem);
    }

    private DataSet dsInput = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "sampleid";
    private static final String DATASET_PROPERTY_SAMPLE_TYPE = "sampletype";
    private static final String DATASET_PROPERTY_TESTCODE = "testcode";
    private static final String DATASET_PROPERTY_CONTROLTYPE = "controltype";
    private static final String TESTCODE_METHODOLOGY_DATA = "IHC;FISH";
    private static final String SLIDE_TYPE_DATA = "CU;CST;U;CH";

    private void initilizeDataset() throws SapphireException {
        if (dsInput == null) {
            dsInput = new DataSet();
            dsInput.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_SAMPLE_TYPE, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_TESTCODE, DataSet.STRING);
            dsInput.addColumn(DATASET_PROPERTY_CONTROLTYPE, DataSet.STRING);
        }

    }
    /***END (AS PER JULI's requirement)****/
    /**
     * This method is used for creating control samples from the  Input Samples.
     *
     * @param childSampleId Input Samples(should be a child sample)
     * @param sampleType    Sample type of the Input samples
     * @return newkeyid1 New samples which are created under the parent samples of the Input Samples
     * @throws SapphireException
     */

    private String createChildSample(String childSampleId, String sampleType) throws SapphireException {
        String sql = "select sp.sourcesampleid from s_samplemap sp,s_sample s where sp.destsampleid = s.s_sampleid and s.s_sampleid in ('" + childSampleId + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String parentSample = ds.getString(0, "sourcesampleid");

        //Creating Control child Sample
        PropertyList props = new PropertyList();
        props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentSample);
        props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
        props.setProperty(MultiSampleChild.PROPERTY_CHILD_SAMPLETYPEID, sampleType);

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create control sample.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }

        return props.getProperty("newkeyid1", "");
        //return childSampleid;
    }

    /**
     * @param sampleID
     * @return
     */

    public String copySample(String sampleID) throws SapphireException {

        String newsampleid = "";

        //Note: Action excuted in loop. We had a business logic which cannot be cater out side of loop.
        //String[] samparr = StringUtil.split(sampleID,";");
        //for (int i = 0; i < samparr.length; i++) {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(AddSDI.PROPERTY_TEMPLATEID, sampleID);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);

        } catch (SapphireException ex) {
            String errMsg = getTranslationProcessor().translate("Cannot create control sample.");
            errMsg += "\nError Detail:" + ex.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);

        }

        newsampleid = props.getProperty("newkeyid1", "");
        return newsampleid;
    }

    /**
     * This method to add Control flag in u_controlslideflag column of the above created sample in sample table as 'Y'
     *
     * @param sdcid  SDC ID
     * @param keyid1 Primary Key
     * @throws SapphireException
     */


    public void markAsControlSlide(String sdcid, String keyid1) throws SapphireException {

        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
        props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
        props.setProperty("u_type", PROPERTY_CONTROL_SLIDE_FLAG);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception e) {
            throw new SapphireException("u_controlflag not created");
        }

    }

    /**
     * This method is used to add testcode to control samples. This method trakes input as sampleid(parentsample)
     * and childsampleid(newly created sampleid). It will retrive the testcode from and parent sample and add those testcode in the child samples
     *
     * @param sampleId      Input Samples
     * @param childSampleid Newly Created child samples
     * @throws SapphireException
     */


    public void addTestCode(String sampleId, String childSampleid) throws SapphireException {

        if (!Util.isNull(sampleId)) {
            if (!Util.isNull(childSampleid)) {
                String psample = StringUtil.replaceAll(sampleId, ";", "','");
                //String[] samples = StringUtil.split(sampleId, "','");
                //String[] unstainedsample = StringUtil.split(childSampleid, ";");

                String tc_sql = "select s_sampleid,lvtestcodeid,ispanel  from u_sampletestcodemap where s_sampleid in ('" + psample + "')";

                DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);

                if (dstestcode == null) {
                    String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
                    errmsg += "\nQuery failed:\n" + tc_sql;
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
                }
                if (dstestcode.size() == 0) {
                    String error = getTranslationProcessor().translate("SampleID " + psample + " doesn't have any Test !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }

                if (dstestcode.size() > 0) {

                    DataSet dsSamplefinal = new DataSet();
                    dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
                    dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
                    dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

                    DataSet sampleFiltered = new DataSet();
                    HashMap hmFilter = new HashMap();
                    //for (int i = 0; i < samples.length; i++) {
                    hmFilter.clear();
                    sampleFiltered.clear();
                    hmFilter.put("s_sampleid", sampleId);
                    sampleFiltered = dstestcode.getFilteredDataSet(hmFilter);
                    for (int j = 0; j < sampleFiltered.size(); j++) {
                        int rowID = dsSamplefinal.addRow();
                        dsSamplefinal.setValue(rowID, "s_sampleid", childSampleid);
                        dsSamplefinal.setValue(rowID, "lvtestcode", sampleFiltered.getValue(j, "lvtestcodeid"));
                        dsSamplefinal.setValue(rowID, "ispanel", sampleFiltered.getValue(j, "ispanel", ""));
                    }


                    PropertyList hsAddTestCode = new PropertyList();
                    hsAddTestCode.clear();
                    hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
                    hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
                    hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
                    hsAddTestCode.setProperty("workitemflag", "N");//todo
                    hsAddTestCode.setProperty("bypassvalidation", "Y");

                    try {
                        getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
                    } catch (ActionException e) {
                        String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch. ");
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                    }
                }
/*
        /*String sql = "select LVTESTCODEID,ispanel from u_sampletestcodemap where S_SAMPLEID = '" + sampleId + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds == null){
            String errMsg =getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg+="\nQuery returns null, Query failed:"+sql;

            throw new SapphireException(ErrorDetail.TYPE_FAILURE,errMsg);

        }
        if(ds.size()==0){
            String errMsg =getTranslationProcessor().translate("No Test code found for source sample.");
            errMsg+="\nSampleID:"+sampleId+", Query retuns no rows:"+sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,errMsg);
        }

        String testCode = ds.getString(0, "LVTESTCODEID");
        String panelid = ds.getString(0,"ispanel","");
        PropertyList pl = new PropertyList();
        pl.setProperty("s_sampleid", childSampleid);
        pl.setProperty("lvtestcode", testCode);
        pl.setProperty("ispanel",panelid);
        pl.setProperty("bypassvalidation", "Y");
        pl.setProperty("workitemflag", "Y");


        try {

            getActionProcessor().processAction("AddTestCode", "1", pl);
        } catch (SapphireException e) {
            throw new SapphireException("Unable to assign Test code to control slide"+e.getMessage());
        }
*/

            }
        }
    }


}
