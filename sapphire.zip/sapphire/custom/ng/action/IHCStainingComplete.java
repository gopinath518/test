package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.SimpleDateFormat;
import java.util.Date;

/****
 * Created by surajit.baitalik
 * Description: This is used to complete staining for slide(s).
 */
public class IHCStainingComplete extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1", "");
        String u_hl7result = properties.getProperty("u_hl7result", "");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep", "");
        String u_currenttramstop = properties.getProperty("u_currenttramstop", "");
        if (Util.isNull(keyid1)) {
            throw new SapphireException("Please select specimen(s).");
        }
        DataSet dsFinal=backupAssignToArchaive(keyid1,u_hl7result,u_currentmovementstep,u_currenttramstop);
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("keyid", ";"));
        props.setProperty("u_hl7result", dsFinal.getColumnValues("u_hl7result", ";"));
        props.setProperty("u_currentmovementstep", dsFinal.getColumnValues("u_currentmovementstep", ";"));
        props.setProperty("u_staincompletedt", "n");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update specimen movements step." + ex.getMessage());
        }
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFinal.getColumnValues("keyid", ";"));
        props.setProperty("u_currenttramstop", dsFinal.getColumnValues("u_currenttramstop", ";"));
        props.setProperty("custodialdepartmentid", dsFinal.getColumnValues("custodialdepartmentid", ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update department" + ex.getMessage());
        }
        enterIHCStainingDate(keyid1);
    }
    /*
     * After stain completed Backup slide will route to  HistologyArchive and other will route to QC
     */
    private DataSet backupAssignToArchaive(String sampleid,String u_hl7result,String u_currentmovementstep,String u_currenttramstop) throws  SapphireException{
    	String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String site = department.substring(0, department.lastIndexOf('-'));
    	String sqlBackupSlide = Util.parseMessage(ApSql.SPECIMEN_INFO, StringUtil.replaceAll(sampleid, ";", "','"));
    	DataSet dsBackupSlide = getQueryProcessor().getSqlDataSet(sqlBackupSlide);
        if (dsBackupSlide == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlBackupSlide;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        DataSet dsFinal=new DataSet();
        dsFinal.addColumn("keyid", DataSet.STRING);
        dsFinal.addColumn("u_hl7result", DataSet.STRING);
        dsFinal.addColumn("u_currentmovementstep", DataSet.STRING);
        dsFinal.addColumn("u_currenttramstop", DataSet.STRING);
        dsFinal.addColumn("custodialdepartmentid", DataSet.STRING);
        int incr=0;
        for(int i=0;i<dsBackupSlide.size();i++){
        	incr=dsFinal.addRow();
        	dsFinal.setValue(incr, "keyid", dsBackupSlide.getValue(i, "s_sampleid"));
        	dsFinal.setValue(incr, "u_hl7result", u_hl7result);
        	dsFinal.setValue(incr, "u_currentmovementstep", u_currentmovementstep);
        	if("B".equalsIgnoreCase(dsBackupSlide.getValue(i, "u_type"))){
        		dsFinal.setValue(incr, "u_currentmovementstep", "HistologyArchive");
        		dsFinal.setValue(incr, "u_currenttramstop", "HistologyArchive");
        		dsFinal.setValue(incr, "custodialdepartmentid", site+"-Accessioning");
        	}else{
        		dsFinal.setValue(incr, "u_currentmovementstep", u_currentmovementstep);
        		dsFinal.setValue(incr, "u_currenttramstop", u_currenttramstop);
        		dsFinal.setValue(incr, "custodialdepartmentid",site+"-AP");
        	}
        }
        return dsFinal;
    }

    private void enterIHCStainingDate(String sampleid) throws SapphireException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
        Date date = new Date();
        String crrntdt = formatter.format(date);
        DataSet dsSpecialTestcodes = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "IHC Staining Date");
        if (dsSpecialTestcodes.size() > 0) {
            String staindttestcodes = StringUtil.replaceAll(dsSpecialTestcodes.getColumnValues("testcode", ";"), ";", "','");
            String sampleTestReagenrom = Util.parseMessage(ApSql.GET_TESTTS_FOR_STAINING, StringUtil.replaceAll(sampleid, ";", "','"), staindttestcodes);
            DataSet dsTestReagenRom = getQueryProcessor().getSqlDataSet(sampleTestReagenrom);
            if (dsTestReagenRom != null && dsTestReagenRom.size() > 0) {
                String testname = StringUtil.replaceAll(dsTestReagenRom.getColumnValues("testname", ";"), ";", "','");
                String slides = StringUtil.replaceAll(dsTestReagenRom.getColumnValues("s_sampleid", ";"), ";", "','");
                String sqlenterdata = Util.parseMessage(ApSql.GET_PARAMIDS_BY_IHC_STATINIG, slides, testname);//IHC Staining Date
                DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
                if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                    props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                    props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                    props.setProperty("enteredtext", StringUtil.repeat(crrntdt.toUpperCase(), dsSqlEnterData.size(), ";"));
                    props.setProperty("displayvalue", StringUtil.repeat(crrntdt.toUpperCase(), dsSqlEnterData.size(), ";"));
                    try {
                        getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                    } catch (SapphireException e) {
                        throw new SapphireException("IHC Staining date  not performed." + e.getMessage());
                    }
                }
            }
        }
    }
}
