package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.ArrayList;
import java.util.HashMap;

/***
 * Action Name- CreateHemeExtractionTube
 * Description: This Action is use to create Extraction tube for heme type of sample
 * input :-
 * param1-sampleid
 * throws SapphireException
 * Created by mpandey on 9/18/2016.
 * Modified by surajit
 */
public class CreateHemeExtractionTube extends BaseAction {
    String requestID = "";
    String parentsampleid = "";
    String input_requestID = "";
    String molecularsubmethodology = "";
    String hascoldt = "";
    public static final String PROSTATETESTCODE = "4205X";

    public void processAction(PropertyList properties) throws SapphireException {

        String newsampleid = "";
        String extractionType = "";
        String sampleType = "";
        String sampleInfo = "";
        DataSet dsParentSampleInfo = null;

        parentsampleid = properties.getProperty("keyid1");
        extractionType = properties.getProperty("extractiontype");
        hascoldt = properties.getProperty("hascoldt", "");
        molecularsubmethodology = properties.getProperty("molecularsubmethodology");
        if ("NanoString".equalsIgnoreCase(molecularsubmethodology)) {
            String sql = "select u_sampletestcodemapid,extractiontype,lvtestcodeid from u_sampletestcodemap where s_sampleid in('" + parentsampleid + "')" +
                    " and molecularsubmethodology='NanoString'";
            DataSet dsUSS = getQueryProcessor().getSqlDataSet(sql);
            String testcodeid = dsUSS.getValue(0, "lvtestcodeid", "");
            DataSet dsNanoExtrctnType = getExtractionTypeForNanoString();
            HashMap hm = new HashMap();
            hm.put("testcodeid", testcodeid);
            DataSet dsExtrcFilter = dsNanoExtrctnType.getFilteredDataSet(hm);
            if (dsExtrcFilter.size() > 0) {
                String extrcs = dsExtrcFilter.getColumnValues("extractiontype", ";");
                if (extrcs.contains(extractionType)) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsUSS.getColumnValues("u_sampletestcodemapid", ";"));
                    prop.setProperty("extractiontype", StringUtil.repeat(extractionType, dsUSS.size(), ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } else {
                    String errorr = "Select a specimen which has extraction type is " + extractionType;
                    throw new SapphireException(errorr);
                }
            }
            /*PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsUSS.getColumnValues("u_sampletestcodemapid", ";"));
            prop.setProperty("extractiontype", StringUtil.repeat(extractionType, dsUSS.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);*/
        }
        if (parentsampleid.length() > 0)
            checkForRequestId(parentsampleid);
        dsParentSampleInfo = getParentSampleInfo(parentsampleid);
        //extractionType = dsParentSampleInfo.getValue(0, "extractiontype");
        sampleType = dsParentSampleInfo.getValue(0, "sampletype");
        sampleInfo = dsParentSampleInfo.getValue(0, "sampleinfo");
        newsampleid = hemeextractiontube(properties, extractionType, sampleInfo, sampleType);
        //updateTrackitem(newsampleid);
        properties.setProperty("newkeyid1", newsampleid);

        //throw new SapphireException("tex");
    }

    public DataSet getExtractionTypeForNanoString() throws SapphireException {
        DataSet dsNanoExtr = new DataSet();
        dsNanoExtr.addColumn("testcodeid", DataSet.STRING);
        dsNanoExtr.addColumn("extractiontype", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("NanoStringExtractionTypePolicy", "NanoStringExtractionType");
        PropertyListCollection plctestcodelist = plMicroPolicy.getCollection("testcodelist");
        if (plctestcodelist == null)
            throw new SapphireException("Extraction type is not defined for NanoString-> Policy.");
        //PropertyListCollection plclosmap = plctestcodelist.getCollection("extractiontypelist");
        for (int i = 0; i < plctestcodelist.size(); i++) {
            String testcodeid = plctestcodelist.getPropertyList(i).getProperty("testcodeid");
            PropertyListCollection plExtractionTypeList = plctestcodelist.getPropertyList(i).getCollection("extractiontypelist");
            for (int j = 0; j < plExtractionTypeList.size(); j++) {
                String extractiontype = plExtractionTypeList.getPropertyList(j).getProperty("extractiontype");
                int rowID = dsNanoExtr.addRow();
                dsNanoExtr.setValue(rowID, "testcodeid", testcodeid);
                dsNanoExtr.setValue(rowID, "extractiontype", extractiontype);
                //extractionreagentprops.setProperty(reagenttype, extractionetype);
            }
        }
        return dsNanoExtr;
    }

    /**
     * This method is use to update containertype in trackitem.
     *
     * @param childsampleid
     * @throws SapphireException
     */
    private void updateTrackitem(String childsampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", "Extraction Tube");
        // props.setProperty("custodialuserid", currentuser);
        // props.setProperty("custodialdepartmentid", defaultdepartment);
        // props.setProperty("custodytakendt", "n");
        // props.setProperty("qtycurrent", volume);
        // props.setProperty("qtyunits", units);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * This function is use to create pool sample
     *
     * @param parentsampleid
     * @param poolcopies
     * @return
     * @throws SapphireException
     */

    private String createPoolSample(String parentsampleid, int poolcopies, String extractionType) throws SapphireException {

        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "SELECT distinct t.qtycurrent,t.containertypeid,t.custodialdepartmentid," +
                "  t.qtyunits,s.u_sampleinformation" +
                " FROM trackitem t," +
                "  s_sample s" +
                " WHERE t.linksdcid = 'Sample'" +
                " AND t.linkkeyid1  = s.s_sampleid" +
                " AND s.s_sampleid " +
                " in('" + qrsample + "')";
        DataSet dstrack = getQueryProcessor().getSqlDataSet(sql);

        if (dstrack.size() == 0) {
            String error = getTranslationProcessor().translate("Trackitem is not defined for sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        PropertyList props = new PropertyList();
        String newkeyid1;
        props.setProperty("sampleid", parentsampleid);
        DataSet dsExtractionPrefix = Util.getExtractionPrefix(getConfigurationProcessor());
        if (dsExtractionPrefix == null || dsExtractionPrefix.size() == 0) {
            throw new SapphireException("Extraction Prefix Policy not define into system.");
        }
        HashMap hmprefix = new HashMap();
        hmprefix.clear();
        hmprefix.put("extractiontype", extractionType);
        DataSet dsExtractionFilter = dsExtractionPrefix.getFilteredDataSet(hmprefix);
        String samplevolume = dsExtractionFilter.getValue(0, "samplevolume", "10");
        props.setProperty("quantity", samplevolume);
        props.setProperty("poolquantity", samplevolume);
        /*if ("DNA".equalsIgnoreCase(extractionType)) {
            props.setProperty("quantity", "100");
            props.setProperty("poolquantity", "100");
        } else if ("RNA".equalsIgnoreCase(extractionType)) {
            props.setProperty("quantity", "100");
            props.setProperty("poolquantity", "100");
        } else if ("TNA".equalsIgnoreCase(extractionType)) {
            props.setProperty("quantity", "50");
            props.setProperty("poolquantity", "50");
        } else if ("PLASMA".equalsIgnoreCase(extractionType)) {
            props.setProperty("quantity", "25");
            props.setProperty("poolquantity", "25");
        } else {
            props.setProperty("quantity", "10");
            props.setProperty("poolquantity", "10");
        }*/
        props.setProperty("poolcopies", String.valueOf(poolcopies));
        props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        props.setProperty("poolcustodialdepartmentid", connectionInfo.getDefaultDepartment()); //todo

        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);

        } catch (Exception e) {
            String error = getTranslationProcessor().translate("Unable to create pool sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        newkeyid1 = props.getProperty("newkeyid1", "");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        Util.setRootForPoolSample(newkeyid1, parentsampleid, getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        return newkeyid1;
    }

    /**
     * This function is use to update information of newly created sample.
     *
     * @param newsampleid
     * @param parentsampleid
     * @param sampleinfo
     * @throws SapphireException
     */
    private void editSampleSDI(String newsampleid, String parentsampleid, String sampleinfo) throws SapphireException {
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "select distinct u_accessionid,u_sampleinformation,u_clientspecimenid,u_currentmovementstep  from s_sample where s_sampleid " +
                " in('" + qrsample + "')";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sql);

        if (dsSamp.size() == 0) {
            String error = getTranslationProcessor().translate("Sample must belongs to same accesion ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, newsampleid);
        editProp.setProperty("u_accessionid", StringUtil.repeat(dsSamp.getValue(0, "u_accessionid", ""), newsampleid.split(";").length, ";"));
        editProp.setProperty("u_sampleinformation", sampleinfo);
        editProp.setProperty("u_clientspecimenid", StringUtil.repeat(dsSamp.getValue(0, "u_clientspecimenid", ""), newsampleid.split(";").length, ";"));
        editProp.setProperty("u_currentmovementstep", StringUtil.repeat(dsSamp.getValue(0, "u_currentmovementstep", ""), newsampleid.split(";").length, ";"));

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This fuction is use to create extraction tube, attach testcode in it and
     * create extractionid for it .
     *
     * @param properties
     * @param extractionType
     * @param sampleInfo
     * @param sampleType
     * @return
     * @throws SapphireException
     */

    private String hemeextractiontube(PropertyList properties, String extractionType, String sampleInfo, String sampleType) throws SapphireException {
        String newsampleid = "";
        String parentsampleid = "";
        int poolcopies = 1;
        String extractionid = "";

        parentsampleid = properties.getProperty("keyid1");
        newsampleid = createPoolSample(parentsampleid, poolcopies, extractionType);
        editSampleSDI(newsampleid, parentsampleid, sampleInfo);
        updateTrackitem(newsampleid);

        //Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor());
        if ("NanoString".equalsIgnoreCase(molecularsubmethodology)) {
            Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor(), "Molecular");
            String sql = "select u_sampletestcodemapid,extractiontype from u_sampletestcodemap where s_sampleid in('" + newsampleid + "')" +
                    " and molecularsubmethodology='NanoString'";
            DataSet dsUSS = getQueryProcessor().getSqlDataSet(sql);
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsUSS.getColumnValues("u_sampletestcodemapid", ";"));
            prop.setProperty("extractiontype", StringUtil.repeat(extractionType, dsUSS.size(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } else {
            copyTestCodeFromParentByExtractionType(newsampleid, getQueryProcessor(), getActionProcessor(), extractionType);
        }

        if (requestID.length() > 0) {
            extractionid = getReExtractExtractionId(requestID);
            if (extractionid.length() > 0)
                updateExtractionID(newsampleid, extractionid);
        } else {
            String extractionIdOnCond = getExtIdOnSpecialCond(newsampleid, extractionType, sampleInfo, sampleType);
            if (extractionIdOnCond.length() == 0)
                createExtractionID(newsampleid, extractionType, "");
        }

        return newsampleid;

    }

    /**
     * This fuction is use to get extractionid for special conditions.
     *
     * @param newsampleid
     * @param extractiontype
     * @param sampleInfo
     * @param sampleType
     * @return
     * @throws SapphireException
     */
    private String getExtIdOnSpecialCond(String newsampleid, String extractiontype, String sampleInfo, String sampleType) throws SapphireException {
        String newExtractionId = "";
        String tail = "";
        String testname = "";
        String pairSampleInfo = "";
        String checkexttype = "";
        String prevextractionds = "";
        if (Util.isNull(hascoldt) || !"Y".equalsIgnoreCase(hascoldt)) {
            prevextractionds = "select sm.destsampleid,(select u_extractionid from s_sample where s_sample.s_sampleid = sm.destsampleid) extractionid," +
                    " s.u_accessionid, s.collectiondt from s_sample s, s_samplemap sm,u_sampletestcodemap stm where" +
                    " s.u_accessionid = (select u_accessionid from s_sample where s_sampleid = '" + parentsampleid + "')" +
                    " and s.collectiondt = (select collectiondt from s_sample where s_sampleid = '" + parentsampleid + "')" +
                    " and s.u_clientspecimenid = (select u_clientspecimenid from s_sample where s_sampleid = '" + parentsampleid + "')" +
                    " and s.s_sampleid = sm.sourcesampleid and s.s_sampleid=stm.s_sampleid and stm.methodology='Molecular' and (select u_extractionid from s_sample" +
                    " where s_sample.s_sampleid = sm.destsampleid ) is not null";
        } else {
            prevextractionds = "select sm.destsampleid,(select u_extractionid from s_sample where s_sample.s_sampleid = sm.destsampleid) extractionid," +
                    " s.u_accessionid, s.collectiondt from s_sample s, s_samplemap sm,u_sampletestcodemap stm where" +
                    " s.u_accessionid = (select u_accessionid from s_sample where s_sampleid = '" + parentsampleid + "')" +
                    " and s.collectiondt is null" +
                    " and s.u_clientspecimenid = (select u_clientspecimenid from s_sample where s_sampleid = '" + parentsampleid + "')" +
                    " and s.s_sampleid = sm.sourcesampleid  and s.s_sampleid=stm.s_sampleid  and stm.methodology='Molecular' and (select u_extractionid from s_sample" +
                    " where s_sample.s_sampleid = sm.destsampleid ) is not null";
        }
        DataSet dsprevextractionid = getQueryProcessor().getSqlDataSet(prevextractionds);

        if (dsprevextractionid == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + prevextractionds;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }


        if (dsprevextractionid.size() > 0) {

            // String exsql = "select u_extractionid from s_sample where s_sampleid = '" + dsprevextractionid.getValue(0, "destsampleid") + "'";
            String exsql = "select distinct sm.extractiontype,s.u_extractionid " +
                    " from u_sampletestcodemap sm,s_sample s" +
                    " where s.s_sampleid=sm.s_sampleid and sm.methodology='Molecular' and sm.s_sampleid  IN ('" + dsprevextractionid.getColumnValues("destsampleid", "','") + "') and sm.extractiontype is not null";
            DataSet extraxtds = getQueryProcessor().getSqlDataSet(exsql);
            // newExtractionId = extraxtds.getColumnValues("u_extractionid", ";");
            HashMap filter = new HashMap();
            filter.put("extractiontype", extractiontype);
            DataSet filteredds = extraxtds.getFilteredDataSet(filter);
            if (filteredds.size() > 0)
                newExtractionId = filteredds.getValue(0, "u_extractionid");

        }
        if (newExtractionId.length() > 0) {
            updateExtractionID(newsampleid, newExtractionId);
            return newExtractionId;

        } else if (sampleType.equalsIgnoreCase("Urine")) {
            //Prostate testcode(4205X) varification
            String sql = "select count(1) procount from u_sampletestcodemap where lvtestcodeid='" + PROSTATETESTCODE + "'" +
                    " and s_sampleid='" + newsampleid + "' and methodology='Molecular'";
            DataSet dspro = getQueryProcessor().getSqlDataSet(sql);
            if (dspro == null) {
                String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
            if (dspro.size() > 0 && Integer.parseInt(dspro.getValue(0, "procount", "0")) > 0) {
                newExtractionId = createExtractionID(newsampleid, extractiontype, "U");
                return newExtractionId;
            }
        } else if (sampleInfo.equalsIgnoreCase("Normal") || sampleInfo.equalsIgnoreCase("Tumor")) {
            if (sampleInfo.equalsIgnoreCase("Normal")) {
                tail = "N";
                testname = "MSI";
                pairSampleInfo = "Tumor";
            } else if (sampleInfo.equalsIgnoreCase("Tumor")) {
                tail = "T";
                testname = "MSI";
                pairSampleInfo = "Normal";
            }
            String sql = "select count(1) testcount from u_sampletestcodemap where testname='" + testname + "'" +
                    " and s_sampleid='" + newsampleid + "' and methodology='Molecular'";
            DataSet dsTest = getQueryProcessor().getSqlDataSet(sql);
            if (dsTest == null) {
                String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
            String s_sql = "select s.u_extractionid from s_sample s,u_sampletestcodemap stm where s.s_sampleid=stm.s_sampleid  and " +
                    "s.u_accessionid=(select s.u_accessionid from s_sample s,u_sampletestcodemap stm where s.s_sampleid=stm.s_sampleid and stm.testname='" + testname + "' and stm.s_sampleid='" + newsampleid + "')" +
                    " and s.u_sampleinformation in ('" + pairSampleInfo + "') and stm.testname='" + testname + "' and stm.methodology='Molecular' and s.u_extractionid is not null";
            DataSet dsext = getQueryProcessor().getSqlDataSet(s_sql);
            if (dsext == null) {
                String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + s_sql;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }

            if (dsext.size() > 0 && Integer.parseInt(dsTest.getValue(0, "testcount", "0")) > 0) {
                String[] arrExtId = dsext.getValue(0, "u_extractionid", "").split("-");
                if (arrExtId.length > 1)
                    newExtractionId = arrExtId[0] + "-" + arrExtId[1] + "-" + tail;
                updateExtractionID(newsampleid, newExtractionId);
                return newExtractionId;
            } //else if (dsext.size() == 0 && Integer.parseInt(dsTest.getValue(0, "testcount", "0")) > 0) {
            else if (dsext.size() == 0 && Integer.parseInt(dsTest.getValue(0, "testcount", "0")) == 0) {
                newExtractionId = createExtractionID(newsampleid, extractiontype, tail);
                return newExtractionId;
            }
        }
        return "";
    }

    private void checkForRequestId(String sampleid) throws SapphireException {
        String sql = "select distinct ror.incidentrequestid from u_repeatopsrequest ror,u_repeatops ro where ro.requestid=ror.incidentrequestid and ror.sampleid in " +
                " ('" + sampleid.replaceAll(";", "','") + "') and  ror.operations in('ReExtract','Re-Extract') and ro.ispending='Y'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null) {
            String error = "Something error occured. Please contact your Administrator.";
            error += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (ds.size() == 0) {
            return;
        }
        if (ds.size() > 1)
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Multiple requestId found in Extraction Tube to Re-Extract.");
        input_requestID = ds.getValue(0, "incidentrequestid", "");
    }

    /**
     * This method is use to create unique sequence for exractionid
     *
     * @param newsampleid
     * @param extractionType
     * @param sampleInfo
     * @return
     * @throws SapphireException
     */
    private String createExtractionID(String newsampleid, String extractionType, String sampleInfo) throws SapphireException {

        PropertyList hsCreateExtractionID = new PropertyList();
        hsCreateExtractionID.clear();
        hsCreateExtractionID.setProperty("sampleid", newsampleid);
        hsCreateExtractionID.setProperty("extractiontype", extractionType);
        hsCreateExtractionID.setProperty("suffix", sampleInfo);

        try {
            getActionProcessor().processAction("CreateExtractionID", "1", hsCreateExtractionID);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed CreateExtractionID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        return hsCreateExtractionID.getProperty("extractionid", "");
    }

    /**
     * This method is use to get information about parent sample.
     *
     * @param parentsampleid
     * @return
     * @throws SapphireException
     */
    private DataSet getParentSampleInfo(String parentsampleid) throws SapphireException {
        String extractionType = "";
        String sampleType = "";
        String sampleInfo = "";
        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String s_sql = "select distinct sm.extractiontype,s.u_sampleinformation,s.sampletypeid" +
                " from u_sampletestcodemap sm,s_sample s" +
                " where s.s_sampleid=sm.s_sampleid and sm.s_sampleid  IN ('" + psample + "') and sm.extractiontype is not null";
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(s_sql);
        if (dsSampleInfo == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + s_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsSampleInfo.size() == 0) {
            String error = getTranslationProcessor().translate("Extraction type is not defined for Samples");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        extractionType = dsSampleInfo.getColumnValues("extractiontype", ";");
        extractionType = Util.getUniqueList(extractionType, ";", true);

        /*if (extractionType.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Samples have more than one extraction type ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }*/
        if (extractionType.length() == 0) {
            String error = getTranslationProcessor().translate("Extraction type is not defined for Samples");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        sampleType = dsSampleInfo.getColumnValues("sampletypeid", ";");
        sampleType = Util.getUniqueList(sampleType, ";", true);
        if (sampleType.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Sample have more then one sample type ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        sampleInfo = dsSampleInfo.getColumnValues("u_sampleinformation", ";");
        sampleInfo = Util.getUniqueList(sampleInfo, ";", true);
        if (sampleInfo.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Samples have more then one sample information");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        DataSet dsReturn = new DataSet();
        dsReturn.addColumn("extractiontype", DataSet.STRING);
        dsReturn.addColumn("sampletype", DataSet.STRING);
        dsReturn.addColumn("sampleinfo", DataSet.STRING);
        int rowID = dsReturn.addRow();
        dsReturn.setValue(rowID, "extractiontype", extractionType);
        dsReturn.setValue(rowID, "sampletype", sampleType);
        dsReturn.setValue(rowID, "sampleinfo", sampleInfo);
        return dsReturn;
    }

    /**
     * This function is use mark a sample as re Extracted
     * by updating its extractionid
     *
     * @param requestid
     * @return
     */
    private String getReExtractExtractionId(String requestid) throws SapphireException {
        String ExtractionId = "";
        String rxSuffix = "RX";
        String reExtractCount = "";
        String sql = "select distinct ro.orgextractionid,rod.operation from u_repeatops ro,u_repeatopsdetail rod where ro.u_repeatopsid=rod.u_repeatopsid and ro.orgextractionid=(select orgextractionid from u_repeatops where requestid='" + requestid + "' )and rod.operation='RX'";
        DataSet dsRepeat = getQueryProcessor().getSqlDataSet(sql);
        if (dsRepeat == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsRepeat.size() == 0) {
            String error = getTranslationProcessor().translate("Invalid Request Id. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        if (dsRepeat.size() > 0 && dsRepeat != null) {
            ExtractionId = dsRepeat.getValue(0, "orgextractionid");
            reExtractCount = String.valueOf(dsRepeat.getRowCount());
            if (dsRepeat.size() == 1)
                ExtractionId = ExtractionId + "-" + rxSuffix;
            else
                ExtractionId = ExtractionId + "-" + reExtractCount + rxSuffix;
        }
        return ExtractionId;
    }

    /**
     * This Function is use to update Extraction id in sample sdi.
     *
     * @param sample
     * @param extractionid
     * @throws SapphireException
     */
    private void updateExtractionID(String sample, String extractionid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sample);
        pl.setProperty("u_extractionid", extractionid);

        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Extraction id not updated for " + sample);
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

    }

    public static void copyTestCodeFromParentByExtractionType(String childSampleID, QueryProcessor qp, ActionProcessor ap, String extractiontype) throws SapphireException {

        String sql = "select m.sourcesampleid parentsampleid,m.destsampleid childsampleid, st.lvtestcodeid,st.extractiontype" +
                ",nvl(st.ispanel,'N')ispanel,st.lvtestpanelid" +
                " from s_sample s, s_samplemap m, u_sampletestcodemap st" +
                " where s.s_sampleid  = m.destsampleid and st.s_sampleid = m.sourcesampleid" +
                " and st.methodology='Molecular' and st.extractiontype='" + extractiontype + "'" +
                " and s.s_sampleid in('" + StringUtil.replaceAll(childSampleID, ";", "','") + "')";

        DataSet dsChildTestCode = qp.getSqlDataSet(sql);
        if (dsChildTestCode == null || dsChildTestCode.size() == 0) {
            return;
        }
        DataSet dsAddTestCodes = new DataSet();
        dsAddTestCodes.addColumn("childsampleid", DataSet.STRING);
        dsAddTestCodes.addColumn("testcodeid", DataSet.STRING);//This can be panelcode/testcode
        dsAddTestCodes.addColumn("testpanelcodeid", DataSet.STRING);// this is panel code if above is testcode

        dsChildTestCode.sort("childsampleid");
        ArrayList groupByChildArray = dsChildTestCode.getGroupedDataSets("childsampleid");

        HashMap hmFilter = new HashMap();
        String abc = "";
        for (int i = 0; i < groupByChildArray.size(); i++) {
            DataSet dsEach = (DataSet) groupByChildArray.get(i); // This can be mix of panel & testcode

            String eachChildSampleForPanel = "";
            String lvTestPanelCode = "";
            String lvTestCode = "";
            String lvPanelForTestCode = "";
            String eachChildSampleForTestCode = "";

            if (dsEach != null && dsEach.size() > 0) {
                eachChildSampleForTestCode = Util.getUniqueList(dsEach.getColumnValues("childsampleid", ";"), ";", true);//This will be only one test code
                lvTestCode = Util.getUniqueList(dsEach.getColumnValues("lvtestcodeid", ";"), ";", true);
                int noOfTestCodes = StringUtil.split(lvTestCode, ";").length;

                lvPanelForTestCode = StringUtil.repeat(Util.getUniqueList(dsEach.getColumnValues("lvtestpanelid", ";"), ";", true), noOfTestCodes, ";");
                eachChildSampleForTestCode = StringUtil.repeat(eachChildSampleForTestCode, noOfTestCodes, ";");
            }

            int rowID = dsAddTestCodes.addRow();
            dsAddTestCodes.setValue(rowID, "childsampleid", eachChildSampleForTestCode);
            dsAddTestCodes.setValue(rowID, "testcodeid", lvTestCode);
            dsAddTestCodes.setValue(rowID, "testpanelcodeid", lvPanelForTestCode);

        }


        String aSample = "";
        String aTestCodes = "";
        String aTestPanelCodes = "";
        for (int i = 0; i < dsAddTestCodes.getRowCount(); i++) {
            aSample += ";" + dsAddTestCodes.getValue(i, "childsampleid");
            aTestCodes += ";" + dsAddTestCodes.getValue(i, "testcodeid");
            aTestPanelCodes += ";" + dsAddTestCodes.getValue(i, "testpanelcodeid");
        }
        aSample = aSample.substring(1);
        aTestCodes = aTestCodes.substring(1);
        aTestPanelCodes = aTestPanelCodes.substring(1);

        PropertyList pl = new PropertyList();
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, aSample);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, aTestCodes);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, aTestPanelCodes);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");
        try {
            ap.processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
        } catch (Exception ex) {
            throw new SapphireException("Unable to add testcode.");
        }
        //TODO NOT REQUIRED FOR DELETE EXTRACTION TUBE SCENARIO
        String mapid = pl.getProperty("sampletestcodemapid");
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        props.setProperty(EditSDI.PROPERTY_KEYID1, mapid);
        props.setProperty("extractiontype", dsChildTestCode.getValue(0, "extractiontype", ""));
        try {
            ap.processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update extraction type.");
        }
    }
}
