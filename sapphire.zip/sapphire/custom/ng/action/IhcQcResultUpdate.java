package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.RecordIncident;
import sapphire.action.SubmitSDIForApproval;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by DMondal on 11/25/2016.
 */
public class IhcQcResultUpdate extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        /*   9 May 17 DG
            Commenting out it because in Bio Pharma we dont need to generate Request / incident id
                for any king of value of choice selected
        in Bio Pharma repeat is Manual process
        */
        String sample = properties.getProperty("sample");
        if (Util.isNull(sample)) {
            String errStr = getTranslationProcessor().translate("Selected sampleid not found.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        DataSet daChoice = getChoice(sample);
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String user = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String dept = department.substring(0, department.indexOf("-"));
        String requestid = "";
        String sampleToDispose = "";
        int incr = 0;

        poputaleQCuserDTS(sample);

        if (daChoice != null && daChoice.getRowCount() > 0) {
            initializeDataSet();
            for (int i = 0; i < daChoice.size(); i++) {
                String choice = daChoice.getString(i, "u_choice", "");
                /*
                * || choice.equalsIgnoreCase("Unsatisfactory- Release")
                        || choice.equalsIgnoreCase("QNS- Release materials to client for their review")
                        || choice.equalsIgnoreCase("QNS- Pending the submission of additional materials")
                        || choice.equalsIgnoreCase("QNS- Quantity Not Sufficient")
                        || choice.equalsIgnoreCase("TNP-Test not performed")
                * */
                if (choice.equalsIgnoreCase("Repeat") ) {

                    /*String msg = choice + " for sample -" + daChoice.getString(i, "s_sampleid") + ", Block id " + daChoice.getString(i, "u_clientspecimenid")
                            + " from accession # " + daChoice.getString(i, "u_accessionid");
                    PropertyList recordProp = new PropertyList();
                    recordProp.setProperty("sourcesdcid", "Sample");
                    recordProp.setProperty("sourcekeyid1", daChoice.getString(i, "s_sampleid"));
                    recordProp.setProperty("incidentcategory", "UnPlanned");
                    recordProp.setProperty("incidentdesc", choice);
                    recordProp.setProperty("explanation", "Stain Qc request for " + choice + "." + msg);
                    recordProp.setProperty("rootcause", "Stain Qc request for " + choice + "." + msg);
                    recordProp.setProperty("u_fromdepartment", department);
                    recordProp.setProperty("initialstatus", "PendingApproval");
                    recordProp.setProperty("reportedby", user);
                    recordProp.setProperty("u_message", msg);*/
                    if (choice.equalsIgnoreCase("Repeat")) {
                        //String deptrt = checkBackUpSlides(daChoice.getString(i, "s_sampleid"), dept);
                       // recordProp.setProperty("departmentid", deptrt);
                        incr = dsRepeat.addRow();
                        dsRepeat.setValue(incr, DATASET_PROPERTY_SAMPLE_ID, daChoice.getString(i, "s_sampleid"));
                        dsRepeat.setValue(incr, DATASET_PROPERTY_CHOICE, choice);
                    } else {
                        /*String siteDept = dept + "-ClientServices";
                        String deptrt = deptValidate(siteDept);
                        recordProp.setProperty("departmentid", deptrt);*/
                    }
                   /* getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);
                    PropertyList approvalProps = new PropertyList();
                    approvalProps.setProperty("sdcid", "LV_Incdt");
                    approvalProps.setProperty("keyid1", recordProp.getProperty("newkeyid1"));
                    approvalProps.setProperty("pendingapprovalstatus", "PendingApproval");
                    approvalProps.setProperty("approvalstatus", "Approved");
                    approvalProps.setProperty("approvalstatuscolumn", "incidentstatus");
                    getActionProcessor().processAction(SubmitSDIForApproval.ID, SubmitSDIForApproval.VERSIONID, approvalProps);

                    String request = recordProp.getProperty("newkeyid1");
                    requestid = requestid + "," + request;*/

                }
            }
            /*String[] requestArr = requestid.split(",");
            if (requestArr.length > 1) {

                //IN BIO-PHARMA, NO REQUEST WILL BE GENERATED (SURAJIT 10-MAY-2017) STARTS

                //String finalmsg = "Request has been created.Request ids are:" + requestid.substring(1);
                String finalmsg = "Operation successful.";

               // IN BIO-PHARMA, NO REQUEST WILL BE GENERATED (SURAJIT 10-MAY-2017) ENDS

               // properties.setProperty("requestid", finalmsg);
            } else {
                properties.setProperty("requestid", "");
            }*/
            if (dsRepeat.size() > 0) {
                updateStatus();
            }
        }
    }

    /**
     * Description : This method will check department is valid or not.
     *
     * @param siteDept
     * @return
     * @throws SapphireException
     */
    private String deptValidate(String siteDept) throws SapphireException {
        String site = siteDept.substring(0, siteDept.indexOf("-"));
        String targetDept = siteDept.substring(siteDept.indexOf("-") + 1, siteDept.length());
        String department = "";
        String dept = "select departmentid from department where departmentid='" + siteDept + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor().translate(targetDept + " Department not found in site " + site);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
        }
        return department;
    }

    /**
     * Description : This method will check backup slides present or not.Depend on availability of backup slides it will go different department.
     *
     * @param sampleid
     * @param dept
     * @return
     * @throws SapphireException
     */
    private String checkBackUpSlides(String sampleid, String dept) throws SapphireException {
        String depart = "";
        String sql = "select s_sampleid from s_sample where s_sampleid in(select s_samplemap.DESTSAMPLEID from s_samplemap " +
                "where s_samplemap.SOURCESAMPLEID in (SELECT s_samplemap.SOURCESAMPLEID FROM s_samplemap   " +
                "where s_samplemap.destsampleid ='" + sampleid + "')) and  " +
                " s_sample.POOLEDFLAG is null and u_type='B'";
        try {
            DataSet dsBackup = getQueryProcessor().getSqlDataSet(sql);
            if (dsBackup == null) {
                throw new SapphireException("Something wrong happened. Contact your Administrator");
            }
            if (dsBackup.size() > 0) {
                String siteDept = dept + "-Histology";
                String validateDept = deptValidate(siteDept);
                depart = validateDept;
            } else {
                String siteDept = dept + "-BlockRoom";
                String validateDept = deptValidate(siteDept);
                depart = validateDept;
            }
        } catch (Exception e) {
            String error = getTranslationProcessor().translate("Error Failed to process request no sample found or data mismatch.");
            error += e.getMessage();
            logger.debug("Error. sql is " + error + "sql" + sql);
        }
        return depart;
    }

    /**
     * Description : This method will search sample information.
     *
     * @param sample
     * @return
     * @throws SapphireException
     */
    private DataSet getChoice(String sample) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sample, ";", "','");
        String sqlChoice = "select s_sampleid,u_choice,u_accessionid,u_clientspecimenid from s_sample where (storagestatus != 'Disposed' or samplestatus != 'Disposed' ) and s_Sampleid in ('" + sampleid + "' )";
        DataSet dsChoice = getQueryProcessor().getSqlDataSet(sqlChoice);
        if (dsChoice == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlChoice;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsChoice.size() == 0) {
            String errStr = getTranslationProcessor().translate("Sample not found in LV database.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        return dsChoice;
    }

    /**
     * Description : This method is used for dispose the selected samples.
     *
     * @throws SapphireException
     */
    private void updateStatus() throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsRepeat.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("storagestatus", "Disposed");
            props.setProperty("u_currentmovementstep", "Disposed");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update request in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    private void poputaleQCuserDTS(String samples) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, samples);
        prop.setProperty("u_ihcqcuser", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
        prop.setProperty("u_ihcqcdts", "n");
        getActionProcessor().processAction("EditSDI", "1", prop);
    }

    private DataSet dsRepeat = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "sampleid";
    private static final String DATASET_PROPERTY_CHOICE = "choice";


    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsRepeat == null) {
            dsRepeat = new DataSet();
            dsRepeat.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsRepeat.addColumn(DATASET_PROPERTY_CHOICE, DataSet.STRING);
        }
    }
}
