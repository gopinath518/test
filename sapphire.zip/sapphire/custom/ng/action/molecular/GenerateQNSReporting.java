package sapphire.custom.ng.action.molecular;

import com.labvantage.sapphire.actions.report.GenerateReport;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.NGSendMail;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class GenerateQNSReporting extends BaseAction {

    String fileloc = "";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("keyid1");
        String comment = properties.getProperty("comment");
        String tests = properties.getProperty("tests");
        String results = properties.getProperty("results");
        String prvreportflag = properties.getProperty("prvreportflag", "Y");
        String signedby = properties.getProperty("signedby");
        String attahmenttype = properties.getProperty("attahmenttype");
        //String batchid = properties.getProperty("batchid");
        if (Util.isNull(sampleids))
            throw new SapphireException("Specimen can't be blank.");

        tests = StringUtil.replaceAll(tests, ";", "','");
        DataSet dsQNS = getQNS(sampleids);
        if (dsQNS.size() > 0) {
            DataSet dsError = new DataSet();
            dsError.addColumn("specimen_id", DataSet.STRING);
            dsError.addColumn("qns", DataSet.STRING);
            for (int i = 0; i < dsQNS.size(); i++) {
                String qns = dsQNS.getValue(i, "u_qns", "");
                if (!"Y".equalsIgnoreCase(qns)) {
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "specimen_id", dsQNS.getValue(i, "s_sampleid", ""));
                    dsError.setValue(rowID, "qns", "Not checked");
                }
            }
            if (dsError.size() > 0) {
                String error = Util.getDisplayMessage("You must have QNS checked.", dsError);
                throw new SapphireException(error);
            }
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("u_qns", "Y");
            DataSet dsQNSFilter = dsQNS.getFilteredDataSet(hm);
            if (dsQNSFilter.size() > 0) {
                sampleids = dsQNSFilter.getColumnValues("s_sampleid", ";");
                //moveSpecimenToQNSReporting(dsQNSFilter);//TODO ONLY GENERATE THE REPORT
                String sql = Util.parseMessage(MolecularSql.GET_HNE_BATCH_DETAILS, StringUtil.replaceAll(sampleids, ";", "','"));
                DataSet dsBatch = getQueryProcessor().getSqlDataSet(sql);
                String batchid = dsBatch.getValue(0, "u_hnebatchdetailid", "");
                DataSet dsInput = valudateClientSLides(sampleids);
                initializeDataSet();
                hm.clear();
                hm.put("isclientslide", "N");
                DataSet dsCutSlide = dsInput.getFilteredDataSet(hm);
                if (dsCutSlide.size() > 0) {
                    sql = Util.parseMessage(MolecularSql.GET_CUTTING_SLDIE_BY_SAMPLE_TEST,
                            StringUtil.replaceAll(dsCutSlide.getColumnValues("sampleid", ";"), ";", "','"), tests);
                    DataSet dsTests = getQueryProcessor().getSqlDataSet(sql);
                    dsTests.sort("u_rootsample");
                    ArrayList groupByChildArray = dsTests.getGroupedDataSets("u_rootsample");
                    for (int i = 0; i < groupByChildArray.size(); i++) {
                        DataSet dsEach = (DataSet) groupByChildArray.get(i); // This can be
                        markedUSSAsQNS(dsEach);
                        int rowID = dsFinal.addRow();
                        dsFinal.setValue(rowID, "hnesample", dsEach.getValue(0, "hnesample", ""));
                        dsFinal.setValue(rowID, "sampleid", dsEach.getValue(0, "s_sampleid", ""));
                        dsFinal.setValue(rowID, "parmlistid", dsEach.getValue(0, "testname", ""));
                        dsFinal.setValue(rowID, "testcodeid", dsEach.getValue(0, "lvtestcodeid", ""));
                        dsFinal.setValue(rowID, "testname", dsEach.getValue(0, "testcodedesc", ""));
                    }
                }
                hm.clear();
                hm.put("isclientslide", "Y");
                DataSet dsClientSlide = dsInput.getFilteredDataSet(hm);
                if (dsClientSlide.size() > 0) {
                    sql = Util.parseMessage(MolecularSql.GET_CLIENT_SLIDES_BY_SAMPL_TEST,
                            StringUtil.replaceAll(dsClientSlide.getColumnValues("sampleid", ";"), ";", "','"), tests);
                    DataSet dsTests = getQueryProcessor().getSqlDataSet(sql);
                    dsTests.sort("u_clientspecimenid");
                    ArrayList groupByChildArray = dsTests.getGroupedDataSets("u_clientspecimenid");
                    for (int i = 0; i < groupByChildArray.size(); i++) {
                        DataSet dsEach = (DataSet) groupByChildArray.get(i); // This can be
                        markedUSSAsQNS(dsEach);
                        int rowID = dsFinal.addRow();
                        dsFinal.setValue(rowID, "hnesample", dsEach.getValue(0, "hnesample", ""));
                        dsFinal.setValue(rowID, "sampleid", dsEach.getValue(0, "s_sampleid", ""));
                        dsFinal.setValue(rowID, "parmlistid", dsEach.getValue(0, "testname", ""));
                        dsFinal.setValue(rowID, "testcodeid", dsEach.getValue(0, "lvtestcodeid", ""));
                        dsFinal.setValue(rowID, "testname", dsEach.getValue(0, "testcodedesc", ""));
                    }
                }
                if (dsFinal.size() > 0) {
                    applyDataEntry(comment, results);
                    if ("N".equalsIgnoreCase(prvreportflag)) {
                        batchid = properties.getProperty("batchid");
                    }
                    updateReportTypeDetails(properties);
                    fileloc = generatereport(properties, dsFinal, batchid, prvreportflag, signedby, comment, tests, results, attahmenttype);
                    if ("N".equalsIgnoreCase(prvreportflag)) {
                        markedAsReportSample();
                        //updateReportTypeDetails(properties);
                    }
                }
            }
            if ("Y".equalsIgnoreCase(prvreportflag)) {
                properties.setProperty("prvreportflag", prvreportflag);
            }
            if ("N".equalsIgnoreCase(prvreportflag)) {
                DataSet dsAttachmnt = dsFinalReportData();
                properties.setProperty("sdcid", dsAttachmnt.getValue(0, "sdcid", ""));
                properties.setProperty("keyid1", dsAttachmnt.getValue(0, "keyid1", ""));
                properties.setProperty("keyid2", dsAttachmnt.getValue(0, "keyid2", ""));
                properties.setProperty("keyid3", dsAttachmnt.getValue(0, "keyid3", ""));
                properties.setProperty("attachmentnum", dsAttachmnt.getValue(0, "attachmentnum", ""));
            }
        }
        //throw new SapphireException("test");
    }

    /**
     * Description : This method will search QNS information.
     *
     * @param sample
     * @return
     * @throws SapphireException
     */
    private DataSet getQNS(String sample) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sample, ";", "','");
        String sqlQNS = Util.parseMessage(MolecularSql.GET_QNS_SAMPLE, sampleid);
        DataSet dsQNS = getQueryProcessor().getSqlDataSet(sqlQNS);
        if (dsQNS == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlQNS;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsQNS.size() == 0) {
            String errStr = getTranslationProcessor().translate("Specimen(s) are not found in LV database.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        return dsQNS;
    }

    private void moveSpecimenToQNSReporting(DataSet dsInput) throws SapphireException {
        String department = connectionInfo.getDefaultDepartment();
        String dept = department.substring(0, department.indexOf("-"));
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsInput.getColumnValues("s_sampleid", ";"));
        props.setProperty("custodialdepartmentid", dept + "-Molecular");
        props.setProperty("custodialuserid", "(null)");
        props.setProperty("u_currenttramstop", "QNSReporting");
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update department." + ex.getMessage());
        }
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, dsInput.getColumnValues("s_sampleid", ";"));
        props.setProperty("u_currentmovementstep", "QNSReporting");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update department." + ex.getMessage());
        }
    }

    public String generatereport(PropertyList properties, DataSet dsFinal, String batchid, String prvreportflag, String signedby, String comments,
                                 String tests, String results, String attahmenttype) throws SapphireException {
        String filename = "", hnesample = "", unstainedslide = "";
        hnesample = dsFinal.getColumnValues("hnesample", ";");
        unstainedslide = dsFinal.getColumnValues("sampleid", ";");
        if (!Util.isNull(hnesample) && !Util.isNull(batchid)) {
            String[] sampArr = StringUtil.split(hnesample, ";");
            String[] USSSampArr = StringUtil.split(unstainedslide, ";");

            /**
             * For business logic GenerateReport action is used in loop. In a batch there are more than one sample so
             * report need to be generated per sample.
             */

            for (int i = 0; i < sampArr.length; i++) {
                String location = getFileLocation(sampArr[i]);
                String sql = Util.parseMessage(MolecularSql.GET_SAMPLEINFO_BY_SAMPLEID, sampArr[i]);
                DataSet ds = getQueryProcessor().getSqlDataSet(sql);
                String tc_sql = Util.parseMessage(MolecularSql.GET_TC_BY_SAMPLEID, sampArr[i]);
                DataSet dsTest = getQueryProcessor().getSqlDataSet(tc_sql);

                String tp_sql = Util.parseMessage(MolecularSql.GET_TP_BY_SAMPLEID, sampArr[i]);
                DataSet dsPanel = getQueryProcessor().getSqlDataSet(tp_sql);


                if (ds == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
                }
                if (ds.size() == 0) {
                    String error = getTranslationProcessor().translate("Parent Sample of " + sampArr[i] + " doesn't have Client Specimen ID !" + sql);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
                if (dsTest == null && dsPanel == null) {
                    String err = "Something wrong happened. Contact your administrator.\n Sql failed:";
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
                }
                if (dsTest.size() == 0 && dsPanel.size() == 0) {
                    String error = getTranslationProcessor().translate("SpecimenID " + sampArr[i] + " doesn't have any Test !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }
                /*String rootsampleid = ds.getValue(0, "s_sampleid", "");
                if (Util.isNull(rootsampleid)) {
                    String error = getTranslationProcessor().translate("Parent Sample not found of sample " + sampArr[i]);
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }*/
                String clientspecimenid = ds.getValue(0, "u_clientspecimenid", "");
                if (Util.isNull(clientspecimenid)) {
                    String error = getTranslationProcessor().translate("Parent Sample of " + sampArr[i] + " doesn't have Client Specimen ID !");
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
                }

                if (dsTest.size() > 0) {
                    filename = location + File.separator + clientspecimenid + "MolecularQNSReport" + new Date().getTime() + ".pdf";
                } else if (dsPanel.size() > 0) {
                    filename = location + File.separator + clientspecimenid + "MolecularQNSReport" + new Date().getTime() + ".pdf";
                }
                if (Util.isNull(batchid)) {
                    throw new SapphireException("Specimen " + sampArr[i] + " is not associated with any batch");
                }

                if ("N".equalsIgnoreCase(prvreportflag)) {
                    PropertyList prop = new PropertyList();
                    prop.clear();
                    prop.setProperty("reportid", "MolGenNonPanelSubRep");
                    prop.setProperty("reportversionid", "1");
                    prop.setProperty("s_sampleid", USSSampArr[i]);
                    prop.setProperty("batchid", batchid);
                    prop.setProperty("destination", "file");
                    prop.setProperty("debuglog", "Y");
                    prop.setProperty("filename", filename);
                    prop.setProperty("filetype", "PDF");

                    try {
                        getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);//TODO OPEN AS REPORT WILL GENERATE FOR MSI
                        sendEmailNotificationForBioPharma(sampArr[i], batchid, USSSampArr[i], filename);
                    } catch (SapphireException e) {
                        String errMSG = getTranslationProcessor().translate("Action failed. Molecular Report not created for " + sampArr[i] + "Sample ID" + e.getMessage());
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                    }
                    addAttachmentAfterSignOutGenReport(sampArr[i], USSSampArr[i], batchid, filename, attahmenttype);
                } else if ("Y".equalsIgnoreCase(prvreportflag)) {
                    attachPreviewReport(properties, USSSampArr[i], batchid, filename, comments, tests, results);
                }
            }
        }
        return filename;
    }

    private String getFileLocation(String sampleid) throws SapphireException {
        String fileLocation = "";
        String sql = Util.parseMessage(MolecularSql.GET_ACCESSION_INFO_BY_SAMPLE, sampleid);
        DataSet dsAccessionIfo = getQueryProcessor().getSqlDataSet(sql);
        String sponsornumber = "", projectprotocolid = "";
        if (dsAccessionIfo.size() > 0) {
            sponsornumber = dsAccessionIfo.getValue(0, "sponsornumber");
            projectprotocolid = dsAccessionIfo.getValue(0, "projectprotocolid");
        }
        sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        //fileLocation = Util.generateMolLocPath(baseloc, "Molecular", "Reports");
        //baseloc = "C:\\Temp";
        fileLocation = Util.generateMolReportLocPath(baseloc, sponsornumber, projectprotocolid, "Molecular", "QNSReport");
        logger.info("GemerateQNSReporting>>Report Path>>>", fileLocation);

        return fileLocation;
    }

    private DataSet valudateClientSLides(String sampleids) throws SapphireException {
        DataSet dsInput = new DataSet();
        dsInput.addColumn("sampleid", DataSet.STRING);
        dsInput.addColumn("isclientslide", DataSet.STRING);
        String sql = Util.parseMessage(MolecularSql.GET_CLIENT_SPECID, StringUtil.replaceAll(sampleids, ";", "','"));
        DataSet dsChkSLides = getQueryProcessor().getSqlDataSet(sql);
        if (dsChkSLides.size() > 0) {
            for (int i = 0; i < dsChkSLides.size(); i++) {
                String sampleid = dsChkSLides.getValue(i, "s_sampleid", "");
                String u_type = dsChkSLides.getValue(i, "u_type", "");
                int rowID = dsInput.addRow();
                if ("CH".equalsIgnoreCase(u_type) || "CU".equalsIgnoreCase(u_type)) {
                    dsInput.setValue(rowID, "sampleid", sampleid);
                    dsInput.setValue(rowID, "isclientslide", "Y");
                } else {
                    dsInput.setValue(rowID, "sampleid", sampleid);
                    dsInput.setValue(rowID, "isclientslide", "N");
                }
            }
        }
        return dsInput;
    }

    private DataSet dsFinal = null;

    private void initializeDataSet() throws SapphireException {
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn("hnesample", DataSet.STRING);
            dsFinal.addColumn("sampleid", DataSet.STRING);
            dsFinal.addColumn("parmlistid", DataSet.STRING);
            dsFinal.addColumn("testcodeid", DataSet.STRING);
            dsFinal.addColumn("testname", DataSet.STRING);
        }
    }

    private void applyDataEntry(String comments, String results) throws SapphireException {
        String sampleids = dsFinal.getColumnValues("sampleid", ";");
        String parmlistid = dsFinal.getColumnValues("parmlistid", ";");
        String sql = Util.parseMessage(MolecularSql.GET_SDI_DATA_ITEM, StringUtil.replaceAll(sampleids, ";", "','"),
                StringUtil.replaceAll(parmlistid, ";", "','"));
        DataSet dsSDIDataItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsSDIDataItem.size() > 0) {
            for (int i = 0; i < dsSDIDataItem.size(); i++) {
                String paramid = dsSDIDataItem.getValue(i, "paramid", "");
                String enteredtext = dsSDIDataItem.getValue(i, "enteredtext", "");
                if ("ManualRESULT".equalsIgnoreCase(paramid) || "RESULT".equalsIgnoreCase(paramid)) {
                    dsSDIDataItem.setValue(i, "enteredtext", results);
                    dsSDIDataItem.setValue(i, "displayvalue", results);
                } else if ("COMMENTS".equalsIgnoreCase(paramid)/* || "COMMENTS".equalsIgnoreCase(paramid)*/) {
                    dsSDIDataItem.setValue(i, "enteredtext", comments);
                    dsSDIDataItem.setValue(i, "displayvalue", comments);
                } else if ("Initial or Repeat".equalsIgnoreCase(paramid) && Util.isNull(enteredtext)) {
                    dsSDIDataItem.setValue(i, "enteredtext", "Initial");
                    dsSDIDataItem.setValue(i, "displayvalue", "Initial");
                }
            }
            PropertyList props = new PropertyList();
            props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSDIDataItem.getColumnValues("keyid1", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSDIDataItem.getColumnValues("paramlistid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSDIDataItem.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSDIDataItem.getColumnValues("paramid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSDIDataItem.getColumnValues("variantid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSDIDataItem.getColumnValues("paramtype", ";"));
            props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSDIDataItem.getColumnValues("replicateid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSDIDataItem.getColumnValues("dataset", ";"));
            props.setProperty("enteredtext", dsSDIDataItem.getColumnValues("enteredtext", ";"));
            props.setProperty("displayvalue", dsSDIDataItem.getColumnValues("displayvalue", ";"));

            try {
                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException("EnterDataItem not performed." + e.getMessage());
            }
        }
    }

    private void addAttachmentAfterSignOutGenReport(String hnesample, String usslide, String batchid, String filename, String attahmenttype) throws SapphireException {
        /*String sqlCorrectionValue = Util.parseMessage(MolecularSql.GET_CORRECTION_VAL, StringUtil.replaceAll(hnesample, ";", "','"));
        DataSet dsCorrectionValue = getQueryProcessor().getSqlDataSet(sqlCorrectionValue);
        if (dsCorrectionValue == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sqlCorrectionValue;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);

        }

        HashMap hm = new HashMap();
        hm.clear();
        hm.put("s_sampleid", hnesample);
        DataSet dsFilterValue = dsCorrectionValue.getFilteredDataSet(hm);*/
        //TODO NOT NECESSARY TO ATTACH FOR BATCH
        /*PropertyList propSamp = new PropertyList();
        propSamp.clear();
        propSamp.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
        propSamp.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
        propSamp.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        propSamp.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
        propSamp.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
        propSamp.setProperty("ATTACHMENTCLASS", "SOP");

        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, propSamp);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Molecular Report not created for " + hnesample + "Sample ID" + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }*/
        //Bellow code added for created report will also attach to the root sample.
        PropertyList propRoot = new PropertyList();
        propRoot.clear();
        propRoot.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Sample");
        propRoot.setProperty(AddSDIAttachment.PROPERTY_KEYID1, hnesample);
        propRoot.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        propRoot.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
        propRoot.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
        propRoot.setProperty("ATTACHMENTCLASS", "SOP");
        propRoot.setProperty("U_ATTACHMENTTYPE", attahmenttype);
        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, propRoot);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate(" Molecular Report not created for H&E sampleid:" + hnesample + "Error:" + e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
        /*String sqlUpdate = Util.parseMessage(MolecularSql.GET_ATTACHMNT_DETAILS, dsFilterValue.getValue(0, "u_correctionvalue", "Normal"),
                hnesample, usslide);
        database.executeUpdate(sqlUpdate);
        try {
            //copyFileSFTPPath(filename, sampArr[i]);
        } catch (Exception e) {
            e.getMessage();
        }*/
    }

    private void markedUSSAsQNS(DataSet dsInput) throws SapphireException {
        if (dsInput.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsInput.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_qns", StringUtil.repeat("Y", dsInput.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to mark as QNS for USS." + ex.getMessage());
            }
        }
    }

    private void attachPreviewReport(PropertyList properties, String usslide, String batchid, String filename, String cmments, String tests, String results)
            throws SapphireException {
        properties.setProperty("reportid", "MolGenNonPanelSubRep");
        properties.setProperty("reportversionid", "1");
        properties.setProperty("s_sampleid", usslide);
        properties.setProperty("batchid", batchid);
        properties.setProperty("destination", "file");
        properties.setProperty("debuglog", "Y");
        properties.setProperty("filename", filename);
        properties.setProperty("cmments", cmments);
        properties.setProperty("tests", tests);
        properties.setProperty("chsresult", results);

        /*fileloc = "rc?command=ViewReport&reportid=MolGenNonPanelSubRep&reportversionid=1&s_sampleid=" + usslide + "&batchid=" + batchid +
                "&destination=file&debuglog=Y&filename=" + filename + "&filetype=PDF&mode=submitarg&displaytype=pdf&previewflag=Y";*/
    }

    private void markedAsReportSample() throws SapphireException {
        if (dsFinal.size() > 0) {
            String conncusername = connectionInfo.getSysuserId();
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("hnesample", ";"));
            props.setProperty("u_reportflag", StringUtil.repeat("Y", dsFinal.size(), ";"));
            props.setProperty("u_reportingdts", StringUtil.repeat("n", dsFinal.size(), ";"));
            props.setProperty("u_reportingusername", StringUtil.repeat(conncusername, dsFinal.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to mark reporting flag." + ex.getMessage());
            }
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
            props.setProperty("u_reportflag", StringUtil.repeat("Y", dsFinal.size(), ";"));
            props.setProperty("u_reportingdts", StringUtil.repeat("n", dsFinal.size(), ";"));
            props.setProperty("u_reportingusername", StringUtil.repeat(conncusername, dsFinal.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to mark reporting flag." + ex.getMessage());
            }
        }
    }

    private DataSet dsFinalReportData() throws SapphireException {
        DataSet dsFinalReport = null;
        if (dsFinal.size() > 0) {
            String hnesampleid = dsFinal.getColumnValues("hnesample", ";");
            String sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_TYPE_HNE, StringUtil.replaceAll(hnesampleid, ";", "','"));
            dsFinalReport = getQueryProcessor().getSqlDataSet(sql);

        }
        return dsFinalReport;
    }

    private void updateReportTypeDetails(PropertyList properties) throws SapphireException {
        if (dsFinal.size() > 0) {
            String attahmenttype = properties.getProperty("attahmenttype");
            String attachmentcomment = properties.getProperty("attachmentcomment");
            if (Util.isNull(attahmenttype))
                return;
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("hnesample", ";"));
            props.setProperty("u_correctionvalue", StringUtil.repeat(attahmenttype, dsFinal.size(), ";"));
            props.setProperty("u_correctioncomments", StringUtil.repeat(attachmentcomment, dsFinal.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to mark report type." + ex.getMessage());
            }
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
            props.setProperty("u_correctionvalue", StringUtil.repeat(attahmenttype, dsFinal.size(), ";"));
            props.setProperty("u_correctioncomments", StringUtil.repeat(attachmentcomment, dsFinal.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to mark report type." + ex.getMessage());
            }
        }
    }

    private void sendEmailNotificationForBioPharma(String hnesampleid, String batchid, String usssampleid, String filename) throws SapphireException {
        if (!Util.isNull(hnesampleid)) {
            String sql = Util.parseMessage(CommonSql.GET_INFO_FROM_SITE_LABEL_BY_SAMPLEID, StringUtil.replaceAll(hnesampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);

            sql = Util.parseMessage(CommonSql.GET_INFO_FROM_PROJECT_LABEL_BY_SAMPLEID, StringUtil.replaceAll(hnesampleid, ";", "','"));
            DataSet dsProject = getQueryProcessor().getSqlDataSet(sql);
            ds.copyRow(dsProject, -1, 1);

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                DataSet tempDsFiltr = null;
                DataSet tempDsFiltrProjectLevel = null;
                String nodeId = "";
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            //TODO RESULT NOTIFICATION
                            hmap.put("type", "Email");
                            hmap.put("event", "Result Notification");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Result Notification");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ResultNotification";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, hnesampleid, nodeId, "SendMail", "");

                            //TODO REPORT DISTRIBUTION
                            hmap.clear();
                            hmap.put("type", "Email");
                            hmap.put("event", "Report Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            hmap.clear();
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Report Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ReportDistribution";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, hnesampleid, nodeId, "AttachReport", filename);

                            //TODO FAX DISTRIBUTION
                            hmap.clear();
                            hmap.put("type", "Fax");
                            hmap.put("event", "Fax Distribution");
                            tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            hmap.clear();
                            hmap.put("projtype", "Fax");
                            hmap.put("projevent", "Fax Distribution");
                            tempDsFiltrProjectLevel = tempDs.getFilteredDataSet(hmap);
                            nodeId = "";
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                nodeId = "ReportFax";
                            } else if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
                                nodeId = "ClinicalAccession";
                            }
                            sendNotification(tempDsFiltr, tempDsFiltrProjectLevel, batchid, hnesampleid, nodeId, "AttachReport", filename);
                        }
                    }
                }
            }
        }
    }

    private void sendNotification(DataSet tempDsFiltr, DataSet tempDsFiltrProjectLevel, String batchid, String rootsampleid,
                                  String nodeid, String mode, String filename) throws SapphireException {
        String toList = "";
        PropertyList prop = new PropertyList();
        prop.setProperty(NGSendMail.NODE_ID, nodeid);
        prop.setProperty(NGSendMail.MODE, mode);
        if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
            toList = tempDsFiltr.getColumnValues("email", ";");
            if (!Util.isNull(toList)) {
                toList = Util.getUniqueList(toList, ";", true);
                String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                if (!Util.isNull(invistigatoName))
                    invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(rootsampleid, ";", true));
                prop.setProperty(NGSendMail.BATCHID, Util.getUniqueList(batchid, ";", true));
                prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                if (!Util.isNull(filename))
                    prop.setProperty(NGSendMail.FILENAME, filename);
            }
        }
        if (tempDsFiltrProjectLevel != null && tempDsFiltrProjectLevel.size() > 0) {
            toList = tempDsFiltrProjectLevel.getColumnValues("email", ";") + ";" + toList;
            if (!Util.isNull(toList))
                toList = Util.getUniqueList(toList, ";", true);

            String sponcerName = tempDsFiltrProjectLevel.getColumnValues("sponsername", ";");
            if (!Util.isNull(sponcerName))
                sponcerName = Util.getUniqueList(sponcerName, ";", true);

            String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
            if (!Util.isNull(invistigatoName))
                invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

            prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(rootsampleid, ";", true));
            prop.setProperty(NGSendMail.BATCHID, Util.getUniqueList(batchid, ";", true));
            prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", ";"), ";", true));
            prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_accessionid", "','"), ";", true));
            prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
            prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("investigatorsiteid", ";"), ";", true));
            prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
            prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("projectprotocolid", ";"), ";", true));
            prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltrProjectLevel.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
            prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
            if (!Util.isNull(filename))
                prop.setProperty(NGSendMail.FILENAME, filename);
        }
        if (toList != null && !"".equals(toList)) {
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
            prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
            prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
            prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
        }
    }
}
