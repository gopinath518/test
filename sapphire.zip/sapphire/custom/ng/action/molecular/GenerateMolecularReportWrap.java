package sapphire.custom.ng.action.molecular;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class GenerateMolecularReportWrap extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String doctoname = properties.getProperty("u_doctorname", "");
        String reportingusername = properties.getProperty("u_reportingusername", "");
        String sampleid = properties.getProperty("s_sampleid", "");
        String ngbatchid = properties.getProperty("u_ngbatchid", "");
        String correctionvalue = properties.getProperty("u_correctionvalue", "");
        String correctioncomments = properties.getProperty("u_correctioncomments", "");
        if (Util.isNull(sampleid))
            throw new SapphireException("Specimen ID can't be blank.");
        if (Util.isNull(ngbatchid))
            throw new SapphireException("Batch ID can't be blank.");

        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        props.setProperty("u_reportingusername", reportingusername);
        props.setProperty("u_doctorname", doctoname);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Assigning doctor failed." + ex.getMessage());
        }
        if (!Util.isNull(correctionvalue))
            updateCorrectionValue(properties);
        props.clear();
        props.setProperty("u_ngbatchid", ngbatchid);
        props.setProperty("s_sampleid", sampleid);
        try {
            getActionProcessor().processAction("MolecularGenetics", "1", props);
        } catch (Exception ex) {
            throw new SapphireException("Report generation failed." + ex.getMessage());
        }
        properties.setProperty("msg", props.getProperty("msg"));
    }

    private void updateCorrectionValue(PropertyList props) throws SapphireException {
        String sampleid = props.getProperty("s_sampleid", "");
        String correctionvalue = props.getProperty("u_correctionvalue", "");
        String correctioncomments = props.getProperty("u_correctioncomments", "");
        if (!Util.isNull(correctionvalue)) {
            if (sampleid.startsWith(";"))
                sampleid = sampleid.substring(1);
            String sql = Util.parseMessage(MolecularSql.GET_MOL_REPORT_SAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            sampleid = dsSampleInfo.getColumnValues("s_sampleid", ";") + ";" + dsSampleInfo.getColumnValues("u_rootsample", ";");
            sampleid = Util.getUniqueList(sampleid, ";", true);
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            prop.setProperty("u_correctionvalue", correctionvalue);
            prop.setProperty("u_correctioncomments", correctioncomments);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update correction value." + ex.getMessage());
            }
        }
    }
}
