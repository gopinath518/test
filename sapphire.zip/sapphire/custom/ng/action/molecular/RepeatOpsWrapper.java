package sapphire.custom.ng.action.molecular;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.servlet.AjaxResponse;
import sapphire.xml.PropertyList;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RepeatOpsWrapper extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String mainData = properties.getProperty("inputvalue");
        if (Util.isNull(mainData)) {
            String error = getTranslationProcessor().translate("Please select something before press Save button.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        PropertyList props = new PropertyList();
        props.setProperty("inputvalue", mainData);
        try {
            getActionProcessor().processAction("PerformRepeatOps", "1", props);
        } catch (Exception ex) {
            throw new SapphireException("Repeat Ops failed." + ex.getMessage());
        }
        //showCreatedChildNRequest(props);//TODO INCIDENT REQUEST WILL NOT BE THERE
        String msg = props.getProperty("msg");
        String requestmsg = props.getProperty("request");
        if (!Util.isNull(requestmsg))
            msg += "\n" + requestmsg;
        properties.setProperty("msg", msg);
        //throw new SapphireException("test");
    }

    private void showCreatedChildNRequest(PropertyList pl) throws SapphireException {
        String childSample = pl.getProperty("childsample").replaceAll("[;]+", ",");
        Pattern pattern1 = Pattern.compile("[a-zA-Z0-9|-]+");
        Matcher matcher1 = pattern1.matcher(childSample);
        String regChildSampleid = "";
        while (matcher1.find()) {
            matcher1.start();
            regChildSampleid = regChildSampleid + matcher1.group() + ",";

        }
        if (regChildSampleid.length() > 0) {
            regChildSampleid = regChildSampleid.substring(0, regChildSampleid.lastIndexOf(','));
        }
        String requestid = pl.getProperty("request").replaceAll("[;]+", ",");
        Pattern pattern = Pattern.compile("[a-zA-Z0-9|-]+");
        Matcher matcher = pattern.matcher(requestid);
        String regRequestid = "";
        while (matcher.find()) {
            matcher.start();
            regRequestid = regRequestid + matcher.group() + ",";

        }
        if (regRequestid.length() > 0) {
            regRequestid = regRequestid.substring(0, regRequestid.lastIndexOf(','));
        }
        if ((!Util.isNull(regChildSampleid)) && (!Util.isNull(regRequestid))) {
            //ajaxResponse.addCallbackArgument("msg", "Request successfully submitted.Created new sample(s):"+regChildSampleid+" and submitted requestid(s):"+regRequestid);
            //ajaxResponse.addCallbackArgument("msg", "Operation Successful");
        } else if ((Util.isNull(regChildSampleid)) && (!Util.isNull(regRequestid))) {
            //ajaxResponse.addCallbackArgument("msg", "Request successfully submitted.Submitted requestid(s):"+regRequestid);
            //ajaxResponse.addCallbackArgument("msg", "Operation Successful");
        } else if ((!Util.isNull(regChildSampleid)) && (Util.isNull(regRequestid))) {
            //ajaxResponse.addCallbackArgument("msg", "Request successfully submitted.Created new sample(s):"+regChildSampleid);
            //ajaxResponse.addCallbackArgument("msg", "Operation Successful");
        }
    }
}
