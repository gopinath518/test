package sapphire.custom.ng.action.molecular;

import com.labvantage.sapphire.actions.sdi.EditSDI;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.CompletePreExtraction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

import static sapphire.custom.ng.util.Util.getUniqueList;

public class MolHNEReviewComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sdcid = properties.getProperty("sdcid");
        String sampleids = properties.getProperty("keyid1");
        String currentmovementstep = getUniqueList(properties.getProperty("u_currentmovementstep"), ";", true);
        String hnebatchreview = getUniqueList(properties.getProperty("u_hnebatchreview"), ";", true);
        String pathreviewedby = getUniqueList(properties.getProperty("u_pathreviewedby"), ";", true);
        String pathreviewdts = getUniqueList(properties.getProperty("u_pathreviewdts"), ";", true);
        String currenttramstop = getUniqueList(properties.getProperty("u_currenttramstop"), ";", true);
        String custodialuserid = getUniqueList(properties.getProperty("custodialuserid"), ";", true);
        String custodytakendt = getUniqueList(properties.getProperty("custodytakendt"), ";", true);
        String custodialdepartmentid = getUniqueList(properties.getProperty("custodialdepartmentid"), ";", true);

        if (Util.isNull(sampleids))
            throw new SapphireException("Specimen can't be blank.");

        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));
        String newCustodialdepartmentid = departmentSite + "-Accessioning";

        DataSet dsSql = dsHNESamples(sampleids);
        if (!dsSql.isValidColumn("u_currentmovementstep")) {
            dsSql.addColumn("u_currentmovementstep", DataSet.STRING);
        }
        if (!dsSql.isValidColumn("u_currenttramstop")) {
            dsSql.addColumn("u_currenttramstop", DataSet.STRING);
        }
        if (!dsSql.isValidColumn("custodialdept")) {
            dsSql.addColumn("custodialdept", DataSet.STRING);
        }
        if (!dsSql.isValidColumn("isqnsflag")) {
            dsSql.addColumn("isqnsflag", DataSet.STRING);
        }
        DataSet dsHNELot = new DataSet();
        dsHNELot.addColumn("specimen_id", DataSet.STRING);
        dsHNELot.addColumn("eosin_lot", DataSet.STRING);
        dsHNELot.addColumn("hematoxylin_lot", DataSet.STRING);
        dsHNELot.addColumn("eosin_exp_date", DataSet.STRING);
        dsHNELot.addColumn("hematoxylin_exp_date", DataSet.STRING);
        for (int i = 0; i < dsSql.size(); i++) {
            String meth = dsSql.getValue(i, "methodology", "");
            String u_qns = dsSql.getValue(i, "u_qns", "");
            if (meth.equalsIgnoreCase("Molecular")) {
                if ("Y".equalsIgnoreCase(u_qns)) {
                    dsSql.setValue(i, "u_currentmovementstep", "QNSReporting");
                    dsSql.setValue(i, "u_currenttramstop", "QNSReporting");
                    dsSql.setValue(i, "isqnsflag", "Y");
                    dsSql.setValue(i, "custodialdept", departmentSite + "-Pathology");
                } else {
                    dsSql.setValue(i, "u_currentmovementstep", currentmovementstep);
                    dsSql.setValue(i, "u_currenttramstop", currenttramstop);
                    dsSql.setValue(i, "custodialdept", newCustodialdepartmentid);
                    dsSql.setValue(i, "isqnsflag", "N");
                }
                //CHECK EOSIN LOT AND HEMATOXIN LOT
                String u_eosinlotid = dsSql.getValue(i, "u_eosinlotid", "");
                String u_hematoxylinlotid = dsSql.getValue(i, "u_hematoxylinlotid", "");
                String u_eosinexpdt = dsSql.getValue(i, "u_eosinexpdt", "");
                String u_hematoxylinexpdt = dsSql.getValue(i, "u_hematoxylinexpdt", "");
                if (Util.isNull(u_eosinlotid) || Util.isNull(u_hematoxylinlotid) || Util.isNull(u_eosinexpdt) || Util.isNull(u_hematoxylinexpdt)) {
                    int rowId = dsHNELot.addRow();
                    dsHNELot.setValue(rowId, "specimen_id", dsSql.getValue(i, "sampleid", ""));
                    dsHNELot.setValue(rowId, "eosin_lot", u_eosinlotid);
                    dsHNELot.setValue(rowId, "hematoxylin_lot", u_hematoxylinlotid);
                    dsHNELot.setValue(rowId, "eosin_exp_date", u_eosinexpdt);
                    dsHNELot.setValue(rowId, "hematoxylin_exp_date", u_hematoxylinexpdt);
                }
            }
        }
        if (dsHNELot != null && dsHNELot.size() > 0) {
            String err = Util.getDisplayMessage("Eosin and Hematoxylin lot information are required for below specimen(s).", dsHNELot);
            throw new SapphireException(err);
        }
        //ROUTE QNS SAMPLE TO THE QNS REPORTING
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("isqnsflag", "Y");
        DataSet dsQNSSamples = dsSql.getFilteredDataSet(hm);
        if (dsQNSSamples.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsQNSSamples.getColumnValues("sampleid", ";"));
            prop.setProperty("u_currentmovementstep", dsQNSSamples.getColumnValues("u_currentmovementstep", ";"));
            prop.setProperty("u_hnebatchreview", StringUtil.repeat(hnebatchreview, dsQNSSamples.size(), ";"));
            prop.setProperty("u_pathreviewedby", StringUtil.repeat(pathreviewedby, dsQNSSamples.size(), ";"));
            prop.setProperty("u_pathreviewdts", StringUtil.repeat(pathreviewdts, dsQNSSamples.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Error in edit sample" + ae.getMessage());
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            prop.clear();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsQNSSamples.getColumnValues("sampleid", ";"));
            prop.setProperty("u_currenttramstop", dsQNSSamples.getColumnValues("u_currenttramstop", ";"));
            prop.setProperty("custodialuserid", StringUtil.repeat("(null)", dsQNSSamples.size(), ";"));
            prop.setProperty("custodytakendt", StringUtil.repeat(custodytakendt, dsQNSSamples.size(), ";"));
            prop.setProperty("custodialdepartmentid", dsQNSSamples.getColumnValues("custodialdept", ";"));

            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Error in edit track item." + ae.getMessage());
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
        }
        hm.clear();
        hm.put("isqnsflag", "N");
        DataSet dsNonQNSSamples = dsSql.getFilteredDataSet(hm);
        if (dsNonQNSSamples.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty("keyid1", dsNonQNSSamples.getColumnValues("sampleid", ";"));
            try {
                getActionProcessor().processAction(CompletePreExtraction.ID, CompletePreExtraction.VERSIONID, prop);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Error occur to follow macrodissection rule." + ae.getMessage());
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
        }
        //throw new SapphireException("Test");
    }

    private DataSet dsHNESamples(String sampleids) throws SapphireException {
        DataSet dsHNESamples = null;
        String sql = Util.parseMessage(MolecularSql.GET_HNE_SAMPLE_FR_PATHOLOGY_REV, StringUtil.replaceAll(sampleids, ";", "','"));
        dsHNESamples = getQueryProcessor().getSqlDataSet(sql);
        return dsHNESamples;
    }

}
