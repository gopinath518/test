package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by mpandey on 3/28/2017.
 */
public class EditSamplePostFluroScan extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        DataSet dssample = getSampleDetails(batchid);
        if(dssample.size()>0)
        editSample(dssample);
    }

    private void editSample(DataSet dssample) {
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dssample.getColumnValues("s_sampleid", ";"));
        prop.setProperty("u_fusiondilutionfactor", dssample.getColumnValues("fusiondilutionfactor", ";"));
        prop.setProperty("u_fusiontrishcl", dssample.getColumnValues("fusiontrishcl", ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException e) {
            e.printStackTrace();
        }
    }

    private DataSet getSampleDetails(String batchid) {
        String sql = " select s.s_sampleid,nvl(ROUND(TO_CHAR((s.U_NGSFUSIONCONC*90.4)-2),1),'0') fusiontrishcl,nvl(ROUND(TO_CHAR(s.U_NGSFUSIONCONC*45.2),1),'0') fusiondilutionfactor " +
                " from u_ngbatch_sample ns,s_sample s where ns.sampleid=s.s_sampleid and u_ngbatchid='" + batchid + "'";
        DataSet dssample = getQueryProcessor().getSqlDataSet(sql);
        return dssample;
    }
}
