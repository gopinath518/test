package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import sapphire.action.AddSDI;
import sapphire.custom.ng.util.Util;

/**
 * Created by mpandey on 8/24/2016.
 */
public class CompleteNGSMLPADay1Batch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String sql="select batchtype,batchname,PARENTBATCHID from u_ngbatch where u_ngbatchid='"+batchid+"'";
        DataSet dsbatch = getQueryProcessor().getSqlDataSet(sql);

        String batchname=dsbatch.getColumnValues("batchname",";");
        String batchtype=dsbatch.getColumnValues("batchtype",";");
        String newbatchid = createBatch(batchname, batchtype,batchid);
        // updateDetail(newbatchid, sampleid, reagent);//todo now added from xls sheet
        copyOldBatchDetail(newbatchid,batchid,batchname);

    }
    private void copyOldBatchDetail(String newBatchid, String orgBatchID, String batchname) throws SapphireException {
        String sql = "select filename from sdiattachment where keyid1='" + orgBatchID + "'";
        DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
        if (dsAttachment != null && dsAttachment.size() > 0) {
            String filename = dsAttachment.getValue(0, "filename", "");
            if (!Util.isNull(filename)) {
                //load to plate and create new plate
                PropertyList plBatchPlate = new PropertyList();
                plBatchPlate.setProperty("batchid", newBatchid);
                plBatchPlate.setProperty("path", filename);
                plBatchPlate.setProperty("pageid", "NGMLPADay2Maint");
                plBatchPlate.setProperty("returntolistpage", "Day2NGMLPLABatchList");
                plBatchPlate.setProperty("associatereagent", "N");
                plBatchPlate.setProperty("copyfile", "Y");
                getActionProcessor().processAction("CreateMolecularBatch", "1", plBatchPlate);
            }
            else {
                throw new SapphireException("Plate Map is not found for the batch "+batchname+".");
            }
        }

    }

    private String createBatch(String batchname, String batchtype, String batchid) throws SapphireException {

        String ngbatchid;
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
//    pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        //pl.setProperty("batchtype", batchtype);
        pl.setProperty("batchname", batchname);
        pl.setProperty("parentbatchid", batchid);
        pl.setProperty("origin", "NGSMLPADay2");
        pl.setProperty("batchtype", "NGS");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }
}
