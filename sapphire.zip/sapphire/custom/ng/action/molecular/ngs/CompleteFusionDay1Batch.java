package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by mpandey on 10/25/2016.
 */
public class CompleteFusionDay1Batch extends BaseAction {
    String sampleLabel = "";

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = "";
        String plateid= "";
        String batchid = properties.getProperty("batchid");
        sampleid = getSampleid(batchid);
        plateid=getPlateid(batchid);
        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty("sampleid", sampleid);
        pl.setProperty("batchid", batchid);
        pl.setProperty("plateid",plateid);
        String day2batchid= addFusionDay2Batch(pl);
        completeDay1Batch(batchid);
        properties.setProperty("day2batchid",day2batchid);
    }

    private String getPlateid(String batchid){
        String sql = " select plateid from u_ngbatch_plate where u_ngbatchid='" + batchid + "'";
        DataSet dsbatch = getQueryProcessor().getSqlDataSet(sql);
        return dsbatch.getColumnValues("plateid", ";");
    }

    private void completeDay1Batch(String batchid) throws ActionException {



        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        props.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        props.setProperty("batchmovestatus", "FusionDay1Completed");
        props.setProperty("batchcompletedts", "n");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
    }

    /**
     * This method is use to get all samples associated with a batch.
     *
     * @param batchid
     * @return
     */
    private String getSampleid(String batchid) {
        String sql = " select sampleid,samplelabel from u_ngbatch_sample where u_ngbatchid='" + batchid + "'";
        DataSet dsbatch = getQueryProcessor().getSqlDataSet(sql);
        sampleLabel = dsbatch.getColumnValues("samplelabel", ";");
        return dsbatch.getColumnValues("sampleid", ";");
    }

    /**
     * This method is use to create and attach details with batch.
     *
     * @param properties
     * @throws SapphireException
     */
    public String addFusionDay2Batch(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("sampleid");
        String batchid = properties.getProperty("batchid");
        String plateid = properties.getProperty("plateid");
        String sql = "select batchtype,batchname,parentbatchid from u_ngbatch where u_ngbatchid='" + batchid + "'";
        DataSet dsbatch = getQueryProcessor().getSqlDataSet(sql);
        String batchname = dsbatch.getColumnValues("batchname", ";");
        String batchtype = dsbatch.getColumnValues("batchtype", ";");
        String newbatchid = createBatch(batchname, batchtype, batchid);
        updateDetail(newbatchid, sampleid,plateid);

        return newbatchid;
    }

    /**
     * This method is use to create a batch .
     *
     * @param batchname
     * @param batchtype
     * @param batchid
     * @return
     * @throws SapphireException
     */
    private String createBatch(String batchname, String batchtype, String batchid) throws SapphireException {

        String ngbatchid;
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype", batchtype);
        pl.setProperty("batchname", batchname);
        pl.setProperty("parentbatchid", batchid);
        pl.setProperty("origin", "NGSFusionDay2");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }

    /**
     * This method is use to attach details to a batch.
     *
     * @param batchid
     * @param sampleid
     * @param plateid
     * @throws SapphireException
     */
    private void updateDetail(String batchid, String sampleid, String plateid) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        pl.setProperty("sampleid", sampleid);
        pl.setProperty("samplelabel", sampleLabel);
        pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);


        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("There isn't any sample in batch.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        if(plateid.length()>0){

            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
            props.setProperty("plateid", plateid);
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");


            try {
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);


            } catch (SapphireException ex) {
                String error = getTranslationProcessor().translate("Action failed try again");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

            }

        }
        
    }

}

