package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;


/**
 * Created by mpandey on 4/3/2017.
 */
public class CreateNGSFusionDay1Batch extends BaseAction {
    private static final String COLS_TO_COPY = "u_extractionid;sampletypeid;u_clientspecimenid;u_sampleinformation;u_accessionid;u_tumorcircled;u_totaltumor;u_pathologycomments;u_extractioncomments";

    public void processAction(PropertyList properties) throws SapphireException {

        String sampleids = properties.getProperty("sampleid", "");
        String batchname = properties.getProperty("batchname", "");
        String startpos = properties.getProperty("startpos", "1");

        String dilutiontube = createDilution(sampleids);
        PropertyList pl = new PropertyList();
        pl.clear();
        pl.setProperty("sampleid", dilutiontube);
        pl.setProperty("batchname", batchname);
        pl.setProperty("startpos", startpos);
        String batchid = addFusionDay1Batch(pl);

        properties.setProperty("batchid",batchid);
    }

    private String addFusionDay1Batch(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String reagent = properties.getProperty("reagentid");
        String batchname = properties.getProperty("batchname");
        String startpos = properties.getProperty("startpos");
        String batchid = createBatch(batchname);
        String samplelbl = getSampleLbl(sampleid, startpos);
        updateDetail(batchid, sampleid, reagent, samplelbl.substring(1));
        return batchid;
    }

    private String createDilution(String elutiontubes) throws ActionException {
        String dilutiontubes = "";
        String copies = "1";
        if (!Util.isNull(elutiontubes)) {
            String sql = "select t.qtycurrent,t.containertypeid,t.custodialdepartmentid,t.qtyunits,s.* " +
                    "from s_sample s,trackitem t " +
                    "where t.linksdcid='Sample' and s.s_sampleid=t.linkkeyid1 and s.s_sampleid in('" + StringUtil.replaceAll(elutiontubes, ";", "','") + "')";
            DataSet dselutiontube = getQueryProcessor().getSqlDataSet(sql);
            if (dselutiontube != null && dselutiontube.size() > 0) {
                int dsSize = dselutiontube.size();
                copies = StringUtil.repeat(copies, dsSize, ";");
                String syncPrnt = StringUtil.repeat("N", dsSize, ";");
                String mode = StringUtil.repeat("Child", dsSize, ";");

                PropertyList pl = new PropertyList();
                pl.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, copies);
                pl.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, COLS_TO_COPY);
                pl.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, dselutiontube.getColumnValues("s_sampleid", ";"));
                pl.setProperty(MultiSampleChild.PROPERTY_MODE, mode);
                pl.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY, dselutiontube.getColumnValues("qtycurrent", ";"));
                pl.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT, dselutiontube.getColumnValues("qtyunits", ";"));
                pl.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, syncPrnt);
                pl.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
                try {
                    getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, pl);
                } catch (ActionException e) {
                    e.printStackTrace();
                }

                dilutiontubes = pl.getProperty(MultiSampleChild.RETURN_NEWKEYID1, "");
                String currentuser = connectionInfo.getSysuserId();
                String defaultdepartment = connectionInfo.getDefaultDepartment();

                pl.clear();
                pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditTrackItem.PROPERTY_KEYID1, dilutiontubes);
                pl.setProperty("containertypeid", "Dilution Tube");
                pl.setProperty("custodialdepartmentid", defaultdepartment);
                pl.setProperty("custodialuserid", currentuser);

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);

            }
        }
        try {
            Util.copyTestCodeFromParent(dilutiontubes, getQueryProcessor(), getActionProcessor());
        } catch (SapphireException e) {
            e.printStackTrace();
        }
        return dilutiontubes;
    }

    /**
     * This function is use to create ngs fusion batch.
     *
     * @param batchname
     * @return
     * @throws SapphireException
     */
    private String createBatch(String batchname) throws SapphireException {
        String ngbatchid;
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchname", batchname);
        pl.setProperty("origin", "NGSFusionDay1");
        pl.setProperty("batchtype", "NGS");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }

    /**
     * This method is use to update all detail tables associated  with batch.
     *
     * @param batchid
     * @param sampleid
     * @param reagent
     * @param samplelbl
     * @throws SapphireException
     */
    private void updateDetail(String batchid, String sampleid, String reagent, String samplelbl) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        pl.setProperty("sampleid", sampleid);
        pl.setProperty("samplelabel", samplelbl);
        pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        pl.clear();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("sampledesc", samplelbl);
        pl.setProperty("u_currentmovementstep", StringUtil.repeat("NGFusionBatch", sampleid.split(";").length, ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

    }

    /**
     * This method is use to create sample label based on starting position.
     *
     * @param sampleid
     * @param startpos
     * @return
     */
    private String getSampleLbl(String sampleid, String startpos) {
        String samplelbl = "";
        int pos = Integer.parseInt(startpos);
        for (String currsample : sampleid.split(";")) {

            samplelbl += ";" + "Sample" + pos;
            pos++;
        }
        return samplelbl;
    }
}
