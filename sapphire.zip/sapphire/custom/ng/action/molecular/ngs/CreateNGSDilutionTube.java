package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by mpandey on 6/11/2016.
 * pupose - create dilution tube out of ellution tube and assign test on it
 * mandatory input - parentsampleid
 */
public class CreateNGSDilutionTube extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String parentsample = properties.getProperty("parentsample");
        String ngstype = properties.getProperty("ngstype");
        String psampleque = StringUtil.replaceAll(parentsample, ";", "','");
        String copies = "1";
        String childvolume = "";
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();


        String sql = "select linkkeyid1,containertypeid,qtycurrent,qtyunits from trackitem where linksdcid='Sample' and linkkeyid1 in ('" + psampleque + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String containertype = "Dilution Tube";
        String parentvol = ds.getColumnValues("qtycurrent", ";");
        String parentunit = ds.getColumnValues("qtyunits", ";");
        String childsampleid = createDaughterTube(parentsample, copies, childvolume, parentunit, parentvol, containertype);

        // updateSample(childsampleid);
        updateTrackitem(childsampleid, currentuser, childvolume, parentunit, containertype, defaultdepartment);
      //  addTestCode(childsampleid, parentsample);
        Util.copyTestCodeFromParent(childsampleid, getQueryProcessor(), getActionProcessor());
        String tsmapid = getSampleTestcodeMapID(childsampleid);
        //  if (tsmapid.length() > 0)
        properties.setProperty("tsmapid", tsmapid);
        properties.setProperty("newkeyid1", childsampleid);


    }

    private String getSampleTestcodeMapID(String childsampleid) {
        String stmapid = "";
        String tc_sql = "select u_sampletestcodemapid from U_SAMPLETESTCODEMAP where S_SAMPLEID in('" + StringUtil.replaceAll(childsampleid, ";", "','") + "')";
        DataSet dssampletestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        if (dssampletestcode.size() > 0)
            stmapid = dssampletestcode.getColumnValues("u_sampletestcodemapid", ";");
        return stmapid;
    }

    private void addTestCode(String childsampleid, String parentsample) throws SapphireException {
        String queparent = StringUtil.replaceAll(parentsample, ";", "','");
        String quechild = StringUtil.replaceAll(childsampleid, ";", "','");
        //to do
       /* String tc_sql = "SELECT DISTINCT tc.ispanel," +
                "  tc.u_testcodeid," +
                "  tc.molecularsubmethodology," +
                "  tc.isneotypepanel," +
                "  sm.s_sampleid," +
                "  sm.lvtestpanelid" +
                " FROM u_testcode tc," +
                "  U_SAMPLETESTCODEMAP sm" +
                // " WHERE tc.u_testcodeid =sm.lvtestpanelid and " +
                " WHERE tc.u_testcodeid=sm.lvtestcodeid and " +
                "  sm.s_sampleid     in('" + queparent + "')";
        //" AND tc.ISNEOTYPEPANEL = 'Y' and tc.molecularsubmethodology='NGS'";*/
        String tc_sql = "select distinct lvtestpanelid,ispanel,s_sampleid from u_sampletestcodemap where s_sampleid in('" + queparent + "') and isneotypepanel='Y'";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);

        String[] samparr = StringUtil.split(childsampleid, ";");
        if (dstestcode == null) {
            String error = getTranslationProcessor().translate("Query Faild ");
            error += tc_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String sm_sql = "select SOURCESAMPLEID,DESTSAMPLEID from s_samplemap where DESTSAMPLEID in('" + quechild + "')";
        DataSet dssamplemap = getQueryProcessor().getSqlDataSet(sm_sql);
        if (dssamplemap == null) {
            String error = getTranslationProcessor().translate("Query Faild ");
            error += sm_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dstestcode.size() > 0) {
            DataSet dsSamplefinal = new DataSet();
            dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
            dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
            dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

            DataSet sampleFiltered = new DataSet();
            HashMap hmFilter = new HashMap();

            for (int i = 0; i < dssamplemap.size(); i++) {
                hmFilter.clear();
                sampleFiltered.clear();

                hmFilter.put("s_sampleid", dssamplemap.getValue(i, "SOURCESAMPLEID"));
                sampleFiltered = dstestcode.getFilteredDataSet(hmFilter);
                for (int j = 0; j < sampleFiltered.getRowCount(); j++) {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", dssamplemap.getValue(i, "DESTSAMPLEID"));
                    dsSamplefinal.setValue(rowID, "lvtestcode", sampleFiltered.getValue(j, "lvtestpanelid"));
                    dsSamplefinal.setValue(rowID, "ispanel", sampleFiltered.getValue(j, "ispanel", ""));

                }
            }


            PropertyList hsAddTestCode = new PropertyList();
            hsAddTestCode.clear();
            hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
            hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
            //  hsAddTestCode.setProperty("lvtestcode", "NAMLFR");
            // hsAddTestCode.setProperty("ispanel","Y");
            hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
            hsAddTestCode.setProperty("bypassvalidation", "Y");
            try {
                getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }

    private String createDaughterTube(String parentsample, String copies, String childvolume, String parentunit, String parentvol, String containertype) throws SapphireException {

        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentsample);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, copies);
        // prop.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY, childvolume);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY, "");
        // prop.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT, parentunit);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT, "");
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_QUANTITY, parentvol);
        //   prop.setProperty(MultiSampleChild.PROPERTY_CHILD_SAMPLETYPEID, parentvol);
        //  prop.setProperty(MultiSampleChild.PROPERTY_CHILD_CONTAINERTYPEID, containertype);
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        prop.setProperty("__trackitem_custodialdepartmentid", connectionInfo.getDefaultDepartment());
        //  prop.setProperty("__trackitem_custodialuserid", connectionInfo.getDefaultDepartment());
        //  prop.setProperty("__trackitem_containertypeid", containertype);
        //  prop.setProperty("__trackitem_containertypeid", connectionInfo.getDefaultDepartment());
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_extractionid;u_bodysite;u_markminimal;u_clientspecimenid;u_sampleinformation;u_accessionid;sstudyid;u_currentmovementstep");

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create child sample.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

    private void updateTrackitem(String childsampleid, String currentuser, String volume, String units, String containertype, String defaultdepartment) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", containertype);
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", defaultdepartment);
        props.setProperty("custodytakendt", "n");
        props.setProperty("qtycurrent", volume);
        props.setProperty("qtyunits", units);

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    private void updateSample(String childsampleid) throws SapphireException {
        PropertyList prop1 = new PropertyList();
        prop1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop1.setProperty(EditSDI.PROPERTY_KEYID1, childsampleid);
        prop1.setProperty("storagestatus", "In Circulation");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop1);

    }
}


