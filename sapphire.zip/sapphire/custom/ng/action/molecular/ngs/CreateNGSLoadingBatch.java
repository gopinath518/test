package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.ArrayList;

public class CreateNGSLoadingBatch extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String parentbatchmovestatus = properties.getProperty("parentbatchmovestatus");
        String childbatchmovestatus = properties.getProperty("childbatchmovestatus");
        String parentbatchstatusview = properties.getProperty("parentbatchstatusview");
        String childbatchstatusview = properties.getProperty("childbatchstatusview");
        String origin = properties.getProperty("origin");
        String batchtype = properties.getProperty("batchtype");
        if (Util.isNull(batchid)) {
            throw new SapphireException("Normalization Complete process cannot be performed.\nReason: Batchid is not found");
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(AddSDI.PROPERTY_TEMPLATEID, batchid);
        prop.setProperty("batchmovestatus", childbatchmovestatus);
        prop.setProperty("batchstatusview", childbatchstatusview);
        prop.setProperty("batchcompletedts", "n");
        prop.setProperty("origin", "Molecular");
        prop.setProperty("batchtype", "Molecular");
        prop.setProperty("parentbatchid", batchid);
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        String newBatch = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");

        if (!Util.isNull(newBatch)) {
            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
            prop.setProperty("batchmovestatus", parentbatchmovestatus);
            prop.setProperty("batchstatusview", parentbatchstatusview);
            //prop.setProperty("batchcompletedts", "n");
            prop.setProperty("origin", origin);
            prop.setProperty("batchtype", "Molecular");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            //deleteRegInfo(newBatch);

            /*String sql = "select filename from sdiattachment where keyid1='" + batchid + "'";
            DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
            if (dsAttachment != null && dsAttachment.size() > 0) {
                String filename = dsAttachment.getValue(0, "filename", "");
                if (!Util.isNull(filename)) {
                    prop.clear();
                    prop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                    prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newBatch);
                    prop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                    prop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                    prop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, prop);
                }
            }*/
        } else {
            throw new SapphireException("Child batch cannot be created.");
        }
        //throw new SapphireException("Test");
    }

    private void deleteRegInfo(String newBatch) throws SapphireException {
        if (!Util.isNull(newBatch)) {
            String sql = "select u_ngbatchid,analyte,reagentid,testcodeid,direction from u_ngbatcg_reagent_detail " +
                    "where u_ngbatchid in('" + StringUtil.replaceAll(newBatch, ";", "','") + "') ";
            DataSet dsRegInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsRegInfo != null && dsRegInfo.size() > 0) {
                dsRegInfo.sort("u_ngbatchid");
                ArrayList<DataSet> dsRegInfoArr = dsRegInfo.getGroupedDataSets("u_ngbatchid");
                if (dsRegInfoArr != null && dsRegInfoArr.size() > 0) {
                    PropertyList prop = new PropertyList();
                    for (int i = 0; i < dsRegInfoArr.size(); i++) {
                        DataSet tempDS = dsRegInfoArr.get(i);
                        if (tempDS != null && tempDS.size() > 0) {
                            String keyid1 = tempDS.getValue(0, "u_ngbatchid", "");
                            if (!Util.isNull(keyid1)) {
                                prop.clear();
                                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, keyid1);
                                prop.setProperty("analyte", tempDS.getColumnValues("analyte", ";"));
                                prop.setProperty("reagentid", tempDS.getColumnValues("reagentid", ";"));
                                prop.setProperty("testcodeid", tempDS.getColumnValues("testcodeid", ";"));
                                prop.setProperty("direction", tempDS.getColumnValues("direction", ";"));
                                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");

                                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
                            }
                        }
                    }
                }
            }
        }
    }

}