package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.xml.PropertyList;

public class RemoveRunBatchSample extends BaseAction {
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String sampleid = properties.getProperty("sampleid","");
		if("".equals(sampleid))
			throw new SapphireException("Sample Id not found");
		
		changeSampleCurrentMovement(sampleid);
		changeCurrentTramstop(sampleid);
	}
	
	
	public void changeSampleCurrentMovement(String sampleid) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
		pl.setProperty("u_currentmovementstep", "QuantCompleted");
		
		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	}
	public void changeCurrentTramstop(String sampleid) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
		pl.setProperty("u_currenttramstop", "RunDesign");
		
		getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	}
}
