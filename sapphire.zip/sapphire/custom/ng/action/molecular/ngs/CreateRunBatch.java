package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class CreateRunBatch extends BaseAction {

    static String newkeyid1;

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("sampleid", "");
        String batchName = properties.getProperty("batchname", "");

        if (batchName.contains("/")) {
            throw new SapphireException("Batch name does not support ' <b>/</b> ' operator as system can not recognize.");
        }

        Util.validateDuplicateBatchName(batchName, "RunDesign", getQueryProcessor());

        addNgBatchName(sampleid, batchName);
        addNgBatchSample(newkeyid1, sampleid);
        changeSampleCurrentMovement(sampleid);
        changeCurrentTramstop(sampleid);

        String setMsg = "<script>top.sapphire.lookup.util.openWindow( 'Run Design batch', 'Run Design Batch'," +
                "'rc?command=page&page=NanoRunBatchMaintPopUp&keyid1=" + newkeyid1 + "&mode=Edit', 1000, 500 )</script>BatchName: " + batchName + " created successful!";
        properties.setProperty("msg", setMsg);
    }

    public void addNgBatchName(String sampleid, String batchName) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype", "RunDesign");
        pl.setProperty("origin", "RunDesign");
        pl.setProperty("batchname", batchName);
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        newkeyid1 = pl.getProperty("newkeyid1");
    }

    public void addNgBatchSample(String newkeyid1, String sampleid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, newkeyid1);
        pl.setProperty("linkid", "u_ngbatch_sample_link");
        pl.setProperty("sampleid", sampleid);

        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
    }

    public void changeSampleCurrentMovement(String sampleid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currentmovementstep", "NanoRunBatch");

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    public void changeCurrentTramstop(String sampleid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currenttramstop", "RunDesignBatch");

        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
    }
}
