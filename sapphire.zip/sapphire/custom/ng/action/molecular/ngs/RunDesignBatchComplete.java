package sapphire.custom.ng.action.molecular.ngs;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.CopyNanoBatch;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class RunDesignBatchComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String batchId = properties.getProperty("batchid", "");
        if ("".equals(batchId))
            throw new SapphireException("Batch Id not found");

        copyBatchToHisto(batchId);
        String newBatchId = moveToNormalization(batchId);
        DataSet ds = getSampleid(newBatchId);
        if (ds != null && ds.size() > 0) {
            changeSampleCurrentMovement(ds.getColumnValues("sampleid", ";"));
            changeCurrentTramstop(ds.getColumnValues("sampleid", ";"));
        }
    }

    public void copyBatchToHisto(String batchId) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype", "HistoricalBatch");
        pl.setProperty("batchstatusview", "RunDesignBatchCompleted");
        pl.setProperty("batchcompletedts", "n");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, batchId);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    public DataSet getSampleid(String batchId) {
        String sql = Util.parseMessage(MolecularSql.GET_NGBATCH_SAMPLE, StringUtil.replaceAll(batchId, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        return ds;
    }

    public void changeSampleCurrentMovement(String sampleid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currentmovementstep", "Normalization");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update current step." + ex.getMessage());
        }
    }

    public void changeCurrentTramstop(String sampleid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currenttramstop", "Normalization");
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        } catch (Exception ex) {
            throw new SapphireException("Unable to update current step." + ex.getMessage());
        }
    }

    public String moveToNormalization(String batchId) throws SapphireException {
        String newKeyid1 = "";
        PropertyList editbatch = new PropertyList();
        editbatch.setProperty("parentbatchid", batchId);
        editbatch.setProperty("origin", "RunDesign");
        editbatch.setProperty("batchtype", "NanoNormalization");
        editbatch.setProperty("batchmovestatus", "RunDesignBatchComplete");
        try {
            getActionProcessor().processAction(CopyNanoBatch.ID, CopyNanoBatch.VERSIONID, editbatch);
            newKeyid1 = editbatch.getProperty("childbatchid", "");
        } catch (SapphireException se) {
            throw new SapphireException("Can not create duplicate Batch");
        }
        return newKeyid1;
    }
}
