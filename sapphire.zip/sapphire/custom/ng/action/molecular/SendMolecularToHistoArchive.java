/**
 *
 */
package sapphire.custom.ng.action.molecular;

import sapphire.action.EditTrackItem;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * @author sudeepta.pal
 * Modified by surajit.baitalik
 */
public class SendMolecularToHistoArchive extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        // TODO Auto-generated method stub
        String sampleId = properties.getProperty("sampleid", "");
        String currentmovementstep = properties.getProperty("u_currentmovementstep", "");//HistologyArchive
        String custodialdepartment = properties.getProperty("custodialdepartmentid", "");//Accessioning
        if (Util.isNull(sampleId)) {
            throw new SapphireException("Specimen(s) not found");
        }
        if ("Extraction".equalsIgnoreCase(currentmovementstep) || "Microdissection".equalsIgnoreCase(currentmovementstep) ||
                "Pre-Extraction".equalsIgnoreCase(currentmovementstep)) {
            custodialdepartment = "Molecular";
        }
        if ("PathSupport".equalsIgnoreCase(currentmovementstep) || "IHCSlideRecon".equalsIgnoreCase(currentmovementstep) ||
                "HistologyArchive".equalsIgnoreCase(currentmovementstep)) {
            custodialdepartment = "Accessioning";
        }
        if ("FISH LAB".equalsIgnoreCase(currentmovementstep)) {
            custodialdepartment = "FISH";
            String sql = Util.parseMessage(MolecularSql.GET_U_TYPE_METHOD, StringUtil.replaceAll(sampleId, ";", "','"));

            DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
            if (dsSql == null || dsSql.getRowCount() == 0) {
                throw new SapphireException("Not a valid Specimens.");
            }
            String movementstep = "";
            for (int i = 0; i < dsSql.size(); i++) {
                String type = dsSql.getValue(i, "u_type");
                String method = dsSql.getValue(i, "methodology");
                if ((("H".equalsIgnoreCase(type)) && ("Molecular".equalsIgnoreCase(method))) || (("CH".equalsIgnoreCase(type)) && ("Molecular".equalsIgnoreCase(method)))) {
                    movementstep = "FISHReceiveHNE";
                } else {
                    throw new SapphireException("Specimen doen't not belong to FISH LAB.");
                }
            }
            if (!"".equalsIgnoreCase(movementstep)) {
                currentmovementstep = movementstep;
            }
        }

        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleId);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLEINFO_BY_SAMPLEID_MANULA, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsSampleinfo = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("u_type", "B");
        DataSet dsBackUpFilter = dsSampleinfo.getFilteredDataSet(hm);
        if ("HistologyArchieve".equalsIgnoreCase(currentmovementstep) || "HistologyArchive".equalsIgnoreCase(currentmovementstep)) {
            if (dsBackUpFilter.size() == 0) {
                throw new SapphireException("Only backup slide(s) is/are allow to route Histology Archive tramstop.");
            }
        }
        hm.clear();
        hm.put("specimentype", "Extraction Tube");
        DataSet dsExtrctnFilter = dsSampleinfo.getFilteredDataSet(hm);
        if (dsExtrctnFilter.size() > 0) {
            throw new SapphireException("Only H&E and USS slide(s) are allowed to move.");
        }
        hm.clear();
        hm.put("specimentype", "Ellution Tube");
        DataSet dsEluFilter = dsSampleinfo.getFilteredDataSet(hm);
        if (dsEluFilter.size() > 0) {
            throw new SapphireException("Only H&E and USS slide(s) are allowed to move.");
        }
        String department = connectionInfo.getDefaultDepartment();
        if (!Util.isNull(department)) {
            String[] siteDept = StringUtil.split(department, "-");
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
            pl.setProperty("u_currentmovementstep", currentmovementstep);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update movement step for the specimen(s)." + ex.getMessage());
            }
            pl.clear();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
            pl.setProperty("custodialdepartmentid", siteDept[0] + "-" + custodialdepartment);
            pl.setProperty("custodialuserid", "(null)");
            pl.setProperty("u_currenttramstop", currentmovementstep);
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update department for the specimen(s)." + ex.getMessage());
            }

            sampleId = StringUtil.replaceAll(sampleId, ";", ", ");
            if ("Pre-Extraction".equalsIgnoreCase(currentmovementstep))
                properties.setProperty("msg", sampleId + " has been routed to Molecular COC tramstop.");
            else
                properties.setProperty("msg", sampleId + " has been routed to " + currentmovementstep + " tramstop.");
        }
    }
}
