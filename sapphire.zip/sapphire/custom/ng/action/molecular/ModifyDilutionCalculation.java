/**
 * 
 */
package sapphire.custom.ng.action.molecular;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDIDetail;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class ModifyDilutionCalculation extends BaseAction {

	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		if(properties == null ){
			throw new SapphireException("Properties not found");
		}
		
		String sampleIds = properties.getProperty("sampleids", "");
		String dilutionValue = properties.getProperty("dilutionval", "");
		//String batchName = properties.getProperty("batchname", "");
		String batchId = properties.getProperty("keyid1", "");
		
		DataSet dsDilutionCal = new DataSet();
        dsDilutionCal.addColumn("dilutiontube", DataSet.STRING);
        dsDilutionCal.addColumn("concentration", DataSet.STRING);
        dsDilutionCal.addColumn("amntofsample", DataSet.STRING);
        dsDilutionCal.addColumn("amntofwater", DataSet.STRING);
        dsDilutionCal.addColumn("inputvol", DataSet.STRING);
        dsDilutionCal.addColumn("sampledilution", DataSet.STRING);
		
		String sql = Util.parseMessage(MolecularSql.GET_INFO_BY_SPECIMEN, StringUtil.replaceAll(sampleIds, ";", "','"));
		DataSet dsDilutionInfo = getQueryProcessor().getSqlDataSet(sql);
		if(dsDilutionInfo != null && dsDilutionInfo.getRowCount() > 0){
			for (int i = 0; i < dsDilutionInfo.size(); i++) {
				String dilutube = dsDilutionInfo.getValue(i, "s_sampleid", "");
				double dilutionratio = 0.0;
				double amntofwater = 0.0;
				double inputvol = 0.0;
				double fxdval = Double.parseDouble(dilutionValue);
				double fxdstaticval = 51.0;
				
				double concentration = Double.parseDouble(dsDilutionInfo.getValue(i, "concentration", "0.0"));
                double amntofsample = 0.0;
                if (concentration > 0) {
                    amntofsample = fxdval / concentration;
                    amntofsample = Util.roundAvoid(amntofsample);
                } else {
                    amntofsample = 0.0;
                }

                if (concentration > 0 && amntofsample < 2) {
                    dilutionratio = concentration / 10;
                    dilutionratio = Util.roundAvoid(dilutionratio);

                    amntofsample = fxdval / dilutionratio;
                    amntofsample = Util.roundAvoid(amntofsample);

                    amntofwater = fxdstaticval - amntofsample;
                    amntofwater = Util.roundAvoid(amntofwater);

                    inputvol = dilutionratio * amntofsample;
                    inputvol = Util.roundAvoid(inputvol);
                } else {
                    amntofwater = Util.roundAvoid(fxdstaticval - amntofsample);
                    inputvol = Util.roundAvoid(concentration * amntofsample);

                }
                if (dilutionratio < 0) {
                    dilutionratio = 0.0;
                } else if (amntofwater < 0) {
                    amntofwater = 0.0;
                } else if (inputvol < 0) {
                    inputvol = 0.0;
                } else if (concentration < 0) {
                    concentration = 0.0;
                } else if (amntofsample < 0) {
                    amntofsample = 0.0;
                }
                if (Double.isInfinite(dilutionratio))
                    dilutionratio = 0.0;
                if (Double.isInfinite(amntofwater))
                    amntofwater = 0.0;
                if (Double.isInfinite(inputvol))
                    inputvol = 0.0;
                if (Double.isInfinite(amntofwater))
                    amntofwater = 0.0;
                if (Double.isInfinite(inputvol))
                    inputvol = 0.0;
                int rowID = dsDilutionCal.addRow();
                dsDilutionCal.setValue(rowID, "dilutiontube", dilutube);
                dsDilutionCal.setValue(rowID, "concentration", String.valueOf(concentration));
                dsDilutionCal.setValue(rowID, "amntofsample", String.valueOf(amntofsample));
                dsDilutionCal.setValue(rowID, "amntofwater", String.valueOf(amntofwater));
                dsDilutionCal.setValue(rowID, "inputvol", String.valueOf(inputvol));
                dsDilutionCal.setValue(rowID, "sampledilution", String.valueOf(dilutionratio));
			}
			
			if(dsDilutionCal != null && dsDilutionCal.getRowCount() > 0){
				PropertyList proptag = new PropertyList();
                proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
                proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, batchId);
                proptag.setProperty("sampleid", dsDilutionCal.getColumnValues("dilutiontube", ";"));
                proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                proptag.setProperty("amtofsample", dsDilutionCal.getColumnValues("amntofsample", ";"));
                proptag.setProperty("amtofwater", dsDilutionCal.getColumnValues("amntofwater", ";"));
                proptag.setProperty("sampleinput", dsDilutionCal.getColumnValues("inputvol", ";"));
                proptag.setProperty("sampledilution", dsDilutionCal.getColumnValues("sampledilution", ";"));
                proptag.setProperty("rulebypass", "Y");
                
                getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
			}
		}
	}
}
