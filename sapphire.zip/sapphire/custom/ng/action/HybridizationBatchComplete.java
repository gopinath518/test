package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDIDetail;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

/***
 * Created By surajit
 * Description: Complete Hybridization batch and generate CSV for the batch.
 */
public class HybridizationBatchComplete extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1");
        String batchtype = properties.getProperty("batchtype");
        String filelocationpath = properties.getProperty("filelocationpath");
        String generatecsvflag = properties.getProperty("generatecsvflag");
        String origin = properties.getProperty("origin");
        String newKeyid1 = "";

        String sql = MolecularSql.GET_SAMPLES_BY_BATCHID;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchSamples = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSamples == null && dsBatchSamples.size() == 0) {
            throw new SapphireException("This Batch does not have specimen(s).");
        }
        if ("Y".equalsIgnoreCase(generatecsvflag)) {
            sql = CommonSql.GET_FILE_BASE_PATH;
            DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
            if (dsBasePath == null || dsBasePath.size() == 0) {
                throw new SapphireException("Base path not find into the system");
            }
           /* String baseloc = dsBasePath.getValue(0, "propvalue");
            filelocationpath = Util.generateMolLocPath(baseloc, "Molecular", "NanoString");*/
            filelocationpath = getFileLocation();
            generateCSV(batchid, filelocationpath);
        } else {
            sql = MolecularSql.GET_BATCHDETAILS_BY_BATCHID;
            sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
            DataSet dsCSVGenerate = getQueryProcessor().getSqlDataSet(sql);
            String csvgenflag = dsCSVGenerate.getColumnValues("generatecsvflag", ";");
            if (csvgenflag.contains("N")) {
                throw new SapphireException("This Batch has no CSV generated, You can not complete the batch.");
            }
            PropertyList editbatch = new PropertyList();
            editbatch.setProperty("parentbatchid", batchid);
            editbatch.setProperty("origin", origin);
            editbatch.setProperty("batchtype", batchtype);//batchtype
            editbatch.setProperty("batchmovestatus", properties.getProperty("batchmovestatus"));
            try {
                getActionProcessor().processAction(CopyNanoBatch.ID, CopyNanoBatch.VERSIONID, editbatch);
                newKeyid1 = editbatch.getProperty("childbatchid", "");
                deleteReagentInstrument(newKeyid1);
                updateMovement(batchid, dsBatchSamples, properties);
            } catch (SapphireException se) {
                throw new SapphireException("Can not create duplicate Batch");
            }
        }
    }

    private void generateCSV(String batchid, String filelocationpath) throws SapphireException {
        String sql = MolecularSql.GET_SAMPLES_BY_BATCHID;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchSamples = getQueryProcessor().getSqlDataSet(sql);

        sql = MolecularSql.GET_BATCHDETAILS_BY_BATCHID;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sql);

        String currentuser = connectionInfo.getSysuserId();
        sql = MolecularSql.GET_LOGIN_USERINFO_BY_USERID;
        sql = Util.parseMessage(sql, currentuser);
        DataSet dsSysUserInfo = getQueryProcessor().getSqlDataSet(sql);

        sql = MolecularSql.GET_ATTACHMENT_BY_BATCHID;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsAttachmentInfo = getQueryProcessor().getSqlDataSet(sql);

        sql = MolecularSql.GET_GENRLF_VAL_BY_ID;
        sql = Util.parseMessage(sql, dsBatchDetails.getValue(0, "generlf", ""));
        DataSet dsGenRLFInfo = getQueryProcessor().getSqlDataSet(sql);
        JSONObject jHeader = new JSONObject();
        try {
            /*int version = 1;
            String actualattachmntcount = "" + dsAttachmentInfo.size();
            int actualcountlngth = actualattachmntcount.length();
            String firstversnini = "";
            if (actualcountlngth > 1) {
                for (int i = 0; i < actualcountlngth - 1; i++) {
                    firstversnini += actualattachmntcount.charAt(i);
                }
            }
            String lastattchmntchar = "" + actualattachmntcount.charAt(actualcountlngth - 1);
            if (firstversnini.length() > 0) {
                version = version + Integer.parseInt(firstversnini);
            }
            String fileversion = version + "." + lastattchmntchar;*/
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date date = new Date();
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.DATE, 1);
            System.out.println(dateFormat.format(cal.getTime()));
            jHeader.put("File Version", "1.1");
            //jHeader.put("File Version", fileversion);
            //jHeader.put("CartridgeID", dsBatchDetails.getValue(0, "cartridgeid", "") + " " + dsBatchDetails.getValue(0, "run", ""));
            jHeader.put("CartridgeID", dsBatchDetails.getValue(0, "cartridgeid", ""));
            //jHeader.put("Email ID", dsSysUserInfo.getValue(0, "email", ""));
            jHeader.put("Email ID", "");
            //jHeader.put("ArchiveFolder", filelocationpath);
            jHeader.put("ArchiveFolder", "");
            JSONArray jBody = new JSONArray();
            if (dsBatchSamples.size() > 1) {
                for (int i = 0; i < dsBatchSamples.size(); i++) {
                    JSONObject jObcj = new JSONObject();
                    jObcj.put("LaneID", "" + (i + 1));
                    jObcj.put("SampleID", dsBatchSamples.getValue(i, "u_extractionid", ""));
                    jObcj.put("Owner", dsSysUserInfo.getValue(0, "logonname", ""));
                    jObcj.put("Comments", dsBatchSamples.getValue(i, "u_extractioncomments", ""));
                    jObcj.put("Date", dateFormat.format(cal.getTime()));
                    jObcj.put("FovCount", dsBatchDetails.getValue(0, "fovcount", ""));
                    jObcj.put("GeneRLF", dsGenRLFInfo.getValue(0, "value", ""));
                    jBody.put(jObcj);
                }
            }
            if (dsBatchSamples.size() == 1) {
                for (int i = 0; i < dsBatchSamples.size(); i++) {
                    JSONObject jObcj = new JSONObject();
                    jObcj.put("LaneID", "" + (i + 1));
                    jObcj.put("SampleID", dsBatchSamples.getValue(i, "u_extractionid", ""));
                    jObcj.put("Owner", dsSysUserInfo.getValue(0, "logonname", ""));
                    jObcj.put("Comments", dsBatchSamples.getValue(i, "u_extractioncomments", ""));
                    jObcj.put("Date", dateFormat.format(cal.getTime()));
                    jObcj.put("FovCount", dsBatchDetails.getValue(0, "fovcount", ""));
                    jObcj.put("GeneRLF", dsGenRLFInfo.getValue(0, "value", ""));
                    jBody.put(jObcj);
                }
            }
            if (dsBatchSamples.size() != 12) {
                int actualbtchspccount = dsBatchSamples.size();
                int needmorespecs = 12 - actualbtchspccount;
                for (int i = 0; i < needmorespecs; i++) {
                    JSONObject jObcj = new JSONObject();
                    int actlcnt = (actualbtchspccount + 1 + i);
                    //nt seq = Integer.parseInt(LATESTSEQ);
                    //newExtractionID = head + YY + "-" + String.format("%06d", seq);
                    jObcj.put("LaneID", "" + actlcnt);
                    jObcj.put("SampleID", "Sample " + String.format("%02d", actlcnt));
                    jObcj.put("Owner", dsSysUserInfo.getValue(0, "logonname", ""));
                    jObcj.put("Comments", "");
                    jObcj.put("Date", dateFormat.format(cal.getTime()));
                    jObcj.put("FovCount", dsBatchDetails.getValue(0, "fovcount", ""));
                    jObcj.put("GeneRLF", dsGenRLFInfo.getValue(0, "value", ""));
                    jBody.put(jObcj);
                }
            }
            String batchname = dsBatchDetails.getValue(0, "batchname", "");
            String filenameformat = "DigitalAnalyzer_" + batchname + "_" + generateFileName(batchid, batchname);
            if (batchname.contains("/")) {
                throw new SapphireException("Batch name does not support ' <b>/</b> ' operator as system can not recognize.");
            }
            File existingDir = new File(filelocationpath);
            if (!existingDir.isDirectory()) {
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "File location path is not valid or can't accessable.");
            }
            //filelocationpath = filelocationpath + "" + batchname + "_" + date.getTime() + ".csv";
            //filelocationpath = filelocationpath + File.separator + filenameformat + ".csv";//TODO GETTING FROM POLICY
            if (filelocationpath.endsWith("/"))
                filelocationpath = filelocationpath + filenameformat + ".csv";
            else
                filelocationpath = filelocationpath + File.separator + filenameformat + ".csv";
            generateCsvFile(filelocationpath, jHeader.toString(), jBody.toString());
            logger.info("CSV has been generated for Hybridization");
            PropertyList attachprop = new PropertyList();
            attachprop.clear();
            attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "HybridizationCSV");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, filenameformat);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filelocationpath);
            attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "U");
            attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filelocationpath).getName());
            attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");
            attachprop.setProperty("ATTACHMENTCLASS", "SOP");
            attachprop.setProperty("SOURCEFILENAME", filelocationpath);
            try {
                getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the"
                        + dsBatchDetails.getValue(0, "batchname", "") + " batch" + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
            attachprop.clear();
            attachprop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
            attachprop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
            attachprop.setProperty("generatecsvflag", "Y");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, attachprop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. attachment flag not added to the"
                        + dsBatchDetails.getValue(0, "batchname", "") + " batch" + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void updateMovement(String batchid, DataSet dsSample, PropertyList properties) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        prop.setProperty("batchtype", properties.getProperty("childbatchtype"));
        prop.setProperty("batchstatusview", properties.getProperty("batchstatusview"));
        prop.setProperty("batchcompletedts", "n");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsSample.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currentmovementstep", StringUtil.repeat("PrepStation", dsSample.size(), ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        prop.clear();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSample.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currenttramstop", StringUtil.repeat("PrepStation", dsSample.size(), ";"));
        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
    }

    private void deleteReagentInstrument(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_REAGENT_BY_BATCHID, batchid);
        DataSet dsReagents = getQueryProcessor().getSqlDataSet(sql);
        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("reagentid", dsReagents.getColumnValues("reagentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }

        sql = Util.parseMessage(MolecularSql.GET_INSTRUMENT_BY_BATCHID, batchid);
        DataSet dsInstruments = getQueryProcessor().getSqlDataSet(sql);
        attachprop.clear();
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, batchid);
        attachprop.setProperty("instrumentid", dsInstruments.getColumnValues("instrumentid", ";"));
        attachprop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");

        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate(ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

    public static void generateCsvFile(String localtionfilename, String headerinput, String bodyinput) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(localtionfilename);
            /**** CREATE HEADER PART STARTS ****/
            writer.append("<Header>\n");
            JSONObject jRootObj = new JSONObject(headerinput);
            String fileversion = jRootObj.getString("File Version");
            String cartridgeid = jRootObj.getString("CartridgeID");
            String emailid = jRootObj.getString("Email ID");
            String archivefolder = jRootObj.getString("ArchiveFolder");
            writer.append("FileVersion" + "," + fileversion + "\n");
            writer.append("CartridgeID" + "," + cartridgeid + "\n");
            writer.append("Email" + "," + emailid + "\n");
            writer.append("ArchiveFolder" + "," + archivefolder + "\n");
            /*Iterator<?> headerkeys = jRootObj.keys();
            while (headerkeys.hasNext()) {
                String key = (String) headerkeys.next();
                String jobjval = (String) jRootObj.get(key);
                System.out.println(key + ": " + jobjval);
                writer.append(key + ": " + "," + jobjval + "\n");
            }*/
            writer.append("</Header>\n");
            /**** CREATE HEADER PART ENDS ****/
            writer.append("\n");
            writer.append("<Samples>\n");
            JSONArray jArryBody = new JSONArray(bodyinput);
            writer.append("LaneID,SampleID,Owner,Comments,Date,FovCount,GeneRLF");
            writer.append('\n');
            for (int i = 0; i < jArryBody.length(); i++) {
                JSONObject element = jArryBody.getJSONObject(i);
                String laneid = element.getString("LaneID");
                String sampleid = element.getString("SampleID");
                String owner = element.getString("Owner");
                String comments = element.getString("Comments");
                String date = element.getString("Date");
                String fovcount = element.getString("FovCount");
                String generlf = element.getString("GeneRLF");
                writer.append(laneid + "," + sampleid + "," + owner + "," + comments + "," + date + "," + fovcount + "," + generlf);
                writer.append('\n');
            }
            writer.append("</Samples>");
            System.out.println("CSV file is created...");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param batchid
     * @param batchname
     * @return latestfilename
     * @throws SapphireException
     * @Desc: Used to rename CSV file name.
     */
    private String generateFileName(String batchid, String batchname) throws SapphireException {
        String latestfilename = "";
        String sql = MolecularSql.GET_ATTACHMENT_BY_BATCHID_HY;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"), "%" + batchname + "%");
        DataSet dsAttachmentInfo = getQueryProcessor().getSqlDataSet(sql);
        int attachmentcount = dsAttachmentInfo.size();
        String tails = "A";
        if (attachmentcount == 0) {
            char c = tails.charAt(0);
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        } else {
            int c = tails.charAt(0) + attachmentcount;
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        }
        return latestfilename;
    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        //CHECK FOLDER
        fileLocation = Util.createFolderForMolecular(fileLocation, "Hybridization");
        return fileLocation;
    }
}
