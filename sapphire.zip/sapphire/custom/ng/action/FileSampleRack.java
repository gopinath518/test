package sapphire.custom.ng.action;


import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 5/27/2016.
 * TODO provide Action Details and Mandatory Input List
 */
public class FileSampleRack extends BaseAction {

    /*
    *   OOB metod provided to override
    *
    *   @param properties   Property List of inputs
    * */
    public void processAction(PropertyList properties) throws SapphireException {

        String hemerack = properties.getProperty("hemerack");
        String sampleid = properties.getProperty("sampleid");
        sampleid = StringUtil.replaceAll(sampleid, ";", "','") ;


        DataSet ds = getQueryProcessor().getSqlDataSet(MolecularSql.FILESAMPLERACK_TRACKITEM, sampleid);
        String trackitemid = ds.getColumnValues("trackitemid", ";");

        DataSet dsretort = getQueryProcessor().getSqlDataSet(MolecularSql.FILESAMPLERACK_STORAGEUNIT, hemerack);
        String storageunitid = dsretort.getColumnValues("storageunitid", ";");
        updateCheckInStorage(storageunitid, trackitemid);

    }

    /*
    *   Update trackitem for storage unit
    *
    *   @param storageunitid    Storage unit id
    *   @param trackitemid      Track item id
    * */
    private void updateCheckInStorage(String storageunitid, String trackitemid) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("currentstorageunitid", storageunitid);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }

    }

}
