package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.xml.crypto.Data;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by SBaitalik on 12/5/2016.
 * Description: This action is used for creating automatic NGBatch for Panel when any of the test's result will be
 * detected then all dilution tube will be TNP.
 */
public class AutoNGBatchCreate extends BaseAction {

    public static final String ID = "AutoNGBatchCreate";
    public static final String VERSION = "1";

    private final String POLICY_NAME = "PanelAutoBatchCreatePolicy";
    private final String POLICY_NODE = "MolAutoBatchCrt";
    private final String STATIC_MMER_PARAMLISTNAME = "JAK2 V617F Mutation Analysis;JAK2 Exon 12-14 Mutation Analysis;Calreticulin (CALR) Mutation Analysis;MPL Mutation Analysis";
    private final String STATIC_MMER_PARAMLISTNAME_SEQ = "1;2;3;4";
    private final String STATIC_MMSR_PARAMLISTNAME = "JAK2 V617F Mutation Analysis;JAK2 Exon 12-14 Mutation Analysis;MPL Mutation Analysis";
    private final String STATIC_MMSR_PARAMLISTNAME_SEQ = "1;2;3";
    private final String STATIC_PANEL = "MMER;MMSR";
    private final String STATIC_NOT_TNP_PANEL = "MBIP;MBTK";


    public void processAction(PropertyList properties) throws SapphireException {
        String extractionid = properties.getProperty("u_extractionid", "");
        String sampleid = properties.getProperty("s_sampleid", "");
        String paramlist = properties.getProperty("paramlistid", "");
        String tramstop = properties.getProperty("tramstop", "");

        if (Util.isNull(extractionid)) {
            throw new SapphireException("Extraction ID can not be blank.");
        }
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Sample ID can not be blank.");
        }
        String childsampleid = "";
        String testname = "";
        String batchid = "";
        extractionid = Util.getUniqueList(extractionid, ";", true);
        if ("Precepetation".equalsIgnoreCase(tramstop)) {
            DataSet dsPanel = getMolPanelFrmPolicy();
            if (dsPanel == null) {
                return;
            }
            if (dsPanel.size() == 0) {
                return;
            }
            String sql = "select distinct s.u_accessionid,smp.testname,s.u_extractionid,s.s_sampleid,t.containertypeid,smp.lvtestcodeid,smp.ispanel,nvl(smp.lvtestpanelid,'N') lvtestpanelid" +
                    " from s_sample s,trackitem t,u_sampletestcodemap smp" +
                    " where" +
                    " s.s_sampleid = t.linkkeyid1" +
                    " and smp.s_sampleid = s.s_sampleid" +
                    " and smp.lvtestpanelid in('" + StringUtil.replaceAll(dsPanel.getColumnValues("panelid", ";"), ";", "','") + "')" +
                    " and s.u_extractionid in('" + StringUtil.replaceAll(extractionid, ";", "','") + "')";
            DataSet dsMMERCheck = getQueryProcessor().getSqlDataSet(sql);
            if (dsMMERCheck == null) {
                return;
            }
            if (dsMMERCheck.size() == 0) {
                return;
            }

            String panelcodes = "";
            if (dsMMERCheck != null && dsMMERCheck.size() > 0) {
                /*String unqPanelLst[] = StringUtil.split(Util.getUniqueList(dsMMERCheck.getColumnValues("lvtestpanelid", ";"), ";", true), ";");
                if (unqPanelLst.length > 1) {
                    for (int i = 0; i < unqPanelLst.length; i++) {
                        HashMap hm = new HashMap();
                        hm.put("panelid", unqPanelLst[i]);
                        DataSet dsFilter = dsPanel.getFilteredDataSet(hm);
                        if (dsFilter == null) {
                            return;
                        }
                        if (dsFilter.size() == 0) {
                            return;
                        }
                    }
                    //return;
                }*/
                for (int i = 0; i < dsMMERCheck.size(); i++) {
                    String mmerPanelid = dsMMERCheck.getValue(i, "lvtestpanelid", "");
                    for (int j = 0; j < dsPanel.size(); j++) {
                        if (mmerPanelid.equalsIgnoreCase(dsPanel.getValue(j, "panelid", ""))) {
                            panelcodes += ";" + dsPanel.getValue(j, "panelid", "");
                        } /*else {
                            //IF THERE IS ANY OTHER PANEL ASSOCIATED WIT THE BATCH NO REFLEX PANEL WILL CREATED.
                            return;
                        }*/
                    }
                }

            }
            if (!Util.isNull(panelcodes)) {
                panelcodes = panelcodes.substring(1);
                panelcodes = Util.getUniqueList(panelcodes, ";", true);
            } else {
                return;
            }
            sql = "select distinct s.u_accessionid,smp.testname,s.u_extractionid,s.s_sampleid,t.containertypeid,smp.lvtestcodeid,smp.ispanel,nvl(smp.lvtestpanelid,'N') lvtestpanelid" +
                    " from s_sample s,trackitem t,u_sampletestcodemap smp" +
                    " where" +
                    " s.s_sampleid = t.linkkeyid1" +
                    " and smp.s_sampleid = s.s_sampleid" +
                    " and smp.lvtestpanelid in( '" + StringUtil.replaceAll(panelcodes, ";", "','") + "' )" +
                    " and s.u_extractionid in('" + StringUtil.replaceAll(extractionid, ";", "','") + "')" +
                    " and t.containertypeid ='Ellution Tube'";
            DataSet dsPanelCheck = getQueryProcessor().getSqlDataSet(sql);
            if (dsPanelCheck == null) {
                return;
            }
            if (dsPanelCheck.size() == 0) {
                return;
            }
            batchid = createNGBatch(panelcodes);
            DataSet dsSampleInfo = getSampleInfo(extractionid, panelcodes);
            String mmerpaneltestcodes = getMMERTestCodes(panelcodes);
            childsampleid = createDilutionTube(dsSampleInfo, paramlist, mmerpaneltestcodes);
            updateReportFlag(childsampleid);
            updateTrackItem(childsampleid);
            addTestCode(extractionid, childsampleid, panelcodes);
            testname = Util.getUniqueList(dsSampleInfo.getColumnValues("testname", ";"), ";", true);
            //addEnterDataItem(childsampleid, testname, properties);
            addNGBatchSampleMap(batchid, childsampleid);
        } else {
            DataSet dsTNPPanel = new DataSet();
            dsTNPPanel.addColumn("panelid", DataSet.STRING);
            String[] panelArray = StringUtil.split(STATIC_PANEL, ";");
            for (int i = 0; i < panelArray.length; i++) {
                int rowId = dsTNPPanel.addRow();
                dsTNPPanel.setValue(rowId, "panelid", panelArray[i]);
            }


            DataSet dsSampleInfo = getSampleInfo(extractionid, dsTNPPanel.getColumnValues("panelid", ";"));
            String unqPanelId = Util.getUniqueList(dsSampleInfo.getColumnValues("lvtestpanelid", ";"), ";", true);
            String[] inputPanel = StringUtil.split(unqPanelId, ";");

            for (int i = 0; i < inputPanel.length; i++) {
                HashMap hm = new HashMap();
                hm.put("panelid", inputPanel[i]);
                DataSet dsFilter = dsTNPPanel.getFilteredDataSet(hm);
                if (dsFilter == null) {
                    return;
                }
                if (dsFilter.size() == 0) {
                    dsTNPPanel = new DataSet();
                    dsTNPPanel.addColumn("panelid", DataSet.STRING);
                    String[] nottnppanelArray = StringUtil.split(STATIC_NOT_TNP_PANEL, ";");
                    for (int j = 0; j < nottnppanelArray.length; j++) {
                        int rowId = dsTNPPanel.addRow();
                        dsTNPPanel.setValue(rowId, "panelid", nottnppanelArray[j]);
                    }
                    dsSampleInfo = getSampleInfo(extractionid, dsTNPPanel.getColumnValues("panelid", ";"));
                    unqPanelId = Util.getUniqueList(dsSampleInfo.getColumnValues("lvtestpanelid", ";"), ";", true);
                    childsampleid = getDilutionTubeFromMMERBatch(sampleid);
                    testname = Util.getUniqueList(dsSampleInfo.getColumnValues("testname", ";"), ";", true);
                    testname = stringMinusParamList(testname, paramlist, unqPanelId);
                    addNormalEnterDataItem(childsampleid, testname, properties, paramlist);
                    return;
                }
            }
            childsampleid = getDilutionTubeFromMMERBatch(sampleid);
            testname = Util.getUniqueList(dsSampleInfo.getColumnValues("testname", ";"), ";", true);
            testname = stringMinusParamList(testname, paramlist, unqPanelId);
            addEnterDataItem(childsampleid, testname, properties, paramlist);
            //addNGBatchSampleMap(batchid, childsampleid);
        }

        //SET PROPERTY OF NEWLY CREATED MMER BATCH
        properties.setProperty("newmmerbatchid", batchid);
        //throw new SapphireException("test");
    }

    /**
     * This function is used for creating a batch into the system.
     *
     * @throws SapphireException
     */
    private String createNGBatch(String panelcodes) throws SapphireException {
        String ngbatchid = "";
        if ("MMER".equalsIgnoreCase(panelcodes)) {
            panelcodes = "MPN_Extended";
        } else if ("MMSR".equalsIgnoreCase(panelcodes)) {
            panelcodes = "MPN_Standard";
        } else if ("MBTK".equalsIgnoreCase(panelcodes)) {
            panelcodes = "BTK Resistance";
        } else if ("MBIP".equalsIgnoreCase(panelcodes)) {
            panelcodes = "BTK Susceptibility";
        }
        String timestamp = new java.text.SimpleDateFormat("MMddyyyyhmmssa").format(new Date());
        String batchname = panelcodes + "_" + timestamp;
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchname", batchname);
        pl.setProperty("batchmovestatus", "SequencingComplete");
        pl.setProperty("origin", "Reporting");//SequencingComplete
        pl.setProperty("mmerbatch", "Y");
        pl.setProperty("batchtype", "Molecular");
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid = pl.getProperty("newkeyid1");
        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("NGBatch can not create.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return ngbatchid;
    }

    /**
     * This will create dilution tube for parent sample of the same extraction
     *
     * @param dsSampleInfo
     * @throws SapphireException
     */
    private String createDilutionTube(DataSet dsSampleInfo, String paramlist, String mmerpaneltestcodes) throws SapphireException {
        String newkeyid = "";
        String getUniqueParamlist = Util.getUniqueList(paramlist, ";", true);
        if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
            String getUniqueSampleids = Util.getUniqueList(dsSampleInfo.getColumnValues("s_sampleid", ";"), ";", true);
            String mmerpaneltestcodesArry[] = StringUtil.split(mmerpaneltestcodes, ";");
            /*HashMap hm = new HashMap();
            hm.clear();
            hm.put("testname", getUniqueParamlistArry[i]);
            DataSet dsFilter = dsSampleInfo.getFilteredDataSet(hm);*/
            PropertyList prop = new PropertyList();
            prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, getUniqueSampleids);
            prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "" + mmerpaneltestcodesArry.length);
            prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
            prop.setProperty("__trackitem_custodialdepartmentid", StringUtil.repeat(connectionInfo.getDefaultDepartment(), (StringUtil.split(getUniqueSampleids, ";")).length, ";"));
            prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "u_concentrationratio;sampletypeid;u_extractionid;u_bodysite;u_markminimal;u_clientspecimenid;u_sampleinformation;u_accessionid;sstudyid;u_currentmovementstep");

            try {
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Cannot create child sample.");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            newkeyid = prop.getProperty("newkeyid1");
        }

        return newkeyid;
    }

    /**
     * This will update container type of child sample
     *
     * @param childsampleid This is newly created child samples.
     * @throws SapphireException
     */
    private void updateTrackItem(String childsampleid) throws SapphireException {
        String childsampleidArry[] = StringUtil.split(childsampleid, ";");
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, childsampleid);
        props.setProperty("containertypeid", StringUtil.repeat("Dilution Tube", childsampleidArry.length, ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * This is for adding testcode with child samples(s)
     *
     * @param extractionid  This is extraction id of input param.
     * @param childsampleid This is newly created child sample(s).
     * @throws SapphireException
     */
    private void addTestCode(String extractionid, String childsampleid, String panelcodes) throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn("s_sampleid", DataSet.STRING);
        ds.addColumn("lvtestcodeid", DataSet.STRING);
        String sql = "select s.u_accessionid,s.u_extractionid,s.s_sampleid,t.containertypeid,smp.lvtestcodeid,smp.ispanel,nvl(smp.lvtestpanelid,'N') lvtestpanelid" +
                " from s_sample s,trackitem t,u_sampletestcodemap smp" +
                " where" +
                " s.s_sampleid = t.linkkeyid1" +
                " and smp.s_sampleid = s.s_sampleid" +
                " and t.containertypeid ='Ellution Tube'" +
                " and smp.lvtestpanelid in('" + StringUtil.replaceAll(panelcodes, ";", "','") + "')" +
                " and u_extractionid in('" + StringUtil.replaceAll(extractionid, ";", "','") + "')";

        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
            String panelid = Util.getUniqueList(dsSampleInfo.getColumnValues("lvtestpanelid", ";"), ";", true);
            String getUniqueEllutionTubeId = Util.getUniqueList(dsSampleInfo.getColumnValues("s_sampleid", ";"), ";", true);
            sql = "select tm.indtestcodeid from u_testcode t, u_testcodepanelmap tm" +
                    " where" +
                    " t.u_testcodeid = tm.u_testcodeid" +
                    " and tm.u_testcodeid in('" + StringUtil.replaceAll(panelid, ";", "','") + "')";
            DataSet dsTestCodes = getQueryProcessor().getSqlDataSet(sql);
            if (dsTestCodes != null && dsTestCodes.size() > 0) {
                String[] childsampleidArry = StringUtil.split(childsampleid, ";");
                String[] getUniqueEllutionTubeIdArry = StringUtil.split(getUniqueEllutionTubeId, ";");
                for (int i = 0; i < getUniqueEllutionTubeIdArry.length; i++) {
                    for (int j = 0; j < dsTestCodes.size(); j++) {
                        int rowID = ds.addRow();
                        ds.setValue(rowID, "s_sampleid", "");
                        ds.setValue(rowID, "lvtestcodeid", dsTestCodes.getValue(j, "indtestcodeid", ""));
                    }
                }
                for (int i = 0; i < childsampleidArry.length; i++) {
                    ds.setValue(i, "s_sampleid", childsampleidArry[i]);
                }
                /*for (int i = 0; i < dsTestCodes.size(); i++) {
                    for (int j = 0; j < childsampleidArry.length; j++) {
                        int rowID = ds.addRow();
                        ds.setValue(rowID, "s_sampleid", childsampleidArry[j]);
                        ds.setValue(rowID, "lvtestcodeid", dsTestCodes.getValue(i, "indtestcodeid", ""));
                    }
                }*/
                PropertyList prop = new PropertyList();
                prop.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, ds.getColumnValues("s_sampleid", ";"));
                prop.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, ds.getColumnValues("lvtestcodeid", ";"));
                prop.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE,"Y");
                getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, prop);
            }
        }
    }

    /**
     * This will return samples information which container type are Ellution tube by extraction id(s).
     *
     * @param extractionid This is extraction id of input param.
     * @throws SapphireException
     */
    private DataSet getSampleInfo(String extractionid, String panelcodes) throws SapphireException {
        DataSet dsSampleInfo = null;
        String sql = "select s.u_accessionid,smp.testname,s.u_extractionid,s.s_sampleid,t.containertypeid,smp.lvtestcodeid,smp.ispanel,nvl(smp.lvtestpanelid,'N') lvtestpanelid" +
                " from s_sample s,trackitem t,u_sampletestcodemap smp" +
                " where" +
                " s.s_sampleid = t.linkkeyid1" +
                " and smp.s_sampleid = s.s_sampleid" +
                " and t.containertypeid ='Ellution Tube'" +
                " and smp.lvtestpanelid in('" + StringUtil.replaceAll(panelcodes, ";", "','") + "')" +
                " and u_extractionid in('" + StringUtil.replaceAll(extractionid, ";", "','") + "')";
        dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

        return dsSampleInfo;
    }

    /**
     * This is for entering data of child samples.
     *
     * @param testname      This is paramlist
     * @param childsampleid This is newly created child sample(s).
     * @throws SapphireException
     */
    private void addEnterDataItem(String childsampleid, String testname, PropertyList inputprops, String paramlistinput) throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn("parentsampleid", DataSet.STRING);
        ds.addColumn("paramlistid", DataSet.STRING);
        ds.addColumn("paramlistversionid", DataSet.STRING);
        ds.addColumn("paramid", DataSet.STRING);
        ds.addColumn("enteredtext", DataSet.STRING);
        ds.addColumn("variantid", DataSet.STRING);
        ds.addColumn("paramtype", DataSet.STRING);
        ds.addColumn("replicateid", DataSet.STRING);
        ds.addColumn("dataset", DataSet.STRING);
        String sql = "select sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                " sd.dataset = sdi.dataset and sd.paramlistid in('" + StringUtil.replaceAll(testname, ";", "','") + "')" +
                " and  sd.keyid1 in ('" + StringUtil.replaceAll(childsampleid, ";", "','") + "') and paramid='RESULT'";
        DataSet dsGetSamplesData = getQueryProcessor().getSqlDataSet(sql);
        sql = "select enteredtext,paramlistid,keyid1,paramid from sdidataitem where keyid1 in(" +
                "'" + StringUtil.replaceAll(inputprops.getProperty("s_sampleid", ""), ";", "','") + "')" +
                " and paramlistid in('" + StringUtil.replaceAll(inputprops.getProperty("paramlistid", ""), ";", "','") + "') and paramid='RESULT'";
        DataSet dsGetData = getQueryProcessor().getSqlDataSet(sql);
        if (dsGetSamplesData != null && dsGetSamplesData.size() > 0) {
            String paramlistid = dsGetData.getValue(0, "paramlistid", "");

            for (int i = 0; i < dsGetSamplesData.size(); i++) {
                int rowID = ds.addRow();
                if (paramlistid.equalsIgnoreCase(dsGetSamplesData.getValue(i, "paramlistid"))) {
                    ds.setValue(rowID, "parentsampleid", dsGetSamplesData.getValue(i, "parentsampleid"));
                    ds.setValue(rowID, "paramlistid", dsGetSamplesData.getValue(i, "paramlistid"));
                    ds.setValue(rowID, "paramlistversionid", dsGetSamplesData.getValue(i, "paramlistversionid"));
                    ds.setValue(rowID, "paramid", dsGetSamplesData.getValue(i, "paramid"));
                    ds.setValue(rowID, "enteredtext", dsGetData.getValue(0, "enteredtext"));
                    ds.setValue(rowID, "variantid", dsGetSamplesData.getValue(i, "variantid"));
                    ds.setValue(rowID, "paramtype", dsGetSamplesData.getValue(i, "paramtype"));
                    ds.setValue(rowID, "replicateid", dsGetSamplesData.getValue(i, "replicateid"));
                    ds.setValue(rowID, "dataset", dsGetSamplesData.getValue(i, "dataset"));
                } else {
                    ds.setValue(rowID, "parentsampleid", dsGetSamplesData.getValue(i, "parentsampleid"));
                    ds.setValue(rowID, "paramlistid", dsGetSamplesData.getValue(i, "paramlistid"));
                    ds.setValue(rowID, "paramlistversionid", dsGetSamplesData.getValue(i, "paramlistversionid"));
                    ds.setValue(rowID, "paramid", dsGetSamplesData.getValue(i, "paramid"));
                    ds.setValue(rowID, "enteredtext", "TNP");
                    ds.setValue(rowID, "variantid", dsGetSamplesData.getValue(i, "variantid"));
                    ds.setValue(rowID, "paramtype", dsGetSamplesData.getValue(i, "paramtype"));
                    ds.setValue(rowID, "replicateid", dsGetSamplesData.getValue(i, "replicateid"));
                    ds.setValue(rowID, "dataset", dsGetSamplesData.getValue(i, "dataset"));
                }
            }
            String paramid = inputprops.getProperty("paramid", "");
            String enteredtext = inputprops.getProperty("enteredtext", "");
            String sampleid = inputprops.getProperty("s_sampleid", "");
            String paramlist = inputprops.getProperty("paramlistid", "");
            sql = "select sdi.enteredtext,sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                    " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                    " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                    " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                    " sd.dataset = sdi.dataset and sd.paramlistid in('" + StringUtil.replaceAll(paramlist, ";", "','") + "')" +
                    " and sd.keyid1 in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "') and sdi.paramid in ('" + StringUtil.replaceAll(paramid, ";", "','") + "')--!='RESULT' --and sdi.enteredtext is not null";
            DataSet dsGetOtherData = getQueryProcessor().getSqlDataSet(sql);

            HashMap hm = new HashMap();
            hm.clear();
            hm.put("paramlistid", Util.getUniqueList(paramlist, ";", true));
            DataSet dsFilter = ds.getFilteredDataSet(hm);

            if (dsGetOtherData != null && dsGetOtherData.size() > 0) {
                for (int i = 0; i < dsFilter.size(); i++) {
                    String paramlistidNew = dsFilter.getValue(i, "paramlistid", "");

                    for (int j = 0; j < dsGetOtherData.size(); j++) {
                        if (paramlistidNew.equalsIgnoreCase(dsGetOtherData.getValue(j, "paramlistid", ""))) {
                            int rowId = ds.addRow();
                            ds.setValue(rowId, "parentsampleid", dsFilter.getValue(i, "parentsampleid"));
                            ds.setValue(rowId, "paramlistid", dsFilter.getValue(i, "paramlistid"));
                            ds.setValue(rowId, "paramlistversionid", dsFilter.getValue(i, "paramlistversionid"));
                            ds.setValue(rowId, "paramid", dsGetOtherData.getValue(j, "paramid"));
                            ds.setValue(rowId, "enteredtext", dsGetOtherData.getValue(j, "enteredtext"));
                            ds.setValue(rowId, "variantid", dsFilter.getValue(j, "variantid"));
                            ds.setValue(rowId, "paramtype", dsFilter.getValue(j, "paramtype"));
                            ds.setValue(rowId, "replicateid", dsFilter.getValue(j, "replicateid"));
                            ds.setValue(rowId, "dataset", dsFilter.getValue(j, "dataset"));
                        }
                    }
                }


                /*HashMap hm = new HashMap();
                hm.clear();
                hm.put("paramlistid", paramlist);
                DataSet dsFilter = dsGetOtherData.getFilteredDataSet(hm);
                String childsampleidArry[] = StringUtil.split(childsampleid, ";");
                for (int j = 0; j < childsampleidArry.length; j++) {
                    for (int i = 0; i < dsFilter.size(); i++) {
                        int rowID = ds.addRow();
                        ds.setValue(rowID, "parentsampleid", childsampleidArry[j]);
                        ds.setValue(rowID, "paramlistid", dsFilter.getValue(i, "paramlistid"));
                        ds.setValue(rowID, "paramlistversionid", dsFilter.getValue(i, "paramlistversionid"));
                        ds.setValue(rowID, "paramid", dsFilter.getValue(i, "paramid"));
                        ds.setValue(rowID, "enteredtext", dsFilter.getValue(i, "enteredtext"));
                        ds.setValue(rowID, "variantid", dsFilter.getValue(i, "variantid"));
                        ds.setValue(rowID, "paramtype", dsFilter.getValue(i, "paramtype"));
                        ds.setValue(rowID, "replicateid", dsFilter.getValue(i, "replicateid"));
                        ds.setValue(rowID, "dataset", dsFilter.getValue(i, "dataset"));
                    }
                }*/
            }
            PropertyList props = new PropertyList();
            props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataItem.PROPERTY_KEYID1, ds.getColumnValues("parentsampleid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, ds.getColumnValues("paramlistid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, ds.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMID, ds.getColumnValues("paramid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, ds.getColumnValues("enteredtext", ";"));

            props.setProperty(EnterDataItem.PROPERTY_VARIANTID, ds.getColumnValues("variantid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, ds.getColumnValues("paramtype", ";"));
            props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, ds.getColumnValues("replicateid", ";"));
            props.setProperty(EnterDataItem.PROPERTY_DATASET, ds.getColumnValues("dataset", ";"));
            props.setProperty("bypass", "Y");

            try {
                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
            } catch (SapphireException e) {
                throw new SapphireException("EnterDataItem not performed." + e.getMessage());
            }

        }
    }

    private void addNormalEnterDataItem(String childsampleid, String testname, PropertyList inputprops, String paramlistinput) throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn("parentsampleid", DataSet.STRING);
        ds.addColumn("paramlistid", DataSet.STRING);
        ds.addColumn("paramlistversionid", DataSet.STRING);
        ds.addColumn("paramid", DataSet.STRING);
        ds.addColumn("enteredtext", DataSet.STRING);
        ds.addColumn("variantid", DataSet.STRING);
        ds.addColumn("paramtype", DataSet.STRING);
        ds.addColumn("replicateid", DataSet.STRING);
        ds.addColumn("dataset", DataSet.STRING);
        String paramlist = inputprops.getProperty("paramlistid", "");
        String paramid = inputprops.getProperty("paramid", "");
        String enteredtext = inputprops.getProperty("enteredtext", "");
        String sampleid = inputprops.getProperty("s_sampleid", "");

        String sql = "select sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                " sd.dataset = sdi.dataset and sd.paramlistid in('" + StringUtil.replaceAll(Util.getUniqueList(paramlist, ";", true), ";", "','") + "')" +
                " and sdi.paramid in('" + StringUtil.replaceAll(Util.getUniqueList(paramid, ";", true), ";", "','") + "')" +
                " and  sd.keyid1 in ('" + StringUtil.replaceAll(childsampleid, ";", "','") + "')";
        DataSet dsGetChildSamplesData = getQueryProcessor().getSqlDataSet(sql);

        sql = "select sdi.enteredtext,sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid," +
                " sdi.paramtype,sdi.replicateid,sdi.dataset" +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2" +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and" +
                " sd.dataset = sdi.dataset and sd.paramlistid in('" + StringUtil.replaceAll(Util.getUniqueList(paramlist, ";", true), ";", "','") + "')" +
                " and sdi.paramid in('" + StringUtil.replaceAll(Util.getUniqueList(paramid, ";", true), ";", "','") + "')" +
                " and sd.keyid1 in ('" + StringUtil.replaceAll(sampleid, ";", "','") + "')";
        DataSet dsGetRootSampleOtherData = getQueryProcessor().getSqlDataSet(sql);

        String[] inputParamlist = StringUtil.split(Util.getUniqueList(paramlist, ";", true), ";");
        String[] inputParamid = StringUtil.split(Util.getUniqueList(paramid, ";", true), ";");
        String[] inputEnteredtext = StringUtil.split(enteredtext, ";");
        for (int i = 0; i < inputParamlist.length; i++) {
            for (int j = 0; j < inputParamid.length; j++) {
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("paramlistid", inputParamlist[i]);
                hm.put("paramid", inputParamid[j]);
                DataSet dsChildFilter = dsGetChildSamplesData.getFilteredDataSet(hm);
                if (dsChildFilter != null && dsChildFilter.size() > 0) {
                    for (int d = 0; d < dsChildFilter.size(); d++) {
                        int rowID = ds.addRow();
                        ds.setValue(rowID, "parentsampleid", dsChildFilter.getValue(d, "parentsampleid", ""));
                        ds.setValue(rowID, "paramlistid", dsChildFilter.getValue(d, "paramlistid", ""));
                        ds.setValue(rowID, "paramlistversionid", dsChildFilter.getValue(d, "paramlistversionid", ""));
                        ds.setValue(rowID, "paramid", dsChildFilter.getValue(d, "paramid", ""));
                        ds.setValue(rowID, "enteredtext", inputEnteredtext[j]);
                        ds.setValue(rowID, "variantid", dsChildFilter.getValue(d, "variantid", ""));
                        ds.setValue(rowID, "paramtype", dsChildFilter.getValue(d, "paramtype", ""));
                        ds.setValue(rowID, "replicateid", dsChildFilter.getValue(d, "replicateid", ""));
                        ds.setValue(rowID, "dataset", dsChildFilter.getValue(d, "dataset", ""));

                    }
                }
            }
            //DataSet dsrootFilter = dsGetRootSampleOtherData.getFilteredDataSet(hm);
        }
        PropertyList props = new PropertyList();
        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataItem.PROPERTY_KEYID1, ds.getColumnValues("parentsampleid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, ds.getColumnValues("paramlistid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, ds.getColumnValues("paramlistversionid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMID, ds.getColumnValues("paramid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, ds.getColumnValues("enteredtext", ";"));

        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, ds.getColumnValues("variantid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, ds.getColumnValues("paramtype", ";"));
        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, ds.getColumnValues("replicateid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_DATASET, ds.getColumnValues("dataset", ";"));
        props.setProperty("bypass", "Y");

        try {
            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
        } catch (SapphireException e) {
            throw new SapphireException("EnterDataItem not performed." + e.getMessage());
        }
    }

    private void updateReportFlag(String childsampleid) throws SapphireException {
        String uniqueSample = Util.getUniqueList(childsampleid, ";", true);
        String uniqueSampleArr[] = StringUtil.split(uniqueSample, ";");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, uniqueSample);
        prop.setProperty("u_reportflag", StringUtil.repeat("Y", uniqueSampleArr.length, ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
    }

    /**
     * Entering child sample(s) information and newly created batch into NGBatchSampleMap SDC
     *
     * @param batchid       This is creating automatically.
     * @param childsampleid This is newly created child sample(s).
     * @throws SapphireException
     */
    private void addNGBatchSampleMap(String batchid, String childsampleid) throws SapphireException {
        String[] childsampleidArr = StringUtil.split(childsampleid, ";");
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatchSampleMap");
        prop.setProperty(AddSDI.PROPERTY_COPIES, "" + childsampleidArr.length);
        prop.setProperty("ngbatchid", StringUtil.repeat(batchid, childsampleidArr.length, ";"));
        prop.setProperty("sampleid", childsampleid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("NGBatchSample failed.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }

    }

    private String getDilutionTubeFromMMERBatch(String sampleids) throws SapphireException {
        String sql = "select u_ngbatchid from u_batch_sample_detail where sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "') order by createdt desc";
        DataSet dsBatch = getQueryProcessor().getSqlDataSet(sql);
        String ngbatchid = dsBatch.getValue(0, "u_ngbatchid", "");
        sql = "select sampleid,ngbatchid from u_ngbatchsamplemap where ngbatchid=(select mmerbatchid from u_ngbatch where u_ngbatchid='" + ngbatchid + "')";
        DataSet dsMMERBatch = getQueryProcessor().getSqlDataSet(sql);
        String sampleid = dsMMERBatch.getColumnValues("sampleid", ";");
        return sampleid;
    }

    private String getMMERTestCodes(String panelcodes) throws SapphireException {
        String testcodes = "";
        String sql = "select indtestcodeid from u_testcodepanelmap where u_testcodeid='" + panelcodes + "'";
        DataSet dsTestcodes = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestcodes != null && dsTestcodes.size() > 0) {
            testcodes = dsTestcodes.getColumnValues("indtestcodeid", ";");
        }
        return testcodes;
    }

    private DataSet getMolPanelFrmPolicy() throws SapphireException {
        DataSet dsPanelIds = new DataSet();
        dsPanelIds.addColumn("panelid", DataSet.STRING);
        PropertyList policyProps = getConfigurationProcessor().getPolicy(POLICY_NAME, POLICY_NODE);
        if (policyProps != null) {
            PropertyListCollection panelcollectioninfo = policyProps.getCollection("panelcollection");
            for (int i = 0; i < panelcollectioninfo.size(); i++) {
                int rowID = dsPanelIds.addRow();
                dsPanelIds.setValue(rowID, "panelid", panelcollectioninfo.getPropertyList(i).getProperty("panelid"));
            }
        }
        return dsPanelIds;
    }

    private String stringMinusParamList(String actualparamlistname, String inputparamlist, String unqPanelId) throws SapphireException {
        String testname = "";
        DataSet dsParamlistSeq = new DataSet();
        dsParamlistSeq.addColumn("paramlistname", DataSet.STRING);
        dsParamlistSeq.addColumn("paramlistnameseq", DataSet.STRING);
        String actualparamlistnameArry[] = StringUtil.split(actualparamlistname, ";");
        if ("MMER".equalsIgnoreCase(unqPanelId)) {
            String staticparamlistnameArry[] = StringUtil.split(STATIC_MMER_PARAMLISTNAME, ";");
            String actualparamlistnameSeqArry[] = StringUtil.split(STATIC_MMER_PARAMLISTNAME_SEQ, ";");
            for (int i = 0; i < staticparamlistnameArry.length; i++) {
                for (int j = 0; j < actualparamlistnameArry.length; j++) {
                    if (staticparamlistnameArry[i].equalsIgnoreCase(actualparamlistnameArry[j])) {
                        int rowID = dsParamlistSeq.addRow();
                        dsParamlistSeq.setValue(rowID, "paramlistname", staticparamlistnameArry[i]);
                        dsParamlistSeq.setValue(rowID, "paramlistnameseq", actualparamlistnameSeqArry[i]);
                    }
                }
            }
        } else if ("MMSR".equalsIgnoreCase(unqPanelId)) {
            String staticparamlistnameArry[] = StringUtil.split(STATIC_MMSR_PARAMLISTNAME, ";");
            String actualparamlistnameSeqArry[] = StringUtil.split(STATIC_MMSR_PARAMLISTNAME_SEQ, ";");
            for (int i = 0; i < staticparamlistnameArry.length; i++) {
                for (int j = 0; j < actualparamlistnameArry.length; j++) {
                    if (staticparamlistnameArry[i].equalsIgnoreCase(actualparamlistnameArry[j])) {
                        int rowID = dsParamlistSeq.addRow();
                        dsParamlistSeq.setValue(rowID, "paramlistname", staticparamlistnameArry[i]);
                        dsParamlistSeq.setValue(rowID, "paramlistnameseq", actualparamlistnameSeqArry[i]);
                    }
                }
            }

        } else {
            String sql = "select stmp.u_testcodeid,stmp.indtestcodeid,t.testname from u_testcodepanelmap stmp, u_testcode t where" +
                    " t.u_testcodeid=stmp.indtestcodeid and" +
                    " stmp.u_testcodeid='" + unqPanelId + "'";
            DataSet dsPanelInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsPanelInfo != null && dsPanelInfo.size() > 0) {
                testname = dsPanelInfo.getColumnValues("testname", ";");
                return testname;
            }
        }
        String uniqInputParamlistname = Util.getUniqueList(inputparamlist, ";", true);
        if (dsParamlistSeq != null && dsParamlistSeq.size() > 0) {
            HashMap hm = new HashMap();
            hm.put("paramlistname", uniqInputParamlistname);
            DataSet dsParamListFilter = dsParamlistSeq.getFilteredDataSet(hm);
            String paramlistname = dsParamListFilter.getValue(0, "paramlistname", "");
            String paramlistnameseq = dsParamListFilter.getValue(0, "paramlistnameseq", "");
            int lengthActualParamlistnm = actualparamlistnameArry.length;
            int inputparamlistseq = Integer.parseInt(paramlistnameseq);
            for (int i = inputparamlistseq; i <= lengthActualParamlistnm; i++) {
                HashMap hmm = new HashMap();
                hmm.put("paramlistnameseq", String.valueOf(i));
                DataSet dsFilterParamName = dsParamlistSeq.getFilteredDataSet(hmm);
                testname = testname + ";" + dsFilterParamName.getValue(0, "paramlistname", "");
            }
        }
        if (!Util.isNull(testname)) {
            testname = testname.substring(1);
        }
        return testname;
    }


    public static final String INPUT_PROPERTY_SAMPLE_ID = "s_sampleid";
    public static final String INPUT_PROPERTY_EXTRACTION_ID = "u_extractionid";
    public static final String INPUT_PROPERTY_PARAMLIST_ID = "paramlistid";
    public static final String INPUT_PROPERTY_PARAM_ID = "paramid";
    public static final String INPUT_PROPERTY_ENTERDTEXT = "enteredtext";
}
