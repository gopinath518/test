package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;

/**
 * Created by rrmandal on 9/6/2016.
 */
public class EGELComplete extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid=properties.getProperty("batchid","");
        if(Util.isNull(batchid))
            throw new SapphireException("Batch id is not found.");
        String sql = "select molmethodlogy,u_testcodeid from u_molecularmethodlogy where u_testcodeid " +
                "in(select distinct testcodeid from u_batch_sample_detail where u_ngbatchid='"+batchid+"') and molmethodlogy not in('NGS','MICROARRAY')";
        DataSet dsMolMethodology= getQueryProcessor().getSqlDataSet(sql);

        if(dsMolMethodology!=null && dsMolMethodology.size()>0){

            String methodologies = dsMolMethodology.getColumnValues("molmethodlogy",";");
            String testcodesArr[]=null;
            String methodologiesArr[]=null;
            if(!Util.isNull(methodologies)) {
                methodologies = Util.getUniqueList(methodologies, ";", true);
                methodologiesArr= StringUtil.split(methodologies,";");
            }
            String testcodes = dsMolMethodology.getColumnValues("u_testcodeid",";");

            if(!Util.isNull(testcodes)) {
                testcodes = Util.getUniqueList(testcodes, ";", true);
                testcodesArr = StringUtil.split(testcodes,";");
            }

            PropertyList prop = new PropertyList();
            prop.setProperty("batchid",batchid);

//            if(testcodesArr!=null && testcodesArr.length>1){
//                getActionProcessor().processAction("CreateExoBatch","1",prop);
//            }
//
//            else

            if(methodologiesArr!=null){
                if(methodologiesArr.length==1) {
                    if ("SANGER".equalsIgnoreCase(methodologiesArr[0])) {
                        getActionProcessor().processAction("CreateExoBatch", "1", prop);
                    } else if ("FRAGMENT".equalsIgnoreCase(methodologiesArr[0])) {
                        prop.setProperty("orgbatchtatus","EGEL Complete");
                        getActionProcessor().processAction("CreateReportingBatch", "1", prop);
                    }
                }
                else if(methodologiesArr.length>1){
                    if(methodologies.indexOf("SANGER")>=0) {
                        String orgBatchID = properties.getProperty("batchid");
                        DataSet dsBatch = getQueryProcessor().getSqlDataSet("select batchname, batchtype from u_ngbatch where u_ngbatchid='" + orgBatchID + "'");

                        if (dsBatch == null || dsBatch.size() == 0)
                            throw new SapphireException("Information of the PCR batch is not found from the database");
                        // create new batch

                        PropertyList prop1 = new PropertyList();
                        prop1.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
                        prop1.setProperty("batchname", dsBatch.getString(0, "batchname", ""));
                        prop1.setProperty("batchmovestatus", "EGELComplete");
                        prop1.setProperty("origin", "ExoSap");
                        prop1.setProperty("batchstatusview", "ExoSap Pending");
                        prop1.setProperty("batchtype", "Molecular");
                        prop1.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop1);
                        String newBatch = prop1.getProperty(AddSDI.RETURN_NEWKEYID1, "");

                        if (!Util.isNull(newBatch)) {
                            prop1.clear();
                            prop1.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
                            prop1.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
                            prop1.setProperty("batchmovestatus", "Complete");
                            prop1.setProperty("batchcompletedts", "n");
                            prop1.setProperty("batchstatusview", "EGEL Complete");
                            prop1.setProperty("origin", "ExoSap");
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop1);

                            sql = "select filename from sdiattachment where keyid1='" + batchid + "'";
                            DataSet dsAttachment = getQueryProcessor().getSqlDataSet(sql);
                            if (dsAttachment != null && dsAttachment.size() > 0) {
                                String filename = dsAttachment.getValue(0, "filename", "");
                                if (!Util.isNull(filename)) {
                                    prop.clear();
                                    prop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "NGBatch");
                                    prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, newBatch);
                                    prop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filename);
                                    prop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filename).getName());
                                    prop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                                    getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, prop);
                                }
                            }
                        }
                    }
                    else if(methodologies.indexOf("FRAGMENT")>=0) {
                        prop.setProperty("orgbatchtatus","EGEL Complete");
                        getActionProcessor().processAction("CreateReportingBatch","1",prop);
                    }
                }
                else
                    throw new SapphireException("EGEL Complete can only be performed on the batch having specimen(s) associated with the " +
                            "testcode having one of the below Molecular Methodology(s):\nSANGER,FRAGMENT");

            }
            else
                throw new SapphireException("Molecular methodologies are not found for the testcode(s) "+dsMolMethodology.getColumnValues("u_testcodeid",","));
        }
        else{
            throw new SapphireException("No Molecular Methodology has been found for the testcodes associated " +
                    "with specimens for the batch "+batchid);
        }
    }
}
