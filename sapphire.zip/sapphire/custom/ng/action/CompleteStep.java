package sapphire.custom.ng.action;

import static sapphire.custom.ng.util.Util.isNull;

import java.util.ArrayList;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.cyto.MoveSampleToCyto;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

/**
 * Created by ajha on 4/26/2016.
 */
public class CompleteStep extends BaseAction {
    private String otherSampleId = "";
    private String cytoSampleid = "";
    private String flowSampleId = "";
    private String fishSampleId = "";
    private String multiomyxSampleId = "";

    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_TYPE = "type";
    private static final String DATASET_PROPERTY_METHODOLOGY = "methodology";
    private static final String DATASET_PROPERTY_TRAMSTOP = "tramstop";
    private static final String DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT = "custodialdepartmentid";
    private static final String DATASET_PROPERTY_IS_CUSTODIAN_CHANGED = "custodianchangeflag";
    private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";
    private static final String DATASET_PROPERTY_ROOTSAMPLEID = "rootsampleid";
    private static final String DATASET_PROPERTY_LVTESTNAME = "testname";

    public void processAction(PropertyList properties) throws SapphireException {
        String completestepbypass = properties.getProperty("completestepbypass", "N");
        String currentstep = properties.getProperty("currentstep");
        String nextstep = properties.getProperty("nextstep", "");
        //String steps = "Grossing";
        String sampleid = properties.getProperty("sampleid");
        String stepaction = properties.getProperty("stepaction");
        String completedby = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String department = properties.getProperty("destdeptid");
        if (!"Y".equalsIgnoreCase(completestepbypass)) {
            DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
            if (storageStaus != null && storageStaus.size() > 0) {
                DataSet dsDisplayMsg = new DataSet();
                dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
                dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
                for (int i = 0; i < storageStaus.size(); i++) {
                    int rowID = dsDisplayMsg.addRow();
                    dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                    dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
                }
                String errCodes = Util.getDisplayMessage(dsDisplayMsg);
                throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
            }
        }
        if ("QC Completed".equalsIgnoreCase(stepaction) && "FPQCComplete".equalsIgnoreCase(nextstep)) {
            if (Util.isNull(department))
                throw new SapphireException("Error: No department is selected");
            
            /* 17th Dec 2017 - Change by subhendu  Flow Change ++*/
            seperateSamplBasedOnMethodology(sampleid);
            if (!"".equalsIgnoreCase(flowSampleId))
                updateFlowStep(flowSampleId, department);
            /* 17th Dec 2017 - Change by subhendu  Flow Change --*/

            if (!"".equalsIgnoreCase(cytoSampleid))
                updateCytoStep(cytoSampleid.substring(1), department);

            if (!"".equalsIgnoreCase(otherSampleId)) {
                sampleid = otherSampleId.substring(1);
                sampleid = movementSamples(sampleid);
                if (!isNull(sampleid)) {
                    completeStep(currentstep, sampleid, completedby, department, stepaction);
                    if (nextstep.length() > 0){
                    	DataSet ds = this.getSampleStepData(sampleid, nextstep);
                    	if(ds != null && ds.getRowCount() > 0){
                    		updateStep(ds.getColumnValues("steps", ";"), ds.getColumnValues("sampleid", ";"));
                    	}
                    }
                }
            }
        } else {
            department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
            seperateSamplBasedOnMethodology(sampleid);
            if (!Util.isNull(multiomyxSampleId)) {
                if (multiomyxSampleId.startsWith(";"))
                    multiomyxSampleId = multiomyxSampleId.substring(1);
                DataSet dsPolicy = getPolicy();
                String tempSampleid = multiomyxSampleId;
                tempSampleid = Util.getUniqueList(tempSampleid, ";", true);
                routeMOSlides(tempSampleid, dsPolicy);
            }
            if (!Util.isNull(otherSampleId)) {
                if (otherSampleId.startsWith(";"))
                    otherSampleId = otherSampleId.substring(1);
                sampleid = otherSampleId;
                sampleid = Util.getUniqueList(sampleid, ";", true);
                sampleid = movementSamples(sampleid);
                if (!isNull(sampleid)) {
                    completeStep(currentstep, sampleid, completedby, department, stepaction);
                    if (nextstep.length() > 0)
                        updateStep(nextstep, sampleid);
                }
            }
            if (!Util.isNull(flowSampleId)) {
                if (flowSampleId.startsWith(";"))
                    flowSampleId = flowSampleId.substring(1);
                sampleid = flowSampleId;
                sampleid = Util.getUniqueList(sampleid, ";", true);
                sampleid = movementSamples(sampleid);
                if (!isNull(sampleid)) {
                    completeStep(currentstep, sampleid, completedby, department, stepaction);
                    if (nextstep.length() > 0)
                        updateStep(nextstep, sampleid);
                }
            } else if (!Util.isNull(cytoSampleid)) {
                if (cytoSampleid.startsWith(";"))
                    cytoSampleid = cytoSampleid.substring(1);
                sampleid = cytoSampleid;
                sampleid = Util.getUniqueList(sampleid, ";", true);
                sampleid = movementSamples(sampleid);
                if (!isNull(sampleid)) {
                    completeStep(currentstep, sampleid, completedby, department, stepaction);
                    if (nextstep.length() > 0)
                        updateStep(nextstep, sampleid);
                }
            } else if (!Util.isNull(fishSampleId)) {
                if (fishSampleId.startsWith(";"))
                    fishSampleId = fishSampleId.substring(1);
                sampleid = fishSampleId;
                sampleid = Util.getUniqueList(sampleid, ";", true);
                sampleid = movementSamples(sampleid);
                if (!isNull(sampleid)) {
                    completeStep(currentstep, sampleid, completedby, department, stepaction);
                    if (nextstep.length() > 0)
                        updateStep(nextstep, sampleid);
                }
            }

        }
        //throw new SapphireException("TEST");
    }

    /**
     * Description: The completeStep class is created to update the sample movement step in different class.
     *
     * @param steps
     * @param sampleid
     * @param completedby
     * @param stepaction
     * @throws SapphireException
     */
    private void completeStep(String steps, String sampleid, String completedby, String department, String stepaction) throws SapphireException {
        //TODO SKIP TO ADD ASSIGN DEPARTMENT FOR ACCESSION STATUS PAGE FOR 1.6.1 RELEASE
        String sql = Util.parseMessage(CommonSql.GET_UTYPE_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        sql = ApSql.GET_SETUP_COMPLETE_SLIDES;
        DataSet dsIHCSkipStepSlides = getQueryProcessor().getSqlDataSet(sql);
        DataSet dsIHCSlides = new DataSet();
        dsIHCSlides.addColumn("sampleid", DataSet.STRING);
        dsIHCSlides.addColumn("isroute", DataSet.STRING);
        HashMap hm = new HashMap();
        for (int i = 0; i < dsSampleInfo.size(); i++) {
            String u_type = dsSampleInfo.getValue(i, "u_type", "");
            String specimentype = dsSampleInfo.getValue(i, "specimentype", "");
            String sampleidd = dsSampleInfo.getValue(i, "s_sampleid", "");
            hm.clear();
            hm.put("methodology", "IHC");
            DataSet dsMethodologyFilter = dsSampleInfo.getFilteredDataSet(hm);

            hm.clear();
            hm.put("refvalueid", u_type);
            DataSet dsUTypeFilter = dsIHCSkipStepSlides.getFilteredDataSet(hm);

            hm.clear();
            hm.put("refvalueid", specimentype);
            DataSet dsSpecimenTypeFilter = dsIHCSkipStepSlides.getFilteredDataSet(hm);
            if (dsMethodologyFilter.size() > 0 && (dsUTypeFilter.size() > 0 || dsSpecimenTypeFilter.size() > 0)) {
                int rowID = dsIHCSlides.addRow();
                dsIHCSlides.setValue(rowID, "sampleid", sampleidd);
                dsIHCSlides.setValue(rowID, "isroute", "N");
            } else {
                int rowID = dsIHCSlides.addRow();
                dsIHCSlides.setValue(rowID, "sampleid", sampleidd);
                dsIHCSlides.setValue(rowID, "isroute", "Y");
            }
        }
        hm.clear();
        hm.put("isroute", "Y");
        DataSet dsOtherSampleFilter = dsIHCSlides.getFilteredDataSet(hm);
        if (dsOtherSampleFilter.size() > 0) {
            PropertyList props = new PropertyList();
            //int repeat = sampleid.split(";").length;
            int repeat = dsOtherSampleFilter.size();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            //props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsOtherSampleFilter.getColumnValues("sampleid", ";"));
            props.setProperty("u_currenttramstop", StringUtil.repeat(stepaction, repeat, ";"));
            props.setProperty("custodialuserid", StringUtil.repeat("", repeat, ";"));
            props.setProperty("custodialdepartmentid", StringUtil.repeat(department, repeat, ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Can't move next step");
                error += ae.getMessage();
                throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
            }
        }
    }

    private void updateStep(String steps, String sampleid) throws SapphireException {

        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty("keyid1", sampleid);
            prop.setProperty("u_currentmovementstep", steps);
            prop.setProperty("u_currenttramstop", steps);
            //prop.setProperty("u_microtomycompletedt", "n");//TODO NOT REQUIRED AS ACCESSION SLIDE(S) DOES NOT HAVE MICROTOMY COMPLETE DATE
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    private String movementSamples(String sampleids) throws SapphireException {

        String sql = "select unique(s.s_sampleid) as sampleids,s.u_type from s_sample s, U_SAMPLETESTCODEMAP stm ,u_testcode t " +
                "where s.s_sampleid in ('" + StringUtil.replaceAll(sampleids, ";", "','") + "')" +
                "and s.s_sampleid=stm.s_sampleid and stm.lvtestcodeid = t.u_testcodeid and ((t.METHODOLOGY = 'IHC' and " +
                "(s.u_type not in('U', 'CH', 'H', 'CU','CST','PC', 'NC') or s.u_type is null)) or t.METHODOLOGY <> 'IHC')";
        DataSet dsResults = getQueryProcessor().getSqlDataSet(sql);
        if (dsResults == null)
            throw new SapphireException("Error: unable to perform query in Datatbase: " + sql);
        if (dsResults.size() == 0) {
            return sampleids;
        } else {
            return dsResults.getColumnValues("sampleids", ";");
        }
    }

    private void seperateSamplBasedOnMethodology(String sampleid) throws SapphireException {
        String sql = Util.parseMessage(CommonSql.GET_SAMPLEID_TESTCODE_METHODOLOGY, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        if (dsSql == null)
            throw new SapphireException("Error: Unable to perform query in database\nSQL: " + sql);
        else if (dsSql.size() == 0)
            throw new SapphireException("Error: No active testcode is associated with samples\nSQL: Returned zero rows\n" + sql);

        //Seperate cyto, Flow and other type of sample 
        for (int i = 0; i < dsSql.size(); i++) {
            if (dsSql.getValue(i, "methodology").equalsIgnoreCase("Cytogenetics"))
                cytoSampleid = cytoSampleid + ";" + dsSql.getValue(i, "s_sampleid");
        
        	/*17th Dec 2017 - Change by subhendu  Flow Change ++*/
            else if (dsSql.getValue(i, "methodology").equalsIgnoreCase("Flow"))
                flowSampleId = flowSampleId + ";" + dsSql.getValue(i, "s_sampleid");
            /*17th Dec 2017 - Change by subhendu  Flow Change --*/

            else if (dsSql.getValue(i, "methodology").equalsIgnoreCase("Multiomyx"))
                multiomyxSampleId = multiomyxSampleId + ";" + dsSql.getValue(i, "s_sampleid");

            else if (dsSql.getValue(i, "methodology").equalsIgnoreCase("FISH"))
                fishSampleId = fishSampleId + ";" + dsSql.getValue(i, "s_sampleid");
            else
                otherSampleId = otherSampleId + ";" + dsSql.getValue(i, "s_sampleid") + ";";
        }
        flowSampleId = Util.getUniqueList(flowSampleId, ";", true);
    }
    /*17th Dec 2017 - Change by subhendu  Flow Change ++*/

    private void updateFlowStep(String flowSampleId, String department) throws SapphireException {
        PropertyList props = new PropertyList();
        String query = Util.parseMessage(FlowSql.GET_INTERNAL_ID_FROM_SOURCE_SAMPLE, StringUtil.replaceAll(flowSampleId, ";", "','"));
        try {
            DataSet ds = getQueryProcessor().getSqlDataSet(query);

            String[] flowSampleIdArr = StringUtil.split(flowSampleId, ";");
            String invalidSampleId = "";
            for (String sampleId : flowSampleIdArr) {
                HashMap<String, String> hm = new HashMap<>();
                hm.put("sourcesampleid", sampleId);
                DataSet filteredDS = ds.getFilteredDataSet(hm);
                if (filteredDS == null || (filteredDS != null && filteredDS.getRowCount() == 0)) {
                    invalidSampleId += "," + sampleId;
                }
            }
            if (!Util.isNull(invalidSampleId)) {
                invalidSampleId = invalidSampleId.substring(1);
                throw new SapphireException("\nInternal specimens of Flow has not yet been generated. "
                        + "\nPlease generate internal specimens of Flow for the below specimens and then proceed :: \n" + invalidSampleId);
            } else {
                //Edit Sample sdi
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty("keyid1", flowSampleId);
                props.setProperty("u_currentmovementstep", "SpecimenPickup");
                props.setProperty("u_flowsamplereceivedt", "n");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                //Edit Trackitem

                props.clear();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, flowSampleId);
                props.setProperty("u_currenttramstop", "SpecimenPickup");
                props.setProperty("custodialuserid", "(null)");
                props.setProperty("custodialdepartmentid", department);
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }

//            getActionProcessor().processAction(CreateFlowWorkFlowSample.ID, CreateFlowWorkFlowSample.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in specimen.\n");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    /*17th Dec 2017 - Change by subhendu  Flow Change --*/
    private void updateCytoStep(String sampleid, String department) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            //Edit Sample sdi
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty("keyid1", sampleid);
            props.setProperty("u_currentmovementstep", "CytoSetup");
            //props.setProperty("u_cytostatus", "Ready for Setup");
            props.setProperty("bypassorgsampleedit", "Y");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            //Edit Trackitem
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
            props.setProperty("u_currenttramstop", "CytoSetup");
            props.setProperty("custodialuserid", "(null)");
            props.setProperty("custodialdepartmentid", department);
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
        try {
            //Create cyto child sample
            props.clear();
            props.setProperty("sampleid", sampleid);
            props.setProperty("sampleprefix", "CG" + department.substring(0, 1));
            getActionProcessor().processAction("MoveSampleToCyto", MoveSampleToCyto.VERSION, props);
        } catch (ActionException ae) {
            throw new SapphireException("Unable to move samples to cyto - " + ae.getMessage());
        }
    }

    private DataSet getPolicy() throws SapphireException {
        DataSet dsPloicy = new DataSet();
        int incr = 0;
        dsPloicy.addColumn("type", DataSet.STRING);
        dsPloicy.addColumn("methodology", DataSet.STRING);
        dsPloicy.addColumn("tramstop", DataSet.STRING);
        dsPloicy.addColumn("currenttramstop", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("MicrotomyCompletePolicy", "MicrotomyComplete");
        PropertyListCollection plcRoutingrules = plMicroPolicy.getCollection("routingrules");
        for (int i = 0; i < plcRoutingrules.size(); i++) {
            incr = dsPloicy.addRow();
            PropertyListCollection plcConditions = plcRoutingrules.getPropertyList(i).getCollection("conditions");
            PropertyListCollection plcColumnvaluepair = plcConditions.getPropertyList(0).getCollection("columnvaluepair");
            for (int j = 0; j < plcColumnvaluepair.size(); j++) {
                String column = plcColumnvaluepair.getPropertyList(j).getProperty("column");
                String value = plcColumnvaluepair.getPropertyList(j).getProperty("value");
                if (column.equalsIgnoreCase("u_type")) {
                    dsPloicy.setValue(incr, "type", value);
                } else {
                    dsPloicy.setValue(incr, "methodology", value);
                }
            }
            String currentmovementstep = plcConditions.getPropertyList(0).getProperty("currentmovementstep");
            String currenttramstop = plcConditions.getPropertyList(0).getProperty("currenttram");
            dsPloicy.setValue(incr, "tramstop", currentmovementstep);
            dsPloicy.setValue(incr, "currenttramstop", currenttramstop);
        }
        return dsPloicy;
    }

    private void routeMOSlides(String sampleid1, DataSet dsPloicy) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sampleid1, ";", "','");

        String sqlType = "select s.s_sampleid,stm.methodology,s.u_type,stm.lvtestcodeid,s.u_rootsample,stm.testname,t.containertypeid  " +
                " from s_sample s,u_sampletestcodemap stm,trackitem t " +
                " where s.s_sampleid=stm.s_sampleid and t.linkkeyid1=s.s_sampleid and s.s_sampleid in ('" + sampleid + "') and stm.teststatus != 'Cancelled'";
        DataSet dsType = getQueryProcessor().getSqlDataSet(sqlType);
        if (dsType == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlType;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        /*if (dsType.size() == 0) {
            String errStr = getTranslationProcessor().translate("No test code is associated with the sample. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }*/
        if (dsType.size() > 0) {
            DataSet dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TYPE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_METHODOLOGY, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TRAMSTOP, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_ROOTSAMPLEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTNAME, DataSet.STRING);
            dsMain.addColumn("currenttramstop", DataSet.STRING);

            String moBlocks = "";
            String stainedSample ="";

            HashMap hm = new HashMap();
            int rowCnt = 0;
            for (int i = 0; i < dsType.size(); i++) {
                String sample = dsType.getValue(i, "s_sampleid", "");
                String type = dsType.getValue(i, "u_type", ""); // null will be work for Block to move HistoBlockRoom
                String methodology = dsType.getValue(i, "methodology", "");
                String lvtestcodeid = dsType.getValue(i, "lvtestcodeid", "");
                String rootsample = dsType.getValue(i, "u_rootsample", "");
                String testname = dsType.getValue(i, "testname", "");
                String containertype  = dsType.getValue(i, "containertypeid", "");
                if (dsMain.findRow(DATASET_PROPERTY_SAMPLEID, sample) < 0 && !Util.isNull(methodology) && "Multiomyx".equalsIgnoreCase(methodology) && !Util.isNull(type)) {
                    hm.clear();
                    hm.put("type", type);
                    hm.put("methodology", methodology);
                    DataSet dsfilter = dsPloicy.getFilteredDataSet(hm);
                    if (dsfilter != null && dsfilter.size() > 0) {
                        rowCnt = dsMain.addRow();
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_SAMPLEID, sample);
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_TYPE, dsfilter.getValue(0, "type", ""));
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_METHODOLOGY, dsfilter.getValue(0, "methodology", ""));
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_LVTESTCODEID, lvtestcodeid);
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_ROOTSAMPLEID, rootsample);
                        dsMain.setValue(rowCnt, DATASET_PROPERTY_LVTESTNAME, testname);
                        //If any step is not defined in microtomycompletePolicy then let them stay in Microtomy
                        if("H".equalsIgnoreCase(type) && "Stained Slide".equalsIgnoreCase(containertype)){
                            dsMain.setValue(rowCnt, DATASET_PROPERTY_TRAMSTOP, "StainCompleted");
                            dsMain.setValue(rowCnt, "currenttramstop", "StainCompleted");
                            stainedSample += ";"+sample;
                        }
                        else {
                            dsMain.setValue(rowCnt, DATASET_PROPERTY_TRAMSTOP, dsfilter.getValue(0, "tramstop", "Microtomy"));
                            dsMain.setValue(rowCnt, "currenttramstop", dsfilter.getValue(0, "currenttramstop", "Microtomy"));
                        }
                    }
                } else if (Util.isNull(type)) {
                    moBlocks += ";" + sample;
                }
            }
            if (dsMain != null && dsMain.size() > 0) {
                String defaultdepartment = connectionInfo.getDefaultDepartment();
                String site = StringUtil.split(defaultdepartment, "-")[0];

                for (int l = 0; l < dsMain.getRowCount(); l++) {
                    String typeOfSample = dsMain.getValue(l, DATASET_PROPERTY_TYPE, "");
                    String meth = dsMain.getValue(l, DATASET_PROPERTY_METHODOLOGY, "");
                    if ("Multiomyx".equalsIgnoreCase(meth)) {
                        if ("H".equalsIgnoreCase(typeOfSample) || "CH".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "AP");
                        } else if ("U".equalsIgnoreCase(typeOfSample) || "CU".equalsIgnoreCase(typeOfSample)|| "CST".equalsIgnoreCase(typeOfSample)) {
                            //dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "MOWetLab");
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        }
                        else if ("B".equalsIgnoreCase(typeOfSample)) {
                            dsMain.setValue(l, DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, site + "-" + "Accessioning");
                        }
                        dsMain.setValue(l, DATASET_PROPERTY_IS_CUSTODIAN_CHANGED, "Y");
                    }
                }

                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
                props.setProperty("u_currentmovementstep", dsMain.getColumnValues(DATASET_PROPERTY_TRAMSTOP, ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

                props.clear();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
                props.setProperty("custodialdepartmentid", dsMain.getColumnValues(DATASET_PROPERTY_FUTURE_CUSTODIAN_DEPT, ";"));
                props.setProperty("custodialuserid", StringUtil.repeat("(null)", dsMain.size(), ";"));
                props.setProperty("u_currenttramstop", dsMain.getColumnValues(DATASET_PROPERTY_TRAMSTOP, ";"));
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }
            if (!Util.isNull(moBlocks)) {
                if (moBlocks.startsWith(";"))
                    moBlocks = moBlocks.substring(1);
                moBlocks = Util.getUniqueList(moBlocks, ";", true);
                otherSampleId += ";" + moBlocks;
            }
            if(!Util.isNull(stainedSample)){
                if(stainedSample.startsWith(";"))
                    stainedSample = stainedSample.substring(1);
                    stainedSample = Util.getUniqueList(stainedSample, ";", true);
                    String stainedSampleAll = StringUtil.replaceAll(stainedSample, ";", "','");
                String sqldata = Util.parseMessage(MultiomyxSql.GET_STPDETAILS_MOSTAINEDSLIDE, stainedSampleAll);
                String sampleTestCMapId ="";
                HashMap hmmap = new HashMap();
                DataSet dsAlldata = getQueryProcessor().getSqlDataSet(sqldata);
                if(dsAlldata!= null && dsAlldata.size()>0 ){
                    dsAlldata.sort("s_sampleid");
                    ArrayList<DataSet> dsSampleArr = dsAlldata.getGroupedDataSets("s_sampleid");
                    if(dsSampleArr.size()>0){
                        for (int i = 0; i < dsSampleArr.size(); i++) {
                            DataSet dsSample = dsSampleArr.get(i);
                            if(dsSample != null && dsSample.size()>0){
                                hmmap.clear();
                                hmmap.put("stepname","QC");
                                DataSet dstemp = dsSample.getFilteredDataSet(hmmap);
                                String stepNm = dstemp.getValue(0,"stepno");
                                int stepno = Integer.parseInt(stepNm);
                                for(int k=0; k < dsSample.size(); k++){
                                    String currStepNo = dsSample.getValue(k,"stepno",null);
                                    int currStep = Integer.parseInt(currStepNo);
                                    String status = dsSample.getValue(k,"status",null);
                                    if( currStep < stepno && "Pending".equalsIgnoreCase(status)){
                                        sampleTestCMapId +=  ";"+ dsSample.getValue(k,"u_sampletestcodestpmapid",null) ;


                                    }

                                }




                            }
                        }
                    }
                    if(!Util.isNull(sampleTestCMapId)){
                        if(sampleTestCMapId.startsWith(";")){
                            sampleTestCMapId = sampleTestCMapId.substring(1);
                        }
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleTestCMapId);
                        pl.setProperty("status", "Completed");

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    }

                }



            }
        }
    }
    
    private DataSet getSampleStepData(String sampleid, String steps) {
		// TODO Auto-generated method stub
    	DataSet dsFinal = new DataSet();
    	dsFinal.addColumn("sampleid", DataSet.STRING);
    	dsFinal.addColumn("steps", DataSet.STRING);
		if(!Util.isNull(sampleid) && !Util.isNull(steps)){
			String[] samples = StringUtil.split(sampleid, ";");
			int len = samples.length;
			
			
			String query = Util.parseMessage(MolecularSql.GET_MOLSUBMETHODOLOGY_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
			DataSet ds = getQueryProcessor().getSqlDataSet(query);
			
			for(int i=0; i<len; i++){
				if(ds != null && ds.getRowCount() > 0){
					HashMap<String, String> hm = new HashMap<>();
					hm.put("s_sampleid", samples[i]);
					hm.put("molecularsubmethodology", "Biocartis");
					DataSet filteredDS = ds.getFilteredDataSet(hm);
					if(filteredDS != null && filteredDS.getRowCount() > 0){
						for(int j=0; j<filteredDS.getRowCount(); j++){
							int bcRow = dsFinal.addRow();
							dsFinal.setValue(bcRow, "sampleid", samples[j]);
							dsFinal.setValue(bcRow, "steps", "BioAssaySetup");
						}
					}else{
						int row = dsFinal.addRow();
						dsFinal.setValue(row, "sampleid", samples[i]);
						dsFinal.setValue(row, "steps", steps);
					}
				}else{
					int rowId = dsFinal.addRow();
					dsFinal.setValue(rowId, "sampleid", samples[i]);
					dsFinal.setValue(rowId, "steps", steps);
				}
			}
		}
		return dsFinal;
	}
}



