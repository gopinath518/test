package sapphire.custom.ng.action;


import com.labvantage.sapphire.actions.sms.CreateStorageUnit;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.*;
import sapphire.custom.ng.util.Constants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by mpandey on 4/28/2016.
 */

/**
 * Description: The CreateAndFileCassatte class is created to create child sample and cassettes .
 * and associates sample with cassette
 * 
 * input-
 * param1-sampleid
 * param2- no of cassette
 * throws SapphireException
 */
public class CreateAndFileCassatte extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
// Extracting values from propertylist(Coming from front end)
        //ActionProcessor ap = getActionProcessor();
        //QueryProcessor qp = getQueryProcessor();
        String cassetteid = null;
        String sampleid = properties.getProperty("sampleid");

        if(Util.isNull(sampleid)){
            String error = getTranslationProcessor().translate("SampleID can't be null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        String cassettecount = properties.getProperty("cassettecount");

        PropertyList pl = new PropertyList();
        pl.setProperty("sampleid", sampleid);
        getActionProcessor().processAction("CreateContainer", "1", pl, true);


       String sql = "select s.u_accessionid,s.u_clientspecimenid,s.sampletypeid,s.u_currentmovementstep,ti.containertypeid" +
               " from s_sample s,trackitem ti " +
               "where s.s_sampleid=ti.linkkeyid1 and   s_sampleid in ('" + sampleid + "') ";
        DataSet dssample = getQueryProcessor().getSqlDataSet(sql);

        if (dssample.size() < 0 || dssample.getString(0, "u_clientspecimenid", "").isEmpty()) {

            String error = getTranslationProcessor().translate("SampleID " + sampleid + " does not have a Clientspecimenid ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
        /* logic changes
        String casstte_sql = "select  * from u_cassette where u_cassetteid like ('" + dssample.getString(0, "u_clientspecimenid", "") + "%" + "') ";
        DataSet dscassette = getQueryProcessor().getSqlDataSet(casstte_sql);

        if (dscassette.size() > 0) {
            String error = getTranslationProcessor().translate("SampleID " + sampleid + " already have Cassettes ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }*/
        //added for checking casstteid already present or not.If present then new casstteid will be
        String casstte_sql = "select u_cassetteid cassette from u_cassette a where a.u_cassetteid " +
                "like ('" + dssample.getString(0, "u_clientspecimenid", "") + "%" + "')  " +
                "order by a.createdt  desc ";
        DataSet ds = getQueryProcessor().getSqlDataSet(casstte_sql);
        int cassettePresnt;
        if (ds == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (ds.size() ==0) {
            cassettePresnt=1;
        }else {
            String num=null;
            cassetteid=ds.getValue(0, "cassette");
            //String lastCassetteChar=cassetteid.substring(cassetteid.lastIndexOf("-")+1);
            String lastCassetteChar= String.valueOf(cassetteid.charAt(cassetteid.length()-1));
            Pattern p = Pattern.compile("[0-9]+");
            Matcher m = p.matcher(lastCassetteChar);
            if (m.find()){
                num=m.group();
            }
            cassettePresnt=Integer.parseInt(num);
            cassettePresnt=cassettePresnt+1;
        }

        String sampletypeid = dssample.getString(0, "sampletypeid", "");
        String accessionid = dssample.getString(0, "u_accessionid", "");
        String currentmovementstep = dssample.getString(0, "u_currentmovementstep", "");
        String clientspecimenid = dssample.getString(0, "u_clientspecimenid", "");
        String containertypeid = dssample.getString(0, "containertypeid", "");



        String newcassetteid = createCassette(cassettecount, clientspecimenid,cassettePresnt);
        addTrackItemCassette(newcassetteid);
        String storageunitid = CreateStorageUnit(newcassetteid);
        String newsampleid = createChildSample(sampleid, cassettecount,properties, sampletypeid, currentmovementstep, accessionid, newcassetteid);
        properties.setProperty("newsampleid", newsampleid+",Cassette id:"+newcassetteid);//added for opening maint page
        updateTrackItem(newsampleid, storageunitid, containertypeid, cassettecount);
        updateParentSample(sampleid);
       // addTestCode(sampleid, newsampleid);
        Util.copyTestCodeFromParent(newsampleid, getQueryProcessor(), getActionProcessor());
        generatePSVLabelFile(newsampleid);


    }

    /**
     * This function is use to get file location from
     * file location policies.
     * @return
     * @throws SapphireException
     */
    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "CassetteLabel");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }

        return fileLocation;
    }

    /**
     * This function is use to generate .txt file
     * for label printing of cassettes.
     * @param newsampleid
     * @Desc Use to craete .txt file to generate label for Cassette
     */
    private void generatePSVLabelFile(String newsampleid) throws SapphireException {
        String sql = "select s_sample.s_sampleid as sampleid, s_sample.U_CLIENTSPECIMENID as blockid, (sb.U_FIRSTNAME || ' ' || sb.U_LASTNAME) as patientname " +
                "from s_sample ,u_accession ac, s_subject sb where s_sample.s_sampleid in ('" + StringUtil.replaceAll(newsampleid, ";", "','") + "') and s_sample.U_ACCESSIONID=ac.U_ACCESSIONID and ac.PATIENTID=sb.S_SUBJECTID";
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsSampleInfo.size() > 0) {
            String PIPE_DELIMITER = "|";
            String NEW_LINE_SEPARATOR = "\n";

            String location = getFileLocation();
            String timestamp = new java.text.SimpleDateFormat("MMddyyyyhmmssa").format(new Date());
            String fileName = location + "\\" + "cassette" + timestamp + ".txt";

            try {

                File file = new File(fileName);

                // if file doesnt exists, then create it
                if (!file.exists()) {
                    file.createNewFile();
                }

                FileWriter fw = new FileWriter(file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);

                for (int i = 0; i < dsSampleInfo.size(); i++) {
                    bw.write(dsSampleInfo.getValue(i, "sampleid"));
                    bw.write(PIPE_DELIMITER);
                    bw.write(dsSampleInfo.getValue(i, "blockid"));
                    bw.write(PIPE_DELIMITER);
                    bw.write(dsSampleInfo.getValue(i, "patientname"));
                    bw.write(NEW_LINE_SEPARATOR);
                }
                bw.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * This function is use to copy down
     * test code from parent sample to newly created samples .
     * @param sampleid
     * @param newsampleid
     * @throws SapphireException
     */

    private void addTestCode(String sampleid, String newsampleid) throws SapphireException {
      //to do
        String tc_sql = "select lvtestcodeid,ispanel from u_sampletestcodemap where lvtestpanelid is null and ispanel is null and s_sampleid='" + sampleid + "'";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        String lvestcode = dstestcode.getColumnValues("lvtestcodeid", ";");
        String tp_sql = "select unique lvtestpanelid,ispanel from u_sampletestcodemap where lvtestpanelid is not null and s_sampleid='" + sampleid + "'";
        DataSet dstespanel = getQueryProcessor().getSqlDataSet(tp_sql);
        String[] samparr = StringUtil.split(newsampleid, ";");

        if (dstestcode.size() == 0 && dstespanel.size() == 0) {
            String error = getTranslationProcessor().translate("SampleID " + sampleid + " doesn't have any Test !");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

        for (String currentsamp : samparr) {
            for (int j = 0; j < dstestcode.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));

            }
        }

        for (String currentsamp : samparr) {
            for (int j = 0; j < dstespanel.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstespanel.getValue(j, "lvtestpanelid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstespanel.getValue(j, "ispanel", ""));

            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * This function is use to set sample status
     * and storage status of parent sample as "disposed".
     * @param sampleid
     * @throws SapphireException
     */

    private void updateParentSample(String sampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("storagestatus", "Disposed");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update request in sample");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,error);
        }
    }

    /**
     * This function is use to add a row in trackitem sdc ,
     * when ever a new cassette is created .
     * @param newcassetteid
     * @throws SapphireException
     */
    private void addTrackItemCassette(String newcassetteid) throws SapphireException {
        PropertyList addTIProps = new PropertyList();
        String[] tracknum = newcassetteid.split(";");
        try {

            addTIProps.setProperty(AddTrackItem.PROPERTY_SDCID, "Cassette");
            addTIProps.setProperty(AddTrackItem.PROPERTY_KEYID1, newcassetteid);
            addTIProps.setProperty("numoftrackitems", String.valueOf(tracknum.length));
            addTIProps.setProperty("ownerdepartmentid", connectionInfo.getDefaultDepartment());

            getActionProcessor().processAction(AddTrackItem.ID, AddTrackItem.VERSIONID, addTIProps);
        } catch (ActionException a) {
            String error = getTranslationProcessor().translate("Can't update trackeitem ");
            error += a.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,error);
        }

    }

    /**
     * This function is use to create multiple child samples
     * and update their client specimen id with respective cassette id .
     * @param sampleid
     * @param cassettecount
     * @param sampletypeid
     * @param currentmovementstep
     * @param accessionid
     * @param newcassetteid
     * @return
     * @throws SapphireException
     */
    private String createChildSample(String sampleid, String cassettecount,PropertyList finalprop,String accessionid,String currentmovementstep,String sampletypeid, String newcassetteid) throws SapphireException {

                PropertyList props = new PropertyList();
        String newkeyid1;
        props.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, sampleid);
        props.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, cassettecount);
        props.setProperty(MultiSampleChild.PROPERTY_CHILD_SAMPLETYPEID, sampletypeid);
        //   props.setProperty("sstudyid", "NeoClinical"); ///TODO Hadcoded need to remove later
        //   props.setProperty("u_currentmovementstep", currentmovementstep);
        //  props.setProperty("u_accessionid", accessionid);
        //props.setProperty("copydowncolumns", "sstudyid;u_currentmovementstep;u_accessionid");old
        props.setProperty("copydowncolumns", "sstudyid;u_currentmovementstep;u_accessionid;u_grossdesription;u_measurment;u_particular;u_color;u_decal;u_fragment;u_wrapped;u_grossingcomment;u_numofpieces");
        props.setProperty("custodialuserid", connectionInfo.getSysuserId());
        props.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());


        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, props);

            newkeyid1 = props.getProperty("newkeyid1", "");
            PropertyList propEditSDI = new PropertyList();
            propEditSDI.setProperty("sdcid", "Sample");
            propEditSDI.setProperty("keyid1", newkeyid1);
            propEditSDI.setProperty("u_clientspecimenid", newcassetteid);
            propEditSDI.setProperty("storagestatus", "In Circulation");
            propEditSDI.setProperty("confirmedby", connectionInfo.getSysuserId());
            propEditSDI.setProperty("confirmeddt", "N");
            propEditSDI.setProperty("u_measurment", finalprop.getProperty("measurement",""));
            propEditSDI.setProperty("u_particular", finalprop.getProperty("solid",""));
            //propEditSDI.setProperty("u_type", "CST");
            propEditSDI.setProperty("u_type", Constants.U_TYPE_CASSETTE);
            propEditSDI.setProperty("u_color", finalprop.getProperty("u_color",""));
            propEditSDI.setProperty("u_numofpieces", finalprop.getProperty("pieces",""));
            propEditSDI.setProperty("u_decal", finalprop.getProperty("u_decal",""));
            propEditSDI.setProperty("u_fragment", finalprop.getProperty("u_fragment",""));
            propEditSDI.setProperty("u_wrapped", finalprop.getProperty("u_wrapped",""));
            propEditSDI.setProperty("u_grossdesription", finalprop.getProperty("grossdescription",""));
            propEditSDI.setProperty("u_grossingcomment", finalprop.getProperty("u_grossingcomment",""));



            getActionProcessor().processAction("EditSDI", "1", propEditSDI);

        } catch (Exception e) {
            throw new SapphireException("Unable to create child sample  ");

        }

        return newkeyid1;

    }

    /**
     * This function is use to update currentstorageunitid and containertype
     * in trackitem for new sample id.
     * @param newsampleid
     * @param newcassetteid
     * @param containertypeid
     * @param cassettecount
     * @throws SapphireException
     */
    private void updateTrackItem(String newsampleid, String newcassetteid, String containertypeid, String cassettecount) throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        PropertyList editTIProps = new PropertyList();
        newsampleid = StringUtil.replaceAll(newsampleid, ";", "','");
        String sql = "select trackitemid from trackitem where linkkeyid1 in ('" + newsampleid + "') ";
        DataSet dssample = getQueryProcessor().getSqlDataSet(sql);
        if (dssample.size() > 0) {
            try {
                //editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                editTIProps.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, dssample.getColumnValues("trackitemid", ";"));
                editTIProps.setProperty("currentstorageunitid", newcassetteid);
                editTIProps.setProperty("custodialuserid", currentuser);//added
                editTIProps.setProperty("custodialdepartmentid",defaultdepartment);//added
                editTIProps.setProperty("containertypeid", StringUtil.repeat(containertypeid, Integer.parseInt(cassettecount), ";"));

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
            } catch (ActionException a) {
                a.printStackTrace();
                String error = getTranslationProcessor().translate("Can't update trackeitem ");
                error += a.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION,error);
            }
        }
    }

    /**
     * This function is use to create new storage unit for
     * sdcid "Cassette".
     * @param newcassetteid
     * @return
     * @throws SapphireException
     */
    private String CreateStorageUnit(String newcassetteid) throws SapphireException {
        PropertyList props = new PropertyList();
        String[] newkeyarr = StringUtil.split(newcassetteid, ";");
        String storageunitid = "";
        for (String newkeyid1 : newkeyarr) {
            props.clear();
            try {


                props.setProperty("propertytreeid", "No Layout");
                props.setProperty("linkpropnodeid", "No Layout|Cassette");
                props.setProperty("maxtiallowed", "undefined");
                props.setProperty("moveableflag", "Y");
                props.setProperty("linksdcid", "Cassette");
                props.setProperty("size", "1;0");
                props.setProperty("newkeyid1", newkeyid1);
                props.setProperty("nodeid", "Cassette");
                props.setProperty("spaceavailflag", "Y");
                props.setProperty("maxtiallowed", "-1");
                props.setProperty("createsu", "Y");

                getActionProcessor().processAction(CreateStorageUnit.ID, CreateStorageUnit.VERSIONID, props);
                storageunitid = storageunitid + ";" + props.getProperty("storageunitid");
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Can't create Cassette");
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION,error);
            }
        }
        storageunitid = storageunitid.substring(1, storageunitid.length());
        return storageunitid;
    }

    /**
     * This function is use to create new cassette sdi
     * in cassette sdc .
     * @param cassettecount
     * @param clientspecimenid
     * @return
     * @throws SapphireException
     */
    private String createCassette(String cassettecount, String clientspecimenid,int cassettePresnt) throws SapphireException {
        PropertyList props = new PropertyList();
        /*Old
        String keyid1 = clientspecimenid + "1";
        for (int i = 2; i <= Integer.parseInt(cassettecount); i++) {
            keyid1 = keyid1 + ";" + clientspecimenid + i;
        }*/
        String keyid1 = clientspecimenid + cassettePresnt;
        for (int i = cassettePresnt+1; i < Integer.parseInt(cassettecount)+cassettePresnt; i++) {
            keyid1 = keyid1 + ";" + clientspecimenid + i;
        }
        String newkeyid;
        try {
            props.setProperty(AddSDI.PROPERTY_SDCID, "Cassette");
            props.setProperty(AddSDI.PROPERTY_COPIES, cassettecount);
            props.setProperty("keyid1", keyid1);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            newkeyid = props.getProperty("newkeyid1");
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't create Cassette");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,error);
        }
        return newkeyid;
    }


}
