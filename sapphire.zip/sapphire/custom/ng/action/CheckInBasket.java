package sapphire.custom.ng.action;

/**
 * Created by mpandey on 5/6/2016.
 * Action updates currentstorage value for baskets.
 * Checkin basket into retort
 * Mandatory input - basketid,retortid
 */


import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CheckInBasket extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {

        String retortid = properties.getProperty("retortid");

        String basketid = properties.getProperty("basketid");
        String baskets = StringUtil.replaceAll(basketid, ";", "','");


        String sql = " select trackitemid, CURRENTSTORAGEUNITID from  TRACKITEM where   linkkeyid1 in('" + baskets + "') and linksdcid = 'Basket'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        // String CURRENTSTORAGEUNIT = ds.getColumnValues("CURRENTSTORAGEUNITID", ";");
        String trackitemid = ds.getColumnValues("trackitemid", ";");

        String r_sql = " select storageunitid " +
                "from storageunit where linkkeyid1 = '" + retortid + "' and linksdcid ='Retort'";
        DataSet dsretort = getQueryProcessor().getSqlDataSet(r_sql);
        String storageunitid = dsretort.getColumnValues("storageunitid", ";");
        updateCheckInStorage(storageunitid, trackitemid);
        updateSampleStep(basketid);
    }

    /**
     * This function updates current storage unit in trackitem
     * for linksdcid="Basket"
     * @param storageunitid
     * @param trackitemid
     * @throws SapphireException
     */
    private void updateCheckInStorage(String storageunitid, String trackitemid) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("currentstorageunitid", storageunitid);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }

    }

    /**
     * update next movement step of sample .
     * @param basketid
     * @throws SapphireException
     */
    private void updateSampleStep(String basketid) throws  SapphireException{
        String sql = "Select * from storageunit where linkkeyid1 in ('"+basketid+"')";
        DataSet dsStorageBasket = getQueryProcessor().getSqlDataSet(sql);
        String sqlTiCassette = "select * from trackitem where currentstorageunitid in ('"+dsStorageBasket.getColumnValues("storageunitid","','")+"')";
        DataSet dsTICassette = getQueryProcessor().getSqlDataSet(sqlTiCassette);
        String sqlStgCassette = "Select * from storageunit where linkkeyid1 in ('"+dsTICassette.getColumnValues("linkkeyid1","','")+"')";
        DataSet dsStorageCassette = getQueryProcessor().getSqlDataSet(sqlStgCassette);
        String sqlTiSample = "select * from trackitem where currentstorageunitid in ('"+dsStorageCassette.getColumnValues("storageunitid","','")+"')";
        DataSet dsTISample = getQueryProcessor().getSqlDataSet(sqlTiSample);
        String sampleid = dsTISample.getColumnValues("linkkeyid1",";");

        PropertyList plCompleteStep = new PropertyList();
        plCompleteStep.setProperty("currentstep","Grossing");
        plCompleteStep.setProperty("nextstep","Processing");
        plCompleteStep.setProperty("sampleid",sampleid);
        getActionProcessor().processAction("CompleteStep","1",plCompleteStep);
    }


}
