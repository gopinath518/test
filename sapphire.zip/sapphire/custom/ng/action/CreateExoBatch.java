package sapphire.custom.ng.action;


import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by dgupta on 7/6/2016.
 */
public class CreateExoBatch extends BaseAction {

    private String DEFAULT_COPY_DOWN = "sampletypeid;u_accessionid;u_bodysite;u_sampleinformation;u_clientspecimenid;sstudyid;u_extractionid;u_currentmovementstep";

    /*
    *   OOB method override for Egel Exobach createion
    * */
    public void processAction(PropertyList properties) throws SapphireException {
        String orgBatchID = properties.getProperty("batchid");


        DataSet dsBatch = getQueryProcessor().getSqlDataSet( Util.parseMessage(MolecularSql.EXO_BATCH_ORGBATCH_SQL, orgBatchID ));
        DataSet dsSample  = getQueryProcessor().getSqlDataSet(Util.parseMessage(MolecularSql.EXO_BATCH_SAMPLE_SQL, orgBatchID)) ;
    // create new batch
        PropertyList newBatchProp = new PropertyList();
        newBatchProp.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        newBatchProp.setProperty("batchmovestatus", "EGELComplete");
        newBatchProp.setProperty("origin", "ExoSap");
        newBatchProp.setProperty("batchtype", dsBatch.getValue(0,"batchtype",""));
        newBatchProp.setProperty("batchname", dsBatch.getString(0, "batchname", ""));
        newBatchProp.setProperty("batchstatusview", "ExoSap Pending");
        newBatchProp.setProperty("batchtype", "Molecular");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, newBatchProp);
    // add old batch reagents and control to new batch
        String newBatchid = newBatchProp.getProperty("newkeyid1");



        DataSet dsAttachment = getQueryProcessor().getSqlDataSet(Util.parseMessage(MolecularSql.EXO_BATCH_ORGBATCH_FILE_SQL,  orgBatchID));
        if (dsAttachment != null && dsAttachment.size() > 0) {
            String filename = dsAttachment.getValue(0, "filename", "");
            if (!Util.isNull(filename)) {
                //load to plate and create new plate
                PropertyList plBatchPlate = new PropertyList();
                plBatchPlate.setProperty("batchid", newBatchid);
                plBatchPlate.setProperty("path", filename);
                plBatchPlate.setProperty("associatereagent", "N");
                plBatchPlate.setProperty("copyfile", "Y");
                getActionProcessor().processAction("CreateMolecularBatch", "1", plBatchPlate);
            }
            else {
                throw new SapphireException("Plate Map is not found for the batch "+dsBatch.getString(0, "batchname", "")+".");
            }
        }
        else{
            throw new SapphireException("Plate Map is not found for the batch "+dsBatch.getString(0, "batchname", "")+"." +
                    "\nReason: The query "+ Util.parseMessage(MolecularSql.EXO_BATCH_ORGBATCH_SQL,  orgBatchID) +" did not return any value.");
        }


        deleteRegInfo(newBatchid);

        //Edit batchmovementstatus for old batch
        PropertyList oldBatchProp = new PropertyList();
        oldBatchProp.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
        oldBatchProp.setProperty(EditSDI.PROPERTY_KEYID1, orgBatchID);
        oldBatchProp.setProperty("batchmovestatus", "Complete");
        oldBatchProp.setProperty("batchstatusview", "EGEL Complete");
        oldBatchProp.setProperty("batchcompletedts", "n");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, oldBatchProp);

    }


    /*
    *   This method delete reagent info from the new batch created
    *
    *   @paramm   newBatch  new batch id as string
    * */
    private void deleteRegInfo(String newBatch)throws SapphireException{
        if(!Util.isNull(newBatch)) {

            DataSet dsRegInfo = getQueryProcessor().getSqlDataSet(Util.parseMessage(MolecularSql.EXO_BATCH_NEWBATCH_DELREGINFO,  StringUtil.replaceAll(newBatch,";","','")));
            if(dsRegInfo!=null && dsRegInfo.size()>0) {
                dsRegInfo.sort("u_ngbatchid");
                ArrayList<DataSet> dsRegInfoArr = dsRegInfo.getGroupedDataSets("u_ngbatchid");
                if(dsRegInfoArr!=null && dsRegInfoArr.size()>0) {
                    PropertyList prop = new PropertyList();
                    for(int i=0;i<dsRegInfoArr.size();i++) {
                        DataSet tempDS = dsRegInfoArr.get(i);
                        if(tempDS!=null  && tempDS.size()>0) {
                            String keyid1= tempDS.getValue(0,"u_ngbatchid","");
                            if(!Util.isNull(keyid1)) {
                                prop.clear();
                                prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
                                prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, keyid1);
                                prop.setProperty("analyte", tempDS.getColumnValues("analyte", ";"));
                                prop.setProperty("reagentid", tempDS.getColumnValues("reagentid", ";"));
                                prop.setProperty("testcodeid", tempDS.getColumnValues("testcodeid", ";"));
                                prop.setProperty("direction", tempDS.getColumnValues("direction", ";"));
                                prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatcg_reagent_detail_link");

                                getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, prop);
                            }
                        }
                    }
                }
            }
        }
    }


}
