package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by rrmandal on 9/6/2016.
 */
public class PCRComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid", "");
        String isloadingbatch = properties.getProperty("isloadingbatch", "N");
        String parentbatchmovestatus = properties.getProperty("parentbatchmovestatus");
        String childbatchmovestatus = properties.getProperty("childbatchmovestatus");
        String parentbatchstatusview = properties.getProperty("parentbatchstatusview");
        String childbatchstatusview = properties.getProperty("childbatchstatusview");
        String origin = properties.getProperty("origin");
        if (Util.isNull(batchid))
            throw new SapphireException("Batch id is not found.");
        String sql = "select molmethodlogy,u_testcodeid from u_molecularmethodlogy where u_testcodeid " +
                "in(select distinct testcodeid from u_batch_sample_detail where u_ngbatchid='" + batchid + "') and molmethodlogy not in('NGS','MICROARRAY')";
        DataSet dsMolMethodology = getQueryProcessor().getSqlDataSet(sql);
        if (dsMolMethodology != null && dsMolMethodology.size() > 0) {
            if (dsMolMethodology.size() == 1) {
                String methodology = dsMolMethodology.getValue(0, "molmethodlogy", "");
                if (Util.isNull(methodology))
                    throw new SapphireException("No Molecular Methodology has been found for " +
                            "the testcode " + dsMolMethodology.getValue(0, "u_testcodeid", ""));
                PropertyList prop = new PropertyList();
                prop.setProperty("batchid", batchid);
                if ("REALTIME".equalsIgnoreCase(methodology)) {
                    prop.setProperty("orgbatchtatus", "PCR Complete");
                    getActionProcessor().processAction("CreateReportingBatch", "1", prop);
                } else {
                    prop.setProperty("parentbatchmovestatus", parentbatchmovestatus);
                    prop.setProperty("childbatchmovestatus", childbatchmovestatus);
                    prop.setProperty("parentbatchstatusview", parentbatchstatusview);
                    prop.setProperty("childbatchstatusview", childbatchstatusview);
                    prop.setProperty("origin", origin);
                    try {
                        getActionProcessor().processAction("CreateNGSLoadingBatch", "1", prop);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to create Loading batch." + ex.getMessage());
                    }
                    /*if ("N".equalsIgnoreCase(isloadingbatch))
                        getActionProcessor().processAction("CreateEGELBatch", "1", prop);
                    else if ("Y".equalsIgnoreCase(isloadingbatch))
                        getActionProcessor().processAction("CreateNGSLoadingBatch", "1", prop);*/
                }
            } else if (dsMolMethodology.size() > 1) {
                String methodologies = dsMolMethodology.getColumnValues("molmethodlogy", ";");
                methodologies = Util.getUniqueList(methodologies, ";", true);
                String methodologiesArr[] = null;
                String testcodesArr[] = null;
                if (!Util.isNull(methodologies)) {
                    methodologiesArr = StringUtil.split(methodologies, ";");
                }
                String testcodes = dsMolMethodology.getColumnValues("u_testcodeid", ";");
                testcodes = Util.getUniqueList(testcodes, ";", true);
                if (!Util.isNull(testcodes)) {
                    testcodesArr = StringUtil.split(testcodes, ";");
                }

                if (methodologiesArr != null && methodologiesArr.length == 1) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty("batchid", batchid);
                    if ("REALTIME".equalsIgnoreCase(methodologiesArr[0])) {
                        prop.setProperty("orgbatchtatus", "PCR Complete");
                        getActionProcessor().processAction("CreateReportingBatch", "1", prop);
                    } else {
                        getActionProcessor().processAction("CreateEGELBatch", "1", prop);
                    }
                }

//                else if(testcodesArr!=null && testcodesArr.length>1){
//                    if(methodologiesArr!=null){
//                        if(methodologiesArr.length>1 || !"SANGER".equalsIgnoreCase(methodologiesArr[0]))
//                            throw new SapphireException("Multi test can only be performed having the molecular methodology SANGER");
//
//                        PropertyList prop = new PropertyList();
//                        prop.setProperty("batchid",batchid);
//                        getActionProcessor().processAction("CreateEGELBatch","1",prop);
//                    }
//                }

                else if (methodologiesArr != null && methodologiesArr.length > 1) {

                    if (methodologies.indexOf("SANGER") >= 0) {
                        PropertyList prop = new PropertyList();
                        prop.setProperty("batchid", batchid);
                        getActionProcessor().processAction("CreateEGELBatch", "1", prop);
                    } else if (methodologies.indexOf("FRAGMENT") >= 0) {//If Only fragment, then only batch will be created and other detailes will not be copied down as they need to modify the excel to segregate fragment and realtime and load it to egel again
                        String orgBatchID = properties.getProperty("batchid");
                        DataSet dsBatch = getQueryProcessor().getSqlDataSet("select batchname, batchtype from u_ngbatch where u_ngbatchid='" + orgBatchID + "'");

                        if (dsBatch == null || dsBatch.size() == 0)
                            throw new SapphireException("Information of the PCR batch is not found from the database");
                        // create new batch

                        PropertyList prop = new PropertyList();
                        prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
                        prop.setProperty("batchname", dsBatch.getString(0, "batchname", ""));
                        prop.setProperty("batchmovestatus", "NormalComplete");
                        prop.setProperty("origin", "EGEL");
                        prop.setProperty("batchstatusview", "EGEL Pending");
                        prop.setProperty("batchtype", "Molecular");
                        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
                        String newBatch = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");

                        if (!Util.isNull(newBatch)) {
                            prop.clear();
                            prop.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
                            prop.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
                            prop.setProperty("batchmovestatus", "Complete");
                            prop.setProperty("batchstatusview", "PCR Complete");
                            prop.setProperty("batchcompletedts", "n");
                            prop.setProperty("origin", "EGEL");
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                        }
                    }

                }
            }
            updateElutionVolume(batchid);
            /***************TODO RELEASE 1.6.1******************/
            populatePCRBatchCOmpleteDt(batchid);
        } else {
            throw new SapphireException("No Molecular Methodology has been found for the testcodes associated " +
                    "with specimens for the batch " + batchid);
        }
        //throw new SapphireException("test");
    }

    private void updateElutionVolume(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLE_FOR_PCR_BY_BATCHID, batchid);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSample != null && dsBatchSample.size() > 0) {
            if (!dsBatchSample.isValidColumn("elutionblncqty"))
                dsBatchSample.addColumn("elutionblncqty", DataSet.STRING);
            for (int i = 0; i < dsBatchSample.size(); i++) {
                String elutionqty = dsBatchSample.getValue(i, "elutionqty", "0.0");
                String diluqtycurrent = dsBatchSample.getValue(i, "diluqtycurrent", "0.0");
                double blnsqtyelu = Double.parseDouble(elutionqty) - Double.parseDouble(diluqtycurrent);
                blnsqtyelu = Util.roundAvoid(blnsqtyelu);
                if (Double.isInfinite(blnsqtyelu))
                    blnsqtyelu = 0.0;
                else if (blnsqtyelu < 0)
                    blnsqtyelu = 0.0;

                dsBatchSample.setValue(i, "elutionblncqty", String.valueOf(blnsqtyelu));
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsBatchSample.getColumnValues("elutiontube", ";"));
            prop.setProperty("qtycurrent", dsBatchSample.getColumnValues("elutionblncqty", ";"));
            try {
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update Elution volume." + ex.getMessage());
            }
        }
    }

    /***
     * @Desc: Populate PCR Batch complete date for Testing Date Analyte if present.
     * @param batchid - Input batch id
     */
    private void populatePCRBatchCOmpleteDt(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLE_FOR_PCR_BY_BATCHID, batchid);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSample.size() > 0) {
            String elutiontubes = dsBatchSample.getColumnValues("elutiontube", ";");
            String dilutiontube = dsBatchSample.getColumnValues("dilutiontube", ";");
            String extractionid = dsBatchSample.getColumnValues("u_extractionid", ";");
            if (!Util.isNull(dilutiontube)) {
                elutiontubes = elutiontubes + ";" + dilutiontube;
            }
            sql = Util.parseMessage(MolecularSql.GET_SDIDATA_TESTINGDT_INFO_BY_SAMPLE_MOLECULAR, StringUtil.replaceAll(elutiontubes, ";", "','"));
            DataSet dsTesttingDtInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTesttingDtInfo == null || dsTesttingDtInfo.size() == 0) {
                return;
            }
            if (dsTesttingDtInfo != null && dsTesttingDtInfo.size() > 0) {
                //GET CURRENT DATE
                SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
                Date date = new Date();
                String crrntdt = formatter.format(date);
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsTesttingDtInfo.getColumnValues("s_sampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsTesttingDtInfo.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsTesttingDtInfo.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsTesttingDtInfo.getColumnValues("paramid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsTesttingDtInfo.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsTesttingDtInfo.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsTesttingDtInfo.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsTesttingDtInfo.getColumnValues("dataset", ";"));
                props.setProperty("enteredtext", StringUtil.repeat(crrntdt.toUpperCase(), dsTesttingDtInfo.size(), ";"));
                props.setProperty("displayvalue", StringUtil.repeat(crrntdt.toUpperCase(), dsTesttingDtInfo.size(), ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("Testing date EnterDataItem not performed." + e.getMessage());
                }
            }
            //POPULATE REPEAT DATA
            populateRepeatOpsRequest(batchid, extractionid);
        }

    }

    private void populateRepeatOpsRequest(String batchid, String extractionid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_REPEAT_REQ_MOLECULAR, StringUtil.replaceAll(extractionid, ";", "','"));
        DataSet dsRepeatOps = getQueryProcessor().getSqlDataSet(sql);
        if (dsRepeatOps == null || dsRepeatOps.size() == 0) {
            markedInitialOrRepeatMolecular(batchid, "N");
        }
        if (dsRepeatOps != null && dsRepeatOps.size() > 0) {
            String sampleids = dsRepeatOps.getColumnValues("s_sampleid", ";");
            sql = Util.parseMessage(MolecularSql.GET_SDIDATA_INFO_BY_SAMPLE_MOLECULAR, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsTesttingDtInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTesttingDtInfo == null || dsTesttingDtInfo.size() == 0) {
                return;
            }
            if (dsTesttingDtInfo != null && dsTesttingDtInfo.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsTesttingDtInfo.getColumnValues("s_sampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsTesttingDtInfo.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsTesttingDtInfo.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsTesttingDtInfo.getColumnValues("paramid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsTesttingDtInfo.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsTesttingDtInfo.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsTesttingDtInfo.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsTesttingDtInfo.getColumnValues("dataset", ";"));
                props.setProperty("enteredtext", StringUtil.repeat("Repeat", dsTesttingDtInfo.size(), ";"));
                props.setProperty("displayvalue", StringUtil.repeat("Repeat", dsTesttingDtInfo.size(), ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("Initial Or Repeat EnterDataItem not performed." + e.getMessage());
                }
            }
            //TODO REASON FOR REPEAT WILL NOT POPULATE AS IT IS MANUAL INPUT
            /*sql = Util.parseMessage(MolecularSql.GET_SDIDATA_INFO_BY_RE_SAMPLE_MOLECULAR, StringUtil.replaceAll(sampleids, ";", "','"));
            DataSet dsResnFrRpt = getQueryProcessor().getSqlDataSet(sql);
            if (dsResnFrRpt.size() > 0) {
                HashMap hm = new HashMap();
                for (int i = 0; i < dsResnFrRpt.size(); i++) {
                    hm.clear();
                    hm.put("s_sampleid", dsResnFrRpt.getValue(i, "s_sampleid", ""));
                    DataSet dsRsnFIlter = dsRepeatOps.getFilteredDataSet(hm);
                    if (dsRsnFIlter.size() > 0) {
                        dsResnFrRpt.setValue(i, "enteredtext", dsRsnFIlter.getValue(0, "notes", ""));
                        dsResnFrRpt.setValue(i, "displayvalue", dsRsnFIlter.getValue(0, "notes", ""));
                    }
                }
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsResnFrRpt.getColumnValues("s_sampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsResnFrRpt.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsResnFrRpt.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsResnFrRpt.getColumnValues("paramid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsResnFrRpt.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsResnFrRpt.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsResnFrRpt.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsResnFrRpt.getColumnValues("dataset", ";"));
                props.setProperty("enteredtext", dsResnFrRpt.getColumnValues("enteredtext", ";"));
                props.setProperty("displayvalue", dsResnFrRpt.getColumnValues("displayvalue", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("Initial Or Repeat EnterDataItem not performed." + e.getMessage());
                }
            }*/
        }
    }

    /****
     * @Desc: This function is used to mark the slide as Initial or Repeat for Molecular.
     * @throws SapphireException
     */
    private void markedInitialOrRepeatMolecular(String batchid, String ismolrepeatflag) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_SAMPLE_FOR_PCR_BY_BATCHID, batchid);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSample.size() > 0) {
            String elutiontubes = dsBatchSample.getColumnValues("elutiontube", ";");
            String dilutiontube = dsBatchSample.getColumnValues("dilutiontube", ";");
            String extractionid = dsBatchSample.getColumnValues("u_extractionid", ";");
            if (!Util.isNull(dilutiontube)) {
                elutiontubes = elutiontubes + ";" + dilutiontube;
            }
            sql = Util.parseMessage(MolecularSql.GET_SDIDATA_INFO_BY_SAMPLE_MOLECULAR, StringUtil.replaceAll(elutiontubes, ";", "','"));
            DataSet dsSampleInfoAll = getQueryProcessor().getSqlDataSet(sql);
            if (dsSampleInfoAll == null || dsSampleInfoAll.size() == 0) {
                return;
            }
            if (dsSampleInfoAll != null && dsSampleInfoAll.size() > 0) {
                if (!dsSampleInfoAll.isValidColumn("molrepeatflag")) {
                    dsSampleInfoAll.addColumn("molrepeatflag", DataSet.STRING);
                }
                for (int i = 0; i < dsSampleInfoAll.size(); i++) {
                    if ("Y".equalsIgnoreCase(ismolrepeatflag)) {
                        dsSampleInfoAll.setValue(i, "molrepeatflag", "Repeat");
                    } else {
                        dsSampleInfoAll.setValue(i, "molrepeatflag", "Initial");
                    }
                }
                //ENTERED DATA
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSampleInfoAll.getColumnValues("s_sampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSampleInfoAll.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSampleInfoAll.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSampleInfoAll.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSampleInfoAll.getColumnValues("molrepeatflag", ";"));
                props.setProperty("displayvalue", dsSampleInfoAll.getColumnValues("molrepeatflag", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSampleInfoAll.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSampleInfoAll.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSampleInfoAll.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSampleInfoAll.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("Molecular EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }

}
