package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by dmondal on 11/8/2016.
 * Description : This action will remove items from box.
 */
public class RemoveFromBox extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String boxid = properties.getProperty("boxid");
        if (Util.isNull(boxid)) {
            String error = getTranslationProcessor().translate("Please select checkbox first to empty the box.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        DataSet dsBoxType = checkBoxtype(boxid);
        DataSet dsUnsorted = getUnsortedBoxList(dsBoxType);
        DataSet dsSorted=getSortedBoxList(dsBoxType);
        removeFromBox(dsUnsorted,dsSorted);
    }

    /**
     * Description : This method will combine two dataset and calling updateTrackItemSdc method for updating
     * @param dsUnsorted
     * @param dsSorted
     * @throws SapphireException
     */
    private void removeFromBox(DataSet dsUnsorted, DataSet dsSorted) throws SapphireException {
        DataSet dsMain = new DataSet();
        dsMain.addColumn("trackitemid", DataSet.STRING);
        dsMain.addColumn("currentstorageunitid", DataSet.STRING);
        dsMain.addColumn("linkkeyid1", DataSet.STRING);
        int incr = 0;
        if (dsUnsorted.size() > 0) {
            for (int i = 0; i < dsUnsorted.size(); i++) {
                incr = dsMain.addRow();
                dsMain.setValue(incr, "trackitemid", dsUnsorted.getValue(i, "trackitemid", ""));
                dsMain.setValue(incr, "currentstorageunitid", dsUnsorted.getValue(i, "currentstorageunitid", ""));
                dsMain.setValue(incr, "linkkeyid1", dsUnsorted.getValue(i, "linkkeyid1", ""));
            }
        }
        if (dsSorted.size() > 0) {
            for (int i = 0; i < dsSorted.size(); i++) {
                incr = dsMain.addRow();
                dsMain.setValue(incr, "trackitemid", dsSorted.getValue(i, "trackitemid", ""));
                dsMain.setValue(incr, "currentstorageunitid", dsSorted.getValue(i, "currentstorageunitid", ""));
                dsMain.setValue(incr, "linkkeyid1", dsSorted.getValue(i, "linkkeyid1", ""));
            }
        }

        updateTrackItemSdc(dsMain);

    }

    /**
     * Description : This will update currentstorageunitid to null for remove items from batch.
     * @param ds
     * @throws SapphireException
     */
    private void updateTrackItemSdc(DataSet ds) throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();

        PropertyList editTIProps = new PropertyList();
        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "TrackItemSDC");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("trackitemid", ";"));
        editTIProps.setProperty("custodialuserid", StringUtil.repeat(currentuser, ds.size(), ";"));
        editTIProps.setProperty("custodialdepartmentid", StringUtil.repeat(defaultdepartment, ds.size(), ";"));
        editTIProps.setProperty("currentstorageunitid", StringUtil.repeat("(null)", ds.size(), ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

    }

    /**
     * Description : This will search only boxtype,it may be sorted ,unsorted .
     * @param boxids
     * @return
     * @throws SapphireException
     */
    private DataSet checkBoxtype(String boxids) throws SapphireException {
        String boxid = StringUtil.replaceAll(boxids, ";", "','");
        String sqlboxType = "select s_boxid,boxtype from  s_box where s_boxid in ('" + boxid + "') ";
        DataSet dsBoxType = getQueryProcessor().getSqlDataSet(sqlboxType);
        if (dsBoxType == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlboxType;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsBoxType.size() == 0) {
            String errStr = getTranslationProcessor().translate("Boxid not found.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        return dsBoxType;
    }

    /**
     * Decription : This method will search selected box is unsorted or not.
     * @param dsBoxType
     * @return
     * @throws SapphireException
     */
    private DataSet getUnsortedBoxList(DataSet dsBoxType) throws SapphireException {

        HashMap<String, String> hm = new HashMap<String, String>();
        hm.put("boxtype", "Unsorted");
        DataSet dsUnSorted = dsBoxType.getFilteredDataSet(hm);
        DataSet dsunsortedBox =new DataSet();
        if (dsUnSorted.size() > 0) {
            String unsorted = dsUnSorted.getColumnValues("s_boxid", ";");
            String unsortedBoxid = StringUtil.replaceAll(unsorted, ";", "','");
            String sqlboxid = "select t.currentstorageunitid,t.trackitemid,t.linkkeyid1 from trackitem t,s_sample s where s.s_sampleid=t.linkkeyid1 and t.currentstorageunitid in " +
                    " (select storageunitid from storageunit where linkkeyid1 in ('" + unsortedBoxid + "')) ";
            dsunsortedBox = getQueryProcessor().getSqlDataSet(sqlboxid);
            if (dsunsortedBox == null) {
                String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
                errStr += "\n Query failed: " + sqlboxid;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            if (dsunsortedBox.size() == 0) {
                String errStr = getTranslationProcessor().translate("Selected Box already empty.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }

        return dsunsortedBox;
    }

    /**
     * Description : This method will search selected box is sorted or not.
     * @param dsBoxType
     * @return
     * @throws SapphireException
     */
    private DataSet getSortedBoxList(DataSet dsBoxType) throws SapphireException {

        HashMap<String, String> hm = new HashMap<String, String>();
        hm.put("boxtype", "Sorted");
        DataSet dsSorted = dsBoxType.getFilteredDataSet(hm);
        DataSet dssortedBox =new DataSet();
        if (dsSorted.size() > 0) {
            String sorted = dsSorted.getColumnValues("s_boxid", ";");
            String sortedBoxid = StringUtil.replaceAll(sorted, ";", "','");
            String sqlsortedBoxid = "select currentstorageunitid,trackitemid,linkkeyid1 from trackitem t,s_sample s where s.s_sampleid=t.linkkeyid1 and t.currentstorageunitid in " +
                    "(select storageunitid from storageunit where storageunit.parentid in " +
                    "(select storageunitid from storageunit where linkkeyid1 in('" + sortedBoxid + "'))) ";

            dssortedBox = getQueryProcessor().getSqlDataSet(sqlsortedBoxid);
            if (dssortedBox == null) {
                String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
                errStr += "\n Query failed: " + sqlsortedBoxid;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
            if (dssortedBox.size() == 0) {
                String errStr = getTranslationProcessor().translate("Selected Box already empty.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }
        return dssortedBox;
    }
}
