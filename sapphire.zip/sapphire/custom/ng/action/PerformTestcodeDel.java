package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Constants;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

public class PerformTestcodeDel extends BaseAction {

    public static final String DATASET_COLUMN_TYPE = "u_type";
    public static final String DATASET_COLUMN_TYPE_UPDATED = "iftypeupdated";
    public static final String TRANSPORT_TYPE_UNSTAINED_SLIDE = "Unstained Slide";
    public static final String TRANSPORT_TYPE_STAINED_SLIDE = "Stained Slide";
    public static final String TRANSPORT_TYPE_HNE_SLIDE = "H&E Slide";
    public static final String TRANSPORT_TYPE_CLIENT_HNE_SLIDE = "Client H&E Slide";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1");
        String eventtype = properties.getProperty("eventtype");
        String evntreason = properties.getProperty("evntreason");
        String isundobypass = properties.getProperty("isundobypass", "N");
        if (Util.isNull(keyid1)) {
            throw new SapphireException("Primary key can't be blank");
        }
        String sql = Util.parseMessage(ApSql.GET_SPECIMEN_ONLY, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsTestInfo = getQueryProcessor().getSqlDataSet(sql);

        if (dsTestInfo == null)
            throw new SapphireException("Below query cannot be executed.\n" + sql);
        if (dsTestInfo.size() == 0)
            throw new SapphireException("Testcode info cannot be obtained from the database for the selected testcode(s)");

        HashMap<String, String> hm = new HashMap<String, String>();
        hm.clear();
        hm.put("methodology", "Cytogenetics");
        DataSet dsCytoMethodologyFilter = dsTestInfo.getFilteredDataSet(hm);

        String nonCYtoTestcodeMapIds = "";

        if (dsCytoMethodologyFilter != null && dsCytoMethodologyFilter.size() > 0) {
            keyid1 = "";
            String inputKeyid1Arr[] = StringUtil.split(keyid1, ";");
            if (inputKeyid1Arr != null && inputKeyid1Arr.length > 0) {
                for (int i = 0; i < inputKeyid1Arr.length; i++) {
                    if (!Util.isNull(inputKeyid1Arr[i])) {
                        int rowindex = dsCytoMethodologyFilter.findRow("u_sampletestcodemapid", inputKeyid1Arr[i]);
                        if (rowindex < 0) {
                            nonCYtoTestcodeMapIds += ";" + inputKeyid1Arr[i];
                        }
                    }
                }
            }
            if (!Util.isNull(nonCYtoTestcodeMapIds)) {
                if (nonCYtoTestcodeMapIds.startsWith(";"))
                    nonCYtoTestcodeMapIds = nonCYtoTestcodeMapIds.substring(1);
                keyid1 = nonCYtoTestcodeMapIds;
            }
            /***************************TODO CYTO STARTS*******************************/
            if ("cancel".equalsIgnoreCase(eventtype)) {
                String orgSampleid = dsCytoMethodologyFilter.getColumnValues("s_sampleid", ";");
                if (!Util.isNull(orgSampleid)) {
                    orgSampleid = Util.getUniqueList(orgSampleid, ";", true);
                    PropertyList prop = new PropertyList();
                    prop.setProperty("orgsample", orgSampleid);
                    prop.setProperty("option", "Discard");
                    if (Util.isNull(evntreason))
                        prop.setProperty("auditreason", "Cancelling Test");
                    else
                        prop.setProperty("auditreason", evntreason);
                    getActionProcessor().processAction("CytoCancelTest", "1", prop);
                }
            }
            if ("undo".equalsIgnoreCase(eventtype)) {
                PropertyList prop = new PropertyList();
                prop.setProperty("keyid1", dsCytoMethodologyFilter.getColumnValues("u_sampletestcodemapid", ";"));
                if (Util.isNull(evntreason))
                    prop.setProperty("auditreason", "Uncancelling Test");
                else
                    prop.setProperty("auditreason", evntreason);
                getActionProcessor().processAction("CytoTestUnCancellation", "1", prop);
            }
            if ("delete".equalsIgnoreCase(eventtype)) {
                String cytoKeyid1 = dsCytoMethodologyFilter.getColumnValues("u_sampletestcodemapid", ";");
                sql = Util.parseMessage(ApSql.GET_DATASET_BY_SAMPLETESTCODEMAP_ID, StringUtil.replaceAll(cytoKeyid1, ";", "','"),
                        StringUtil.replaceAll(cytoKeyid1, ";", "','"));
                DataSet dsCytoTest = getQueryProcessor().getSqlDataSet(sql);

                sql = Util.parseMessage(ApSql.GET_WORKITEM_BY_SAMPLETESTCODEMAP_ID, StringUtil.replaceAll(cytoKeyid1, ";", "','"),
                        StringUtil.replaceAll(cytoKeyid1, ";", "','"));
                DataSet dsCytoWorkItem = getQueryProcessor().getSqlDataSet(sql);

                deleteDataSet(dsCytoTest);
                deleteSDIWorkItem(dsCytoWorkItem);
                deleteTestcode(cytoKeyid1, evntreason);
                updateActionReason(cytoKeyid1, evntreason);
            }
        }
        /***************************TODO CYTO ENDS*******************************/
        /***************************TODO IHC FISH FLOW MO MOL STARTS*******************************/
        if (!Util.isNull(keyid1)) {
            //CHECK DATASET FOR INDIVIDUAL TESTS
            sql = Util.parseMessage(ApSql.GET_DATASET_BY_SAMPLETESTCODEMAP_ID, StringUtil.replaceAll(keyid1, ";", "','"),
                    StringUtil.replaceAll(keyid1, ";", "','"));
            DataSet dsTest = getQueryProcessor().getSqlDataSet(sql);
            //CHECK WORKITEM FOR INDIVIDUAL TEST
            sql = Util.parseMessage(ApSql.GET_WORKITEM_BY_SAMPLETESTCODEMAP_ID, StringUtil.replaceAll(keyid1, ";", "','"),
                    StringUtil.replaceAll(keyid1, ";", "','"));
            DataSet dsWorkItem = getQueryProcessor().getSqlDataSet(sql);
            //CHECK INFO FOR PANEL
            sql = Util.parseMessage(ApSql.GET_OTHER_INFO_BY_TCM, StringUtil.replaceAll(keyid1, ";", "','"));
            DataSet dsTcm = getQueryProcessor().getSqlDataSet(sql);
            if ("delete".equalsIgnoreCase(eventtype)) {
                hm.clear();
                hm.put("ispanel", "Y");
                DataSet dsPanel = dsTcm.getFilteredDataSet(hm);
                if (dsPanel.size() > 0) {
                    String accessionid = Util.getUniqueList(dsPanel.getColumnValues("u_accessionid", ";"), ";", true);
                    String u_clientspecimenid = Util.getUniqueList(dsPanel.getColumnValues("u_clientspecimenid", ";"), ";", true);
                    String testname = Util.getUniqueList(dsPanel.getColumnValues("testname", ";"), ";", true);
                    //GET PANEL DATASET
                    sql = Util.parseMessage(ApSql.GET_PANEL_DATASET, StringUtil.replaceAll(accessionid, ";", "','"),
                            StringUtil.replaceAll(u_clientspecimenid, ";", "','"), StringUtil.replaceAll(testname, ";", "','"));
                    DataSet dsPanelDataSet = getQueryProcessor().getSqlDataSet(sql);
                    //GET PANEL WORKITEM
                    sql = Util.parseMessage(ApSql.GET_PANEL_WORKITEM, StringUtil.replaceAll(accessionid, ";", "','"),
                            StringUtil.replaceAll(u_clientspecimenid, ";", "','"), StringUtil.replaceAll(testname, ";", "','"));
                    DataSet dsPanelWorkItem = getQueryProcessor().getSqlDataSet(sql);
                    if (dsPanelDataSet.size() > 0) {
                        deletePanelDataSet(dsPanelDataSet);
                    }
                    if (dsPanelWorkItem.size() > 0) {
                        deletePanelSDIWorkItem(dsPanelWorkItem);
                    }
                }
                //DELETE FROM SAMPLE LEVEL
                deleteDataSet(dsTest);
                deleteSDIWorkItem(dsWorkItem);
                //DELETE TESTCODE STEPS
                deleteTestCodeSteps(keyid1, eventtype, evntreason);
                deleteTestcode(keyid1, evntreason);
                updateActionReason(keyid1, evntreason);
                validatePreSlideType(keyid1, eventtype);
            }
            if ("cancel".equalsIgnoreCase(eventtype)) {
                hm.clear();
                hm.put("ispanel", "Y");
                DataSet dsPanel = dsTcm.getFilteredDataSet(hm);
                if (dsPanel.size() > 0) {
                    String accessionid = Util.getUniqueList(dsPanel.getColumnValues("u_accessionid", ";"), ";", true);
                    String u_clientspecimenid = Util.getUniqueList(dsPanel.getColumnValues("u_clientspecimenid", ";"), ";", true);
                    String testname = Util.getUniqueList(dsPanel.getColumnValues("testname", ";"), ";", true);
                    //GET PANEL DATASET
                    sql = Util.parseMessage(ApSql.GET_PANEL_DATASET, StringUtil.replaceAll(accessionid, ";", "','"),
                            StringUtil.replaceAll(u_clientspecimenid, ";", "','"), StringUtil.replaceAll(testname, ";", "','"));
                    DataSet dsPanelDataSet = getQueryProcessor().getSqlDataSet(sql);
                    //GET PANEL WORKITEM
                    sql = Util.parseMessage(ApSql.GET_PANEL_WORKITEM, StringUtil.replaceAll(accessionid, ";", "','"),
                            StringUtil.replaceAll(u_clientspecimenid, ";", "','"), StringUtil.replaceAll(testname, ";", "','"));
                    DataSet dsPanelWorkItem = getQueryProcessor().getSqlDataSet(sql);
                    if (dsPanelDataSet.size() > 0) {
                        cancelPanelDataSet(dsPanelDataSet);
                    }
                    if (dsPanelWorkItem.size() > 0) {
                        cancelPanelSDIWorkItem(dsPanelWorkItem);
                    }
                }
                //CANCEL FROM SAMPLE LEVEL
                cancelDataSet(dsTest);
                cancelSDIWorkItem(dsWorkItem);
                cancelTestcode(keyid1, evntreason);
                updateActionReason(keyid1, evntreason);
                validatePreSlideType(keyid1, eventtype);
            }
            if ("undo".equalsIgnoreCase(eventtype)) {
                hm.clear();
                hm.put("ispanel", "Y");
                DataSet dsPanel = dsTcm.getFilteredDataSet(hm);
                if (dsPanel.size() > 0) {
                    String accessionid = Util.getUniqueList(dsPanel.getColumnValues("u_accessionid", ";"), ";", true);
                    String u_clientspecimenid = Util.getUniqueList(dsPanel.getColumnValues("u_clientspecimenid", ";"), ";", true);
                    String testname = Util.getUniqueList(dsPanel.getColumnValues("testname", ";"), ";", true);
                    //GET PANEL DATASET
                    sql = Util.parseMessage(ApSql.GET_PANEL_DATASET, StringUtil.replaceAll(accessionid, ";", "','"),
                            StringUtil.replaceAll(u_clientspecimenid, ";", "','"), StringUtil.replaceAll(testname, ";", "','"));
                    DataSet dsPanelDataSet = getQueryProcessor().getSqlDataSet(sql);
                    //GET PANEL WORKITEM
                    sql = Util.parseMessage(ApSql.GET_PANEL_WORKITEM, StringUtil.replaceAll(accessionid, ";", "','"),
                            StringUtil.replaceAll(u_clientspecimenid, ";", "','"), StringUtil.replaceAll(testname, ";", "','"));
                    DataSet dsPanelWorkItem = getQueryProcessor().getSqlDataSet(sql);
                    if (dsPanelDataSet.size() > 0) {
                        undoPanelDataSet(dsPanelDataSet);
                    }
                    if (dsPanelWorkItem.size() > 0) {
                        undoPanelSDIWorkItem(dsPanelWorkItem);
                    }
                }
                if ("N".equalsIgnoreCase(isundobypass))
                    checkMoreThanOneActiveTestOnSlide(keyid1);
                //UNDO FROM SAMPLE LEVEL
                undoDataSet(dsTest);
                updoSDIWorkItem(dsWorkItem);
                undoTestcode(keyid1);
                updateActionReason(keyid1, evntreason);
                validatePreSlideType(keyid1, eventtype);
            }
            /***************************TODO IHC FISH FLOW MO MOL STARTS*******************************/
        }

        //throw new SapphireException("test");
    }

    /**
     * @param keyid1
     * @param evntreason
     * @throws SapphireException
     * @Desc: Used to delete test(s) from the specimen.
     */
    private void deleteTestcode(String keyid1, String evntreason) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty(DeleteSDI.PROPERTY_AUDITREASON, evntreason);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete testcode(s)." + ex.getMessage());
            }
        }
    }

    /**
     * @param keyid1
     * @param evntreason
     * @throws SapphireException
     * @Desc: Used to changes test status as cancelled for selected,
     */
    private void cancelTestcode(String keyid1, String evntreason) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_CURRNT_PRE_STEP_BYTESTCODEMAPID, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsTestsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestsInfo.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsTestsInfo.getColumnValues("u_sampletestcodemapid", ";"));
            props.setProperty("prestatus", dsTestsInfo.getColumnValues("teststatus", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update test previous status.");
            }
        }
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty(EditSDI.PROPERTY_AUDITREASON, evntreason);
            props.setProperty("teststatus", "Cancelled");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canceled testcode(s).");
            }
        }
    }

    /**
     * @param keyid1
     * @throws SapphireException
     * @Desc: Restore test previous step.
     */
    private void undoTestcode(String keyid1) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_CURRNT_PRE_STEP_BYTESTCODEMAPID, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsTestsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestsInfo.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsTestsInfo.getColumnValues("u_sampletestcodemapid", ";"));
            props.setProperty("teststatus", dsTestsInfo.getColumnValues("prestatus", ";"));
            props.setProperty("prestatus", StringUtil.repeat("(null)", dsTestsInfo.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to Undo cancelled testcode(s).");
            }
        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Delete dataset for individual test.
     */
    private void deleteDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteDataSet.ID, DeleteDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s).");
            }

        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Delete dataset for panel.
     */
    private void deletePanelDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteDataSet.PROPERTY_SDCID, "Accession");
            props.setProperty(DeleteDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_KEYID2, dsTest.getColumnValues("keyid2", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_KEYID3, dsTest.getColumnValues("keyid3", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteDataSet.ID, DeleteDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s).");
            }

        }
    }

    /**
     * @param deleteWorkItem
     * @throws SapphireException
     * @Desc: Delete workitem for individual test.
     */
    private void deleteSDIWorkItem(DataSet deleteWorkItem) throws SapphireException {
        if (deleteWorkItem != null && deleteWorkItem.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1, deleteWorkItem.getColumnValues("keyid1", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID, deleteWorkItem.getColumnValues("workitemid", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE, deleteWorkItem.getColumnValues("workiteminstance", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES, "Y");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s).");
            }

        }
    }

    /**
     * @param deleteWorkItem
     * @throws SapphireException
     * @Desc: Delete workitem for panel
     */
    private void deletePanelSDIWorkItem(DataSet deleteWorkItem) throws SapphireException {
        if (deleteWorkItem != null && deleteWorkItem.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Accession");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1, deleteWorkItem.getColumnValues("keyid1", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID2, deleteWorkItem.getColumnValues("keyid2", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID3, deleteWorkItem.getColumnValues("keyid3", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID, deleteWorkItem.getColumnValues("workitemid", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE, deleteWorkItem.getColumnValues("workiteminstance", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES, "Y");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Cancel dataset for panel.
     */
    private void cancelPanelDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditDataSet.PROPERTY_SDCID, "Accession");
            props.setProperty(EditDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(EditDataSet.PROPERTY_KEYID2, dsTest.getColumnValues("keyid2", ";"));
            props.setProperty(EditDataSet.PROPERTY_KEYID3, dsTest.getColumnValues("keyid3", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EditDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(EditDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty("s_datasetstatus", "Cancelled");
            props.setProperty("s_cancellableflag", "Y");
            props.setProperty("cancelleddt", "n");
            props.setProperty("cancelledby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo cancelled test workiem(s).");
            }

        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Cancel dataset from sample level.
     */
    private void cancelDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(EditDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EditDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(EditDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty("s_datasetstatus", "Cancelled");
            props.setProperty("s_cancellableflag", "Y");
            props.setProperty("cancelleddt", "n");
            props.setProperty("cancelledby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo cancelled test dataset(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param deleteWorkItem
     * @throws SapphireException
     * @Desc: Cancel workitem for individual test.
     */
    private void cancelSDIWorkItem(DataSet deleteWorkItem) throws SapphireException {
        if (deleteWorkItem != null && deleteWorkItem.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID1, deleteWorkItem.getColumnValues("keyid1", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMID, deleteWorkItem.getColumnValues("workitemid", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMINSTANCE, deleteWorkItem.getColumnValues("workiteminstance", ";"));
            props.setProperty("workitemstatus", "Cancelled");
            props.setProperty("cancelleddt", "n");
            props.setProperty("cancelledby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditSDIWorkItem.ID, EditSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canecled test workiem(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param deleteWorkItem
     * @throws SapphireException
     * @Desc: Cancel workitem for panel
     */
    private void cancelPanelSDIWorkItem(DataSet deleteWorkItem) throws SapphireException {
        if (deleteWorkItem != null && deleteWorkItem.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDIWorkItem.PROPERTY_SDCID, "Accession");
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID1, deleteWorkItem.getColumnValues("keyid1", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID2, deleteWorkItem.getColumnValues("keyid2", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID3, deleteWorkItem.getColumnValues("keyid3", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMID, deleteWorkItem.getColumnValues("workitemid", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMINSTANCE, deleteWorkItem.getColumnValues("workiteminstance", ";"));
            props.setProperty("workitemstatus", "Cancelled");
            props.setProperty("cancelleddt", "n");
            props.setProperty("cancelledby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditSDIWorkItem.ID, EditSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canecled test workiem(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param dsWorkitem
     * @throws SapphireException
     * @Desc: Undo workitem for individual test.
     */
    private void updoSDIWorkItem(DataSet dsWorkitem) throws SapphireException {
        if (dsWorkitem != null && dsWorkitem.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID1, dsWorkitem.getColumnValues("keyid1", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMID, dsWorkitem.getColumnValues("workitemid", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMINSTANCE, dsWorkitem.getColumnValues("workiteminstance", ";"));
            props.setProperty("workitemstatus", "Initial");
            props.setProperty("cancelleddt", "(null)");
            props.setProperty("cancelledby", "(null)");
            try {
                getActionProcessor().processAction(EditSDIWorkItem.ID, EditSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo cancelled test workiem(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Undo workitem for panel.
     */
    private void undoPanelSDIWorkItem(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDIWorkItem.PROPERTY_SDCID, "Accession");
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID2, dsTest.getColumnValues("keyid2", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_KEYID3, dsTest.getColumnValues("keyid3", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMID, dsTest.getColumnValues("workitemid", ";"));
            props.setProperty(EditSDIWorkItem.PROPERTY_WORKITEMINSTANCE, dsTest.getColumnValues("workiteminstance", ";"));
            props.setProperty("workitemstatus", "Initial");
            props.setProperty("cancelleddt", "(null)");
            props.setProperty("cancelledby", "(null)");
            try {
                getActionProcessor().processAction(EditSDIWorkItem.ID, EditSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo cancelled test workiem(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Undo dataset for panel.
     */
    private void undoPanelDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditDataSet.PROPERTY_SDCID, "Accession");
            props.setProperty(EditDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(EditDataSet.PROPERTY_KEYID2, dsTest.getColumnValues("keyid2", ";"));
            props.setProperty(EditDataSet.PROPERTY_KEYID3, dsTest.getColumnValues("keyid3", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EditDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(EditDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty("s_datasetstatus", "Initial");
            props.setProperty("s_cancellableflag", "N");
            props.setProperty("cancelleddt", "(null)");
            props.setProperty("cancelledby", "(null)");
            try {
                getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo cancelled test workiem(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param dsTest
     * @throws SapphireException
     * @Desc: Undo cancelled dataset from sample level.
     */
    private void undoDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(EditDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EditDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(EditDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty("s_datasetstatus", "Initial");
            props.setProperty("s_cancellableflag", "N");
            props.setProperty("cancelleddt", "(null)");
            props.setProperty("cancelledby", "(null)");
            try {
                getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo cancelled test workiem(s)." + ex.getMessage());
            }

        }
    }

    /**
     * @param keyid1
     * @param reason
     * @throws SapphireException
     * @Desc: Update reason for cancel/delete/undo.
     */
    private void updateActionReason(String keyid1, String reason) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_SAMPLEID_BY_SAMPLETCMAPID, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsSamples = getQueryProcessor().getSqlDataSet(sql);
        if (dsSamples != null && dsSamples.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsSamples.getColumnValues("s_sampleid", ";"));
            props.setProperty("notes", StringUtil.repeat(reason, dsSamples.size(), ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update reason." + ex.getMessage());
            }
        }
    }

    /**
     * @param mapid
     * @throws SapphireException
     * @Desc: Check more than one active testcode peresents or not into slide level.
     */
    private void checkMoreThanOneActiveTestOnSlide(String mapid) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_TESTS_BY_MAPID_IHC, StringUtil.replaceAll(mapid, ";", "','"));
        DataSet dsSamplInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsSamplInfo.size() > 0) {
            throw new SapphireException("<b>Unable to perform. Already slide(s) has active test(s).</b>");
        }
        if (dsSamplInfo.size() == 0) {
            sql = Util.parseMessage(ApSql.GET_TESTS_BY_MAPID_IHC_CHKCANCEL, StringUtil.replaceAll(mapid, ";", "','"),
                    StringUtil.replaceAll(mapid, ";", "','"));
            DataSet dsCancelTestInfo = getQueryProcessor().getSqlDataSet(sql);
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("teststatus", "Cancelled");
            DataSet dsCancel = dsCancelTestInfo.getFilteredDataSet(hm);
            if (dsCancel.size() > 1) {
                throw new SapphireException("<b>You can active only one test per slide(s).</b>");
            }
        }
    }

    /**
     * @param mapid
     * @param eventtype
     * @throws SapphireException
     * @Desc: Valdate slide type which is present before added tests.
     */
    private void validatePreSlideType(String mapid, String eventtype) throws SapphireException {
        DataSet dsSampleType = new DataSet();
        dsSampleType.addColumn("sampleid", DataSet.STRING);
        dsSampleType.addColumn("transporttypeid", DataSet.STRING);
        String sql = Util.parseMessage(ApSql.GET_SAMPLE_TESTCODE_BY_MAPID, StringUtil.replaceAll(mapid, ";", "','"));
        DataSet dsTestsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsTestsInfo != null && dsTestsInfo.size() > 0) {
            dsTestsInfo.sort("s_sampleid");
            ArrayList<DataSet> dsSamplesArr = dsTestsInfo.getGroupedDataSets("s_sampleid");
            for (int i = 0; i < dsSamplesArr.size(); i++) {
                DataSet temDs = dsSamplesArr.get(i);
                for (int j = 0; j < temDs.size(); j++) {
                    String sampleid = temDs.getValue(j, "s_sampleid", "");
                    String teststatus = temDs.getValue(j, "teststatus", "");
                    String hneflag = temDs.getValue(j, "hneflag", "");
                    String transporttypeid = temDs.getValue(j, "transporttypeid", "");
                    if ("Cancelled".equalsIgnoreCase(teststatus) && "Y".equalsIgnoreCase(hneflag)) {
                        int rowID = dsSampleType.addRow();
                        dsSampleType.setValue(rowID, "sampleid", sampleid);
                        dsSampleType.setValue(rowID, "transporttypeid", transporttypeid);
                    } else if (!"Cancelled".equalsIgnoreCase(teststatus) && "Y".equalsIgnoreCase(hneflag)) {
                        int rowID = dsSampleType.addRow();
                        dsSampleType.setValue(rowID, "sampleid", sampleid);
                        dsSampleType.setValue(rowID, "transporttypeid", transporttypeid);
                    }
                }
            }
        }
        if (dsSampleType.size() > 0) {
            markClientSlides(dsSampleType, eventtype);
        }
    }

    /**
     * @param dsFinal
     * @param eventtype
     * @throws SapphireException
     * @Desc: For H&E testcode applied on slide(s), marking as H/CH based on specimen type.
     */
    private void markClientSlides(DataSet dsFinal, String eventtype) throws SapphireException {
        if (!dsFinal.isValidColumn(DATASET_COLUMN_TYPE)) {
            dsFinal.addColumn(DATASET_COLUMN_TYPE, DataSet.STRING);
        }
        if (!dsFinal.isValidColumn(DATASET_COLUMN_TYPE_UPDATED)) {
            dsFinal.addColumn(DATASET_COLUMN_TYPE_UPDATED, DataSet.STRING);
        }

        HashMap hm = new HashMap();
        hm.put("transporttypeid", TRANSPORT_TYPE_UNSTAINED_SLIDE);
        DataSet dsUnstainedSlide = dsFinal.getFilteredDataSet(hm);
        if (dsUnstainedSlide != null && dsUnstainedSlide.size() > 0) {
            for (int i = 0; i < dsUnstainedSlide.size(); i++) {
                dsUnstainedSlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                if ("cancel".equalsIgnoreCase(eventtype))
                    dsUnstainedSlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_UNSTAINED_SLIDE);
                else if (!"cancel".equalsIgnoreCase(eventtype))
                    dsUnstainedSlide.setValue(i, DATASET_COLUMN_TYPE, "H");
            }

        }
        hm.clear();
        hm.put("transporttypeid", TRANSPORT_TYPE_STAINED_SLIDE);
        DataSet stainedSlide = dsFinal.getFilteredDataSet(hm);
        if (stainedSlide != null && stainedSlide.size() > 0) {
            for (int i = 0; i < stainedSlide.size(); i++) {
                stainedSlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                if ("cancel".equalsIgnoreCase(eventtype))
                    stainedSlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_STAINED_SLIDE); //Client Stained Slide
                else if (!"cancel".equalsIgnoreCase(eventtype))
                    stainedSlide.setValue(i, DATASET_COLUMN_TYPE, "H"); //Client Stained Slide
            }

        }

        hm.clear();
        hm.put("transporttypeid", TRANSPORT_TYPE_HNE_SLIDE);
        DataSet HNESlide = dsFinal.getFilteredDataSet(hm);
        if (HNESlide != null && HNESlide.size() > 0) {
            for (int i = 0; i < HNESlide.size(); i++) {
                HNESlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                if ("cancel".equalsIgnoreCase(eventtype))
                    HNESlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_HNE_SLIDE); //Client H&E
                else if (!"cancel".equalsIgnoreCase(eventtype))
                    HNESlide.setValue(i, DATASET_COLUMN_TYPE, "CH"); //Client H&E
            }

        }

        hm.clear();
        hm.put("transporttypeid", TRANSPORT_TYPE_CLIENT_HNE_SLIDE);
        DataSet ClientHNESlide = dsFinal.getFilteredDataSet(hm);
        if (ClientHNESlide != null && ClientHNESlide.size() > 0) {
            for (int i = 0; i < ClientHNESlide.size(); i++) {
                ClientHNESlide.setValue(i, DATASET_COLUMN_TYPE_UPDATED, "Y");
                if ("cancel".equalsIgnoreCase(eventtype))
                    ClientHNESlide.setValue(i, DATASET_COLUMN_TYPE, Constants.U_TYPE_CLIENT_HNE_SLIDE); //Client H&E
                if (!"cancel".equalsIgnoreCase(eventtype))
                    ClientHNESlide.setValue(i, DATASET_COLUMN_TYPE, "CH"); //Client H&E
            }

        }

        hm.clear();
        hm.put(DATASET_COLUMN_TYPE_UPDATED, "Y");
        DataSet dsToUpdate = dsFinal.getFilteredDataSet(hm);

        if (dsToUpdate != null && dsToUpdate.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsToUpdate.getColumnValues("sampleid", ";"));
            prop.setProperty("u_type", dsToUpdate.getColumnValues(DATASET_COLUMN_TYPE, ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to undo slide type. " + ex.getMessage());
            }
        }
    }

    /**
     * Desc: Delete steps from test code steps based on sample testcode.
     *
     * @param mapid
     * @param eventtype
     * @throws SapphireException
     */
    private void deleteTestCodeSteps(String mapid, String eventtype, String evntreason) throws SapphireException {
        if ("delete".equalsIgnoreCase(eventtype)) {
            String sql = Util.parseMessage(ApSql.GET_TESTCODE_STEPS, StringUtil.replaceAll(mapid, ";", "','"));
            DataSet dsTestCodeStps = getQueryProcessor().getSqlDataSet(sql);
            if (dsTestCodeStps.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestcodeStpMap");
                props.setProperty(DeleteSDI.PROPERTY_KEYID1, dsTestCodeStps.getColumnValues("u_sampletestcodestpmapid", ";"));
                props.setProperty(DeleteSDI.PROPERTY_AUDITREASON, evntreason);
                try {
                    getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
                } catch (Exception ex) {
                    throw new SapphireException("Unable to delete testcode(s) steps." + ex.getMessage());
                }
            }
        }
    }
}
