package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.HashMap;

public class CreateHemeExtractionWrap extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String searchedText = properties.getProperty("scansample");
        //String alreadyScannedSamples = ajaxResponse.getRequestParameter("alreadyscannedsample");
        String coldate = properties.getProperty("coldate");
        String extractiontype = properties.getProperty("extractiontype");
        String requestid = properties.getProperty("requestid", "");
        String tnaworkflow = properties.getProperty("tnaworkflow", "N");
        String newsampleid = "";
        String sqlExtrct = Util.parseMessage(MolecularSql.CHECK_EXTRACTION_PRESENT_BY_SAMPLE, searchedText);
        DataSet dsExtractionInfo = getQueryProcessor().getSqlDataSet(sqlExtrct);
        if (dsExtractionInfo.size() > 0 && "N".equalsIgnoreCase(tnaworkflow)) {
            String extractionid = dsExtractionInfo.getValue(0, "u_extractionid", "");
            throw new SapphireException("<b>Extraction ID( " + extractionid + " ) already been generated for the specimen: " + searchedText + ". Please scan another specimen.</b>");
        }
        String collectiondtsql = Util.parseMessage(MolecularSql.GET_COLLECTIONDT_BY_SAMPLEID, searchedText);
        DataSet dscollectiondt = getQueryProcessor().getSqlDataSet(collectiondtsql);
        if (dscollectiondt == null) {
            String err = "Failed to query LabVantage database. Please contact Administrator. Query framed - \n" + collectiondtsql;
            logger.error("Failed to query LabVantage System. Query returns a null dataset. Query framed- \n" + collectiondtsql);
            throw new SapphireException(err);

        }
        //TODO
        if ("N".equalsIgnoreCase(coldate) && dscollectiondt.size() == 0) {
            String err = "Please update collection date for scanned specimen.";
            logger.error("Please scan correct sample- \n" + collectiondtsql);
            throw new SapphireException(err);
            /*ajaxResponse.setError(err);
            ajaxResponse.print();
            return;*/

        }
        if (dscollectiondt.size() > 0 || dscollectiondt.size() == 0) {
            String sql = Util.parseMessage(MolecularSql.GET_EXTRACTIONTYPE_DETAILS_BY_SAMPLEID, searchedText);
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            String molecularsubmethodology = ds.getColumnValues("molecularsubmethodology", ";");
            String Extractiontype = ds.getColumnValues("extractiontype", ";");
            String SpecimentypeId = ds.getColumnValues("specimentypeid", ";");
            //if (extractiontype.equalsIgnoreCase(Extractiontype)) {
            if (Extractiontype.contains(extractiontype)) {
                if (!SpecimentypeId.equalsIgnoreCase("Tissue")) {
                    PropertyList pl = new PropertyList();
                    pl.clear();
                    pl.setProperty("keyid1", searchedText);
                    pl.setProperty("extractiontype", extractiontype);
                    pl.setProperty("hascoldt", coldate);
                    if (!Util.isNull(requestid)) {
                        pl.setProperty("requestid", requestid);
                    }
                    //TAKE CUSTODY AFTER SCANNING
                    takeCustodyScannedSample(searchedText);
                    //pl.setProperty("alreadyScannedSamples",alreadyScannedSamples);
                    try {
                        // getActionProcessor().processAction("CreateExtractionTube", "1", pl);
                        getActionProcessor().processAction("CreateHemeExtractionTube", "1", pl);

                    } catch (ActionException e) {
                        e.printStackTrace();
                    }
                    newsampleid = pl.getProperty("newkeyid1");
                    validateScannedItem(newsampleid);
                    labelPrint(newsampleid);//Print Label requirement changes.No need to print labels for
                    // extraction tubes during sample scanning Non-FFPE.
                    //as per discussion with team again label print add on 22,01,2018
                } else {
                    String error = "Select a sample which has sample type not tissue";
                    throw new SapphireException(error);
                }

            } else if (Util.isNull(Extractiontype) && molecularsubmethodology.contains("NanoString")) {
                DataSet dsNanoExtrctnType = getExtractionTypeForNanoString();
                if (!SpecimentypeId.equalsIgnoreCase("Tissue")) {
                    PropertyList pl = new PropertyList();
                    sql = Util.parseMessage(MolecularSql.GET_NANOSTRING_INFO_BY_SAMPLE, searchedText);
                    DataSet dsUSS = getQueryProcessor().getSqlDataSet(sql);
                    String testcoodes = Util.getUniqueList(dsUSS.getColumnValues("lvtestcodeid", ";"), ";", true);
                    HashMap hm = new HashMap();
                    hm.put("testcodeid", testcoodes);
                    DataSet dsExtrcFilter = dsNanoExtrctnType.getFilteredDataSet(hm);
                    if (dsExtrcFilter.size() > 0) {
                        String extrcs = dsExtrcFilter.getColumnValues("extractiontype", ";");
                        if (extrcs.contains(extractiontype)) {

                            pl.clear();
                            pl.setProperty("keyid1", searchedText);
                            pl.setProperty("extractiontype", extractiontype);
                            pl.setProperty("hascoldt", coldate);
                            pl.setProperty("molecularsubmethodology", "NanoString");
                            if (!Util.isNull(requestid)) {
                                pl.setProperty("requestid", requestid);
                            }
                        } else {
                            String errorr = "Select a sample which has extraction type is " + extractiontype;
                            throw new SapphireException(errorr);
                        }
                    }
                    //TODO CHANGES FOR VALIDATE EXTRACTION TYPE FOR NANOSTRING TESTCODE(S)
                            /*PropertyList pl = new PropertyList();
                            pl.clear();
                            pl.setProperty("keyid1", searchedText);
                            pl.setProperty("extractiontype", extractiontype);
                            pl.setProperty("molecularsubmethodology", "NanoString");
                            if (!Util.isNull(requestid)) {
                                pl.setProperty("requestid", requestid);
                            }*/
                    //TAKE CUSTODY AFTER SCANNING
                    takeCustodyScannedSample(searchedText);
                    //pl.setProperty("alreadyScannedSamples",alreadyScannedSamples);
                    try {
                        // getActionProcessor().processAction("CreateExtractionTube", "1", pl);
                        getActionProcessor().processAction("CreateHemeExtractionTube", "1", pl);

                    } catch (ActionException e) {
                        throw new SapphireException(e.getMessage());
                    }
                    newsampleid = pl.getProperty("newkeyid1");
                    validateScannedItem(newsampleid);
                    labelPrint(newsampleid);//Print Label requirement changes.No need to print labels for
                    // extraction tubes during sample scanning Non-FFPE.
                    //as per discussion with team again label print add on 22,01,2018

                } else {
                    String error = "Select a sample which has sample type not tissue";
                    throw new SapphireException(error);
                }

            } else {
                String error = "Select a sample which has extraction type is " + Extractiontype;
                throw new SapphireException(error);
            }
        }
        properties.setProperty("newsampleid", newsampleid);
    }

    /**
     * Description : This method will call PrintLabel action and will print label depend on extractiontype
     *
     * @param newkeyid1
     * @throws SapphireException
     */

    private void labelPrint(String newkeyid1) throws SapphireException {
        String sqlExTube = Util.parseMessage(MolecularSql.GET_EXTRACTION_TUBE_BY_SAMPLE, StringUtil.replaceAll(newkeyid1, ";", "','"));
        DataSet dsExTube = getQueryProcessor().getSqlDataSet(sqlExTube);
        if (dsExTube == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlExTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsExTube.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample Type not found.");
            errMsg += "\nQuery returns zero rows:" + sqlExTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        for (int i = 0; i < dsExTube.size(); i++) {
            String sample = dsExTube.getValue(i, "s_sampleid", "");
            if (Util.isNull(sample)) {
                String errMsg = getTranslationProcessor().translate("Sample id not found.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }

            String extractiontype = dsExTube.getValue(i, "extractiontype", "");
            if (Util.isNull(extractiontype)) {
                String errMsg = getTranslationProcessor().translate("Extraction type not found/Extraction id is already generated for specimen:" + sample);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
        }
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, dsExTube.getColumnValues("s_sampleid", ";"));
        props.setProperty(PrintLabel.EXTRACTION_TYPE, Util.getUniqueList(dsExTube.getColumnValues("extractiontype", ";"), ";", true));//added
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Molecular");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, "ExtractionTube");
        props.setProperty(PrintLabel.TRAMLINE_PROP, "Extraction");
        props.setProperty(PrintLabel.COPIES, "3");  // As per discussion with Lito, business need 3 prints (23-Jan-2018)
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    private void takeCustodyScannedSample(String scannedsample) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_TRACKITEM_BY_SAMPLE, scannedsample);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String currentdepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
        props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("trackitemid", ";"));
        props.setProperty("custodytakendt", "n");
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", currentdepartment);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
    }

    public DataSet getExtractionTypeForNanoString() throws SapphireException {
        DataSet dsNanoExtr = new DataSet();
        dsNanoExtr.addColumn("testcodeid", DataSet.STRING);
        dsNanoExtr.addColumn("extractiontype", DataSet.STRING);
        PropertyList plMicroPolicy = getConfigurationProcessor().getPolicy("NanoStringExtractionTypePolicy", "NanoStringExtractionType");
        PropertyListCollection plctestcodelist = plMicroPolicy.getCollection("testcodelist");
        if (plctestcodelist == null)
            throw new SapphireException("Extraction type is not defined for NanoString-> Policy.");
        //PropertyListCollection plclosmap = plctestcodelist.getCollection("extractiontypelist");
        for (int i = 0; i < plctestcodelist.size(); i++) {
            String testcodeid = plctestcodelist.getPropertyList(i).getProperty("testcodeid");
            PropertyListCollection plExtractionTypeList = plctestcodelist.getPropertyList(i).getCollection("extractiontypelist");
            for (int j = 0; j < plExtractionTypeList.size(); j++) {
                String extractiontype = plExtractionTypeList.getPropertyList(j).getProperty("extractiontype");
                int rowID = dsNanoExtr.addRow();
                dsNanoExtr.setValue(rowID, "testcodeid", testcodeid);
                dsNanoExtr.setValue(rowID, "extractiontype", extractiontype);
                //extractionreagentprops.setProperty(reagenttype, extractionetype);
            }
        }
        return dsNanoExtr;
    }

    private void validateScannedItem(String searchedText) throws SapphireException {
        if (searchedText == null || "".equalsIgnoreCase(searchedText.trim())) {
            throw new SapphireException("Scanned item is blank.");
        }
    }
}
