package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.storage.DeleteTrackItem;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by ajha on 5/3/2016.
 * TODO provide Action Details and Mandatory Input List
 */
public class DelCassette extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String cassetteid = properties.getProperty("cassetteids");
        String queCassette= StringUtil.replaceAll(cassetteid,";","','");
        //String sql = "select u_accessionid from  s_sample  where  s_sampleid in('" + sampleid.replaceAll(";", "','") + "')";
        String sql = "select linkkeyid1 ,CURRENTSTORAGEUNITID,trackitemid from TRACKITEM where CURRENTSTORAGEUNITID in(select storageunitid " +
                "from storageunit where linkkeyid1 in ('"+queCassette+"') and linksdcid= 'Cassette') and linksdcid= 'Sample'";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String sampleid =ds.getColumnValues("linkkeyid1",";");
        String storageunitid = ds.getColumnValues("CURRENTSTORAGEUNITID",";");
        String trackitemidSample = ds.getValue(0,"trackitemid");

if(ds.size()>0) {
    updateStatus(sampleid);
    updateTrackItem(sampleid);
}
        DeleteStorageUnit(cassetteid);
        DeleteTrackItemCassette(cassetteid);
        DeleteCassette(cassetteid);



}
    private void updateStatus(String sampleid) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("storagestatus", "Disposed");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update request in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
    private void updateTrackItem(String sampleid) throws SapphireException {
        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            props.setProperty("CURRENTSTORAGEUNITID", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }
        catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Can't update track item SDC");
                error += ae.getMessage();
                throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }
    private void DeleteStorageUnit(String cassetteid) throws SapphireException {
        String queCassette= StringUtil.replaceAll(cassetteid,";","','");
        String c_sql=" select storageunitid from storageunit where linkkeyid1 in('"+queCassette+"') and linksdcid='Cassette'";
        DataSet ds = getQueryProcessor().getSqlDataSet(c_sql);
        String storageunitid=ds.getColumnValues("storageunitid",";");
        PropertyList props = new PropertyList();


        try {
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "StorageUnitSDC");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1,storageunitid);
            getActionProcessor().processAction(DeleteSDI.ID,DeleteSDI.VERSIONID,props);
        }
        catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from storageunit SDC");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }
    private void DeleteTrackItemCassette(String cassetteid) throws SapphireException {
        String queCassette= StringUtil.replaceAll(cassetteid,";","','");
       String c_sql="Select trackitemid from trackitem where linkkeyid1 in('"+queCassette+"') and linksdcid='Cassette'";
        DataSet ds = getQueryProcessor().getSqlDataSet(c_sql);
        String trackitemid=ds.getColumnValues("trackitemid",";");
        PropertyList props = new PropertyList();


     /*  try {
            props.setProperty(DeleteTrackItem.TRACKITEMSDCID, "TrackItemSDC");
            props.setProperty(DeleteTrackItem.PROPERTY_TRACKITEMID, trackitemid);

            getActionProcessor().processAction(DeleteTrackItem.ID,DeleteTrackItem.VERSIONID,props);
        }
        catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from track item");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }*/

        try {
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1,trackitemid);
            getActionProcessor().processAction(DeleteSDI.ID,DeleteSDI.VERSIONID,props);
        }
        catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from trackitem SDC");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }
    private void DeleteCassette(String u_cassetteid) throws SapphireException {
        PropertyList props = new PropertyList();


        try {
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "Cassette");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1,u_cassetteid);
            getActionProcessor().processAction(DeleteSDI.ID,DeleteSDI.VERSIONID,props);
        }
        catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from Cassette SDC");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }
    }


