package sapphire.custom.ng.action;

import static sapphire.custom.ng.util.Util.getUniqueList;
import static sapphire.custom.ng.util.Util.isNull;

import java.util.HashMap;

import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.action.RecordIncident;
import sapphire.action.SubmitSDIForApproval;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by dkundu on 10/18/2016.
 * Modified by surajit.baitalik on 08/28/2018
 */
public class HNEReviewComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sdcid = properties.getProperty("sdcid");
        String sampleids = properties.getProperty("keyid1");
        String currentmovementstep = getUniqueList(properties.getProperty("u_currentmovementstep"), ";", true);
        String hnebatchreview = getUniqueList(properties.getProperty("u_hnebatchreview"), ";", true);
        String pathreviewedby = getUniqueList(properties.getProperty("u_pathreviewedby"), ";", true);
        String pathreviewdts = getUniqueList(properties.getProperty("u_pathreviewdts"), ";", true);
        String currenttramstop = getUniqueList(properties.getProperty("u_currenttramstop"), ";", true);
        String custodialuserid = getUniqueList(properties.getProperty("custodialuserid"), ";", true);
        String custodytakendt = getUniqueList(properties.getProperty("custodytakendt"), ";", true);
        String custodialdepartmentid = getUniqueList(properties.getProperty("custodialdepartmentid"), ";", true);

        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String departmentSite = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));
        //String newCustodialdepartmentid = departmentSite + "-PathSupport";
        String newCustodialdepartmentid = departmentSite + "-Accessioning";

        //DataSet dsSql = getAllHNENUnstainedSlides(sampleids);
        DataSet dsSql = dsHNESamples(sampleids);
        populateTumorCercledValueOnUSS(dsSql);
        if (!dsSql.isValidColumn("u_currentmovementstep")) {
            dsSql.addColumn("u_currentmovementstep", DataSet.STRING);
        }
        if (!dsSql.isValidColumn("u_currenttramstop")) {
            dsSql.addColumn("u_currenttramstop", DataSet.STRING);
        }
        if (!dsSql.isValidColumn("custodialdept")) {
            dsSql.addColumn("custodialdept", DataSet.STRING);
        }
        DataSet dsHNELot = new DataSet();
        dsHNELot.addColumn("specimen_id", DataSet.STRING);
        dsHNELot.addColumn("eosin_lot", DataSet.STRING);
        dsHNELot.addColumn("hematoxylin_lot", DataSet.STRING);
        dsHNELot.addColumn("eosin_exp_date", DataSet.STRING);
        dsHNELot.addColumn("hematoxylin_exp_date", DataSet.STRING);
        for (int i = 0; i < dsSql.size(); i++) {
            String meth = dsSql.getValue(i, "methodology", "");
            String u_qns = dsSql.getValue(i, "u_qns", "");
            if (meth.equalsIgnoreCase("Molecular")) {
                dsSql.setValue(i, "u_currentmovementstep", currentmovementstep);
                dsSql.setValue(i, "u_currenttramstop", currenttramstop);
                dsSql.setValue(i, "custodialdept", newCustodialdepartmentid);
                //CHECK EOSIN LOT AND HEMATOXIN LOT
                String u_eosinlotid = dsSql.getValue(i, "u_eosinlotid", "");
                String u_hematoxylinlotid = dsSql.getValue(i, "u_hematoxylinlotid", "");
                String u_eosinexpdt = dsSql.getValue(i, "u_eosinexpdt", "");
                String u_hematoxylinexpdt = dsSql.getValue(i, "u_hematoxylinexpdt", "");
                if (Util.isNull(u_eosinlotid) || Util.isNull(u_hematoxylinlotid) || Util.isNull(u_eosinexpdt) || Util.isNull(u_hematoxylinexpdt)) {
                    int rowId = dsHNELot.addRow();
                    dsHNELot.setValue(rowId, "specimen_id", dsSql.getValue(i, "sampleid", ""));
                    dsHNELot.setValue(rowId, "eosin_lot", u_eosinlotid);
                    dsHNELot.setValue(rowId, "hematoxylin_lot", u_hematoxylinlotid);
                    dsHNELot.setValue(rowId, "eosin_exp_date", u_eosinexpdt);
                    dsHNELot.setValue(rowId, "hematoxylin_exp_date", u_hematoxylinexpdt);
                }
            } else if (meth.equalsIgnoreCase("FISH")) {
                //dsSql.setValue(i,"u_currentmovementstep", "FISHQC");
                //dsSql.setValue(i,"u_currenttramstop", "CheckInQC");
                dsSql.setValue(i, "u_currentmovementstep", "PathSupport");
                dsSql.setValue(i, "u_currenttramstop", "PathSupportCOC");
                dsSql.setValue(i, "custodialdept", newCustodialdepartmentid);
            }
        }
        if (dsHNELot != null && dsHNELot.size() > 0) {
            String err = Util.getDisplayMessage("Eosin and Hematoxylin lot information are required for below specimen(s).", dsHNELot);
            throw new SapphireException(err);
        }

        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsSql.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currentmovementstep", dsSql.getColumnValues("u_currentmovementstep", ";"));
        prop.setProperty("u_hnebatchreview", StringUtil.repeat(hnebatchreview, dsSql.size(), ";"));
        prop.setProperty("u_pathreviewedby", StringUtil.repeat(pathreviewedby, dsSql.size(), ";"));
        prop.setProperty("u_pathreviewdts", StringUtil.repeat(pathreviewdts, dsSql.size(), ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit sample" + ae.getMessage());
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        prop.clear();
        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSql.getColumnValues("sampleid", ";"));
        prop.setProperty("u_currenttramstop", dsSql.getColumnValues("u_currenttramstop", ";"));
        prop.setProperty("custodialuserid", StringUtil.repeat("(null)", dsSql.size(), ";"));
        prop.setProperty("custodytakendt", StringUtil.repeat(custodytakendt, dsSql.size(), ";"));
        prop.setProperty("custodialdepartmentid", dsSql.getColumnValues("custodialdept", ";"));
        //prop.setProperty("custodialdepartmentid", StringUtil.repeat(newCustodialdepartmentid, dsSql.size(), ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item." + ae.getMessage());
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        /***
         * TODO WE DON'T NEED THIS AS WE DON"T HAVE REQUEST MODULE
         */
        //createIncident(departmentSite, sampleids);
        /***
         * FOLLOW MICRODISSECTION RULE IF REQUIRED.
         */
        /*prop.clear();
        prop.setProperty("keyid1", sampleids);
        try {
            getActionProcessor().processAction("CompletePreExtraction", "1", prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in rule.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }*/
        //throw new SapphireException("test");

    }

    private DataSet getAllHNENUnstainedSlides(String sampleids) throws SapphireException {
        if (isNull(sampleids))
            throw new SapphireException("No sampleids found");
        DataSet dsReturn = null;
        String inputSamples[] = sampleids.split(";");

        StringBuilder sqlHNEWithParent = new StringBuilder();
        sqlHNEWithParent.append("select destsampleid from s_samplemap where destsampleid in('");
        sqlHNEWithParent.append(StringUtil.replaceAll(sampleids, ";", "','"));
        sqlHNEWithParent.append("')");
        DataSet dsHNEWithParent = getQueryProcessor().getSqlDataSet(sqlHNEWithParent.toString());
        if (dsHNEWithParent == null)
            throw new SapphireException("Error: Unable to perform query in database\n" + sqlHNEWithParent.toString());
        if (dsHNEWithParent.size() > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("select sm.destsampleid as sampleid from s_samplemap sm,s_sample s ");
            sb.append("where s.s_sampleid=sm.destsampleid and sourcesampleid in ");
            sb.append("(select unique(sourcesampleid) from s_samplemap where destsampleid in('");
            sb.append(StringUtil.replaceAll(dsHNEWithParent.getColumnValues("destsampleid", ";"), ";", "','"));
            sb.append("'))");
            dsReturn = getQueryProcessor().getSqlDataSet(sb.toString());
            if (dsReturn == null)
                throw new SapphireException("Error: Unable to perform query in database\n" + sb.toString());
            if (dsReturn.size() == 0)
                throw new SapphireException("No parent found for HNE samples\nSQL: " + sb.toString());

            //Find HNE samples that does not have entry in samplemap and add them to the DataSet
            HashMap<String, String> hmFilter = new HashMap<>();
            for (int i = 0; i < inputSamples.length; i++) {
                hmFilter.clear();
                hmFilter.put("destsampleid", inputSamples[i]);
                if (dsHNEWithParent.getFilteredDataSet(hmFilter).size() == 0) {
                    int row = dsReturn.addRow();
                    dsReturn.setValue(row, "sampleid", inputSamples[i]);
                }
            }
        }
        if (dsHNEWithParent.size() == 0) {
            if (dsReturn == null) {
                dsReturn = new DataSet();
                dsReturn.addColumn("sampleid", DataSet.STRING);
            }
            for (int i = 0; i < inputSamples.length; i++) {
                int row = dsReturn.addRow();
                dsReturn.setValue(row, "sampleid", inputSamples[i]);
            }
        }
        return dsReturn;
    }

    private DataSet dsHNESamples(String sampleids) throws SapphireException {
        DataSet dsHNESamples = null;
        String sql = Util.parseMessage(MolecularSql.GET_HNE_SAMPLE_FR_PATHOLOGY_REV, StringUtil.replaceAll(sampleids, ";", "','"));
        /*String sql = "select s.s_sampleid as sampleid,st.methodology as methodology,s.u_qns from s_sample s, u_sampletestcodemap st where s.s_sampleid=st.s_sampleid" +
                " and st.methodology in('Molecular','FISH') and s.s_sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";*/
        dsHNESamples = getQueryProcessor().getSqlDataSet(sql);
        return dsHNESamples;
    }

    private void createIncident(String departmentSite, String sampleids) throws SapphireException {
        String dept = departmentSite + "-ClientServices";
        String department = deptValidate(dept);
        String sql = "select s_sampleid,u_clientspecimenid,u_accessionid,u_qns from s_sample where s_sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "')";
        DataSet dsqns = getQueryProcessor().getSqlDataSet(sql);
        if (dsqns == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsqns.size() == 0) {
            String errStr = getTranslationProcessor().translate("Selected saple not found in LV database.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        HashMap hm = new HashMap();
        hm.put("u_qns", "Y");
        DataSet dsFilterQns = dsqns.getFilteredDataSet(hm);
        if (dsFilterQns.size() > 0) {
            for (int i = 0; i < dsFilterQns.size(); i++) {

                String msg = "For the bellow sample(s) quantity not sufficient. Contact customer. \n Sample -" + dsFilterQns.getString(i, "s_sampleid") + ", Block id " + dsFilterQns.getString(i, "u_clientspecimenid")
                        + ",Accession id # " + dsFilterQns.getString(i, "u_accessionid");
                PropertyList recordProp = new PropertyList();
                recordProp.setProperty("sourcesdcid", "Sample");
                recordProp.setProperty("sourcekeyid1", dsFilterQns.getString(i, "s_sampleid"));
                recordProp.setProperty("incidentcategory", "UnPlanned");
                recordProp.setProperty("incidentdesc", "Quantity not sufficient. Contact customer.");
                recordProp.setProperty("explanation", "Stain Qc request." + msg);
                recordProp.setProperty("rootcause", "Stain Qc request." + msg);
                recordProp.setProperty("u_fromdepartment", connectionInfo.getDefaultDepartment());
                recordProp.setProperty("initialstatus", "PendingApproval");
                recordProp.setProperty("reportedby", connectionInfo.getSysuserId());
                recordProp.setProperty("u_message", msg);
                recordProp.setProperty("departmentid", department);

                getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);
                PropertyList approvalProps = new PropertyList();
                approvalProps.setProperty("sdcid", "LV_Incdt");
                approvalProps.setProperty("keyid1", recordProp.getProperty("newkeyid1"));
                approvalProps.setProperty("pendingapprovalstatus", "PendingApproval");
                approvalProps.setProperty("approvalstatus", "Approved");
                approvalProps.setProperty("approvalstatuscolumn", "incidentstatus");
                getActionProcessor().processAction(SubmitSDIForApproval.ID, SubmitSDIForApproval.VERSIONID, approvalProps);
            }
        }
    }

    /**
     * Description : This method will check department is valid or not.
     *
     * @param siteDept
     * @return
     * @throws SapphireException
     */
    private String deptValidate(String siteDept) throws SapphireException {
        String site = siteDept.substring(0, siteDept.indexOf("-"));
        String targetDept = siteDept.substring(siteDept.indexOf("-") + 1, siteDept.length());
        String department = "";
        String dept = "select departmentid from department where departmentid='" + siteDept + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor().translate(targetDept + " Department not found in site " + site);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
        }
        return department;
    }

    private void populateTumorCercledValueOnUSS(DataSet dsSql) throws SapphireException {
        DataSet dsAllSlides = null;
        if (dsSql.size() > 0) {
            String accessionid = Util.getUniqueList(dsSql.getColumnValues("u_accessionid", ";"), ";", true);
            String sql = Util.parseMessage(MolecularSql.GET_ALL_SAMPLE_FR_PATHOLOGY_REV_ACCESSION, StringUtil.replaceAll(accessionid, ";", "','"));
            dsAllSlides = getQueryProcessor().getSqlDataSet(sql);
        }
        for (int i = 0; i < dsSql.size(); i++) {
            String u_type = dsSql.getValue(i, "u_type", "");
            String u_rootsample = dsSql.getValue(i, "u_rootsample", "");
            String u_clientspecimenid = dsSql.getValue(i, "u_clientspecimenid", "");
            String u_tumorcircled = dsSql.getValue(i, "u_tumorcircled", "");
            String u_accessionid = dsSql.getValue(i, "u_accessionid", "");
            HashMap hm = new HashMap();
            if ("H".equalsIgnoreCase(u_type) || "SH".equalsIgnoreCase(u_type)) {

                hm.clear();
                hm.put("u_rootsample", u_rootsample);
                hm.put("u_accessionid", u_accessionid);
                hm.put("u_type", "U");
                DataSet dsUSSFilter = dsAllSlides.getFilteredDataSet(hm);
                if (dsUSSFilter.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsUSSFilter.getColumnValues("sampleid", ";"));
                    props.setProperty("u_tumorcircled", StringUtil.repeat(u_tumorcircled, dsUSSFilter.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to complete H&E review." + ex.getMessage());
                    }
                }
            } else if ("CH".equalsIgnoreCase(u_type)/* || "SH".equalsIgnoreCase(u_type)*/) {
                hm.clear();
                hm.put("u_accessionid", u_accessionid);
                hm.put("u_type", "CU");
                DataSet dsClientUSSFilter = dsAllSlides.getFilteredDataSet(hm);
                if (dsClientUSSFilter.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsClientUSSFilter.getColumnValues("sampleid", ";"));
                    props.setProperty("u_tumorcircled", StringUtil.repeat(u_tumorcircled, dsClientUSSFilter.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to complete H&E review." + ex.getMessage());
                    }
                }
            }
        }

    }
}