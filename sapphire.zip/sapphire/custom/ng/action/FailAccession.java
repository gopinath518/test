package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class FailAccession extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1", "");
        String accessionfailedby = properties.getProperty("accessionfailedby", "");

        String sql = Util.parseMessage(ApSql.GET_ACCESSION_INFO_BY_ACCESSIONID, keyid1);
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo == null || dsInfo.size() == 0) {
            throw new SapphireException("Invalid accession");
        }
        String status = dsInfo.getValue(0, "status", "");
        if ("In Progress".equalsIgnoreCase(status)) {
            throw new SapphireException("You can't proceed further as this accession is already been generated.");
        }
        if ("Completed".equalsIgnoreCase(status)) {
            throw new SapphireException("You can't proceed further as this accession is already been completed.");
        }
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
        props.setProperty("status", "In Progress- QC Failed");
        props.setProperty("accessionfailedby", accessionfailedby);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Execution failed to update.Reason: " + ex.getMessage());
        }
    }
}
