package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.CopySDIAttachment;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 6/15/2016.
 */
public class NGSIlluminaCopy extends BaseAction {

    /*
    *   OOB method to override for copy of batch
    * */
    public void processAction(PropertyList properties) throws SapphireException {

        String batchmovestatus = "DiscoveryIlluminaDay2";
        String day = properties.getProperty("day");
        String batchid = properties.getProperty("batchid");
        String batchname = properties.getProperty("batchname");
        String str = "";
        if (day.equalsIgnoreCase("2"))
            str = MolecularSql.NGSILLUMINACOPY_POOL_SQL;
        else
            str = MolecularSql.NGSILLUMINACOPY_SQL;

        DataSet dsbatch = getQueryProcessor().getSqlDataSet(Util.parseMessage(str, batchid));

        batchmovestatus = day.equalsIgnoreCase("1") ? "DiscoveryIlluminaDay2" : (day.equalsIgnoreCase("2") ? "DiscoveryIlluminaDay3" : "DiscoveryIlluminaDay2");

        PropertyList prop = new PropertyList();
        try {

            prop.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
            prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
            prop.setProperty("batchname", batchname);
            prop.setProperty("parentbatchid", batchid);
            prop.setProperty("batchmovestatus", batchmovestatus);
            prop.setProperty("batchtype", "NGS");
            prop.setProperty("origin", batchmovestatus);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);

        } catch (SapphireException e) {
            String er = getTranslationProcessor().translate(batchname + "  Batch is not created ");
            throw new SapphireException(er + e.getMessage());
        }

        String ngbatchid = prop.getProperty("newkeyid1");

        String allSample = "";
        String allPlate = "";
        if (dsbatch != null && dsbatch.getRowCount() > 0) {
            for (int i = 0; i < dsbatch.getRowCount(); i++) {
                allSample = allSample + ";" + dsbatch.getString(i, "sampleid", "");
            }
            associateSample(ngbatchid, dsbatch);
        }

        dsbatch = getQueryProcessor().getSqlDataSet(Util.parseMessage(MolecularSql.NGSILLUMINACOPY_BATCH_PLATE, batchid));
        if (dsbatch != null && dsbatch.getRowCount() > 0) {
            //allNewbatch="";
            for (int i = 0; i < dsbatch.getRowCount(); i++) {
                //allNewbatch = allNewbatch + ";" + ngbatchid;
                allPlate = allPlate + ";" + dsbatch.getString(i, "plateid", "");
            }
            associatePlate(ngbatchid, dsbatch.getColumnValues("plateid", ";"));
        }


        PropertyList plAttachment = new PropertyList();
        plAttachment.setProperty(CopySDIAttachment.PROPERTY_FROMSDCID, "NGBatch");
        plAttachment.setProperty(CopySDIAttachment.PROPERTY_FROMKEYID1, batchid);
        plAttachment.setProperty(CopySDIAttachment.PROPERTY_TOSDCID, "NGBatch");
        plAttachment.setProperty(CopySDIAttachment.PROPERTY_TOKEYID1, ngbatchid);

    }

    /*
    *   This methos associate sample with the batch
    *
    *   @param  ngbatchid  NGS batch id
     *  @param  dsBatch     Data set of sample of the batch
    * */
    private void associateSample(String ngbatchid, DataSet dsBatch) throws SapphireException {
        PropertyList sampleprop = new PropertyList();
        sampleprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        sampleprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        sampleprop.setProperty("sampleid", dsBatch.getColumnValues("sampleid", ";"));
        sampleprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

        sampleprop.setProperty("tagid", dsBatch.getColumnValues("tagid", ";"));
        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, sampleprop);
    }


    /*
    *   This method associates pate to the batch
    *
    *   @param  ngbatchid  NGS batch is
    *   @param  plateids    plate id to be associated with batch
    * */
    private void associatePlate(String ngbatchid, String plateids) throws SapphireException {
        PropertyList reagentprop = new PropertyList();
        reagentprop.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        reagentprop.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngbatchid);
        reagentprop.setProperty("plateid", plateids);
        reagentprop.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, reagentprop);
    }
}

