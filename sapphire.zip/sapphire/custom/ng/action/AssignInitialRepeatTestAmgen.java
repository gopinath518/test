package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

public class AssignInitialRepeatTestAmgen extends BaseAction {
    /**
     * @param properties
     * @throws SapphireException
     */
    public void processAction(PropertyList properties) throws SapphireException {
        String sample = properties.getProperty("sampleid");
        if (Util.isNull(sample)) {
            throw new SapphireException("Please select specimen(s).");
        }
        String sampleid = StringUtil.replaceAll(sample, ";", "','");
        String option = properties.getProperty("option");
        option = Util.getUniqueList(option, ";", true);
        //DataSet dsTestCodePolicy = getTestCodePolicy();//TODO WILL REMOVED AS THIS WILL TAKEN CARE FROM SDC AnalyteTcValidation
        DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "Initial or Repeat");
        if (dsTestCodePolicy.size() == 0) {
            throw new SapphireException("No Testcode(s) found for Initial/Repeat into LV system.");
        }
        String specialtestcodes = StringUtil.replaceAll(dsTestCodePolicy.getColumnValues("testcode", ";"), ";", "','");
        String sqltestcode = Util.parseMessage(ApSql.GET_SPECIMENS_BY_SPECIMEN_TESTCODE, sampleid, specialtestcodes);
        DataSet ds = getQueryProcessor().getSqlDataSet(sqltestcode);
        if (ds.size() > 0) {
            sampleid = StringUtil.replaceAll(ds.getColumnValues("s_sampleid", ";"), ";", "','");
            String testname = StringUtil.replaceAll(ds.getColumnValues("testname", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_ANALYTE_BY_SAMPLE_PARAM, sampleid, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", StringUtil.repeat(option, dsSqlEnterData.size(), ";"));
                props.setProperty("displayvalue", StringUtil.repeat(option, dsSqlEnterData.size(), ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        } else {
            throw new SapphireException("Associate testcode(s) does not support to choose Initial/Repeat Option");
        }
        /*} else {
            throw new SapphireException("Specimen is not attached with any test code");
        }*/
        properties.setProperty("msg", "<b>Status has been updated for specimen(s): " + StringUtil.replaceAll(sampleid, "','", ", ") + "</b>");

    }
}
