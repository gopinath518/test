package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by dkundu on 11/4/2016.
 */
public class AssignToDoctor extends BaseAction {
    /**
     * @param properties
     * @throws SapphireException
     */
    public void processAction(PropertyList properties) throws SapphireException {
        if (properties == null || properties.size() == 0)
            throw new SapphireException("PropertyList does not contain any property");
        String assignedDoctor = Util.getUniqueList(properties.getProperty("u_assignedtodoctor"), ";", true);
        String sampleid = properties.getProperty("keyid1");

        if (sampleid == null || assignedDoctor == null)
            throw new SapphireException("Error: Insufficient values in PropertyList");

        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            props.setProperty("u_assignedtodoctor", assignedDoctor);
            props.setProperty("u_assigndoctordt", "n");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);

        } catch (SapphireException e) {
            String error = getTranslationProcessor().translate("Can't update movement step in sample");
            error += e.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
