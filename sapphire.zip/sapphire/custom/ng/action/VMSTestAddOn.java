package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 7/25/2016.
 */
public class VMSTestAddOn extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("externalimageidentifier");
        String imageid = properties.getProperty("imageid");
        String testcode = properties.getProperty("testcode");
        String userid = properties.getProperty("userid");
        String version = properties.getProperty("version");
        PropertyList props = new PropertyList();

        props.setProperty("s_sampleid", sampleid);
        props.setProperty("lvtestcode", testcode);
        props.setProperty("ispanel", "N");
        props.setProperty("workitemflag", "Y");
        props.setProperty("bypassvalidation", "Y");
        props.setProperty("imageid", imageid);
        props.setProperty("userid", userid);
        props.setProperty("version", version);
        //getActionProcessor().processAction("AddTestCode", "1", props);

       /* DataSet dsVms = getQueryProcessor().getSqlDataSet("select * from u_vmsimageregion where s_sampleid = '"+sampleid+"' and regionid='"+regionid+"' and displayid='"+displayid+"'");
        if(null != dsVms  && dsVms.getRowCount()>0){
            properties.setProperty("newkeyid", dsVms.getString(0,"aperiostatusid"));
        }
        props.setProperty("newProp", properties);*/
       // System.out.println("new props=   == xml " + props.toXMLString());
       // logger.info("Dharam  =props   xml  " + props.toXMLString() );
    }
}
