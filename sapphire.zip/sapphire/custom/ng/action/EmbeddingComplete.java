package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class EmbeddingComplete extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1", "");
        String u_type = properties.getProperty("u_type", "");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep", "");
        String u_currenttramstop = properties.getProperty("u_currenttramstop", "");
        if (Util.isNull(keyid1)) {
            throw new SapphireException("Specimen(s) can't be blank.");
        }
        String sql = Util.parseMessage(ApSql.GET_RECEIVEDFROM_DATE_BY_SAMPLEID, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsRecvdFrmDt = getQueryProcessor().getSqlDataSet(sql);
        if (dsRecvdFrmDt.size() == 0) {
            throw new SapphireException("Please provide <b>Received From</b> date for below specimen(s):\n"+StringUtil.replaceAll(keyid1, ";", ", "));
        }
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
        props.setProperty("u_type", u_type);
        props.setProperty("u_currentmovementstep", u_currentmovementstep);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Failed to update Specimen(s)." + ex.getMessage());
        }
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, keyid1);
        props.setProperty("u_currenttramstop", u_currenttramstop);
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("Failed to update TrackItem." + ex.getMessage());
        }
    }
}
