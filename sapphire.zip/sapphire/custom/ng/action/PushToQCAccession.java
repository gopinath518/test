package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.accession.AccessionPageSql;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by SBaitalik on 8/4/2017.
 */
public class PushToQCAccession extends BaseAction {
    String msg = "Operation Successful.";

    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("keyid1", "");
        String accessionstatussql = Util.parseMessage(AccessionPageSql.GET_ACCESSION_STATUS_BY_ACCESSIONID_SQL, accessionid);
        DataSet dsAccessionStatus = getQueryProcessor().getSqlDataSet(accessionstatussql);
        //TODO WILL OPEN AFTER GETTING APPROVAL FOR PROJECT/TESTCODE VALIDATION FROM BUSINESS.
        //validatePendingSample(accessionid);TODO NOT REQUIRED AS IF DONT HAVE PENDING SAMPLE.
        validateProjectTestcode(dsAccessionStatus, accessionid);
        validateTestcodeOnSlide(accessionid);
        if (dsAccessionStatus != null && dsAccessionStatus.size() > 0) {
            String accessionstatus = dsAccessionStatus.getValue(0, "status", "");
            if ("On Hold".equalsIgnoreCase(accessionstatus)) {
                throw new SapphireException("Unable to proceed because accession status is on hold.");
            } else if ("Completed".equalsIgnoreCase(accessionstatus)) {
                throw new SapphireException("Unable to proceed because accession is already got completed.");
            } else if ("Accession QC Pending".equalsIgnoreCase(accessionstatus)) {
                throw new SapphireException("Accession has already been pushed to QC.");
            } else {
                String currentuser = connectionInfo.getSysuserId();
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, accessionid);
                prop.setProperty("status", "Accession QC Pending");
                prop.setProperty("accessionqcby", currentuser);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                } catch (SapphireException se) {
                    throw new SapphireException("QC failed");
                }
                /*TODO:: Storing sample issue::START*/
                String query = AccessionPageSql.GET_SAMPLEINFO_INCLD_TESTS_BY_ACCESSION;
                DataSet ds = getQueryProcessor().getPreparedSqlDataSet(query, new Object[]{accessionid});
                prop.clear();
                prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
                prop.setProperty("custodialuserid", "(null)");
                try {
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
                } catch (SapphireException se) {
                    throw new SapphireException("QC failed");
                }
                /*TODO:: Storing sample issue::END*/
            }
        }
    }

    private void validateProjectTestcode(DataSet dsAccessionStatus, String accessionid) throws SapphireException {
        String projectid = dsAccessionStatus.getValue(0, "bioprojectname", "");
        if (Util.isNull(projectid)) {
            throw new SapphireException("Please add project.");
        }
        String sql = Util.parseMessage(AccessionPageSql.GET_TESTCODE_BYACCESSIONID, accessionid);
        DataSet dsTestcodes = getQueryProcessor().getSqlDataSet(sql);
        String projectstestcode = StringUtil.replaceAll(dsTestcodes.getColumnValues("lvtestcodeid", ";"), ";", "','");
        sql = Util.parseMessage(AccessionPageSql.GET_TESTCODES_BY_PROJECTID, projectid, projectstestcode, projectstestcode);
        DataSet dsProjectsTestcode = getQueryProcessor().getSqlDataSet(sql);
        if (dsProjectsTestcode == null || dsProjectsTestcode.size() == 0) {
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Project and testcode(s) combination does not matched. You can't proceed.");
        }
        if (dsTestcodes != null && dsTestcodes.size() > 0) {
            DataSet dsTestCodeVal = new DataSet();
            dsTestCodeVal.addColumn("project_id", DataSet.STRING);
            dsTestCodeVal.addColumn("specimen_id", DataSet.STRING);
            dsTestCodeVal.addColumn("testcode_id", DataSet.STRING);
            for (int i = 0; i < dsTestcodes.size(); i++) {
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("u_testcodeid", dsTestcodes.getValue(i, "lvtestcodeid", ""));
                DataSet dsTestFilter = dsProjectsTestcode.getFilteredDataSet(hm);
                if (dsTestFilter.size() == 0) {
                    int rowId = dsTestCodeVal.addRow();
                    dsTestCodeVal.setValue(rowId, "project_id", dsTestcodes.getValue(i, "projectprotocolid", ""));
                    dsTestCodeVal.setValue(rowId, "specimen_id", dsTestcodes.getValue(i, "s_sampleid", ""));
                    dsTestCodeVal.setValue(rowId, "testcode_id", dsTestcodes.getValue(i, "lvtestcodeid", ""));

                }
            }
            if (dsTestCodeVal.size() > 0) {
                String errCodes = "Unable to proceed because below testcode(s) does not matches with project label. Please select correct testcode(s).";
                errCodes += Util.getDisplayMessage(dsTestCodeVal);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errCodes);
            }
        }
    }

    private void validateTestcodeOnSlide(String accessionid) throws SapphireException {
        DataSet dsMessage = new DataSet();
        dsMessage.addColumn("sampleid", DataSet.STRING);
        dsMessage.addColumn("testcode", DataSet.STRING);
        String sql = Util.parseMessage(AccessionPageSql.GET_VALIDATE_TCODE, accessionid);
        DataSet dsTcode = getQueryProcessor().getSqlDataSet(sql);
        if (dsTcode != null && dsTcode.size() > 0) {
            dsTcode.sort("s_sampleid");
            ArrayList<DataSet> dsFinalArr = dsTcode.getGroupedDataSets("s_sampleid");
            for (int i = 0; i < dsFinalArr.size(); i++) {
                DataSet dsEach = (DataSet) dsFinalArr.get(i);
                if (dsEach.size() > 1) {
                    for (int c = 0; c < dsEach.size(); c++) {
                        int rowid = dsMessage.addRow();
                        dsMessage.setValue(rowid, "sampleid", dsEach.getValue(c, "s_sampleid", ""));
                        dsMessage.setValue(rowid, "testcode", dsEach.getValue(c, "lvtestcodeid", ""));
                    }
                }
            }
        }
        if (dsMessage != null && dsMessage.size() > 0) {
            String errCodes = "Duplicate/More than one testcode(s) associated with the below slide(s).";
            errCodes += Util.getDisplayMessage(dsMessage);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errCodes);
        }
    }

    private void validatePendingSample(String accessionid) throws SapphireException {
        String sqlVal = Util.parseMessage(ApSql.GET_SAMPLE_BY_ACCESSIONID, accessionid);
        DataSet dsVal = getQueryProcessor().getSqlDataSet(sqlVal);
        if (dsVal != null && dsVal.size() == 0) {
            throw new SapphireException("<b>Accession does not have specimen(s).</b>");
        }
        HashMap hmv = new HashMap();
        hmv.put("u_accessioningcomplete", "N");
        DataSet dsFilV = dsVal.getFilteredDataSet(hmv);
        if (dsFilV != null && dsFilV.size() == 0) {
            throw new SapphireException("<b>There is no specimen(s) pending to QCed the accession.</b>");
        }
    }
}
