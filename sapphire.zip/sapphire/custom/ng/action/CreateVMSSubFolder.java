package sapphire.custom.ng.action;

import java.io.File;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

public class CreateVMSSubFolder extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        //String folderpath = properties.getProperty("folderpath", "");
        String folderid = properties.getProperty("u_vmsfolderid", "");
        //String rootpath = properties.getProperty("rootpath", "");
        String subfoldername = properties.getProperty("subfoldername", "");
        String sql = Util.parseMessage(ApSql.GET_DETAILS_BY_FOLDERID, folderid);
        DataSet dsFolderInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsFolderInfo == null || dsFolderInfo.size() == 0) {
            String errMsg = getTranslationProcessor().translate("This folder doesn't exist into the system.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        //String defaultdepartment = connectionInfo.getDefaultDepartment();
        //String site = StringUtil.split(defaultdepartment, "-")[0];
        String rootpath = "";
        //getRootPathFromPolicy();

        /*HashMap hm = new HashMap();
        hm.clear();
        hm.put("site", site);
        DataSet dsImagePathFilter = dsFolderPath.getFilteredDataSet(hm);
        if (dsImagePathFilter == null || dsImagePathFilter.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Root path can't defined according to the site.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }*/
        rootpath = dsFolderInfo.getValue(0, "rootfolder", "");
        //String folderpath = dsFolderInfo.getValue(0, "folderpath", "");
        //GET WINDOWN MAPPING PATH FROM DB
        DataSet dsMountedPath = getMountedPath();
        HashMap hm = new HashMap();
        hm.clear();
        /*hm.put("windowspath", rootpath);
        DataSet dsFolderFilter = dsMountedPath.getFilteredDataSet(hm);
        if (dsFolderFilter.size() == 0) {
            String errMsg = getTranslationProcessor().translate(rootpath + " directory not found.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }*/
        String serverpath = dsMountedPath.getValue(0, "mounteddrive");
        //String rootpath = dsFolderInfo.getValue(0, "rootfolder", "");
        if (Util.isNull(rootpath)) {
            String errMsg = getTranslationProcessor().translate("Root path can't be null.Please contact to Admin to provide a root path in configaration.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String folderpath = dsFolderInfo.getValue(0, "folderpath", "");
        String sponsorid = dsFolderInfo.getValue(0, "sponsorid", "");
        String projectid = dsFolderInfo.getValue(0, "projectid", "");
        if (!Util.isNull(folderid)) {
            if (Util.isNull(folderpath)) {
                String errMsg = getTranslationProcessor().translate("Folder path can't be null for the folder Id:" + folderid);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            File existingDir = new File(serverpath);
            if (!existingDir.isDirectory()) {
                String errMsg = getTranslationProcessor().translate(folderpath + " This is not valid directory.You can't create any subfolder here.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }//TODO WILL OPEN WHEN RUN INTO SBX
        } else {
            File existingDir = new File(serverpath);
            if (!existingDir.isDirectory()) {
                String errMsg = getTranslationProcessor().translate(rootpath + " This root path is not valid directory.You can't create any subfolder here.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            folderpath = rootpath;
        }

        if (Util.isNull(subfoldername)) {
            String errMsg = getTranslationProcessor().translate("Please provide a folder name.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String finalserverfolderpath = folderpath + "/" + subfoldername;
        finalserverfolderpath = StringUtil.split(finalserverfolderpath, rootpath)[1];
        finalserverfolderpath = StringUtil.replaceAll(finalserverfolderpath, "\\", "/");
        String servdir = serverpath + "" + finalserverfolderpath;
        String finalfolderpath = folderpath + "\\" + subfoldername;
        File theDir = new File(servdir);
        if (theDir.exists() && theDir.isDirectory()) {
            String errMsg = getTranslationProcessor().translate("Folder already exists.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);

        } else {
            theDir = new File(servdir);
            boolean successful = theDir.mkdir();
            if (!successful) {
                String errMsg = getTranslationProcessor().translate("Failed to create the directory.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            } else {
                sql = Util.parseMessage(IHCSql.GET_ROOTFOLDER_METHODOLOGY, StringUtil.replaceAll(folderid, ";", "','"));
                DataSet dsRootFldrsInfo = getQueryProcessor().getSqlDataSet(sql);
                String methodology = "";
                if (dsRootFldrsInfo.size() > 0) {
                    methodology = dsRootFldrsInfo.getValue(0, "methodology", "IHC");
                } else {
                    methodology = "IHC";
                }
                PropertyList props = new PropertyList();
                props.setProperty(AddSDI.PROPERTY_SDCID, "VMSFolder");
                props.setProperty(AddSDI.PROPERTY_COPIES, "1");
                props.setProperty("vmsfolderparentid", folderid);
                props.setProperty("rootfolder", rootpath);
                props.setProperty("foldername", subfoldername);
                props.setProperty("folderpath", finalfolderpath);
                props.setProperty("sponsorid", sponsorid);
                props.setProperty("projectid", projectid);
                props.setProperty("type", "FLD");
                props.setProperty("methodology", methodology);
                try {
                    getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                } catch (Exception ex) {
                    throw new SapphireException("Can't create folder." + ex.getMessage());
                }
            }
        }
        //throw new SapphireException("Test");
    }

    private void getRootPathFromPolicy() throws SapphireException {
        if (dsFolderPath == null) {
            dsFolderPath = new DataSet();
            dsFolderPath.addColumn("imagepath", DataSet.STRING);
            dsFolderPath.addColumn("site", DataSet.STRING);
            PropertyList plVMSaperioPolicy = getConfigurationProcessor().getPolicy("VMSAperioIntegrationPolicy", "VMSAperioIntegration");
            if (plVMSaperioPolicy == null)
                throw new SapphireException("VMS Aperio folder path policy is not define in System Admin-> Policy.");
            PropertyListCollection plclosmap = plVMSaperioPolicy.getCollection("imagesitepathlist");
            for (int i = 0; i < plclosmap.size(); i++) {
                String imagepath = plclosmap.getPropertyList(i).getProperty("imagepath");
                String site = plclosmap.getPropertyList(i).getProperty("site");
                int rowID = dsFolderPath.addRow();
                dsFolderPath.setValue(rowID, "imagepath", imagepath);
                dsFolderPath.setValue(rowID, "site", site);
            }
        }
    }

    private DataSet getMountedPath() throws SapphireException {
        DataSet dsMountedPath = null;
        String sql = ApSql.GET_WINDOWS_MAPPING_PATH;
        dsMountedPath = getQueryProcessor().getSqlDataSet(sql);

        if (dsMountedPath == null)
            throw new SapphireException("Network path and mounted drive mapping info cannot be obtained from database.");
        if (dsMountedPath.size() == 0)
            throw new SapphireException("The Query:\n" + sql + "\n is returning no row.");

        return dsMountedPath;
    }

    private DataSet dsFolderPath = null;
}
