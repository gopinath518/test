package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by mpandey on 5/6/2016.
 * Checkout Cassette from Basket, clears currentstorage for cassette
 * input - Cassetteid
 */
public class CheckOutCassette  extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String cassetteid = properties.getProperty("cassetteid");
        String queCassette= StringUtil.replaceAll(cassetteid,";","','");
        String sql = "select trackitemid,CURRENTSTORAGEUNITID from TRACKITEM where linkkeyid1 in ('"+queCassette+"') and linksdcid= 'Cassette'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String trackitemid=ds.getColumnValues("trackitemid",";");
        updateTrackItem(trackitemid);

    }

    /**
     * This method is use to check out cassette from storage .
     * @param trackitemid
     * @throws SapphireException
     */
    private void updateTrackItem(String trackitemid) throws SapphireException {
        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("CURRENTSTORAGEUNITID", "");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        }
        catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }
}
