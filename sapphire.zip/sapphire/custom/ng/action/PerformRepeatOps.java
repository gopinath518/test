package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Created by Debasis Mondal on 8/23/2016.
 * This Action is creating multiple child sample based on value selected from dropdown box and creating extractionid
 * with appending dash sign followed by number of operation and creating repeatopsid for inserting repeatops value in
 * repeateops SDC .And also it is creating request id for drop down value Re-extract.
 * Updated tables are s_sample,s_samplemap,u_repeatops,trackitem,u_repeatopsdetail,u_repeatopsrequest and incident
 */
public class PerformRepeatOps extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String mainData = properties.getProperty("inputvalue");
        if (Util.isNull(mainData)) {
            String error = getTranslationProcessor().translate("Please select something before press Save button.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        if (!Util.isNull(mainData)) {
            initializeDataSet();
            initializeDataSetForrepeatOps();
            validateData(mainData);
            updateReportFlag();//added for set ReportFlag N.
            addSampleSdi();
            insertToSamplemap();
            getParentTestCode();
            repeatAddSdiAndDtls(dsMain);
            DataSet filterDs = filterChildSamplesToApplyTest();
            if (filterDs.size() > 0) {
                updateTrackItemSdc(filterDs);
                HashMap hm = new HashMap();
                hm.clear();
                hm.put("repeatoptions", "Repeat");
                DataSet dsRepeatFilter = filterDs.getFilteredDataSet(hm);
                if (dsRepeatFilter != null && dsRepeatFilter.size() > 0) {
                    applyTestCodesToChildRepeat(dsRepeatFilter);
                }
                hm.clear();
                hm.put("repeatoptions", "Re-Extract");
                DataSet dsReExtractFilter = filterDs.getFilteredDataSet(hm);
                if (dsReExtractFilter != null && dsReExtractFilter.size() > 0) {
                    applyTestCodesToChild(dsReExtractFilter);
                }
                copyDataItemValuesToChildDataSet(filterDs);
            }
            if (dsMainOpsRequest.size() > 0) {
                insertToRepeatOpsRequest();
                updateLV_Incdt();
            }
            DataSet dsShowMsg = new DataSet();
            //dsShowMsg.addColumn("requested_specimen_id", DataSet.STRING);
            dsShowMsg.addColumn("req._extraction_id", DataSet.STRING);
            dsShowMsg.addColumn("gen._specimen_id", DataSet.STRING);
            dsShowMsg.addColumn("gen._extraction_id", DataSet.STRING);
            dsShowMsg.addColumn("operations", DataSet.STRING);
            dsShowMsg.addColumn("analytes", DataSet.STRING);
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("repeatoptions", "Repeat");
            DataSet dsRepeatFilter = dsMain.getFilteredDataSet(hm);

            hm.clear();
            hm.put("repeatoptions", "Re-Extract");
            DataSet dsReExtractFilter = dsMain.getFilteredDataSet(hm);
            if (dsRepeatFilter.size() > 0) {
                /*properties.setProperty("genextractionid", dsRepeatFilter.getColumnValues("repeatextraction", ";"));
                properties.setProperty("childsample", dsRepeatFilter.getColumnValues(DATASET_PROPERTY_GENSAMPLE_ID, ";"));
                properties.setProperty("request", dsRepeatFilter.getColumnValues("s_sampleid", ",") + " has been moved to Pre-Extraction.");*/
                for (int i = 0; i < dsRepeatFilter.size(); i++) {
                    int rowID = dsShowMsg.addRow();
                    //dsShowMsg.setValue(rowID, "requested_specimen_id", dsRepeatFilter.getValue(i, "s_sampleid", ""));
                    dsShowMsg.setValue(rowID, "req._extraction_id", dsRepeatFilter.getValue(i, "extractionid", ""));
                    dsShowMsg.setValue(rowID, "gen._specimen_id", dsRepeatFilter.getValue(i, DATASET_PROPERTY_GENSAMPLE_ID, ""));
                    dsShowMsg.setValue(rowID, "gen._extraction_id", dsRepeatFilter.getValue(i, DATASET_PROPERTY_REPEATEXTRACTION, ""));
                    dsShowMsg.setValue(rowID, "operations", dsRepeatFilter.getValue(i, "repeatoptions", ""));
                    dsShowMsg.setValue(rowID, "analytes", dsRepeatFilter.getValue(i, "analyte", ""));
                }
            }
            if (dsReExtractFilter.size() > 0) {
                DataSet dsAllSlides = createMicrodissectionRule();//TODO WILL OPEN WHEN CODE WILL MOVE TO SANDBOX1 FOR RE-EXTRACT(1.3.1 Release)
                if (dsAllSlides.size() == 0) {
                    properties.setProperty("genextractionid", dsReExtractFilter.getColumnValues("repeatextraction", ";"));
                    properties.setProperty("childsample", dsReExtractFilter.getColumnValues(DATASET_PROPERTY_GENSAMPLE_ID, ";"));
                    properties.setProperty("request", "You don't have Un-Scrapped slide(s), please cut slide(s) for this operation.");
                } else {
                    /*for (int i = 0; i < dsReExtractFilter.size(); i++) {
                        int rowID = dsShowMsg.addRow();
                        //dsShowMsg.setValue(rowID, "requested_specimen_id", dsReExtractFilter.getValue(i, "s_sampleid", ""));
                        dsShowMsg.setValue(rowID, "req._extraction_id", dsReExtractFilter.getValue(i, "extractionid", ""));
                        dsShowMsg.setValue(rowID, "gen._specimen_id", dsReExtractFilter.getValue(i, DATASET_PROPERTY_GENSAMPLE_ID, "N/A"));
                        dsShowMsg.setValue(rowID, "gen._extraction_id", dsReExtractFilter.getValue(i, DATASET_PROPERTY_REPEATEXTRACTION, "N/A"));
                        dsShowMsg.setValue(rowID, "operations", dsReExtractFilter.getValue(i, "repeatoptions", ""));
                        dsShowMsg.setValue(rowID, "analytes", dsReExtractFilter.getValue(i, "analyte", ""));
                    }*/
                    properties.setProperty("genextractionid", dsReExtractFilter.getColumnValues("repeatextraction", ";"));
                    properties.setProperty("childsample", dsReExtractFilter.getColumnValues(DATASET_PROPERTY_GENSAMPLE_ID, ";"));
                    properties.setProperty("request", dsAllSlides.getColumnValues("s_sampleid", ",") + " has been moved to Molecular COC.");
                }
            }
            if (dsShowMsg.size() > 0) {
                String disMsg = Util.getDisplayMessage("Operation Successful.", dsShowMsg);
                properties.setProperty("msg", disMsg);
            }
            if (dsShowMsg.size() == 0) {
                properties.setProperty("msg", "");
            }
        }
    }

    /**
     * Description: validateData() method used for checking input data format that is coming from jsp and creating
     * a main data set with that values.Based on dropdown value except Re-Extract it is creating
     * different extraction ids.If drop down selected value is With/WO LNA then it will create two different extraction id
     * one is for With/WO LNA and another is for Without LNA.For Re-Extract it will create requestid.
     *
     * @return ds - dataset
     * @throws SapphireException
     */
    private void validateData(String mainData) throws SapphireException {
        String userDepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String[] allData = StringUtil.split(mainData, "`");
        if (allData.length == 1 || allData.length == 0) {
            String error = getTranslationProcessor().translate("Data is not valid");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        int rowIncrement = 0;
        int incRow = 0;
        for (int i = 1; i < allData.length; i++) {
            String[] allColData = StringUtil.split(allData[i], "|");
            String PrntSampleid = allColData[0];
            if (PrntSampleid.length() == 0) {
                String error = getTranslationProcessor().translate("Sample Id not valid");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String PrntExtractionid = allColData[1];
            if (PrntExtractionid.length() == 0) {
                String error = getTranslationProcessor().translate("Extraction Id not valid");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String analyte = allColData[2];
            if (analyte.length() == 0) {
                String error = getTranslationProcessor().translate("Please select an Analyte.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
            String comments = allColData[5];

            String selectedDropDwnVal = allColData[3];
            String[] dropdownVal = StringUtil.split(selectedDropDwnVal, ";");
            if (dropdownVal.length == 1 || dropdownVal.length == 0) {
                String error = getTranslationProcessor().translate("Please select from dropdown");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }

            String parentContainer = parentContainerType(PrntSampleid);
            String repeatExtraction = PrntExtractionid;
            List<String> listOfoperation = new ArrayList<String>();
            for (int dropDwnValCount = 1; dropDwnValCount < dropdownVal.length; dropDwnValCount++) {
                if ((dropdownVal[dropDwnValCount]).equalsIgnoreCase("With/WO LNA")) {
                    listOfoperation.add("With/WO LNA");
                    listOfoperation.add("Without LNA");
                } else {
                    listOfoperation.add(dropdownVal[dropDwnValCount]);
                }
            }

            if (listOfoperation.size() > 1) {
                //multiple sample
                for (int j = 0; j < listOfoperation.size(); j++) {
                    rowIncrement = dsMain.addRow();
                    String singleOperation = listOfoperation.get(j).toString();
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_COMMENTS, comments);
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_SAMPLE_ID, PrntSampleid);
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_ANALYTE, analyte); // Can be semi colon sepered data eg. EXON 18; EXON 19
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_REPEATOPTIONS, singleOperation);
                    if ("Repeat".equalsIgnoreCase(singleOperation)) {
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "R");
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                        repeatExtraction = checkForExtraction(PrntExtractionid, "R");
                        addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                    } else if ("Purification".equalsIgnoreCase(singleOperation)) {
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "Q");
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                        repeatExtraction = checkForExtraction(PrntExtractionid, "Q");
                        addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                    } else if ("Without LNA".equalsIgnoreCase(singleOperation)) {
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "WO");
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                        repeatExtraction = checkForExtraction(PrntExtractionid, "WO");
                        addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                    } else if ("With/WO LNA".equalsIgnoreCase(singleOperation)) {
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "W");
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                        repeatExtraction = checkForExtraction(PrntExtractionid, "W");
                        addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                    } else if ("Re-Extract".equalsIgnoreCase(singleOperation)) {
                        String extractionidForRx = getParentExtractionForRX(PrntExtractionid);
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "RX");
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, extractionidForRx);
                        //String requestid = createRequestId(PrntSampleid); old
                        DataSet dsChkSampleType = rootForIncidentAndRecut(PrntExtractionid);
                        String requestid = createRequestId(dsChkSampleType, userDepartment);
                        addToDataSet(dsMain, rowIncrement, "", requestid, "", "N", "");
                        String ussFound = allColData[6];
                        int yesorMorePressed = Integer.valueOf(ussFound);
                        DataSet dsNoOfUsslides = noOfUnScrappedsSlide(PrntExtractionid);

                        if (yesorMorePressed == 0) {//If yesorMorePressed=0 means user pressed YES button
                            ussFoundYes(userDepartment, dsNoOfUsslides, yesorMorePressed, requestid, PrntExtractionid, incRow);
                        } else if (yesorMorePressed > 0) {//If yesorMorePressed=+ve means user pressed Need More button with some +ve values that need to recut
                            needMore(userDepartment, dsNoOfUsslides, yesorMorePressed, requestid, PrntExtractionid, incRow, dsChkSampleType);
                        } else {
                            String error = getTranslationProcessor().translate("Number of Unscrapped slide coming from Jsp is invalid,that is:" + yesorMorePressed);
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                        }
                    } else if ("Dilution".equalsIgnoreCase(singleOperation)) {
                        String dilutionRatio = allColData[4];
                        if (dilutionRatio == "" || dilutionRatio == null) {
                            String error = getTranslationProcessor().translate("Please insert dilution ratio");
                            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                        }
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "D");
                        dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                        repeatExtraction = checkForExtraction(PrntExtractionid, "D");
                        addToDataSet(dsMain, rowIncrement, repeatExtraction, "", dilutionRatio, "Y", parentContainer);
                    }
                }
            } else {
                //one sample
                rowIncrement = dsMain.addRow();
                String singleOperation = listOfoperation.get(0).toString();

                dsMain.setValue(rowIncrement, DATASET_PROPERTY_COMMENTS, comments);
                dsMain.setValue(rowIncrement, DATASET_PROPERTY_SAMPLE_ID, PrntSampleid);
                dsMain.setValue(rowIncrement, DATASET_PROPERTY_ANALYTE, analyte);
                dsMain.setValue(rowIncrement, DATASET_PROPERTY_REPEATOPTIONS, singleOperation);
                if ("Repeat".equalsIgnoreCase(singleOperation)) {
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "R");
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                    repeatExtraction = checkForExtraction(PrntExtractionid, "R");
                    addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                } else if ("Purification".equalsIgnoreCase(singleOperation)) {
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "Q");
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                    repeatExtraction = checkForExtraction(PrntExtractionid, "Q");
                    addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                } else if ("Without LNA".equalsIgnoreCase(singleOperation)) {
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "W");
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                    repeatExtraction = checkForExtraction(PrntExtractionid, "W");
                    addToDataSet(dsMain, rowIncrement, repeatExtraction, "", "", "Y", parentContainer);
                } else if ("Re-Extract".equalsIgnoreCase(singleOperation)) {
                    String extractionidForRx = getParentExtractionForRX(PrntExtractionid);
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "RX");
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, extractionidForRx);
                    //String requestid = createRequestId(PrntSampleid); old
                    DataSet dsChkSampleType = rootForIncidentAndRecut(PrntExtractionid);
                    String requestid = createRequestId(dsChkSampleType, userDepartment);
                    addToDataSet(dsMain, rowIncrement, "", requestid, "", "N", "");
                    String ussFound = allColData[6];
                    int yesorMorePressed = Integer.valueOf(ussFound);
                    DataSet dsNoOfUsslides = noOfUnScrappedsSlide(PrntExtractionid);

                    if (yesorMorePressed == 0) {//If yesorMorePressed=0 means user pressed YES button
                        ussFoundYes(userDepartment, dsNoOfUsslides, yesorMorePressed, requestid, PrntExtractionid, incRow);
                    } else if (yesorMorePressed > 0) {//If yesorMorePressed=+ve means user pressed Need More button with some +ve values that need to recut
                        needMore(userDepartment, dsNoOfUsslides, yesorMorePressed, requestid, PrntExtractionid, incRow, dsChkSampleType);
                    } else {
                        String error = getTranslationProcessor().translate("Number of Unscrapped slide coming from Jsp is invalid,That is:" + yesorMorePressed);
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                    }
                } else if ("Dilution".equalsIgnoreCase(singleOperation)) {
                    String dilutionRatio = allColData[4];
                    if (dilutionRatio == "" || dilutionRatio == null) {
                        String error = getTranslationProcessor().translate("Please insert dilution ratio");
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
                    }
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_OPERATION, "D");
                    dsMain.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
                    repeatExtraction = checkForExtraction(PrntExtractionid, "D");
                    addToDataSet(dsMain, rowIncrement, repeatExtraction, "", dilutionRatio, "Y", parentContainer);
                }

            }

        }
    }

    /**
     * Description : This is for Updating u_reportflag to N initially.
     *
     * @throws SapphireException
     */
    private void updateReportFlag() throws SapphireException {
        String sample = Util.getUniqueList(dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"), ";", true);
        String[] sampleArr = StringUtil.split(sample, ";");
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, sample);
            props.setProperty("u_reportflag", StringUtil.repeat("N", sampleArr.length, ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update Sample SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }

    /**
     * Description: This used for select parent extractionid for RX extraction id.
     *
     * @param rxextractionid
     * @return parentContainerid
     * @throws SapphireException
     */
    private String getParentExtractionForRX(String rxextractionid) throws SapphireException {
        String sql = "select orgextractionid from u_repeatops where extractionid= '" + rxextractionid + "' ";
        DataSet dsContainer = getQueryProcessor().getSqlDataSet(sql);
        if (dsContainer == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String orgextractionid = dsContainer.getValue(0, "orgextractionid", "");
        if (Util.isNull(orgextractionid)) {
            return rxextractionid;
        } else {
            return orgextractionid;
        }

    }

    /**
     * Description : This method is required for editSDI in LV_Incdt SDC.This will edit explanation column of incident table
     * with message like "N Unscrapped slide available in your laboratory. N more Unscrapped slide required by userid".
     *
     * @throws SapphireException
     */
    private void updateLV_Incdt() throws SapphireException {
        String userId = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        DataSet ds = new DataSet();
        ds.addColumn("reqid", DataSet.STRING);
        ds.addColumn("uss", DataSet.STRING);
        ds.addColumn("needMore", DataSet.STRING);
        ds.addColumn("explanationmsg", DataSet.STRING);
        HashMap hm = new HashMap();
        String req = Util.getUniqueList(dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_REQUEST_ID, ";"), ";", true);
        String[] reqArr = StringUtil.split(req, ";");
        DataSet dsLvIncdt = null;
        for (int j = 0; j < reqArr.length; j++) {
            hm.clear();
            hm.put("requestid", reqArr[j]);
            dsLvIncdt = dsMainOpsRequest.getFilteredDataSet(hm);
            String reqid = Util.getUniqueList(dsLvIncdt.getColumnValues(DATASET_PROPERTY_OPSREQUEST_REQUEST_ID, ";"), ";", true);
            String uss = Util.getUniqueList(dsLvIncdt.getColumnValues(DATASET_PROPERTY_OPSREQUEST_NOOFUNSCRAPPED, ";"), ";", true);
            String needMore = Util.getUniqueList(dsLvIncdt.getColumnValues(DATASET_PROPERTY_OPSREQUEST_NOOFNEEDMORE, ";"), ";", true);

            int incr = ds.addRow();
            ds.setValue(incr, "reqid", reqid);
            ds.setValue(incr, "uss", uss);
            ds.setValue(incr, "needMore", needMore);
            ds.setValue(incr, "explanationmsg", uss + " Unscrapped slide available in your laboratory. " + needMore + " more Unscrapped slide required by " + userId);
        }

        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "LV_Incdt");
            props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("reqid", ";"));
            props.setProperty("explanation", ds.getColumnValues("explanationmsg", ";"));
            props.setProperty("u_message", ds.getColumnValues("explanationmsg", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update LV_Incdt SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }

    /**
     * Description : This method will show you number of un Scrapped slides for a extractionid.
     *
     * @param extractionid - Parent extractionid.
     * @return DataSet of un Scrapped slides.
     * @throws SapphireException
     */
    private DataSet noOfUnScrappedsSlide(String extractionid) throws SapphireException {
        String sql = "select ss.s_sampleid sampleid from s_samplemap ssm, s_sample ss " +
                "where  ss.s_sampleid =ssm.destsampleid  and ss.u_type='U' " +
                "and nvl(ss.U_ISSCRAP,'N') ='N' and ssm.sourcesampleid =( " +
                /*"    select DISTINCT sourcesampleid from s_samplemap where DESTSAMPLEID in ( " +*/
                "      select sourcesampleid from s_samplemap where destsampleid = ( " +
                "        select s.s_sampleid from s_sample  s, trackitem t where s.s_sampleid = t.linkkeyid1 and " +
                "        s.u_extractionid='" + extractionid + "' and t.containertypeid='Extraction Tube' " +
                "      ) " +
               /* "    ) " +*/
                ")";
        DataSet dsUssSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsUssSample == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        return dsUssSample;
    }

    /**
     * Description: This method will search no of Unscrapped slides for given extractionid
     * and will set all found slides with operation ReExtract and noOfslidetocut is zero to dsMainOpsRequest
     * dataset for AddSDI in RepeatOpsRequest SDC.
     *
     * @param noOfUssFound
     * @param requestid
     * @param extractionid
     * @param incRow
     * @throws SapphireException
     */
    private void ussFoundYes(String userDepartment, DataSet dsUssSample, int noOfUssFound, String requestid, String extractionid, int incRow) throws SapphireException {
        String noofSlidetoCut = String.valueOf(noOfUssFound);

        if (dsUssSample.size() == 0) {
            String error = getTranslationProcessor().translate("Invalid Condition:You don't have Unscrapped slide for extractionid " + extractionid);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        int dsSize = dsUssSample.size();
        for (int i = 0; i < dsUssSample.size(); i++) {
            String sample = dsUssSample.getValue(i, "sampleid", "");
            setDataTodsMainOpsRequest(incRow, sample, requestid, noofSlidetoCut, userDepartment, "", "Re-Extract", String.valueOf(dsSize), "0", "");
        }

    }

    /**
     * Description : This root sample is required creating incident request and recut.
     *
     * @param extractionid
     * @return
     * @throws SapphireException
     */
    private DataSet rootForIncidentAndRecut(String extractionid) throws SapphireException {
        String sqlChkSampleType = "SELECT DISTINCT CONNECT_BY_ROOT sourcesampleid rootsample,(SELECT sampletypeid FROM s_sample WHERE s_sample.s_sampleid=sourcesampleid) sampletype " +
                "FROM s_samplemap " +
                "WHERE DESTSAMPLEID in (SELECT s.s_sampleid FROM s_sample s, trackitem t " +
                "WHERE s.s_Sampleid = t. linkkeyid1 " +
                "AND s.u_extractionid = '" + extractionid + "' " +
                "AND t.containertypeid ='Extraction Tube') " +
                "AND LEVEL= " +
                "(SELECT DISTINCT MAX(LEVEL) " +
                "FROM s_samplemap " +
                "WHERE DESTSAMPLEID in (SELECT s.s_sampleid FROM s_sample s, trackitem t " +
                "WHERE s.s_Sampleid = t. linkkeyid1 " +
                "AND s.u_extractionid = '" + extractionid + "' " +
                "AND t.containertypeid ='Extraction Tube') " +
                "CONNECT BY PRIOR DESTSAMPLEID = sourcesampleid " +
                ") " +
                "CONNECT BY PRIOR DESTSAMPLEID  = sourcesampleid";
        DataSet dsChkSampleType = getQueryProcessor().getSqlDataSet(sqlChkSampleType);
        if (dsChkSampleType == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlChkSampleType;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsChkSampleType.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No root sample found,for extractionid:" + extractionid);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        return dsChkSampleType;
    }

    /**
     * Description : This method will search no of Unscrapped slides for given extractionid.If number of extractionid greater than zero
     * all found slide will set to dsMainOpsRequest dataset with operation=ReExtract,noOfSlideToCut zero and to department is null.And for user given
     * noOfSlideToCut it will search for sampletypeid,root sample by extractionid.If sampletypeid is found Tissue to department will be Histology
     * and sampletypeid is found Blood(Heme) to department will be Fresh Prep with sampleid=rootsample operation=ReCut and noOfSlideToCut
     * is given by user and  and to department site will be logged user site.
     * <p/>
     * Root sample will find by rootForIncidentAndRecut() method.
     *
     * @param noOfMoreSlides
     * @param requestid
     * @param extractionid
     * @param incRow
     * @throws SapphireException
     */
    private void needMore(String userDepartment, DataSet dsUssSample, int noOfMoreSlides, String requestid, String extractionid, int incRow, DataSet dsChkSampleType) throws SapphireException {
        String noOfSlideForRecut = String.valueOf(noOfMoreSlides);
        String userSite = userDepartment.substring(0, 3);
        int noOfUsslids = dsUssSample.size();
        if (noOfUsslids > 0) {
            for (int i = 0; i < dsUssSample.size(); i++) {
                String sample = dsUssSample.getValue(i, "sampleid", "");
                setDataTodsMainOpsRequest(incRow, sample, requestid, "0", userDepartment, "", "Re-Extract", String.valueOf(noOfUsslids), noOfSlideForRecut, "");//As reExtract so noOfSampletoCut is zero
            }
        }
        String rootsample = dsChkSampleType.getValue(0, "rootsample");
        String sampletype = dsChkSampleType.getValue(0, "sampletype");
        if (sampletype.equalsIgnoreCase("Paraffin Tissue")) {
            //setDataTodsMainOpsRequest(incRow, rootsample, requestid, noOfSlideForRecut, userDepartment, userSite + "Histology", "Re-Cut", String.valueOf(noOfUsslids), noOfSlideForRecut,"Y"); old
            setDataTodsMainOpsRequest(incRow, rootsample, requestid, noOfSlideForRecut, userDepartment, userSite + "BlockRoom", "Re-Cut", String.valueOf(noOfUsslids), noOfSlideForRecut, "Y");
        } else if (sampletype.equalsIgnoreCase("Peripheral Blood")) {
            setDataTodsMainOpsRequest(incRow, rootsample, requestid, noOfSlideForRecut, userDepartment, userSite + "Fresh Prep", "Re-Cut", String.valueOf(noOfUsslids), noOfSlideForRecut, "Y");
        }
    }

    /**
     * Description : This method is used for setting all data to dsMainOpsRequest dataset
     *
     * @param incRow
     * @param sample
     * @param requestid
     * @param noOfMoreSlides
     * @param userDepartment
     * @param todept
     * @param operation
     * @throws SapphireException
     */
    private void setDataTodsMainOpsRequest(int incRow, String sample, String requestid, String noOfMoreSlides, String userDepartment, String todept, String operation, String noofuss, String needmore, String recutflag) throws SapphireException {
        incRow = dsMainOpsRequest.addRow();
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_SAMPLE_ID, sample);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_REQUEST_ID, requestid);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_NOOFSLIDETOCUT, noOfMoreSlides);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_FROMDEPT, userDepartment);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_TODEPT, todept);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_OPERATION, operation);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_NOOFUNSCRAPPED, noofuss);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_NOOFNEEDMORE, needmore);
        dsMainOpsRequest.setValue(incRow, DATASET_PROPERTY_OPSREQUEST_ISRECUTPENDING, recutflag);
    }

    /**
     * Description : This method is used for AddSDI in RepeatOpsRequest SDC
     *
     * @throws SapphireException
     */
    private void insertToRepeatOpsRequest() throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(AddSDI.PROPERTY_SDCID, "RepeatOpsRequest");
            props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsMainOpsRequest.getRowCount()));
            props.setProperty("sampleid", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_SAMPLE_ID, ";"));
            props.setProperty("incidentrequestid", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_REQUEST_ID, ";"));
            props.setProperty("noofslide", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_NOOFSLIDETOCUT, ";"));
            props.setProperty("fromdepartment", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_FROMDEPT, ";"));
            props.setProperty("todepartment", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_TODEPT, ";"));
            props.setProperty("operations", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_OPERATION, ";"));
            props.setProperty("isrecutpending", dsMainOpsRequest.getColumnValues(DATASET_PROPERTY_OPSREQUEST_ISRECUTPENDING, ";"));
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in AddSDI in RepeatOpsRequest SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * Description: For setting all values to the dataset
     *
     * @param ds
     * @param rowIncrement
     * @param repeatExtraction
     * @param requestid
     * @param dilutionratio
     * @param childFlag
     */
    private void addToDataSet(DataSet ds, int rowIncrement, String repeatExtraction, String requestid, String dilutionratio, String childFlag, String parentContainer) {
        ds.setValue(rowIncrement, DATASET_PROPERTY_REPEATEXTRACTION, repeatExtraction);
        ds.setValue(rowIncrement, DATASET_PROPERTY_REQUEST_ID, requestid);
        ds.setValue(rowIncrement, DATASET_PROPERTY_DILUTION_RATIO, dilutionratio);
        ds.setValue(rowIncrement, DATASET_PROPERTY_CHILDFLAG, childFlag);
        ds.setValue(rowIncrement, DATASET_PROPERTY_PARENTCONTAINERTYPE_ID, parentContainer);
        //ds.setValue(rowIncrement, DATASET_PROPERTY_EXTRACTION_ID, PrntExtractionid);
    }

    /**
     * Description: parentContainerType() method used for finding container type id from trackitem table of parent sample
     *
     * @param parentSampleId
     * @return parentContainerid
     * @throws SapphireException
     */
    private String parentContainerType(String parentSampleId) throws SapphireException {
        String sql = "select containertypeid from trackitem where linkkeyid1 = '" + parentSampleId + "' ";
        DataSet dsContainer = getQueryProcessor().getSqlDataSet(sql);
        if (dsContainer == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsContainer.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No Container found for source sample.");
            errMsg += "\nSampleID:" + parentSampleId + ", Query retuns no rows:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String parentContainerid = dsContainer.getValue(0, "containertypeid");
        return parentContainerid;
    }

    /**
     * Description: addSampleSdi() method used for creating child sample based on parent and setting new sampleids
     * and trackitemid to the main data set
     *
     * @throws SapphireException
     */
    private void addSampleSdi() throws SapphireException {
        //Note: Action excuted in loop. We had a business logic which cannot be cater out side of loop.
        for (int sampCount = 0; sampCount < dsMain.size(); sampCount++) {
            if (!(dsMain.getValue(sampCount, "operation")).equalsIgnoreCase("RX")) {
                PropertyList props = new PropertyList();
                props.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(AddSDI.PROPERTY_TEMPLATEID, dsMain.getValue(sampCount, "sampleid", ""));
                props.setProperty("u_extractionid", dsMain.getValue(sampCount, "repeatextraction", ""));
                props.setProperty("u_concentrationratio", dsMain.getValue(sampCount, "dilutionratio", " "));//double quote contain space

                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
                String newSampleid = props.getProperty("newkeyid1");
                dsMain.setValue(sampCount, "gensampleid", newSampleid);
                String trackitemid = props.getProperty("newtrackitemid");
                dsMain.setValue(sampCount, "trackitemid", trackitemid);
            } else {
                dsMain.setValue(sampCount, "gensampleid", "");
                dsMain.setValue(sampCount, "trackitemid", "");
            }
        }
    }

    /**
     * Description: updateTrackItemSdc() this method is used for EditTrackItem for child sample by parent containertypeid
     *
     * @throws SapphireException
     */
    private void updateTrackItemSdc(DataSet ds) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("trackitemid", ";"));
            props.setProperty("containertypeid", StringUtil.repeat("Ellution Tube", ds.size(), ";"));
            props.setProperty("custodialdepartmentid", StringUtil.repeat(connectionInfo.getDefaultDepartment(), ds.size(), ";"));
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }

    /**
     * Description: checkForExtraction() this method is used for creating new extractionid based on repeat values
     *
     * @param orgextractionid,Operation
     * @return Child extraction id.
     * @throws SapphireException
     */
    private String checkForExtraction(String orgextractionid, String operation) throws SapphireException {
        String sqlExtraction = "select r.orgextractionid from u_repeatops r,u_repeatopsdetail rd where r.orgextractionid='" + orgextractionid + "' and rd.operation='" + operation + "' and r.u_repeatopsid=rd.u_repeatopsid";

        DataSet dsExtraction = getQueryProcessor().getSqlDataSet(sqlExtraction);
        if (dsExtraction == null) {
            String error = getTranslationProcessor().translate("Please contact you Administrator.\nQuery Failed: ");
            error += sqlExtraction;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        HashMap hm = new HashMap();
        if (dsExtraction.size() >= 1) {
            int dsSize = dsExtraction.size();
            hm.clear();
            hm.put(DATASET_PROPERTY_EXTRACTION_ID, orgextractionid);
            hm.put(DATASET_PROPERTY_OPERATION, operation);
            DataSet sameExtraction = dsMain.getFilteredDataSet(hm);//First time always get a record
            int sameExtractionSize = sameExtraction.size();
            dsSize = dsSize + sameExtractionSize;

            String dsSizeval = Integer.toString(dsSize);
            return orgextractionid + "-" + dsSizeval + operation;
        } else {
            int val = 0;
            hm.clear();
            hm.put(DATASET_PROPERTY_EXTRACTION_ID, orgextractionid);
            hm.put(DATASET_PROPERTY_OPERATION, operation);
            DataSet sameExtraction = dsMain.getFilteredDataSet(hm);//First time always get a record
            int sameExtractionSize = sameExtraction.size();
            val = val + sameExtractionSize;
            String valSize = Integer.toString(val);
            if ("1".equalsIgnoreCase(valSize)) {
                return orgextractionid + "-" + operation;
            } else {
                return orgextractionid + "-" + valSize + operation;
            }
        }
    }

    /**
     * Description: InsertToSamplemap() this method is used for inserting parent and child sampleids to s_samplemap table
     *
     * @throws SapphireException
     */
    private void insertToSamplemap() throws SapphireException {

        try {
            PreparedStatement ps = database.prepareStatement("insert into s_samplemap(sourcesampleid,destsampleid) values(?,?)");
            for (int i = 0; i < dsMain.size(); i++) {
                ps.setString(1, dsMain.getValue(i, "sampleid"));
                ps.setString(2, dsMain.getValue(i, "gensampleid"));
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            //String error = getTranslationProcessor().translate("Additional Extraction Tube is failed to create");
            //throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            e.getMessage();
        }
    }

    /**
     * Description: Desc repeatAddSdiAndDtls() this method is used for adding values to RepeatOps SDC and generating gensrepeatid and this
     * gensrepeatid will be added to detail table RepeatOps SDC with all selected analyte from jsp
     *
     * @param ds
     * @throws SapphireException
     */
    private void repeatAddSdiAndDtls(DataSet ds) throws SapphireException {
        PropertyList propRepeat = new PropertyList();
        propRepeat.setProperty(AddSDI.PROPERTY_SDCID, "RepeatOps");
        propRepeat.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(ds.getRowCount()));
        propRepeat.setProperty("sampleid", ds.getColumnValues("gensampleid", ";"));
        propRepeat.setProperty("orgextractionid", ds.getColumnValues("extractionid", ";"));
        propRepeat.setProperty("extractionid", ds.getColumnValues("repeatextraction", ";"));
        propRepeat.setProperty("orgsampleid", ds.getColumnValues("sampleid", ";"));
        propRepeat.setProperty("requestid", ds.getColumnValues("requestid", ";"));
        propRepeat.setProperty("ispending", StringUtil.repeat("Y", ds.size(), ";"));
        propRepeat.setProperty("notes", ds.getColumnValues(DATASET_PROPERTY_COMMENTS, ";"));
        propRepeat.setProperty("operation", ds.getColumnValues("repeatoptions", ";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, propRepeat);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("RepeatId is not successfully created in Repeatops SDC.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String newRepid = propRepeat.getProperty("newkeyid1");
        for (int repeateIdCount = 0; repeateIdCount < ds.size(); repeateIdCount++) {
            String[] RepeatVal = StringUtil.split(newRepid, ";");
            ds.setValue(repeateIdCount, "gensrepeatid", RepeatVal[repeateIdCount]);
        }

        DataSet dsRepeatDtls = new DataSet();
        dsRepeatDtls.addColumn("repeatids", DataSet.STRING);
        dsRepeatDtls.addColumn("analyteval", DataSet.STRING);
        dsRepeatDtls.addColumn("operation", DataSet.STRING);

        int rIncrement = 0;
        for (int k = 0; k < ds.size(); k++) {
            String analyteValue = ds.getValue(k, "analyte", "");
            String[] singleAnalyte = StringUtil.split(analyteValue, ";");
            for (int m = 0; m < singleAnalyte.length; m++) {
                rIncrement = dsRepeatDtls.addRow();
                dsRepeatDtls.setValue(rIncrement, "repeatids", ds.getValue(k, "gensrepeatid", ""));
                dsRepeatDtls.setValue(rIncrement, "operation", ds.getValue(k, "operation", ""));
                dsRepeatDtls.setValue(rIncrement, "analyteval", singleAnalyte[m]);
            }
        }
        PropertyList propRepeatDtl = new PropertyList();
        propRepeatDtl.setProperty(AddSDIDetail.PROPERTY_SDCID, "RepeatOps");
        propRepeatDtl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_repeatopsdetail_link");
        propRepeatDtl.setProperty("analyte", dsRepeatDtls.getColumnValues("analyteval", ";"));
        propRepeatDtl.setProperty("analyteid", dsRepeatDtls.getColumnValues("analyteval", ";"));
        propRepeatDtl.setProperty("u_repeatopsid", dsRepeatDtls.getColumnValues("repeatids", ";"));
        propRepeatDtl.setProperty("operation", dsRepeatDtls.getColumnValues("operation", ";"));
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, propRepeatDtl);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Analytes are not successfully saved in Repeatops SDC.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * Description: This method is creating request id for ReExtraction
     *
     * @param dsChkSampleType
     * @param userDepartment
     * @return
     * @throws SapphireException
     */
    private String createRequestId(DataSet dsChkSampleType, String userDepartment) throws SapphireException {
        String userSite = userDepartment.substring(0, 3);
        String rootsample = dsChkSampleType.getValue(0, "rootsample");
        String sampletype = dsChkSampleType.getValue(0, "sampletype");
        String todepartment = "";
        if (sampletype.equalsIgnoreCase("Tissue")) {
            todepartment = userSite + "BlockRoom";
        } else if (sampletype.equalsIgnoreCase("Blood")) {
            todepartment = userSite + "Fresh Prep";
        }

        PropertyList recordProp = new PropertyList();
        recordProp.setProperty("sourcesdcid", "Sample");
        recordProp.setProperty("sourcekeyid1", rootsample);
        recordProp.setProperty("incidentcategory", "UnPlanned");
        recordProp.setProperty("incidentdesc", "");
        recordProp.setProperty("explanation", "");//Will be updated by no. of uss reextract,recut
        //recordProp.setProperty("rootcause", "Stain Qc request for repeat "); Not required
        recordProp.setProperty("initialstatus", "InProgress");
        //recordProp.setProperty("initialstatus", "Approved");
        recordProp.setProperty("u_fromdepartment", userDepartment);
        recordProp.setProperty("departmentid", todepartment);
        getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);
        String requestid = recordProp.getProperty("newkeyid1");
        return requestid;
    }

    /**
     * Description: This method is used for getting test code of parent sample and will add to the main data set for applying test code to the child sample.
     *
     * @throws SapphireException
     */
    private void getParentTestCode() throws SapphireException {
        String parentSample = dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";");
        //1 Get parents test code
        String sqlTestCode = "select lvtestcodeid,lvtestpanelid,nvl(ispanel,'N') as ispanel,s_sampleid from u_sampletestcodemap where s_sampleid in ('" + StringUtil.replaceAll(parentSample, ";", "','") + "')";
        DataSet dsTestCode = getQueryProcessor().getSqlDataSet(sqlTestCode);
        if (dsTestCode == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlTestCode;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsTestCode.size() == 0) {
            String errStr = getTranslationProcessor().translate("No test code found for the parent sample");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        //2. filter testcode by parent and assign to child in main dataset
        HashMap hm = new HashMap();
        for (int i = 0; i < dsMain.getRowCount(); i++) {
            String parentSample1 = dsMain.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            hm.clear();
            hm.put("s_sampleid", parentSample1);
            DataSet dsFilter = dsTestCode.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.getRowCount() > 0) {
                String isPanelExists = Util.getUniqueList(dsFilter.getColumnValues("ispanel", ";"), ";", true); // This will be either Y or N // if mixmatch then logic will be change
                if ("Y".equalsIgnoreCase(isPanelExists)) {
                    //Test panel block
                    dsMain.setValue(i, DATASET_PROPERTY_PARENTTESTCODE, dsFilter.getColumnValues("lvtestpanelid", ";"));
                } else {
                    //Test code block
                    dsMain.setValue(i, DATASET_PROPERTY_PARENTTESTCODE, dsFilter.getColumnValues("lvtestcodeid", ";"));
                }
            }
        }
    }

    /**
     * Description:This method is used for filtering child sample to applying test code.
     *
     * @throws SapphireException
     */
    private DataSet filterChildSamplesToApplyTest() throws SapphireException {
        DataSet dsFilterChild = new DataSet();
        HashMap hm = new HashMap();
        hm.put(DATASET_PROPERTY_CHILDFLAG, "Y");
        dsFilterChild = dsMain.getFilteredDataSet(hm);
        return dsFilterChild;
    }

    /**
     * Description: This method is used for applying parent sample's test code to the child sample.
     *
     * @throws SapphireException
     */
    private void applyTestCodesToChildRepeat(DataSet filterDs) throws SapphireException {
        String childSample = filterDs.getColumnValues(DATASET_PROPERTY_GENSAMPLE_ID, ";");
        String parentTestCode = filterDs.getColumnValues(DATASET_PROPERTY_PARENTTESTCODE, ";");
        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, childSample);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_APPLY_WI, StringUtil.repeat("N", filterDs.size(), ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, parentTestCode);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");/**ADDED FOR BYPASS VALIDATION (SURAJIT) 05-05-17**/
        props.setProperty("ismolrepeatflag", "Y");/**ADDED FOR BYPASS VALIDATION (SURAJIT) 05-05-17**/
        props.setProperty("isapplyinitialrep", "N");/**ADDED FOR BYPASS VALIDATION (SURAJIT) 05-05-17**/
        getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
        /*
        AddTestCode will not be applied here because data already inserted in sdidata and sdidataitem table during
        child sample creation.If we use AddTestCode data will be redandent so We need to use AssignTestCode, here
        data insertion restricted by workitemflag=N in above mention table
         */
        // getActionProcessor().processAction("AddTestCode", "1", props);//will not be used
    }

    private void applyTestCodesToChild(DataSet filterDs) throws SapphireException {
        String childSample = filterDs.getColumnValues(DATASET_PROPERTY_GENSAMPLE_ID, ";");
        String parentTestCode = filterDs.getColumnValues(DATASET_PROPERTY_PARENTTESTCODE, ";");
        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, childSample);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_APPLY_WI, StringUtil.repeat("N", filterDs.size(), ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, parentTestCode);
        props.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");/**ADDED FOR BYPASS VALIDATION (SURAJIT) 05-05-17**/
        getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
        /*
        AddTestCode will not be applied here because data already inserted in sdidata and sdidataitem table during
        child sample creation.If we use AddTestCode data will be redandent so We need to use AssignTestCode, here
        data insertion restricted by workitemflag=N in above mention table
         */
        // getActionProcessor().processAction("AddTestCode", "1", props);//will not be used
    }

    /**
     * Description: This method is used for EnterDataItem.Entered all Analyte data value for the parent sample will goes to child sample.
     *
     * @param filterDs
     * @throws SapphireException
     */
    private void copyDataItemValuesToChildDataSet(DataSet filterDs) throws SapphireException {
        String parentSample = filterDs.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";");
        String sqlDisplayValue = "select sdi.keyid1 parentsampleid,sdi.paramlistid,sdi.paramlistversionid,sdi.paramid,sdi.displayvalue,sdi.variantid,sdi.paramtype,sdi.replicateid,sdi.dataset " +
                " from  sdidata sd, sdidataitem sdi where  sd.sdcid = sdi.sdcid and sd.keyid1 = sdi.keyid1 and sd.keyid2 = sdi.keyid2 " +
                " and sd.paramlistid = sdi.paramlistid and  sd.paramlistversionid = sdi.paramlistversionid and  sd.variantid = sdi.variantid and " +
                " sd.dataset = sdi.dataset and  sd.keyid1 in ('" + StringUtil.replaceAll(parentSample, ";", "','") + "') and sdi.enteredtext is not null";

        DataSet dsDisplayValue = getQueryProcessor().getSqlDataSet(sqlDisplayValue);
        if (dsDisplayValue == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlDisplayValue;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsDisplayValue.size() == 0) {
            String errStr = getTranslationProcessor().translate("No display value found for parent sample.");
            //throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            return;
        }
        DataSet dsCopyDataitem = new DataSet();
        dsCopyDataitem.addColumn("parentsampleid", DataSet.STRING);
        dsCopyDataitem.addColumn("paramlistid", DataSet.STRING);
        dsCopyDataitem.addColumn("paramlistversionid", DataSet.STRING);
        dsCopyDataitem.addColumn("paramid", DataSet.STRING);
        dsCopyDataitem.addColumn("displayvalue", DataSet.STRING);
        dsCopyDataitem.addColumn("childsample", DataSet.STRING);

        dsCopyDataitem.addColumn("variantid", DataSet.STRING);
        dsCopyDataitem.addColumn("paramtype", DataSet.STRING);
        dsCopyDataitem.addColumn("replicateid", DataSet.STRING);
        dsCopyDataitem.addColumn("dataset", DataSet.STRING);
        HashMap hm = new HashMap();
        for (int i = 0; i < filterDs.getRowCount(); i++) {
            String sampleID = filterDs.getValue(i, DATASET_PROPERTY_SAMPLE_ID, "");
            String childSample = filterDs.getValue(i, DATASET_PROPERTY_GENSAMPLE_ID, "");
            hm.clear();
            hm.put("parentsampleid", sampleID);
            DataSet dsFilter = dsDisplayValue.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {

                for (int j = 0; j < dsFilter.getRowCount(); j++) {
                    int rowid = dsCopyDataitem.addRow();
                    dsCopyDataitem.setValue(rowid, "parentsampleid", dsFilter.getValue(j, "parentsampleid", ""));
                    dsCopyDataitem.setValue(rowid, "paramlistid", dsFilter.getValue(j, "paramlistid", ""));
                    dsCopyDataitem.setValue(rowid, "paramlistversionid", dsFilter.getValue(j, "paramlistversionid", ""));
                    dsCopyDataitem.setValue(rowid, "paramid", dsFilter.getValue(j, "paramid", ""));
                    dsCopyDataitem.setValue(rowid, "displayvalue", dsFilter.getValue(j, "displayvalue", ""));
                    dsCopyDataitem.setValue(rowid, "childsample", childSample);
                    dsCopyDataitem.setValue(rowid, "variantid", dsFilter.getValue(j, "variantid", ""));
                    dsCopyDataitem.setValue(rowid, "paramtype", dsFilter.getValue(j, "paramtype", ""));
                    dsCopyDataitem.setValue(rowid, "replicateid", dsFilter.getValue(j, "replicateid", ""));
                    dsCopyDataitem.setValue(rowid, "dataset", dsFilter.getValue(j, "dataset", ""));
                }

            }
        }
        PropertyList props = new PropertyList();
        props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsCopyDataitem.getColumnValues("childsample", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsCopyDataitem.getColumnValues("paramlistid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsCopyDataitem.getColumnValues("paramlistversionid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsCopyDataitem.getColumnValues("paramid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsCopyDataitem.getColumnValues("displayvalue", ";"));

        props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsCopyDataitem.getColumnValues("variantid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsCopyDataitem.getColumnValues("paramtype", ";"));
        props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsCopyDataitem.getColumnValues("replicateid", ";"));
        props.setProperty(EnterDataItem.PROPERTY_DATASET, dsCopyDataitem.getColumnValues("dataset", ";"));

        getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
    }

    private DataSet createMicrodissectionRule() throws SapphireException {
        DataSet dsAllSlides = null;
        HashMap hm = new HashMap();
        hm.clear();
        hm.put(DATASET_PROPERTY_REPEATOPTIONS, "Re-Extract");
        DataSet dsReExtractFIlter = dsMain.getFilteredDataSet(hm);
        if (dsReExtractFIlter.size() == 0) {
            return dsAllSlides;
        }
        String sampleid = Util.getUniqueList(dsReExtractFIlter.getColumnValues("sampleid", ";"), ";", true);
        String sql = "select s_sampleid,u_clientspecimenid,collectiondt,u_accessionid from s_sample where u_rootsample in(select u_rootsample from s_sample" +
                " where s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "')) and u_type in('H','CH','CU','U') and u_isscrap is null";
        dsAllSlides = getQueryProcessor().getSqlDataSet(sql);
        if (dsAllSlides.size() == 0) {
            return dsAllSlides;
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsAllSlides.getColumnValues("s_sampleid", ";"));
        prop.setProperty("u_currentmovementstep", "Pre-Extraction");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error to update movement of specimen(s).");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        /*dsAllSlides.sort("u_accessionid,u_clientspecimenid,collectiondt");
        ArrayList arrySlides = dsAllSlides.getGroupedDataSets("u_accessionid,u_clientspecimenid,collectiondt");
        for (int i = 0; i < arrySlides.size(); i++) {
            DataSet dsEach = (DataSet) arrySlides.get(i);
            PropertyList prop = new PropertyList();
            prop.setProperty("keyid1", dsEach.getColumnValues("s_sampleid", ";"));
            prop.setProperty("reextractbypass", "Y");
            try {
                getActionProcessor().processAction(CompletePreExtraction.ID, CompletePreExtraction.VERSIONID, prop);
            } catch (ActionException ae) {
                String error = getTranslationProcessor().translate("Error in rule.");
                error += ae.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
        }*/
        return dsAllSlides;
    }

    /*****************
     * BASE DESIGN ***********DO NOT CHANGE THIS
     *****************************/
    private DataSet dsMain = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "sampleid";
    private static final String DATASET_PROPERTY_EXTRACTION_ID = "extractionid";
    private static final String DATASET_PROPERTY_ANALYTE = "analyte";
    private static final String DATASET_PROPERTY_REPEATOPTIONS = "repeatoptions";
    private static final String DATASET_PROPERTY_REPEATEXTRACTION = "repeatextraction";
    private static final String DATASET_PROPERTY_OPERATION = "operation";
    private static final String DATASET_PROPERTY_GENSAMPLE_ID = "gensampleid";
    private static final String DATASET_PROPERTY_GEN_REPEAT_KEYID1 = "gensrepeatid";
    private static final String DATASET_PROPERTY_PARENTCONTAINERTYPE_ID = "parentcontainertypeid";
    private static final String DATASET_PROPERTY_TRACKITEM_ID = "trackitemid";
    private static final String DATASET_PROPERTY_REQUEST_ID = "requestid";
    private static final String DATASET_PROPERTY_DILUTION_RATIO = "dilutionratio";
    private static final String DATASET_PROPERTY_PARENTTESTCODE = "parenttestcode";
    private static final String DATASET_PROPERTY_CHILDFLAG = "childflag";
    private static final String DATASET_PROPERTY_COMMENTS = "comments";

    //For RepeatOpsRequest

    private DataSet dsMainOpsRequest = null;
    private static final String DATASET_PROPERTY_OPSREQUEST_SAMPLE_ID = "reqsampleid";
    private static final String DATASET_PROPERTY_OPSREQUEST_REQUEST_ID = "requestid";
    private static final String DATASET_PROPERTY_OPSREQUEST_NOOFSLIDETOCUT = "noofslidetocut";
    private static final String DATASET_PROPERTY_OPSREQUEST_FROMDEPT = "fromdept";
    private static final String DATASET_PROPERTY_OPSREQUEST_TODEPT = "todept";
    private static final String DATASET_PROPERTY_OPSREQUEST_OPERATION = "reqoperation";
    private static final String DATASET_PROPERTY_OPSREQUEST_NOOFUNSCRAPPED = "noofuss";
    private static final String DATASET_PROPERTY_OPSREQUEST_NOOFNEEDMORE = "noofneedmore";
    private static final String DATASET_PROPERTY_OPSREQUEST_ISRECUTPENDING = "isrecutpending";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_ANALYTE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_REPEATOPTIONS, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_REPEATEXTRACTION, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_OPERATION, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_GENSAMPLE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_GEN_REPEAT_KEYID1, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TRACKITEM_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_REQUEST_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_DILUTION_RATIO, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_CHILDFLAG, DataSet.STRING);

            dsMain.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_EXTRACTION_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_PARENTCONTAINERTYPE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_PARENTTESTCODE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_COMMENTS, DataSet.STRING);
        }
    }

    private void initializeDataSetForrepeatOps() throws SapphireException {
        if (dsMainOpsRequest == null) {
            dsMainOpsRequest = new DataSet();
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_SAMPLE_ID, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_REQUEST_ID, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_NOOFSLIDETOCUT, DataSet.NUMBER);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_FROMDEPT, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_TODEPT, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_OPERATION, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_NOOFUNSCRAPPED, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_NOOFNEEDMORE, DataSet.STRING);
            dsMainOpsRequest.addColumn(DATASET_PROPERTY_OPSREQUEST_ISRECUTPENDING, DataSet.STRING);
        }
    }

}
