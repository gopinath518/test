package sapphire.custom.ng.action.quantification;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.DecimalFormat;
import java.util.HashMap;

public class CobasQuantITParser extends BaseAction {

    private static DecimalFormat ONE_DECIMAL_FORMAT = new DecimalFormat(".#");

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String samples = properties.getProperty("sampleid", "");
        String concentration = properties.getProperty("concentration", "");
        if (Util.isNull(samples)) {
            throw new SapphireException("Specimens can't be null.");
        }
        if (Util.isNull(concentration)) {
            throw new SapphireException("Concentration Values can't be null.");
        }
        initializeDataSet();
        samples = Util.getUniqueList(samples, ";", true);
        String extractionids = StringUtil.replaceAll(samples, ";", "','");
        String sql = Util.parseMessage(MolecularSql.GET_MOLBATCH_BY_EXTRACTID, extractionids);
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() == 0) {
            String errStr = getTranslationProcessor().translate("Parse specimen(s) does not belongs with any batch. Please check again.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String batchid = Util.getUniqueList(dsBatchInfo.getColumnValues("u_ngbatchid", ";"), ";", true);
        createDataSet(samples, concentration, batchid, dsBatchInfo);
        valiadteSpecimenReadingCount();
        extractionCOBASValidation(batchid);
        saveQuantItValueToDB();

        //throw new SapphireException("test");
    }

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_EXTARCTIONID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_CONCENTRATION, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_BATCHID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_INSTRUMENTID, DataSet.STRING);
            dsFinal.addColumn(DATASET_PROPERTY_READ_COUNT, DataSet.STRING);
        }
    }

    /**
     * Description: This method is only used for create dataset
     *
     * @param concentration
     * @param batchid
     * @throws SapphireException
     */
    private void createDataSet(String extractionids, String concentration, String batchid, DataSet dsBatchInfo) throws SapphireException {
        String extractionidsArr[] = StringUtil.split(extractionids, ";");
        String concentrationArr[] = StringUtil.split(concentration, ";");
        for (int i = 0; i < extractionidsArr.length; i++) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("u_extractionid", extractionidsArr[i]);
            DataSet dsFiletr = dsBatchInfo.getFilteredDataSet(hm);
            String sampleid = dsFiletr.getValue(0, "s_sampleid", "");
            double doblconc = Double.parseDouble(concentrationArr[i]);
            int rowID = dsFinal.addRow();
            dsFinal.setValue(rowID, DATASET_PROPERTY_EXTARCTIONID, extractionidsArr[i]);
            dsFinal.setValue(rowID, DATASET_PROPERTY_CONCENTRATION, ONE_DECIMAL_FORMAT.format(doblconc));
            dsFinal.setValue(rowID, DATASET_PROPERTY_BATCHID, batchid);
            dsFinal.setValue(rowID, DATASET_PROPERTY_SAMPLEID, sampleid);
            dsFinal.setValue(rowID, DATASET_PROPERTY_INSTRUMENTID, "Quantit");
        }
    }

    /**
     * Description : Validate extraction ID in XLSX and Database
     *
     * @param batchid
     * @throws SapphireException
     */
    private void extractionCOBASValidation(String batchid) throws SapphireException {
        String sqlSample = Util.parseMessage(MolecularSql.QUBITPARSER_BATCHSAMPLE_COBAS, batchid);
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sqlSample);
        if (dsSample == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsSample.size() > 0) {
            DataSet dsError = new DataSet();
            dsError.addColumn("specimen_id", DataSet.STRING);
            HashMap<String, String> hmFilter = new HashMap<>();
            String extIds = "";
            for (int i = 0; i < dsFinal.size(); i++) {
                hmFilter.clear();
                String ext = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID, "");
                hmFilter.put("u_extractionid", ext);
                DataSet dsFilter = dsSample.getFilteredDataSet(hmFilter);
                if (dsFilter.size() == 0) {
                    //extIds = extIds + ";" + ext;
                    int rowID = dsError.addRow();
                    dsError.setValue(rowID, "specimen_id", ext);
                }
                if (dsFilter.size() > 0) {
                    dsFilter.setValue(i, DATASET_PROPERTY_SAMPLEID, dsFilter.getValue(0, "s_sampleid"));
                }
            }
            if (dsError.size() > 0) {
                String errorCode = Util.getDisplayMessage("Below specimen(s) does not matched with the uploaded XLSX.", dsError);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errorCode);
            }
            /*if (extIds.length() > 1) {
                extIds = extIds.substring(1);
                String errStr = getTranslationProcessor().translate(extIds + " Doesn't match with database value. Please check 'Sample ID' coulmn in XLSX file.");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }*/
        }
    }

    /**
     * Description : This is used to get and validate specimen reading with the uploaded file
     * and from the database.
     *
     * @throws SapphireException
     */
    private void valiadteSpecimenReadingCount() throws SapphireException {
        if (dsFinal.size() > 0) {

            String sampleid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"), ";", true);
            String extractionid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_EXTARCTIONID, ";"), ";", true);
            String parsebatchid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_BATCHID, ";"), ";", true);
            String instrumentid = Util.getUniqueList(dsFinal.getColumnValues(DATASET_PROPERTY_INSTRUMENTID, ";"), ";", true);

            String sql = Util.parseMessage(MolecularSql.NanodropPARSER_ATTACHEDCOUNT_BY_COMBINATION, StringUtil.replaceAll(parsebatchid, ";", "','"),
                    StringUtil.replaceAll(instrumentid, ";", "','"), StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsReadingInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsReadingInfo.size() > 0 || dsReadingInfo.size() == 0) {
                String arryExtarction[] = StringUtil.split(extractionid, ";");
                for (int i = 0; i < arryExtarction.length; i++) {
                    HashMap hm = new HashMap();
                    hm.clear();
                    hm.put(DATASET_PROPERTY_EXTARCTIONID, arryExtarction[i]);
                    DataSet dsFileterMain = dsFinal.getFilteredDataSet(hm);
                    int parseSpecimenCount = dsFileterMain.size();
                    hm.clear();
                    hm.put("extractionid", arryExtarction[i]);
                    DataSet dsFileterInstrument = dsReadingInfo.getFilteredDataSet(hm);
                    int dbSpecimenCount = dsFileterInstrument.size();
                    if (parseSpecimenCount > 4) {
                        String errStr = getTranslationProcessor().translate("You can't upload more than 3 records of specimen(s): " + arryExtarction[i]);
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                    }
                    if (dbSpecimenCount >= 4) {
                        String errStr = getTranslationProcessor().translate("<b>You can't upload more than 3 records of specimen(s): " + arryExtarction[i] + "</b>");
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                    }
                    int balncReadingCount = 4 - dbSpecimenCount;
                    if (parseSpecimenCount > balncReadingCount) {
                        String errStr = getTranslationProcessor().translate("<b>You can upload reading " + balncReadingCount + " time(s) more of specimen(s): " + arryExtarction[i] + "</b>");
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
                    }
                }
            }
            for (int i = 0; i < dsFinal.size(); i++) {
                String specimenid = dsFinal.getValue(i, DATASET_PROPERTY_SAMPLEID);
                String ngbatchid = dsFinal.getValue(i, DATASET_PROPERTY_BATCHID);
                String instrumentused = dsFinal.getValue(i, DATASET_PROPERTY_INSTRUMENTID);

                if (!bufferSpecimen.equalsIgnoreCase(specimenid)) {
                    //incr = 0;
                    specCount = readingCountByCombination(specimenid, ngbatchid, instrumentused);
                } else {
                    //incr = (incr + 1);
                    //specCount = specCount + incr;
                    specCount = specCount + 1;
                }
                dsFinal.setValue(i, DATASET_PROPERTY_READ_COUNT, "" + specCount);
            }
        }
    }

    /**
     * Description: This is used to count and validate specimen reading records.
     *
     * @param sampleid
     * @param batchid
     * @param instrumentid
     * @throws SapphireException
     */
    private int readingCountByCombination(String sampleid, String batchid, String instrumentid) throws SapphireException {
        int count = 0;
        String sql = Util.parseMessage(MolecularSql.NanodropPARSER_ATTACHEDCOUNT_BY_COMBINATION, batchid, instrumentid, sampleid);
        DataSet dsReadingInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsReadingInfo.size() == 0) {
            bufferSpecimen = sampleid;
            count = dsReadingInfo.size();
        }
        if (dsReadingInfo.size() > 0) {
            bufferSpecimen = sampleid;
            count = dsReadingInfo.size();
        }
        return count + 1;
    }

    /**
     * Description : Parse XLS file coming from Quant-iT instrument to Database.
     *
     * @throws : SapphireException
     */
    private void saveQuantItValueToDB() throws SapphireException {
        if (dsFinal == null || dsFinal.size() == 0) {
            throw new SapphireException("Main DataSet doesn't have any Values");
        }

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "InstrumentQuantific");
        props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsFinal.size()));
        props.setProperty("u_ngbatchid", dsFinal.getColumnValues(DATASET_PROPERTY_BATCHID, ";"));
        props.setProperty("sampleid", dsFinal.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
        props.setProperty("extractionid", dsFinal.getColumnValues(DATASET_PROPERTY_EXTARCTIONID, ";"));
        props.setProperty("concentration", dsFinal.getColumnValues(DATASET_PROPERTY_CONCENTRATION, ";"));
        props.setProperty("u_instrumentused", dsFinal.getColumnValues(DATASET_PROPERTY_INSTRUMENTID, ";"));
        props.setProperty("uploadcount", dsFinal.getColumnValues(DATASET_PROPERTY_READ_COUNT, ";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in InstrumentQuantific");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }

    }

    String bufferSpecimen = "";
    int incr = 0;
    int specCount = 0;
    private DataSet dsFinal = null;
    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_EXTARCTIONID = "extractionid";
    private static final String DATASET_PROPERTY_CONCENTRATION = "concentration";
    private static final String DATASET_PROPERTY_BATCHID = "batchid";
    private static final String DATASET_PROPERTY_INSTRUMENTID = "instrumentid";
    private static final String DATASET_PROPERTY_READ_COUNT = "samplereadcount";
}
