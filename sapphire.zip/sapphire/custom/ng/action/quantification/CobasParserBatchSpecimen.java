package sapphire.custom.ng.action.quantification;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.sql.sdcrule.RulesSql;
import sapphire.custom.ng.util.MolecularConstaints;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.custom.ng.action.QubitParser;
import sapphire.action.CreateArray;
import sapphire.action.CreateArray;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static sapphire.custom.ng.util.Util.getUniqueList;

public class CobasParserBatchSpecimen extends BaseAction {
    private static DecimalFormat TWO_DECIMAL_FORMAT = new DecimalFormat(".##");

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid");
        String instrumentparser = properties.getProperty("instrumentparser");
        String path = properties.getProperty("path", "");
        String messagetypeid = properties.getProperty("messagetypeid", "");
        String tramstop = properties.getProperty("tramstop", "");

        if (Util.isNull(batchid))
            throw new SapphireException("Batch ID can't be blank.");
        String sql = Util.parseMessage(MolecularSql.GET_BATCH_SAMPLE_TEST_CODE_BY_BATCHID, batchid);
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() == 0) {
            throw new SapphireException("<b>Batch does not contain any EGFR COBAS specimen(s).</b>");
        }
        if (dsBatchInfo.size() > 0) {
            if ("QbF".equalsIgnoreCase(instrumentparser)) {
                PropertyList props = new PropertyList();
                props.setProperty("batchid", batchid);
                props.setProperty("path", path);
                props.setProperty("tramstop", tramstop);
                try {
                    getActionProcessor().processAction("QubitParser", "1", props);
                } catch (Exception ex) {
                    throw new SapphireException("Qubit parsing failed." + ex.getMessage());
                }
                initializeDataSet();
                getSampleConc(batchid, "Qubit");
                editMeanSD();
            } else if ("NdF".equalsIgnoreCase(instrumentparser)) {
                PropertyList props = new PropertyList();
                props.setProperty("batchid", batchid);
                props.setProperty("path", path);
                props.setProperty("tramstop", tramstop);
                try {
                    getActionProcessor().processAction("NanodropParser", "1", props);
                } catch (Exception ex) {
                    throw new SapphireException("Nano Drop parsing failed." + ex.getMessage());
                }
                initializeDataSet();
                getSampleConc(batchid, "Nanodrop");
                editMeanSD();
                DataSet ds = geta260a280(batchid, "Nanodrop");
                editMeanSDa260a280(ds);
            } else if ("QiT".equalsIgnoreCase(instrumentparser)) {
                PropertyList props = new PropertyList();
                props.setProperty("batchid", batchid);
                props.setProperty("path", path);
                props.setProperty("tramstop", tramstop);
                try {
                    getActionProcessor().processAction("UploadQuantExcelFile", "1", props, false, false);
                } catch (Exception ex) {
                    throw new SapphireException("Quant IT parsing failed.:UploadQuantExcelFile>>" + ex.getMessage());
                }
                props.clear();
                props.setProperty(MolecularConstaints.MESSAGE_TYPE_ID_INDF, messagetypeid);
                props.setProperty(MolecularConstaints.PATH_INDF, path);
                props.setProperty(MolecularConstaints.PROCESS_ACTIONID_INDF, MolecularConstaints.PROCESS_ACTIONID_VAL);
                props.setProperty(MolecularConstaints.PROCESS_ACTION_VERSIONID_INDF, MolecularConstaints.PROCESS_ACTION_VERSIONID_VAL);
                props.setProperty(MolecularConstaints.READACTION_ID_INDF, MolecularConstaints.READACTION_ID_VAL);
                props.setProperty(MolecularConstaints.READACTION_VERSION_ID_INDF, MolecularConstaints.READACTION_VERSION_ID_VAL);
                props.setProperty(MolecularConstaints.READ_FILE_CONTENT_INDF, MolecularConstaints.READ_FILE_CONTENT_VAL);
                props.setProperty(MolecularConstaints.FILE_CONTENT_PROPERTY_ID_INDF, MolecularConstaints.FILE_CONTENT_PROPERTY_ID_VAL);
                props.setProperty(MolecularConstaints.TAG_PROPERTY_ID_INDF, MolecularConstaints.TAG_PROPERTY_ID_VAL);
                props.setProperty(MolecularConstaints.RETAINON_SUCCESS_INDF, MolecularConstaints.RETAINON_SUCCESS_VAL);
                props.setProperty(MolecularConstaints.RETAINON_FAILURE_INDF, MolecularConstaints.RETAINON_FAILURE_VAL);
                try {
                    getActionProcessor().processAction("ProcessFile", "1", props, false, false);
                } catch (Exception ex) {
                    throw new SapphireException("Quant IT parsing failed.:ProcessFile>>" + ex.getMessage());
                }
                initializeDataSet();
                getSampleConc(batchid, "Quantit");
                editMeanSD();
            } else {
                throw new SapphireException("<b>Please select atleast One Parser Option</b>");
            }

        }
        //throw new SapphireException("test");
    }

    private void getSampleConc(String batchid, String instrumentid) throws SapphireException {
        String sqlBatchSample = Util.parseMessage(MolecularSql.GET_LATEST_READINGS_BY_BATCH, batchid, instrumentid);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sqlBatchSample);
        if (dsBatchSample == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        dsBatchSample.sort("sampleid");
        ArrayList<DataSet> grDs = dsBatchSample.getGroupedDataSets("sampleid");
        int incr = 0;
        for (int i = 0; i < grDs.size(); i++) {
            incr = dsMeanSD.addRow();
            DataSet sameSampleDs = grDs.get(i);
            String sampleid = Util.getUniqueList(sameSampleDs.getColumnValues("sampleid", ";"), ";", true);
            dsMeanSD.setValue(incr, DATASET_PROPERTY_SAMPLEID, sampleid);

            List<Double> li = new ArrayList<>();
            for (int j = 0; j < sameSampleDs.size(); j++) {
                Double conc = sameSampleDs.getDouble(j, "concentration", 0.0);
                li.add(conc);
            }
            meanAndSDCalculation(incr, li);
        }
    }

    private void meanAndSDCalculation(int incr, List<Double> list) {

		/*try{
            if(list.size()==0){
				String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
				throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
			}
		}catch(SapphireException se){

		}*/
        double sum = 0.0;
        double mean = 0.0;
        double powSum = 0.0;
        double powNum = 0.0;
        double sd = 0.0;

        for (int l = 0; l < list.size(); l++) {
            sum += list.get(l);
        }
        mean = sum / list.size();

        for (int l = 0; l < list.size(); l++) {
            powNum = Math.pow((list.get(l) - mean), 2);
            powSum += powNum;
        }
        sd = Math.sqrt(powSum / list.size());
        dsMeanSD.setNumber(incr, DATASET_PROPERTY_MEAN, TWO_DECIMAL_FORMAT.format(mean));
        dsMeanSD.setNumber(incr, DATASET_PROPERTY_SD, TWO_DECIMAL_FORMAT.format(sd));
    }

    private void editMeanSD() throws SapphireException {
        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsMeanSD.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"));
            props.setProperty("concentration", dsMeanSD.getColumnValues(DATASET_PROPERTY_MEAN, ";"));
            props.setProperty("u_standarddeviation", dsMeanSD.getColumnValues(DATASET_PROPERTY_SD, ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    private DataSet geta260a280(String batchid, String instrumentid) throws SapphireException {
        DataSet dsMeanSDa260a280 = new DataSet();
        dsMeanSDa260a280.addColumn("sample", DataSet.STRING);
        dsMeanSDa260a280.addColumn("a260a280mean", DataSet.NUMBER);
        dsMeanSDa260a280.addColumn("a260a280sd", DataSet.NUMBER);

        String sqlBatchSample = Util.parseMessage(MolecularSql.GET_LATEST_READINGS_BY_BATCH, batchid, instrumentid);
        DataSet dsBatchSample = getQueryProcessor().getSqlDataSet(sqlBatchSample);
        if (dsBatchSample == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        dsBatchSample.sort("sampleid");
        ArrayList<DataSet> grDs = dsBatchSample.getGroupedDataSets("sampleid");
        int incr = 0;
        for (int i = 0; i < grDs.size(); i++) {
            incr = dsMeanSDa260a280.addRow();
            DataSet sameSampleDs = grDs.get(i);
            String sampleid = Util.getUniqueList(sameSampleDs.getColumnValues("sampleid", ";"), ";", true);
            dsMeanSDa260a280.setValue(incr, "sample", sampleid);

            List<Double> li = new ArrayList<>();
            for (int j = 0; j < sameSampleDs.size(); j++) {
                Double a260a280 = sameSampleDs.getDouble(j, "a260a280", 0.0);
                li.add(a260a280);
            }
            meanAndSDFora260a280(dsMeanSDa260a280, incr, li);
        }
        return dsMeanSDa260a280;
    }

    private void meanAndSDFora260a280(DataSet dsMeanSDa260a280, int incr, List<Double> list) {

        double sum = 0.0;
        double mean = 0.0;
        double powSum = 0.0;
        double powNum = 0.0;
        double sd = 0.0;

        for (int l = 0; l < list.size(); l++) {
            sum += list.get(l);
        }
        mean = sum / list.size();

        for (int l = 0; l < list.size(); l++) {
            powNum = Math.pow((list.get(l) - mean), 2);
            powSum += powNum;
        }
        sd = Math.sqrt(powSum / list.size());
        dsMeanSDa260a280.setNumber(incr, "a260a280mean", TWO_DECIMAL_FORMAT.format(mean));
        dsMeanSDa260a280.setNumber(incr, "a260a280sd", TWO_DECIMAL_FORMAT.format(sd));
    }

    private void editMeanSDa260a280(DataSet dsMeanSDa260a280) throws SapphireException {
        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsMeanSDa260a280.getColumnValues("sample", ";"));
            props.setProperty("u_a260a280", dsMeanSDa260a280.getColumnValues("a260a280mean", ";"));
            props.setProperty("u_sd_a260a280", dsMeanSDa260a280.getColumnValues("a260a280sd", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    private DataSet dsMeanSD = null;
    private static final String DATASET_PROPERTY_SAMPLEID = "sampleid";
    private static final String DATASET_PROPERTY_MEAN = "mean";
    private static final String DATASET_PROPERTY_SD = "sd";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMeanSD == null) {
            dsMeanSD = new DataSet();
            dsMeanSD.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsMeanSD.addColumn(DATASET_PROPERTY_MEAN, DataSet.NUMBER);
            dsMeanSD.addColumn(DATASET_PROPERTY_SD, DataSet.NUMBER);
        }
    }

}
