package sapphire.custom.ng.action.quantification;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class COBASExportCalculation extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("keyid1", "");
        String tramstop = properties.getProperty("tramstop", "");
        if (Util.isNull(batchid)) {
            throw new SapphireException("Batch ID can't be blank.");
        }
        String sql = Util.parseMessage(MolecularSql.GET_COBAS_SAMPLE_BY_BATCH, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsCobasBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsCobasBatchInfo == null || dsCobasBatchInfo.size() == 0) {
            throw new SapphireException("No COBAS specimen(s) found into the batch.");
            //properties.setProperty("msg","No COBAS specime(s) found into the batch.");
        }
        String filelocation = getFileLocation();
        if (filelocation == null || Util.isNull(filelocation)) {
            throw new SapphireException("Default Location is not defined in molecular.");
        }
        if (filelocation.endsWith("/"))
            filelocation = filelocation;
        else
            filelocation = filelocation + File.separator;

        String filenameformat = filelocation + tramstop + "_QuantCalculation_" + generateFileName(batchid) + ".xlsx";
        DataSet dsFinal = getMainDataSet(dsCobasBatchInfo);
        if (dsFinal == null || dsFinal.size() == 0) {
            properties.setProperty("msg", "No Quant. reading found for COBAS specime(s).");
            return;
        }
        generateCsvFile(filenameformat, dsFinal, tramstop);
        attachedExportReport(batchid, filenameformat);
        sql = Util.parseMessage(MolecularSql.GET_ATTACHMENT_NANOSTRING_REPORT, batchid);
        DataSet dsAttachmnt = getQueryProcessor().getSqlDataSet(sql);
        int attachnum = Integer.parseInt(dsAttachmnt.getValue(0, "attachmentnum", "0"));
        String url = "rc?command=ViewAttachment&sdcid=Dummy&keyid1=" + batchid + "&keyid2=COBASCalculation&keyid3=COBASCalculation&attachmentnum=" + attachnum + "&download=Y";
        String msg = "<script>window.open('" + url + "', '_blank');</script>";
        properties.setProperty("msg", "Operation Successful. File has been downloaded." + msg);
        PropertyList prop = new PropertyList();
        prop.setProperty("id", batchid);
        prop.setProperty("location", filenameformat);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "InventoryReportingTempDeleteAction");
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
        prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
        prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n+1");
        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
    }

    private static void generateCsvFile(String localtionfilename, DataSet dsInputs, String tramstop) throws SapphireException {
        int rownum = 0;
        XSSFSheet firstSheet;
        Collection<File> files;
        XSSFWorkbook workbook;
        File exactFile;
        workbook = new XSSFWorkbook();
        //SET CELL STYLE
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        style.setFont(font);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        //SET ALL BORDER
        CellStyle borderStyle = workbook.createCellStyle();
        borderStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
        borderStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);

        firstSheet = workbook.createSheet(tramstop + "-COBAS Quant. Calculation");
        Row headerRow = firstSheet.createRow(rownum);
        headerRow.setHeightInPoints(40);
        List<String> headerRoww = new ArrayList<String>();
        headerRoww.add("Sl. No.");
        headerRoww.add("Extraction ID");
        //headerRoww.add("Specimen ID");
        /*headerRoww.add("Molecular Batch ID");
        headerRoww.add("Batch Specimen ID");*/
        headerRoww.add("OD1");
        headerRoww.add("OD2");
        headerRoww.add("DNA Concentration(ng/µL)");//CALCULATION WILL THROW BASED ON OD1 & OD2
        headerRoww.add("Final Volume");
        headerRoww.add("DNA µl");//CALCULATION REQUIRED
        headerRoww.add("H2O µl");//CALCULATION REQUIRED
        List<List> recordToAdd = new ArrayList<List>();
        recordToAdd.add(headerRoww);
        for (int i = 0; i < dsInputs.size(); i++) {

            String s_sampleid = dsInputs.getValue(i, "specimen_id", "");
            String u_molbatchspecimenid = dsInputs.getValue(i, "batch_specimen_id", "");
            String molbatchid = dsInputs.getValue(i, "mol_batch_id");
            String u_extractionid = dsInputs.getValue(i, "extraction_id");
            String quant_one = dsInputs.getValue(i, "quant_one", "0.0");
            String quant_two = dsInputs.getValue(i, "quant_two", "0.0");

            double calconcentration = (Double.parseDouble(quant_one) + Double.parseDouble(quant_two)) / 2;
            String calconc = String.valueOf(Util.roundAvoid(calconcentration));

            String sample_vol = dsInputs.getValue(i, "sample_vol", "0.0");

            double dnacal = (Double.parseDouble(sample_vol) * 2) / calconcentration;
            String dnaul = String.valueOf(Util.roundAvoid(dnacal));

            double watercal = Double.parseDouble(sample_vol) - Double.parseDouble(dnaul);
            String waterul = String.valueOf(Util.roundAvoid(watercal));
            ;

            List<String> firstRow = new ArrayList<String>();
            firstRow.add(String.valueOf(i + 1));
            //firstRow.add(s_sampleid);
            firstRow.add(u_extractionid);
            /*firstRow.add(molbatchid);
            firstRow.add(u_molbatchspecimenid);*/
            firstRow.add(quant_one);
            firstRow.add(quant_two);
            firstRow.add(calconc);
            firstRow.add(sample_vol);
            firstRow.add(dnaul);
            firstRow.add(waterul);
            recordToAdd.add(firstRow);
        }
        FileOutputStream fos = null;
        try {
            for (int j = 0; j < recordToAdd.size(); j++) {
                if (rownum == 0) {
                    Row row = firstSheet.createRow(rownum);
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        Cell cell = row.createCell(k);
                        cell.setCellValue(l2.get(k));
                        cell.setCellStyle(style);
                    }
                } else {
                    Row row = firstSheet.createRow(rownum);
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        Cell cell = row.createCell(k);
                        cell.setCellValue(l2.get(k));
                        cell.setCellStyle(borderStyle);
                    }
                }
                rownum++;
            }
            fos = new FileOutputStream(new File(localtionfilename));
            //AUTO SIZE COLUMN
            int rowcol = 0;
            for (int j = 0; j < recordToAdd.size(); j++) {
                if (rowcol == 0) {
                    List<String> l2 = recordToAdd.get(j);
                    for (int k = 0; k < l2.size(); k++) {
                        firstSheet.autoSizeColumn(k);
                    }
                }
                rowcol++;
            }
            //WRITE DATA INTO EXCEL
            workbook.write(fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

    }

    private String getFileLocation() throws SapphireException {
        String fileLocation = "";

        PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "MolecularDefaultLocation");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }
        //CHECK FOLDER
        //fileLocation = "C:\\Temp";//TODO HIDE FOR SERVER
        fileLocation = Util.createFolderForMolecular(fileLocation, "COBAS");
        return fileLocation;
    }

    private String generateFileName(String batchid) throws SapphireException {
        String latestfilename = "";
        String sql = MolecularSql.GET_ATTACHMENT_BY_BATCHID_COBAS;
        sql = Util.parseMessage(sql, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsAttachmentInfo = getQueryProcessor().getSqlDataSet(sql);
        int attachmentcount = dsAttachmentInfo.size();
        String tails = "A";
        if (attachmentcount == 0) {
            char c = tails.charAt(0);
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        } else {
            int c = tails.charAt(0) + attachmentcount;
            char newc = (char) c;
            latestfilename = String.valueOf(newc);
        }
        return latestfilename;
    }

    private void attachedExportReport(String batchid, String filenameformat) throws SapphireException {
        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Dummy");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, batchid);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "COBASCalculation");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "COBASCalculation");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenameformat);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "U");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, new File(filenameformat).getName());
        attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");
        attachprop.setProperty("ATTACHMENTCLASS", "SOP");
        attachprop.setProperty("SOURCEFILENAME", filenameformat);
        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. Attachment not added.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
    }

    private DataSet getMainDataSet(DataSet dsCobasBatchInfo) throws SapphireException {
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("specimen_id", DataSet.STRING);
        dsFinal.addColumn("mol_batch_id", DataSet.STRING);
        dsFinal.addColumn("batch_specimen_id", DataSet.STRING);
        dsFinal.addColumn("extraction_id", DataSet.STRING);
        dsFinal.addColumn("quant_one", DataSet.STRING);
        dsFinal.addColumn("quant_two", DataSet.STRING);
        dsFinal.addColumn("sample_vol", DataSet.STRING);
        dsFinal.addColumn("concentration", DataSet.STRING);
        dsCobasBatchInfo.sort("s_sampleid,u_extractionid");
        ArrayList<DataSet> arrBatchInfo = dsCobasBatchInfo.getGroupedDataSets("s_sampleid,u_extractionid");
        for (int i = 0; i < arrBatchInfo.size(); i++) {
            DataSet dsEach = (DataSet) arrBatchInfo.get(i);
            for (int d = 0; d < dsEach.size(); d++) {
                if (d < 2) {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, "specimen_id", dsEach.getValue(d, "s_sampleid", ""));
                    dsFinal.setValue(rowID, "mol_batch_id", dsEach.getValue(d, "molbatchid", ""));
                    dsFinal.setValue(rowID, "batch_specimen_id", dsEach.getValue(d, "u_molbatchspecimenid", ""));
                    dsFinal.setValue(rowID, "extraction_id", dsEach.getValue(d, "u_extractionid", ""));
                    dsFinal.setValue(rowID, "concentration", dsEach.getValue(d, "readingconc", ""));
                    //dsFinal.setValue(rowID, "concentration", dsEach.getValue(d, "concentration", ""));
                    dsFinal.setValue(rowID, "sample_vol", dsEach.getValue(d, "qtycurrent", ""));
                }
            }
        }
        DataSet dsMain = new DataSet();
        dsMain.addColumn("specimen_id", DataSet.STRING);
        dsMain.addColumn("mol_batch_id", DataSet.STRING);
        dsMain.addColumn("batch_specimen_id", DataSet.STRING);
        dsMain.addColumn("extraction_id", DataSet.STRING);
        dsMain.addColumn("quant_one", DataSet.STRING);
        dsMain.addColumn("quant_two", DataSet.STRING);
        dsMain.addColumn("sample_vol", DataSet.STRING);
        dsMain.addColumn("concentration", DataSet.STRING);
        if (dsFinal.size() > 0) {
            dsFinal.sort("specimen_id,extraction_id");
            ArrayList<DataSet> arrInputBatchInfo = dsFinal.getGroupedDataSets("specimen_id,extraction_id");
            for (int i = 0; i < arrInputBatchInfo.size(); i++) {
                DataSet dsEach = (DataSet) arrInputBatchInfo.get(i);
                int rowID = dsMain.addRow();
                dsMain.setValue(rowID, "specimen_id", dsEach.getValue(0, "specimen_id", ""));
                dsMain.setValue(rowID, "mol_batch_id", dsEach.getValue(0, "mol_batch_id", ""));
                dsMain.setValue(rowID, "batch_specimen_id", dsEach.getValue(0, "batch_specimen_id", ""));
                dsMain.setValue(rowID, "extraction_id", dsEach.getValue(0, "extraction_id", ""));
                dsMain.setValue(rowID, "quant_one", dsEach.getValue(0, "concentration", ""));
                dsMain.setValue(rowID, "quant_two", dsEach.getValue(1, "concentration", ""));
                dsMain.setValue(rowID, "sample_vol", dsEach.getValue(0, "sample_vol", ""));
            }
        }
        if (dsMain.size() > 0) {
            return dsMain;
        }
        return null;
    }

}
