package sapphire.custom.ng.action.quantification;

import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class AddElutionTube extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String extractionid = properties.getProperty("extractionid");
        String scannedsample = properties.getProperty("scannedsample");
        String batchid = properties.getProperty("batchid");

        if (Util.isNull(extractionid))
            throw new SapphireException("<b>Please scan elution tube(s).</b>");
        if (Util.isNull(batchid))
            throw new SapphireException("<b>Batch ID can not be blank.</b>");

        String sql = Util.parseMessage(MolecularSql.VALIDATE_BATCH_SAMPLE, extractionid, batchid);
        DataSet dsBatchSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchSampleInfo.size() > 0) {
            throw new SapphireException("<b>Elution tube already exist into this batch.</b>");
        }
        //GET BATCH DETAILS
        String extractiontype = "";
        sql = Util.parseMessage(MolecularSql.GET_BATCH_DET_BY_BATCHID, batchid);
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo != null && dsBatchInfo.size() > 0) {
            extractiontype = dsBatchInfo.getValue(0, "extractiontype", "");
        }
        //GET SAMPLE EXTRACTION TYPE
        sql = Util.parseMessage(MolecularSql.GET_EXTRACTIONTYPE_BY_EXTRCTNID, StringUtil.replaceAll(extractionid, ";", "','"));
        DataSet dsExrctnInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsExrctnInfo == null || dsExrctnInfo.size() == 0) {
            throw new SapphireException("<b>Extraction Type is not found for the specimen(s).</b>");
        }
        String smextrcttype = dsExrctnInfo.getColumnValues("extractiontype", ";");
        if (!smextrcttype.contains(extractiontype)) {
            throw new SapphireException("<b>Please scan " + extractiontype + " extraction type specimen(s) only.</b>");
        }
        //if (dsBatchSampleInfo.size() == 0) {
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        props.setProperty("sampleid", scannedsample);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        } catch (Exception ex) {
            throw new SapphireException("<b>Unable to add specimen(s) into the batch.</b>");
        }
        //}
        properties.setProperty("msg", "<b>Elution tube has been added into the batch.</b>");
    }
}
