package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.ExcelParsing;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by ssen on 10/18/2016.
 */
public class PerformNanodrop extends BaseAction {
    /**
     * This method is used for Nanodrop File parse.
     * @param properties
     * @throws sapphire.SapphireException
     * */
    public void processAction(PropertyList properties) throws SapphireException {
        String file = properties.getProperty("path", "");
        if (Util.isNull(file))
            throw new SapphireException("file is not found. Please upload a valid file.");
        if (file.indexOf(".txt") <= 0)
            throw new SapphireException("Invalid file format obtained. Please upload a txt file format.");
        else {
            DataSet ds = ExcelParsing.nanoDropFileParse(file);
            /** Validate the Sample*/
            if (ds == null && ds.size() == 0)
                    throw new SapphireException("No Data found inside File");
                /*String sampleIdSQL = "SELECT s.s_sampleid as sampleid " +
                        "FROM s_sample s,trackitem t " +
                        "WHERE s.s_sampleid= t.linkkeyid1 " +
                        "AND s.s_sampleid in ('" + StringUtil.replaceAll(ds.getColumnValues("sampleid", ";"), ";", "','") + "')";*/
            String sampleIdSQL = "select s.s_sampleid as sampleid,s.u_extractionid as extractionid  from s_sample s,trackitem t " +
                    "where s.s_sampleid=t.linkkeyid1 and t.containertypeid='Ellution Tube' and s.u_extractionid in('" + StringUtil.replaceAll(ds.getColumnValues("extractionid", ";"), ";", "','") + "')";
                DataSet dssample = getQueryProcessor().getSqlDataSet(sampleIdSQL);
                if(dssample==null || dssample.size()==0)
                    throw new SapphireException("Query "+sampleIdSQL+" is not returning any row.");
                HashMap<String,String> hmap = new HashMap<>();
                for(int i=0;i<ds.size();i++){
                    String sampleId=ds.getValue(i,"extractionid","");
                    if(Util.isNull(sampleId))
                        throw  new SapphireException("Extraction Id is not found in the row "+(i+1));
                    hmap.clear();
                    hmap.put("extractionid",sampleId);
                    DataSet tempFiltrDs = dssample.getFilteredDataSet(hmap);
                    if(tempFiltrDs==null || tempFiltrDs.size()==0)
                        throw  new SapphireException("Extraction id "+sampleId+" is not a valid sample");
                }
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dssample.getColumnValues("sampleid", ";"));
                props.setProperty("concentration", ds.getColumnValues("conc.", ";"));
                props.setProperty("concentrationunits", ds.getColumnValues("units", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);




        }
    }
}
