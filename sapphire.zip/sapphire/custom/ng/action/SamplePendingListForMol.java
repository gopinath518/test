package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 11/1/2016.
 */
public class SamplePendingListForMol extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sql="select s.s_sampleid from u_samplemovementsteps sm,s_sample s where \n" +
                "sampleid in(select sourcesampleid from s_samplemap where SOURCESAMPLEID \n" +
                "in(select sampleid from u_samplemovementsteps where totramstop='Accessioning') \n" +
                "and totramstop not in('MolecularExtraction')) and s.s_sampleid=sm.sampleid \n" +
                "and sysdate-sm.createdt>2 order by sm.createdt ";
        DataSet pendinglist=getQueryProcessor().getSqlDataSet(sql);

        String pendingsamp="select destsampleid from s_samplemap where sourcesampleid in('"+ StringUtil.replaceAll(pendinglist.getColumnValues("s_sampleid",";"),";","','")+"')";
        DataSet pendingds=getQueryProcessor().getSqlDataSet(pendingsamp);
        String sampleid=pendingds.getColumnValues("destsampleid",";");
        properties.setProperty("sampleid",sampleid);
    }
}
