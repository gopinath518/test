package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 8/24/2016.
 * @Desc :This class is responsible to copy a Discovery Agilent day1 batch.
 * The batch is created by parsing the excel sheet which contains Extraction ID.
 * The name of the excel file must start with NGS.
 */
public class DiscoveryAgilentDay2Batch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException{
        String batchid=properties.getProperty("batchid");
        String filename=properties.getProperty("path");
        String origin=properties.getProperty("origin");
        String pageid=properties.getProperty("pageid");
        String batchtype=properties.getProperty("batchtype","NGS");
        String returntolistpage=properties.getProperty("returntolistpage");
        String sql="select batchname from u_ngbatch where u_ngbatchid='"+batchid+"'";
        String msg="";
        String newbatch="";
        DataSet dsbatchname =getQueryProcessor().getSqlDataSet(sql);
        String batchname=dsbatchname.getColumnValues("batchname",";");
            if (!Util.isNull(filename)) {
                //load to plate and create new plate
                PropertyList plBatchPlate = new PropertyList();
                plBatchPlate.setProperty("batchname", batchname);
                plBatchPlate.setProperty("path", filename);
                plBatchPlate.setProperty("associatereagent", "Y");
                plBatchPlate.setProperty("copyfile", "N");
                plBatchPlate.setProperty("pageid",pageid);
                plBatchPlate.setProperty("origin",origin);
                plBatchPlate.setProperty("batchtype",batchtype);
                plBatchPlate.setProperty("returntolistpage",returntolistpage);
                getActionProcessor().processAction("CreateMolecularBatch", "1", plBatchPlate);
                msg=plBatchPlate.getProperty("msg");
                newbatch=plBatchPlate.getProperty("batchid");
                updateBatch(newbatch,batchid,origin);
            }
            else {
                throw new SapphireException("Plate Map is not found for the batch "+batchname);
            }

               properties.setProperty("msg",msg);
               properties.setProperty("parentbatchid",newbatch);

        }

    /**
     * @Desc :Associates the parent batch from which the new batch is copied.
     * @param newbatch -Newly created Batch ID
     * @param batchid - Parent Batch ID from which the new batch is copied
     * @throws SapphireException
     *
     */
    private void updateBatch(String newbatch,String batchid,String origin) throws SapphireException{
        PropertyList prop=new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID,"NGBatch");
        prop.setProperty(EditSDI.PROPERTY_KEYID1,newbatch);
        prop.setProperty("parentbatchid",batchid);
        if(origin.equalsIgnoreCase("MicroArrayDay2"))
            prop.setProperty("batchmovestatus","MADay1Completed");
        if(origin.equalsIgnoreCase("MicroArrayDay3"))
            prop.setProperty("batchmovestatus","MADay2Completed");

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,prop);
    }

    }

