package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdi.EditSDI;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by smitra on 4/26/2016. Modified by sbaitalik 10/6/2016
 */
public class CuttingSample extends BaseAction {

    private static final String PROPERTY_METH_IHC = "IHC";
    private static final String PROPERTY_METH_FISH = "FISH";
    private static final String PROPERTY_METH_MOLEULAR = "Molecular";
    private static final String PROPERTY_METH_MULTIOMIX = "Multiomyx";
    private static final String PROPERTY_METH_GENERIC = "Generic";
    private static final String PROPERTY_GENERATE_SLIDE_FOR_RECUTTING = "recutslide";

    private final String SOLID_SAMPLES = "Tissue";
    private String newSlideIDs = "";
    private String defaultMicrotomyStation = "";
    private PropertyList homogeneousLOS = null;
    private static final String HOMOGENEOUSLOSPOLICYID = "HomogeneousLOSPolicy";
    private static final String NODEID = "LOS";
    private static final String POLICY_MAPPING = "losmapping";
    private static final String POLICY_PARENT_LOS = "parentlos";
    private static final String POLICY_CHILD_LOS = "childlos";
    private static final String POLICY_CHILD_LOS_ID = "childlosid";

    private DataSet dsSlides = null;// slides for dos
    private DataSet dsIHCSlides = null;
    private DataSet dsFishSlides = null;
    private DataSet dsGenericSlides = null;
    private DataSet dsMolSlides = null;
    private DataSet dsMOSlides = null;
    private DataSet dsBackupTestCode = null;
    private DataSet dsCuttingPriority = null;
    private TreeMap<Integer, String> priorityMap = null;

    private final String POLICY_NAME = "HETestCodes";
    private final String POLICY_NODE_MOLECULAR = "Molecular";
    private final String POLICY_NODE_FISH = "FISH";

    private boolean RE_CUTTING_FLAG = false;


    /**
     * @param properties: properties send from calling function
     * @throws SapphireException
     * @desc: LabVantage BaseAction override function.
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        newSlideIDs = "";
        String sampleid = properties.getProperty("parentsamples");
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        validateOnlyOneSample(sampleid);
        validationForSlides(sampleid);
        validateOnlyCrrntMovementStep(sampleid);
        hasTestCodes(sampleid);
        DataSet dsSlides = hasSectionedCheckBlock(sampleid);
        // Validate if user not assigned to any microtomy station or not
        validateUserDefaultMicrotomyStation();
        setHomogeneousLOS();

        String sqlSrcSampleDetails = Util.parseMessage(ApSql.GET_PARENT_SAMPLE_DETAILS, sampleid);
        DataSet dsInput = getQueryProcessor().getSqlDataSet(sqlSrcSampleDetails);
        if (dsInput == null) {
            String errmsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + sqlSrcSampleDetails;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (dsInput.getRowCount() == 0) {
            String errmsg = getTranslationProcessor()
                    .translate("Cannot Prodeed futher as there is no Test code associated with the selected sampleid::")
                    + sampleid;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errmsg);
        }

        validateSample(dsInput);
        dsInput.sort("methodology");

        HashMap hm = new HashMap();

        // ********** identify it is a recutting or it is a fresh cutting *************************************//
        String noOfChildOfBlock = dsInput.getValue(0,"childsamplecount","0");
        if(Integer.parseInt(noOfChildOfBlock)>0) {

            RE_CUTTING_FLAG = true;
            String sqlChildSample = Util.parseMessage(ApSql.GET_CHILD_SAMPLE_TEST_CODE_INFO, sampleid);

            //Recutting applicable
            DataSet dsEarlierChildSlides = getQueryProcessor().getSqlDataSet(sqlChildSample);
            //compare and create column in dsInput for child create y/n
            if (!dsInput.isValidColumn(PROPERTY_GENERATE_SLIDE_FOR_RECUTTING)) {
                dsInput.addColumn(PROPERTY_GENERATE_SLIDE_FOR_RECUTTING, DataSet.STRING);
            }

            for (int l = 0; l < dsInput.getRowCount(); l++) {
                String testcodeTmp = dsInput.getValue(l, "lvtestcode", "");
                hm.clear();
                hm.put("lvtestcodeid", testcodeTmp);

                DataSet dsFilter = dsEarlierChildSlides.getFilteredDataSet(hm);

                if (dsFilter != null && dsFilter.size() > 0) {
                    //Slide created earlier already exists
                    dsInput.setValue(l, PROPERTY_GENERATE_SLIDE_FOR_RECUTTING, "N");
                } else {
                    dsInput.setValue(l, PROPERTY_GENERATE_SLIDE_FOR_RECUTTING, "Y");
                }
            }

            //If no new testcode associated to the block then no need to proceed further.
            hm.clear();
            hm.put(PROPERTY_GENERATE_SLIDE_FOR_RECUTTING, "Y");
            DataSet dsNewTestAddedToBlock = dsInput.getFilteredDataSet(hm);

            if (dsNewTestAddedToBlock == null || dsNewTestAddedToBlock.size() == 0) {
                //All Slide created earlier already exists in the system and no new testcode associated.
                String errMsg = "All the slide(s) has already been created earlier. Please associate new test and then try recut.";
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
        }

        /****************  call shared h&e code here... *****************************************/
        //1. filter only the shared h&e testcode
        if(!RE_CUTTING_FLAG) {
            hm.clear();
            hm.put("isshared", "Y");
            DataSet dsSharedHNE = dsInput.getFilteredDataSet(hm);
            if (dsSharedHNE != null && dsSharedHNE.size() > 0) {
                cuttingForGenericConcurrency(dsSharedHNE);
                controlRegularHnEGen(dsInput);
            }
        }

        //ArrayList dsGroupByMethArray = dsInput.getGroupedDataSets("methodology");
        hm.clear();
        hm.put("isshared", "N");
        DataSet dsAllMeth = dsInput.getFilteredDataSet(hm);
        ArrayList dsGroupByMethArray = dsAllMeth.getGroupedDataSets("methodology");
        for (int i = 0; i < dsGroupByMethArray.size(); i++) {

            DataSet dsIndividualGroup = (DataSet) dsGroupByMethArray.get(i);
            if (dsIndividualGroup == null || dsIndividualGroup.size() == 0) {
                logger.info(i + "th rows don't have any methodology");
                continue;
            }

            String methodology = dsIndividualGroup.getValue(0, "methodology", "");
            String los = dsIndividualGroup.getValue(0, "los", "");
            String panellos = dsIndividualGroup.getValue(0, "panellos", "");// TODO
            // pls make sure only one los exists for PANEL
            int testCodeCount = dsIndividualGroup.getRowCount();
            String distnctlos = Util.getUniqueList(dsIndividualGroup.getValue(0, "los", ""), ";", true);


            if (PROPERTY_METH_MOLEULAR.equalsIgnoreCase(methodology)) {// for
                /**** molecular there is no DOS, everthing will be by concurrency rule ******/
                if(!RE_CUTTING_FLAG){
                    cuttingForMolecularConcurrency(dsIndividualGroup);
                }
            } else if (PROPERTY_METH_MULTIOMIX.equalsIgnoreCase(methodology)) {
                if(!RE_CUTTING_FLAG){
                    cuttingForMultiomixConcurrency(dsIndividualGroup);
                }
            } else if (PROPERTY_METH_FISH.equalsIgnoreCase(methodology)) {

                if(RE_CUTTING_FLAG){
                    hm.clear();
                    hm.put(PROPERTY_GENERATE_SLIDE_FOR_RECUTTING, "Y");
                    DataSet dsSlidesForRecut = dsIndividualGroup.getFilteredDataSet(hm);
                    if(dsSlidesForRecut.getRowCount()>0) {
                        cuttingForFISHConcurrency(dsSlidesForRecut);
                    }
                }else {
                    cuttingForFISHConcurrency(dsIndividualGroup);
                }
            } else {
                if (testCodeCount == 1 || (Util.isNull(distnctlos))) {// for FISH, IHC
                    // ---- GOTO DOS ------------//
                    if(RE_CUTTING_FLAG){
                        String errMsg = "All the slide(s) has already been created earlier. Unable to recut the block";
                        throw new SapphireException(ErrorDetail.TYPE_VALIDATION,errMsg);
                    }else {
                        cuttingWithDOSRule(dsIndividualGroup);
                    }

                } else {
                    // ----- GOTO Concurrency for IHC -----------//
                    if (PROPERTY_METH_IHC.equalsIgnoreCase(methodology)) {
                        if(RE_CUTTING_FLAG){
                            hm.clear();
                            hm.put(PROPERTY_GENERATE_SLIDE_FOR_RECUTTING, "Y");
                            DataSet dsSlidesForRecut = dsIndividualGroup.getFilteredDataSet(hm);
                            if(dsSlidesForRecut.getRowCount()>0) {
                                cuttingForIHCConcurrency(dsSlidesForRecut);
                            }
                        }else {
                            cuttingForIHCConcurrency(dsIndividualGroup);
                        }
                    }
                }
            }
        }

        updateHNELabelDetail();

        /**
         * Priority Rule is applied to sample to display child sample in screen
         * in a particular order. Microtomy person will create slide in that
         * order from the Block Global rule is: 1st row -- H&E 2nd row -- Test
         * Slides/ unstained slides 3rd row -- Backup Slides
         *
         */
        applyPriorityRule(dsAllMeth);

        // TODO lebel printing here... Fetch lebel printer from sysuser.
        String printlabel = "";
        for (int i = 0; i < dsAllMeth.getRowCount(); i++) {
            if (("Y".equalsIgnoreCase(dsAllMeth.getValue(i, "isneotypepanel")))) {
                printlabel = "N";
                break;
            }

        }
        if (!("N".equalsIgnoreCase(printlabel)))
            generatePrintLabel(newSlideIDs, dsAllMeth);

        assignSlideSectioneddt(newSlideIDs);
        updateSlideSectionDate(dsInput);
        getAllChildsAssociatedWithBlock(sampleid);
        properties.setProperty("newkeyid1", newSlideIDs);
        properties.setProperty("message", dsSlides.getColumnValues("destsampleid", ","));
        logger.info("Microtomy complete");
    }
    /**
     * This is added for updateSlideSectionDate in portal lable
     * @param dsInput
     * @throws SapphireException
     */
    private void updateSlideSectionDate(DataSet dsInput) throws SapphireException {
   	 try {
   		// String accessionid = properties.getProperty("accessionid");
   		String accessionid = dsInput.getValue(0, "u_accessionid", "");
            //DataSet dsTestCodePolicy = getTestCodePolicy();
            DataSet dsTestCodePolicy = Util.getAnalyteTestCodeValidationRule(getQueryProcessor(), "slidesectoneddt");
            if (dsTestCodePolicy.size() > 0) {
                enterDataForAmgen(accessionid, dsTestCodePolicy);
            }
           // getResponse(ajaxResponse, "Success", tabletype, accessionid);
        } catch (Exception ex) {
       	 throw new SapphireException("Error in updateSlideSectionDate method.\n" + ex.getMessage());
            //getResponse(ajaxResponse, "Failed", tabletype, accessionid);
        }
   }
    private void enterDataForAmgen(String accessionid, DataSet dsTestCodePolicy) throws SapphireException {
        String testcodePolicy = dsTestCodePolicy.getColumnValues("testcode", "','");
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES, accessionid, testcodePolicy);
        //String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES, accessionid, testcodePolicy);
        String sampleTestAmgen = Util.parseMessage(ApSql.GET_TESTCODES_BY_ACCESSION_SLIDES_PORTAL, accessionid, testcodePolicy);
        DataSet dsTestAmgen = getQueryProcessor().getSqlDataSet(sampleTestAmgen);
        if (dsTestAmgen != null && dsTestAmgen.size() > 0) {
            String testname = StringUtil.replaceAll(dsTestAmgen.getColumnValues("testname", ";"), ";", "','");
            String slides = StringUtil.replaceAll(dsTestAmgen.getColumnValues("s_sampleid", ";"), ";", "','");
            String sqlenterdata = Util.parseMessage(ApSql.GET_PARAMIDS, slides, testname);
            DataSet dsSqlEnterData = getQueryProcessor().getSqlDataSet(sqlenterdata);
            if (dsSqlEnterData != null && dsSqlEnterData.size() > 0) {
                for (int i = 0; i < dsSqlEnterData.size(); i++) {
                    String slidesectiondt = dsSqlEnterData.getValue(i, "u_slidesectiondate", "");
                    if (!Util.isNull(slidesectiondt)) {
                        try {
                            //input date format
                            SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyyy");
                            //output date format
                            SimpleDateFormat dFormatFinal = new SimpleDateFormat("dd-MMM-yyyy");
                            Date date = dFormat.parse(slidesectiondt);
                            String formtSlideSectndt = dFormatFinal.format(date);
                            dsSqlEnterData.setValue(i, "u_slidesectiondate", formtSlideSectndt.toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                PropertyList props = new PropertyList();
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsSqlEnterData.getColumnValues("childsampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsSqlEnterData.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsSqlEnterData.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsSqlEnterData.getColumnValues("paramid", ";"));
                props.setProperty("enteredtext", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty("displayvalue", dsSqlEnterData.getColumnValues("u_slidesectiondate", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsSqlEnterData.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsSqlEnterData.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsSqlEnterData.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, dsSqlEnterData.getColumnValues("dataset", ";"));
                try {
                    getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);
                } catch (SapphireException e) {
                    throw new SapphireException("EnterDataItem not performed." + e.getMessage());
                }
            }
        }
    }
    private void controlRegularHnEGen(DataSet dsInput) throws SapphireException{

        if(!dsInput.isValidColumn("regularhnerequired")) {
           // dsInput.addColumn("regularhnerequired", DataSet.STRING);
            dsInput.addColumnValues("regularhnerequired", DataSet.STRING,"",";","Y");
        }
        String lvTestCode=dsInput.getColumnValues("lvtestcode","','");
        String sql=Util.parseMessage(ApSql.GET_SHAREDHNE_DATA,lvTestCode);
        DataSet dsSql=getQueryProcessor().getSqlDataSet(sql);


        HashMap hm=new HashMap();
        for(int i=0;i<dsSql.size();i++){
            String methodology=dsSql.getValue(i,"methodology");

            hm.clear();
            hm.put("methodology",methodology);
            DataSet dsMethodology=dsInput.getFilteredDataSet(hm);
            if(dsMethodology!=null && dsMethodology.size()>0){
                for(int j=0;j<dsMethodology.size();j++) {
                    dsMethodology.setValue(j, "regularhnerequired", "N");
                }
            }

        }

    }

    private void assignSlideSectioneddt(String childsamples) throws SapphireException {
        String childArry[] = StringUtil.split(childsamples, ";");
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, childsamples);
        prop.setProperty("u_slidesectiondate", StringUtil.repeat("n", childArry.length, ";"));
        //prop.setProperty("u_slidesectiondate", StringUtil.repeat(crrntdt.toUpperCase(), childArry.length, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update slide sectioned date in child sample" + ae.getMessage());
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }

    private void updateHNELabelDetail() throws SapphireException {
        DataSet dsLabel = new DataSet();
        dsLabel.addColumn("hnesampleid", DataSet.STRING);
        dsLabel.addColumn("usssampleid", DataSet.STRING);

        if (dsMolSlides != null && dsMolSlides.size() > 0) {
            dsMolSlides.sort(DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE);
            ArrayList dsGroupByExtractionTypeArray = dsMolSlides
                    .getGroupedDataSets(DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE);// DNA,
            // RNA
            for (int i = 0; i < dsGroupByExtractionTypeArray.size(); i++) {
                DataSet dsIndividualGroup = (DataSet) dsGroupByExtractionTypeArray.get(i);
                if (dsIndividualGroup == null || dsIndividualGroup.size() == 0) {
                    continue;
                }

                // 1. Get the HNE Sample.
                HashMap hm = new HashMap();
                hm.put(DATASET_PROPERTY_CHILD_TYPE, SLIDE_SYMBOL_HE);
                DataSet dsHNE = dsIndividualGroup.getFilteredDataSet(hm);
                if (dsHNE == null || dsHNE.size() == 0) {
                    continue;
                }

                // 2. Put HNE, USS combination in dataset
                String hneSampleID = dsHNE.getValue(0, DATASET_PROPERTY_CHILD_SAMPLE_ID, "");
                for (int j = 0; j < dsIndividualGroup.size(); j++) {
                    String ussSampleID = dsIndividualGroup.getValue(j, DATASET_PROPERTY_CHILD_SAMPLE_ID, "");
                    if (!ussSampleID.equalsIgnoreCase(hneSampleID)) {
                        int rowID = dsLabel.addRow();
                        dsLabel.setValue(rowID, "hnesampleid", hneSampleID);
                        dsLabel.setValue(rowID, "usssampleid", ussSampleID);
                    }
                }
            }
        }

        if (dsLabel.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(AddSDI.PROPERTY_SDCID, "HNESampleDetail");
            props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsLabel.getRowCount()));
            props.setProperty("hnesampleid", dsLabel.getColumnValues("hnesampleid", ";"));
            props.setProperty("usssampleid", dsLabel.getColumnValues("usssampleid", ";"));

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        }
    }

    private void generatePrintLabel(String sampleids, DataSet dsInput) throws SapphireException {
        PropertyList prop = new PropertyList();

        prop.setProperty(PrintLabel.LABELTYPE_PROP, "Histology");
        prop.setProperty(PrintLabel.TRAMLINE_PROP, "");
        prop.setProperty(PrintLabel.TRAMSTOP_PROP, "");
        prop.setProperty(PrintLabel.KEYID1_PROP, sampleids);
        prop.setProperty(PrintLabel.SDCID_PROP, "Sample");
        prop.setProperty(PrintLabel.MICROTOMY_PRINT, "Y");

        try {
            getActionProcessor().processAction("PrintLabel", "1", prop);
        } catch (SapphireException se) {
            throw new SapphireException(se.getMessage());
        }
    }

    /**
     * @param dsIndividualGroup: Subset of DataSet with all molecular testcodes
     * @throws SapphireException
     * @desc:
     */
    private void cuttingForMolecularConcurrency(DataSet dsIndividualGroup) throws SapphireException {
        /**** Only one parent sample cutting is allowed  *******/
        String parentSampleID = dsIndividualGroup.getValue(0, "s_sampleid", "");
        String parentSampleTypeID = dsIndividualGroup.getValue(0, "sampletypeid", "");
        String parentContainerTypeID = dsIndividualGroup.getValue(0, "containertypeid", "");
        String los = dsIndividualGroup.getValue(0, "los", "");
        //String regularHneRequired = dsIndividualGroup.getValue(0, "regularhnerequired", "");
        String regularHneRequired = Util.getUniqueList(dsIndividualGroup.getColumnValues("regularhnerequired", ";"), ";", true);

        /*** can be semicolon seperated ***/
        String testCodes = dsIndividualGroup.getColumnValues("lvtestcode", ";");
        String testPanelCodes = dsIndividualGroup.getColumnValues("lvtestpanelid", ";"); // can
        if (Util.isDataSetColumnValuesNull(testPanelCodes)) {
            testPanelCodes = "";
        }

        String whereClause = getMolecularConcurrencyWhereClause(parentSampleID);
        dsMolSlides = initializeDataSet();

        String distinctLos = Util.getUniqueList(dsIndividualGroup.getColumnValues("los", ";"), ";", true);
        String sql = "select u_molecularconcurrencyid,u_molecularconcurrencyid,testslidedna,testsliderna,testslideneotype,hnedna,hnerna,hneneotype,testslideprotein,hneprotein"
                + " from u_molecularconcurrency" + " where " + whereClause;

        DataSet dsConcurrency = getQueryProcessor().getSqlDataSet(sql);
        if (dsConcurrency == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact you Administrator.");
            Util.queryReturnsNULLException(errMsg, sql);
        }
        if (dsConcurrency.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No Molecular concurrency rule defined for below LOS:")
                    + "<BREAK>" + distinctLos;
            Util.queryReturnsZeroRowException(errMsg, sql);
        }
        //If the shared h&E created then we won't be creating the regular h&e
        // 1. *********** Create H&E slides *********************
        // ,hnedna,hnerna,hneneotype

        if(regularHneRequired.equalsIgnoreCase("Y")|| regularHneRequired.equalsIgnoreCase("")) {

            if (Integer.parseInt(dsConcurrency.getValue(0, "hnedna", "0")) > 0) {
                addRowToDataSet(dsMolSlides, parentSampleID, getHnETestCodeIDByMethodology("DNA", POLICY_NODE_MOLECULAR), "", IS_PANEL_NO,
                        PROPERTY_METH_MOLEULAR, los, SLIDE_SYMBOL_HE, "N", parentSampleTypeID, parentContainerTypeID,
                        "DNA");
            }
            if (Integer.parseInt(dsConcurrency.getValue(0, "hnerna", "0")) > 0) {
                addRowToDataSet(dsMolSlides, parentSampleID, getHnETestCodeIDByMethodology("RNA", POLICY_NODE_MOLECULAR), "", IS_PANEL_NO,
                        PROPERTY_METH_MOLEULAR, los, SLIDE_SYMBOL_HE, "N", parentSampleTypeID, parentContainerTypeID,
                        "RNA");
            }
            if (Integer.parseInt(dsConcurrency.getValue(0, "hneneotype", "0")) > 0) {
                addRowToDataSet(dsMolSlides, parentSampleID, getHnETestCodeIDByMethodology("Neotype", POLICY_NODE_MOLECULAR), "", IS_PANEL_NO,
                        PROPERTY_METH_MOLEULAR, los, SLIDE_SYMBOL_HE, "N", parentSampleTypeID, parentContainerTypeID,
                        "DNA");
            }
            if (Integer.parseInt(dsConcurrency.getValue(0, "hneprotein", "0")) > 0) {
                addRowToDataSet(dsMolSlides, parentSampleID, getHnETestCodeIDByMethodology("PROTEIN", POLICY_NODE_MOLECULAR), "", IS_PANEL_NO,
                        PROPERTY_METH_MOLEULAR, los, SLIDE_SYMBOL_HE, "N", parentSampleTypeID, parentContainerTypeID,
                        "PROTEIN");
            }
        }
        // 2. ******* Create test slide for each test ***************
        int noOfTestSlide = 0;
        String panelFlag = "";
        String uniquePanel = "";
        if (!Util.isNull(testPanelCodes)) {
            panelFlag = IS_PANEL_YES;
            uniquePanel = Util.getUniqueList(testPanelCodes, ";", true);
        } else {
            panelFlag = IS_PANEL_NO;
        }

        if (Integer.parseInt(dsConcurrency.getValue(0, "testslidedna", "0")) > 0) { // TEST
            // SLIDES
            // FOR
            // DNA
            // Extraction
            noOfTestSlide = Integer.parseInt(dsConcurrency.getValue(0, "testslidedna", "0"));
            String testCodesForChild = getTestCodeFromParents(parentSampleID, "DNA"); // hash
            // (#)
            // seperated
            if (!Util.isNull(testCodesForChild)) {
                for (int l = 0; l < noOfTestSlide; l++) {
                    addRowToDataSet(dsMolSlides, parentSampleID, testCodesForChild, uniquePanel, panelFlag,
                            PROPERTY_METH_MOLEULAR, dsIndividualGroup.getValue(0, "los", ""), SLIDE_SYMBOL_TEST_SLIDE,
                            "N", parentSampleTypeID, parentContainerTypeID, "DNA");
                }
            }
        }
        if (Integer.parseInt(dsConcurrency.getValue(0, "testsliderna", "0")) > 0) { // TEST
            // SLIDES
            // FOR
            // RNA
            // Extraction
            noOfTestSlide = Integer.parseInt(dsConcurrency.getValue(0, "testsliderna", "0"));
            String testCodesForChild = getTestCodeFromParents(parentSampleID, "RNA");// #
            // seperated
            if (!Util.isNull(testCodesForChild)) {
                for (int l = 0; l < noOfTestSlide; l++) {
                    addRowToDataSet(dsMolSlides, parentSampleID, testCodesForChild, uniquePanel, panelFlag,
                            PROPERTY_METH_MOLEULAR, dsIndividualGroup.getValue(0, "los", ""), SLIDE_SYMBOL_TEST_SLIDE,
                            "N", parentSampleTypeID, parentContainerTypeID, "RNA");
                }
            }
        }
        if (Integer.parseInt(dsConcurrency.getValue(0, "testslideprotein", "0")) > 0) {// TEST
            // SLIDES
            // FOR
            // PROTEIN
            // Extraction
            noOfTestSlide = Integer.parseInt(dsConcurrency.getValue(0, "testslideprotein", "0"));
            String testCodesForChild = getTestCodeFromParents(parentSampleID, "PROTEIN");// #
            // seperated
            if (!Util.isNull(testCodesForChild)) {
                for (int l = 0; l < noOfTestSlide; l++) {
                    addRowToDataSet(dsMolSlides, parentSampleID, testCodesForChild, uniquePanel, panelFlag,
                            PROPERTY_METH_MOLEULAR, dsIndividualGroup.getValue(0, "los", ""), SLIDE_SYMBOL_TEST_SLIDE,
                            "N", parentSampleTypeID, parentContainerTypeID, "RNA");
                }
            }
        }
        if (Integer.parseInt(dsConcurrency.getValue(0, "testslideneotype", "0")) > 0) { // PANEL
            noOfTestSlide = Integer.parseInt(dsConcurrency.getValue(0, "testslideneotype", "0"));
            String uniquesPanels = Util.getUniqueList(testPanelCodes, ";", true);// this
            // can
            // be
            // semi
            // colon
            // seperated.
            for (int l = 0; l < noOfTestSlide; l++) {
                addRowToDataSet(dsMolSlides, parentSampleID, testCodes, uniquesPanels, IS_PANEL_YES,
                        PROPERTY_METH_MOLEULAR, dsIndividualGroup.getValue(0, "los", ""), SLIDE_SYMBOL_TEST_SLIDE, "N",
                        parentSampleTypeID, parentContainerTypeID, "DNA");
            }
        }

        /** Cobas exceptional workflow ******/

        HashMap hm = new HashMap();
        hm.put("followcobas","Y");
        DataSet dsCobasFollowerTest = dsIndividualGroup.getFilteredDataSet(hm);
        if(dsCobasFollowerTest!=null && dsCobasFollowerTest.size()>0){
            for (int i = 0; i < dsCobasFollowerTest.getRowCount(); i++) {
                String extractionType = dsCobasFollowerTest.getValue(i,"extractiontype","");
                String testCodesForChild = dsCobasFollowerTest.getValue(i,"lvtestcode","");
                //String testCodesForChild = getTestCodeFromParents(parentSampleID, "RNA");// #
                addRowToDataSet(dsMolSlides, parentSampleID, testCodesForChild, uniquePanel, panelFlag,
                        PROPERTY_METH_MOLEULAR, dsCobasFollowerTest.getValue(0, "los", ""), SLIDE_SYMBOL_TEST_SLIDE,
                        "N", parentSampleTypeID, parentContainerTypeID, extractionType);
            }
        }


        createChildSamples(dsMolSlides, PROPERTY_METH_MOLEULAR);
    }

    /**
     * Fish concurrency rules
     *
     * @param
     * @throws SapphireException....
     */

    private void cuttingForGenericConcurrency( DataSet dsSharedHNE ) throws SapphireException {

        // Only one parent sample cutting is allowed
        String parentSampleID = dsSharedHNE.getValue(0, "s_sampleid", "");
        String parentSampleTypeID = dsSharedHNE.getValue(0, "sampletypeid", "");
        String parentContainerTypeID = dsSharedHNE.getValue(0, "containertypeid", "");
        String methodology = dsSharedHNE.getValue(0, "methodology", "");


        dsGenericSlides = initializeDataSet();

        for (int loop = 0; loop < dsSharedHNE.getRowCount(); loop++) {
            String pHnEPanelCode = dsSharedHNE.getValue(loop,"panelcode", "");
            String pHnETestCode = dsSharedHNE.getValue(loop,"lvtestcode", "");

            addRowToDataSet(dsGenericSlides, parentSampleID, pHnETestCode, pHnEPanelCode, IS_PANEL_NO, PROPERTY_METH_GENERIC, "", SLIDE_SYMBOL_SHARED_HE, "N",
                    parentSampleTypeID, parentContainerTypeID, "");

        }

        createChildSamples(dsGenericSlides, PROPERTY_METH_GENERIC);
    }

    /********************************************************************
     private void cuttingForFISHConcurrency(DataSet dsIndividualGroup) throws SapphireException {

     HashMap hm = new HashMap();

     // Only one parent sample cutting is allowed
     String parentSampleID = dsIndividualGroup.getValue(0, "s_sampleid", "");
     String parentSampleTypeID = dsIndividualGroup.getValue(0, "sampletypeid", "");
     String parentContainerTypeID = dsIndividualGroup.getValue(0, "containertypeid", "");
     String methodology = dsIndividualGroup.getValue(0, "methodology", "");

     // t.lvtestcodeid lvtestcode,t.ispanel,t.lvtestpanelid
     String parentTestCodeID = Util.getUniqueList(dsIndividualGroup.getColumnValues("", ";"), ";", true);
     String parentIsPanel = dsIndividualGroup.getValue(0, "ispanel", "");
     String parentPanelID = dsIndividualGroup.getValue(0, "lvtestpanelid", "");

     dsFishSlides = initializeDataSet();

     String parentTestCode = dsIndividualGroup.getColumnValues("lvtestcode", ";");
     String parentTestCodeLos = dsIndividualGroup.getColumnValues("los", ";");
     //1. duplicate testcode free dsIndividualGroup

     //2. Create all unstained slide
     int slideCount = 0;
     String hneflag = "";
     String childType = "";
     String hneTestCode = "";
     for (int i = 0; i < dsIndividualGroup.getRowCount(); i++) {
     childType = "";
     hneflag = dsIndividualGroup.getValue(i, "hneflag", "");
     hneTestCode = dsIndividualGroup.getValue(i, "lvtestcode", "");
     if (hneflag.equalsIgnoreCase("Y")) {
     slideCount = 1;
     childType = "H";
     } else {
     slideCount = 2;
     childType = "U";
     }

     //All the tests one by one from parent.
     String panelForSingleSample = "";
     String testsForSingleSample = "";

     dsIndividualGroup.sort("lvtestpanelid");
     ArrayList dsGroupByPanelArray = dsIndividualGroup.getGroupedDataSets("lvtestpanelid");
     for (int t = 0; t < dsGroupByPanelArray.size(); t++) {

     DataSet dsOneGroup = (DataSet) dsGroupByPanelArray.get(t);
     if (dsOneGroup == null || dsOneGroup.size() == 0) {
     continue;
     }

     String singlePanel = "";
     String allTestcodeUnderSinglePanel = "";
     if (childType.equalsIgnoreCase("H")) {
     singlePanel = dsOneGroup.getColumnValues("lvtestpanelid", ";");
     allTestcodeUnderSinglePanel = hneTestCode;

     } else {
     singlePanel = dsOneGroup.getColumnValues("lvtestpanelid", ";");
     if (singlePanel.startsWith(";")) {
     singlePanel = singlePanel.substring(1);
     }
     //allTestcodeUnderSinglePanel = dsOneGroup.getColumnValues("lvtestcode", ";");
     HashMap hmfilterOtherThanHNE = new HashMap();
     hmfilterOtherThanHNE.put("hneflag", "N");
     DataSet dsAllTestCodeOtherThanHNE = dsOneGroup.getFilteredDataSet(hmfilterOtherThanHNE);
     if (dsAllTestCodeOtherThanHNE != null && dsAllTestCodeOtherThanHNE.size() > 0) {
     allTestcodeUnderSinglePanel = dsAllTestCodeOtherThanHNE.getColumnValues("lvtestcode", ";");
     }
     }

     panelForSingleSample += "#" + singlePanel;
     testsForSingleSample += "#" + allTestcodeUnderSinglePanel;
     }

     if (panelForSingleSample.startsWith("#")) {
     panelForSingleSample = panelForSingleSample.substring(1);
     }

     if (testsForSingleSample.startsWith("#")) {
     testsForSingleSample = testsForSingleSample.substring(1);
     }


     for (int j = 0; j < slideCount; j++) {
     addRowToDataSet(dsFishSlides, parentSampleID, testsForSingleSample, panelForSingleSample, IS_PANEL_NO, PROPERTY_METH_FISH, "", childType, "N",
     parentSampleTypeID, parentContainerTypeID, "");

     }
     }

     // ------- Creating samples and applying test codes ------- //
     // Client wants to see the child sample in below fashion 1st: H&E, 2nd
     // test slide, 3rd: Backups( don't change below order of calling )
     tagHnESlides(dsFishSlides);
     //createBackupSlideForFish();
     createChildSamples(dsFishSlides, PROPERTY_METH_FISH);
     removeTestsFromUnstainedSlide(); //Special function for FISH only.

     }

     *********************************************************************/
    private void cuttingForFISHConcurrency(DataSet dsIndividualGroup) throws SapphireException {

        HashMap hm = new HashMap();

        // Only one parent sample cutting is allowed
        String parentSampleID = dsIndividualGroup.getValue(0, "s_sampleid", "");
        String parentSampleTypeID = dsIndividualGroup.getValue(0, "sampletypeid", "");
        String parentContainerTypeID = dsIndividualGroup.getValue(0, "containertypeid", "");
        String methodology = dsIndividualGroup.getValue(0, "methodology", "");

        // t.lvtestcodeid lvtestcode,t.ispanel,t.lvtestpanelid
        String parentTestCodeID = Util.getUniqueList(dsIndividualGroup.getColumnValues("", ";"), ";", true);
        String parentIsPanel = dsIndividualGroup.getValue(0, "ispanel", "");
        String parentPanelID = dsIndividualGroup.getValue(0, "lvtestpanelid", "");

        dsFishSlides = initializeDataSet();

        String parentTestCode = dsIndividualGroup.getColumnValues("lvtestcode", ";");
        String parentTestCodeLos = dsIndividualGroup.getColumnValues("los", ";");

        //1. get number of slide from project level


        String sql = Util.parseMessage(ApSql.FISH_CUTTING, parentSampleID);
        DataSet dsSlideCount = getQueryProcessor().getSqlDataSet(sql);
        if (dsSlideCount == null || dsSlideCount.getRowCount() == 0) {
            throw new SapphireException("No of slide not defined at project level.");
        }

        String noOfSlideStr = dsSlideCount.getValue(0, "fishslidecount", "");
        if ("".equals(noOfSlideStr)) {
            throw new SapphireException("# of slides to section is not provided in project level.");
        }
        int totalNoOfSlide = Integer.parseInt(noOfSlideStr);


        //----------- Create H&E slides ---------------------------------------
        DataSet dsHnETestsForSample = getTests(dsIndividualGroup, "Y"); // Get USS Testcodes
        String pHnEPanelCode = dsHnETestsForSample.getColumnValues("panelcode", "#");
        String pHnETestCode = dsHnETestsForSample.getColumnValues("testcode", "#");
        int noOfHnEToCreate = 0;
        if (dsHnETestsForSample == null && dsHnETestsForSample.size() == 0) {
            noOfHnEToCreate = 0;
        }

        noOfHnEToCreate = dsHnETestsForSample.size();
        for (int loop = 0; loop < noOfHnEToCreate; loop++) {
            addRowToDataSet(dsFishSlides, parentSampleID, pHnETestCode, pHnEPanelCode, IS_PANEL_NO, PROPERTY_METH_FISH, "", SLIDE_SYMBOL_HE, "N",
                    parentSampleTypeID, parentContainerTypeID, "");

        }

        //----------- Create Unstained slides ---------------------------------------
        int noOfUSStoBeCreated = totalNoOfSlide - noOfHnEToCreate; //

        DataSet dsTestsForSample = getTests(dsIndividualGroup, "N"); // Get USS Testcodes
        String pPanelCode = dsTestsForSample.getColumnValues("panelcode", "#");
        String pTestCode = dsTestsForSample.getColumnValues("testcode", "#");
        //2. Create all unstained slide
        for (int loop = 0; loop < noOfUSStoBeCreated; loop++) {

            addRowToDataSet(dsFishSlides, parentSampleID, pTestCode, pPanelCode, IS_PANEL_NO, PROPERTY_METH_FISH, "", SLIDE_SYMBOL_TEST_SLIDE, "N",
                    parentSampleTypeID, parentContainerTypeID, "");

        }


        // ------- Creating samples and applying test codes ------- //
        // Client wants to see the child sample in below fashion 1st: H&E, 2nd
        // test slide, 3rd: Backups( don't change below order of calling )
        tagHnESlides(dsFishSlides);
        createChildSamples(dsFishSlides, PROPERTY_METH_FISH);
        tagChildSlideWithTest(pPanelCode, pTestCode);
        removeTestsFromUnstainedSlide(); //Special function for FISH only.

    }

    private void tagChildSlideWithTest(String parentPanelCode, String parentTestCode) throws SapphireException {
        String updateStr = "";
        if (parentPanelCode.startsWith(";")) {
            parentPanelCode = parentPanelCode.substring(1);
        }

        if ("".equalsIgnoreCase(parentPanelCode)) {
            if (parentTestCode.contains(";")) {
                updateStr = "Multiple Tests";
            } else {
                updateStr = "Single Test";
            }

        } else {
            if (parentPanelCode.contains("#")) {
                updateStr = "Multiple Panel";
            } else {
                updateStr = "Single Panel";

            }
        }

        if ("".equals(updateStr)) {
            return;
        }


        HashMap hmfilter = new HashMap();
        hmfilter.put("childtype", "U");
        DataSet dsUSSTestCode = dsFishSlides.getFilteredDataSet(hmfilter);
        if (dsUSSTestCode != null && dsUSSTestCode.size() > 0) {
            PropertyList p = new PropertyList();
            p.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            p.setProperty("keyid1", dsUSSTestCode.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
            p.setProperty("u_fishslidetest", StringUtil.repeat(updateStr, dsUSSTestCode.getRowCount(), ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p);
        }

    }

    private DataSet getTests(DataSet dsIndividualGroup, String IsHnE) {
        DataSet dsTemp = new DataSet();
        dsTemp.addColumn("panelcode", DataSet.STRING);
        dsTemp.addColumn("testcode", DataSet.STRING);


        HashMap hmfilter = new HashMap();
        hmfilter.clear();
        hmfilter.put("hneflag", IsHnE);
        DataSet dsUSSTestCode = dsIndividualGroup.getFilteredDataSet(hmfilter);
        if (dsUSSTestCode == null && dsUSSTestCode.size() == 0) {
            //ussTestCode = dsUSSTestCode.getColumnValues("lvtestcode", "#");
            //ussPanelcode = dsUSSTestCode.getColumnValues("lvtestpanelid", "#");
            return null;
        }


        dsUSSTestCode.sort("lvtestpanelid");
        ArrayList dsGroupByPanelArray = dsUSSTestCode.getGroupedDataSets("lvtestpanelid");
        for (int i = 0; i < dsGroupByPanelArray.size(); i++) {

            DataSet dsIndividualPanelGroup = (DataSet) dsGroupByPanelArray.get(i);
            if (dsIndividualPanelGroup == null || dsIndividualPanelGroup.size() == 0) {
                logger.info(i + "th rows don't have any methodology");
                continue;
            }

            String individualPanel = dsIndividualPanelGroup.getColumnValues("lvtestpanelid", ";");
            String individualTestForEachPanel = dsIndividualPanelGroup.getColumnValues("lvtestcode", ";");

            int rowId = dsTemp.addRow();
            dsTemp.setValue(rowId, "testcode", individualTestForEachPanel);
            dsTemp.setValue(rowId, "panelcode", individualPanel);

        }

        return dsTemp;
    }

    /**
     * Create backup slides for FISH. backup slides are as unstained slides here.
     *
     * @throws SapphireException
     */
    private void createBackupSlideForFish() throws SapphireException {
        HashMap hmFilter = new HashMap();
        hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, PROPERTY_METH_FISH);
        hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, SLIDE_SYMBOL_TEST_SLIDE);
        DataSet allUSS = dsFishSlides.getFilteredDataSet(hmFilter);
        if (allUSS == null && allUSS.size() == 0) {
            return;
        }
        for (int j = 0; j < allUSS.getRowCount(); j++) {
            addRowToDataSet(dsFishSlides, allUSS.getValue(j, DATASET_PROPERTY_PARENT_SAMPLE_ID, ""),
                    allUSS.getValue(j, DATASET_PROPERTY_CHILD_TEST_CODE_ID, ""),
                    allUSS.getValue(j, DATASET_PROPERTY_CHILD_PANEL_ID, ""), IS_PANEL_NO,
                    PROPERTY_METH_FISH, allUSS.getValue(j, DATASET_PROPERTY_CHILD_SAMPLE_LOS, ""), SLIDE_SYMBOL_TEST_SLIDE, "N",
                    allUSS.getValue(j, DATASET_PROPERTY_CHILD_SAMPLE_TYPE_ID, ""),
                    allUSS.getValue(j, DATASET_PROPERTY_CHILD_TRANSPORT_TYPE_ID, ""), "");
        }

    }

    private void removeTestsFromUnstainedSlide() throws SapphireException {

        /*find if any panel is associated with FISh tests.
            If panel found then remove the testcode, testnames.
            if panel not found then don't remove testcodes, testnames
            IF only one test found in USS then also don't remove the tests.
        */

        String distinctPanels =
                Util.getUniqueList(dsFishSlides.getColumnValues(DATASET_PROPERTY_CHILD_PANEL_ID, ";"), ";", true);

        String distinctPanelsWithoutDelimiter = StringUtil.replaceAll(distinctPanels, ";", "");
        if ("".equals(distinctPanelsWithoutDelimiter)) {
            //Panel not found case
            return;
        }

        HashMap hmFilter = new HashMap();
        hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, SLIDE_SYMBOL_TEST_SLIDE);
        DataSet dsAllUSS = dsFishSlides.getFilteredDataSet(hmFilter);
        if (dsAllUSS == null && dsAllUSS.size() == 0) {
            return;
        }
        //String allSlide = dsAllUSS.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";");
        String allSlide = "";

        //get all the slide which have multiple testcodes...
        for (int count = 0; count < dsAllUSS.getRowCount(); count++) {
            String childSample = dsAllUSS.getValue(count, DATASET_PROPERTY_CHILD_SAMPLE_ID, "");
            String childTestCodes = dsAllUSS.getValue(count, DATASET_PROPERTY_CHILD_TEST_CODE_ID, "");
            if (childTestCodes.contains(";")) {
                allSlide += ";" + childSample;
            }
        }
        if (allSlide.startsWith(";")) {
            allSlide = allSlide.substring(1);
        }
        if ("".equalsIgnoreCase(allSlide)) {
            return;
        }

        hmFilter.clear();
        hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, SLIDE_SYMBOL_BACKUP);
        DataSet dsAllBackup = dsFishSlides.getFilteredDataSet(hmFilter);
        String allBackupSlides = "";
        if (dsAllBackup != null && dsAllBackup.size() > 0) {
            allBackupSlides = dsAllBackup.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";");
        }

        //Merging backup slides and Unstained slides
        if (!allBackupSlides.equals("")) {
            allSlide = allSlide + ";" + allBackupSlides;
        }

        String sql = Util.parseMessage(ApSql.GET_SAMPLE_TEST_CODE_MAP_BY_SAMPLE_ID, StringUtil.replaceAll(allSlide, ";", "','"));
        DataSet dsEditSDI = getQueryProcessor().getSqlDataSet(sql);
        if (dsEditSDI == null && dsEditSDI.size() == 0) {
            return;
        }
        //find if

        PropertyList p = new PropertyList();
        p.clear();
        p.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        p.setProperty("keyid1", dsEditSDI.getColumnValues("u_sampletestcodemapid", ";"));
        p.setProperty("lvtestcodeid", StringUtil.repeat("", dsEditSDI.getRowCount(), ";"));
        p.setProperty("testcode", StringUtil.repeat("", dsEditSDI.getRowCount(), ";"));
        p.setProperty("testname", StringUtil.repeat("", dsEditSDI.getRowCount(), ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p);

    }

    private void cuttingForMultiomixConcurrency(DataSet dsIndividualGroup) throws SapphireException {
        String parentSampleID = dsIndividualGroup.getValue(0, "s_sampleid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentSampleTypeID = dsIndividualGroup.getValue(0, "sampletypeid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentContainerTypeID = dsIndividualGroup.getValue(0, "containertypeid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentPanelID = dsIndividualGroup.getValue(0, "lvtestpanelid", "");
        String parentLOS = dsIndividualGroup.getValue(0, "los", "");
        String testCodes = dsIndividualGroup.getColumnValues("lvtestcode", ";"); // can
        // be
        // semicolon
        // seperated

        String regularHneRequired = Util.getUniqueList(dsIndividualGroup.getColumnValues("regularhnerequired", ";"), ";", true);


        dsMOSlides = initializeDataSet();

        // 1. ******* Create only one test slide and add the whole panel to it
        // ***************
        String uniquesPanels = Util.getUniqueList(parentPanelID, ";", true);// this
        // can
        // be
        // semi
        // colon
        // seperated.
        addRowToDataSet(dsMOSlides, parentSampleID, testCodes, uniquesPanels, IS_PANEL_YES, PROPERTY_METH_MULTIOMIX,
                parentLOS, SLIDE_SYMBOL_TEST_SLIDE, "N", parentSampleTypeID, parentContainerTypeID, "");

        // 2. Create hne Sample
        if(regularHneRequired.equalsIgnoreCase("Y")|| regularHneRequired.equalsIgnoreCase("")) {
            addRowToDataSet(dsMOSlides, parentSampleID, getMultiomyxHnETestCodeID(), "", IS_PANEL_NO,
                    PROPERTY_METH_MULTIOMIX, parentLOS, SLIDE_SYMBOL_HE, "N", parentSampleTypeID, parentContainerTypeID,
                    "");
        }

        // 3. *************** Create Backup slides *********************
        int noOFBackUpSlide = 0;
        String backupSlideForDept = "";
        String backupTestCode = getBackupTestCode(PROPERTY_METH_MULTIOMIX);
        addRowToDataSet(dsMOSlides, parentSampleID, backupTestCode, "", IS_PANEL_NO, PROPERTY_METH_MULTIOMIX, parentLOS,
                SLIDE_SYMBOL_BACKUP, "N", parentSampleTypeID, parentContainerTypeID, "");

        tagHnESlides(dsMOSlides);
        createChildSamples(dsMOSlides, PROPERTY_METH_MULTIOMIX);
    }

    /**
     * IHC concurrency rules
     *
     * @param dsIndividualGroup
     * @throws SapphireException....
     */
    private void cuttingForIHCConcurrency(DataSet dsIndividualGroup) throws SapphireException {
        String parentSampleID = dsIndividualGroup.getValue(0, "s_sampleid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentSampleTypeID = dsIndividualGroup.getValue(0, "sampletypeid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentContainerTypeID = dsIndividualGroup.getValue(0, "containertypeid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String methodology = dsIndividualGroup.getValue(0, "methodology", "");
        // String los = dsIndividualGroup.getValue(0, "los", "");
        String panellos = dsIndividualGroup.getValue(0, "panellos", "");
        String regularHneRequired = dsIndividualGroup.getValue(0, "regularhnerequired", "");



        dsIHCSlides = initializeDataSet();

        String distinctLos = Util.getUniqueList(synkHomogeneousLOS(dsIndividualGroup.getColumnValues("los", ";")), ";",
                true); // Replace Global Image by Global
        String sql = "";

        if ("Technical".equalsIgnoreCase(distinctLos)) {
            sql = "select distinct los1,los2,testslide,stainhne,technicalhne,globalhne, molecularhne, fishhne,"
                    + " stainbackup,globalbackup,technicalbackup, fishbackup, globalbackupmax,technicalbackupmax,stainonlybackupmax"
                    + " from u_ihcconcurrency where los1||'#'||los2 in ('" + getIHCLOSCombination(distinctLos, "#")
                    + "')";
        } else if ("Global".equalsIgnoreCase(distinctLos)) {
            sql = "select los1,los2,testslide,stainhne,technicalhne,globalhne, molecularhne, fishhne,"
                    + " stainbackup,globalbackup,technicalbackup, fishbackup, globalbackupmax,technicalbackupmax,stainonlybackupmax"
                    + " from u_ihcconcurrency where los1||'#'||los2 in ('" + getIHCLOSCombination(distinctLos, "#")
                    + "')";
        } else if ("Consult".equalsIgnoreCase(distinctLos)) {
            sql = "select u_ihcconcurrencyid,speciallosflag,los1,los2,testslide,stainhne,technicalhne,globalhne, molecularhne, fishhne,"
                    + " stainbackup,globalbackup,technicalbackup, fishbackup, globalbackupmax,technicalbackupmax,stainonlybackupmax"
                    + " from u_ihcconcurrency " + getWhereClauseForLOS(distinctLos, null);
        } else if ("Stain Only".equalsIgnoreCase(distinctLos)) {
            sql = "select los1,los2,testslide,stainhne,technicalhne,globalhne, molecularhne, fishhne,"
                    + " stainbackup,globalbackup,technicalbackup, fishbackup, globalbackupmax,technicalbackupmax,stainonlybackupmax"
                    + " from u_ihcconcurrency where los1||'#'||los2 in ('" + getIHCLOSCombination(distinctLos, "#")
                    + "')";
        } else if ("Morphology".equalsIgnoreCase(distinctLos)) {
            sql = "select"
                    + " h.los1,h.los2,h.testslide,h.stainhne,h.technicalhne,h.globalhne, h.molecularhne, h.fishhne,"
                    + " h.stainbackup,h.globalbackupmax,h.globalbackup,h.technicalbackupmax,h.stainonlybackupmax,h.technicalbackup, h.fishbackup,nvl(h.speciallosflag,'N') speciallosflag,"
                    + " r.sampletype,r.testcodeid lvtestpanelid,r.cassettecreated,level1hne,r.level1backupslide,r.level2hne, r.level2backupslide"
                    + " from u_ihcconcurrency h left outer join u_ihcconcurrencyrule r"
                    + " on h.u_ihcconcurrencyid = r.ihcconcurrencyid " + getWhereClauseForLOS(distinctLos, "h");

        } else {
            sql = "select los1,los2,testslide,stainhne,technicalhne,globalhne, molecularhne, fishhne,"
                    + " stainbackup,globalbackup,technicalbackup, fishbackup, globalbackupmax,technicalbackupmax,stainonlybackupmax"
                    + " from u_ihcconcurrency " + getWhereClauseForLOS(distinctLos, null);

        }

        // dsConcurrency will always return one row.
        DataSet dsConcurrency = getQueryProcessor().getSqlDataSet(sql);
        if (dsConcurrency == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact you Administrator.");
            Util.queryReturnsNULLException(errMsg, sql);
        }
        if (dsConcurrency.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No IHC concurrency rule defined for below LOS:")
                    + "<BREAK>" + distinctLos;
            Util.queryReturnsZeroRowException(errMsg, sql);
        }

        // 1. ******* Create test slide for each test ***************
        for (int i = 0; i < dsIndividualGroup.size(); i++) {
            addRowToDataSet(dsIHCSlides, parentSampleID, dsIndividualGroup.getValue(i, "lvtestcode", ""), "",
                    IS_PANEL_NO, PROPERTY_METH_IHC, dsIndividualGroup.getValue(i, "los", ""), "U", "N",
                    parentSampleTypeID, parentContainerTypeID, "");
        }

        // 3. *************** Create Backup slides *********************
        int noOFBackUpSlide = 0;
        String backupSlideForDept = "";
        /***********************
         * BACKUP SLIDES WILL BE CREATED AS PER TESTCODE ATTACHED WITH THE
         * PARENT SAMPLE FOR IHC & FISH
         *******/

        if (dsConcurrency.getInt(0, "stainbackup", 0) > 0) {
            noOFBackUpSlide = getTestCodeCountFromParents(parentSampleID, "IHC");// do
            // not
            // put
            // this
            // line
            // out
            // of
            // if
            // statement,
            // otherwise
            // IHC
            // concurrencyconfiguration
            // will
            // not
            // work
            int maxBackup = dsConcurrency.getInt(0, "stainonlybackupmax", 0);
            if (maxBackup > 0 && (noOFBackUpSlide > maxBackup)) {
                noOFBackUpSlide = dsConcurrency.getInt(0, "stainonlybackupmax", 0);
            }
            backupSlideForDept = "Stainonly";
        } else if (dsConcurrency.getInt(0, "technicalbackup", 0) > 0) {
            noOFBackUpSlide = getTestCodeCountFromParents(parentSampleID, "IHC");// do
            // not
            // put
            // this
            // line
            // out
            // of
            // if
            // statement,
            // otherwise
            // IHC
            // concurrencyconfiguration
            // will
            // not
            // work
            int maxBackup = dsConcurrency.getInt(0, "technicalbackupmax", 0);
            if (maxBackup > 0 && (noOFBackUpSlide > maxBackup)) {
                noOFBackUpSlide = dsConcurrency.getInt(0, "technicalbackupmax", 0);
            }
            backupSlideForDept = "Technical";
        } else if (dsConcurrency.getInt(0, "globalbackup", 0) > 0) {
            noOFBackUpSlide = getTestCodeCountFromParents(parentSampleID, "IHC"); // do
            // not
            // put
            // this
            // line
            // out
            // of
            // if
            // statement,
            // otherwise
            // IHC
            // concurrencyconfiguration
            // will
            // not
            // work
            int maxBackup = dsConcurrency.getInt(0, "globalbackupmax", 0);
            if (maxBackup > 0 && (noOFBackUpSlide > maxBackup)) {
                noOFBackUpSlide = dsConcurrency.getInt(0, "globalbackupmax", 0);
            }
            backupSlideForDept = "Global";
        } else if (dsConcurrency.getInt(0, "molecularhne", 0) > 0) {
            // No such scenario

        }

        String backupTestCode = getBackupTestCode("IHC");
        for (int i = 0; i < noOFBackUpSlide; i++) {
            addRowToDataSet(dsIHCSlides, parentSampleID, backupTestCode, "", IS_PANEL_NO, PROPERTY_METH_IHC,
                    backupSlideForDept, "B", "N", parentSampleTypeID, parentContainerTypeID, "");
        }

        tagHnESlides(dsIHCSlides);
        createChildSamples(dsIHCSlides, PROPERTY_METH_IHC);
    }

    private String getBackupTestCode(String arg_methodology) throws SapphireException {
        String backupTestCode = "";

        // 1. Get testcode from policy.
        if (dsBackupTestCode == null) {// storing all methodologies backup in a
            // dataset so that don't need to query
            // db in concurrency rule.
            dsBackupTestCode = new DataSet();
            dsBackupTestCode.addColumn("methodology", DataSet.STRING);
            dsBackupTestCode.addColumn("testcodeid", DataSet.STRING);
            dsBackupTestCode.addColumn("testcodeexists", DataSet.STRING);

            PropertyList plBackupTestCodePolicy = getConfigurationProcessor().getPolicy("BackupTestcodePolicy",
                    "BackupTestCode");
            if (plBackupTestCodePolicy == null) {
                throw new SapphireException("BackupTestCodePolicy is not define in System Admin-> Policy.");
            }
            PropertyListCollection backupCollection = plBackupTestCodePolicy.getCollection("backupcollection");
            if (backupCollection != null) {
                for (int j = 0; j < backupCollection.size(); j++) {
                    PropertyList plMethContainer = backupCollection.getPropertyList(j)
                            .getPropertyList("methodologycontainer");
                    if (plMethContainer != null) {
                        String meth = plMethContainer.getProperty("methodology", "");
                        String testcode = plMethContainer.getProperty("testcodeid", "");
                        if (!"".equalsIgnoreCase(meth)) {
                            int rowID = dsBackupTestCode.addRow();
                            dsBackupTestCode.setValue(rowID, "methodology", meth);
                            dsBackupTestCode.setValue(rowID, "testcodeid", testcode);
                            dsBackupTestCode.setValue(rowID, "testcodeexists", "N");
                        }
                    }
                }
            }

            if (dsBackupTestCode == null || dsBackupTestCode.size() == 0) {
                return "";
            }

            // 2.validate if testcode exists in LV system.
            String sql = "select u_testcodeid testcodeid from u_testcode where u_testcodeid in ('"
                    + dsBackupTestCode.getColumnValues("testcodeid", "','") + "')";
            DataSet dsExist = getQueryProcessor().getSqlDataSet(sql);
            if (dsExist == null) {
                throw new SapphireException("Something wrong happened, Contact you Administrator. SQL failed:" + sql);
            }
            if (dsExist.size() == 0) {
                // DO nothing because exist default is No --
                // dsBackupTestCode.setValue(rowID, "testcodeexists", "N");
            }

            HashMap hm = new HashMap();
            for (int i = 0; i < dsBackupTestCode.size(); i++) {
                String compareTestCode = dsBackupTestCode.getValue(i, "testcodeid", "");
                hm.clear();
                hm.put("testcodeid", compareTestCode);
                DataSet dsCompare = dsExist.getFilteredDataSet(hm);
                if (dsCompare != null && dsCompare.size() > 0) {
                    dsBackupTestCode.setValue(i, "testcodeexists", "Y");
                }
            }

        }

        // 3. Return backup testcode.
        if (dsBackupTestCode.size() == 0) {
            return "";
        }

        HashMap hm = new HashMap();
        hm.clear();
        hm.put("methodology", arg_methodology);
        DataSet dsFilter = dsBackupTestCode.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            String testcode = dsFilter.getValue(0, "testcodeid", "");
            String testexist = dsFilter.getValue(0, "testcodeexists", "");
            if ("Y".equalsIgnoreCase(testexist)) {
                backupTestCode = testcode;
            } else {
                backupTestCode = "";
            }
        }

        return backupTestCode;
    }

    private void cuttingForIHCMorphologyConcurrency(DataSet dsIndividualGroup, DataSet dsConcurrency)
            throws SapphireException {

        String parentSampleID = dsIndividualGroup.getValue(0, "s_sampleid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentSampleTypeID = dsIndividualGroup.getValue(0, "sampletypeid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String parentContainerTypeID = dsIndividualGroup.getValue(0, "containertypeid", ""); // Only
        // one
        // parent
        // sample
        // cutting
        // is
        // allowed
        String methodology = dsIndividualGroup.getValue(0, "methodology", "");
        String testAssociatedWithParentSample = Util.getUniqueList(dsIndividualGroup.getColumnValues("lvtestcode", ";"),
                ";", true);

        int level1HnE = 0;
        int level2HnE = 0;
        int level1Backup = 0;
        int level2Backup = 0;

        HashMap hm = new HashMap();
        String morphologySpecialTestCode = "";
        if ("Bone Marrow Core".equalsIgnoreCase(parentSampleTypeID)) {

            hm.clear();
            hm.put("sampletype", parentSampleTypeID);
            DataSet dsFilter = dsConcurrency.getFilteredDataSet(hm);

            level1HnE = Integer.parseInt(dsFilter.getValue(0, "level1hne", "0"));
            level2HnE = Integer.parseInt(dsFilter.getValue(0, "level2hne", "0"));
            level1Backup = Integer.parseInt(dsFilter.getValue(0, "level1backupslide", "0"));
            level2Backup = Integer.parseInt(dsFilter.getValue(0, "level2backupslide", "0"));

            morphologySpecialTestCode = dsFilter.getValue(0, "lvtestpanelid", "");

        } else if ("Bone Marrow Clot".equalsIgnoreCase(parentSampleTypeID)) {

            // if multiple cassette exeists and only 9800ME test attached then
            // follow fist one
            int cassetteCount = isMultipleCassetteExists(parentSampleID);
            String firstCutHNE = getFistCutHNE(parentSampleID);
            if (cassetteCount > 1) {// Multiple Cassette
                if (firstCutHNE.equalsIgnoreCase("")) {// First time microtomy
                    hm.clear();
                    hm.put("cassettecreated", "Multiple");
                    hm.put("sampletype", parentSampleTypeID);

                    DataSet dsFilter = dsConcurrency.getFilteredDataSet(hm);
                    level1HnE = Integer.parseInt(dsFilter.getValue(0, "level1hne", "0"));
                    level2HnE = Integer.parseInt(dsFilter.getValue(0, "level2hne", "0"));
                    level1Backup = Integer.parseInt(dsFilter.getValue(0, "level1backupslide", "0"));
                    level2Backup = Integer.parseInt(dsFilter.getValue(0, "level2backupslide", "0"));
                    morphologySpecialTestCode = dsFilter.getValue(0, "lvtestpanelid", "");
                } else {// second time microtomy Bone marrow Clot for Single
                    // rule will applied.( level1 HnE already cut in first
                    // microtomy , so we will not cut label1 H&E any more
                    hm.clear();
                    hm.put("cassettecreated", "One");
                    hm.put("sampletype", parentSampleTypeID);

                    DataSet dsFilter = dsConcurrency.getFilteredDataSet(hm);
                    level1HnE = 0;// In Second microtomy no need to cut level1
                    // HnE.
                    level2HnE = Integer.parseInt(dsFilter.getValue(0, "level2hne", "0"));
                    level1Backup = Integer.parseInt(dsFilter.getValue(0, "level1backupslide", "0"));
                    level2Backup = Integer.parseInt(dsFilter.getValue(0, "level2backupslide", "0"));
                    morphologySpecialTestCode = dsFilter.getValue(0, "lvtestpanelid", "");
                }

            } else if (cassetteCount == 1) {// only one cassette rule
                hm.clear();
                hm.put("cassettecreated", "One");
                hm.put("sampletype", parentSampleTypeID);
                DataSet dsFilter = dsConcurrency.getFilteredDataSet(hm);

                level1HnE = Integer.parseInt(dsFilter.getValue(0, "level1hne", "0"));
                level2HnE = Integer.parseInt(dsFilter.getValue(0, "level2hne", "0"));
                level1Backup = Integer.parseInt(dsFilter.getValue(0, "level1backupslide", "0"));
                level2Backup = Integer.parseInt(dsFilter.getValue(0, "level2backupslide", "0"));
                morphologySpecialTestCode = dsFilter.getValue(0, "lvtestpanelid", "");
            } else {
                String err = "No cassette has been created from the container. Please create cassettes first.";
                throw new SapphireException(TYPE_VALIDATION, err);
            }

        } else {// surgical Morphology --> any other sampletype other than
            // Boremarrow code/ clot
            hm.clear();
            hm.put("sampletype", null);
            DataSet dsFilter = dsConcurrency.getFilteredDataSet(hm);

            level1HnE = Integer.parseInt(dsFilter.getValue(0, "level1hne", "0"));
            level2HnE = Integer.parseInt(dsFilter.getValue(0, "level2hne", "0"));
            level1Backup = Integer.parseInt(dsFilter.getValue(0, "level1backupslide", "0"));
            level2Backup = Integer.parseInt(dsFilter.getValue(0, "level2backupslide", "0"));
            morphologySpecialTestCode = dsFilter.getValue(0, "lvtestpanelid", "");
        }

        if (level1HnE > 0) {
            for (int i = 0; i < level1HnE; i++) {
                addRowToDataSet(dsIHCSlides, parentSampleID, getMorphologyHnETestCodeID("1"), "", IS_PANEL_NO,
                        PROPERTY_METH_IHC, "Morphology", SLIDE_SYMBOL_HE, "Y", parentSampleTypeID,
                        parentContainerTypeID, "");
            }
        }

        if (level2HnE > 0) {
            for (int i = 0; i < level2HnE; i++) {
                addRowToDataSet(dsIHCSlides, parentSampleID, getMorphologyHnETestCodeID("2"), "", IS_PANEL_NO,
                        PROPERTY_METH_IHC, "Morphology", SLIDE_SYMBOL_HE, "Y", parentSampleTypeID,
                        parentContainerTypeID, "");
            }
        }

        String backupTestCode = getBackupTestCode(PROPERTY_METH_IHC);
        if (level1Backup > 0) {
            for (int i = 0; i < level1Backup; i++) {
                addRowToDataSet(dsIHCSlides, parentSampleID, backupTestCode, "", IS_PANEL_NO, PROPERTY_METH_IHC,
                        "Morphology", SLIDE_SYMBOL_BACKUP, "N", parentSampleTypeID, parentContainerTypeID, "");
            }
        }

        if (level2Backup > 0) {
            for (int i = 0; i < level2Backup; i++) {
                addRowToDataSet(dsIHCSlides, parentSampleID, backupTestCode, "", IS_PANEL_NO, PROPERTY_METH_IHC,
                        "Morphology", SLIDE_SYMBOL_BACKUP, "N", parentSampleTypeID, parentContainerTypeID, "");
            }
        }

    }

    private void cuttingForIHCConsultConcurrency(DataSet dsIndividualGroup, String los, String parentSampleID,
                                                 String methodology, String parentSampleTypeID, String parentContainerTypeID) throws SapphireException {
        String sql = "select ihcc.consulthne,ihcc.los1,ihcc.los2,ihcc.testslide,ihcc.stainhne,ihcc.technicalhne,ihcc.globalhne,ihcc.molecularhne,ihcc.fishhne,ihcc.stainbackup,"
                + " ihcc.globalbackup,ihcc.technicalbackup,ihccr.testcodeid,ihccr.level1hne,ihccr.level1backupslide,ihccr.level2hne,ihccr.level2backupslide,"
                + " ihcc.fishbackup, ihcc.globalbackupmax,ihcc.technicalbackupmax,ihcc.stainonlybackupmax"
                + " from u_ihcconcurrency ihcc, u_ihcconcurrencyrule ihccr where"
                + " ihcc.u_ihcconcurrencyid = ihccr.ihcconcurrencyid" + " and ihcc.speciallosflag='Y'"
                + " and ihcc.los1 in ('" + los + "')";
        DataSet dsIhcConRule = getQueryProcessor().getSqlDataSet(sql);
        if (dsIhcConRule == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact you Administrator.");
            Util.queryReturnsNULLException(errMsg, sql);
        }
        if (dsIhcConRule.size() == 0) {
            String errMsg = getTranslationProcessor().translate(
                    "LOS With Special Test Code is checked, but no Special Test code found into IHC concurrency rule defined for below LOS:")
                    + "<BREAK>" + los;
            Util.queryReturnsZeroRowException(errMsg, sql);
        }
        String parent_testcode_special = dsIhcConRule.getValue(0, "testcodeid", "");
        int consulthne = dsIhcConRule.getInt(0, "consulthne", 0);
        String parentTestCode = dsIndividualGroup.getColumnValues("lvtestcode", ";");

        if (parentTestCode.contains(parent_testcode_special)) {
            // 1. Create H&E samples here for Consult
            for (int i = 0; i < consulthne; i++) {
                addRowToDataSet(dsIHCSlides, parentSampleID, getIHCConsultHnETestCodeID(), "", IS_PANEL_NO, methodology,
                        "Consult", SLIDE_SYMBOL_HE, "Y", parentSampleTypeID, parentContainerTypeID, "");
            }
            // 2. Create test slide(s) per test here. Do not create testslide
            // for 9800C
            int noOfTestSlide = dsIhcConRule.getInt(0, "testslide", 0);
            if (noOfTestSlide > 0) {
                for (int i = 0; i < dsIndividualGroup.size(); i++) {
                    String eachTestCode = dsIndividualGroup.getValue(i, "lvtestcode", "");
                    if (!eachTestCode.equalsIgnoreCase(parent_testcode_special)) {
                        addRowToDataSet(dsIHCSlides, parentSampleID, eachTestCode, "", IS_PANEL_NO, methodology,
                                "Consult", SLIDE_SYMBOL_TEST_SLIDE, "Y", parentSampleTypeID, parentContainerTypeID, "");
                    }
                }
            }

        } else {
            return;
        }
    }

    /**
     * Cutting rules are followed from DOS
     *
     * @param dsIHCMaster
     * @throws SapphireException...........
     */
    private void cuttingWithDOSRule(DataSet dsIHCMaster) throws SapphireException {

        if (dsSlides == null) {
            dsSlides = initializeDataSet();
        }

        for (int i = 0; i < dsIHCMaster.size(); i++) {
            // get row by row and prepare dataset for H&E, Unstained, backup
            String parentSampleID = dsIHCMaster.getValue(i, "s_sampleid", "");
            String parentTestCodeID = dsIHCMaster.getValue(i, "lvtestcode", "");
            String parentSampleTypeID = dsIHCMaster.getValue(i, "sampletypeid", "");
            String parentContainerTypeID = dsIHCMaster.getValue(0, "containertypeid", "");
            String parentMeth = dsIHCMaster.getValue(0, "methodology", "");
            String parentLOS = dsIHCMaster.getValue(0, "los", "");
            // 1. H&E samples have own test code. Not inheritate from Parent
            int noOfHE = Integer.parseInt(dsIHCMaster.getValue(i, "heslides", "0"));
            String noOfUSS = dsIHCMaster.getValue(i, "unstainedslides", "");
            String noOfBKPS = dsIHCMaster.getValue(i, "backupslides", "");
            if (Util.isNull(noOfUSS)) {
                throw new SapphireException(
                        getTranslationProcessor().translate(" Number of Unstained slide(s) not defined into Testcode")
                                + "\n" + parentTestCodeID);
            }
            if (Util.isNull(noOfBKPS)) {
                throw new SapphireException(
                        getTranslationProcessor().translate("Number of Backup slide(s) not defined into Testcode")
                                + "\n" + parentTestCodeID);
            }
            // 2. For unstained slide/ test slide: one parent test code will be
            // applied to one child
            int noOfUnstained = Integer.parseInt(dsIHCMaster.getValue(i, "unstainedslides", "0"));
            for (int j = 0; j < noOfUnstained; j++) {
                addRowToDataSet(dsSlides, parentSampleID, parentTestCodeID, "", IS_PANEL_NO, parentMeth, parentLOS, "U",
                        "N", parentSampleTypeID, parentContainerTypeID, "");
            }
            // 3. For backup slides no test code will be applied. LOS will be
            // applied
            int noOfBackup = Integer.parseInt(dsIHCMaster.getValue(i, "backupslides", "0"));
            for (int j = 0; j < noOfBackup; j++) {
                addRowToDataSet(dsSlides, parentSampleID, getBackupTestCode(parentMeth), "", IS_PANEL_NO, parentMeth,
                        parentLOS, "B", "N", parentSampleTypeID, parentContainerTypeID, "");
            }
            //4. For H&E parent Test Code will be applied
            for (int j = 0; j < noOfHE; j++) {
                addRowToDataSet(dsSlides, parentSampleID, parentTestCodeID, "", IS_PANEL_NO, parentMeth, parentLOS, "H",
                        "N", parentSampleTypeID, parentContainerTypeID, "");
            }
        }

        // Client wants to see the child sample in below fashion 1st: H&E, 2nd
        // test slide, 3rd: Backups( don't change below order of calling )
        createChildSamples(dsSlides, "");
    }

    /**
     * Create Child Sample(s)
     *
     * @param ds
     * @throws SapphireException....
     */
    private void createChildSamples(DataSet ds, String methodology) throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String site = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));

        if (ds == null || ds.size() == 0) {
            return;
        }

        String parentSample = ds.getValue(0, "parentsampleid", "");
        PropertyList props = new PropertyList();
        props.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, parentSample);
        props.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "" + ds.getRowCount());
        props.setProperty(CreateChildSamples.PROPERTY_MODE, "derivative");
        props.setProperty("__trackitem_custodialdepartmentid", connectionInfo.getDefaultDepartment());

        try {
            getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, props);
        } catch (SapphireException e) {
            throw new SapphireException(
                    getTranslationProcessor().translate("Unable to create child sample.") + "\n" + e.getMessage());
        }

        String childSampleIDArray[] = StringUtil.split(props.getProperty("newkeyid1", ""), ";");
        for (int i = 0; i < ds.getRowCount(); i++) {
            ds.setValue(i, DATASET_PROPERTY_CHILD_SAMPLE_ID, childSampleIDArray[i]);
        }

        // --------------- Set type of slide ( Edit sample SDC )
        // ------------------ //
        PropertyList p = new PropertyList();
        p.clear();
        p.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        p.setProperty("keyid1", ds.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
        p.setProperty("u_type", ds.getColumnValues(DATASET_PROPERTY_CHILD_TYPE, ";"));
        p.setProperty("sampletypeid", ds.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_TYPE_ID, ";"));
        p.setProperty("u_microtomystation", StringUtil.repeat(defaultMicrotomyStation, ds.getRowCount(), ";"));
        p.setProperty("u_currentmovementstep", StringUtil.repeat("Microtomy", ds.getRowCount(), ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p);

        p.clear();
        // p = new PropertyList();
        p.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        p.setProperty("keyid1", parentSample);
        p.setProperty("u_microtomystation", defaultMicrotomyStation);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p);

        // --------------- Set containertype of slide ( Edit Trackitem SDC )
        // ------------------ //
        PropertyList plEditContainerTrackItem = new PropertyList();
        plEditContainerTrackItem.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        plEditContainerTrackItem.setProperty(EditTrackItem.PROPERTY_KEYID1,
                ds.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
        plEditContainerTrackItem.setProperty("containertypeid", ds.getColumnValues("childtransporttypeid", ";"));
        plEditContainerTrackItem.setProperty("u_currenttramstop",
                StringUtil.repeat("Microtomy", ds.getRowCount(), ";"));

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, plEditContainerTrackItem);
        } catch (Exception ex) {
            throw new SapphireException("General Error", SapphireException.TYPE_FAILURE, getTranslationProcessor()
                    .translate("Failed to update trackitem.Please contact Administrator." + ex.getMessage()));
        }

        // ---------------- Assigning Test codes ------//TODO assigning steps &
        // apply WI-----------//

        // Filter dataset: select those child samples which have test codes.
        DataSet dsTestCodes = new DataSet();
        for (int i = 0; i < ds.getRowCount(); i++) {
            if (!"".equals(ds.getValue(i, "childtestcodeid", ""))) {
                dsTestCodes.copyRow(ds, i, 1);
            }
        }

        if (dsTestCodes.size() == 0) {
            return;
        }

        PropertyList pl = getPropertyListForAddingTestCode(dsTestCodes, methodology);
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_BYPASS_TRANSPORTTYPE, "Y");

        //getActionProcessor().processAction("AddTestCode", "1", pl);
        getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);

        if ("IHC".equalsIgnoreCase(methodology)) {
            String mapid = pl.getProperty("sampletestcodemapid");
            updatePanelWithChilds(parentSample, mapid);
        }

        /********** HL7 integration *****************************************/
        // TODO please call this HL7 action for IHC only
        /*
         * PropertyList hl7Props = new PropertyList();
		 * hl7Props.setProperty("sampleid",ds.getValue(0,
		 * DATASET_PROPERTY_PARENT_SAMPLE_ID, ""));
		 * hl7Props.setProperty(AddToDoListEntry.PROPERTY_ACTIONID,
		 * "ForHL7Message");
		 * hl7Props.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
		 * //props.setProperty(AddToDoListEntry.PROPERTY_DUEDATE,
		 * timestamp.toString()); //
		 * props.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
		 * getActionProcessor().processAction(AddToDoListEntry.ID,
		 * AddToDoListEntry.VERSIONID, hl7Props);
		 */
        // *********************************************************************************************/
        updateTestStatus(pl);

    }

    private void updatePanelWithChilds(String parentsampleid, String mapid) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_PARENT_PANEL_ID, StringUtil.replaceAll(parentsampleid, ";", "','"));
        DataSet dsParentInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsParentInfo != null && dsParentInfo.size() > 0) {
            String parentpanelid = dsParentInfo.getValue(0, "lvtestpanelid", "");
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(EditSDI.PROPERTY_KEYID1, mapid);
            props.setProperty("lvtestpanelid", parentpanelid);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to update panel code with child(s).");
            }
        }
    }

    /**
     * Description : This method is used for getting movement step for samples.
     *
     * @throws SapphireException
     */

    private String getMovementstep(String sample) throws SapphireException {
        String sqlLosMethodology = "select distinct los,methodology from u_sampletestcodemap where s_sampleid ='"
                + sample + "'";
        DataSet dsLosMethodology = getQueryProcessor().getSqlDataSet(sqlLosMethodology);
        if (dsLosMethodology == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlLosMethodology;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        String los = dsLosMethodology.getColumnValues("los", ";");
        String methodology = dsLosMethodology.getColumnValues("methodology", ";");
        if (Util.isNull(los) || Util.isNull(methodology)) {
            return "BlockRoomCOC";
        }
        if ("IHC".equalsIgnoreCase(methodology) && "Morphology".equalsIgnoreCase(los)) {
            return "HistologyArchive";// this is for morphology block
        } else if ("IHC".equalsIgnoreCase(methodology) && "StainOnly".equalsIgnoreCase(los)) {
            return "HistologyArchive";// this is for StainOnly block
        } else {
            return "BlockRoomCOC";
        }
    }

    /**
     * Description: This method is used for update teststatus into
     * u_sampletestcodemap
     *
     * @param pl This contains test codes associate into child sample;
     * @throws SapphireException
     */
    private void updateTestStatus(PropertyList pl) throws SapphireException {
        String childsampleids = pl.getProperty("s_sampleid", "");
        String lvtestcodes = pl.getProperty("lvtestcode", "");

        String isChildSampleLength[] = StringUtil.split(childsampleids, ";");
        String islvtestcodesLength[] = StringUtil.split(lvtestcodes, ";");

        if (isChildSampleLength.length != islvtestcodesLength.length) {
            return;
        }

        String childSamplesArg = StringUtil.replaceAll(childsampleids, ";", "','");
        String lvTestcodesArg = StringUtil.replaceAll(lvtestcodes, ";", "','");

        String sql = Util.parseMessage(ApSql.GET_SAMPLE_TEST_CODE_MAP_BY_SAMPLE_AND_TESTCODE, childSamplesArg, lvTestcodesArg);

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null && ds.size() == 0) {// tis will never come
            throw new SapphireException("Sample testcode not associate.");
        }
        String u_sampletestcodemapid = ds.getColumnValues("u_sampletestcodemapid", ";");
        String lenSampletestcodeMap[] = StringUtil.split(u_sampletestcodemapid, ";");

        PropertyList propUpdateSampleMap = new PropertyList();
        propUpdateSampleMap.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        propUpdateSampleMap.setProperty(EditSDI.PROPERTY_KEYID1, u_sampletestcodemapid);
        propUpdateSampleMap.setProperty("teststatus",
                StringUtil.repeat("In Progress", lenSampletestcodeMap.length, ";"));
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propUpdateSampleMap);
    }

    /**
     * IHC: Priority1 FISH: Priority2 Molecular: Priority3
     *
     * @throws SapphireException
     */
    private void applyPriorityRule(DataSet dsInput) throws SapphireException {
        String allUniqueMethodology = Util.getUniqueList(dsInput.getColumnValues("methodology", ";"), ";", true);
        String isNeotypeBreast = Util.getUniqueList(dsInput.getColumnValues("isneotypebreast", ";"), ";", true);
        String priorityRuleKey = getPriorityRuleKey(dsInput);

        String sql = "select cuttingkey,methodology,type,extractiontype,priority,specialtestcode,include"
                + " from u_cuttingpriority where cuttingkey = '" + priorityRuleKey + "' order by priority";
        DataSet dsPriorityFromDB = getQueryProcessor().getSqlDataSet(sql);
        if (dsPriorityFromDB.size() == 0) {
            logger.error("No priority rule defined for " + allUniqueMethodology + " SQL: " + sql);
            throw new SapphireException("No priority rule defined for " + allUniqueMethodology);

        }

        priorityMap = new TreeMap<Integer, String>();

        HashMap hmFilter = new HashMap();
        if (dsIHCSlides != null && dsIHCSlides.size() > 0) {
            for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));
                if (!PROPERTY_METH_IHC.equalsIgnoreCase(methodologyFromDB)) {
                    continue;
                }

                hmFilter.clear();
                hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                DataSet dsFilterIHC = dsIHCSlides.getFilteredDataSet(hmFilter);
                if (dsFilterIHC != null & dsFilterIHC.size() > 0) {
                    String allSampleID = removeBlank(
                            dsFilterIHC.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                    priorityMap.put(priorityFromDB, allSampleID);
                }

            }
        }

        if (dsMOSlides != null && dsMOSlides.size() > 0) {
            for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));
                if (!PROPERTY_METH_MULTIOMIX.equalsIgnoreCase(methodologyFromDB)) {
                    continue;
                }

                hmFilter.clear();
                hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                DataSet dsFilterIHC = dsMOSlides.getFilteredDataSet(hmFilter);
                if (dsFilterIHC != null & dsFilterIHC.size() > 0) {
                    String allSampleID = removeBlank(
                            dsFilterIHC.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                    priorityMap.put(priorityFromDB, allSampleID);
                }

            }
        }

        if (dsFishSlides != null && dsFishSlides.size() > 0) {
            for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));
                String specialTestCode = dsPriorityFromDB.getValue(i, "specialtestcode", "");
                String includeString = dsPriorityFromDB.getValue(i, "include", "");
                if (!PROPERTY_METH_FISH.equalsIgnoreCase(methodologyFromDB)) {
                    continue;
                }

                hmFilter.clear();
                hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                DataSet dsFilterFISH = dsFishSlides.getFilteredDataSet(hmFilter);

                String allSampleID = "";
                if (dsFilterFISH != null && dsFilterFISH.size() > 0) {
                    if ("".equals(specialTestCode)) {
                        allSampleID = removeBlank(dsFilterFISH.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                    } else {
                        allSampleID = getSampleIDs(dsFilterFISH, specialTestCode, includeString);
                    }
                }
                if (!"".equals(allSampleID)) {
                    priorityMap.put(priorityFromDB, allSampleID);
                }
            }
        }

        if (dsMolSlides != null && dsMolSlides.size() > 0) {
            String allUniqueMethodologyArray[] = StringUtil.split(allUniqueMethodology, ";");
            if (allUniqueMethodologyArray.length == 1 || isNeotypeBreast.contains("Y")) { // this
                // means
                // only
                // molecular
                for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                    String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                    String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                    int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));
                    if (!PROPERTY_METH_MOLEULAR.equalsIgnoreCase(methodologyFromDB)) {
                        continue;
                    }

                    hmFilter.clear();
                    hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                    hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                    DataSet dsFilterMolecular = dsMolSlides.getFilteredDataSet(hmFilter);
                    if (dsFilterMolecular != null & dsFilterMolecular.size() > 0) {
                        String allSampleID = removeBlank(
                                dsFilterMolecular.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                        // ArrayList<String> sampleList =
                        // (ArrayList)Arrays.asList(allSampleID.split(";"));
                        priorityMap.put(priorityFromDB, allSampleID);
                    }
                }
            } else if (allUniqueMethodologyArray.length == 2) {
                // THIS BLOCK IS APPLICABLE FOR IHC+MOL, FISH+MOL
                for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                    String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                    String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                    int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));
                    if (!PROPERTY_METH_MOLEULAR.equalsIgnoreCase(methodologyFromDB)) {
                        continue;
                    }

                    hmFilter.clear();
                    hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                    hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                    DataSet dsFilterMolecular = dsMolSlides.getFilteredDataSet(hmFilter);
                    if (dsFilterMolecular != null & dsFilterMolecular.size() > 0) {
                        String allSampleID = removeBlank(
                                dsFilterMolecular.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                        // ArrayList<String> sampleList =
                        // (ArrayList)Arrays.asList(allSampleID.split(";"));
                        priorityMap.put(priorityFromDB, allSampleID);
                    }
                }
            } else {// DNA,RNA, Neotype Block
                for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                    String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                    String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                    String extractiontypeFromDB = dsPriorityFromDB.getValue(i, "extractiontype", "");
                    int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));
                    if (!PROPERTY_METH_MOLEULAR.equalsIgnoreCase(methodologyFromDB)) {
                        continue;
                    }

                    hmFilter.clear();
                    hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                    hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                    hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE, extractiontypeFromDB);
                    DataSet dsFilterMolecular = dsMolSlides.getFilteredDataSet(hmFilter);
                    if (dsFilterMolecular != null & dsFilterMolecular.size() > 0) {
                        String allSampleID = removeBlank(
                                dsFilterMolecular.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                        // ArrayList<String> sampleList =
                        // (ArrayList)Arrays.asList(allSampleID.split(";"));
                        priorityMap.put(priorityFromDB, allSampleID);
                    }
                }

            }
        }

        if (dsSlides != null && dsSlides.size() > 0) {
            for (int i = 0; i < dsPriorityFromDB.size(); i++) {
                String methodologyFromDB = dsPriorityFromDB.getValue(i, "methodology", "");
                String typeFromDB = dsPriorityFromDB.getValue(i, "type", "");
                int priorityFromDB = Integer.parseInt(dsPriorityFromDB.getValue(i, "priority", "0"));

                hmFilter.clear();
                hmFilter.put(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, methodologyFromDB);
                hmFilter.put(DATASET_PROPERTY_CHILD_TYPE, typeFromDB);
                DataSet dsFilterMolecular = dsSlides.getFilteredDataSet(hmFilter);
                if (dsFilterMolecular != null & dsFilterMolecular.size() > 0) {
                    String allSampleID = removeBlank(
                            dsFilterMolecular.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";"));
                    // ArrayList<String> sampleList =
                    // (ArrayList)Arrays.asList(StringUtil.split(allSampleID,";"));---JHAR
                    // KACHE
                    priorityMap.put(priorityFromDB, allSampleID);
                }
            }
        }

        String finalString = "";
        Set<Integer> keys = priorityMap.keySet();
        for (int key : keys) {
            finalString += ";" + priorityMap.get(key);
        }
        if (finalString.startsWith(";")) {
            finalString = finalString.substring(1);
        }
        newSlideIDs = finalString;

    }

    private String getSampleIDs(DataSet dsFilteredFISH, String specialTestCode, String include)
            throws SapphireException {
        String finalIncludeStr = "";
        String finalExcludeStr = "";
        for (int i = 0; i < dsFilteredFISH.size(); i++) {
            String testCode = dsFilteredFISH.getValue(i, DATASET_PROPERTY_CHILD_TEST_CODE_ID, "");
            String sampleID = dsFilteredFISH.getValue(i, DATASET_PROPERTY_CHILD_SAMPLE_ID, "");
            if (specialTestCode.contains(testCode)) {
                finalIncludeStr += ";" + sampleID;
            } else {
                finalExcludeStr += ";" + sampleID;
            }
        }
        if (finalIncludeStr.startsWith(";")) {
            finalIncludeStr = finalIncludeStr.substring(1);
        }
        if (finalExcludeStr.startsWith(";")) {
            finalExcludeStr = finalExcludeStr.substring(1);
        }
        if (include.equalsIgnoreCase("INCLUDE")) {
            return finalIncludeStr;
        } else {
            return finalExcludeStr;
        }
    }

    /**
     * Key must be be configured configured in db in below sequence:
     * <p/>
     * 1.IHC, 2.FISH, 3. Molecular
     *
     * @param dsInput
     * @return
     * @throws SapphireException
     */
    private String getPriorityRuleKey(DataSet dsInput) throws SapphireException {

        String allMethodology = Util.getUniqueList(dsInput.getColumnValues("methodology", ";"), ";", true);
        String isNeotypeBreast = Util.getUniqueList(dsInput.getColumnValues("isneotypebreast", ";"), ";", true);
        if ("".equals(allMethodology)) {
            return "";
        }

        if (isNeotypeBreast.contains("Y")) {
            return "NeotypeBreast";
        }

        String allMethodologyArray[] = StringUtil.split(allMethodology, ";");
        if (allMethodologyArray.length == 1) {
            if (allMethodology.contains(PROPERTY_METH_IHC)) {
                return "UniversalIHC"; // This value mast exists in
                // u_cuttingPriority as cuttingkey.
            } else if (allMethodology.contains(PROPERTY_METH_MOLEULAR)) {
                return "UniversalMolecular";
            } else if (allMethodology.contains(PROPERTY_METH_FISH)) {
                return "UniversalFISH";
            } else if (allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "UniversalMultiomyx";
            }
        } else if (allMethodologyArray.length == 2) {// BLOCK FOR IHC+FISH
            // FISH+MOL IHC+MOL
            if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_FISH)) {
                return "IHC+FISH"; // This value mast exists in
                // u_cuttingPriority as cuttingkey.
            } else if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_MOLEULAR)) {
                return "IHC+Molecular";
            } else if (allMethodology.contains(PROPERTY_METH_FISH) && allMethodology.contains(PROPERTY_METH_MOLEULAR)) {
                return "FISH+Molecular";
            } else if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "IHC+Multiomyx";
            } else if (allMethodology.contains(PROPERTY_METH_MOLEULAR) && allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "Molecular+Multiomyx";
            }else if(allMethodology.contains(PROPERTY_METH_FISH) && allMethodology.contains(PROPERTY_METH_MULTIOMIX)){
                return "FISH+Multiomyx";
            }
        } else if (allMethodologyArray.length == 3) {
            HashMap hm = new HashMap();
            if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_FISH)
                    && allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "IHC+FISH+Multiomyx";
            } else if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_MOLEULAR)
                    && allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "IHC+Molecular+Multiomyx";
            } else if (allMethodology.contains(PROPERTY_METH_FISH) && allMethodology.contains(PROPERTY_METH_MOLEULAR)
                    && allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "FISH+Molecular+Multiomyx";
            } else if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_FISH)
                    && allMethodology.contains(PROPERTY_METH_MOLEULAR)) {
                /******** IHC+FISH+Molecular(DNA,RNA)-Neotype,IHC+FISH+Molecular(DNA,RNA)-Neotype ******/

                // 1. Neotype
                hm.clear();
                hm.put("methodology", PROPERTY_METH_MOLEULAR);
                DataSet dsFilterMolecular = dsInput.getFilteredDataSet(hm);
                if (dsFilterMolecular != null && dsFilterMolecular.size() > 0) {
                    hm.clear();
                    hm.put("isneotypepanel", "Y");
                    DataSet dsFilterNeotype = dsFilterMolecular.getFilteredDataSet(hm);
                    /***************************** Neeotype Block ***************************************/
                    if (dsFilterNeotype != null && dsFilterNeotype.size() > 0) {
                        hm.clear();
                        hm.put("extractiontype", "DNA");
                        DataSet dsNeotypeDNA = dsFilterNeotype.getFilteredDataSet(hm);
                        hm.clear();
                        hm.put("extractiontype", "RNA");
                        DataSet dsNeotypeRNA = dsFilterNeotype.getFilteredDataSet(hm);

                        if (dsNeotypeDNA != null && dsNeotypeDNA.size() > 0 && dsNeotypeRNA != null
                                && dsNeotypeRNA.size() > 0) {
                            // IHC+FISH+Molecular(Neotype+DNA+RNA)
                            return "IHC+FISH+Molecular(Neotype+DNA+RNA)";
                        } else if (dsNeotypeDNA != null && dsNeotypeDNA.size() > 0) {
                            // IHC+FISH+Molecular(Neotype+DNA)
                            return "IHC+FISH+Molecular(Neotype+DNA)";
                        } else if (dsNeotypeRNA != null && dsNeotypeRNA.size() > 0) {
                            // IHC+FISH+Molecular(Neotype+RNA)
                            return "IHC+FISH+Molecular(Neotype+RNA)";
                        } else {
                            // only neotype
                        }
                    } else {/************************ non neotype **********************************************/
                        hm.clear();
                        hm.put("extractiontype", "DNA");
                        DataSet dsNonNeotypeDNA = dsFilterMolecular.getFilteredDataSet(hm);
                        hm.clear();
                        hm.put("extractiontype", "RNA");
                        DataSet dsNonNeotypeRNA = dsFilterMolecular.getFilteredDataSet(hm);

                        if (dsNonNeotypeDNA != null && dsNonNeotypeDNA.size() > 0 && dsNonNeotypeRNA != null
                                && dsNonNeotypeRNA.size() > 0) {
                            // IHC+FISH+Molecular(DNA+RNA)
                            return "IHC+FISH+Molecular(DNA+RNA)";
                        } else if (dsNonNeotypeDNA != null && dsNonNeotypeDNA.size() > 0) {
                            // IHC+FISH+Molecular(DNA)
                            return "IHC+FISH+Molecular(DNA)";
                        } else if (dsNonNeotypeRNA != null && dsNonNeotypeRNA.size() > 0) {
                            // IHC+FISH+Molecular(RNA)
                            return "IHC+FISH+Molecular(RNA)";
                        } else {
                            // only neotype. This will never come I believe.
                            logger.error("No priority rule for neotype only.");
                        }

                    }
                }

                // 2. Not Neotype panel

            }

        }else if (allMethodologyArray.length == 4) {
            if (allMethodology.contains(PROPERTY_METH_IHC) && allMethodology.contains(PROPERTY_METH_FISH)
                    && allMethodology.contains(PROPERTY_METH_MOLEULAR) &&  allMethodology.contains(PROPERTY_METH_MULTIOMIX)) {
                return "IHC+FISH+Molecular+Multiomyx";
            }

        }

        return "";

    }

    private String removeBlank(String str) throws SapphireException {
        String returnStr = "";
        String strArray[] = StringUtil.split(str, ";");
        for (String s : strArray) {
            if (!"".equals(s)) {
                returnStr += ";" + s;
            }
        }
        if (returnStr.startsWith(";")) {
            returnStr = returnStr.substring(1);
        }

        return returnStr;
    }

    /**
     * This method is used to Tag slide(s) as H&E
     *
     * @param ds
     * @throws SapphireException....
     */
    private void tagHnESlides(DataSet ds) throws SapphireException {

        // Util.getUniqueList(dsIndividualGroup.getColumnValues("los", ";"),
        // ";", true);

        String childTestCodeID = Util.getUniqueList(ds.getColumnValues(DATASET_PROPERTY_CHILD_TEST_CODE_ID, ";"), ";",
                true);
        String testcodeid = StringUtil.replaceAll(childTestCodeID, ";", "','");
        String sql = Util.parseMessage(ApSql.GET_HNE_TEST_CODES, testcodeid);

        DataSet dsHNE = getQueryProcessor().getSqlDataSet(sql);
        if (dsHNE == null) {

        }
        if (dsHNE.size() == 0) {
            return;
        }
        HashMap hm = new HashMap();
        for (int i = 0; i < dsHNE.size(); i++) {
            hm.clear();
            hm.put(DATASET_PROPERTY_CHILD_TEST_CODE_ID, dsHNE.getValue(i, "u_testcodeid"));
            DataSet dsFilter = ds.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                for (int j = 0; j < dsFilter.size(); j++) {
                    dsFilter.setValue(j, DATASET_PROPERTY_CHILD_TYPE, SLIDE_SYMBOL_HE);
                }
            }
        }
    }

    /**
     * Description: This method is used for to set Homogeneous LOS
     *
     * @throws SapphireException
     */
    private void setHomogeneousLOS() throws SapphireException {
        if (homogeneousLOS == null) {
            homogeneousLOS = new PropertyList();
            PropertyList plHomogeneousPolicy = getConfigurationProcessor().getPolicy(HOMOGENEOUSLOSPOLICYID, NODEID);
            if (plHomogeneousPolicy == null)
                throw new SapphireException("Homogeneous LOS policy is not defined in System Admin-> Policy.");
            PropertyListCollection plclosmap = plHomogeneousPolicy.getCollection(POLICY_MAPPING);
            if (plclosmap != null) {
                for (int j = 0; j < plclosmap.size(); j++) {
                    String propParentLOS = plclosmap.getPropertyList(j).getProperty(POLICY_PARENT_LOS);
                    PropertyListCollection plChildLOS = plclosmap.getPropertyList(j).getCollection(POLICY_CHILD_LOS);
                    if (plChildLOS != null) {
                        for (int k = 0; k < plChildLOS.size(); k++) {
                            String childlodis = plChildLOS.getPropertyList(k).getProperty(POLICY_CHILD_LOS_ID);
                            homogeneousLOS.setProperty(childlodis, propParentLOS);
                        }
                    }
                }

            }

        }
    }

    /********************************************************************************************************
     * Utility Functions
     ********************************************************************************************************/
    private void makeReadyForDisplay(String childID) throws SapphireException {
        if (childID != null && !"".equalsIgnoreCase(childID)) {
            newSlideIDs += ";" + childID;
        }

        if (newSlideIDs.startsWith(";")) {
            newSlideIDs = newSlideIDs.substring(1);
        }
    }

    private String getWhereClauseForLOS(String inputLOS, String alias) {
        if (inputLOS == null || inputLOS.equals("")) {
            return null;
        }
        String[] arrayInputLOS = StringUtil.split(inputLOS, ";");

        ArrayList<String> allCombinationValues = new ArrayList<String>();
        permute(arrayInputLOS, 0, allCombinationValues);
        String arg = "";
        for (String eachItem : allCombinationValues) {
            arg += ";" + eachItem;
        }
        arg = arg.substring(1);
        arg = arg.replaceAll(";", "','");

        String whereClause = " where " + getColumnCombination(arrayInputLOS.length, alias) + " in ('" + arg + "')";
        return whereClause;
    }

    private String getColumnCombination(int count, String alias) {
        String los = "LOS";
        if (alias != null) {
            los = alias + "." + los;
        }
        String finalStr = "";
        for (int i = 1; i <= count; i++) {
            finalStr += ";" + los + i;
        }
        finalStr = finalStr.substring(1);
        return StringUtil.replaceAll(finalStr, ";", "||'#'||");
    }

    private void permute(String[] a, int k, List<String> allCombination) {
        if (k == a.length) {
            String oneCombination = "";
            for (int i = 0; i < a.length; i++) {
                oneCombination += "#" + a[i];
            }
            allCombination.add(oneCombination.substring(1));
        } else {
            for (int i = k; i < a.length; i++) {
                String temp = a[k];
                a[k] = a[i];
                a[i] = temp;

                permute(a, k + 1, allCombination);
                temp = a[k];
                a[k] = a[i];
                a[i] = temp;
            }
        }
    }

    private String getSQLParam(String parentTestCode, String parentTestCodeLos, String seperator)
            throws SapphireException {
        String finalStr = "";
        String parentTestCodeArray[] = StringUtil.split(parentTestCode, ";");
        String parentTestCodeLosArray[] = StringUtil.split(parentTestCodeLos, ";");
        // parentTestArray & LOS will have same number iof record
        for (int i = 0; i < parentTestCodeArray.length; i++) {
            finalStr += ";" + parentTestCodeArray[i] + seperator + parentTestCodeLosArray[i];
        }

        finalStr = finalStr.substring(1);
        return finalStr;
    }

    private String getIHCLOSCombination(String uniqueLOS, String seperator) throws SapphireException {
        String finalStr = "";
        String arrayLOS[] = StringUtil.split(uniqueLOS, ";");
        for (int i = 0; i < arrayLOS.length; i++) {
            finalStr += ";" + arrayLOS[i] + seperator;
        }

        finalStr = finalStr.substring(1);
        return finalStr;
    }

    private boolean validateFishConcurrencyRule(String fishconcurrencyid, int noOfRecord) throws SapphireException {
        String sql = "select u_fishconcurrencyruleid from u_fishconcurrencyrule where fishconcurrencyid='"
                + fishconcurrencyid + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.size() == noOfRecord) {
            return true;
        }
        return false;
    }

    private String getClientHnETestCode(String methodology) throws SapphireException {
        // TODO complete this method
        return "";
    }

    private String getMorphologyHnETestCodeID(String level1or2) throws SapphireException {
        String sql = "select u_testcodeid from u_testcode where methodology='IHC' and hneflag='Y'"
                + " and los='Morphology' and testname like ('%" + level1or2 + "%')";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0) {
            return ds.getValue(0, "u_testcodeid", "");
        }

        return "";

    }

    private String getHnETestCodeID(String methodology, String LOS) throws SapphireException {
        return "";
    }

    private String getIHCConsultHnETestCodeID() throws SapphireException {
        PropertyList policyProps = getConfigurationProcessor().getPolicy(POLICY_NAME, "LOS-Consult");
        if (policyProps == null) {
            String errMsg = getTranslationProcessor().translate("Unable to retrieve Policy properties.");
            errMsg += POLICY_NAME;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }

        String testHE = policyProps.getProperty("testcode");
        if (testHE == null || "".equalsIgnoreCase(testHE)) {
            throw new SapphireException("No H&E test code defined for IHC-Consult in HETestCodes Policy");
        }
        // Find if testHE is exists in system or not
        if (!isTestCodeExists(testHE)) {
            String err = "H&E testcode '" + testHE
                    + "' as defined in HETestCodes Policy for IHC-Consult has not been found in LV System.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        return testHE;
    }

    private String getHnETestCodeIDByMethodology(String extractiontype, String policy_node) throws SapphireException {
        PropertyList policyProps = getConfigurationProcessor().getPolicy(POLICY_NAME, policy_node);
        if (policyProps == null) {
            String errMsg = getTranslationProcessor().translate("Unable to retrieve Policy properties.");
            errMsg += POLICY_NAME;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }

        String testHE = policyProps.getProperty("testcode");
        if (testHE == null || "".equalsIgnoreCase(testHE)) {
            throw new SapphireException("No H&E test code defined for Molecular in HETestCodes Policy");
        }
        // Find if testHE is exists in system or not
        if (!isTestCodeExists(testHE)) {
            String err = "H&E testcode '" + testHE
                    + "' as defined in HETestCodes Policy for Molecular methodology is not found in LV System.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        return testHE;
    }

    private String getMultiomyxHnETestCodeID() throws SapphireException {
        PropertyList policyProps = getConfigurationProcessor().getPolicy(POLICY_NAME, "Multiomix");
        if (policyProps == null) {
            String errMsg = getTranslationProcessor().translate("Unable to retrieve Policy properties.");
            errMsg += POLICY_NAME;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }

        String testHE = policyProps.getProperty("testcode");
        if (testHE == null || "".equalsIgnoreCase(testHE)) {
            throw new SapphireException("No H&E test code defined for Multiomix in HETestCodes Policy");
        }
        // Find if testHE is exists in system or not
        if (!isTestCodeExists(testHE)) {
            String err = "H&E testcode '" + testHE
                    + "' as defined in HETestCodes Policy for Multiomix methodology is not found in LV System.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        return testHE;
    }

    /**
     * Get molecular rule from database.
     *
     * @param parentSampleID
     * @return
     * @throws SapphireException
     */
    private String getMolecularConcurrencyWhereClause(String parentSampleID) throws SapphireException {
        String whereClause = "";
        String sql = "  select nvl(ispanel,'N') ispanel,lvtestpanelid,"
                + " nvl((select isneotypepanel from u_testcode where u_testcodeid = u_sampletestcodemap.lvtestpanelid),'N' ) isneotypepanel,"
                + " (select liposarcomaflag from u_testcode where u_testcodeid = u_sampletestcodemap.lvtestcodeid) liposarcomaflag,"
                + " (select dnarnaflag from u_testcode where u_testcodeid = u_sampletestcodemap.lvtestcodeid) dnarnaflag,"
                + " (select fdaflag from u_testcode where u_testcodeid = u_sampletestcodemap.lvtestcodeid) fdaflag,"
                + " (select dnarnaproteinflag from u_testcode where u_testcodeid = u_sampletestcodemap.lvtestcodeid) dnarnaproteinflag,"
                + " extractiontype from u_sampletestcodemap where methodology='Molecular'" + " and s_sampleid = '"
                + parentSampleID + "'";// TODO Now as per new Molecular
        // Requirement.
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        if (ds == null || ds.size() == 0) {
            return null;
        }

        HashMap hm = new HashMap();
        hm.clear();
        hm.put("extractiontype", "DNA");
        DataSet dsDNATestCode = ds.getFilteredDataSet(hm);

        hm.clear();
        hm.put("extractiontype", "RNA");
        DataSet dsRNATestCode = ds.getFilteredDataSet(hm);

        hm.clear();
        hm.put("extractiontype", "PROTEIN");
        DataSet dsPROTEINTestCode = ds.getFilteredDataSet(hm);

        hm.clear();
        hm.put("isneotypepanel", "Y");
        DataSet dsNeoTypePanel = ds.getFilteredDataSet(hm);

        // TODO added Liposarcoma Profile + DNA Extraction Type
        /*
         * hm.clear(); hm.put("liposarcomaflag", "Y"); hm.put("extractiontype",
		 * "DNA"); DataSet dsLiposarcomaDNATestCode = ds.getFilteredDataSet(hm);
		 */

        // TODO added Liposarcoma Profile + RNA Extraction Type
        /*
         * hm.clear(); hm.put("liposarcomaflag", "Y"); hm.put("extractiontype",
		 * "RNA"); DataSet dsLiposarcomaRNATestCode = ds.getFilteredDataSet(hm);
		 */

        // TODO added only Liposarcoma profile
        hm.clear();
        hm.put("liposarcomaflag", "Y");
        DataSet dsLiposarcomaTestCode = ds.getFilteredDataSet(hm);

        // TODO FDA approval
        hm.clear();
        hm.put("fdaflag", "Y");
        DataSet dsFDATestcode = ds.getFilteredDataSet(hm);

        // TODO DNA & RNA Flag
        hm.clear();
        hm.put("dnarnaflag", "Y");
        DataSet dsDNARNATestcode = ds.getFilteredDataSet(hm);

        // TODO DNA & RNA &PROTEIN Flag
        hm.clear();
        hm.put("dnarnaproteinflag", "Y");
        DataSet dsDNARNAPROTEINTestcode = ds.getFilteredDataSet(hm);


        // if every row of the dataset is neotypepanel then then
        if (dsDNATestCode.size() > 0 && dsRNATestCode.size() > 0 && dsNeoTypePanel.size() > 0) { // neotype
            // panel's
            // test
            // code
            whereClause = "nvl(dnaextraction,'N') ='Y' and nvl(rnaextraction,'N') ='Y' and neotypepanel ='Y'";
            // return whereClause;
        } else if (dsDNATestCode.size() > 0 && dsNeoTypePanel.size() > 0) { // DNA
            // Extraction
            // +
            // neotype
            // panel
            // together
            // whereClause = "dnaextraction ='Y' and neotypepanel ='Y'";
            whereClause = "dnaextraction='Y' and nvl(neotypepanel,'N')='Y' and nvl(rnaextraction,'N')='N'";
        } else if (dsRNATestCode.size() > 0 && dsNeoTypePanel.size() > 0) { // RNA
            // Extraction
            // +
            // neotype
            // panel
            // together
            // whereClause = "rnaextraction ='Y' and neotypepanel ='Y'";
            whereClause = "rnaextraction='Y' and nvl(neotypepanel,'N')='Y' and nvl(dnaextraction,'N')='N'";
        } else if (dsRNATestCode.size() > 0 && dsDNATestCode.size() > 0) { // DNA
            // Extraction
            // +
            // RNA
            // Extraction
            // together
            // whereClause = "rnaextraction ='Y' and dnaextraction ='Y'";
            whereClause = "dnaextraction ='Y' and rnaextraction='Y' and nvl(neotypepanel,'N')='N'";
        } else if (ds.size() == dsDNATestCode.size()) { // all test code's are
            // DNA
            // whereClause = "dnaextraction ='Y'";
            whereClause = "dnaextraction ='Y' and nvl(rnaextraction,'N')='N' and nvl(neotypepanel,'N')='N'";
        } else if (ds.size() == dsRNATestCode.size()) { // all test code's are
            // RNA
            // whereClause = "rnaextraction ='Y'";
            whereClause = "rnaextraction ='Y' and nvl(dnaextraction,'N')='N' and nvl(neotypepanel,'N')='N'";
        } else if (ds.size() == dsPROTEINTestCode.size()) { // all test code's
            // are PROTEIN
            // whereClause = "rnaextraction ='Y'";
            whereClause = "proteinextraction='Y' and nvl(rnaextraction,'N')='N' and nvl(dnaextraction,'N')='N' and nvl(neotypepanel,'N')='N'";
        } else if (ds.size() == dsNeoTypePanel.size()) { // all are panel's test
            // code
            whereClause = "nvl(dnaextraction,'N') !='Y' and nvl(rnaextraction,'N') !='Y' and neotypepanel ='Y'";
        } else if (dsLiposarcomaTestCode.size() > 0) {
            whereClause = "liposarcomaflag = 'Y'";
        } else if (dsFDATestcode.size() > 0) {
            whereClause = "fdaflag = 'Y'";
        } else if (dsDNARNATestcode.size() > 0) {
            whereClause = "dnarnaflag = 'Y'";
        } else if (dsDNARNAPROTEINTestcode.size() > 0) {
            whereClause = "dnarnaproteinflag = 'Y'";
        } else {
            String errMsg = getTranslationProcessor()
                    .translate("No Molecular concurrency rule defined for below Extraction type:") + "<BREAK>"
                    + ds.getColumnValues("extractiontype", "");
            Util.queryReturnsZeroRowException(errMsg, sql);
        }
        /*
         * else if (dsLiposarcomaDNATestCode.size() > 0) { // Liposarcoma
		 * testcode + DNA Extraction whereClause =
		 * "liposarcomaflag='Y' and dnaextraction ='Y'"; } else if
		 * (dsLiposarcomaRNATestCode.size() > 0) { // Liposarcoma testcode + RNA
		 * Extraction whereClause =
		 * "liposarcomaflag='Y' and rnaextraction ='Y'"; }
		 */

		/*
         * if (dsLiposarcomaTestCode.size() > 0) { whereClause =
		 * "liposarcomaflag = 'Y'"; } if (dsFDATestcode.size() > 0) {
		 * whereClause = "fdaflag = 'Y'"; } if (dsDNARNATestcode.size() > 0) {
		 * whereClause = "dnarnaflag = 'Y'"; }
		 */

        return whereClause;
    }

    private boolean isTestCodeExists(String lvTestCodeID) throws SapphireException {
        String sql = "select u_testcodeid lvtestcodeid from u_testcode where u_testcodeid ='" + lvTestCodeID + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds != null && ds.size() > 0) {
            return true;
        }
        return false;
    }

    private String stringMinusOperation(String parentTestCode, String parent_testcode_special)
            throws SapphireException {
        String resultString = "";

        String parentTestCodeArray[] = StringUtil.split(parentTestCode, ";");
        for (int i = 0; i < parentTestCodeArray.length; i++) {
            if (!parent_testcode_special.contains(parentTestCodeArray[i])) {
                resultString += ";" + parentTestCodeArray[i];
            }
        }
        // CHECK null or blank
        if ("".equalsIgnoreCase(resultString)) {
            return resultString;
        } else {
            return resultString.substring(1);
        }
    }

    private void validateOnlyOneSample(String sampleid) throws SapphireException {
        if (sampleid == null || "".equalsIgnoreCase(sampleid)) {
            String errMsg = getTranslationProcessor().translate("No specimen provided for cutting.");
            // throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            throw new SapphireException(errMsg);
        }
        if (sampleid.contains(";")) {
            String errMsg = getTranslationProcessor().translate("Select only one specimen.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
    }

    /**
     * Description: This method is used to validate only cutting sample is valid
     * for cutting or not
     *
     * @param sampleid
     * @throws SapphireException
     */
    private void validateOnlyCrrntMovementStep(String sampleid) throws SapphireException {
        String sql = "select u_currentmovementstep from s_sample where s_sampleid='" + sampleid + "'";
        DataSet dsCrrntMv = getQueryProcessor().getSqlDataSet(sql);
        if (dsCrrntMv == null) {
            throw new SapphireException("Something goes wrong in sql" + sql);
        }
        if (dsCrrntMv.size() == 0) {
            throw new SapphireException("No movement step found of sample: " + sampleid);
        }
        String u_currentmovementstep = dsCrrntMv.getValue(0, "u_currentmovementstep", "");
        if ("Histo".equalsIgnoreCase(u_currentmovementstep)) {
            throw new SapphireException("Current Movement Step of Sample Id: " + sampleid + " is "
                    + u_currentmovementstep + ".\nPlease complete step of the Sample from Histology Setup.");
        } else if ("BlockRoomCOC".equalsIgnoreCase(u_currentmovementstep)) {
            throw new SapphireException("Sample Id: " + sampleid + " is not in Microtomy tramstop.");
        } else if ("Microtomy".equalsIgnoreCase(u_currentmovementstep)) {
            return;
        } /*
             * else { throw new SapphireException("Sample Id: " + sampleid +
			 * " is not in Microtomy tramstop."); }
			 */
    }

    /**
     * Description: This method is used to validate the Sample type is Client
     * H&E or Client Unstained Slide.
     *
     * @param sampleid
     * @throws SapphireException
     */
    private void validationForSlides(String sampleid) throws SapphireException {
        String sql = "select s.u_type,t.containertypeid from s_sample s, trackitem t" + " where s.s_sampleid='"
                + sampleid + "'" + " and s.s_sampleid = t.linkkeyid1";
        DataSet dsType = getQueryProcessor().getSqlDataSet(sql);
        if (dsType == null) {
            throw new SapphireException("Something goes wrong in sql" + sql);
        }
        String u_type = dsType.getValue(0, "u_type", "");
        String containertypeid = dsType.getValue(0, "containertypeid", "");
        if ("H".equalsIgnoreCase(u_type) || "U".equalsIgnoreCase(u_type) || "B".equalsIgnoreCase(u_type)) {
            throw new SapphireException("Microtomy can not be performed on slide(s).");
        } else if ("Stained Slide".equalsIgnoreCase(containertypeid)
                || "Unstained Slide".equalsIgnoreCase(containertypeid)
                || "HNE Slide".equalsIgnoreCase(containertypeid)) {
            throw new SapphireException("Cutting can not be performed for slide(s)");
        } else {
            return;
        }

        //

    }

    private void validateUserDefaultMicrotomyStation() throws SapphireException {
        String currentUser = connectionInfo.getSysuserId();
        String sql = "select u_microtomystn from sysuser where sysuserid='" + currentUser + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happend. Contact your Administrator.");
            errMsg += " \n Query failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (ds.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No Microtomy station assigned to user:");
            errMsg += " " + currentUser;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        defaultMicrotomyStation = ds.getValue(0, "u_microtomystn", "");
    }

    private void validateSample(DataSet dsInput) throws SapphireException {
        String sampleID = dsInput.getValue(0, "s_sampleid", "");
        String sampletype = dsInput.getValue(0, "sampletypeid", "");
        String transporttype = dsInput.getValue(0, "containertypeid", "");
        if (Util.isNull(sampletype)) {
            throw new SapphireException("Sample type is not defined for the Specimen " + sampleID);
        }
        if (Util.isNull(transporttype)) {
            throw new SapphireException("transport type is not defined for the Specimen " + sampleID);
        }

        String sqlValidate = "select stct.u_movementstep,m.los,m.LVTESTCODEID  from s_sample s, trackitem t, u_sampletestcodemap m,s_sampletypecontainertype stct"
                + " where s.s_sampleid = t.linkkeyid1 and s.s_sampleid =m.s_sampleid and s.SAMPLETYPEID =stct.s_sampletypeid and t.CONTAINERTYPEID = stct.CONTAINERTYPEID"
                + " and stct.s_sampletypeid='" + sampletype + "' and stct.containertypeid='" + transporttype
                + "' and s.s_sampleid='" + sampleID + "'";

        DataSet dsSampleTypeContainerType = getQueryProcessor().getSqlDataSet(sqlValidate);
        String movementstep = Util.getUniqueList(dsSampleTypeContainerType.getColumnValues("u_movementstep", ";"), ";",
                true);
        String sqlSampleClass = "select decode(s.u_type,'EB','Solid',nvl(st.u_class,'N')) u_class"
                + " from s_sample s, s_sampletype st" + " where s.sampletypeid=st.s_sampletypeid"
                + " and s.s_sampleid='" + sampleID + "'";
        DataSet dsSampleClass = getQueryProcessor().getSqlDataSet(sqlSampleClass);
        String u_class = dsSampleClass.getValue(0, "u_class", "");
        String los = Util.getUniqueList(dsSampleTypeContainerType.getColumnValues("los", ";"), ";", true);
        // Only surgical Morphology (Tissue+RPMI) will come throgh FreshPrep
        if (!"Solid".equalsIgnoreCase(u_class)) {
            if ("FreshPrep".equalsIgnoreCase(movementstep) && !("Morphology;Morphology IA".contains(los))) {
                throw new SapphireException("You can perform Microtomy only for Solid Specimens.");
            }
        }

    }

    private int isMultipleCassetteExists(String parentSampleID) throws SapphireException {
        // Do not consider disposed cassettes in cassette count
        String sql = "select count(outs.s_sampleid) count from s_sample outs where nvl(outs.disposalstatus,'Not Disposed')!='Disposed' and  outs.s_sampleid in ("
                + " select destsampleid from s_samplemap where sourcesampleid =("
                + " select m.sourcesampleid from s_samplemap m, s_sample s" + " where m.destsampleid = s.s_sampleid"
                + " and s.s_sampleid= '" + parentSampleID + "'))";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        return ds.getInt(0, "count", 0);

    }

    private String getFistCutHNE(String parentSampleID) throws SapphireException {
        /**
         * First time only one H&E has created .
         */
        String sql = "select m.destsampleid,m.sourcesampleid,s.u_type" + " from s_sample s, s_samplemap m"
                + " where s.s_sampleid = m.destsampleid" + " and m.sourcesampleid ='" + parentSampleID
                + "' and u_type='H'";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            throw new SapphireException("Something wrong happened. Contact your Administrator.\nSQL failed:" + sql);
        }
        if (ds.size() == 0) {
            return "";
        }
        return ds.getValue(0, "destsampleid", "");

    }

    private String getSlidesFromDataSet(DataSet ds, String slidetype) throws SapphireException {
        if (ds == null || ds.size() == 0) {
            return "";
        }

        String hneSlides = "";
        HashMap hm = new HashMap();
        hm.put(DATASET_PROPERTY_CHILD_TYPE, slidetype);
        DataSet dsFilter = ds.getFilteredDataSet(hm);

        if (dsFilter == null || dsFilter.size() == 0) {
            return "";
        }

        hneSlides = dsFilter.getColumnValues(DATASET_PROPERTY_CHILD_SAMPLE_ID, ";");

        return hneSlides;

    }

    private String synkHomogeneousLOS(String los) throws SapphireException {
        String replaceStr = "";
        String losArray[] = StringUtil.split(los, ";");
        String finalLOS = "";
        for (String eachlos : losArray) {
            replaceStr = homogeneousLOS.getProperty(eachlos);
            if (!Util.isNull(replaceStr)) {
                // los = StringUtil.replaceAll(los, eachlos, replaceStr);
                finalLOS += ";" + replaceStr;
            } else {
                finalLOS += ";" + eachlos;
            }
        }
        if (finalLOS.startsWith(";")) {
            finalLOS = finalLOS.substring(1);
        }

        return finalLOS;
    }

    private String getTestCodeFromParents(String parentSampleID, String extractiontype) {
        String lvtestcodes = "";
        String sql = "select lvtestcodeid from u_sampletestcodemap where s_sampleid='" + parentSampleID
                + "' and extractiontype='" + extractiontype + "'";
        DataSet dsLvTestcodes = getQueryProcessor().getSqlDataSet(sql);
        lvtestcodes = dsLvTestcodes.getColumnValues("lvtestcodeid", "#");
        logger.info(extractiontype + " extractiontype tests: " + lvtestcodes);
        return lvtestcodes;
    }

    private int getTestCodeCountFromParents(String parentSampleID, String methogology) throws SapphireException {
        int count = 0;
        String sql = Util.parseMessage(ApSql.GET_SAMPLE_TEST_CODE_MAP, parentSampleID, methogology);

        DataSet dsIHCMetho = getQueryProcessor().getSqlDataSet(sql);
        count = dsIHCMetho.size();
        return count;
    }

    private void hasTestCodes(String sampleid) throws SapphireException {
        String sql = "select s_sampleid from u_sampletestcodemap where s_sampleid='" + sampleid + "'";
        DataSet dsTests = getQueryProcessor().getSqlDataSet(sql);
        if (dsTests != null && dsTests.size() > 0) {
            return;
        } else {
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION,
                    "No Test Code(s) associated with the sample: " + sampleid);
        }
    }

    private void getAllChildsAssociatedWithBlock(String sampleid) throws SapphireException {
        String slides = Util.parseMessage(ApSql.GET_ALL_SPECIMENS_BY_BLOCK, sampleid);
        DataSet dsSlides = getQueryProcessor().getSqlDataSet(slides);
        if (dsSlides != null && dsSlides.size() > 0) {
            newSlideIDs = dsSlides.getColumnValues("s_sampleid", ";");
        }
    }

    /**************************
     * Base dataset design
     *******************************************************************/
    private static final String DATASET_PROPERTY_PARENT_SAMPLE_ID = "parentsampleid";
    private static final String DATASET_PROPERTY_CHILD_TEST_CODE_ID = "childtestcodeid";
    private static final String DATASET_PROPERTY_CHILD_PANEL_ID = "childtestpanelid";
    private static final String DATASET_PROPERTY_CHILD_IS_PANEL = "childispanel";
    private static final String DATASET_PROPERTY_CHILD_PANEL_LOAD = "childpanelload";// full/partial/none
    private static final String DATASET_PROPERTY_CHILD_SAMPLE_ID = "childsampleid";
    private static final String DATASET_PROPERTY_CHILD_SAMPLE_TYPE_ID = "childsampletypeid";
    private static final String DATASET_PROPERTY_CHILD_TRANSPORT_TYPE_ID = "childtransporttypeid";
    private static final String DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY = "childsamplemethodology";
    private static final String DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE = "childsampleextractiontype";
    private static final String DATASET_PROPERTY_CHILD_SAMPLE_LOS = "childsamplelos";
    private static final String DATASET_PROPERTY_CHILD_TYPE = "childtype";
    private static final String DATASET_PROPERTY_IS_SPECIAL_TEST_CODE = "isspecialtestcode";

    public static final String SLIDE_SYMBOL_HE = "H";
    public static final String SLIDE_SYMBOL_SHARED_HE = "SH";
    public static final String SLIDE_SYMBOL_TEST_SLIDE = "U";
    public static final String SLIDE_SYMBOL_BACKUP = "B";

    public static final String IS_PANEL_YES = "Y";
    public static final String IS_PANEL_NO = "N";

    private DataSet initializeDataSet() throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn(DATASET_PROPERTY_PARENT_SAMPLE_ID, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_TEST_CODE_ID, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_PANEL_ID, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_IS_PANEL, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_PANEL_LOAD, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_SAMPLE_ID, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_SAMPLE_TYPE_ID, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_TRANSPORT_TYPE_ID, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_SAMPLE_LOS, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_CHILD_TYPE, DataSet.STRING);
        ds.addColumn(DATASET_PROPERTY_IS_SPECIAL_TEST_CODE, DataSet.STRING);

        return ds;
    }

    private void addRowToDataSet(DataSet ds, String parentSampleID, String childTestCodeID, String childPanelID,
                                 String isPanel, String childMethodology, String childSampleLOS, String childType, String splTestCodeFlag,
                                 String sampletype, String transporttype, String molecularExtractionType) throws SapphireException {

        int rowID = ds.addRow();
        ds.setValue(rowID, DATASET_PROPERTY_PARENT_SAMPLE_ID, parentSampleID);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_TEST_CODE_ID, childTestCodeID); // this
        // can
        // be
        // semicolon
        // separated
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_IS_PANEL, isPanel);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_PANEL_ID, childPanelID);// this
        // can
        // be
        // semicolon
        // separated
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, childMethodology);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_LOS, childSampleLOS);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_TYPE, childType);
        ds.setValue(rowID, DATASET_PROPERTY_IS_SPECIAL_TEST_CODE, splTestCodeFlag);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_TYPE_ID, sampletype);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_TRANSPORT_TYPE_ID, transporttype);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE, molecularExtractionType);
    }

    private void addRowToDataSetForPanelPopulation(DataSet ds, String parentSampleID, String childTestCodeID, String childPanelID,
                                                   String isPanel, String childMethodology, String childSampleLOS, String childType, String splTestCodeFlag,
                                                   String sampletype, String transporttype, String molecularExtractionType) throws SapphireException {

        int rowID = ds.addRow();
        ds.setValue(rowID, DATASET_PROPERTY_PARENT_SAMPLE_ID, parentSampleID);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_TEST_CODE_ID, childTestCodeID); // this
        // can
        // be
        // semicolon
        // separated
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_IS_PANEL, isPanel);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_PANEL_ID, childPanelID);// this
        // can
        // be
        // semicolon
        // separated
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_METHODOLOGY, childMethodology);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_LOS, childSampleLOS);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_TYPE, childType);
        ds.setValue(rowID, DATASET_PROPERTY_IS_SPECIAL_TEST_CODE, splTestCodeFlag);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_TYPE_ID, sampletype);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_TRANSPORT_TYPE_ID, transporttype);
        ds.setValue(rowID, DATASET_PROPERTY_CHILD_SAMPLE_EXTRACTION_TYPE, molecularExtractionType);
    }

    private PropertyList getPropertyListForAddingTestCode(DataSet dsTestCodes, String methodology)
            throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, DataSet.STRING);
        // this column for both panel & test code
        ds.addColumn(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, DataSet.STRING);
        ds.addColumn(AssignTestCode.INPUT_PROPERTY_IS_PANEL, DataSet.STRING);
        ds.addColumn(AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, DataSet.STRING);
        ds.addColumn(AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, DataSet.STRING);

        HashMap hm = new HashMap();
        if (methodology.equalsIgnoreCase(PROPERTY_METH_MOLEULAR)) {
            for (int i = 0; i < dsTestCodes.getRowCount(); i++) {
                String sampleID = dsTestCodes.getValue(i, DATASET_PROPERTY_CHILD_SAMPLE_ID);
                String childTestCodes = dsTestCodes.getValue(i, DATASET_PROPERTY_CHILD_TEST_CODE_ID);
                String childPanelCodes = dsTestCodes.getValue(i, DATASET_PROPERTY_CHILD_PANEL_ID);
                String childTestCodesArray[] = StringUtil.split(childTestCodes, "#"); // TODO
                // MAKE
                // it
                // as
                // #
                // seperated
                for (int j = 0; j < childTestCodesArray.length; j++) {// String
                    // test
                    // :
                    // childTestCodesArray)
                    // {
                    int rowID = ds.addRow();
                    ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, sampleID);
                    ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, childTestCodesArray[j]);
                    ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, childPanelCodes);
                }
            }

        } else if (methodology.equalsIgnoreCase(PROPERTY_METH_FISH)) {
            for (int i = 0; i < dsTestCodes.getRowCount(); i++) {
                String sampleID = dsTestCodes.getValue(i, DATASET_PROPERTY_CHILD_SAMPLE_ID);
                String childTestCodes = dsTestCodes.getValue(i, DATASET_PROPERTY_CHILD_TEST_CODE_ID);
                String childPanelCodes = dsTestCodes.getValue(i, DATASET_PROPERTY_CHILD_PANEL_ID);

                //Length of testcode array and panecode array will be same.
                String childTestCodesArray[] = StringUtil.split(childTestCodes, "#");
                String childPanelCodesArray[] = StringUtil.split(childPanelCodes, "#");
                for (int j = 0; j < childTestCodesArray.length; j++) {// String
                    String semicolonSeperatedTestcodes[] = StringUtil.split(childTestCodesArray[j], ";");
                    String semicolonSeperatedPanelcodes[] = StringUtil.split(childPanelCodesArray[j], ";");
                    for (String eachTestCode : semicolonSeperatedTestcodes) {
                        int rowID = ds.addRow();
                        ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, sampleID);
                        ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, eachTestCode);
                        ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, semicolonSeperatedPanelcodes[0]);
                    }
                }
            }

        } else {

            hm.put(DATASET_PROPERTY_CHILD_IS_PANEL, "Y");
            DataSet dsFilterPanel = dsTestCodes.getFilteredDataSet(hm);
            for (int i = 0; i < dsFilterPanel.getRowCount(); i++) {
                String sampleID = dsFilterPanel.getValue(i, DATASET_PROPERTY_CHILD_SAMPLE_ID);
                String childTestPanelCodes = Util
                        .getUniqueList(dsFilterPanel.getValue(i, DATASET_PROPERTY_CHILD_PANEL_ID), ";", true);
                String childTestPanelCodesArray[] = StringUtil.split(childTestPanelCodes, ";");
                for (String test : childTestPanelCodesArray) {
                    int rowID = ds.addRow();
                    ds.setValue(rowID, "s_sampleid", sampleID);
                    ds.setValue(rowID, "lvtestcode", test);
                    ds.setValue(rowID, "ispanel", "Y");
                    ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, methodology);
                }
            }

            hm.clear();
            hm.put(DATASET_PROPERTY_CHILD_IS_PANEL, "N");
            DataSet dsFilterTestCodes = dsTestCodes.getFilteredDataSet(hm);
            for (int i = 0; i < dsFilterTestCodes.getRowCount(); i++) {
                String sampleID = dsFilterTestCodes.getValue(i, DATASET_PROPERTY_CHILD_SAMPLE_ID);
                String childTestCodes = dsFilterTestCodes.getValue(i, DATASET_PROPERTY_CHILD_TEST_CODE_ID);
                String childTestCodesArray[] = StringUtil.split(childTestCodes, ";");
                for (String test : childTestCodesArray) {
                    int rowID = ds.addRow();
                    ds.setValue(rowID, "s_sampleid", sampleID);
                    ds.setValue(rowID, "lvtestcode", test);
                    // ds.setValue(rowID, "lvtestpanelid", test);
                    ds.setValue(rowID, "ispanel", "N");
                    ds.setValue(rowID, AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, ""); // panel
                    // specific
                    // input
                }
            }
        }
        PropertyList pl = new PropertyList();
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,
                ds.getColumnValues(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, ";"));
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,
                ds.getColumnValues(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, ";"));
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL,
                ds.getColumnValues(AssignTestCode.INPUT_PROPERTY_IS_PANEL, ";"));
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY,
                ds.getColumnValues(AssignTestCode.INPUT_PROPERTY_APPLY_PANEL_FOR_METHODOLOGY, ";"));
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE,
                ds.getColumnValues(AssignTestCode.INPUT_PROPERTY_PANEL_ASSOCIATED_WITH_TEST_CODE, ";"));
        pl.setProperty(AssignTestCode.INPUT_PROPERTY_CHANGE_BACKUP_TO_USS,
                StringUtil.repeat("N", ds.getRowCount(), ";"));
        pl.setProperty("workitemflag", "Y");

        return pl;

    }

    private DataSet hasSectionedCheckBlock(String sampleid) throws SapphireException {
        String sql = "select destsampleid from s_samplemap where sourcesampleid='" + sampleid + "'";
        DataSet dsSlides = getQueryProcessor().getSqlDataSet(sql);
        if (dsSlides != null && dsSlides.size() > 0) {
            return dsSlides;
        }
        return dsSlides;
    }

}
