package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.xml.crypto.Data;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by DMondal on 9/28/2016.
 * Description : This Action will identify samples with associated test codes which is belongs to User Given los.
 * Then it will find appropriate testcode which is belongs to Global los for those test code,
 * then it will delete all finding test codes with los User Given.Next it will call Assign Test Code for test apply to that samples
 * with new finding test code that is belongs to Global los.
 * Updated tables are u_sampletestcodemap,sdiworkitem,sdiworkitemitem,sdidata and sdidataitem
 */
public class TurnToGlobal extends BaseAction {
    private static final String PROPERT_IHC_LOS_GLOBAL_IA = "Global IA";
    private static final String PROPERT_IHC_LOS_TECHNICAL_IA = "Technical IA";
    private static final String PROPERT_IHC_LOS_WHOLE_SLIDE_SCAN = "Whole Slide Scan";
    private static final String PROPERT_IHC_LOS_GLOBAL_MANUAL_QUANTITATIVE = "Global Manual Quantitative";
    private static final String PROPERT_IHC_LOS_GLOBAL_MANUAL_QUALITATIVE = "Global Manual Qualitative";

    public void processAction(PropertyList properties) throws SapphireException {
        String inputLos = properties.getProperty("inputLos", "");
        if (Util.isNull(inputLos)) {
            String error = getTranslationProcessor().translate("Input LOS cannot be blank/null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        String inputAccessionId = properties.getProperty("inputAccessionId", "");
        if (Util.isNull(inputAccessionId)) {
            String error = getTranslationProcessor().translate("Input Accession ID cannot be blank/null.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        String userid = properties.getProperty("userid", "");//This is not mandatory , but email communication would happen by this userid

        initializeDataSet();
        searchSamplesForTurnToGlobal(inputLos, inputAccessionId);
        deleteSDIData();
        addTestCode();
        try {
            if(!Util.isNull(userid))
                emailSend(userid);
        }catch (SapphireException e){
            logger.error("Turn to global error in email >>"+e.getMessage());
        }
    }

    /**
     * Description : This method is used for sending email to user.email is not mandatory.
     *
     * @param userid
     * @throws SapphireException
     */
    private void emailSend(String userid) throws SapphireException {
        String sql = "select sysuserdesc,email from sysuser where sysuserid='" + userid + "'";
        DataSet dsEmail = getQueryProcessor().getSqlDataSet(sql);
        if (dsEmail == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsEmail.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No data found in sysuser table for user id:" + userid);
            errMsg += "\nQuery retuns no rows:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String name = dsEmail.getString(0, "sysuserdesc");
        String email = dsEmail.getString(0, "email");
        PropertyList plGlobalPolicy = getConfigurationProcessor().getPolicy("PushToGlobalEmailPolicy", "global");
        PropertyList plEmail = plGlobalPolicy.getPropertyList("email");
        String from = plEmail.getProperty("from");
        String subject = plEmail.getProperty("subject");
        String content1 = plEmail.getProperty("content1");
        String content2 = plEmail.getProperty("content2");
        String content3 = plEmail.getProperty("content3");
        String c1 = content1.replaceAll("#clientname", name);
        String c2 = c1.replaceAll("#clientid", userid);
        String c3 = c2.replaceAll("#tests", StringUtil.replaceAll(dsMain.getColumnValues(DATASET_PROPERTY_LVTESTCODEPANELCODE, ";"), ";", ","));
        String c4 = c3.replaceAll("#clientspecimenid", StringUtil.replaceAll(dsMain.getColumnValues(DATASET_PROPERTY_CLIENTSPECIMENTID, ";"), ";", ","));
        String finalContent = c4 + " " + content2 + " " + content3;

        PropertyList props = new PropertyList();
        props.setProperty(SendMail.PROPERTY_FROM, from);
        props.setProperty(SendMail.PROPERTY_ADDRESS, email);
        props.setProperty(SendMail.PROPERTY_SUBJECT, subject);
        props.setProperty(SendMail.PROPERTY_MESSAGE, finalContent);
        props.setProperty(SendMail.PROPERTY_MESSAGEHEADER, subject);
        getActionProcessor().processAction(SendMail.ID, SendMail.VERSIONID, props, true);
    }

    /**
     * Description : This method is used for finding appropriate Global testcode and adding to daMain.
     *
     * @param inputLos
     * @throws SapphireException
     */
    private void getGlobalTestCode(String inputLos) throws SapphireException {

        String sqlGetGlobalTestcode = "select u_testcodeid,clienttestcodeid,los from u_testcode " +
                " where clienttestcodeid in('" + dsMain.getColumnValues(DATASET_PROPERTY_CLIENTTESTCODEID, "','") + "') ";
        DataSet dsGetGlobalTestcode = getQueryProcessor().getSqlDataSet(sqlGetGlobalTestcode);
        if (dsGetGlobalTestcode == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlGetGlobalTestcode;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsGetGlobalTestcode.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No Global test code found");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        ///-------------------For grouping different dataset based on clienttestcodeid--------------------------
        dsGetGlobalTestcode.sort("clienttestcodeid");
        ArrayList arrayGlobalTestCode = dsGetGlobalTestcode.getGroupedDataSets("clienttestcodeid");
        for (int j = 0; j < arrayGlobalTestCode.size(); j++) {
            DataSet dsEach = (DataSet) arrayGlobalTestCode.get(j);
            getGlobalTestFromEachDataSet(inputLos, dsEach);
        }
        //-----------------------------------------------
    }

    /**
     * Description : This method will add Global test to DsMain from each Dataset where clienttestcodeid more than one.
     *
     * @param inputLos
     * @param dsGetGlobalTestcode
     * @throws SapphireException
     */
    private void getGlobalTestFromEachDataSet(String inputLos, DataSet dsGetGlobalTestcode) throws SapphireException {
        DataSet dsPolicy = getLosFromPolicy();
        HashMap hm = new HashMap();
        hm.clear();
        hm.put("sourcelos", inputLos);
        DataSet filterdsPolicy = dsPolicy.getFilteredDataSet(hm);
        if (filterdsPolicy.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Input LOS is not defined in policy.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        // sourcelos will not multiple in filterdsPolicy.
        String sourcelos = filterdsPolicy.getValue(0,"sourcelos","");
        String tagetlos = filterdsPolicy.getValue(0,"tagetlos","");
        String target2los = filterdsPolicy.getValue(0,"target2los","");

        DataSet filterGlobalTestCode = null;
        //Logic:If Input LOS is 'Technical IA' it will add 'Global IA'.If input LOS is 'Whole Slide Scan' it will add 'Global Manual Quantitative',If
        //'Global Manual Quantitative' not found then it will add 'Global Manual Qualitative'.

        if (!Util.isNull(sourcelos)) {
            hm.clear();
            hm.put("los", tagetlos);
            filterGlobalTestCode = dsGetGlobalTestcode.getFilteredDataSet(hm);
            if (filterGlobalTestCode.size() == 0) {
                hm.put("los", target2los);
                filterGlobalTestCode = dsGetGlobalTestcode.getFilteredDataSet(hm);
                if (filterGlobalTestCode.size() == 0) {
                    String errMsg = getTranslationProcessor().translate("No Global test code found for the below native test.\n"
                            + dsMain.getColumnValues(DATASET_PROPERTY_CLIENTTESTCODEID, ","));
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
            }
        }

        //After getting Global testcode it will add to the dsMain
        DataSet dsFilterGlobalTestCode;
        for (int i = 0; i < dsMain.size(); i++) {
            hm.clear();
            hm.put("clienttestcodeid", dsMain.getValue(i, DATASET_PROPERTY_CLIENTTESTCODEID, ""));
            dsFilterGlobalTestCode = filterGlobalTestCode.getFilteredDataSet(hm);
            if (dsFilterGlobalTestCode.size() > 0) {
                dsMain.setValue(i, DATASET_PROPERTY_NEWTESTTOAPPLY, dsFilterGlobalTestCode.getValue(0, "u_testcodeid"));
            }
        }

    }

    /**
     * Description : This method is for getting target los from policy.
     * @return
     * @throws SapphireException
     */
    private DataSet getLosFromPolicy() throws SapphireException {
        DataSet ds = new DataSet();
        ds.addColumn("sourcelos", DataSet.STRING);
        ds.addColumn("tagetlos", DataSet.STRING);
        ds.addColumn("target2los", DataSet.STRING);
        int incr = 0;
        PropertyList plTurnToGlobal = getConfigurationProcessor().getPolicy("TurnToGlobalPolicy", "convertlos");
        if (plTurnToGlobal == null)
            throw new SapphireException("Turn To Global Policy is  not found in the system");
        PropertyListCollection plc = plTurnToGlobal.getCollection("losbucket");
        if (plc == null || plc.size() == 0)
            throw new SapphireException("TurnToGlobalPolicy is not configured properly.");

        String sourcelos = "";
        String tagetlos = "";
        String target2los = "";
        for (int i = 0; i < plc.size(); i++) {
            PropertyList pl = plc.getPropertyList(i);
            if (pl != null && pl.size() > 0) {
                PropertyList eachrow = pl.getPropertyList("eachrow");
                sourcelos = eachrow.getProperty("sourcelos", "");
                if (Util.isNull(sourcelos)) {
                    String errMsg = getTranslationProcessor().translate("sourcelos can not be null in TurnToGlobalPolicy.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
                tagetlos = eachrow.getProperty("tagetlos", "");
                if (Util.isNull(tagetlos)) {
                    String errMsg = getTranslationProcessor().translate("tagetlos can not be null in TurnToGlobalPolicy.");
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
                target2los = eachrow.getProperty("target2los", "");
                incr = ds.addRow();
                ds.setValue(incr, "sourcelos", sourcelos);
                ds.setValue(incr, "tagetlos", tagetlos);
                ds.setValue(incr, "target2los", target2los);
            }
        }
        return ds;
    }
    /*private void getGlobalTestFromEachDataSet_old(String inputLos,DataSet dsGetGlobalTestcode) throws SapphireException {
        DataSet filterGlobalTestCode=null;
        HashMap hm=new HashMap();
        //Logic:If Input LOS is 'Technical IA' it will add 'Global IA'.If input LOS is 'Whole Slide Scan' it will add 'Global Manual Quantitative',If
        //'Global Manual Quantitative' not found then it will add 'Global Manual Qualitative'.
        if(PROPERT_IHC_LOS_TECHNICAL_IA.equalsIgnoreCase(inputLos)){
            hm.clear();
            hm.put("los",PROPERT_IHC_LOS_GLOBAL_IA);
            filterGlobalTestCode=dsGetGlobalTestcode.getFilteredDataSet(hm);
            if(filterGlobalTestCode.size()==0){
                String errMsg = getTranslationProcessor().translate("No Global test code found for the below native test.\n"
                        +dsMain.getColumnValues(DATASET_PROPERTY_CLIENTTESTCODEID,","));
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
        }else if(PROPERT_IHC_LOS_WHOLE_SLIDE_SCAN.equalsIgnoreCase(inputLos)){
            hm.clear();
            hm.put("los",PROPERT_IHC_LOS_GLOBAL_MANUAL_QUANTITATIVE);
            filterGlobalTestCode=dsGetGlobalTestcode.getFilteredDataSet(hm);
            if(filterGlobalTestCode.size()==0){
                hm.put("los",PROPERT_IHC_LOS_GLOBAL_MANUAL_QUALITATIVE);
                filterGlobalTestCode=dsGetGlobalTestcode.getFilteredDataSet(hm);
                if(filterGlobalTestCode.size()==0){
                    String errMsg = getTranslationProcessor().translate("No Global test code found for the below native test.\n"
                            +dsMain.getColumnValues(DATASET_PROPERTY_CLIENTTESTCODEID,","));
                    throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
                }
            }
        }else{
            String errMsg = getTranslationProcessor().translate("Input los must be "+PROPERT_IHC_LOS_TECHNICAL_IA+" or "+PROPERT_IHC_LOS_WHOLE_SLIDE_SCAN);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }

        //After getting Global testcode it will add to the dsMain
        DataSet dsFilterGlobalTestCode;
        for(int i=0;i<dsMain.size();i++){
            hm.clear();
            hm.put("clienttestcodeid",dsMain.getValue(i,DATASET_PROPERTY_CLIENTTESTCODEID,""));
            dsFilterGlobalTestCode=filterGlobalTestCode.getFilteredDataSet(hm);
            if(dsFilterGlobalTestCode.size()>0){
                dsMain.setValue(i,DATASET_PROPERTY_NEWTESTTOAPPLY,dsFilterGlobalTestCode.getValue(0,"u_testcodeid"));
            }
        }

    }*/

    /**
     * Description : This method will find all the sample id and parent samples,testcode which is associated with that sample.
     * test code id which belongs to Global los for the test code which is belongs to User Given los.
     *
     * @param inputLos         - This is for input LOS that will be provided by user.
     * @param inputAccessionId - This is for input Accession Id that will be provided by user.
     * @throws SapphireException
     */
    private void searchSamplesForTurnToGlobal(String inputLos, String inputAccessionId) throws SapphireException {
        String sqlSampleTOGlobal = " select s.s_sampleid,s.u_clientspecimenid,m.u_sampletestcodemapid,sdi.workitemid,sdi.workiteminstance," +
                " m.lvtestpanelid,m.lvtestcodeid,nvl(m.ispanel,'N') as ispanel," +
                " (select t.clienttestcodeid from u_testcode t where t.u_testcodeid = m.lvtestcodeid) clienttestcodeid " +
                " from s_sample s, u_sampletestcodemap m, sdiworkitem sdi " +
                " where s.s_sampleid = m.s_sampleid and s.s_sampleid= sdi.keyid1 and m.testname = sdi.workitemid " +
                " and s.u_accessionid='" + inputAccessionId + "' and m.los='" + inputLos + "' ";
        DataSet dsSampleTOGlobal = getQueryProcessor().getSqlDataSet(sqlSampleTOGlobal);
        if (dsSampleTOGlobal == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlSampleTOGlobal;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsSampleTOGlobal.size() == 0) {
            String errMsg = getTranslationProcessor().translate("No Sample(s) found with LOS:" + inputLos + " for Accession:" + inputAccessionId + ".");
            errMsg += "\nQuery retuns no rows:" + sqlSampleTOGlobal;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        addDataToDsMain(dsSampleTOGlobal);
        getGlobalTestCode(inputLos);
    }

    /**
     * Description : This method is used for setting all searched data to the main dataset and if found null data it will throw an exception with proper message.
     *
     * @param dsTechnicalSamples
     * @throws SapphireException
     */
    private void addDataToDsMain(DataSet dsTechnicalSamples) throws SapphireException {
        int rowInc = 0;
        for (int i = 0; i < dsTechnicalSamples.size(); i++) {
            rowInc = dsMain.addRow();
            dsMain.setValue(rowInc, DATASET_PROPERTY_SAMPLE_ID, dsTechnicalSamples.getValue(i, "s_sampleid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_WORKITEMID, dsTechnicalSamples.getValue(i, "workitemid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_WORKITEMINSTANCE, dsTechnicalSamples.getValue(i, "workiteminstance", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_LVTESTPANELID, dsTechnicalSamples.getValue(i, "lvtestpanelid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_LVTESTCODEID, dsTechnicalSamples.getValue(i, "lvtestcodeid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, dsTechnicalSamples.getValue(i, "u_sampletestcodemapid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_CLIENTSPECIMENTID, dsTechnicalSamples.getValue(i, "u_clientspecimenid", ""));
            dsMain.setValue(rowInc, DATASET_PROPERTY_CLIENTTESTCODEID, dsTechnicalSamples.getValue(i, "clienttestcodeid", ""));
            String isPanelExists = dsTechnicalSamples.getValue(i, "ispanel", "");
            if ("Y".equalsIgnoreCase(isPanelExists)) {
                //Test panel block
                String lvpanelcode = dsTechnicalSamples.getValue(i, "lvtestpanelid", "");
                dsMain.setValue(rowInc, DATASET_PROPERTY_LVTESTCODEPANELCODE, lvpanelcode);
            } else {
                //Test code block
                String lvtestcode = dsTechnicalSamples.getValue(i, "lvtestcodeid", "");
                dsMain.setValue(rowInc, DATASET_PROPERTY_LVTESTCODEPANELCODE, lvtestcode);
            }

        }
    }

    /**
     * Description : This method is used for delete a record from SampleTestCodeMap SDC for a Keydi1,Sampleid
     * and testcodeid or testpanelid that is belongs to User Given LOS.
     * DeleteSDIWorkItem where SDCID=Sample will delete sdiworkitem,sdiworkitemitem,sdidata,sdidataitem tables record for
     * a sample id which associated a test that is belongs to User Given LOS.
     *
     * @throws SapphireException
     */
    private void deleteSDIData() throws SapphireException {
        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(DeleteSDI.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, ";"));
            prop.setProperty("lvtestcodeid", dsMain.getColumnValues(DATASET_PROPERTY_LVTESTCODEID, ";"));
            prop.setProperty("lvtestpanelid", dsMain.getColumnValues(DATASET_PROPERTY_LVTESTPANELID, ";"));
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from SampleTestCodeMap.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        PropertyList props = new PropertyList();
        try {
            props.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID, dsMain.getColumnValues(DATASET_PROPERTY_WORKITEMID, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE, dsMain.getColumnValues(DATASET_PROPERTY_WORKITEMINSTANCE, ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES, StringUtil.repeat("Y", dsMain.size(), ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, StringUtil.repeat("Y", dsMain.size(), ";"));
            getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Can't delete from SDIWorkItem and related tables.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }

    /**
     * Description : This method is used for applying test code with los Global.
     *
     * @throws SapphireException
     */
    private void addTestCode() throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsMain.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
        props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsMain.getColumnValues(DATASET_PROPERTY_NEWTESTTOAPPLY, ";"));
        try {
            getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error occurred: Error in AssignTestCode");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }

    /*****************
     * BASE DESIGN ***********DO NOT CHANGE THIS
     *****************************/
    private DataSet dsMain = null;
    private static final String DATASET_PROPERTY_SAMPLE_ID = "s_sampleid";
    private static final String DATASET_PROPERTY_WORKITEMID = "workitemid";
    private static final String DATASET_PROPERTY_WORKITEMINSTANCE = "workiteminstance";
    private static final String DATASET_PROPERTY_LVTESTCODEPANELCODE = "lvtestcodepanelcode";
    private static final String DATASET_PROPERTY_SAMPLETESTCODEMAP_ID = "sampletestcodemapid";
    private static final String DATASET_PROPERTY_LVTESTPANELID = "lvtestpanelid";
    private static final String DATASET_PROPERTY_LVTESTCODEID = "lvtestcodeid";
    private static final String DATASET_PROPERTY_CLIENTSPECIMENTID = "clientspecimenid";
    private static final String DATASET_PROPERTY_CLIENTTESTCODEID = "clienttestcodeid";
    private static final String DATASET_PROPERTY_NEWTESTTOAPPLY = "newtesttoapply";

    /**
     * Description: This method is only used for initialing dataset
     *
     * @throws SapphireException
     */
    private void initializeDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_WORKITEMID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_WORKITEMINSTANCE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTCODEPANELCODE, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_SAMPLETESTCODEMAP_ID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTPANELID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_LVTESTCODEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_CLIENTSPECIMENTID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_CLIENTTESTCODEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_NEWTESTTOAPPLY, DataSet.STRING);
        }
    }
}
