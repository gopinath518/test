package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.action.GenerateLabel;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.ArrayList;

/**
 * Created by mpandey on 10/28/2016.
 */
public class GenerateNGLabel extends BaseAction {

    String labeltype = "";
    String printerpath = "";
    String printerid = "";
    String sampleid = "";
    private static final String PRINTLABELPOLICY = "PrintLabel";
    private static final String NODEID = "PrintLabelInfo";

    public void processAction(PropertyList properties) throws SapphireException {

        printerpath=properties.getProperty("printerpath");
        validateInput(properties);

        printerid = getPrinterID(printerpath);

        ArrayList<DataSet> listChunkData = preparePrintingChunk();
        for (DataSet dsEachChunk : listChunkData) {

            printLabel(dsEachChunk,printerid);
        }
    }

    private void printLabel(DataSet dsEachChunk,String printerid) throws SapphireException {
        String transporttype = dsEachChunk.getValue(0, "containertypeid");
        String labelmethod = getLabelMethod(transporttype);
        if (labelmethod.length() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(GenerateLabel.PROPERTY_KEYID1, sampleid);
            pl.setProperty(GenerateLabel.PROPERTY_LABELMETHODID, labelmethod);
            pl.setProperty(GenerateLabel.PROPERTY_LABELMETHODVERSIONID, "1");
            pl.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSID, printerid);
            pl.setProperty(GenerateLabel.PROPERTY_PRINTERADDRESSTYPE, "Device");
            getActionProcessor().processAction(GenerateLabel.ID, GenerateLabel.VERSIONID, pl);

        } else {
            throw new SapphireException("Label Method is not defined in PrintLabel .");
        }
    }

    private String getLabelMethod(String transporttype) throws SapphireException {
        PropertyList prtLblPolicy = getConfigurationProcessor().getPolicy(PRINTLABELPOLICY, NODEID);
        if (prtLblPolicy == null)
            throw new SapphireException("Print label policy is  not found in the system");
        PropertyListCollection plc = prtLblPolicy.getCollection("labelselectioninfo");
        if (plc == null || plc.size() == 0)
            throw new SapphireException("PrintLabel policy is not configured properly.");
        if (plc != null && plc.size() > 0) {
            for (int i = 0; i < plc.size(); i++) {
                PropertyList tempPl = plc.getPropertyList(i);
                if (tempPl != null && tempPl.size() > 0) {
                    String templabeltype = tempPl.getProperty("labeltype", "");
                    String temptransporttype = tempPl.getProperty("transporttype", "");
                    if (templabeltype.equalsIgnoreCase(labeltype) && temptransporttype.equalsIgnoreCase(transporttype))
                        return tempPl.getProperty("labelmethod", "");
                }
            }
        }
        return "";
    }

    private ArrayList<DataSet> preparePrintingChunk() throws SapphireException {

        String sql = "select  linkkeyid1,containertypeid from trackitem where linksdcid='Sample' and linkkeyid1 in('" + sampleid.replaceAll(";", "','") + "')";
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample == null || dsSample.size() == 0) {
            String errMsg = getTranslationProcessor().translate("There isn't any sample to print label..");
            throw new SapphireException(errMsg);
        }
        ArrayList<DataSet> listChunkData = dsSample.getGroupedDataSets("containertypeid");
        return listChunkData;
    }

    private void validateInput(PropertyList properties) throws SapphireException {
        labeltype = properties.getProperty("labeltype", "");
        sampleid = properties.getProperty("sampleid", "");
        printerid = properties.getProperty("printerid", "");

        if (Util.isNull(sampleid)) {
            String errMsg = "Please provide some sampleid to print label.";
            throw new SapphireException(errMsg);
        }

        if (Util.isNull(labeltype)) {
            String errMsg = "Please provide some value for label type. ";
            throw new SapphireException(errMsg);
        }
        if (Util.isNull(printerid)) {
            String errMsg = "PrinterId is missing,can't proceed. ";
            throw new SapphireException(errMsg);
        }


    }

    private  String getPrinterID(String printerpath) throws SapphireException{
        String sql = "select addressid from address where printerid = '"+printerpath+"'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null ) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact system administrator..");
            throw new SapphireException(errMsg);
        }
        if (ds.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Default printer is not set with this workstation..");
            throw new SapphireException(errMsg);
        }
        String id = ds.getValue(0,"addrressid");
        return id;
    }
}
