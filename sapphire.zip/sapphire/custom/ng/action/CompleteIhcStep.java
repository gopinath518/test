package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

/**
 * Created by dgupta on 6/29/2016.
 */
public class CompleteIhcStep extends BaseAction {
    private static final String HOMOGENEOUSLOSPOLICYID = "HomogeneousLOSPolicy";
    private static final String NODEID = "IHCLOS";
    private static final String POLICY_MAPPING = "losmapping";
    private static final String POLICY_PARENT_LOS = "parentlos";
    private static final String POLICY_CHILD_LOS = "childlos";
    private static final String POLICY_CHILD_LOS_ID = "childlosid";

    /*
    *   Out of box method provided for implementation, used to validate sample and lOS
    *
    *   @param propst   property list
    * */
    public void processAction(PropertyList propst) throws SapphireException {
        String sampleids = propst.getProperty("sampleid");
        if (sampleids.startsWith(";"))
            sampleids = sampleids.substring(1);

        String[] arrSample = StringUtil.split(sampleids, ";");


        DataSet dsSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.SQL_FOR_COMPLETE_IHC_SAMPLES_All, StringUtil.replaceAll(sampleids, ";", "','")));
        if ((dsSample == null) || (dsSample.getRowCount() == 0))
            throw new SapphireException("Looks test are not assigned to sample");

        String los = dsSample.getString(0, "los", "");
        String status = dsSample.getString(0, "u_currentmovementstep", "");
        // los populated from polocy
        PropertyList homogeneousLOS = setHomogeneousLOS();
        los = homogeneousLOS.getProperty(los);
        String department = connectionInfo.getDefaultDepartment();
        String site = department.substring(0, department.indexOf('-'));

        if (dsSample.getRowCount() > 1) {
            for (int i = 0; i < dsSample.getRowCount(); i++) {
                if (los.equalsIgnoreCase(homogeneousLOS.getProperty(dsSample.getString(i, "los")))) {
                    los = homogeneousLOS.getProperty(dsSample.getString(i, "los"));
                }
                /*else {
                    throw new SapphireException("samples are not from same LOS " + dsSample.getColumnValues("los", " and  ") + "\n or " +
                            " in different status " + dsSample.getColumnValues("u_currentmovementstep", " and "));
                }*/
            }
        }

        DataSet dsTestCode = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.SQL_FOR_COMPLETE_IHC_SAMPLES_TEST, StringUtil.replaceAll(sampleids, ";", "','")));
        if ((dsTestCode != null) && (dsTestCode.getRowCount() > 0)) {
            if ((los.equalsIgnoreCase("Global Manual")) && status.equalsIgnoreCase("IHCQCCompleted")) {
                String clinicalSample = "";
                String bioSampleid = dsTestCode.getColumnValues("s_sampleid", ";");
                PropertyList plPath = new PropertyList();
                plPath.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                plPath.setProperty(EditSDI.PROPERTY_KEYID1, bioSampleid);
                plPath.setProperty("u_currentmovementstep", "PathSupport");
                plPath.setProperty("u_imagingdts", "n");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plPath);


//                String destinationDepartment = site + "-PathSupport";
                String destinationDepartment = site + "-Accessioning";
                if (!Util.validateDepartment(destinationDepartment, getQueryProcessor(), getTranslationProcessor()))
                    throw new SapphireException("Unable to route sample as department: " + destinationDepartment + " does not exist");
                plPath.clear();
                plPath.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                plPath.setProperty(EditTrackItem.PROPERTY_KEYID1, bioSampleid);
                plPath.setProperty("u_currenttramstop", "Path Support COC");
                plPath.setProperty("custodialuserid", "(null)");
                plPath.setProperty("custodialdepartmentid", destinationDepartment);
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, plPath);

                for (String sid : arrSample) {
                    if (!bioSampleid.contains(sid)) {
                        clinicalSample = clinicalSample + ";" + sid;
                    }
                }
                sampleids = clinicalSample.startsWith(";") ? clinicalSample.substring(1) : clinicalSample;
            }
        }
        if ((sampleids != null) && sampleids.length() > 0) {
            if ((los.equalsIgnoreCase("Stain Only") && status.equalsIgnoreCase("IHCQCCompleted")) ||
                    ((los.equalsIgnoreCase("Morphology") || los.equalsIgnoreCase("Consult")) && status.equalsIgnoreCase("IHCQCCompleted"))
                    || ((los.equalsIgnoreCase("Global Manual") || los.equalsIgnoreCase("Global Image")
                    || los.equalsIgnoreCase("Global")) && status.equalsIgnoreCase("QCCompleted"))) {  // status.equalsIgnoreCase("StainCompleted")  || status.equalsIgnoreCase("QCStart") || move to path support status.equalsIgnoreCase("ImagingCompleted")  ||
                PropertyList plPath = new PropertyList();
                plPath.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                plPath.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
                plPath.setProperty("u_currentmovementstep", "PathSupport");
                plPath.setProperty("u_imagingdts", "n");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plPath);


//                String destinationDepartment = site + "-PathSupport";
                String destinationDepartment = site + "-Accessioning";
                if (!Util.validateDepartment(destinationDepartment, getQueryProcessor(), getTranslationProcessor()))
                    throw new SapphireException("Unable to route sample as department: " + destinationDepartment + " does not exist");
                plPath.clear();
                plPath.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                plPath.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleids);
                plPath.setProperty("u_currenttramstop", "Path Support COC");
                plPath.setProperty("custodialuserid", "(null)");
                plPath.setProperty("custodialdepartmentid", destinationDepartment);
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, plPath);

            } else if (/*(los.equalsIgnoreCase("Stain Only") && status.equalsIgnoreCase("IHCQCCompleted"))
                    || */((los.equalsIgnoreCase("Scope") || los.equalsIgnoreCase("Technical")) && status.equalsIgnoreCase("QCCompleted")))   //status.equalsIgnoreCase("StainCompleted")  || status.equalsIgnoreCase("QCStart") ||
            {
                PropertyList plLogistic = new PropertyList();
                plLogistic.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                plLogistic.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
                plLogistic.setProperty("u_currentmovementstep", "LogisticCOC");
                plLogistic.setProperty("u_imagingdts", "n");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plLogistic);


                String destinationDepartment = site + "-Accessioning";//"-Logistic";
                if (!Util.validateDepartment(destinationDepartment, getQueryProcessor(), getTranslationProcessor()))
                    throw new SapphireException("Unable to route sample as department: " + destinationDepartment + " does not exist");
                plLogistic.clear();
                plLogistic.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                plLogistic.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleids);
                plLogistic.setProperty("u_currenttramstop", "Logistics COC");
                plLogistic.setProperty("custodialuserid", "(null)");
                plLogistic.setProperty("custodialdepartmentid", destinationDepartment);
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, plLogistic);
            }
        }
    }

    /**
     * Description: This method is used for to set Homogeneous LOS
     *
     * @throws SapphireException
     */
    private PropertyList setHomogeneousLOS() throws SapphireException {
        PropertyList homogeneousLOS = new PropertyList();
        PropertyList plHomogeneousPolicy = getConfigurationProcessor().getPolicy(HOMOGENEOUSLOSPOLICYID, NODEID);
        if (plHomogeneousPolicy == null)
            throw new SapphireException("Homogeneous LOS policy is not define in System Admin-> Policy.");
        PropertyListCollection plclosmap = plHomogeneousPolicy.getCollection(POLICY_MAPPING);
        if (plclosmap != null) {
            for (int j = 0; j < plclosmap.size(); j++) {
                String propParentLOS = plclosmap.getPropertyList(j).getProperty(POLICY_PARENT_LOS);
                PropertyListCollection plChildLOS = plclosmap.getPropertyList(j).getCollection(POLICY_CHILD_LOS);
                if (plChildLOS != null) {
                    for (int k = 0; k < plChildLOS.size(); k++) {
                        String childlodis = plChildLOS.getPropertyList(k).getProperty(POLICY_CHILD_LOS_ID);
                        homogeneousLOS.setProperty(childlodis, propParentLOS);
                    }
                }
            }

        }
        return homogeneousLOS;
    }
}
