package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateStorageUnit;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.PrintLabel.PrintLabelSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.sql.SQLIntegrityConstraintViolationException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by mpandey on 10/24/2016.
 * Modified by surajit
 */
public class CreateNLoadElusionBatch extends BaseAction {
    private static final String CREATESTORAGEUNIT_MAXTIALLOWED_PROP = "maxtiallowed";
    private static final String CREATESTORAGEUNIT_PROPERTYTREEID_PROP = "propertytreeid";
    private static final String CREATESTORAGEUNIT_MOVEABLEFLAG_PROP = "moveableflag";
    private static final String CREATESTORAGEUNIT_NEWKEYID1_PROP = "newkeyid1";
    private static final String CREATESTORAGEUNIT_NODEID_PROP = "nodeid";
    private static final String CREATESTORAGEUNIT_SIZE_PROP = "size";
    private static final String CREATESTORAGEUNIT_RETURN_PROP = "storageunitid";
    private static final String LV_BOX_SDC = "LV_Box";
    private static final String BOXTYPE_PROP = "boxtype";
    private static final String BOXSTATUS_PROP = "boxstatus";

    private static final int MAX_SAMPLE_LOAD = 9;// MAx sample is 10 , but 1
    // space reserve for control

    private static final String COLS_TO_COPY = "u_extractionid;sampletypeid;u_sampleinformation;u_accessionid";

    private String boxId = "";
    private String CONTROL_SAMPLE = "";
    private String batchName = "";
    private String extractiontype = "";
    private static final String SAMPLE_TYPE = "Tissue";
    private boolean duplicateCtrlCrtFlg = false;
    private boolean ifManualExtractionFlag = false;

    public void processAction(PropertyList properties) throws SapphireException {

        String fromtramstop = properties.getProperty("fromtramstop", "");
        String extractionbatchtype = properties.getProperty("type", "FFPE");

        try {
            String batchid = "";
            String vempmsg = "";

            if (properties == null) {
                throw new SapphireException("Properties is obtained as null");
            }
            getBatchPrefixDeatils();
            DataSet dsInput = validateInput(properties);
            extractiontype = getExtractionType(properties);
            ArrayList<DataSet> listChunkData = prepareLoadingChunk(dsInput);

            DataSet dsBatch = new DataSet();
            dsBatch.addColumn("batchid", DataSet.STRING);
            String newBatch = "";
            for (DataSet dsEachChunk : listChunkData) {

                newBatch = processProtocolRun(dsEachChunk, fromtramstop, extractionbatchtype);
                if (!Util.isNull(newBatch)) {
                    if (!ifManualExtractionFlag) {
                        vempmsg = viewExtractionMap(newBatch, boxId, extractiontype);// todo calling
                    } else {
                        String manualextractiontype = "Manual";
                        vempmsg = viewExtractionMap(newBatch, boxId, manualextractiontype);// todo calling
                    }
                    // in loop
                    // for
                    // multiple
                    // batches.
                    int rowid = dsBatch.addRow();
                    dsBatch.setValue(rowid, "batchid", newBatch);
                }
                labelPrintControl(properties);
            }
            if ("quantification".equalsIgnoreCase(fromtramstop)) {
                batchid = newBatch;
            } else {
                batchid = dsBatch.getColumnValues("batchid", ";");
            }
            //RELEASE 1.6.1
            //TODO AUTO POPULATED VOLUME FOR TUBE(S)
            updateSampleVolume(batchid);
            if (batchid.length() > 0) {
                properties.setProperty("batchid", batchid);
                properties.setProperty("url", vempmsg);
            }
            // labelPrintControl(properties);
            labelPrint(properties);
        } catch (Exception exp) {
            throw new SapphireException(exp.getMessage());
        }
        //throw new SapphireException("test");
    }

    /**
     * @param batchid
     * @throws SapphireException
     * @Desc: Used to update sample volume for the batch sample (RELEASE 1.6.1)
     */
    private void updateSampleVolume(String batchid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.GET_TUBE_BY_BATCHID, StringUtil.replaceAll(batchid, ";", "','"));
        DataSet dsBatchInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchInfo.size() > 0) {
            PropertyList proptag = new PropertyList();
            proptag.setProperty(EditSDIDetail.PROPERTY_SDCID, "NGBatch");
            proptag.setProperty(EditSDIDetail.PROPERTY_KEYID1, batchid);
            proptag.setProperty("sampleid", dsBatchInfo.getColumnValues("sampleid", ";"));
            //proptag.setProperty("samplevolmn", dsBatchInfo.getColumnValues("elutionvolume", ";"));
            proptag.setProperty("samplevolmn", dsBatchInfo.getColumnValues("extractionvolume", ";"));
            //proptag.setProperty("samplevolmn", StringUtil.repeat("100", dsBatchInfo.size(), ";"));
            proptag.setProperty(EditSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            proptag.setProperty("tagid", "(null)");
            proptag.setProperty("rulebypass", "Y");
            try {
                getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, proptag);
            } catch (SapphireException se) {
                throw new SapphireException("Unable to update COBAS specimen volume." + se.getMessage());
            }
        }
    }

    private void labelPrintControl(PropertyList properties) throws SapphireException {
        String type = properties.getProperty("type", "");
        if (!Util.isNull(CONTROL_SAMPLE)) {
            /*  Code modified to handle 'Protein Extraction Type' Label.
                Earlier Elution tube and NSC label for Protein Extraction were printed in different printers.
             */
            //String extractionType = CONTROL_SAMPLE.substring(0, CONTROL_SAMPLE.indexOf("-"));
            String extractionType = extractiontype;
            PropertyList props = new PropertyList();
            props.setProperty(PrintLabel.SDCID_PROP, "LV_ReagentLot");
            props.setProperty(PrintLabel.KEYID1_PROP, CONTROL_SAMPLE);
            props.setProperty(PrintLabel.EXTRACTION_TYPE, extractionType);
            props.setProperty("labelmethodid", "NSCLabel");
            String copies = validateCopiesForLabel(properties);
            props.setProperty(PrintLabel.COPIES, copies);
            /*if ("NONFFPE".equalsIgnoreCase(type)) {
                props.setProperty(PrintLabel.COPIES, "3");
            } else {
                //props.setProperty(PrintLabel.COPIES, "1");
                props.setProperty(PrintLabel.COPIES, "2"); ////For FFPE Elution tube 2 labels would be printed. (US# 5179, 25-Oct-2018, Release 1.6.1)
            }*/
            try {
                getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
            } catch (SapphireException e) {
                String errMsg = getTranslationProcessor().translate("Unable To Print Label");
                errMsg += "\nError Detail:" + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
        }
    }

    private void labelPrint(PropertyList properties) throws SapphireException {
        String extTube = properties.getProperty("exttube", "");
        String type = properties.getProperty("type", "");
        DataSet dstype = new DataSet();
        dstype.addColumn("sampleid", DataSet.STRING);
        dstype.addColumn("copies", DataSet.STRING);
        dstype.addColumn("sampletype", DataSet.STRING);
        dstype.addColumn("extractiontype", DataSet.STRING);
        /*String sqlElTube = "select distinct s.s_sampleid,s.sampletypeid,stm.extractiontype from s_sample s,u_sampletestcodemap stm "
                + "where s.s_sampleid=stm.s_sampleid and stm.methodology='Molecular' and s.s_sampleid in('"
                + StringUtil.replaceAll(extTube, ";", "','") + "')"; */

        String sqlElTube = Util.parseMessage(PrintLabelSql.GET_Molecular_ElutionTube, StringUtil.replaceAll(extTube, ";", "','"));

        DataSet dsElTube = getQueryProcessor().getSqlDataSet(sqlElTube);
        if (dsElTube == null) {
            String errMsg = getTranslationProcessor()
                    .translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sqlElTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsElTube.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample Type not found.");
            errMsg += "\nQuery returns zero rows:" + sqlElTube;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String copies = validateCopiesForLabel(properties);
        int incr = 0;
        for (int i = 0; i < dsElTube.size(); i++) {
            incr = dstype.addRow();
            String sample = dsElTube.getValue(i, "s_sampleid", "");
            if (Util.isNull(sample)) {
                String errMsg = getTranslationProcessor().translate("Sample id not found.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            String sampletype = dsElTube.getValue(i, "sampletypeid", "");
            if (Util.isNull(sampletype)) {
                String errMsg = getTranslationProcessor().translate("Sample type not found for sample:" + sample);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            String extractiontype = dsElTube.getValue(i, "extractiontype", "");
            if (Util.isNull(extractiontype)) {
                String errMsg = getTranslationProcessor().translate("Extraction type not found for sample:" + sample);
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
            }
            dstype.setValue(incr, "sampleid", sample);
            dstype.setValue(incr, "sampletype", sampletype);
            // if (SAMPLE_TYPE.equalsIgnoreCase(sampletype)) {
            // Privious logic was is sample type is Tissue it will print 1 copy
            // and for other 3 copy but current logic by Lito if elution tube is
            // create from NON FFPE
            // it will print 3 copy and for creation batch in Extraction it will
            // print 1 copy

            // if (SAMPLE_TYPE.equalsIgnoreCase(sampletype)) {
            //For FFPE Elution tube 2 labels would be generated. (US# 5179, 25-Oct-2018, Release 1.6.1)
            /*if ("NONFFPE".equalsIgnoreCase(type)) {
                dstype.setValue(incr, "copies", "3");
            } else {
                dstype.setValue(incr, "copies", "2");
                //dstype.setValue(incr, "copies", "1");//TODO 1.6.1 COPIES WILL BE 2
            }*/
            dstype.setValue(incr, "copies", copies);
            dstype.setValue(incr, "extractiontype", extractiontype);
        }
        //String copies=validateCopiesForLabel(properties);
        HashMap hmCopies = new HashMap();
        hmCopies.put("copies", copies);
        DataSet dsCopy = dstype.getFilteredDataSet(hmCopies);
        if (dsCopy.size() > 0) {
            forCallPrintlabel(dsCopy, copies);
        }
        /*
        HashMap hm = new HashMap();
        //hm.put("copies", "1");//TODO 1.6.1 COPIES WILL BE 2
        hm.put("copies", "2");
        DataSet dsCopy1 = dstype.getFilteredDataSet(hm);
        hm.clear();
        hm.put("copies", "3");
        DataSet dsCopy3 = dstype.getFilteredDataSet(hm);
        if (dsCopy1.size() > 0) {
            //String copy = "1";TODO 1.6.1 COPIES WILL BE 2
            String copy = "2";
            forCallPrintlabel(dsCopy1, copy);
        }
        if (dsCopy3.size() > 0) {
            String copy = "3";
            forCallPrintlabel(dsCopy3, copy);
        }
        String copies=validateCopiesForLabel(properties);
        dstype.setValue(incr,"copies",copies);
        forCallPrintlabel(dstype, copies); */
    }

    /**
     * Description :This method is used to find out the number of label copies to be printed based on department.
     */
    private String validateCopiesForLabel(PropertyList props) throws SapphireException {
        String depart = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String type = props.getProperty("type", "");

        if (!"NONFFPE".equalsIgnoreCase(type)) {
            type = "FFPE";
        }

        String sqlNoOfCopies = Util.parseMessage(PrintLabelSql.GET_NoOfElutionTubeCopies, depart, type);
        DataSet dsSqlNoOfCopies = getQueryProcessor().getSqlDataSet(sqlNoOfCopies);
        if (dsSqlNoOfCopies == null || dsSqlNoOfCopies.size() > 1) {
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Label Copies not defined properly.");
        }
        String copies = dsSqlNoOfCopies.getColumnValues("noofcopies", ";");
        return copies;
    }

    /**
     * Description :This method is for calling PrintLabel action based on print
     * copy.
     *
     * @param dsCopy
     * @param copy
     * @throws SapphireException
     */
    private void forCallPrintlabel(DataSet dsCopy, String copy) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, dsCopy.getColumnValues("sampleid", ";"));
        props.setProperty(PrintLabel.EXTRACTION_TYPE,
                Util.getUniqueList(dsCopy.getColumnValues("extractiontype", ";"), ";", true));
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Molecular");
        props.setProperty(PrintLabel.TRAMSTOP_PROP, "ExtractionBatch");
        props.setProperty(PrintLabel.TRAMLINE_PROP, "Extraction");
        props.setProperty(PrintLabel.COPIES, copy);
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    /**
     * @param newBatch
     * @param boxId
     * @return
     * @throws SapphireException
     */
    private String viewExtractionMap(String newBatch, String boxId, String extractiontype) throws SapphireException {
        //TODO WILL OPEN IF NOT CALL THURU TODOLIST
        /*PropertyList prop = new PropertyList();
        prop.setProperty("batchid", newBatch);
        prop.setProperty("boxid", boxId);
        prop.setProperty("batchtypename", extractiontype);
        try {
            getActionProcessor().processAction("ViewExtractionMap", "1", prop);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed.ViewExtractionMap.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }*/
        PropertyList prop = new PropertyList();
        prop.setProperty("batchid", newBatch);
        prop.setProperty("boxid", boxId);
        prop.setProperty("batchtypename", extractiontype);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "ViewExtractionMap");
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);

        return prop.getProperty("msg");
    }

    private DataSet validateInput(PropertyList properties) throws SapphireException {
        String extTube = properties.getProperty("exttube", "");
        String volume = properties.getProperty("volume", "");
        String units = properties.getProperty("units", "");
        String comments = properties.getProperty("comments", "");// TODO ask
        // Lito
        // where to
        // update
        // this
        // comments
        String reagent = properties.getProperty("reagent", ""); // TODO Validate
        // reagent lot
        // existance
        String instruments = properties.getProperty("instrument", "");// TODO
        // validate
        // instrument
        // id

        if (Util.isNull(extTube)) {
            String errMsg = "Please scan some extraction tube(s) to create a batch.";
            throw new SapphireException(errMsg);
        }

        int totalItemsScanned = StringUtil.split(extTube, ";").length;
        if (Util.isNull(volume)) {
            volume = StringUtil.repeat(volume, totalItemsScanned, ";");
        }
        if (Util.isNull(units)) {
            units = StringUtil.repeat(units, totalItemsScanned, ";");
        }
        if (Util.isNull(comments)) {
            comments = StringUtil.repeat(comments, totalItemsScanned, ";");
        }

        DataSet dsInput = new DataSet();
        dsInput.addColumnValues("extractiontube", DataSet.STRING, extTube, ";", "");
        dsInput.addColumnValues("volume", DataSet.STRING, volume, ";", "");
        dsInput.addColumnValues("units", DataSet.STRING, units, ";", "");
        dsInput.addColumnValues("comments", DataSet.STRING, comments, ";", "");
        dsInput.addColumnValues("reagent", DataSet.STRING, StringUtil.repeat(reagent, totalItemsScanned, ";"), ";", "");
        dsInput.addColumnValues("instrument", DataSet.STRING, StringUtil.repeat(instruments, totalItemsScanned, ";"),
                ";", "");

        return dsInput;

    }

    /**
     * This function is use to create small chunk of extraction tubes based on
     * extraction type.
     *
     * @param dsInput
     * @return
     * @throws SapphireException
     */
    private ArrayList prepareLoadingChunk(DataSet dsInput) throws SapphireException {
        int chunkSize = getMaxChunkSize();

        // chunkSize = MAX_SAMPLE_LOAD; // 1 reserved for control sample

        int fromRow = 0;
        int toRow = chunkSize;
        int lastRow = dsInput.getRowCount();
        if (toRow >= lastRow) {
            toRow = lastRow;
        }

        ArrayList<DataSet> listChunkDataSet = null;

        do {

            String exttubeInput = dsInput.getColumnValues("extractiontube", fromRow, toRow, ";");
            String volInput = dsInput.getColumnValues("volume", fromRow, toRow, ";");
            String unitInput = dsInput.getColumnValues("units", fromRow, toRow, ";");
            String commentInput = dsInput.getColumnValues("comments", fromRow, toRow, ";");
            String reagentInput = dsInput.getColumnValues("reagent", fromRow, toRow, ";");
            String instrumentInput = dsInput.getColumnValues("instrument", fromRow, toRow, ";");

            DataSet dsChunk = new DataSet();
            dsChunk.addColumnValues("extractiontube", DataSet.STRING, exttubeInput, ";", "");
            dsChunk.addColumnValues("volume", DataSet.STRING, volInput, ";", "");
            dsChunk.addColumnValues("units", DataSet.STRING, unitInput, ";", "");
            dsChunk.addColumnValues("comments", DataSet.STRING, commentInput, ";", "");
            dsChunk.addColumnValues("reagent", DataSet.STRING, reagentInput, ";", "");
            dsChunk.addColumnValues("instrument", DataSet.STRING, instrumentInput, ";", "");

            if (dsChunk.size() > 0) {
                if (listChunkDataSet == null) {
                    listChunkDataSet = new ArrayList<>();
                }
                listChunkDataSet.add(dsChunk);
            }

            // fromRow = toRow + 1;
            fromRow = toRow;
            toRow = (fromRow + chunkSize >= lastRow) ? (lastRow) : (fromRow + chunkSize);
        } while (fromRow < lastRow);

        return listChunkDataSet;
    }

    /**
     * This function is use get the maximum chunk size based on extraction type.
     *
     * @return
     */
    private int getMaxChunkSize() {
        int chunckSize = 0;
        if ((extractiontype.equalsIgnoreCase("PROTEIN") && !ifManualExtractionFlag)
                || (extractiontype.equalsIgnoreCase("Manual") && !ifManualExtractionFlag)) {
            chunckSize = 29; // 1 reserved for control sample
        } else if ((extractiontype.equalsIgnoreCase("TNA") && !ifManualExtractionFlag)
                || (extractiontype.equalsIgnoreCase("Plasma") && !ifManualExtractionFlag)) {
            chunckSize = 29; // 1 reserved for control sample
            //chunckSize = 23; // 1 reserved for control sample
        } else if (ifManualExtractionFlag) {
            chunckSize = 29;
        } else {
            //chunckSize = 11; // 1 reserved for control sample
            chunckSize = 29; // 1 reserved for control sample
        }
        //chunckSize = 29;
        return chunckSize;
    }

    /**
     * This Function is use to drive the flow of execution based on extraction
     * type.
     *
     * @param dsChunk
     * @return
     * @throws SapphireException
     */
    private String processProtocolRun(DataSet dsChunk, String fromtramstop, String extractionbatchtype) throws SapphireException {

        String extTube = dsChunk.getColumnValues("extractiontube", ";");
        String vol = dsChunk.getColumnValues("volume", ";");
        String units = dsChunk.getColumnValues("units", ";");
        String comments = dsChunk.getColumnValues("comments", ";");
        String reagent = Util.getUniqueList(dsChunk.getColumnValues("reagent", ";"), ";", true);
        String instrument = Util.getUniqueList(dsChunk.getColumnValues("instrument", ";"), ";", true);

        // 1. Create batch name...
        // String extractiontype = validateInputProp(extTube);
        batchName = getBatchName(extractiontype, fromtramstop);

        // Update Extraction comments
        if (!Util.isNull(comments)) {
            updateComments(extTube, comments);
        }

        // 2. Create elution tube(s)
        if (!"quantification".equalsIgnoreCase(fromtramstop)) {
            PropertyList pl = new PropertyList();
            pl.setProperty("exttubeid", extTube);
            pl.setProperty("copies", "1");
            pl.setProperty("fromtramstop", fromtramstop);
            getActionProcessor().processAction("CrtElutionTube", "1", pl, false, false);
            String elTube = pl.getProperty("elTube", "");
            if (Util.isNull(elTube)) {
                throw new SapphireException("Failed to create Elution tube(s).");
            }
        }

        // 3. todo create label for Elution tube

        // 4. Batch & Plate creation
        if ("quantification".equalsIgnoreCase(fromtramstop)) {
            return crtQuantificationBatchAndAttchDtls(extTube, batchName, instrument, reagent, fromtramstop, extractiontype);
        } else {
            String boxStgid = crtBox(extractiontype);
            if (!Util.isNull(boxStgid)) {

                if ((extractiontype.equalsIgnoreCase("PROTEIN") && !ifManualExtractionFlag)
                        || (extractiontype.equalsIgnoreCase("Manual") && !ifManualExtractionFlag)
                        || (extractiontype.equalsIgnoreCase("TNA") && !ifManualExtractionFlag)
                        || (extractiontype.equalsIgnoreCase("Plasma") && !ifManualExtractionFlag)) {
                    manualTubeChkInBox(boxStgid, extTube, extractiontype, fromtramstop);
                } else if (ifManualExtractionFlag) {
                    manualTubeChkInBox(boxStgid, extTube, extractiontype, fromtramstop);
                } else {
                    //drnaTubeChkInBox(boxStgid, extTube, extractiontype,fromtramstop);
                    manualTubeChkInBox(boxStgid, extTube, extractiontype, fromtramstop);
                }

                if (!Util.isNull(CONTROL_SAMPLE)) {
                    extTube = extTube + ";" + CONTROL_SAMPLE;
                }

                return crtBatchAndAttchDtls(extTube, batchName, instrument, reagent, fromtramstop, extractiontype, extractionbatchtype);
            }
        }

        return "";

    }

    /**
     * This function is use to get the number of copies of child sample based on
     * sample type.
     *
     * @param extTube
     * @return
     * @throws SapphireException
     */
    private String getNumOfCopies(String extTube) throws SapphireException {
        String copies = "1";
        String sql = "select distinct sampletypeid from s_sample where s_sampleid in ('"
                + extTube.replaceAll(";", "','") + "')";
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact you Administrator.");
            throw new SapphireException(errMsg);
        }
        if (dsSample.size() > 1) {
            String errMsg = getTranslationProcessor().translate("Sample type must be same for all samples");
            throw new SapphireException(errMsg);
        }
        if (!dsSample.getValue(0, "sampletypeid").equalsIgnoreCase("Tissue"))
            copies = "3";
        return copies;
    }

    /**
     * This function is use to get the unique batch name .
     *
     * @param extractiontype
     * @return
     */
    private String getBatchName(String extractiontype, String fromtramstop) throws SapphireException {
        /**
         * GET EXTRACTION DESIGN FORMAT FROM POLICY FOR CREATE BATCH NAME BY
         * EXTRACTION
         */
        DataSet dsExtractionInfo = getExtractionPrefix(extractiontype);
        if (dsExtractionInfo == null || dsExtractionInfo.size() == 0) {
            throw new SapphireException("Batch format is not defined into the policy.");
        }
        String finalLatestBatchName = "";
        String extractiontypeArry[] = StringUtil.split(extractiontype, ";");
        for (int i = 0; i < extractiontypeArry.length; i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.clear();
            hm.put(POLICY_CHILD_EXTRACTION_TYPE, extractiontypeArry[i]);
            DataSet dsExtractionFilter = dsExtractionInfo.getFilteredDataSet(hm);
            String extractiontypeinfo = dsExtractionFilter.getValue(0, POLICY_CHILD_EXTRACTION_TYPE, "");
            String batchnameprefixinfo = dsExtractionFilter.getValue(0, POLICY_CHILD_BATCHNAME_PREFIX, "");
            String seperateoperatorinfo = dsExtractionFilter.getValue(0, POLICY_CHILD_SEPERATE_OPERATOR, "");

            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            String date = sdf.format(d);
            String MMDDYYYY = date.replaceAll("/", "");
            // String batchIDMatch = extractiontypeArry[i] + "-" + MMDDYYYY;
            String batchIDMatch = batchnameprefixinfo + seperateoperatorinfo + MMDDYYYY;
            String latestBatchName = batchIDMatch + seperateoperatorinfo + "A";
            String finaltail = "";
            // String sql_sample = "select max(batchname) batchname from
            // u_ngbatch where origin='Molecular' and batchname like '" +
            // batchIDMatch + "_%' ";
            // String sql_sample = "select batchname from u_ngbatch where
            // origin='Molecular' and batchname like '" + batchIDMatch + "-%'
            // order by createdt desc";
            String sql_sample = "";
            /*if ("quantification".equalsIgnoreCase(fromtramstop)) {
                sql_sample = "select batchname from u_ngbatch where batchname like '"
                        + batchIDMatch + seperateoperatorinfo + "%' and batchtype='Quantification' order by createdt desc";
            } else {
                sql_sample = "select batchname from u_ngbatch where batchname like '"
                        + batchIDMatch + seperateoperatorinfo + "%' and batchtype='Extraction' order by createdt desc";
            }*/
            sql_sample = "select batchname from u_ngbatch where batchname like '"
                    + batchIDMatch + seperateoperatorinfo + "%' and parentbatchid is null order by createdt desc";
            DataSet dsAccess = getQueryProcessor().getSqlDataSet(sql_sample);
            if (dsAccess.size() > 0 && dsAccess.getString(0, "batchname", "").length() > 0) {
                latestBatchName = dsAccess.getString(0, "batchname");

                String tail = latestBatchName.split(seperateoperatorinfo)[2];
                char c = tail.charAt(0);
                int tailacii = c;
                if (tail.length() == 1 && tailacii == 90) {
                    finaltail = "AA";
                } else if (tail.length() > 1) {
                    tailacii = tailacii + 1;
                    finaltail = String.valueOf((char) tailacii);
                    finaltail = finaltail + finaltail;
                } else {
                    int ascii = tailacii + 1;
                    char newc = (char) ascii;
                    finaltail = String.valueOf(newc);
                }
                String[] latestarr = latestBatchName.split(seperateoperatorinfo);
                latestBatchName = latestarr[0] + seperateoperatorinfo + latestarr[1] + seperateoperatorinfo + finaltail;
            }
            finalLatestBatchName += ";" + latestBatchName;

        }
        /*
         * for (int i = 0; i < extractiontypeArry.length; i++) { Date d = new
		 * Date(); SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		 * String date = sdf.format(d); String MMDDYYYY = date.replaceAll("/",
		 * ""); String batchIDMatch = extractiontypeArry[i] + "-" + MMDDYYYY;
		 * String latestBatchName = batchIDMatch + "-A"; String finaltail = "";
		 * // String sql_sample =
		 * "select max(batchname) batchname  from u_ngbatch where origin='Molecular' and  batchname like '"
		 * + batchIDMatch + "_%' "; String sql_sample =
		 * "select  batchname  from u_ngbatch where origin='Molecular' and  batchname like '"
		 * + batchIDMatch + "-%' order by createdt desc"; DataSet dsAccess =
		 * getQueryProcessor().getSqlDataSet(sql_sample); if (dsAccess.size() >
		 * 0 && dsAccess.getString(0, "batchname", "").length() > 0) {
		 * latestBatchName = dsAccess.getString(0, "batchname");
		 * 
		 * String tail = latestBatchName.split("-")[2]; char c = tail.charAt(0);
		 * int tailacii = c; if (tail.length() == 1 && tailacii == 90) {
		 * finaltail = "AA"; } else if (tail.length() > 1) { tailacii = tailacii
		 * + 1; finaltail = String.valueOf((char) tailacii); finaltail =
		 * finaltail + finaltail; } else { int ascii = tailacii + 1; char newc =
		 * (char) ascii; finaltail = String.valueOf(newc); } String[] latestarr
		 * = latestBatchName.split("-"); latestBatchName = latestarr[0] + "-" +
		 * latestarr[1] + "-" + finaltail; } finalLatestBatchName += ";" +
		 * latestBatchName;
		 * 
		 * }
		 */
        if (Util.isNull(finalLatestBatchName)) {
            finalLatestBatchName = "";
        } else {
            finalLatestBatchName = finalLatestBatchName.substring(1);
        }

        return finalLatestBatchName;
    }

    /**
     * This function is use to check in dha/rna samples into box .
     *
     * @param boxStgId
     * @param elutionTube
     * @param extractiontype
     * @throws SapphireException
     */

    private void drnaTubeChkInBox(String boxStgId, String elutionTube, String extractiontype, String fromtramstop) throws SapphireException {
        if (!Util.isNull(boxStgId) && !Util.isNull(elutionTube)) {
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid = ?";
            DataSet dsStorage = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{boxStgId});
            if (dsStorage != null && dsStorage.size() > 0) {
                PropertyList plElLdPolicy = getConfigurationProcessor().getPolicy("EllutionTubeLoadingPolicy",
                        "custom");
                if (plElLdPolicy == null)
                    throw new SapphireException("Ellution tube loading policy is  not found in the system");
                PropertyListCollection plc = plElLdPolicy.getCollection("comb");
                if (plc == null || plc.size() == 0)
                    throw new SapphireException("EllutionTubeLoadingPolicy policy is not configured properly.");
                String elTubeArr[] = StringUtil.split(elutionTube, ";");
                if (elTubeArr != null && elTubeArr.length > 0) {
                    // String boxPosToLd = getBoxPosToLdDNA(plc,
                    // Integer.toString(elTubeArr.length));
                    String boxPosToLd = getBoxPosToLdDNA(plc, Integer.toString(elTubeArr.length + 1)); // 1
                    // for
                    // Control
                    if (!Util.isNull(boxPosToLd)) {
                        String boxPosArr[] = StringUtil.split(boxPosToLd, ";");
                        // if (boxPosArr.length != elTubeArr.length)
                        // throw new SapphireException("Number of box positions
                        // to be loaded for " + elTubeArr.length + " " +
                        // "ellution tube is not configured properly in the
                        // EllutionTubeLoadingPolicy policy");

                        DataSet result = new DataSet();
                        result.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
                        result.addColumn("currentstorageunitid", DataSet.STRING);
                        result.addColumn("boxposition", DataSet.STRING);
                        result.addColumn("iscontrol", DataSet.STRING);
                        HashMap<String, String> hmap = new HashMap<String, String>();
                        for (int i = 0; i < boxPosArr.length; i++) {
                            hmap.clear();
                            hmap.put("storageunitlabel", boxPosArr[i]);
                            DataSet dsStgFiltr = dsStorage.getFilteredDataSet(hmap);
                            if (dsStgFiltr != null && dsStgFiltr.size() > 0) {
                                int rowIndex = result.addRow();
                                String temStgId = dsStgFiltr.getValue(0, "storageunitid", "");
                                if (!Util.isNull(temStgId)) {
                                    if (i < elTubeArr.length) {
                                        result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, elTubeArr[i]);
                                        result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                        result.setValue(rowIndex, "boxposition", boxPosArr[i]);
                                        result.setValue(rowIndex, "iscontrol", "N");
                                    } else {
                                        result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, "");
                                        result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                        result.setValue(rowIndex, "boxposition", boxPosArr[i]);
                                        result.setValue(rowIndex, "iscontrol", "Y");
                                    }
                                }
                            }
                        }

                        hmap.clear();
                        hmap.put("iscontrol", "Y");
                        DataSet dsControl = result.getFilteredDataSet(hmap);
                        if (dsControl != null && dsControl.size() > 0) {
                            String controlSampleBoxPos = dsControl.getValue(0, "boxposition", "");
                            String temStgId = dsStorage.getValue(Integer.parseInt(controlSampleBoxPos) - 1,
                                    "storageunitid", "");
                            String temStgLblId = dsStorage.getValue(Integer.parseInt(controlSampleBoxPos) - 1,
                                    "storageunitlabel", "");
                            if (!Util.isNull(temStgId)) {

                                // Below block is added to avoid Unique Primry
                                // Key error when multiple user tries to create
                                // extraction batch simultaneously.
                                try {
                                    CONTROL_SAMPLE = crateControlSample(batchName, temStgLblId);
                                } catch (Exception exp) {
                                    if (duplicateCtrlCrtFlg) {
                                        batchName = getBatchName(extractiontype, fromtramstop);
                                        CONTROL_SAMPLE = "";
                                        drnaTubeChkInBox(boxStgId, elutionTube, extractiontype, fromtramstop);
                                        return;
                                    }
                                    throw new SapphireException(exp.getMessage());
                                }
                                // Ends here
                                // dsControl.setValue(0,
                                // EditTrackItem.PROPERTY_KEYID1,
                                // CONTROL_SAMPLE);
                                if (CONTROL_SAMPLE.length() > 0) {
                                    PropertyList pl = new PropertyList();
                                    pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                                    pl.setProperty(EditTrackItem.PROPERTY_KEYID1, CONTROL_SAMPLE);
                                    pl.setProperty("currentstorageunitid", StringUtil.repeat(temStgId,
                                            StringUtil.split(CONTROL_SAMPLE, ";").length, ";"));
                                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                                }
                            }
                        }

                        if (result != null && result.size() > 0) {
                            hmap.clear();
                            hmap.put("iscontrol", "N");
                            DataSet dsSample = result.getFilteredDataSet(hmap);
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1,
                                    dsSample.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                            pl.setProperty("currentstorageunitid",
                                    dsSample.getColumnValues("currentstorageunitid", ";"));
                            pl.setProperty("custodialuserid", "(null)");
                            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        }
                    }
                }
            }
        }
    }

    /**
     * This function is use to get the extrection type of input samples.
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String getExtractionType(PropertyList properties) throws SapphireException {
        String extTube = properties.getProperty("exttube", "");
        String extractiontype = properties.getProperty("manualextraction", "");
        String uniqueext = "";
        if (extractiontype.length() > 0) {
            //uniqueext = extractiontype;
            /***
             * TODO CHANGES FOR MANUAL EXTRACTION(12/01/18), AS BATCH NAME SHOULD BE DNA/RNA/PROTEIN BUT PLATE MAP WILL BE MANUAL.
             */
            ifManualExtractionFlag = true;
            String extidarr[] = StringUtil.split(extTube, ";");
            String sql = "select extractiontype from u_sampletestcodemap where s_sampleid in ('"
                    + extTube.replaceAll(";", "','") + "')";
            DataSet dsext = getQueryProcessor().getSqlDataSet(sql);
            if (dsext == null || dsext.size() == 0) {
                throw new SapphireException("Extraction type not found for samples");
            }
            uniqueext = properties.getProperty("extractiontype", "");
        } else {
            String extidarr[] = StringUtil.split(extTube, ";");
            String sql = "select extractiontype from u_sampletestcodemap where s_sampleid in ('"
                    + extTube.replaceAll(";", "','") + "')";
            DataSet dsext = getQueryProcessor().getSqlDataSet(sql);
            if (dsext == null || dsext.size() == 0) {
                throw new SapphireException("Extraction type not found for samples");
            }
            uniqueext = properties.getProperty("extractiontype", "");
        }

        return uniqueext;
    }

    /**
     * This function is use to create unsorted box.
     *
     * @param extractiontype
     * @return
     * @throws SapphireException
     */

    private String crtBox(String extractiontype) throws SapphireException {
        DataSet strgutprop = getStorageUnitProp(extractiontype);
        PropertyList prop = new PropertyList();
        prop.setProperty(AddSDI.PROPERTY_SDCID, LV_BOX_SDC);
        prop.setProperty(AddSDI.PROPERTY_COPIES, "1");
        // prop.setProperty(BOXTYPE_PROP, "Sorted");
        prop.setProperty(BOXTYPE_PROP, "Unsorted");
        prop.setProperty(BOXSTATUS_PROP, "Empty");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop);
        String newBoxId = prop.getProperty(AddSDI.RETURN_NEWKEYID1, "");
        boxId = newBoxId;
        prop.clear();

        DataSet trackItemDS = getQueryProcessor().getPreparedSqlDataSet(
                "select trackitemid from trackitem where linkkeyid1 = ?", new String[]{newBoxId});
        if (trackItemDS != null) {
            String tiIdBox = trackItemDS.getValue(0, "trackitemid", "");
            prop.clear();
            prop.setProperty(CreateStorageUnit.PROPERTY_LINKPROPNODEID, strgutprop.getValue(0, "linkpropnodeid"));
            prop.setProperty(CreateStorageUnit.PROPERTY_CREATESU, "Y");
            prop.setProperty(CreateStorageUnit.PROPERTY_LINKSDCID, LV_BOX_SDC);
            prop.setProperty(CREATESTORAGEUNIT_MAXTIALLOWED_PROP, "undefined;1");
            prop.setProperty(CREATESTORAGEUNIT_PROPERTYTREEID_PROP, "Grid;No Layout");
            prop.setProperty(CREATESTORAGEUNIT_MOVEABLEFLAG_PROP, "Y;N");
            prop.setProperty(CREATESTORAGEUNIT_NEWKEYID1_PROP, newBoxId);
            prop.setProperty(CREATESTORAGEUNIT_NODEID_PROP, strgutprop.getValue(0, "nodeid_prop"));
            prop.setProperty(CREATESTORAGEUNIT_SIZE_PROP, strgutprop.getValue(0, "size_prop"));
            getActionProcessor().processAction(CreateStorageUnit.ID, CreateStorageUnit.VERSIONID, prop);

            String stgUnitIdPlt = StringUtil.split(prop.getProperty(CREATESTORAGEUNIT_RETURN_PROP, ""), ";")[0];
            prop.clear();

            prop.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, tiIdBox);
            prop.setProperty("custodialdepartmentid",
                    getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

            return stgUnitIdPlt;
        }
        return "";
    }

    /**
     * This function is use to get property of storage unit .
     *
     * @param extractiontype
     * @return
     */
    private DataSet getStorageUnitProp(String extractiontype) {
        int rowIndex = 0;
        DataSet strgutprop = new DataSet();
        strgutprop.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
        strgutprop.addColumn("linkpropnodeid", DataSet.STRING);
        strgutprop.addColumn("nodeid_prop", DataSet.STRING);
        strgutprop.addColumn("size_prop", DataSet.STRING);
        if ((extractiontype.equalsIgnoreCase("Manual") && !ifManualExtractionFlag)
                || (extractiontype.equalsIgnoreCase("PROTEIN") && !ifManualExtractionFlag)) {
            strgutprop.addRow();
            strgutprop.setValue(rowIndex, "linkpropnodeid", "Grid|Box-1X30");
            strgutprop.setValue(rowIndex, "nodeid_prop", "Box-1X30;BoxPos");
            strgutprop.setValue(rowIndex, "size_prop", "1;30");
        } else if ((extractiontype.equalsIgnoreCase("TNA") && !ifManualExtractionFlag)
                || (extractiontype.equalsIgnoreCase("Plasma") && !ifManualExtractionFlag)) {
            /*strgutprop.addRow();
            strgutprop.setValue(rowIndex, "linkpropnodeid", "Grid|Box-3X8");
            strgutprop.setValue(rowIndex, "nodeid_prop", "Box-3X8;BoxPos");
            strgutprop.setValue(rowIndex, "size_prop", "1;24");*/
            strgutprop.addRow();
            strgutprop.setValue(rowIndex, "linkpropnodeid", "Grid|Box-1X30");
            strgutprop.setValue(rowIndex, "nodeid_prop", "Box-1X30;BoxPos");
            strgutprop.setValue(rowIndex, "size_prop", "1;30");
        } else if (ifManualExtractionFlag) {
            strgutprop.addRow();
            strgutprop.setValue(rowIndex, "linkpropnodeid", "Grid|Box-1X30");
            strgutprop.setValue(rowIndex, "nodeid_prop", "Box-1X30;BoxPos");
            strgutprop.setValue(rowIndex, "size_prop", "1;30");
        } else {
            /*strgutprop.addRow();
            strgutprop.setValue(rowIndex, "linkpropnodeid", "Grid|Box-6x2");
            strgutprop.setValue(rowIndex, "nodeid_prop", "Box-6x2;BoxPos");
            strgutprop.setValue(rowIndex, "size_prop", "1;12");*/
            strgutprop.addRow();
            strgutprop.setValue(rowIndex, "linkpropnodeid", "Grid|Box-1X30");
            strgutprop.setValue(rowIndex, "nodeid_prop", "Box-1X30;BoxPos");
            strgutprop.setValue(rowIndex, "size_prop", "1;30");
        }
        return strgutprop;
    }

    /**
     * This function is use to check in samples into box if extraction type is
     * manual.
     *
     * @param boxStgId
     * @param elutionTube
     * @param extractiontype
     * @throws SapphireException
     */
    private void manualTubeChkInBox(String boxStgId, String elutionTube, String extractiontype, String fromtramstop) throws SapphireException {
        if (!Util.isNull(boxStgId) && !Util.isNull(elutionTube)) {
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid = ?";
            DataSet dsStorage = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{boxStgId});
            if (dsStorage != null && dsStorage.size() > 0) {
                String elTubeArr[] = StringUtil.split(elutionTube, ";");
                if (elTubeArr != null && elTubeArr.length > 0) {
                    String boxPosToLd = getBoxPosToLdManual(extractiontype);
                    if (!Util.isNull(boxPosToLd)) {
                        DataSet dsBoxsPos = new DataSet();
                        dsBoxsPos.addColumn("boxposid", DataSet.STRING);
                        dsBoxsPos.addColumn("boxfor", DataSet.STRING);
                        dsBoxsPos.addColumn("isfilled", DataSet.STRING);
                        String boxPosArr[] = StringUtil.split(boxPosToLd, ";");
                        for (int i = 0; i < boxPosArr.length; i++) {
                            int rowID = dsBoxsPos.addRow();
                            if (i % 2 == 1) {
                                dsBoxsPos.setValue(rowID, "boxposid", boxPosArr[i]);
                                dsBoxsPos.setValue(rowID, "boxfor", "CN");
                                dsBoxsPos.setValue(rowID, "isfilled", "N");
                            } else {
                                dsBoxsPos.setValue(rowID, "boxposid", boxPosArr[i]);
                                dsBoxsPos.setValue(rowID, "boxfor", "EU");
                                dsBoxsPos.setValue(rowID, "isfilled", "N");
                            }

                        }
                        DataSet result = new DataSet();
                        result.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
                        result.addColumn("currentstorageunitid", DataSet.STRING);
                        for (int i = 0; i < elTubeArr.length; i++) {
                            dsBoxsPos.setValue(i, "isfilled", "Y");
                            int rowIndex = result.addRow();
                            String temStgId = dsStorage.getValue(Integer.parseInt(boxPosArr[i]) - 1, "storageunitid", "");
                            if (!Util.isNull(temStgId)) {
                                result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, elTubeArr[i]);
                                result.setValue(rowIndex, "currentstorageunitid", temStgId);
                            }
                        }
                        //String maxBoxPos = getMaxBoxPos(boxPosToLd, elTubeArr);
                        String maxBoxPos = getMaxBoxPosForManual(boxPosToLd, elTubeArr, dsBoxsPos);
                        if (maxBoxPos.length() > 0) {
                            // int rowIndex = result.addRow();
                            String temStgId = dsStorage.getValue(Integer.parseInt(maxBoxPos), "storageunitid", "");
                            String temStgLblId = dsStorage.getValue(Integer.parseInt(maxBoxPos), "storageunitlabel",
                                    "");
                            if (!Util.isNull(temStgId)) {

                                // Below block is added to avoid Unique Primry
                                // Key error when multiple user tries to create
                                // extraction batch simultaneously.
                                try {
                                    CONTROL_SAMPLE = crateControlSample(batchName, temStgLblId);
                                } catch (Exception exp) {
                                    if (duplicateCtrlCrtFlg) {
                                        batchName = getBatchName(extractiontype, fromtramstop);
                                        CONTROL_SAMPLE = "";
                                        manualTubeChkInBox(boxStgId, elutionTube, extractiontype, fromtramstop);
                                        return;
                                    }
                                    throw new SapphireException(exp.getMessage());
                                }
                                // Block ends here
                                // result.setValue(rowIndex,
                                // EditTrackItem.PROPERTY_KEYID1,
                                // CONTROL_SAMPLE);
                                // result.setValue(rowIndex,
                                // "currentstorageunitid", temStgId);
                                if (CONTROL_SAMPLE.length() > 0) {
                                    PropertyList pl = new PropertyList();
                                    pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                                    pl.setProperty(EditTrackItem.PROPERTY_KEYID1, CONTROL_SAMPLE);
                                    pl.setProperty("currentstorageunitid", temStgId);
                                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                                }
                            }
                        }
                        if (result != null && result.size() > 0) {
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1,
                                    result.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                            pl.setProperty("currentstorageunitid", result.getColumnValues("currentstorageunitid", ";"));
                            pl.setProperty("custodialuserid", "(null)");
                            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        }
                    }
                }
            }
        }

    }

    /**
     * This function is use to get the top most position of box.
     *
     * @param boxPosToLd
     * @param elTubeArr
     * @return
     */
    private String getMaxBoxPos(String boxPosToLd, String[] elTubeArr) {
        String[] posarr = boxPosToLd.split(";");
        int length = posarr.length;
        String maxpos = "";
        if (length > 0) {
            for (int i = 0; i < elTubeArr.length; i++) {
                if (posarr[i].compareToIgnoreCase(maxpos) > 0)
                    maxpos = posarr[i];
            }
        }
        return maxpos;
    }

    private String getMaxBoxPosForManual(String boxPosToLd, String[] elTubeArr, DataSet dsBoxsPos) {
        String maxpos = "";
        HashMap hm = new HashMap();
        hm.put("isfilled", "N");
        hm.put("boxfor", "CN");
        DataSet dsFilter = dsBoxsPos.getFilteredDataSet(hm);
        if (dsFilter.size() > 0) {
            maxpos = "" + (Integer.parseInt(dsFilter.getValue(0, "boxposid", "")) - 1);
        }

        /*String[] posarr = boxPosToLd.split(";");
        int length = posarr.length;
        String maxpos = "";
        if (length > 0) {
            for (int i = 0; i < elTubeArr.length; i++) {
                if (posarr[i].compareToIgnoreCase(maxpos) > 0)
                    maxpos = posarr[i];
            }
        }*/
        return maxpos;
    }

    /**
     * This function is use to create control sample.
     *
     * @param batchName
     * @param temStgLblId
     * @return
     * @throws SapphireException
     */
    private String crateControlSample(String batchName, String temStgLblId) throws SapphireException {
        /*
         * PropertyList props = new PropertyList();
		 * props.setProperty(AddSDI.PROPERTY_SDCID, "Sample"); //
		 * props.setProperty("sampletypeid", "QC");
		 * props.setProperty("sampletypeid", "NSC");//todo
		 * props.setProperty("storagestatus", "In Circulation");
		 * props.setProperty("u_extractionid", batchName + "_" + temStgLblId);
		 * getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID,
		 * props); String newkeyid = props.getProperty("newkeyid1"); return
		 * newkeyid;
		 */
        String newBatchName = "";
        String batchNameArry[] = StringUtil.split(batchName, ";");
        for (int i = 0; i < batchNameArry.length; i++) {
            newBatchName += ";" + batchNameArry[i] + "-" + temStgLblId;
        }
        newBatchName = newBatchName.substring(1);

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "LV_ReagentLot");
        props.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY, "Y");// todo
        props.setProperty(AddSDI.PROPERTY_KEYID1, newBatchName);
        // props.setProperty("reagenttypeid", "NSC");//todo
        props.setProperty("reagenttypeid", StringUtil.repeat("NSC", batchNameArry.length, ";"));// todo
        // props.setProperty("reagenttypeversionid", "1");//todo
        props.setProperty("reagenttypeversionid", StringUtil.repeat("1", batchNameArry.length, ";"));// todo
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (SapphireException exp) {
            if (exp.getMessage().indexOf("ORA-00001") >= 0)
                duplicateCtrlCrtFlg = true;
            throw new SapphireException(exp.getMessage());
        }
        String newkeyid = props.getProperty("newkeyid1");
        props.clear();
        props.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
        props.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY, "Y");
        props.setProperty("reagentlotid", newkeyid);
        props.setProperty("samplestatus", "Reagent Quality");
        props.setProperty(AddSDI.PROPERTY_KEYID1, newkeyid);
        props.setProperty("u_extractionid", newkeyid);
        //TODO make quality sample here
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (SapphireException exp) {
            throw new SapphireException(exp.getMessage());
        }
        return newkeyid;
    }

    /**
     * This function is use to get the loading pattern for manual,plasma and tna
     * type of extraction .
     *
     * @param extractiontype
     * @return
     * @throws SapphireException
     */
    private String getBoxPosToLdManual(String extractiontype) throws SapphireException {
        String boxPosToLd = "";
        if ((extractiontype.equalsIgnoreCase("Manual") && !ifManualExtractionFlag)
                || (extractiontype.equalsIgnoreCase("PROTEIN") && !ifManualExtractionFlag)) {
            boxPosToLd = "1;16;2;17;3;18;4;19;5;20;6;21;7;22;8;23;9;24;10;25;11;26;12;27;13;28;14;29;15;30";
        } else if ((extractiontype.equalsIgnoreCase("TNA") && !ifManualExtractionFlag)
                || (extractiontype.equalsIgnoreCase("Plasma") && !ifManualExtractionFlag)) {
            //boxPosToLd = "1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;18;19;20;21;22;23;24";
            boxPosToLd = "1;16;2;17;3;18;4;19;5;20;6;21;7;22;8;23;9;24;10;25;11;26;12;27;13;28;14;29;15;30";
        } else if (ifManualExtractionFlag) {
            boxPosToLd = "1;16;2;17;3;18;4;19;5;20;6;21;7;22;8;23;9;24;10;25;11;26;12;27;13;28;14;29;15;30";
        } else {
            boxPosToLd = "1;16;2;17;3;18;4;19;5;20;6;21;7;22;8;23;9;24;10;25;11;26;12;27;13;28;14;29;15;30";
        }

        return boxPosToLd;
    }

    /**
     * This function is use to create batch and attach details.
     *
     * @param elTubes
     * @param batchname
     * @param instrumentId
     * @param reagentLotId
     * @return
     * @throws SapphireException
     */
    private String crtBatchAndAttchDtls(String elTubes, String batchname, String instrumentId, String reagentLotId,
                                        String fromtramstop, String extractiontype, String extractionbatchtype) throws SapphireException {
        String batchId = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        //pl.setProperty("origin", "Molecular");
        pl.setProperty("batchname", batchname);
        pl.setProperty("extractiontype", extractiontype);

        if ("quantification".equalsIgnoreCase(fromtramstop)) {
            pl.setProperty("batchtype", "Quantification");
            pl.setProperty("origin", "Molecular");
        } else {
            pl.setProperty("extractionbatchtype", extractionbatchtype);
            pl.setProperty("batchtype", "Extraction");
            pl.setProperty("origin", "Molecular");
        }
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        batchId = pl.getProperty(AddSDI.RETURN_NEWKEYID1, "");

        if (!Util.isNull(batchId) && !Util.isNull(elTubes)) {
            pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            pl.setProperty("sampleid", elTubes);
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);

            pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
            pl.setProperty("plateid", boxId);
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);

            if (!Util.isNull(instrumentId)) {
                pl.clear();
                pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
                pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");
                pl.setProperty("instrumentid", instrumentId);
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
            }
            if (!Util.isNull(reagentLotId)) {
                pl.clear();
                pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
                pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");
                pl.setProperty("reagentid", reagentLotId);
                if ("Extraction".equalsIgnoreCase(fromtramstop)) {
                    pl.setProperty("reagenttype", "Extraction");
                }
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
            }
        }
        return batchId;
    }

    private String crtQuantificationBatchAndAttchDtls(String elTubes, String batchname, String instrumentId, String reagentLotId, String fromtramstop, String extractiontype) throws SapphireException {
        String batchId = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "" + StringUtil.split(batchname, ";").length);
        //pl.setProperty("origin", "Molecular");
        pl.setProperty("batchname", batchname);
        pl.setProperty("extractiontype", extractiontype);
        pl.setProperty("batchtype", "Quantification");
        pl.setProperty("origin", "Molecular");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        batchId = pl.getProperty(AddSDI.RETURN_NEWKEYID1, "");
        String sql = "select extractiontype, s_sampleid from u_sampletestcodemap where s_sampleid in('" + StringUtil.replaceAll(elTubes, ";", "','") + "')";
        DataSet dsElltnTube = getQueryProcessor().getSqlDataSet(sql);
        sql = "select u_ngbatchid,extractiontype from u_ngbatch where u_ngbatchid in('" + StringUtil.replaceAll(batchId, ";", "','") + "')";
        DataSet dsBatchDetails = getQueryProcessor().getSqlDataSet(sql);
        if (dsBatchDetails.size() > 0 && dsElltnTube.size() > 0) {
            HashMap hm = new HashMap();
            for (int i = 0; i < dsBatchDetails.size(); i++) {
                hm.clear();
                hm.put("extractiontype", dsBatchDetails.getValue(i, "extractiontype", ""));
                DataSet dsElutnFilter = dsElltnTube.getFilteredDataSet(hm);
                if (dsElutnFilter.size() > 0) {
                    pl.clear();
                    pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, dsBatchDetails.getValue(i, "u_ngbatchid", ""));
                    pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
                    pl.setProperty("sampleid", dsElutnFilter.getColumnValues("s_sampleid", ";"));
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);

                }
                if (!Util.isNull(instrumentId)) {
                    pl.clear();
                    pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, dsBatchDetails.getValue(i, "u_ngbatchid", ""));
                    pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");
                    pl.setProperty("instrumentid", instrumentId);
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
                }
                if (!Util.isNull(reagentLotId)) {
                    pl.clear();
                    pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                    pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, dsBatchDetails.getValue(i, "u_ngbatchid", ""));
                    pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");
                    pl.setProperty("reagentid", reagentLotId);
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
                }
            }
        }

        /*if (!Util.isNull(batchId) && !Util.isNull(elTubes)) {
            pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            pl.setProperty("sampleid", elTubes);
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);

           *//* pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");
            pl.setProperty("plateid", boxId);
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);*//*

            if (!Util.isNull(instrumentId)) {
                pl.clear();
                pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
                pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_instrument_link");
                pl.setProperty("instrumentid", instrumentId);
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
            }
            if (!Util.isNull(reagentLotId)) {
                pl.clear();
                pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchId);
                pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_reagent_link");
                pl.setProperty("reagentid", reagentLotId);
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
            }
        }*/
        return batchId;
    }

    /**
     * This function is use to get the position in box to load the dna type of
     * extraction .
     *
     * @param plc
     * @param elTubeNo
     * @return
     * @throws SapphireException
     */
    private String getBoxPosToLdDNA(PropertyListCollection plc, String elTubeNo) throws SapphireException {
        if (plc != null && plc.size() > 0) {
            for (int i = 0; i < plc.size(); i++) {
                PropertyList tempPl = plc.getPropertyList(i);
                if (tempPl != null && tempPl.size() > 0) {
                    String sampleNo = tempPl.getProperty("noofsamples", "");
                    if (elTubeNo.equalsIgnoreCase(sampleNo))
                        return tempPl.getProperty("boxpos", "");
                }
            }
        }
        return "";
    }

    private void updateComments(String sampleid, String extractioncomments) throws SapphireException {
        try {
            PropertyList pl = new PropertyList();
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            pl.setProperty("u_extractioncomments", extractioncomments);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

        } catch (Exception sqlex) {
            String error = getTranslationProcessor().translate("Can't edit comments from sample");
            error += sqlex.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }

    }

    private DataSet getExtractionPrefix(String extractiontype) throws SapphireException {
        /*DataSet dsExtractionInfo = new DataSet();
        dsExtractionInfo.addColumn(POLICY_CHILD_EXTRACTION_TYPE, DataSet.STRING);
        dsExtractionInfo.addColumn(POLICY_CHILD_EXTRACTION_PREFIX, DataSet.STRING);
        dsExtractionInfo.addColumn(POLICY_CHILD_BATCHNAME_PREFIX, DataSet.STRING);
        dsExtractionInfo.addColumn(POLICY_CHILD_SEPERATE_OPERATOR, DataSet.STRING);
        PropertyList plExtractionPolicy = getConfigurationProcessor().getPolicy(EXTRACTIONPPREFIXPOLICYID, NODEID);
        if (plExtractionPolicy == null)
            throw new SapphireException("Extraction Type Prefix policy is not define in System Admin-> Policy.");
        PropertyListCollection plclosmap = plExtractionPolicy.getCollection(POLICY_MAPPING);
        if (plclosmap != null) {
            for (int i = 0; i < plclosmap.size(); i++) {
                String propExtractionType = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_EXTRACTION_TYPE);
                String propExtractionPrefix = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_EXTRACTION_PREFIX);
                String propBatchNamePrefix = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_BATCHNAME_PREFIX);
                String propSeperateOperator = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_SEPERATE_OPERATOR);

                int rowID = dsExtractionInfo.addRow();
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_EXTRACTION_TYPE, propExtractionType);
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_EXTRACTION_PREFIX, propExtractionPrefix);
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_BATCHNAME_PREFIX, propBatchNamePrefix);
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_SEPERATE_OPERATOR, propSeperateOperator);
            }
        }*/

        return dsExtractionInfo;
    }

    private void getBatchPrefixDeatils() throws SapphireException {
        if (dsExtractionInfo == null) {
            dsExtractionInfo = new DataSet();
        }

        dsExtractionInfo.addColumn(POLICY_CHILD_EXTRACTION_TYPE, DataSet.STRING);
        dsExtractionInfo.addColumn(POLICY_CHILD_EXTRACTION_PREFIX, DataSet.STRING);
        dsExtractionInfo.addColumn(POLICY_CHILD_BATCHNAME_PREFIX, DataSet.STRING);
        dsExtractionInfo.addColumn(POLICY_CHILD_SEPERATE_OPERATOR, DataSet.STRING);
        PropertyList plExtractionPolicy = getConfigurationProcessor().getPolicy(EXTRACTIONPPREFIXPOLICYID, NODEID);
        if (plExtractionPolicy == null)
            throw new SapphireException("Extraction Type Prefix policy is not define in System Admin-> Policy.");
        PropertyListCollection plclosmap = plExtractionPolicy.getCollection(POLICY_MAPPING);
        if (plclosmap != null) {
            for (int i = 0; i < plclosmap.size(); i++) {
                String propExtractionType = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_EXTRACTION_TYPE);
                String propExtractionPrefix = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_EXTRACTION_PREFIX);
                String propBatchNamePrefix = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_BATCHNAME_PREFIX);
                String propSeperateOperator = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_SEPERATE_OPERATOR);

                int rowID = dsExtractionInfo.addRow();
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_EXTRACTION_TYPE, propExtractionType);
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_EXTRACTION_PREFIX, propExtractionPrefix);
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_BATCHNAME_PREFIX, propBatchNamePrefix);
                dsExtractionInfo.setValue(rowID, POLICY_CHILD_SEPERATE_OPERATOR, propSeperateOperator);
            }
        }
    }

    private static final String EXTRACTIONPPREFIXPOLICYID = "ExtractionPrefixPolicy";
    private static final String NODEID = "MolecularExtraction";
    private static final String POLICY_MAPPING = "extractiontypelist";
    private static final String POLICY_CHILD_EXTRACTION_TYPE = "extractiontype";
    private static final String POLICY_CHILD_EXTRACTION_PREFIX = "extractionprefix";
    private static final String POLICY_CHILD_BATCHNAME_PREFIX = "batchnameprefix";
    private static final String POLICY_CHILD_SEPERATE_OPERATOR = "seperateoperator";
    DataSet dsExtractionInfo = null;
}
