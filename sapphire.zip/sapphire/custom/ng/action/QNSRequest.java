package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.RecordIncident;
import sapphire.action.SubmitSDIForApproval;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by DMondal on 3/24/2017.
 * Description : QNS erquest will generate if user check QNS check box and request id will display in success message.
 */
public class QNSRequest extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        /***
         * TODO WE DON'T NEED THIS AS WE DON"T HAVE REQUEST MODULE
         */
        /*String sample = properties.getProperty("sample");
        if (Util.isNull(sample)) {
            String errStr = getTranslationProcessor().translate("Selected sampleid not found.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        DataSet daQNS=getQNS(sample);
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String user = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String dept = department.substring(0, department.indexOf("-"));
        String requestid="";
        if(daQNS != null && daQNS.getRowCount() > 0) {
            for (int i = 0; i < daQNS.size(); i++) {
                String qns = daQNS.getString(i, "u_qns", "");
                if ("Y".equalsIgnoreCase(qns)) {

                    String msg = " QNS request for sample -" + daQNS.getString(i, "s_sampleid") + ", Block id " + daQNS.getString(i, "u_clientspecimenid")
                            + " from accession # " + daQNS.getString(i, "u_accessionid");
                    PropertyList recordProp = new PropertyList();
                    recordProp.setProperty("sourcesdcid", "Sample");
                    recordProp.setProperty("sourcekeyid1", daQNS.getString(i, "s_sampleid"));
                    recordProp.setProperty("incidentcategory", "UnPlanned");
                    recordProp.setProperty("incidentdesc", "QNS");
                    recordProp.setProperty("explanation",  msg);
                    recordProp.setProperty("rootcause", msg);
                    recordProp.setProperty("u_fromdepartment", department);
                    recordProp.setProperty("initialstatus", "PendingApproval");
                    recordProp.setProperty("reportedby", user);
                    recordProp.setProperty("u_message", msg);
                    String siteDept = dept + "-ClientServices";
                    String deptrt = deptValidate(siteDept);
                    recordProp.setProperty("departmentid", deptrt);
                    getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);

                    PropertyList approvalProps = new PropertyList();
                    approvalProps.setProperty("sdcid", "LV_Incdt");
                    approvalProps.setProperty("keyid1", recordProp.getProperty("newkeyid1"));
                    approvalProps.setProperty("pendingapprovalstatus", "PendingApproval");
                    approvalProps.setProperty("approvalstatus", "Approved");
                    approvalProps.setProperty("approvalstatuscolumn", "incidentstatus");
                    getActionProcessor().processAction(SubmitSDIForApproval.ID, SubmitSDIForApproval.VERSIONID, approvalProps);

                    String request = recordProp.getProperty("newkeyid1");
                    requestid = requestid + "," + request;

                }
            }
            String[] requestArr = requestid.split(",");
            if (requestArr.length > 1) {
                String finalmsg = "Request has been created.Request id(s):" + requestid.substring(1);
                properties.setProperty("requestid", finalmsg);
            } else {
                properties.setProperty("requestid", "");
            }
        }*/
    }
    /**
     * Description : This method will check department is valid or not.
     *
     * @param siteDept
     * @return
     * @throws SapphireException
     */
    private String deptValidate(String siteDept) throws SapphireException {
        String site = siteDept.substring(0, siteDept.indexOf("-"));
        String targetDept = siteDept.substring(siteDept.indexOf("-") + 1, siteDept.length());
        String department = "";
        String dept = "select departmentid from department where departmentid='" + siteDept + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor().translate("QNS not be possible for the site " + site+" as ClientServices department not present here. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
        }
        return department;
    }

    /**
     * Description : This method will search QNS information.
     * @param sample
     * @return
     * @throws SapphireException
     */
    private DataSet getQNS(String sample) throws SapphireException {
        String sampleid= StringUtil.replaceAll(sample,";","','");
        String sqlQNS="select s_sampleid, u_qns,u_accessionid,u_clientspecimenid from s_sample where s_Sampleid in ('"+sampleid+"' )";
        DataSet dsQNS = getQueryProcessor().getSqlDataSet(sqlQNS);
        if (dsQNS == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sqlQNS;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsQNS.size() == 0) {
            String errStr = getTranslationProcessor().translate("Sample not found in LV database.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        return dsQNS;
    }
}
