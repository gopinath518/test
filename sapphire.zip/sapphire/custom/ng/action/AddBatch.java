package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by kshahbaz on 6/8/2016.
 * @desc : This action is used for batch creation.
 * Mandatory Input:
 * @param1 : Reagent Information
 * @param2 : Sample Information
 * @param3 : Control Information
 * @param4 : Batch Name
 * @param5 : Batch Type
 * @throws SapphireException
 */
public class AddBatch extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {

        String reginfo = properties.getProperty("reginfo","");
        String sampinfo = properties.getProperty("sampinfo","");
        String ctrlinfo = properties.getProperty("ctrlinfo","");
        String batchname = properties.getProperty("batchname","");
        String batchtype = properties.getProperty("batchtype","");

        String batchid = createBatch(batchname,batchtype);
        if(!Util.isNull(batchid)){
            addReagent(batchid,reginfo);
            addSample(batchid,sampinfo);
            addControl(batchid,ctrlinfo);
        }
    }

    /**
     * @desc : This method create a batch based on input parameter
     * @param batchname
     * @param batchtype
     * @return Return the batchid
     * @throws SapphireException
     */
    private String createBatch(String batchname,String batchtype) throws SapphireException {
        String ngbatchid = "";
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype",batchtype);
        pl.setProperty("batchname",batchname);
        pl.setProperty("origin","Normalization");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            ngbatchid=pl.getProperty("newkeyid1");

        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return  ngbatchid;
    }

    /**
     * @desc : This method addd reagent information to the batch
     * @param batchid
     * @param reginfo
     * @throws SapphireException
     */
    private void addReagent(String batchid,String reginfo) throws SapphireException{
        if(!Util.isNull(batchid) && !Util.isNull(reginfo)){
            DataSet result = null;
            String reginfoArr[]= StringUtil.split(reginfo,";");
            if(reginfoArr!=null && reginfoArr.length>0){
                result = new DataSet();
                result.addColumn("reagentid",DataSet.STRING);
                result.addColumn("reagenttype",DataSet.STRING);
                result.addColumn("reagenttypeversion",DataSet.STRING);
                result.addColumn("type",DataSet.STRING);
                result.addColumn("ANALYTE",DataSet.STRING);
                for (int i = 0; i < reginfoArr.length; i++) {
                    String comb = reginfoArr[i];
                    if (!Util.isNull(comb)) {
                        String combArr[]= StringUtil.split(comb,"@*@");
                        String analyteArr[]=StringUtil.split(combArr[4],",");
                        if(combArr!=null && combArr.length>0) {
                            if(analyteArr!=null && analyteArr.length>0) {
                                for(int j=0;j<analyteArr.length;j++) {
                                    int rownum = result.addRow();
                                    result.setValue(rownum, "reagentid", combArr[0]);
                                    result.setValue(rownum, "reagenttype", combArr[1]);
                                    result.setValue(rownum, "reagenttypeversion", combArr[2]);
                                    result.setValue(rownum,"type",combArr[3]);
                                    result.setValue(rownum,"ANALYTE",analyteArr[j]);
                                }
                            }
                        }
                    }
                }
                if(result!=null && result.size()>0){
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
                    props.setProperty("reagentid",result.getColumnValues("reagentid",";"));
                    props.setProperty("reagenttype",result.getColumnValues("reagenttype",";"));
                    props.setProperty("reagenttypeversion",result.getColumnValues("reagenttypeversion",";"));
                    props.setProperty("type",result.getColumnValues("type",";"));
                    props.setProperty("ANALYTE",result.getColumnValues("ANALYTE",";"));
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_reagent_link");
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                }
            }
        }
    }

    /**
     * @desc : This method add sample information to batch.
     * @param batchid
     * @param sampinfo
     * @throws SapphireException
     */
    private void addSample(String batchid,String sampinfo) throws SapphireException{
        if(!Util.isNull(batchid) && !Util.isNull(sampinfo)){
            DataSet result = null;
            String sampinfoArr[]= StringUtil.split(sampinfo,";");
            if(sampinfoArr!=null && sampinfoArr.length>0){
                result = new DataSet();
                result.addColumn("sampleid",DataSet.STRING);
                result.addColumn("analyte",DataSet.STRING);

                for (int i = 0; i < sampinfoArr.length; i++) {
                    String comb = sampinfoArr[i];
                    if (!Util.isNull(comb)) {
                        String combArr[]= StringUtil.split(comb,"@*@");
                        if(combArr!=null && combArr.length>0) {
                            int rownum = result.addRow();
                            result.setValue(rownum, "sampleid",combArr[0]);
                            result.setValue(rownum, "analyte",combArr[1]);
                        }
                    }
                }

                if(result!=null && result.size()>0){
                    PropertyList props = new PropertyList();
                    props.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
                    props.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
                    props.setProperty("sampleid",result.getColumnValues("sampleid",";"));
                    props.setProperty("analyte",result.getColumnValues("analyte",";"));
                    props.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_sample_link");
                    getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                }
            }
        }
    }

    /**
     * @desc : This method add control information to batch
     * @param batchid
     * @param ctrlinfo
     * @throws SapphireException
     */

    private void addControl(String batchid,String ctrlinfo) throws SapphireException{
        if(!Util.isNull(batchid) && !Util.isNull(ctrlinfo)){
            DataSet result = null;
            String ctrlinfoArr[]= StringUtil.split(ctrlinfo,";");
            String finalSample = "";
            String reagents = "";
            int regCount=0;
            if(ctrlinfoArr!=null && ctrlinfoArr.length>0){
                result = new DataSet();
                result.addColumn("controltype",DataSet.STRING);
                result.addColumn("sampleid",DataSet.STRING);
                result.addColumn("analyte",DataSet.STRING);
                result.addColumn("position",DataSet.STRING);
                result.addColumn("reagentlotid",DataSet.STRING);

                for (int i = 0; i < ctrlinfoArr.length; i++) {
                    String comb = ctrlinfoArr[i];

                    if (!Util.isNull(comb)) {
                        String combArr[]= StringUtil.split(comb,"@*@");
                        String analyteArr[]=StringUtil.split(combArr[1],",");
                        if(combArr!=null && combArr.length>0) {
                            if(analyteArr!=null && analyteArr.length>0) {
                                for(int j=0;j<analyteArr.length;j++) {
                                    int rownum = result.addRow();
                                    result.setValue(rownum, "analyte", analyteArr[j]);
                                    result.setValue(rownum, "position", combArr[2]);
                                    result.setValue(rownum,"controltype",combArr[3]);
                                    if ("Sample".equalsIgnoreCase(combArr[3]))
                                        finalSample += ";" + combArr[0];
                                    else if ("Reagent".equalsIgnoreCase(combArr[3])) {
                                        reagents += ";" + combArr[0];
                                        regCount++;
                                    }
                                }
                            }
                        }
                    }
                }

                if(result!=null && result.size()>0){
                    PropertyList props = new PropertyList();
                    String regSample = "";
                    if(!Util.isNull(reagents)){
                        if(reagents.startsWith(";"))
                            reagents=reagents.substring(1);
                        String qcsampletype = StringUtil.repeat("Reagent Sample",regCount,";");
                        props.setProperty(AddSDI.PROPERTY_SDCID,"Sample");
                        props.setProperty(AddSDI.PROPERTY_COPIES,Integer.toString(regCount));
                        props.setProperty("reagentlotid",reagents);
                        props.setProperty("qcsampletype",qcsampletype);
                        getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID,props);
                        regSample = props.getProperty(AddSDI.RETURN_NEWKEYID1,"");
                        finalSample+=";"+regSample;
                    }
                    if(!Util.isNull(finalSample)) {
                        if(finalSample.startsWith(";"))
                            finalSample = finalSample.substring(1);
                        props.clear();
                        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
                        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
                        props.setProperty("sampleid", finalSample);
                        props.setProperty("analyte", result.getColumnValues("analyte", ";"));
                        props.setProperty("position", result.getColumnValues("position", ";"));
                        props.setProperty("controltype",result.getColumnValues("controltype",";"));
                        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "ngbatch_control_link");
                        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
                    }
                }
            }
        }
    }

}
