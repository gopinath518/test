package sapphire.custom.ng.action;

import java.util.ArrayList;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CompletePathSupport extends BaseAction {
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleId = properties.getProperty("sampleid", "");
		String message = "";
		if(!"".equals(sampleId)){
			DataSet ds = getQueryProcessor().getSqlDataSet(Util.parseMessage(ApSql.GET_LOS_BY_SAMPLE,StringUtil.replaceAll(sampleId, ";", "','")));
			PropertyList prop = new PropertyList();
			if(ds.size() == 0)
				message = "Los missing for the selected Sample";
			else{
				ds.sort("los");
				ArrayList<DataSet> dsLOSGroupDS = ds.getGroupedDataSets("los");
				if(dsLOSGroupDS!=null && dsLOSGroupDS.size()>0) {
					for(DataSet tempDS: dsLOSGroupDS ){
						prop.clear();
						prop.setProperty("sampleid", tempDS.getColumnValues("s_sampleid", ";"));
						
						getActionProcessor().processAction("IHCFlowCompleteStep", "1", prop);
						message = message+prop.getProperty("msg","")+"\n";
					}
				}
			}
		}
		properties.setProperty("msg", message);
	}
}
