package sapphire.custom.ng.action;


import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDIDetail;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 10/26/2016.
 */
public class MoveBackToNGSDASamples extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException{
        String sampleids=properties.getProperty("sampleid","");
        String batchid=properties.getProperty("ngbatchid","");
        PropertyList prop=new PropertyList();
        prop.setProperty(DeleteSDIDetail.PROPERTY_SDCID,"NGBatch");
        prop.setProperty(DeleteSDIDetail.PROPERTY_KEYID1,batchid);
        prop.setProperty("sampleid",sampleids);
        prop.setProperty(DeleteSDIDetail.PROPERTY_LINKID,"u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID,prop);
        }catch(SapphireException se){
            throw new SapphireException("Samples not moved back");
        }
        PropertyList sample=new PropertyList();
        sample.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        sample.setProperty(EditSDI.PROPERTY_KEYID1,sampleids);
        sample.setProperty("u_currentmovementstep","Agilent");
        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,sample);




    }
}
