package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by msubhra on 6/15/2016.
 *
 * This action is used for loading molecular batches into plate. This action will take
 * Batchtypeid, batchid and plate id as input and return a success message as output.
 */
public class MolecularLoadIntoPlate extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String batchtypeid = properties.getProperty("batchtypeid");
        String batchid = properties.getProperty("batchid");
        String plateid=loadIntoPlate(batchtypeid);
        String message = updatePlateDetail(batchid,plateid);
        properties.setProperty("outmsg",message);

    }

    /**
     * This method is used for create a new plate by calling NGAutoPlateLoading action.
     * This method takes input as batchtype and returns newly created plate id.
     * @param batchtype BatchType which is a input while calling the action
     * @return plateid Newly created plateid
     */
        private String loadIntoPlate (String batchtype){
            String plateID = "";
            PropertyList pl = new PropertyList();
            pl.setProperty("batchtypeid", batchtype);


            try {
                getActionProcessor().processAction("NGAutoPlateLoading", "1", pl);
                plateID = pl.getProperty("newplateid");
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed NGAutoPlateLoading");
                try {
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                } catch (SapphireException e1) {
                    e1.printStackTrace();
                }
            }
            return plateID;

        }

    /**
     * This method is used for update the plate detail in detail table of NGBatch SDC.
     * This method takes input as batchid and plateid and returns success message.
     * @param batchid Batch Id which is a input while calling the action
     * @param plateId Newly created plateid
     * @return Success Message
     * @throws SapphireException
     */

    private String updatePlateDetail(String batchid, String plateId) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
        pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, batchid);
        pl.setProperty("plateid", plateId);
        pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_plate_link");

        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);


        } catch (SapphireException ex) {
            String error = getTranslationProcessor().translate("Action failed try again");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        String message = "Batch has been successfully loaded into plate.";
        return message;
    }
}
