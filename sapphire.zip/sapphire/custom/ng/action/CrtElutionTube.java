package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by rrmandal on 6/8/2016.
 * Modified by surajit
 */
public class CrtElutionTube extends BaseAction {

    private static final String COLS_TO_COPY = "u_extractionid;sampletypeid;u_clientspecimenid;u_sampleinformation;u_accessionid;" +
            "u_tumorcircled;u_totaltumor;u_pathologycomments;u_extractioncomments;concentration;collectiondt;u_collectiontime";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String extTubeId = properties.getProperty("exttubeid", "");
        String copies = properties.getProperty("copies", "1");
        String fromtramstop = properties.getProperty("fromtramstop", "");
        String elTube = crtElutionTube(extTubeId, copies, fromtramstop);
        // copyTestCodeFrmExtToElTube(extTubeId, elTube);
        Util.copyTestCodeFromParent(elTube, getQueryProcessor(), getActionProcessor());
        //assignMolBatchSample(elTube);
        properties.setProperty("elTube", elTube);
        //throw new SapphireException("Test");
    }

    /**
     * @param exttube
     * @return
     * @throws SapphireException
     */

    private String crtElutionTube(String exttube, String copies, String fromtramstop) throws SapphireException {
        String ellutionTubes = "";
        if (!Util.isNull(exttube)) {
            String sql = "select t.qtycurrent,t.containertypeid,t.custodialdepartmentid,t.qtyunits,s.* "
                    + "from s_sample s,trackitem t "
                    + "where t.linksdcid='Sample' and s.s_sampleid=t.linkkeyid1 and s.s_sampleid in('"
                    + StringUtil.replaceAll(exttube, ";", "','") + "')";
            DataSet dsExtTubeInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsExtTubeInfo != null && dsExtTubeInfo.size() > 0) {
                int dsSize = dsExtTubeInfo.size();
                copies = StringUtil.repeat(copies, dsSize, ";");
                String syncPrnt = StringUtil.repeat("N", dsSize, ";");
                String mode = StringUtil.repeat("Child", dsSize, ";");

                PropertyList pl = new PropertyList();
                pl.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, copies);
                pl.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, COLS_TO_COPY);
                pl.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID,
                        dsExtTubeInfo.getColumnValues("s_sampleid", ";"));
                pl.setProperty(MultiSampleChild.PROPERTY_MODE, mode);
                pl.setProperty(MultiSampleChild.PROPERTY_CHILD_QUANTITY,
                        dsExtTubeInfo.getColumnValues("qtycurrent", ";"));
                pl.setProperty(MultiSampleChild.PROPERTY_CHILD_UNIT, dsExtTubeInfo.getColumnValues("qtyunits", ";"));
                pl.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, syncPrnt);
                pl.setProperty(MultiSampleChild.PROPERTY_PROPSMATCH, "Y");
                getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, pl);

                ellutionTubes = pl.getProperty(MultiSampleChild.RETURN_NEWKEYID1, "");

                pl.clear();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, ellutionTubes);
                if ("quantification".equalsIgnoreCase(fromtramstop)) {
                    pl.setProperty("u_currentmovementstep", "QuantExtraction");
                } else {
                    pl.setProperty("u_currentmovementstep", "MolecularExtraction");
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                String currentuser = connectionInfo.getSysuserId();
                String defaultdepartment = connectionInfo.getDefaultDepartment();
                // String site =
                // defaultdepartment.substring(0,defaultdepartment.indexOf("-"));
                // String custodialDepartment = site + "-Molecular";
                pl.clear();
                pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditTrackItem.PROPERTY_KEYID1, ellutionTubes);
                pl.setProperty("containertypeid", "Ellution Tube");// TODO
                // spelling
                // mistake
                // pl.setProperty("custodialdepartmentid",
                // getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment());
                // pl.setProperty("custodialuserid",
                // getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
                pl.setProperty("custodialdepartmentid", defaultdepartment);
                pl.setProperty("custodialuserid", currentuser);
                if ("quantification".equalsIgnoreCase(fromtramstop)) {
                    pl.setProperty("u_currentmovementstep", "QuantificationExtraction");
                    pl.setProperty("u_currenttramstop", "QuantificationExtraction");
                } else {
                    pl.setProperty("u_currentmovementstep", "MolecularExtraction");
                    pl.setProperty("u_currenttramstop", "MolecularExtraction");
                }

                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);

                createSDIAliasForElusionTubes(ellutionTubes);
            }
        }
        return ellutionTubes;
    }

    private void createSDIAliasForElusionTubes(String elusionTubes) throws SapphireException {
        if (!Util.isNull(elusionTubes)) {
            String sql = "select s_sampleid, u_extractionid from s_sample where s_sampleid in('"
                    + StringUtil.replaceAll(elusionTubes, ";", "','") + "')";
            DataSet dsElSamplInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsElSamplInfo != null && dsElSamplInfo.size() > 0) {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDIAlias.PROPERTY_SDCID, "Sample");
                pl.setProperty(AddSDIAlias.PROPERTY_KEYID1, dsElSamplInfo.getColumnValues("s_sampleid", ";"));
                pl.setProperty(AddSDIAlias.PROPERTY_ALIASID, dsElSamplInfo.getColumnValues("u_extractionid", ";"));
                pl.setProperty(AddSDIAlias.PROPERTY_ALIASTYPE,
                        StringUtil.repeat("External", dsElSamplInfo.size(), ";"));
                getActionProcessor().processAction(AddSDIAlias.ID, AddSDIAlias.VERSIONID, pl);
            }
        }
    }

    /**
     * @param extTube
     * @param elTube
     * @throws SapphireException
     */

    private void copyTestCodeFrmExtToElTube(String extTube, String elTube) throws SapphireException {
        String sql = "select s_sampleid,lvtestcodeid,ispanel from u_sampletestcodemap where s_sampleid in('"
                + StringUtil.replaceAll(extTube, ";", "','") + "')";
        DataSet dsExtTestCode = getQueryProcessor().getSqlDataSet(sql);
        sql = "select sourcesampleid,destsampleid from s_samplemap where sourcesampleid in('"
                + StringUtil.replaceAll(extTube, ";", "','") + "') ";
        DataSet dsSampleMap = getQueryProcessor().getSqlDataSet(sql);
        if (dsExtTestCode != null && dsSampleMap != null && dsExtTestCode.size() > 0 && dsSampleMap.size() > 0) {
            String elTubeArr[] = StringUtil.split(elTube, ";");
            if (elTubeArr != null && elTubeArr.length > 0) {
                DataSet result = new DataSet();
                result.addColumn("s_sampleid", DataSet.STRING);
                result.addColumn("lvtestcode", DataSet.STRING);
                result.addColumn("ispanel", DataSet.STRING);

                HashMap<String, String> hmap = new HashMap<String, String>();
                for (int i = 0; i < elTubeArr.length; i++) {
                    hmap.clear();
                    hmap.put("destsampleid", elTubeArr[i]);
                    DataSet dsSampleMapFiltr = dsSampleMap.getFilteredDataSet(hmap);
                    if (dsSampleMapFiltr != null && dsSampleMapFiltr.size() > 0) {
                        String tempExtTube = dsSampleMapFiltr.getValue(0, "sourcesampleid", "");
                        if (!Util.isNull(tempExtTube)) {
                            hmap.clear();
                            hmap.put("s_sampleid", tempExtTube);
                            DataSet dsExtTestCodeFiltr = dsExtTestCode.getFilteredDataSet(hmap);
                            if (dsExtTestCodeFiltr != null && dsExtTestCodeFiltr.size() > 0) {
                                for (int j = 0; j < dsExtTestCodeFiltr.size(); j++) {
                                    int resultIndex = result.addRow();
                                    result.setValue(resultIndex, "s_sampleid", elTubeArr[i]);
                                    result.setValue(resultIndex, "lvtestcode",
                                            dsExtTestCodeFiltr.getValue(j, "lvtestcodeid", ""));
                                    result.setValue(resultIndex, "ispanel",
                                            dsExtTestCodeFiltr.getValue(j, "ispanel", "N"));
                                }
                            }
                        }
                    }
                }
                if (result != null && result.size() > 0) {
                    Util.copyTestCodeFromParent(result.getColumnValues("s_sampleid", ";"), getQueryProcessor(),
                            getActionProcessor());
                }
            }
        }
    }

    private void assignMolBatchSample(String elutiontube) throws SapphireException {
        DataSet dsFinal = new DataSet();
        dsFinal.addColumn("sampleid", DataSet.STRING);
        dsFinal.addColumn("molbatchid", DataSet.STRING);
        dsFinal.addColumn("molbatchspecimenid", DataSet.STRING);
        dsFinal.addColumn("lvtestcodeid", DataSet.STRING);
        String sql = Util.parseMessage(MolecularSql.GET_ELUTION_DETAILS, StringUtil.replaceAll(elutiontube, ";", "','"));
        DataSet dsElutionTubeInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsElutionTubeInfo.size() > 0) {
            for (int i = 0; i < dsElutionTubeInfo.size(); i++) {
                String eltube = dsElutionTubeInfo.getValue(i, "s_sampleid", "");
                String molbatchid = dsElutionTubeInfo.getValue(i, "molbatchid", "");
                String rootmolspecimenid = dsElutionTubeInfo.getValue(i, "rootmolspecimenid", "");
                String lvtestcodeid = dsElutionTubeInfo.getValue(i, "lvtestcodeid", "");
                String elubatchcomb = eltube + "#" + molbatchid;
                sql = Util.parseMessage(MolecularSql.CHECK_ELUTION_PRESENT_BATCH, StringUtil.replaceAll(elubatchcomb, ";", "','"));
                DataSet dsCheckExist = getQueryProcessor().getSqlDataSet(sql);
                if (dsCheckExist.size() == 0) {
                    int rowID = dsFinal.addRow();
                    dsFinal.setValue(rowID, "sampleid", eltube);
                    dsFinal.setValue(rowID, "molbatchid", molbatchid);
                    dsFinal.setValue(rowID, "molbatchspecimenid", rootmolspecimenid);
                    dsFinal.setValue(rowID, "lvtestcodeid", lvtestcodeid);
                }
            }
        }
        if (dsFinal.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid", ";"));
            prop.setProperty("u_molbatchspecimenid", dsFinal.getColumnValues("molbatchspecimenid", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception e) {
                throw new SapphireException("Specimen can't update." + e.getMessage());
            }
            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, dsFinal.getColumnValues("molbatchid", ";"));
            props.setProperty("sampleid", dsFinal.getColumnValues("sampleid", ";"));
            props.setProperty("testcodeid", dsFinal.getColumnValues("lvtestcodeid", ";"));
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");

            try {
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
            } catch (SapphireException se) {
                throw new SapphireException("Can not edit batch detail" + se.getMessage());
            }
        }
    }

}
