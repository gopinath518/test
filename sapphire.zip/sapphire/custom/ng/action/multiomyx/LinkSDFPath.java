package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by ssen on 10/9/2017.
 */
public class LinkSDFPath extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String moimageid = properties.getProperty("moimageid");
        String status = properties.getProperty("status");
        String batchid = properties.getProperty("batchid");
        String sdfpath = properties.getProperty("sdfpath");
        if(Util.isNull(moimageid))
            throw new SapphireException("moimageid can't be found");
        if(Util.isNull(status))
            throw new SapphireException("statush can't be found");
        if(Util.isNull(batchid))
            throw new SapphireException("sampleid can't be found");
        String envid = "MOLogPath";
        String finalbatchid ="";
        if(!Util.isNull(batchid)) {
            String[] batchidarr = batchid.split(";");
            Set<String> mySet = new HashSet(Arrays.asList(batchidarr));
            for (String temp : mySet) {
                finalbatchid += ";" + temp;
            }
            if (finalbatchid.startsWith(";"))
                finalbatchid = finalbatchid.substring(1);
        }

        String sqldata = Util.parseMessage(MultiomyxSql.GET_PATH_FROM_ENVPROP, envid);
        DataSet dspath = getQueryProcessor().getSqlDataSet(sqldata);

        PropertyList prop = new PropertyList();
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, moimageid);
        prop.setProperty("status",status);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. EditSdi on MOImage  " + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "MOBatch");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, finalbatchid);
        if(Util.isNull(sdfpath))
            prop.setProperty("sdfpath",dspath.getValue(0,"propvalue"));
        else
            prop.setProperty("sdfpath",dspath.getValue(0,"propvalue")+ File.separator+ sdfpath );
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. EditSdi on Sample  " + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }





    }

}

