package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

/**
 * Created by aritra.banerjee on 10/26/2017.
 * This Action is called when Complete button is clicked from Slide prep tramstop in MO Wet lab
 */
public class CompleteSlidePrep extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("keyid1", "");

        if (Util.isNull(sampleid))
            throw new SapphireException("Error: Sample Id missing..");

        sampleid = Util.getUniqueList(sampleid, ";", true);

        if (!Util.isNull(sampleid)) {
            updateSlide(sampleid);
        }
    }

    /**\
     * This method callse WS methods from MOLWSAction Action
     * and updates mostatus and other details in Sample
     * @param sampleid
     * @throws SapphireException
     */

    private void updateSlide(String sampleid) throws SapphireException {

        calWSMethod(sampleid);


        if(!Util.isNull(sampleid)){
            try {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                updateProp.setProperty("u_mostatus", "MOSlidePrepCompleted");
                updateProp.setProperty("u_mocreatedt", "n");
                updateProp.setProperty("u_mocreateby", connectionInfo.getSysuserId());
                updateProp.setProperty("u_moreceivecomment", "Complete Slide Prep");
                updateProp.setProperty("auditreason", "Complete Slide Prep");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to edit mo status in Sample.");
            }
        }
    }

    /**
     * This method callse WS methods from MOLWSAction Action
     * @param sampleid
     * @throws SapphireException
     */
    private void calWSMethod(String sampleid) throws SapphireException {

        PropertyList props = new PropertyList();

        try {
            props.setProperty("operationName","updateSlideStatus");
            props.setProperty("slideid",sampleid);

            getActionProcessor().processAction("MOLWSAction", "1", props);

        } catch (Exception ex) {
            throw new SapphireException("Error while calling updateSlideStatus WS. "+ex.getMessage());
        }

    }

}
