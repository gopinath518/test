package sapphire.custom.ng.action.multiomyx;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.SendMail;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;


public class MOReagentMail extends BaseAction {

	public static final String NODE_ID = "MOReagentWarning";
	public static final String EMAILTOLIST = "emailtolist";// Optional
	public static final String EMAILFROM = "emailfrom";// Optional
	public static final String EMAILCCLIST = "emailcclist";// Optional
	private static final String MAIL_CONFIG_POLICY_ID = "MailNotificationPolicy";
	public static final String MODE = "mode";

	/****************************************************
	 * This method is the entry point of calling all the operations of LWS
	 * service
	 *
	 * @param properties
	 * @throws SapphireException
	 ***************************************************/
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String nodeid = NODE_ID;
		if (Util.isNull(nodeid))
			throw new SapphireException("Node Id for the policy " + MAIL_CONFIG_POLICY_ID + " is not found.");
		PropertyList mailConfigPolicy = getConfigurationProcessor().getPolicy(MAIL_CONFIG_POLICY_ID, nodeid);
		if (mailConfigPolicy == null)
			throw new SapphireException("Data from the " + MAIL_CONFIG_POLICY_ID + " policy cannot be obtained.");
		if (mailConfigPolicy.size() == 0)
			throw new SapphireException(
					"The policy " + MAIL_CONFIG_POLICY_ID + " is not properly defined for the nodeid " + nodeid);

		PropertyList mailconfigProp = mailConfigPolicy.getPropertyList("mailconfig");
		if (mailconfigProp == null || mailconfigProp.size() == 0)
			throw new SapphireException(
					"The policy " + MAIL_CONFIG_POLICY_ID + " is not properly defined for the nodeid " + nodeid);
		sendMail(properties, mailconfigProp, nodeid);

	}

	private void sendMail(PropertyList properties, PropertyList mailconfigProp, String nodeid)
			throws SapphireException {
		if (properties != null && properties.size() > 0 && mailconfigProp != null && mailconfigProp.size() > 0) {
			String reagentDetails = "\r\n\r\n"
					+ " <table border=\"1px solid black \"><tr  border=\"1px solid black collapse\"> <th>Reagent ID  </th><th>Marker Name </th>"
					+ "<th>Expiry Date </th><th> Days To Expire </th><th> Quantity Available </th><th> Unit </th></tr>";
			String quantity = mailconfigProp.getProperty("thresoldquantity", "");
			String days = mailconfigProp.getProperty("daysbeforeexpire", "");

			String sql = Util.parseMessage(MultiomyxSql.MOREAGENT_THRESOLD_MAIL, days, quantity);
			DataSet rs = getQueryProcessor().getSqlDataSet(sql);
			Calendar dt = Calendar.getInstance();
			Timestamp tempTS = null ;

			if (rs != null && rs.getRowCount() > 0) 
			{
				HashMap hm = new HashMap();
				hm.put("qtyunits", "ul");
				rs = rs.getFilteredDataSet(hm);
				if (rs != null && rs.getRowCount() > 0) 
				{
					for (int i = 0; i < rs.getRowCount(); i++) {
						reagentDetails = reagentDetails + "<tr border=\"1px solid black collapse\"> <td>";
						reagentDetails = reagentDetails + " " + rs.getString(i, "reagentlotid");
						reagentDetails = reagentDetails + " </td><td>" + rs.getString(i, "reagenttypeid");
						tempTS = rs.getTimestamp(i, "expirydt") ;
						if(tempTS != null) {
							dt.setTimeInMillis(tempTS.getTime());
							reagentDetails = reagentDetails + " </td><td>" + (dt.get(Calendar.MONTH) + 1) + "/" + dt.get(Calendar.DATE) + "/"
								+ dt.get(Calendar.YEAR);
						}else{
							reagentDetails = reagentDetails + " </td><td>" + "Not Define";							
						}
						reagentDetails = reagentDetails + " </td><td>" + rs.getLong(i, "pendingday");
						reagentDetails = reagentDetails + " </td><td> " + rs.getDouble(i, "qtycurrent");
						reagentDetails = reagentDetails + " </td><td>" + rs.getString(i, "qtyunits")  + "</td></tr>";

					}

					reagentDetails = reagentDetails + "</table><br>\r\n";

					String mailServerInfo = getConnectionProcessor()
							.getConfigProperty("com.labvantage.sapphire.server.smtphost");
					
					if (Util.isNull(mailServerInfo))
						throw new SapphireException(
								"Please provide the Mail Server info in the System Configuration under Miscellaneous Option tab.");

					String toList = getToEmailId(properties, mailconfigProp);
					String ccList = getCCEmailId(properties, mailconfigProp);
					String fromId = getFromEmailId(properties, mailconfigProp);
					String subject = mailconfigProp.getProperty("emailsubject", "");

					if (Util.isNull(subject))
						throw new SapphireException(
								"Subject cannot be obtained. Please configure the Subject property in the policy "
										+ MAIL_CONFIG_POLICY_ID + " under the node " + nodeid + ".");

					String body = mailconfigProp.getProperty("emailmessage", "");
					if (Util.isNull(body))
						throw new SapphireException(
								"Subject cannot be obtained. Please configure the Message property in the policy "
										+ MAIL_CONFIG_POLICY_ID + " under the node " + nodeid + ".");
					// body=getProperString(properties,body);

					body = body + "\r\n\r\n" + reagentDetails;

					if (Util.isNull(toList))
						throw new SapphireException(
								"To List is not found.Please configure the To List or To List By Query property in the policy "
										+ MAIL_CONFIG_POLICY_ID + " " + "under the node " + nodeid
										+ " or please provide the value for the action property " + EMAILTOLIST + ".");

					if (Util.isNull(fromId))
						throw new SapphireException(
								"From Id is not found. Please configure the From Address or From Address By Query in the policy "
										+ MAIL_CONFIG_POLICY_ID + " " + "under the node " + nodeid
										+ " or please provide the from address in the System Configuration under the Miscellaneous Option tab.");
					String fromIdArr[] = StringUtil.split(fromId, ";");
					if (fromIdArr != null && fromIdArr.length > 1)
						throw new SapphireException(
								"Multiple From Email Id obtained. Please specify the From Id either in From Address or specify the query returning the From Id "
										+ "in From Address By Query or in the System Configuration under the Miscellaneous Option tab.");

					PropertyList pl = new PropertyList();
					pl.setProperty(SendMail.PROPERTY_FROM, fromId);
					pl.setProperty(SendMail.PROPERTY_ADDRESS, toList);
					if (!Util.isNull(ccList))
						pl.setProperty(SendMail.PROPERTY_CC, ccList);
					pl.setProperty(SendMail.PROPERTY_MESSAGE, body);
					pl.setProperty(SendMail.PROPERTY_SUBJECT, subject);
					pl.setProperty(SendMail.PROPERTY_MAILFORMAT, "html");
					getActionProcessor().processAction(SendMail.ID, SendMail.VERSIONID, pl);
				}
			}
		}

	}

	private String getToEmailId(PropertyList properties, PropertyList mailconfigProp) throws SapphireException {
		String resultToEmailId = "";
		if (properties != null && properties.size() > 0) {
			String tempToList = properties.getProperty(EMAILTOLIST, "");
			if (!Util.isNull(tempToList))
				resultToEmailId += ";" + tempToList;
		}
		if (mailconfigProp != null && mailconfigProp.size() > 0) {
			PropertyListCollection emailtolist = mailconfigProp.getCollection("emailtolist");
			if (emailtolist != null && emailtolist.size() > 0) {
				for (int i = 0; i < emailtolist.size(); i++) {
					PropertyList tempPl = emailtolist.getPropertyList(i);
					if (tempPl != null && tempPl.size() > 0) {
						String tempToAddress = tempPl.getProperty("emailtoaddress", "");
						if (!Util.isNull(tempToAddress))
							resultToEmailId += ";" + tempToAddress;
					}
				}
			}
			String emailtobyqry = mailconfigProp.getProperty("emailtobyqry", "");
			if (!Util.isNull(emailtobyqry)) {
				DataSet dsToAddressInfo = getQueryProcessor().getSqlDataSet(emailtobyqry);
				if (dsToAddressInfo != null && dsToAddressInfo.size() > 0) {
					String colsArr[] = dsToAddressInfo.getColumns();
					if (colsArr.length > 1) {
						logger.info(
								"Cannot obtained the To Email Address from the Query, as multiple columns found inthe select statement of the query");
					} else if (colsArr.length == 1) {
						resultToEmailId += ";" + dsToAddressInfo.getColumnValues(colsArr[0], ";");
					}
				}
			}

		}
		if (!Util.isNull(resultToEmailId)) {
			if (resultToEmailId.startsWith(";"))
				resultToEmailId = resultToEmailId.substring(1);
		}

		return resultToEmailId;
	}

	private String getCCEmailId(PropertyList properties, PropertyList mailconfigProp) throws SapphireException {
		String resultCCEmailId = "";
		if (properties != null && properties.size() > 0) {
			String tempCCList = properties.getProperty(EMAILCCLIST, "");
			if (!Util.isNull(tempCCList))
				resultCCEmailId += ";" + tempCCList;
		}
		if (mailconfigProp != null && mailconfigProp.size() > 0) {

			PropertyListCollection emailcclist = mailconfigProp.getCollection("emailcclist");
			if (emailcclist != null && emailcclist.size() > 0) {
				for (int i = 0; i < emailcclist.size(); i++) {
					PropertyList tempPl = emailcclist.getPropertyList(i);
					if (tempPl != null && tempPl.size() > 0) {
						String tempCCAddress = tempPl.getProperty("emailccaddress", "");
						if (!Util.isNull(tempCCAddress))
							resultCCEmailId += ";" + tempCCAddress;
					}
				}
			}
			String emailccbyqry = mailconfigProp.getProperty("emailccbyqry", "");
			if (!Util.isNull(emailccbyqry)) {
				DataSet dsCCAddressInfo = getQueryProcessor().getSqlDataSet(emailccbyqry);
				if (dsCCAddressInfo != null && dsCCAddressInfo.size() > 0) {
					String colsArr[] = dsCCAddressInfo.getColumns();
					if (colsArr.length > 1) {
						logger.info(
								"Cannot obtained the CC Email Address from the Query, as multiple columns found in the select statement of the query");
					} else if (colsArr.length == 1) {
						resultCCEmailId += ";" + dsCCAddressInfo.getColumnValues(colsArr[0], ";");
					}
				}
			}

		}
		if (!Util.isNull(resultCCEmailId)) {
			if (resultCCEmailId.startsWith(";"))
				resultCCEmailId = resultCCEmailId.substring(1);
		}

		return resultCCEmailId;
	}

	private String getFromEmailId(PropertyList properties, PropertyList mailconfigProp) throws SapphireException {
		String resultFromEmailId = "";
		if (properties != null && properties.size() > 0) {
			String tempFromList = properties.getProperty(EMAILFROM, "");
			if (!Util.isNull(tempFromList))
				resultFromEmailId += ";" + tempFromList;
		}
		if (!Util.isNull(resultFromEmailId)) {
			if (resultFromEmailId.startsWith(";"))
				resultFromEmailId = resultFromEmailId.substring(1);
			return resultFromEmailId;
		}
		if (mailconfigProp != null && mailconfigProp.size() > 0) {
			String emailfromid = mailconfigProp.getProperty("emailfromid", "");
			if (!Util.isNull(emailfromid)) {
				return emailfromid;
			}
			String emailfrombyqry = mailconfigProp.getProperty("emailfrombyqry", "");
			if (!Util.isNull(emailfrombyqry)) {
				// emailfrombyqry=getProperString(properties,emailfrombyqry);
				DataSet dsFROMAddressInfo = getQueryProcessor().getSqlDataSet(emailfrombyqry);
				if (dsFROMAddressInfo != null && dsFROMAddressInfo.size() > 0) {
					String colsArr[] = dsFROMAddressInfo.getColumns();
					if (colsArr.length > 1) {
						logger.info(
								"Cannot obtained the From Email Address from the Query, as multiple columns found in the select statement of the query");
					} else if (colsArr.length == 1) {
						resultFromEmailId += ";" + dsFROMAddressInfo.getColumnValues(colsArr[0], ";");
					}
				}
			}

		}
		if (!Util.isNull(resultFromEmailId)) {
			if (resultFromEmailId.startsWith(";"))
				resultFromEmailId = resultFromEmailId.substring(1);
		} else
			resultFromEmailId = getConnectionProcessor()
					.getConfigProperty("com.labvantage.sapphire.server.emailfromaddress");

		return resultFromEmailId;
	}

}
