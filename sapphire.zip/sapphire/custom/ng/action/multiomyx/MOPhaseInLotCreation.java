/**
 * 
 */
package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class MOPhaseInLotCreation extends BaseAction implements MOConstants{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String regLotId = properties.getProperty("reglotid", "");
		
		PropertyList pl = new  PropertyList();
		pl.setProperty(AddSDI.PROPERTY_SDCID, "LV_ReagentLot");
		pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
		pl.setProperty( AddSDI.PROPERTY_TEMPLATEID, regLotId);
		pl.setProperty("expirydt", "(null)");
		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
		
		String newLotId = pl.getProperty(AddSDI.RETURN_NEWKEYID1,"");
		properties.setProperty("newlotid", newLotId);
		
		String sql = Util.parseMessage(MultiomyxSql.GET_CLONE_FROM_LOT, regLotId);
		String cloneId="";
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds == null ){
			throw new SapphireException("The below query cannot be executed.\n"+sql);
		}
		cloneId = ds.getValue(0,"cloneid", "");
		pl.clear();
		pl.setProperty(AddSDI.PROPERTY_SDCID, "MOCloneReagentLotMap");
		pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
		if(!Util.isNull(cloneId)){
			pl.setProperty("cloneid", cloneId);
		}
		pl.setProperty("reagentlotid", newLotId);
		pl.setProperty("parentreagentlotid", regLotId);
		pl.setProperty("operation", PHASEIN);
		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
		
	}
}
