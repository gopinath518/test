package sapphire.custom.ng.action.multiomyx;

import com.labvantage.sapphire.actions.storage.EditTrackItem;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class MOAddMultipleReagents extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {

        String sdcid = properties.getProperty("sdcid", "");
        String copies = properties.getProperty("copies", "");
        String reagenttypeid = properties.getProperty("reagenttypeid", "");
        String u_methodology = properties.getProperty("u_methodology", "");
        String u_molottype = properties.getProperty("u_molottype", "");
        String expirydt = properties.getProperty("expirydt", "");
        String u_stockconc = properties.getProperty("u_stockconc", "");
        String reagentlotdesc = properties.getProperty("reagentlotdesc", "");
        String u_vendorlot = properties.getProperty("u_vendorlot", "");
        String receiveddt = properties.getProperty("receiveddt", "");
        String receivedby = properties.getProperty("receivedby", "");
        String u_ltstoragetemp = properties.getProperty("u_ltstoragetemp", "");
        String u_phasein = properties.getProperty("u_phasein", "");
        String u_rgtlottype = properties.getProperty("u_rgtlottype", "");
        String vendoritemid = properties.getProperty("vendoritemid", "");
        String supplieraddressid = properties.getProperty("supplieraddressid", "");
        String manufactureraddressid = properties.getProperty("manufactureraddressid", "");
        String reagentclass = properties.getProperty("reagentclass", "");
        String reagenttypeversionid = properties.getProperty("reagenttypeversionid", "");
        String u_morgtsample = properties.getProperty("u_morgtsample", "");
        String u_origconunit = properties.getProperty("u_origconunit", "");
        String qtyunits = properties.getProperty("qtyunits", "");
        String qutcurrent = properties.getProperty("qutcurrent", "");

        if (Util.isNull(sdcid))
            throw new SapphireException("SDC couldnot be blank.");
        if (Util.isNull(reagenttypeid))
            throw new SapphireException("Reagent type couldnot be blank.");
        if (Util.isNull(u_methodology))
            throw new SapphireException("Methodology couldnot be blank.");
        if (Util.isNull(reagentclass))
            throw new SapphireException("Regent Class couldnot be blank.");
        if (Util.isNull(reagenttypeversionid))
            throw new SapphireException("Reagent type version couldnot be blank.");
        if (Util.isNull(u_molottype))
            throw new SapphireException("Lot type couldn't be blank.");
        if (Util.isNull(expirydt))
            throw new SapphireException("Expiry Dt couldn't be blank.");
        if (Util.isNull(qutcurrent))
            throw new SapphireException("Reagents amount couldn't be blank.");

        int number = Integer.parseInt(copies);
        String newReagents = "";

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, sdcid);
        pl.setProperty("reagenttypeid", reagenttypeid);
        pl.setProperty("u_methodology", u_methodology);
        pl.setProperty("u_molottype", u_molottype);
        pl.setProperty("expirydt", expirydt);
        pl.setProperty("u_stockconc", u_stockconc);
        pl.setProperty("reagentlotdesc", reagentlotdesc);
        pl.setProperty("u_vendorlot", u_vendorlot);
        pl.setProperty("receiveddt", receiveddt);
        pl.setProperty("receivedby", receivedby);
        pl.setProperty("u_ltstoragetemp", u_ltstoragetemp);
        pl.setProperty("u_phasein", u_phasein);
        pl.setProperty("u_rgtlottype", u_rgtlottype);
        pl.setProperty("vendoritemid", vendoritemid);
        pl.setProperty("supplieraddressid", supplieraddressid);
        pl.setProperty("manufactureraddressid", manufactureraddressid);
        pl.setProperty("reagentclass", reagentclass);
        pl.setProperty("reagenttypeversionid", reagenttypeversionid);
        pl.setProperty("u_morgtsample", u_morgtsample);
        pl.setProperty("u_origconunit", u_origconunit);

        for (int i = 0; i < number; i++) {
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
                newReagents += ";" + pl.getProperty("newkeyid1");

            } catch (Exception e) {
                throw new SapphireException("Unable to add record in LV ReagentLot.");
            }
        }
        if (!Util.isNull(newReagents))
            newReagents = newReagents.substring(1);

        properties.setProperty("newkeyid1", newReagents);
        pl.clear();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, newReagents);
        pl.setProperty("qtycurrent", qutcurrent);
        pl.setProperty("qtyunits", qtyunits);
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        } catch (Exception e) {
            throw new SapphireException("Unable to add record in LV ReagentLot." + e.getMessage());
        }


    }
}
