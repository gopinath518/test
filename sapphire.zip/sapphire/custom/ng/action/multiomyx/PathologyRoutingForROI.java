package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class PathologyRoutingForROI extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid=properties.getProperty("sampleid","");
        if(Util.isNull(sampleid))
            throw new SapphireException("Please select atleast one sample.");
        assignSampleToPathologyDept(sampleid);
    }

    private void assignSampleToPathologyDept(String sampleid) throws SapphireException{
        if(!Util.isNull(sampleid)){
            String currentUsrdepartment = connectionInfo.getDefaultDepartment();
            if(!Util.isNull(currentUsrdepartment)) {
                String site = StringUtil.split(currentUsrdepartment, "-")[0];
                if(!Util.isNull(site)){
                    String destDept=site+"-"+"Pathology";
                    PropertyList pl=new PropertyList();
                    pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1,sampleid);
                    pl.setProperty("u_currentmovementstep","MOPathology");

                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);

                    pl.clear();
                    pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID,"Sample");
                    pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1,sampleid);
                    pl.setProperty("custodialdepartmentid",destDept);
                    pl.setProperty("custodialuserid","(null)");
                    pl.setProperty("currentstorageunitid","(null)");
                    pl.setProperty("u_currenttramstop", "MOPathology");

                    getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID,pl);
                }
            }
        }
    }
}
