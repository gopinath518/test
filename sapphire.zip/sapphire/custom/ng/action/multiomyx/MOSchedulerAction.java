package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;

public class MOSchedulerAction extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = "";
        DataSet dsSample = new DataSet();
        if (properties.containsKey("sampleid")) {
            sampleids = properties.getProperty("sampleid");
        }

        if (Util.isNull(sampleids)) {
            dsSample = getQueryProcessor().getSqlDataSet(MultiomyxSql.GET_SAMPLE_FOR_SCHEDULER);
        } else {
            sampleids = Util.getUniqueList(sampleids, ";", true);
            dsSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(MultiomyxSql.GET_SAMPLE_FOR_SCHEDULER + " and s.s_sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "')"));
        }

        if ((dsSample != null) && (dsSample.getRowCount() > 0)) {
            dsSample.sort("s_sampleid");
            ArrayList<DataSet> dsSampleArr = dsSample.getGroupedDataSets("s_sampleid");
            if (dsSampleArr != null && dsSampleArr.size() > 0) {
                PropertyList pl = new PropertyList();
                for (int i = 0; i < dsSampleArr.size(); i++) {
                    DataSet tempDS = dsSampleArr.get(i);
                    if (tempDS != null && tempDS.size() > 0) {
                        pl.clear();
                        pl.setProperty("slideid", tempDS.getColumnValues("s_sampleid", ","));
                        pl.setProperty("protocol", tempDS.getColumnValues("u_moprotocol", ","));
                        pl.setProperty("stmprotocol", tempDS.getColumnValues("moprotocol", ","));
                        pl.setProperty("protocoltype", tempDS.getColumnValues("u_moprotocoltype", ","));
                        pl.setProperty("prevprotocoltype", tempDS.getColumnValues("u_prevmoprotocoltype", ","));
                        pl.setProperty("protocolstatus", tempDS.getColumnValues("u_moprotocolstatus", ","));
                        pl.setProperty("stmprotocoltype", tempDS.getColumnValues("moprotocoltype", ","));
                        pl.setProperty("prevstmprotocoltype", tempDS.getColumnValues("prevmoprotocoltype", ","));
                        pl.setProperty("status", tempDS.getColumnValues("status", ","));
                        pl.setProperty("batchid", tempDS.getColumnValues("batchid", ","));
                        pl.setProperty("teststatus", tempDS.getColumnValues("teststatus", ","));
                        pl.setProperty("lvtestpanelid", tempDS.getColumnValues("lvtestpanelid", ","));
                        pl.setProperty("lvtestcodeid", tempDS.getColumnValues("lvtestcodeid", ","));
                        pl.setProperty("u_sampletestcodemapid", tempDS.getColumnValues("u_sampletestcodemapid", ","));
                        pl.setProperty("pendingtest", tempDS.getColumnValues("pendingtest", ","));
                        pl.setProperty("qc", tempDS.getColumnValues("qc", ","));
                        pl.setProperty("operationName", "getSlideStatus");
//                        pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, "MOLWSAction");
//                        pl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, "1");
//                        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, pl);
                        getActionProcessor().processAction("MOLWSAction", "1", pl);
                    }
                }
            }
        }
    }

}