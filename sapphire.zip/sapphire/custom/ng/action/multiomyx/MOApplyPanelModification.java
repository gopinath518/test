package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import static sapphire.util.StringUtil.repeat;

public class MOApplyPanelModification extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String panelid = properties.getProperty("panelid", "");
        String moqcpass = properties.getProperty("moqcpass", "");
        String panelFinal = "";
        if (Util.isNull(panelid))
            throw new SapphireException("Panel id couldn't be blank.");
        if (!moqcpass.equalsIgnoreCase("Y"))
            throw new SapphireException("QC Pass is not done.");
        String getSampleIDsql = Util.parseMessage(MultiomyxSql.GET_SAMPLE_FROM_PANELID, panelid.replaceAll(";", "','"));
        DataSet dsSampleid = getQueryProcessor().getSqlDataSet(getSampleIDsql);
        if (dsSampleid != null && dsSampleid.size() > 0) {
            String protocolAll = Util.getUniqueList(dsSampleid.getColumnValues("u_moprotocolid", ";"), ";", true);
            String protocolArr[] = protocolAll.split(";");
            for (int i = 0; i < protocolArr.length; i++) {
                String protocol = dsSampleid.getValue(i, "u_moprotocolid");
                if (!Util.isNull(protocol))
                    throw new SapphireException("Multiplexing workflow started for one or more sample(s)");
            }
            String sampleAll = Util.getUniqueList(dsSampleid.getColumnValues("s_sampleid", ";"), ";", true);
            String panelAll = Util.getUniqueList(dsSampleid.getColumnValues("lvtestpanelid", ";"), ";", true);

            String[] samplearr = sampleAll.split(";");
            if (!panelAll.contains(";"))
                panelFinal = StringUtil.repeat(panelAll, samplearr.length, ";");
            else {
                String panelArr[] = panelAll.split(";");
                for (int i = 0; i < panelArr.length; i++) {
                    panelFinal += ";" + StringUtil.repeat(panelArr[i], samplearr.length, ";");

                }
            }
            if (panelFinal.startsWith(";"))
                panelFinal = panelFinal.substring(1);


            PropertyList pl = new PropertyList();
            pl.setProperty("sampleid", sampleAll);
            pl.setProperty("panelid", panelid);
            try {
                getActionProcessor().processAction("MOPanelDeletion", "1", pl);
            } catch (Exception ae) {
                throw new SapphireException("Error: Unable to Process MOPanelDeletion: " + ae.getMessage());
            }
            pl.clear();
            pl.setProperty("s_sampleid", sampleAll);
            pl.setProperty("lvtestcode", panelFinal);
            pl.setProperty("ispanel", "Y");
            try {
                getActionProcessor().processAction("AddTestCode", "1", pl);
            } catch (Exception ae) {
                throw new SapphireException("Error: Unable to Process AddTestCode: " + ae.getMessage());
            }


        }
    }
}
