/**
 * 
 */
package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class MOCSMovementToWetLab extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sampleId = properties.getProperty("sampleid", "");
		String movementStep = properties.getProperty("movementstep", "");
		if(Util.isNull(sampleId)){
			throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_FAILURE, "No control slide is found");
		}
		
		if(Util.isNull(movementStep)){
			throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_FAILURE, "Movementstep is not defined for the selected control slide");
		}
		if(!Util.isNull(sampleId) && !Util.isNull(movementStep)){
			PropertyList pl = new PropertyList();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
			pl.setProperty("u_currentmovementstep", movementStep);
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
			
			pl.clear();
			pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
			pl.setProperty("custodialuserid", "(null)");
			pl.setProperty("u_currenttramstop", movementStep);
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
			
		}
	}
}
