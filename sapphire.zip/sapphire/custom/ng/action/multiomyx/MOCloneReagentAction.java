package sapphire.custom.ng.action.multiomyx;

import com.labvantage.sapphire.actions.sdi.AddSDI;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class MOCloneReagentAction extends BaseAction implements MOConstants {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String reagentLotId = properties.getProperty("reagentlotid", "");
		String cloneId = properties.getProperty("cloneid", "");
		
		PropertyList pl = new PropertyList();
		if(!Util.isNull(reagentLotId) && !Util.isNull(cloneId)){
			pl.setProperty(AddSDI.PROPERTY_SDCID, "MOCloneReagentLotMap");
			pl.setProperty("reagentlotid", reagentLotId);
			pl.setProperty("cloneid", cloneId);
			pl.setProperty("approveddt", "n");
			pl.setProperty("approvedby", connectionInfo.getSysuserId());
			pl.setProperty("operation", DOWNSELECTION);
			getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
		}
		
		
	}
}
