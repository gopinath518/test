package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by aritra.banerjee on 10/16/2017.
 * This class updates Protocol Name in Sample and SampleTestCodeMap SDC.
 */
public class MOPrtclStpAssociation extends BaseAction implements MOConstants {


    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String stepid = properties.getProperty("stepid", "");
        String tramstop = properties.getProperty("tramstop", "");

        String sql = Util.parseMessage(MultiomyxSql.GET_PROTOCOL_BY_STEPID, StringUtil.replaceAll(stepid, ";", "','"));
        DataSet dsResult = getQueryProcessor().getSqlDataSet(sql);

        if(dsResult == null)
            throw new SapphireException("Error: Unable to fetch Protocol Details.");
        if(dsResult.size() == 0)
            throw new SapphireException("Error: No Protocol Details defined in Master Data / Step Id not properly defined..");

        if(dsResult.size() > 0){

            if("Stain".equalsIgnoreCase(tramstop) || "Bleach".equalsIgnoreCase(tramstop)){
                // This method gets called from  Stain and Bleach tramstops which are SampleTestCodeMap based tramstop.
                editSampleandSTMSdc(properties, dsResult);
            }
            else if("SlideList".equalsIgnoreCase(tramstop) || "ImageROI".equalsIgnoreCase(tramstop)){
                // This method gets called from  other tramstops which are Sample based tramstop
                editSampleSdc(properties, dsResult);
            } else {
                throw new SapphireException("Error: Please provide proper Tramstop details.");
            }
        }

    }

    /**
     * This method updates protocol name for the selected samples in Sample SDC .
     * @param props which contains sample details
     * @param dsResult which contains protocol details
     * @throws SapphireException
     */
    private void editSampleSdc(PropertyList props, DataSet dsResult) throws SapphireException {

        if(!Util.isNull(props.getProperty("sampleid",""))){
            String sampleid = Util.getUniqueList(props.getProperty("sampleid"), ";", true);
            try {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                updateProp.setProperty("u_moprotocol", dsResult.getValue(0,"protocolname"));


                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to edit protocol in Sample.");
            }
        }
    }

    /**
     * This method updates protocol name in Sample and SmapleTestCodeMap SDC.
     * @param props which contains sample and sampletestcodeid details
     * @param dsResult which contains protocol details
     * @throws SapphireException
     */

    private void editSampleandSTMSdc(PropertyList props, DataSet dsResult) throws SapphireException {

        if(!Util.isNull(props.getProperty("sampleid",""))){
            String sampleid = Util.getUniqueList(props.getProperty("sampleid"), ";", true);
            try {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                updateProp.setProperty("u_moprotocol", dsResult.getValue(0,"protocolname"));


                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to edit protocol in Sample.");
            }
        }

        if(!Util.isNull(props.getProperty("stmid",""))){
            String stmid = Util.getUniqueList(props.getProperty("stmid"), ";", true);
            if(stmid.contains("#semicolon#")) {
                stmid = StringUtil.replaceAll(stmid, "#semicolon#", ";");
            }
            try {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, stmid);
                updateProp.setProperty("moprotocol", dsResult.getValue(0,"protocolname"));


                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to edit protocol in SampleTestCodeMap.");
            }
        }
    }
}
