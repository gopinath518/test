package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class MOControlSampleAction extends BaseAction {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		if(properties.isEmpty()){
			throw new SapphireException("Properties are empty");
		}
		String batchId = properties.getProperty("mobatchid", "");
		String panelId = properties.getProperty("mopanelid", "");
		//String controlType = properties.getProperty("mocontroltype", "");
		String controlSample = properties.getProperty("mocontrolsample", "");
		String moveToAnalytics = properties.getProperty("movetoanalytics", "");
		String projectId = "";
		
		String sql = Util.parseMessage(MultiomyxSql.MO_PROJECTID_BY_PANELID, StringUtil.replaceAll(panelId, ";", "','"));
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.getRowCount() > 0){
			projectId = ds.getColumnValues("projectid", ";");
		}
		
		DataSet newDS = new DataSet();
		newDS.addColumnValues("mobatchid",  DataSet.STRING, batchId, ";");
		newDS.addColumnValues("mopanelid", DataSet.STRING, panelId, ";");
		newDS.addColumnValues("mocontrolsample", DataSet.STRING, controlSample, ";");
		newDS.addColumnValues("movetoanalytics", DataSet.STRING, moveToAnalytics, ";");
		//newDS.addColumnValues("moprojectid", DataSet.STRING, projectId, ";");
		
		if(newDS != null && newDS.getRowCount() > 0){
			
			String existingControlSql = Util.parseMessage(MultiomyxSql.MO_GET_SLIDE_TYPE_FROM_BATCH, newDS.getValue(0, "mobatchid", ""));
			DataSet existingDS = getQueryProcessor().getSqlDataSet(existingControlSql);
			if(existingDS != null && existingDS.getRowCount() > 0){
				String slideTypes = existingDS.getColumnValues("u_type", ";")+";"+newDS.getColumnValues("mocontroltype", ";");
				
				String[] numberOfMetC = StringUtil.split(slideTypes, "METC");
				if(numberOfMetC != null && numberOfMetC.length > 2){
					throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_VALIDATION, "Only one Met Control Slide should be created.");
				}
				
				String[] numberOfTonC = StringUtil.split(slideTypes, "TONC");
				if(numberOfTonC != null && numberOfTonC.length > 2){
					throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_VALIDATION, "Only one Tonsil Control Slide should be created.");
				}
			}
			
			
			/*String masterSampleSql = Util.parseMessage(MultiomyxSql.MO_GET_MASTER_SAMPLE_INFO_FOR_CONTROL_SAMPLE, newDS.getValue(0, "mobatchid", ""));
			DataSet masterDS = getQueryProcessor().getSqlDataSet(masterSampleSql);
			if(masterDS != null && masterDS.getRowCount() > 0){
				/**//*Sample table AddSDI --- u_type, u_mostatus,*//*
				PropertyList samplePl = new PropertyList();
				samplePl.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
				samplePl.setProperty(AddSDI.PROPERTY_COPIES, ""+newDS.getRowCount());
				samplePl.setProperty("u_type", newDS.getColumnValues("mocontroltype", ";"));
				samplePl.setProperty("u_mostatus", StringUtil.repeat(masterDS.getColumnValues("u_mostatus", ";"), newDS.getRowCount(), ";"));
				samplePl.setProperty("u_currentmovementstep", StringUtil.repeat(masterDS.getColumnValues("u_currentmovementstep", ";"), newDS.getRowCount(), ";"));
				samplePl.setProperty("sstudyid", StringUtil.repeat(masterDS.getColumnValues("sstudyid", ";"), newDS.getRowCount(), ";"));
				samplePl.setProperty("storagestatus", StringUtil.repeat(masterDS.getColumnValues("storagestatus", ";"), newDS.getRowCount(), ";"));
				samplePl.setProperty("u_movetoanalytics", newDS.getColumnValues("movetoanalytics", ";"));
				getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, samplePl);
				
				String newSampleList = samplePl.getProperty(AddSDI.RETURN_NEWKEYID1);*/
				/*Sample table AddSDI*/
			try {
				PropertyList samplePl = new PropertyList();
				samplePl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
				//samplePl.setProperty(EditSDI.PROPERTY_KEYID1, controlType);
				samplePl.setProperty(EditSDI.PROPERTY_KEYID1, newDS.getColumnValues("mocontrolsample", ";"));
				samplePl.setProperty("u_movetoanalytics", newDS.getColumnValues("movetoanalytics", ";"));
				samplePl.setProperty("u_currentmovementstep", "MOQCSample");
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, samplePl);
			} catch (ActionException ae) {
				throw new SapphireException("Error: Unable to Edit Data into Sample. Reason: " + ae.getMessage());
			}
			//String newSampleList = controlType;

				
				if(!Util.isNull(controlSample)){
					/*EditSDI with TrackItem*/
					PropertyList atiPl = new PropertyList();
					atiPl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
					atiPl.setProperty(EditTrackItem.PROPERTY_KEYID1, controlSample);
					atiPl.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
					atiPl.setProperty("custodialuserid", connectionInfo.getSysuserId());
					atiPl.setProperty("containertypeid", "Slide(s)");
					atiPl.setProperty("currentstorageunitid", "(null)");
					//atiPl.setProperty("u_currenttramstop", masterDS.getColumnValues("u_currentmovementstep", ";"));
					atiPl.setProperty("u_currenttramstop","MOQCSample");
					getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, atiPl);
					/*EditSDI with TrackItem*/
					
					
					/*AssignTestCode with panelId*/
					PropertyList atcPl = new PropertyList();
					atcPl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, newDS.getColumnValues("mocontrolsample", ";"));
					atcPl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, newDS.getColumnValues("mopanelid", ";"));
					atcPl.setProperty(AssignTestCode.INPUT_PROPERTY_IS_PANEL, "Y");
					getActionProcessor().processAction("AssignTestCode", "1", atcPl);
					/*AssignTestCode with panelId*/
					
					/*u_modetailbatch AddSDI*/
					PropertyList batchProps = new PropertyList();
					batchProps.setProperty(AddSDI.PROPERTY_SDCID, "MODetailBatch");
					batchProps.setProperty(AddSDI.PROPERTY_COPIES, ""+newDS.getRowCount());
					batchProps.setProperty("u_mobatchid", newDS.getColumnValues("mobatchid", ";"));
					batchProps.setProperty("mosampleid", newDS.getColumnValues("mocontrolsample", ";"));
					getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, batchProps);
					/*u_modetailbatch AddSDI*/
				}
			//}
		}
		
		
	}
}
