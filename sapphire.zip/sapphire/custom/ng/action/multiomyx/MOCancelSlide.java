package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

import static sapphire.custom.ng.util.Util.isNull;

public class MOCancelSlide extends BaseAction{

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        // TODO Auto-generated method stub

        try{
            String sampleIds = properties.getProperty("sampleid");
            if(isNull(sampleIds)){
                throw new SapphireException("Please select valid sample");
            }
            PropertyList sampleProperty = new PropertyList();
            sampleProperty.setProperty("operationName", "cancelSlide");
            sampleProperty.setProperty("sampleIdList", sampleIds);
            getActionProcessor().processAction("MOLWSAction", "1", sampleProperty);
        }catch(Exception e){
            throw new SapphireException(e.getMessage());
        }
    }

}
