/**
 * 
 */
package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class MOStainCompleteAction extends BaseAction{
	/* (non-Javadoc)
	 * @see sapphire.action.BaseAction#processAction(sapphire.xml.PropertyList)
	 */
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		try {
			if(properties.isEmpty()){
				throw new SapphireException("No properties found");
			}else{
				String stmId = properties.getProperty("stmId");
				String testcodeId = properties.getProperty("testcodeId");
				String opertationName = properties.getProperty("operationName");
				String sampleId = properties.getProperty("sampleId");
				String sampleSDC = properties.getProperty("sampleSDC");
				String moReceiveComment = properties.getProperty("moReceiveComment");
				String moStatus = properties.getProperty("moStatus");
				String auditReason = properties.getProperty("auditReason");
				String stmSDC = properties.getProperty("stmSDC");
				String testStatus = properties.getProperty("testStatus");

				String sql = Util.parseMessage(MultiomyxSql.SIBLING_SAMPLETESTCODEMAPIS_BY_SAMPLETESTCODEMAPID, StringUtil.replaceAll(stmId, ";", "','"));
				DataSet dsTestStatus = getQueryProcessor().getSqlDataSet(sql);

				if (dsTestStatus == null || dsTestStatus.size() == 0)
					throw new SapphireException("Error: Unable to fetch  Test Status from sampletestcodemap.");

				//SlideReagentAssociation
				PropertyList sraProps = new PropertyList();
				sraProps.setProperty("sampletestcodemapid", dsTestStatus.getColumnValues("u_sampletestcodemapid",";"));
				sraProps.setProperty("testcode", dsTestStatus.getColumnValues("lvtestcodeid",";"));
				getActionProcessor().processAction("SlideReagentAssociation", "1", sraProps);
				//MOLWSAction
				PropertyList molwsProps = new PropertyList();
				molwsProps.setProperty("operationName", opertationName);
				molwsProps.setProperty("slideid", Util.getUniqueList(dsTestStatus.getColumnValues("s_sampleid",";"),";",true));
				getActionProcessor().processAction("MOLWSAction", "1", molwsProps);
				//EditSDI for Sample
				PropertyList sampleProps = new PropertyList();
				sampleProps.setProperty(EditSDI.PROPERTY_SDCID, sampleSDC);
				sampleProps.setProperty(EditSDI.PROPERTY_KEYID1, Util.getUniqueList(dsTestStatus.getColumnValues("s_sampleid",";"),";",true));
				sampleProps.setProperty("u_moreceivecomment", moReceiveComment);
				sampleProps.setProperty("u_mostatus", moStatus);
				sampleProps.setProperty("auditreason", auditReason);
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, sampleProps);
				//EditSDI for SampleTestCodeMap
				PropertyList stmProps = new PropertyList();
				stmProps.setProperty(EditSDI.PROPERTY_SDCID, stmSDC);
				stmProps.setProperty(EditSDI.PROPERTY_KEYID1, dsTestStatus.getColumnValues("u_sampletestcodemapid",";"));
				stmProps.setProperty("teststatus", testStatus);
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, stmProps);

				PropertyList autoCustodyProp=new PropertyList();
				autoCustodyProp.setProperty("sampleid",Util.getUniqueList(dsTestStatus.getColumnValues("s_sampleid",";"),";",true));
				getActionProcessor().processAction("AutoCustodyTransfer","1",autoCustodyProp);
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new SapphireException(e.getMessage());
		}
	}
}
