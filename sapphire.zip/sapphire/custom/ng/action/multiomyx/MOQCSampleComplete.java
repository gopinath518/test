package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by aritra.banerjee on 10/25/2017.
 * This Action is called when Complete button is clicked from QC Sample tramstop in MO Wet lab
 */
public class MOQCSampleComplete extends BaseAction {


    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("sampleid", "");

        if (Util.isNull(sampleid))
            throw new SapphireException("Error: Sample Id missing..");

        sampleid = Util.getUniqueList(sampleid, ";", true);

        if (!Util.isNull(sampleid)) {
            updateSlide(sampleid);
        }
    }

    /**
     * This method callse WS methods from MOLWSAction Action
     * and updates mostatus and protocol name
     * in the end , it executes auto routing logic by implementing FlowCompleteStep Action
     * @param sampleid
     * @throws SapphireException
     */

    private void updateSlide(String sampleid) throws SapphireException {

        calWSMethod(sampleid);


        if(!Util.isNull(sampleid)){
            try {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                updateProp.setProperty("u_mostatus", "QCPassed");
                updateProp.setProperty("u_moprotocolid", "1.2.1");
                updateProp.setProperty("u_moprotocol", "Slide Prep");
                updateProp.setProperty("u_moprotocoltype", "Procedure");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to edit mo status in Sample.");
            }


            //********** Routing Logic
            try {
                PropertyList pl = new PropertyList();
                pl.setProperty("sampleid", sampleid);

                getActionProcessor().processAction("FlowCompleteStep", "1", pl);

            } catch (Exception ex) {
                throw new SapphireException("Error while Routing. Error : "+ex.getMessage());
            }
        }
    }

    /**
     * This method callse WS methods from MOLWSAction Action
     * @param sampleid
     * @throws SapphireException
     */
    private void calWSMethod(String sampleid) throws SapphireException {

        PropertyList props = new PropertyList();

        try {
            props.setProperty("operationName","registerSlide");
            props.setProperty("slideid",sampleid);

            getActionProcessor().processAction("MOLWSAction", "1", props);

        } catch (Exception ex) {
            throw new SapphireException("Error while calling registerSlide WS. "+ex.getMessage());
        }
        props.clear();

        String sql = Util.parseMessage(MultiomyxSql.GET_NOT_REGISTERED_BATCH, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsStatus = getQueryProcessor().getSqlDataSet(sql);

        if (dsStatus == null)
            throw new SapphireException("Error: Unable to execute Query.");
        if (dsStatus.size() == 0)
            return;

        try {
            sampleid = Util.getUniqueList(dsStatus.getColumnValues("mosampleid",";"), ";", true);
            props.setProperty("operationName","submitBatch");
            props.setProperty("slides",sampleid);

            getActionProcessor().processAction("MOLWSAction", "1", props);

        } catch (Exception ex) {
            throw new SapphireException("Error while calling submitBatch WS. "+ex.getMessage());
        }


    }


}
