package sapphire.custom.ng.action.multiomyx;

import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class MOReagentMarkerRollbackApproval extends BaseAction implements MOConstants{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String moRegMarkerSelId = properties.getProperty("moregmarkerselid", "");
		String regLotId = properties.getProperty("reglotid", "");
		String ops = properties.getProperty("operation", "");
		
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "MORegMarkerSelAudit");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, moRegMarkerSelId);
		pl.setProperty("approvedby", "(null)");
		pl.setProperty("approveddt", "(null)");
		pl.setProperty("approvalstatus", "(null)");
		pl.setProperty("approvalcomments", "(null)");
		//pl.setProperty("workingconcentration", "(null");
		//pl.setProperty("workconunit", "(null)");
		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSION, pl);
		
		if(!Util.isNull(ops) 
				&& !BLEACH_SUFFICIENCY.equalsIgnoreCase(ops) && !ANTIGEN_EFFECTS.equalsIgnoreCase(ops)){
			pl.clear();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "LV_ReagentLot");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, regLotId);
			pl.setProperty("u_workconc", "(null)");
			pl.setProperty("u_workconunit", "(null)");
			if(DOWNSELECTION.equalsIgnoreCase(ops)){
				pl.setProperty("u_downselapproved", "(null)");
			} else if(INITIALDC.equalsIgnoreCase(ops)){
				pl.setProperty("u_initdcapproved", "(null)");
			} else if(PHASEIN.equalsIgnoreCase(ops)){
				pl.setProperty("u_phaseinapproved", "(null)");
			}
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSION, pl);
		}
		
	}
}
