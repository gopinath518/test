package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class MOCreateControlSample extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String controlType = properties.getProperty("controltype", "");
		String noOfCopies = properties.getProperty("copynum", "");
		String volume = properties.getProperty("volume", "");
		String volUnit = properties.getProperty("volunit", "");
		String storageUnit = properties.getProperty("storageunit", "");
		
		PropertyList samplePl = new PropertyList();
		samplePl.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
		samplePl.setProperty(AddSDI.PROPERTY_COPIES, noOfCopies);
		samplePl.setProperty( AddSDI.PROPERTY_TEMPLATEID, controlType);
		samplePl.setProperty("u_type", controlType);
		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, samplePl);
		
		String newSampleList = samplePl.getProperty(AddSDI.RETURN_NEWKEYID1);

		
		if(!Util.isNull(newSampleList)){
			PropertyList atiPl = new PropertyList();
			atiPl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
			atiPl.setProperty(EditTrackItem.PROPERTY_KEYID1, newSampleList);
			atiPl.setProperty("u_qtyinitial", volume);
			atiPl.setProperty("u_qtyinitialunits", volUnit);
			if(Util.isNull(storageUnit)){
				atiPl.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
				atiPl.setProperty("custodialuserid", connectionInfo.getSysuserId());
			}else{
				atiPl.setProperty("custodialdepartmentid", "(null)");
				atiPl.setProperty("custodialuserid", "(null)");
				atiPl.setProperty("currentstorageunitid", storageUnit);
			}
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, atiPl);

		}

		String url="<script>sapphire.page.navigate('rc?command=page&page=MOControlList&sdcid=Sample&keyid1="+newSampleList+"','Y','_top',null);sapphire.alert('Operation Successful');</script>";
		properties.setProperty("outscript",url);
		
	}
}
