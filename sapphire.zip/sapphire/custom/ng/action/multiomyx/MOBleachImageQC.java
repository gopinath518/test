package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class MOBleachImageQC extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid","");
        String previousStatus = properties.getProperty("previousstatus","");
        String currentStatus = properties.getProperty("currentstatus","");
        String pendingTest = properties.getProperty("pendingtest","");
        String qcstatus = properties.getProperty("qcstatus","");
        String qcflag = properties.getProperty("qcflag","");
        String smpltstcdmpid = properties.getProperty("stmid", "");
        String auditreason = properties.getProperty("auditreason", "");
        String comment = properties.getProperty("comment", "");
        String batchid = properties.getProperty("mobatchid", "");
        if(Util.isNull(sampleid))
            throw new SapphireException("Select atleast one sample");
        if(Util.isNull(batchid))
            throw new SapphireException("Batch id could not be blank");

        /*Getting stm data and pendingtest-START*/
        sampleid = Util.getUniqueList(sampleid, ";", true);
        String pendingTestSql = Util.parseMessage(MultiomyxSql.STAIN_PENDING_TEST_BY_SAMPLE, sampleid);
        String stmSql = Util.parseMessage(MultiomyxSql.STM_FOR_BLEACH_BY_SAMPLE, sampleid);
        DataSet pendingTestDS = getQueryProcessor().getSqlDataSet(pendingTestSql);
        DataSet stmDS = getQueryProcessor().getSqlDataSet(stmSql);
        if(pendingTestDS != null && pendingTestDS.getRowCount() > 0){
        	pendingTest = pendingTestDS.getColumnValues("pendingtest", ";");
        }
        if(stmDS != null && stmDS.getRowCount() > 0){
        	smpltstcdmpid = stmDS.getColumnValues("qc", ";");
        }
        /*Getting stm data and pendingtest-END*/
        PropertyList props = new PropertyList();

        props.setProperty("sampleid",sampleid);
        props.setProperty( "previousstatus",previousStatus);
        props.setProperty("currentstatus", currentStatus);
        props.setProperty("pendingtest", pendingTest);
        props.setProperty("qcstatus", qcstatus);
        props.setProperty("qcflag", qcflag);
        try {
            getActionProcessor().processAction("MOBleachStainSlide","1",props);
        } catch (Exception ae) {
            throw new SapphireException("Error: Unable to Process MOBleachStainSlide: " + ae.getMessage());
        }

        props.clear();
        props.setProperty("sampleid",sampleid);
        props.setProperty( "stmid",smpltstcdmpid);
        props.setProperty("qcstatus", qcstatus);
        props.setProperty("auditreason", auditreason);
        props.setProperty("comment", comment);
        props.setProperty("bleachqc", "Y");
        try {
            getActionProcessor().processAction("MOSlideQC","1",props);
        } catch (Exception ae) {
            throw new SapphireException("Error: Unable to Process MOSlideQC: " + ae.getMessage());
        }
        props.clear();
        props.setProperty(EditSDI.PROPERTY_SDCID, "MOBatch");
        props.setProperty(EditSDI.PROPERTY_KEYID1, batchid);
        props.setProperty("firstroundqc", "Y");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ae) {
            throw new SapphireException("Error: Unable to Process EditSDI: " + ae.getMessage());
        }





    }
}
