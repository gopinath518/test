package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class MOControlSampleStore extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sampleId = properties.getProperty("sampleid", "");
		String storage = properties.getProperty("storage", "");
		
		String sql = Util.parseMessage(MultiomyxSql.GET_STORAGEUNITID, StringUtil.replaceAll(storage, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        
        if(ds != null && ds.getRowCount() > 0){
        	String storageunitid = ds.getColumnValues("storageunitid", ";");
            if(!Util.isNull(storageunitid)){
                PropertyList props = new PropertyList();
                props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
                props.setProperty("custodialuserid", "(null)");
                props.setProperty("custodialdepartmentid", "(null)");
                props.setProperty("currentstorageunitid", storageunitid);
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
            }
        }
	}
}
