package sapphire.custom.ng.action.multiomyx;

import java.util.HashMap;
import java.util.Map;

import com.labvantage.opal.validation.misc.ConvertUnits;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * 
 * @author sudeepta.pal
 *
 */
public class MOInitialDCCreation extends BaseAction implements MOConstants{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String primaryLotId = properties.getProperty("initdcreglotid", "");
		String lotType = properties.getProperty("initdcreglottype", "");
		String lotQty = properties.getProperty("lotqty", "");
		String lotUnit = properties.getProperty("lotunit", "");
		String origLotType = StringUtil.split(lotType,"|")[0];
		String regClass ="";
		String query = Util.parseMessage(MultiomyxSql.GET_REG_CLASS_FROM_REG_TYPE, origLotType);
		DataSet rs = getQueryProcessor().getSqlDataSet(query);
		if(rs != null && rs.getRowCount() > 0){
			regClass = rs.getColumnValues("reagentclass", ";");
		}
		
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDI.PROPERTY_SDCID, "LV_ReagentLot");
		pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
		//pl.setProperty(AddSDI.PROPERTY_TEMPLATEID,primaryLotId);
		//pl.setProperty("expirydt", "(null)");
		pl.setProperty("reagenttypeid", origLotType);
		pl.setProperty("reagentlotdesc", origLotType);
		pl.setProperty("reagentclass", regClass);
		pl.setProperty("reagenttypeversionid", "1");
		pl.setProperty("u_molottype", "DC");
		pl.setProperty("u_dctype", "Initial");
		//pl.setProperty("u_conjugationdate", "n");
		pl.setProperty("u_methodology", "Multiomyx");
		pl.setProperty("u_origconunit", "ug/ml");
		pl.setProperty("u_workconunit", "ug/ml");

		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
		String initDCLotId = pl.getProperty(AddSDI.RETURN_NEWKEYID1, "");
		
		String sql = Util.parseMessage(MultiomyxSql.GET_CLONE_FROM_LOT, primaryLotId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.getRowCount() > 0){
			String cloneId = ds.getColumnValues("cloneid", ";");
			pl.clear();
			pl.setProperty(AddSDI.PROPERTY_SDCID, "MOCloneReagentLotMap");
			pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
			pl.setProperty("cloneid", cloneId);
			pl.setProperty("reagentlotid", initDCLotId);
			pl.setProperty("parentreagentlotid", primaryLotId);
			pl.setProperty("operation", INITIALDC);
			getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
			properties.setProperty("dclotid", initDCLotId);
		}
		
		String currQtyQuery = Util.parseMessage(MultiomyxSql.GET_RGT_QTY_INFO_BY_RGT_ID, primaryLotId);
		DataSet currQtyDS = getQueryProcessor().getSqlDataSet(currQtyQuery);
		if(currQtyDS != null && currQtyDS.getRowCount() > 0){
			Map<String, Double> map = new HashMap<>();
			String currQty = currQtyDS.getColumnValues("qtycurrent", ";");
			String currUnit = currQtyDS.getColumnValues("qtyunits", ";");
			String convertedQty = "";
			if(!Util.isNull(lotUnit) && !lotUnit.equalsIgnoreCase(currUnit)){
				convertedQty = ConvertUnits.convertUnits(getQueryProcessor(), currUnit, lotUnit, currQty);
			}else{
				convertedQty = currQty;
			}
			double currQtyDbl = Double.parseDouble(convertedQty);
			double reqQtyDbl = Double.parseDouble(lotQty);
			double newQty = currQtyDbl - reqQtyDbl;
			if(newQty < 0.0d){
				map.put(primaryLotId+";"+reqQtyDbl+";"+lotUnit+";"+currUnit, Double.valueOf(currQty));
			}
			String newQtyStr = String.valueOf(newQty);
			if(!Util.isNull(lotUnit) && !lotUnit.equalsIgnoreCase(currUnit)){
				newQtyStr = ConvertUnits.convertUnits(getQueryProcessor(), lotUnit, currUnit, String.valueOf(newQty));
			}
			if(!map.isEmpty()){
				String failureMsg = "The available amount of the below mentioned reagent lot is not sufficient for use \n"+
						"<table border=1>" +
						"<tr border=1><th>Reagent Lot</th><th>Required Qty</th><th>Available Qty</th></tr>";
				for (Map.Entry<String, Double> msg : map.entrySet()) {
					String[] val = StringUtil.split(msg.getKey(), ";");
					failureMsg += "<tr border=1><td>"+val[0]+"</td><td>"+val[1]+" ("+val[2]+")</td><td>"+msg.getValue()+" ("+val[3]+")</td></tr>";
				}
				failureMsg += "</table>";
				throw new SapphireException(failureMsg);
			}
			if(!Util.isNull(newQtyStr) && !Util.isNull(primaryLotId) && !Util.isNull(initDCLotId)){
				PropertyList tiPL = new PropertyList();
				tiPL.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
				tiPL.setProperty(EditTrackItem.PROPERTY_KEYID1, primaryLotId);
				tiPL.setProperty("qtycurrent", newQtyStr);
				getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, tiPL);
				
				tiPL.clear();
				tiPL.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
				tiPL.setProperty(EditTrackItem.PROPERTY_KEYID1, initDCLotId);
				tiPL.setProperty("qtycurrent", lotQty);
				tiPL.setProperty("qtyunits", lotUnit);
				getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, tiPL);
			}
		}
	}
}
