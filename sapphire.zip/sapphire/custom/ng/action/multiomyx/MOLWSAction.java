package sapphire.custom.ng.action.multiomyx;

import static sapphire.custom.ng.util.Util.isNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import org.tempuri.neogen.multiomyxintservice.LWSServiceSoap;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.handler.multiomyx.LWSServiceWSSecurityHandler;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.EncryptDecrypt;
import sapphire.custom.ng.util.GenericServiceUtil;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.util.ActionBlock;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/*****************************************************
 * This action is responsible for consuming LWS
 * SOAP service and necessary changes are being done
 * after retruning values from each operation
 * <p/>
 * Created by smitra on 10/12/2017.
 ****************************************************/
public class MOLWSAction extends BaseAction implements MOConstants {


    /****************************************************
     * This method is the entry point of calling
     * all the operations of LWS service
     *
     * @param properties
     * @throws SapphireException
     ***************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String operationName = EMPTY_STRING;
        DataSet rs = getQueryProcessor().getSqlDataSet(MultiomyxSql.GET_MO_LWS_PROPERTIES);
        String path = Util.getRemoteServicePropsData(rs, MOLWS_SERVICE_URL);
        String token = Util.getRemoteServicePropsData(rs, MOLWS_TOKEN);
        try {
            LWSServiceSoap serviceProxy = GenericServiceUtil.getLWSServiceProxy(path);
            BindingProvider bp = (BindingProvider)serviceProxy;
            List<Handler> handlerChain = new ArrayList<>();
            handlerChain.add(new LWSServiceWSSecurityHandler(EncryptDecrypt.decrypt(token)));
            //handlerChain.add(new LWSServiceWSSecurityHandler("abiyfghkgvghbkjbjklhjlhluhilhkc"));
            bp.getBinding().setHandlerChain(handlerChain);
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, path);

            operationName = properties.getProperty("operationName");
            if (isNull(operationName)) {
                throw new SapphireException("Method name can't be null or empty");
            }

            switch (operationName) {
                case "registerSlide":
                    registerSlide(properties, serviceProxy);
                    break;
                case "submitBatch":
                    submitBatch(properties, serviceProxy);
                    break;
                case "updateBatchStatus":
                    updateBatchStatus(properties, serviceProxy);
                    break;
                case "updateQCStatus":
                    updateQCStatus(properties, serviceProxy);
                    break;
                case "updateSlideStatus":
                    updateSlideStatus(properties, serviceProxy);
                    break;
                case "getSlideStatus":
                    getSlideStatus(properties, serviceProxy);
                    break;
                case "cancelSlide":
                    cancelSlide(properties, serviceProxy);
                    break;
                case "sampleRollBack":
                    sampleRollBk(properties, serviceProxy);
                    break;
                case "datasourceRestart":
                    datasourceRestart(serviceProxy);
                    break;
                case "undoCancelSlide":
                    undoCancelSlide(properties,serviceProxy);
                    break;
                default:
                    throw new SapphireException("Invalid operation obtained");
            }

        } catch (Exception e) {
            throw new SapphireException(e.getMessage());
        }
    }


//    public static void main(String[] args)throws Exception {
//        String path = "http://av1dvm-omyxw.neogen.local/MultiOmyxIntService/LWSService.asmx?wsdl";
//        LWSServiceSoap serviceProxy = GenericServiceUtil.getLWSServiceProxy(path);
//        PropertyList plSlide = new PropertyList();
//        plSlide.setProperty("slideid", "S-170210-00002");
//        plSlide.setProperty("panelname", "CAT_10x_20x");
//        plSlide.setProperty("operationName", "registerSlide");
//        MOLWSAction lws = new MOLWSAction();
//        lws.menu(plSlide,serviceProxy);
//    }
//
//    private void menu(PropertyList props, LWSServiceSoap serviceProxy) throws Exception {
//        String methodName = props.getProperty("operationName");
//        props.remove("operationName");
//        Method method = this.getClass().getDeclaredMethod(methodName, PropertyList.class, LWSServiceSoap.class);
//        method.invoke(this,props,serviceProxy);
//    }

    /*********************************************
     * This method is used to call the
     * registerSlide operation of LWS service
     *
     * @param props
     * @param proxy
     * @throws SapphireException
     ********************************************/
    private void registerSlide(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        try {
            if (props == null || props.size() == 0)
                throw new SapphireException("Input PropertyList object doesn't contain any input property.");
            String inputSlideId = props.getProperty("slideid", "");

            if (Util.isNull(inputSlideId))
                throw new SapphireException("No slide id is obtained to be registered in the Multiomyx db");

            String sql = Util.parseMessage(MultiomyxSql.SAMPLE_PANEL_INFO_BY_SAMPLEID, StringUtil.replaceAll(inputSlideId, ";", "','"));

            DataSet dsSamplePanelInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsSamplePanelInfo == null)
                throw new SapphireException("Sample Panel map info cannot be obtained from db");
            if (dsSamplePanelInfo.size() == 0)
                throw new SapphireException("Panel(s) are not added to the below sample(s)\n" + inputSlideId);

            String inputSlideIdArr[] = StringUtil.split(inputSlideId, ";");

            String disputedSlide = "";

            String combStr = dsSamplePanelInfo.getColumnValues("comb", ";");
            if (inputSlideIdArr != null && inputSlideIdArr.length > 0 && !Util.isNull(combStr)) {
                for (int i = 0; i < inputSlideIdArr.length; i++) {
                    if (combStr.indexOf(inputSlideIdArr[i]) < 0)
                        disputedSlide += ";" + inputSlideIdArr[i];
                }
            }

            if (!Util.isNull(disputedSlide)) {
                if (disputedSlide.startsWith(";"))
                    disputedSlide = disputedSlide.substring(1);
                throw new SapphireException("Below slide(s) do not have panel associated with it\n" + disputedSlide);
            }

            DataSet resultDS = new DataSet();
            resultDS.addColumn("slideid", DataSet.STRING);
            resultDS.addColumn("u_moviewerwlid", DataSet.STRING);

            DataSet disputedDS = new DataSet();
            disputedDS.addColumn("slideid", DataSet.STRING);
            disputedDS.addColumn("message", DataSet.STRING);

            for (int i = 0; i < dsSamplePanelInfo.size(); i++) {
                String tempComb = dsSamplePanelInfo.getValue(i, "comb", "");
                if (!Util.isNull(tempComb)) {
                    String tempCombArr[] = StringUtil.split(tempComb, "@*@");
                    if (tempCombArr != null && tempCombArr.length == 2) {
                        String tempSlide = tempCombArr[0];
                        String tempPanelId = tempCombArr[1];
                        if (!Util.isNull(tempSlide) && !Util.isNull(tempPanelId)) {
                            PropertyList inputProp = new PropertyList();
                            inputProp.setProperty("slideid", tempSlide);
                            inputProp.setProperty("panelname", tempPanelId);
                            String propXMLStr = inputProp.toXMLString();
                            String result = proxy.registerSlide(propXMLStr);
                            PropertyList pl = new PropertyList();
                            pl.setPropertyList(result);
                            if (pl.size() > 0) {
                                String response = pl.getProperty("response", "");
                                String slideid = pl.getProperty("slideid", "");
                                String viewerworlistid = pl.getProperty("viewerworlistid", "");
                                if (Util.isNull(response))
                                    throw new SapphireException("SOAP response does not have the response property.");
                                if ("fail".equalsIgnoreCase(response)) {
                                    String message = pl.getProperty("message", "");
                                    int rownum = disputedDS.addRow();
                                    disputedDS.setValue(rownum, "slideid", slideid);
                                    disputedDS.setValue(rownum, "message", message);

                                }
                                if (Util.isNull(viewerworlistid))
                                    throw new SapphireException("ViewerWorkListId cannot be obtained from the SOAP response for the slide id: " + slideid);

                                int rowNum = resultDS.addRow();
                                resultDS.setValue(rowNum, "slideid", slideid);
                                resultDS.setValue(rowNum, "u_moviewerwlid", viewerworlistid);

                            }
                        }
                    }
                }
            }
            if (disputedDS != null && disputedDS.size() > 0) {
                String errMSG = "Below sample(s) cannnot be registered in the Multiomyx db\n" +
                        "<table border=1>" +
                        "<tr border=1><th>Slide Id</th><th>Reason</th></tr>";
                for (int i = 0; i < disputedDS.size(); i++) {
                    errMSG += "<tr border=1><td>" + disputedDS.getValue(i, "slideid", "") + "</td><td>" + disputedDS.getValue(i, "message", "") + "</td></tr>";
                }
                errMSG += "</table>";
                throw new SapphireException(errMSG);
            }
            if (resultDS != null && resultDS.size() > 0) {
                PropertyList plINput = new PropertyList();
                plINput.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                plINput.setProperty(EditSDI.PROPERTY_KEYID1, resultDS.getColumnValues("slideid", ";"));
                plINput.setProperty("u_moviewerwlid", resultDS.getColumnValues("u_moviewerwlid", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plINput);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new SapphireException(ex.getMessage());
        }
    }

    /*********************************************
     * This method is used to call the
     * submitBatch operation of LWS service
     *
     * @param props
     * @param proxy
     * @throws SapphireException
     ********************************************/
    private void submitBatch(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        if (props == null || props.size() == 0)
            throw new SapphireException("Input PropertyList object doesn't contain any input property.");
        String slides = props.getProperty("slides", "");
        if (Util.isNull(slides))
            throw new SapphireException("Slide Id is required in order to create a batch in the Multiomyx db");
        String sql = Util.parseMessage(MultiomyxSql.SAMPLEID_BY_MOBATCHID, StringUtil.replaceAll(slides, ";", "','"));
        DataSet dsMOBatchSamplemap = getQueryProcessor().getSqlDataSet(sql);
        if (dsMOBatchSamplemap == null)
            throw new SapphireException("Batch sample mapping cannot be obtained from LV db");
        if (dsMOBatchSamplemap.size() == 0)
            throw new SapphireException("Selected slide(s) are not associated with any batch in the LV db");

        String inputSlideIdArr[] = StringUtil.split(slides, ";");

        String disputedSlide = "";

        String mosampleids = dsMOBatchSamplemap.getColumnValues("mosampleid", ";");
        if (inputSlideIdArr != null && inputSlideIdArr.length > 0 && !Util.isNull(mosampleids)) {
            for (int i = 0; i < inputSlideIdArr.length; i++) {
                if (mosampleids.indexOf(inputSlideIdArr[i]) < 0)
                    disputedSlide += ";" + inputSlideIdArr[i];
            }
        }

        if (!Util.isNull(disputedSlide)) {
            if (disputedSlide.startsWith(";"))
                disputedSlide = disputedSlide.substring(1);
            throw new SapphireException("Below slide(s) do not have batch associated with it\n" + disputedSlide);
        }

        dsMOBatchSamplemap.sort("u_mobatchid");
        ArrayList<DataSet> dsMOBatchSamplemapArr = dsMOBatchSamplemap.getGroupedDataSets("u_mobatchid");
        if (dsMOBatchSamplemapArr != null && dsMOBatchSamplemapArr.size() > 0) {
            PropertyList plWS = new PropertyList();

            DataSet resultDS = new DataSet();
            resultDS.addColumn("batchid", DataSet.STRING);
            resultDS.addColumn("lwsbatchid", DataSet.STRING);

            DataSet disputedDS = new DataSet();
            disputedDS.addColumn("batchid", DataSet.STRING);
            disputedDS.addColumn("message", DataSet.STRING);

            for (int i = 0; i < dsMOBatchSamplemapArr.size(); i++) {
                DataSet tempDs = dsMOBatchSamplemapArr.get(i);
                if (tempDs != null && tempDs.size() > 0) {
                    String batchid = tempDs.getValue(0, "u_mobatchid", "");
                    if (Util.isNull(batchid))
                        throw new SapphireException("LV Batchid cannot be obtained for the slide(s)\n" + tempDs.getColumnValues("mosampleid", ";"));
                    plWS.clear();
                    plWS.setProperty("slides", tempDs.getColumnValues("mosampleid", ","));
                    String plWSXMLStr = plWS.toXMLString();
                    String result = proxy.submitBatch(plWSXMLStr);
                    PropertyList pl = new PropertyList();
                    pl.setPropertyList(result);
                    if (pl.size() > 0) {
                        String response = pl.getProperty("response", "");
                        String mobatchid = pl.getProperty("mobatchid", "");
                        if (Util.isNull(response))
                            throw new SapphireException("SOAP response does not have the response property.");
                        if ("fail".equalsIgnoreCase(response)) {
                            String message = pl.getProperty("message", "");
                            int rownum = disputedDS.addRow();
                            disputedDS.setValue(rownum, "batchid", batchid);
                            disputedDS.setValue(rownum, "message", message);
                        }
                        if (Util.isNull(mobatchid))
                            throw new SapphireException("LWS Batchid cannot be obtained from the SOAP response for the batch " + batchid);

                        int rowNum = resultDS.addRow();
                        resultDS.setValue(rowNum, "batchid", batchid);
                        resultDS.setValue(rowNum, "lwsbatchid", mobatchid);

                    }
                }
            }
            if (disputedDS != null && disputedDS.size() > 0) {
                String errMSG = "Below batches cannnot be registered in the Multiomyx db\n" +
                        "<table border=1>" +
                        "<tr border=1><th>Batch Id</th><th>Reason</th></tr>";
                for (int i = 0; i < disputedDS.size(); i++) {
                    errMSG += "<tr border=1><td>" + disputedDS.getValue(i, "batchid", "") + "</td><td>" + disputedDS.getValue(i, "message", "") + "</td></tr>";
                }
                errMSG += "</table>";
                throw new SapphireException(errMSG);
            }

            if (resultDS != null && resultDS.size() > 0) {
                PropertyList plINput = new PropertyList();
                plINput.setProperty(EditSDI.PROPERTY_SDCID, "MOBatch");
                plINput.setProperty(EditSDI.PROPERTY_KEYID1, resultDS.getColumnValues("batchid", ";"));
                plINput.setProperty("lwsbatchid", resultDS.getColumnValues("lwsbatchid", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plINput);
            }
        }

    }

    /*********************************************
     * This method is used to call the
     * updateBatchStatus operation of LWS service
     *
     * @param props
     * @param proxy
     * @throws SapphireException
     ********************************************/
    private void updateBatchStatus(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        if (props == null || props.size() == 0)
            throw new SapphireException("Input PropertyList object doesn't contain any input property.");
        String propXMLStr = props.toXMLString();
        String result = proxy.updateBatchStatus(propXMLStr);
        PropertyList pl = new PropertyList();
        pl.setPropertyList(result);
    }

    /*********************************************
     * This method is used to call the
     * updateQCStatus operation of LWS service
     *
     * @param props
     * @param proxy
     * @throws SapphireException
     ********************************************/
    private void updateQCStatus(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        if (props == null || props.size() == 0)
            throw new SapphireException("Input PropertyList object doesn't contain any input property.");
        String slideid = props.getProperty("slideid", "");
        String status = props.getProperty("status", "");
        if (Util.isNull(slideid))
            throw new SapphireException("Slide Id cannot be obtained.");
        String sql = Util.parseMessage(MultiomyxSql.MO_PROP_BY_SAMPLEID, StringUtil.replaceAll(slideid, ";", "','"));
        DataSet dsMOSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsMOSampleInfo == null)
            throw new SapphireException("Sample info cannot be obtained from db");
        if (dsMOSampleInfo.size() == 0)
            throw new SapphireException("Below slide(s) are not registered in the LV system\n" + slideid);

        DataSet dsSTMQCPendingList = null;

        String queryInput=StringUtil.replaceAll(slideid, ";", "','");
//        queryInput=StringUtil.replaceAll(queryInput, ",", "','");
        sql = Util.parseMessage(MultiomyxSql.SAMPLETESTCODEMAP_BY_SAMPLEID, queryInput);
        dsSTMQCPendingList = getQueryProcessor().getSqlDataSet(sql);
        if (dsSTMQCPendingList == null || dsSTMQCPendingList.size()==0)
            throw new SapphireException("SampleTestcodeMap info cannot be obtained from db");


        String inputSlideIdArr[] = StringUtil.split(slideid, ";");
        String statusArr[] = StringUtil.split(status, ";");

        String disputedSlide = "";

        String sampleIDSStr = dsMOSampleInfo.getColumnValues("s_sampleid", ";");

        HashMap<String, String> sampleStatusMap = new HashMap<String, String>();
        if (inputSlideIdArr != null && inputSlideIdArr.length > 0 && !Util.isNull(sampleIDSStr)) {
            for (int i = 0; i < inputSlideIdArr.length; i++) {
                if (sampleIDSStr.indexOf(inputSlideIdArr[i]) < 0)
                    disputedSlide += ";" + inputSlideIdArr[i];
                else if (statusArr != null && i < statusArr.length) {
                    sampleStatusMap.put(inputSlideIdArr[i], statusArr[i]);
                }
            }
        }

        if (!Util.isNull(disputedSlide)) {
            if (disputedSlide.startsWith(";"))
                disputedSlide = disputedSlide.substring(1);
            throw new SapphireException("Below slide(s) are not registered in the LV system\n" + disputedSlide);
        }

        DataSet resultDS = new DataSet();
        resultDS.addColumn("slideid", DataSet.STRING);
        resultDS.addColumn("u_moprotocolid", DataSet.STRING);
        resultDS.addColumn("u_moprotocol", DataSet.STRING);
        resultDS.addColumn("u_moprotocolstatus", DataSet.STRING);
        resultDS.addColumn("u_prevmoprotocol", DataSet.STRING);
        resultDS.addColumn("u_moscannerid", DataSet.STRING);
        resultDS.addColumn("u_moprotocoltype", DataSet.STRING);
        resultDS.addColumn("u_prevmoprotocoltype", DataSet.STRING);

        DataSet resultSTMDS = new DataSet();
        resultSTMDS.addColumn("u_sampletestcodemapid", DataSet.STRING);
        resultSTMDS.addColumn("moprotocol", DataSet.STRING);
        resultSTMDS.addColumn("prevmoprotocol", DataSet.STRING);
        resultSTMDS.addColumn("moprotocoltype", DataSet.STRING);
        resultSTMDS.addColumn("prevmoprotocoltype", DataSet.STRING);
        resultSTMDS.addColumn("moprotocolid", DataSet.STRING);
        resultSTMDS.addColumn("moprotocolstatus", DataSet.STRING);


        DataSet disputedDS = new DataSet();
        disputedDS.addColumn("slideid", DataSet.STRING);
        disputedDS.addColumn("message", DataSet.STRING);

        HashMap<String, String> hmap = new HashMap<String, String>();

        for (int i = 0; i < dsMOSampleInfo.size(); i++) {

            String tempSlideid = dsMOSampleInfo.getValue(i, "s_sampleid", "");
            String tempScannerid = dsMOSampleInfo.getValue(i, "u_moscannerid", "Unassigned");
            String tempprotocolname = dsMOSampleInfo.getValue(i, "u_moprotocol", "");
            String tempprotocoltype = dsMOSampleInfo.getValue(i, "u_moprotocoltype", "");


            PropertyList soapProp = new PropertyList();
            soapProp.setProperty("slideid", tempSlideid);
            soapProp.setProperty("scannerid", tempScannerid);
            soapProp.setProperty("protocoltype", tempprotocoltype);
            soapProp.setProperty("protocolname", tempprotocolname);
            soapProp.setProperty("status", sampleStatusMap.get(tempSlideid));


            String propXMLStr = soapProp.toXMLString();
            String result = proxy.updateQCStatus(propXMLStr);
            PropertyList newPl = new PropertyList();
            newPl.setPropertyList(result);

            if (newPl.size() > 0) {
//                PropertyList newPl=pl.getPropertyList(tempSlideid);
//                if(newPl==null || newPl.size()==0)
//                    throw new SapphireException("PropertyList object cannote be obtained from SOAP response.");
                String response = newPl.getProperty("response", "");
                String outslideid = newPl.getProperty("slideid", "");
                String protocoltype = newPl.getProperty("protocoltype", "");
                String pendingprotocoltype = newPl.getProperty("pendingprotocoltype", "");
                String protocolid = newPl.getProperty("pendingprotocolid", "");
                String protocolname = newPl.getProperty("protocolname", "");
                String pendingprotocolname = newPl.getProperty("pendingprotocolname", "");
                String protocolstatus = newPl.getProperty("pendingprotocolstatus", "");
                String scannerid = newPl.getProperty("scannerid", "");
                String testname = newPl.getProperty("testname", "");

                if (Util.isNull(response))
                    throw new SapphireException("SOAP response does not have the response property.");
                if(Util.isNull(pendingprotocolname))
                    throw new SapphireException("Protocol info cannot be obtained as SOAP response. May data service is not up and running.");
                if ("fail".equalsIgnoreCase(response)) {
                    String message = newPl.getProperty("message", "");
                    int rownum = disputedDS.addRow();
                    disputedDS.setValue(rownum, "slideid", outslideid);
                    disputedDS.setValue(rownum, "message", message);
                }

                int rowNum = resultDS.addRow();
                resultDS.setValue(rowNum, "slideid", outslideid);
                resultDS.setValue(rowNum, "u_moprotocolid", protocolid);
                resultDS.setValue(rowNum, "u_moprotocol", pendingprotocolname);
                resultDS.setValue(rowNum, "u_moprotocoltype", pendingprotocoltype);
                resultDS.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                resultDS.setValue(rowNum, "u_moscannerid", scannerid);
                resultDS.setValue(rowNum, "u_prevmoprotocol", protocolname);
                resultDS.setValue(rowNum, "u_prevmoprotocoltype", protocoltype);

                if (dsSTMQCPendingList.size() > 0) {
                    if (!Util.isNull(testname)) {
                        String testnameArr[] = StringUtil.split(testname, ",");
                        for (int testIndx = 0; testIndx < testnameArr.length; testIndx++) {

                            hmap.clear();
                            hmap.put("s_sampleid", outslideid);
                            hmap.put("testcodedesc", testnameArr[testIndx]);

                            DataSet dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);

                            if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                hmap.clear();
                                hmap.put("s_sampleid", outslideid);
                                hmap.put("aka", testnameArr[testIndx]);
                                dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);
                            }
                            if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                int rownum = disputedDS.addRow();
                                disputedDS.setValue(rownum, "slideid", outslideid);
                                disputedDS.setValue(rownum, "message", "There is no testcode having name "+testnameArr[testIndx]);
                            }
                            if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                                for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                    rowNum = resultSTMDS.addRow();
                                    resultSTMDS.setValue(rowNum, "u_sampletestcodemapid", dsTempFiltr.getValue(indx, "u_sampletestcodemapid", ""));
                                    resultSTMDS.setValue(rowNum, "moprotocol", pendingprotocolname);
                                    resultSTMDS.setValue(rowNum, "moprotocoltype", pendingprotocoltype);
                                    resultSTMDS.setValue(rowNum, "prevmoprotocol", protocolname);
                                    resultSTMDS.setValue(rowNum, "prevmoprotocoltype", protocoltype);
                                    resultSTMDS.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                    resultSTMDS.setValue(rowNum, "moprotocolid", protocolid);
                                }
                            }
                        }
                    } else {
                        hmap.clear();
                        hmap.put("s_sampleid", outslideid);
                        hmap.put("moprotocol", protocolname);
                        hmap.put("moprotocoltype", protocoltype);

                        DataSet dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);

                        if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                            for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                rowNum = resultSTMDS.addRow();
                                resultSTMDS.setValue(rowNum, "u_sampletestcodemapid", dsTempFiltr.getValue(indx, "u_sampletestcodemapid", ""));
                                resultSTMDS.setValue(rowNum, "moprotocol", pendingprotocolname);
                                resultSTMDS.setValue(rowNum, "moprotocoltype", pendingprotocoltype);
                                resultSTMDS.setValue(rowNum, "prevmoprotocol", protocolname);
                                resultSTMDS.setValue(rowNum, "prevmoprotocoltype", protocoltype);
                                resultSTMDS.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                resultSTMDS.setValue(rowNum, "moprotocolid", protocolid);
                            }
                        }
                    }
                }
            }
        }
        if (disputedDS != null && disputedDS.size() > 0) {
            String errMSG = "QC operation cannnot be performed in the Multiomyx db for the below sample(s)\n" +
                    "<table border=1>" +
                    "<tr border=1><th>Slide Id</th><th>Reason</th></tr>";
            for (int i = 0; i < disputedDS.size(); i++) {
                errMSG += "<tr border=1><td>" + disputedDS.getValue(i, "slideid", "") + "</td><td>" + disputedDS.getValue(i, "message", "") + "</td></tr>";
            }
            errMSG += "</table>";
            throw new SapphireException(errMSG);
        }
        if (resultDS != null && resultDS.size() > 0) {
            PropertyList inputProp = new PropertyList();
            inputProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            inputProp.setProperty(EditSDI.PROPERTY_KEYID1, resultDS.getColumnValues("slideid", ";"));
            inputProp.setProperty("u_moprotocol", resultDS.getColumnValues("u_moprotocol", ";"));
            inputProp.setProperty("u_prevmoprotocol", resultDS.getColumnValues("u_prevmoprotocol", ";"));
            inputProp.setProperty("u_moprotocoltype", resultDS.getColumnValues("u_moprotocoltype", ";"));
            inputProp.setProperty("u_prevmoprotocoltype", resultDS.getColumnValues("u_prevmoprotocoltype", ";"));
            inputProp.setProperty("u_moprotocolstatus", resultDS.getColumnValues("u_moprotocolstatus", ";"));
            inputProp.setProperty("u_moprotocolid", resultDS.getColumnValues("u_moprotocolid", ";"));
            inputProp.setProperty("u_moscannerid", resultDS.getColumnValues("u_moscannerid", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, inputProp);
        }
        if (resultSTMDS != null && resultSTMDS.size() > 0) {
            PropertyList inputProp = new PropertyList();
            inputProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            inputProp.setProperty(EditSDI.PROPERTY_KEYID1, resultSTMDS.getColumnValues("u_sampletestcodemapid", ";"));
            inputProp.setProperty("moprotocol", resultSTMDS.getColumnValues("moprotocol", ";"));
            inputProp.setProperty("moprotocoltype", resultSTMDS.getColumnValues("moprotocoltype", ";"));
            inputProp.setProperty("prevmoprotocol", resultSTMDS.getColumnValues("prevmoprotocol", ";"));
            inputProp.setProperty("prevmoprotocoltype", resultSTMDS.getColumnValues("prevmoprotocoltype", ";"));
            inputProp.setProperty("moprotocolstatus", resultSTMDS.getColumnValues("moprotocolstatus", ";"));
            inputProp.setProperty("moprotocolid", resultSTMDS.getColumnValues("moprotocolid", ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, inputProp);
        }

    }

    /*********************************************
     * This method is used to call the
     * updateSlideStatus operation of LWS service
     *
     * @param props
     * @param proxy
     * @throws SapphireException
     ********************************************/
    private void updateSlideStatus(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        try {
            if (props == null || props.size() == 0)
                throw new SapphireException("Input PropertyList object doesn't contain any input property.");
            String slideid = props.getProperty("slideid", "");

            if (Util.isNull(slideid))
                throw new SapphireException("Slide Id cannot be obtained.");
            String sql = Util.parseMessage(MultiomyxSql.MO_PROP_BY_SAMPLEID, StringUtil.replaceAll(slideid, ";", "','"));
            DataSet dsMOSampleInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsMOSampleInfo == null)
                throw new SapphireException("Sample info cannot be obtained from db");
            if (dsMOSampleInfo.size() == 0)
                throw new SapphireException("Below slide(s) are not registered in the LV system\n" + slideid);

            String inputSlideIdArr[] = StringUtil.split(slideid, ";");

            String disputedSlide = "";

            String sampleIDSStr = dsMOSampleInfo.getColumnValues("s_sampleid", ";");
            if (inputSlideIdArr != null && inputSlideIdArr.length > 0 && !Util.isNull(sampleIDSStr)) {
                for (int i = 0; i < inputSlideIdArr.length; i++) {
                    if (sampleIDSStr.indexOf(inputSlideIdArr[i]) < 0)
                        disputedSlide += ";" + inputSlideIdArr[i];
                }
            }

            if (!Util.isNull(disputedSlide)) {
                if (disputedSlide.startsWith(";"))
                    disputedSlide = disputedSlide.substring(1);
                throw new SapphireException("Below slide(s) are not registered in the LV system\n" + disputedSlide);
            }

            DataSet dsSTMQCPendingList = null;
            String queryInput=StringUtil.replaceAll(slideid, ";", "','");
//            queryInput=StringUtil.replaceAll(queryInput, ",", "','");
            sql = Util.parseMessage(MultiomyxSql.SAMPLETESTCODEMAP_BY_SAMPLEID, queryInput);

            dsSTMQCPendingList = getQueryProcessor().getSqlDataSet(sql);
            if (dsSTMQCPendingList == null || dsSTMQCPendingList.size()==0)
                throw new SapphireException("SampleTestcodeMap info cannot be obtained from db");


            DataSet resultDS = new DataSet();
            resultDS.addColumn("slideid", DataSet.STRING);
            resultDS.addColumn("u_moprotocolid", DataSet.STRING);
            resultDS.addColumn("u_moprotocol", DataSet.STRING);
            resultDS.addColumn("u_moprotocolstatus", DataSet.STRING);
            resultDS.addColumn("u_prevmoprotocol", DataSet.STRING);
            resultDS.addColumn("u_moscannerid", DataSet.STRING);
            resultDS.addColumn("u_moprotocoltype", DataSet.STRING);
            resultDS.addColumn("u_prevmoprotocoltype", DataSet.STRING);

            DataSet resultSTMDS = new DataSet();
            resultSTMDS.addColumn("u_sampletestcodemapid", DataSet.STRING);
            resultSTMDS.addColumn("moprotocol", DataSet.STRING);
            resultSTMDS.addColumn("prevmoprotocol", DataSet.STRING);
            resultSTMDS.addColumn("moprotocoltype", DataSet.STRING);
            resultSTMDS.addColumn("prevmoprotocoltype", DataSet.STRING);
            resultSTMDS.addColumn("moprotocolid", DataSet.STRING);
            resultSTMDS.addColumn("moprotocolstatus", DataSet.STRING);

            DataSet disputedDS = new DataSet();
            disputedDS.addColumn("slideid", DataSet.STRING);
            disputedDS.addColumn("message", DataSet.STRING);

            for (int i = 0; i < dsMOSampleInfo.size(); i++) {

                String tempSlideid = dsMOSampleInfo.getValue(i, "s_sampleid", "");
                String tempScannerid = dsMOSampleInfo.getValue(i, "u_moscannerid", "Unassigned");
                String tempprotocolname = dsMOSampleInfo.getValue(i, "u_moprotocol", "");
                String tempprotocoltype = dsMOSampleInfo.getValue(i, "u_moprotocoltype", "");

                if("Batch Complete, Must check off to finish protocol".equalsIgnoreCase(tempprotocolname))
                    tempprotocoltype="Batch Complete";


                PropertyList soapProp = new PropertyList();
                soapProp.setProperty("slideid", tempSlideid);
                soapProp.setProperty("scannerid", tempScannerid);
                soapProp.setProperty("protocoltype", tempprotocoltype);
                soapProp.setProperty("protocolname", tempprotocolname);
                soapProp.setProperty("status", "Completed");

                PropertyList parentPL = new PropertyList();
                parentPL.setProperty(tempSlideid, soapProp);


                String propXMLStr = parentPL.toXMLString();
                String result = proxy.updateSlideStatus(propXMLStr);
                PropertyList pl = new PropertyList();
                pl.setPropertyList(result);


                if (pl.size() > 0) {
                    PropertyList newPL=pl.getPropertyList(tempSlideid);
                    if(newPL==null || newPL.size()==0)
                        throw new SapphireException("PropertyList object cannot be obtained from the soap response");
                    String response = newPL.getProperty("response", "");
                    String outslideid = newPL.getProperty("slideid", "");
                    String protocoltype = newPL.getProperty("protocoltype", "");
                    String pendingprotocoltype = newPL.getProperty("pendingprotocoltype", "");
                    String protocolid = newPL.getProperty("pendingprotocolid", "");
                    String protocolname = newPL.getProperty("protocolname", "");
                    String pendingprotocolname = newPL.getProperty("pendingprotocolname", "");
                    String protocolstatus = newPL.getProperty("pendingprotocolstatus", "");
                    String scannerid = newPL.getProperty("scannerid", "");
                    String testname = newPL.getProperty("testname", "");


                    if (Util.isNull(response))
                        throw new SapphireException("SOAP response does not have the response property.");
                    if(Util.isNull(pendingprotocolname))
                        throw new SapphireException("Protocol info cannot be obtained as SOAP response. May data service is not up and running.");
                    if ("fail".equalsIgnoreCase(response)) {
                        String message = newPL.getProperty("message", "");
                        int rownum = disputedDS.addRow();
                        disputedDS.setValue(rownum, "slideid", outslideid);
                        disputedDS.setValue(rownum, "message", message);
                    }

                    int rowNum = resultDS.addRow();
                    resultDS.setValue(rowNum, "slideid", outslideid);
                    resultDS.setValue(rowNum, "u_moprotocolid", protocolid);
                    resultDS.setValue(rowNum, "u_moprotocol", pendingprotocolname);
                    resultDS.setValue(rowNum, "u_moprotocoltype", pendingprotocoltype);
                    resultDS.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                    resultDS.setValue(rowNum, "u_moscannerid", scannerid);
                    resultDS.setValue(rowNum, "u_prevmoprotocol", protocolname);
                    resultDS.setValue(rowNum, "u_prevmoprotocoltype", protocoltype);

                    HashMap<String, String> hmap = new HashMap<String, String>();

                    if (dsSTMQCPendingList.size() > 0) {
                        if (!Util.isNull(testname)) {
                            String testnameArr[] = StringUtil.split(testname, ",");
                            for (int testIndx = 0; testIndx < testnameArr.length; testIndx++) {

                                hmap.clear();
                                hmap.put("s_sampleid", outslideid);
                                hmap.put("testcodedesc", testnameArr[testIndx]);

                                DataSet dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);

                                if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                    hmap.clear();
                                    hmap.put("s_sampleid", outslideid);
                                    hmap.put("aka", testnameArr[testIndx]);
                                    dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);
                                }
                                if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                    int rownum = disputedDS.addRow();
                                    disputedDS.setValue(rownum, "slideid", outslideid);
                                    disputedDS.setValue(rownum, "message", "There is no testcode having name "+testnameArr[testIndx]);
                                }
                                if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                                    for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                        rowNum = resultSTMDS.addRow();
                                        resultSTMDS.setValue(rowNum, "u_sampletestcodemapid", dsTempFiltr.getValue(indx, "u_sampletestcodemapid", ""));
                                        resultSTMDS.setValue(rowNum, "moprotocol", pendingprotocolname);
                                        resultSTMDS.setValue(rowNum, "moprotocoltype", pendingprotocoltype);
                                        resultSTMDS.setValue(rowNum, "prevmoprotocol", protocolname);
                                        resultSTMDS.setValue(rowNum, "prevmoprotocoltype", protocoltype);
                                        resultSTMDS.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                        resultSTMDS.setValue(rowNum, "moprotocolid", protocolid);
                                    }
                                }
                            }
                        } else {
                            hmap.clear();
                            hmap.put("s_sampleid", outslideid);
                            hmap.put("moprotocol", protocolname);
                            hmap.put("moprotocoltype", protocoltype);

                            DataSet dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);

                            if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                                for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                    rowNum = resultSTMDS.addRow();
                                    resultSTMDS.setValue(rowNum, "u_sampletestcodemapid", dsTempFiltr.getValue(indx, "u_sampletestcodemapid", ""));
                                    resultSTMDS.setValue(rowNum, "moprotocol", pendingprotocolname);
                                    resultSTMDS.setValue(rowNum, "moprotocoltype", pendingprotocoltype);
                                    resultSTMDS.setValue(rowNum, "prevmoprotocol", protocolname);
                                    resultSTMDS.setValue(rowNum, "prevmoprotocoltype", protocoltype);
                                    resultSTMDS.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                    resultSTMDS.setValue(rowNum, "moprotocolid", protocolid);
                                }
                            }
                        }
                    }
                }
            }
            if (disputedDS != null && disputedDS.size() > 0) {
                String errMSG = "Update operation cannnot be performed in the Multiomyx db for the below sample(s)\n" +
                        "<table border=1>" +
                        "<tr border=1><th>Slide Id</th><th>Reason</th></tr>";
                for (int i = 0; i < disputedDS.size(); i++) {
                    errMSG += "<tr border=1><td>" + disputedDS.getValue(i, "slideid", "") + "</td><td>" + disputedDS.getValue(i, "message", "") + "</td></tr>";
                }
                errMSG += "</table>";
                throw new SapphireException(errMSG);
            }
            if (resultDS != null && resultDS.size() > 0) {
                PropertyList inputProp = new PropertyList();
                inputProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                inputProp.setProperty(EditSDI.PROPERTY_KEYID1, resultDS.getColumnValues("slideid", ";"));
                inputProp.setProperty("u_moprotocol", resultDS.getColumnValues("u_moprotocol", ";"));
                inputProp.setProperty("u_prevmoprotocol", resultDS.getColumnValues("u_prevmoprotocol", ";"));
                inputProp.setProperty("u_moprotocoltype", resultDS.getColumnValues("u_moprotocoltype", ";"));
                inputProp.setProperty("u_prevmoprotocoltype", resultDS.getColumnValues("u_prevmoprotocoltype", ";"));
                inputProp.setProperty("u_moprotocolstatus", resultDS.getColumnValues("u_moprotocolstatus", ";"));
                inputProp.setProperty("u_moprotocolid", resultDS.getColumnValues("u_moprotocolid", ";"));
                inputProp.setProperty("u_moscannerid", resultDS.getColumnValues("u_moscannerid", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, inputProp);
            }
            if (resultSTMDS != null && resultSTMDS.size() > 0) {
                PropertyList inputProp = new PropertyList();
                inputProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                inputProp.setProperty(EditSDI.PROPERTY_KEYID1, resultSTMDS.getColumnValues("u_sampletestcodemapid", ";"));
                inputProp.setProperty("moprotocol", resultSTMDS.getColumnValues("moprotocol", ";"));
                inputProp.setProperty("moprotocoltype", resultSTMDS.getColumnValues("moprotocoltype", ";"));
                inputProp.setProperty("prevmoprotocol", resultSTMDS.getColumnValues("prevmoprotocol", ";"));
                inputProp.setProperty("prevmoprotocoltype", resultSTMDS.getColumnValues("prevmoprotocoltype", ";"));
                inputProp.setProperty("moprotocolstatus", resultSTMDS.getColumnValues("moprotocolstatus", ";"));
                inputProp.setProperty("moprotocolid", resultSTMDS.getColumnValues("moprotocolid", ";"));

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, inputProp);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new SapphireException(ex.getMessage());
        }
    }


    private void getSlideStatus(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        if (props == null || props.size() == 0)
            throw new SapphireException("Input PropertyList object doesn't contain any input property.");
        String inputSlideId = props.getProperty("slideid", "");
        if (Util.isNull(inputSlideId))
            throw new SapphireException("No slide id is obtained to be registered in the Multiomyx db");


        String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        DataSet dsInput = new DataSet();
        dsInput.addColumn("slideid", DataSet.STRING);
        dsInput.addColumn("protocol", DataSet.STRING);
        dsInput.addColumn("stmprotocol", DataSet.STRING);
        dsInput.addColumn("protocoltype", DataSet.STRING);
        dsInput.addColumn("protocolstatus", DataSet.STRING);
        dsInput.addColumn("prevprotocoltype", DataSet.STRING);
        dsInput.addColumn("stmprotocoltype", DataSet.STRING);
        dsInput.addColumn("prevstmprotocoltype", DataSet.STRING);
        dsInput.addColumn("status", DataSet.STRING);
        dsInput.addColumn("batchid", DataSet.STRING);
        dsInput.addColumn("teststatus", DataSet.STRING);
        dsInput.addColumn("u_sampletestcodemapid", DataSet.STRING);
        dsInput.addColumn("lvtestcodeid", DataSet.STRING);
        dsInput.addColumn("lvtestpanelid", DataSet.STRING);
        dsInput.addColumnValues("slideid", DataSet.STRING, props.getProperty("slideid"), ",", "");
        dsInput.addColumnValues("protocol", DataSet.STRING, props.getProperty("protocol"), ",", "");
        dsInput.addColumnValues("stmprotocol", DataSet.STRING, props.getProperty("stmprotocol"), ",", "");
        dsInput.addColumnValues("protocoltype", DataSet.STRING, props.getProperty("protocoltype"), ",", "");
        dsInput.addColumnValues("protocolstatus", DataSet.STRING, props.getProperty("protocolstatus"), ",", "");
        dsInput.addColumnValues("prevprotocoltype", DataSet.STRING, props.getProperty("prevprotocoltype"), ",", "");
        dsInput.addColumnValues("stmprotocoltype", DataSet.STRING, props.getProperty("stmprotocoltype"), ",", "");
        dsInput.addColumnValues("prevstmprotocoltype", DataSet.STRING, props.getProperty("prevstmprotocoltype"), ",", "");
        dsInput.addColumnValues("status", DataSet.STRING, props.getProperty("status"), ",", "");
        dsInput.addColumnValues("batchid", DataSet.STRING, props.getProperty("batchid"), ",", "");
        dsInput.addColumnValues("teststatus", DataSet.STRING, props.getProperty("teststatus"), ",", "");
        dsInput.addColumnValues("u_sampletestcodemapid", DataSet.STRING, props.getProperty("u_sampletestcodemapid"), ",", "");
        dsInput.addColumnValues("qc", DataSet.STRING, props.getProperty("qc"), ",", "");
        dsInput.addColumnValues("pendingtest", DataSet.STRING, props.getProperty("pendingtest"), ",", "");
        dsInput.addColumnValues("lvtestpanelid", DataSet.STRING, props.getProperty("lvtestpanelid"), ",", "");
        dsInput.addColumnValues("lvtestcodeid", DataSet.STRING, props.getProperty("lvtestcodeid"), ",", "");

        // now get the out from call and create a dataset
        //int count = 0 ;
        DataSet outDataset = new DataSet();
        DataSet dsInFilter = new DataSet();
        HashMap hmFilter = new HashMap();
        outDataset.addColumn("slideid", DataSet.STRING);
        outDataset.addColumn("protocol", DataSet.STRING);
        outDataset.addColumn("status", DataSet.STRING);
        DataSet addMoImage = new DataSet();
        addMoImage.addColumn("tramstop", DataSet.STRING);
        addMoImage.addColumn("sampleid", DataSet.STRING);
        addMoImage.addColumn("imagetype", DataSet.STRING);
        addMoImage.addColumn("keyid1", DataSet.STRING);
        addMoImage.addColumn("u_moreceivecomment", DataSet.STRING);
        addMoImage.addColumn("u_mostatus", DataSet.STRING);
        addMoImage.addColumn("teststatus", DataSet.STRING);
        addMoImage.addColumn("testcodeid", DataSet.STRING);
        addMoImage.addColumn("lvtestpanelid", DataSet.STRING);
        addMoImage.addColumn("batchid", DataSet.STRING);
        addMoImage.addColumn("auditreason", DataSet.STRING);
        addMoImage.addColumn("currentstatus", DataSet.STRING);
        DataSet skipFlowaddMoImage = new DataSet();
        skipFlowaddMoImage.addColumn("tramstop", DataSet.STRING);
        skipFlowaddMoImage.addColumn("sampleid", DataSet.STRING);
        skipFlowaddMoImage.addColumn("imagetype", DataSet.STRING);
        skipFlowaddMoImage.addColumn("keyid1", DataSet.STRING);
        skipFlowaddMoImage.addColumn("u_moreceivecomment", DataSet.STRING);
        skipFlowaddMoImage.addColumn("u_mostatus", DataSet.STRING);
        skipFlowaddMoImage.addColumn("teststatus", DataSet.STRING);
        skipFlowaddMoImage.addColumn("testcodeid", DataSet.STRING);
        skipFlowaddMoImage.addColumn("lvtestpanelid", DataSet.STRING);
        skipFlowaddMoImage.addColumn("batchid", DataSet.STRING);
        skipFlowaddMoImage.addColumn("auditreason", DataSet.STRING);
        skipFlowaddMoImage.addColumn("currentstatus", DataSet.STRING);
        DataSet flowCompleteStep = new DataSet();
        flowCompleteStep.addColumn("sampleid", DataSet.STRING);
        DataSet editSample = new DataSet();
        editSample.addColumn("sdcid", DataSet.STRING);
        editSample.addColumn("keyid1", DataSet.STRING);
        editSample.addColumn("u_moreceivecomment", DataSet.STRING);
        editSample.addColumn("u_mocreatedt", DataSet.STRING);
        editSample.addColumn("u_mocreateby", DataSet.STRING);
        editSample.addColumn("u_mostatus", DataSet.STRING);
        editSample.addColumn("auditreason", DataSet.STRING);
        editSample.addColumn("u_moprotocolid", DataSet.STRING);
        editSample.addColumn("u_moprotocol", DataSet.STRING);
        editSample.addColumn("u_moprotocoltype", DataSet.STRING);
        editSample.addColumn("u_moprotocolstatus", DataSet.STRING);
        editSample.addColumn("u_prevmoprotocol", DataSet.STRING);
        editSample.addColumn("u_prevmoprotocoltype", DataSet.STRING);
        editSample.addColumn("u_moscannerid", DataSet.STRING);
        DataSet skipFloweditSample = new DataSet();
        skipFloweditSample.addColumn("sdcid", DataSet.STRING);
        skipFloweditSample.addColumn("keyid1", DataSet.STRING);
        skipFloweditSample.addColumn("u_moreceivecomment", DataSet.STRING);
        skipFloweditSample.addColumn("u_mocreatedt", DataSet.STRING);
        skipFloweditSample.addColumn("u_mocreateby", DataSet.STRING);
        skipFloweditSample.addColumn("u_mostatus", DataSet.STRING);
        skipFloweditSample.addColumn("auditreason", DataSet.STRING);
        skipFloweditSample.addColumn("u_moprotocolid", DataSet.STRING);
        skipFloweditSample.addColumn("u_moprotocol", DataSet.STRING);
        skipFloweditSample.addColumn("u_moprotocoltype", DataSet.STRING);
        skipFloweditSample.addColumn("u_moprotocolstatus", DataSet.STRING);
        skipFloweditSample.addColumn("u_prevmoprotocol", DataSet.STRING);
        skipFloweditSample.addColumn("u_prevmoprotocoltype", DataSet.STRING);
        skipFloweditSample.addColumn("u_moscannerid", DataSet.STRING);
        DataSet protocolInfo = new DataSet();
        protocolInfo.addColumn("sdcid", DataSet.STRING);
        protocolInfo.addColumn("keyid1", DataSet.STRING);
        protocolInfo.addColumn("u_moprotocolid", DataSet.STRING);
        protocolInfo.addColumn("u_moprotocol", DataSet.STRING);
        protocolInfo.addColumn("u_moprotocoltype", DataSet.STRING);
        protocolInfo.addColumn("u_moprotocolstatus", DataSet.STRING);
        protocolInfo.addColumn("u_prevmoprotocol", DataSet.STRING);
        protocolInfo.addColumn("u_prevmoprotocoltype", DataSet.STRING);
        protocolInfo.addColumn("u_moscannerid", DataSet.STRING);
        DataSet stmprotocolInfo = new DataSet();
        stmprotocolInfo.addColumn("sdcid", DataSet.STRING);
        stmprotocolInfo.addColumn("keyid1", DataSet.STRING);
        stmprotocolInfo.addColumn("moprotocolid", DataSet.STRING);
        stmprotocolInfo.addColumn("moprotocol", DataSet.STRING);
        stmprotocolInfo.addColumn("moprotocoltype", DataSet.STRING);
        stmprotocolInfo.addColumn("moprotocolstatus", DataSet.STRING);
        stmprotocolInfo.addColumn("prevmoprotocol", DataSet.STRING);
        stmprotocolInfo.addColumn("prevmoprotocoltype", DataSet.STRING);
        DataSet moSlideQC = new DataSet();
        moSlideQC.addColumn("sampleid", DataSet.STRING);
        moSlideQC.addColumn("qcstatus", DataSet.STRING);
        moSlideQC.addColumn("callws", DataSet.STRING);
        moSlideQC.addColumn("batchid", DataSet.STRING);
        moSlideQC.addColumn("auditreason", DataSet.STRING);
        moSlideQC.addColumn("stmid", DataSet.STRING);
        DataSet moBleachStainSlide = new DataSet();
        moBleachStainSlide.addColumn("sampleid", DataSet.STRING);
        moBleachStainSlide.addColumn("previousstatus", DataSet.STRING);
        moBleachStainSlide.addColumn("currentstatus", DataSet.STRING);
        moBleachStainSlide.addColumn("pendingtest", DataSet.STRING);
        moBleachStainSlide.addColumn("qcstatus", DataSet.STRING);
        moBleachStainSlide.addColumn("qcflag", DataSet.STRING);
        DataSet editProtocolType = new DataSet();
        editProtocolType.addColumn("sdcid", DataSet.STRING);
        editProtocolType.addColumn("keyid1", DataSet.STRING);
        editProtocolType.addColumn("u_moprotocoltype", DataSet.STRING);
        editProtocolType.addColumn("u_prevmoprotocoltype", DataSet.STRING);
        editProtocolType.addColumn("u_moprotocolstatus", DataSet.STRING);
        DataSet editSTMProtocolType = new DataSet();
        editSTMProtocolType.addColumn("sdcid", DataSet.STRING);
        editSTMProtocolType.addColumn("keyid1", DataSet.STRING);
        editSTMProtocolType.addColumn("moprotocoltype", DataSet.STRING);
        editSTMProtocolType.addColumn("prevmoprotocoltype", DataSet.STRING);
        editSTMProtocolType.addColumn("moprotocolstatus", DataSet.STRING);

        DataSet resultSTMDS = new DataSet();
        resultSTMDS.addColumn("u_sampletestcodemapid", DataSet.STRING);
        resultSTMDS.addColumn("moprotocol", DataSet.STRING);
        resultSTMDS.addColumn("prevmoprotocol", DataSet.STRING);
        resultSTMDS.addColumn("moprotocoltype", DataSet.STRING);
        resultSTMDS.addColumn("prevmoprotocoltype", DataSet.STRING);
        resultSTMDS.addColumn("moprotocolid", DataSet.STRING);
        resultSTMDS.addColumn("moprotocolstatus", DataSet.STRING);

        DataSet disputedDS = new DataSet();
        disputedDS.addColumn("slideid", DataSet.STRING);
        disputedDS.addColumn("message", DataSet.STRING);



        inputSlideId = Util.getUniqueList(inputSlideId, ",", true);
        DataSet dsSTMQCPendingList = null;
        String sql = Util.parseMessage(MultiomyxSql.SAMPLETESTCODEMAP_BY_SAMPLEID, StringUtil.replaceAll(inputSlideId, ",", "','"));
        dsSTMQCPendingList = getQueryProcessor().getSqlDataSet(sql);
        if (dsSTMQCPendingList == null || dsSTMQCPendingList.size()==0)
            throw new SapphireException("SampleTestcodeMap info cannot be obtained from db");

        String inputSlideIdArr[] = StringUtil.split(inputSlideId, ",");

        PropertyList inputProp = new PropertyList();


        if (inputSlideIdArr != null && inputSlideIdArr.length > 0) {

            inputProp.clear();
            inputProp.setProperty("slides", inputSlideId);
            String propXMLStr = inputProp.toXMLString();
            String result = proxy.getSlideStatus(propXMLStr);
            PropertyList pl = new PropertyList();
            pl.setPropertyList(result);
            String response=pl.getProperty("response","");
            if("fail".equalsIgnoreCase(response)){
                String message=pl.getProperty("message","");
                throw new SapphireException("GetSlideStatus webservice call failed. Reason:\n"+message);
            }

            HashMap<String,String> hmap=new HashMap<String,String>();

            String roiSelCompltSamples="";


            for (int inptIndx = 0; inptIndx < inputSlideIdArr.length; inptIndx++) {
                PropertyList newPL = pl.getPropertyList(inputSlideIdArr[inptIndx]);
                logger.debug("getSlidestatus", newPL.toJSONString());
                hmFilter.clear();
                hmFilter.put("slideid", inputSlideIdArr[inptIndx]);
                dsInFilter = dsInput.getFilteredDataSet(hmFilter);

                if ((dsInFilter != null) && (dsInFilter.getRowCount() > 0) && newPL != null && newPL.size() > 0) {
                    String protocolname = newPL.getProperty("protocolname", "");
                    String protocolid = newPL.getProperty("protocolid", "");
                    if(Util.isNull(protocolname) || Util.isNull(protocolid))
                        throw new SapphireException("Protocol info is not obtained from the data service");
                    if(!Util.isNull(protocolname) && !Util.isNull(protocolid)) {
                        String protocolstatus = newPL.getProperty("protocolstatus", "");
                        String scannerid = newPL.getProperty("scannerid", "");
                        String testname = newPL.getProperty("testname", "");
                        String protocoltype = newPL.getProperty("protocoltype", "");
                        String prevProtocol = dsInFilter.getString(0, "protocol", "");
                        String prevProtocoltype = dsInFilter.getString(0, "protocoltype", "");

                        if (dsInFilter.getString(0, "protocol", "").equalsIgnoreCase(protocolname)) {
                            String dbProtocolType = dsInFilter.getString(0, "protocoltype", "");
                            String dbPrevProtocolType = dsInFilter.getString(0, "prevprotocoltype", "");
                            String dbProtocolStatus = dsInFilter.getString(0, "protocolstatus", "");
                            boolean isEditable = false;
                            String inputProtocolType = dbProtocolType;
                            String inputPrevProtocolType = dbPrevProtocolType;
                            String inputProtocolStatus = dbProtocolStatus;
                            if (!Util.isNull(protocoltype) && !Util.isNull(dbProtocolType) && !protocoltype.equalsIgnoreCase(dbProtocolType)) {
                                inputProtocolType = protocoltype;
                                inputPrevProtocolType = dbProtocolType;
                                isEditable = true;
                            }
                            if (!Util.isNull(protocolstatus) && !Util.isNull(dbProtocolStatus) && !protocolstatus.equalsIgnoreCase(dbProtocolStatus)) {
                                inputProtocolStatus = protocolstatus;
                                isEditable = true;
                            }
                            if (isEditable) {
                                int rowNum = editProtocolType.addRow();
                                editProtocolType.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                editProtocolType.setValue(rowNum, "u_moprotocoltype", inputProtocolType);
                                editProtocolType.setValue(rowNum, "u_moprotocolstatus", inputProtocolStatus);
                                editProtocolType.setValue(rowNum, "u_prevmoprotocoltype", inputPrevProtocolType);

                                if ((dsInFilter.getString(0, "protocol", "").contains("20x Stain Imaging")) ||
                                        (dsInFilter.getString(0, "protocol", "").contains("20x Stain Imaging QC")) ||
                                        (dsInFilter.getString(0, "protocol", "").contains("20x Bleached Imaging")) ||
                                        (dsInFilter.getString(0, "protocol", "").contains("20x Bleached Imaging QC"))) {

                                    hmap.clear();
                                    hmap.put("slideid", inputSlideIdArr[inptIndx]);
                                    hmap.put("stmprotocol", protocolname);


                                    DataSet dsTempFiltr = dsInFilter.getFilteredDataSet(hmap);

                                    if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                                        for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                            rowNum = editSTMProtocolType.addRow();
                                            editSTMProtocolType.setValue(rowNum, "keyid1", dsTempFiltr.getString(indx, "u_sampletestcodemapid", ""));
                                            editSTMProtocolType.setValue(rowNum, "moprotocoltype", inputProtocolType);
                                            editSTMProtocolType.setValue(rowNum, "moprotocolstatus", inputProtocolStatus);
                                            editSTMProtocolType.setValue(rowNum, "prevmoprotocoltype", inputPrevProtocolType);
                                        }
                                    }

                                }

                            }
                        }
                        else {
                            int rowNum = 0;
                            if ("2x Scan Plan Imaging".equalsIgnoreCase(prevProtocol)) {
                                rowNum = addMoImage.addRow();
                                addMoImage.setValue(rowNum, "tramstop", "MOSamplePrep");
                                addMoImage.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                addMoImage.setValue(rowNum, "imagetype", "2x Unstained");
                                addMoImage.setValue(rowNum, "u_moreceivecomment", "");
                                addMoImage.setValue(rowNum, "u_mostatus", " ");
                                addMoImage.setValue(rowNum, "teststatus", " ");
                                addMoImage.setValue(rowNum, "testcodeid", "");
                                addMoImage.setValue(rowNum, "lvtestpanelid", "");
                                addMoImage.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                addMoImage.setValue(rowNum, "keyid1", "");
                                addMoImage.setValue(rowNum, "auditreason", "");
                                addMoImage.setValue(rowNum, "currentstatus", "");
                                rowNum = 0;
                                rowNum = editSample.addRow();
                                editSample.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                editSample.setValue(rowNum, "u_mocreateby", currentuser);
                                editSample.setValue(rowNum, "u_mocreatedt", "n");
                                editSample.setValue(rowNum, "u_moreceivecomment", "2x Imaging Completed For Unstained Slide");
                                editSample.setValue(rowNum, "u_mostatus", "MOUnstained2xImage");
                                editSample.setValue(rowNum, "auditreason", "2x Imaging Completed For Unstained Slide");
                                if ("10x Whole Tissue".equalsIgnoreCase(protocolname)) {
                                    editSample.setValue(rowNum, "u_moprotocolid", protocolid);
                                    editSample.setValue(rowNum, "u_moprotocol", protocolname);
                                    editSample.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                    editSample.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                    editSample.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                    editSample.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                    editSample.setValue(rowNum, "u_moscannerid", scannerid);
                                } else if ("10x Whole Tissue Imaging QC".equalsIgnoreCase(protocolname)) {
                                    editSample.setValue(rowNum, "u_moprotocolid", "1.2.3");
                                    editSample.setValue(rowNum, "u_moprotocol", "10x Whole Tissue");
                                    editSample.setValue(rowNum, "u_moprotocoltype", "Imaging");
                                    editSample.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                    editSample.setValue(rowNum, "u_prevmoprotocol", "2x Scan Plan Imaging");
                                    editSample.setValue(rowNum, "u_prevmoprotocoltype", "Imaging");
                                    editSample.setValue(rowNum, "u_moscannerid", scannerid);

                                    rowNum = skipFlowaddMoImage.addRow();
                                    skipFlowaddMoImage.setValue(rowNum, "tramstop", "MOSamplePrep");
                                    skipFlowaddMoImage.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                    skipFlowaddMoImage.setValue(rowNum, "imagetype", "10x Unstained");
                                    skipFlowaddMoImage.setValue(rowNum, "u_moreceivecomment", "");
                                    skipFlowaddMoImage.setValue(rowNum, "u_mostatus", " ");
                                    skipFlowaddMoImage.setValue(rowNum, "teststatus", " ");
                                    skipFlowaddMoImage.setValue(rowNum, "testcodeid", "");
                                    skipFlowaddMoImage.setValue(rowNum, "lvtestpanelid", "");
                                    skipFlowaddMoImage.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                    skipFlowaddMoImage.setValue(rowNum, "keyid1", "");
                                    skipFlowaddMoImage.setValue(rowNum, "auditreason", "");
                                    skipFlowaddMoImage.setValue(rowNum, "currentstatus", "");

                                    rowNum = 0;
                                    rowNum = skipFloweditSample.addRow();
                                    skipFloweditSample.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                    skipFloweditSample.setValue(rowNum, "u_mocreateby", currentuser);
                                    skipFloweditSample.setValue(rowNum, "u_mocreatedt", "n");
                                    skipFloweditSample.setValue(rowNum, "u_moreceivecomment", "10x Whole Tissue Imaging Completed For Unstained Slide");
                                    skipFloweditSample.setValue(rowNum, "u_mostatus", "MOUnstained10xImage");
                                    skipFloweditSample.setValue(rowNum, "auditreason", "10x Whole Tissue Imaging Completed For Unstained Slide");
                                    skipFloweditSample.setValue(rowNum, "u_moprotocolid", protocolid);
                                    skipFloweditSample.setValue(rowNum, "u_moprotocol", protocolname);
                                    skipFloweditSample.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                    skipFloweditSample.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                    skipFloweditSample.setValue(rowNum, "u_prevmoprotocol", "10x Whole Tissue");
                                    skipFloweditSample.setValue(rowNum, "u_prevmoprotocoltype", "Imaging");
                                    skipFloweditSample.setValue(rowNum, "u_moscannerid", scannerid);

                                    rowNum = 0;
                                    rowNum = flowCompleteStep.addRow();
                                    flowCompleteStep.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                }

                            } else if ("10x Whole Tissue".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) {
                                rowNum = addMoImage.addRow();
                                addMoImage.setValue(rowNum, "tramstop", "MOSamplePrep");
                                addMoImage.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                addMoImage.setValue(rowNum, "imagetype", "10x Unstained");
                                addMoImage.setValue(rowNum, "u_moreceivecomment", "");
                                addMoImage.setValue(rowNum, "u_mostatus", " ");
                                addMoImage.setValue(rowNum, "teststatus", " ");
                                addMoImage.setValue(rowNum, "testcodeid", "");
                                addMoImage.setValue(rowNum, "lvtestpanelid", "");
                                addMoImage.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                addMoImage.setValue(rowNum, "keyid1", "");
                                addMoImage.setValue(rowNum, "auditreason", "");
                                addMoImage.setValue(rowNum, "currentstatus", "");
                                rowNum = 0;
                                rowNum = editSample.addRow();
                                editSample.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                editSample.setValue(rowNum, "u_mocreateby", currentuser);
                                editSample.setValue(rowNum, "u_mocreatedt", "n");
                                editSample.setValue(rowNum, "u_moreceivecomment", "10x Whole Tissue Imaging Completed For Unstained Slide");
                                editSample.setValue(rowNum, "u_mostatus", "MOUnstained10xImage");
                                editSample.setValue(rowNum, "auditreason", "10x Whole Tissue Imaging Completed For Unstained Slide");
                                editSample.setValue(rowNum, "u_moprotocolid", protocolid);
                                editSample.setValue(rowNum, "u_moprotocol", protocolname);
                                editSample.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                editSample.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                editSample.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                editSample.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                editSample.setValue(rowNum, "u_moscannerid", scannerid);
                                rowNum = 0;
                                rowNum = flowCompleteStep.addRow();
                                flowCompleteStep.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                            } else if ("10x Whole Tissue Imaging QC".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) {
                                rowNum = 0;
                                rowNum = protocolInfo.addRow();
                                protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                //String prevProtocoltypeDb=dsInFilter.getString(0, "prevprotocoltype", "");
                                //String qcStatus="pass";
                                String qcStatus = newPL.getProperty("qcstatus", "");
                                //if(!Util.isNull(prevProtocoltypeDb) && prevProtocoltypeDb.equalsIgnoreCase(protocoltype))
                                //qcStatus="fail";
                                rowNum = 0;
                                rowNum = moSlideQC.addRow();
                                moSlideQC.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                moSlideQC.setValue(rowNum, "qcstatus", qcStatus);
                                moSlideQC.setValue(rowNum, "callws", "N");
                                //moSlideQC.setValue(rowNum, "auditreason", "10x Whole Tissue Imaging QC Completed");
                                moSlideQC.setValue(rowNum, "auditreason", newPL.getProperty("qcnotes", ""));
                                moSlideQC.setValue(rowNum, "stmid", "");
                                moSlideQC.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));


                            } else if ("20x Capture Region Selection (Technician)".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) {
                                roiSelCompltSamples += ";" + dsInFilter.getString(0, "slideid", "");
                                if ("20x Capture Region Selection QC".equalsIgnoreCase(protocolname)) {
                                    rowNum = editSample.addRow();
                                    editSample.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                    editSample.setValue(rowNum, "u_mocreateby", currentuser);
                                    editSample.setValue(rowNum, "u_mocreatedt", "n");
                                    editSample.setValue(rowNum, "u_moreceivecomment", "ROI Selection Completed");
                                    editSample.setValue(rowNum, "u_mostatus", "MOROISelectionCompleted");
                                    editSample.setValue(rowNum, "auditreason", "ROI Selection Completed");
                                    editSample.setValue(rowNum, "u_moprotocolid", protocolid);
                                    editSample.setValue(rowNum, "u_moprotocol", protocolname);
                                    editSample.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                    editSample.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                    editSample.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                    editSample.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                    editSample.setValue(rowNum, "u_moscannerid", scannerid);
                                } else if ("20x Background Imaging".equalsIgnoreCase(protocolname)) {
                                    rowNum = editSample.addRow();
                                    editSample.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                    editSample.setValue(rowNum, "u_mocreateby", currentuser);
                                    editSample.setValue(rowNum, "u_mocreatedt", "n");
                                    editSample.setValue(rowNum, "u_moreceivecomment", "ROI Selection Completed");
                                    editSample.setValue(rowNum, "u_mostatus", "MOROISelectionCompleted");
                                    editSample.setValue(rowNum, "auditreason", "ROI Selection Completed");
                                    editSample.setValue(rowNum, "u_moprotocolid", "1.2.05");
                                    editSample.setValue(rowNum, "u_moprotocol", "20x Capture Region Selection QC");
                                    editSample.setValue(rowNum, "u_moprotocoltype", "RoiSelectionQc");
                                    editSample.setValue(rowNum, "u_moprotocolstatus", "Pending");
                                    editSample.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                    editSample.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                    editSample.setValue(rowNum, "u_moscannerid", scannerid);

                                    rowNum = protocolInfo.addRow();
                                    protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                    protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                    protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                    protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                    protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                    protocolInfo.setValue(rowNum, "u_prevmoprotocol", "20x Capture Region Selection QC");
                                    protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", "RoiSelectionQc");
                                    protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                    String qcStatus = newPL.getProperty("qcstatus", "");
                                    //if(!Util.isNull(prevProtocoltypeDb) && prevProtocoltypeDb.equalsIgnoreCase(protocoltype))
                                    //qcStatus="fail";
                                    rowNum = 0;
                                    rowNum = moSlideQC.addRow();
                                    moSlideQC.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                    moSlideQC.setValue(rowNum, "qcstatus", qcStatus);
                                    moSlideQC.setValue(rowNum, "callws", "N");
                                    //moSlideQC.setValue(rowNum, "auditreason", "20x Capture Region Selection QC Completed");
                                    moSlideQC.setValue(rowNum, "auditreason", newPL.getProperty("qcnotes", ""));
                                    moSlideQC.setValue(rowNum, "stmid", "");
                                    moSlideQC.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                }
                            } else if ("20x Capture Region Selection QC".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) {
                                rowNum = 0;
                                rowNum = protocolInfo.addRow();
                                protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                String prevProtocoltypeDb = dsInFilter.getString(0, "prevprotocoltype", "");
                                //String qcStatus="pass";
                                String qcStatus = newPL.getProperty("qcstatus", "");
                                //if(!Util.isNull(prevProtocoltypeDb) && prevProtocoltypeDb.equalsIgnoreCase(protocoltype))
                                //qcStatus="fail";
                                rowNum = 0;
                                rowNum = moSlideQC.addRow();
                                moSlideQC.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                moSlideQC.setValue(rowNum, "qcstatus", qcStatus);
                                moSlideQC.setValue(rowNum, "callws", "N");
                                //moSlideQC.setValue(rowNum, "auditreason", "20x Capture Region Selection QC Completed");
                                moSlideQC.setValue(rowNum, "auditreason", newPL.getProperty("qcnotes", ""));
                                moSlideQC.setValue(rowNum, "stmid", "");
                                moSlideQC.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));

                            } else if ("20x Background Imaging".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) {
                                rowNum = addMoImage.addRow();
                                addMoImage.setValue(rowNum, "tramstop", "MOImageROI");
                                addMoImage.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                addMoImage.setValue(rowNum, "imagetype", "20x ROI Background");
                                addMoImage.setValue(rowNum, "u_moreceivecomment", "");
                                addMoImage.setValue(rowNum, "u_mostatus", " ");
                                addMoImage.setValue(rowNum, "teststatus", " ");
                                addMoImage.setValue(rowNum, "testcodeid", "");
                                addMoImage.setValue(rowNum, "lvtestpanelid", "");
                                addMoImage.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                addMoImage.setValue(rowNum, "keyid1", "");
                                addMoImage.setValue(rowNum, "auditreason", "");
                                addMoImage.setValue(rowNum, "currentstatus", "");
                                rowNum = 0;
                                rowNum = editSample.addRow();
                                editSample.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                editSample.setValue(rowNum, "u_mocreateby", currentuser);
                                editSample.setValue(rowNum, "u_mocreatedt", "n");
                                editSample.setValue(rowNum, "u_moreceivecomment", "ROI Imaging Completed");
                                editSample.setValue(rowNum, "u_mostatus", "MOImageROICompleted");
                                editSample.setValue(rowNum, "auditreason", "ROI Imaging Completed");
                                editSample.setValue(rowNum, "u_moprotocolid", protocolid);
                                editSample.setValue(rowNum, "u_moprotocol", protocolname);
                                editSample.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                editSample.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                editSample.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                editSample.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                editSample.setValue(rowNum, "u_moscannerid", scannerid);
//                            rowNum = 0;
//                            rowNum = flowCompleteStep.addRow();
//                            flowCompleteStep.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                            } else if ("20x Background Imaging QC".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) {
                                rowNum = 0;
                                rowNum = protocolInfo.addRow();
                                protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                String prevProtocoltypeDb = dsInFilter.getString(0, "prevprotocoltype", "");
                                //String qcStatus="pass";
                                String qcStatus = newPL.getProperty("qcstatus", "");
                                //if(!Util.isNull(prevProtocoltypeDb) && prevProtocoltypeDb.equalsIgnoreCase(protocoltype))
                                //qcStatus="fail";
                                rowNum = 0;
                                rowNum = moSlideQC.addRow();
                                moSlideQC.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                moSlideQC.setValue(rowNum, "qcstatus", qcStatus);
                                moSlideQC.setValue(rowNum, "callws", "N");
                                //moSlideQC.setValue(rowNum, "auditreason", "20x Background Imaging QC Completed");
                                moSlideQC.setValue(rowNum, "auditreason", newPL.getProperty("qcnotes", ""));
                                moSlideQC.setValue(rowNum, "stmid", "");
                                moSlideQC.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));

                                if (!"fail".equalsIgnoreCase(qcStatus) && dsSTMQCPendingList.size() > 0) {
                                    if (!Util.isNull(testname)) {
                                        String testnameArr[] = StringUtil.split(testname, ",");
                                        for (int testIndx = 0; testIndx < testnameArr.length; testIndx++) {

                                            hmap.clear();
                                            hmap.put("s_sampleid", dsInFilter.getString(0, "slideid", ""));
                                            hmap.put("testcodedesc", testnameArr[testIndx]);

                                            DataSet dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);

                                            if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                                hmap.clear();
                                                hmap.put("s_sampleid", dsInFilter.getString(0, "slideid", ""));
                                                hmap.put("aka", testnameArr[testIndx]);
                                                dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);
                                            }
                                            if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                                int rownum = disputedDS.addRow();
                                                disputedDS.setValue(rownum, "slideid", dsInFilter.getString(0, "slideid", ""));
                                                disputedDS.setValue(rownum, "message", "There is no testcode having name " + testnameArr[testIndx]);
                                            }
                                            if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                                                for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                                    rowNum = resultSTMDS.addRow();
                                                    resultSTMDS.setValue(rowNum, "u_sampletestcodemapid", dsTempFiltr.getValue(indx, "u_sampletestcodemapid", ""));
                                                    resultSTMDS.setValue(rowNum, "moprotocol", protocolname);
                                                    resultSTMDS.setValue(rowNum, "moprotocoltype", protocoltype);
                                                    resultSTMDS.setValue(rowNum, "prevmoprotocol", prevProtocol);
                                                    resultSTMDS.setValue(rowNum, "prevmoprotocoltype", prevProtocoltype);
                                                    resultSTMDS.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                                    resultSTMDS.setValue(rowNum, "moprotocolid", protocolid);
                                                }
                                            }
                                        }
                                    } else {
                                        throw new SapphireException("Testname cannot be obtained from the webservice response");
                                    }
                                }

                            } else if ("20x Stain Imaging QC".equalsIgnoreCase(dsInFilter.getString(0, "protocol", "")) || (dsInFilter.getString(0, "protocol", "").contains("20x Stain Imaging QC"))) {
                                logger.debug("MOLWSAction - getSlidestatus--", "sample id and testcode id are " + dsInFilter.getString(0, "slideid") + "   " + dsInFilter.getString(0, "lvtestcodeid"));
                                if (!Util.isNull(dsInFilter.getString(0, "slideid", ""))) {
                                    hmFilter.clear();
                                    hmFilter.put("teststatus", "MOStainedImage");
                                    dsInFilter = dsInFilter.getFilteredDataSet(hmFilter);

                                    if ((dsInFilter != null) && (dsInFilter.getRowCount() > 0)) {
                                        rowNum = 0;
                                        rowNum = protocolInfo.addRow();
                                        protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                        protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                        protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                        protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                        protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                        protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                        for (int k = 0; k < dsInFilter.size(); k++) {
                                            String prevProtocoltypeDb = dsInFilter.getString(k, "prevstmprotocoltype", "");
                                            //String qcStatus="pass";
                                            String qcStatus = newPL.getProperty("qcstatus", "");
                                            //if(!Util.isNull(prevProtocoltypeDb) && prevProtocoltypeDb.equalsIgnoreCase(protocoltype))
                                            //qcStatus="fail";
                                            rowNum = moSlideQC.addRow();
                                            //moSlideQC.setValue(rowNum, "auditreason", "20x Stain Imaging QC complete");
                                            moSlideQC.setValue(rowNum, "auditreason", newPL.getProperty("qcnotes", ""));
                                            moSlideQC.setValue(rowNum, "sampleid", dsInFilter.getString(k, "slideid", ""));
                                            moSlideQC.setValue(rowNum, "qcstatus", qcStatus);
                                            moSlideQC.setValue(rowNum, "callws", "N");
                                            moSlideQC.setValue(rowNum, "stmid", dsInFilter.getString(k, "u_sampletestcodemapid", ""));
                                            moSlideQC.setValue(rowNum, "batchid", dsInFilter.getString(k, "batchid", ""));

                                            rowNum = 0;
                                            rowNum = stmprotocolInfo.addRow();
                                            stmprotocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(k, "u_sampletestcodemapid", ""));
                                            stmprotocolInfo.setValue(rowNum, "moprotocolid", protocolid);
                                            stmprotocolInfo.setValue(rowNum, "moprotocol", protocolname);
                                            stmprotocolInfo.setValue(rowNum, "moprotocoltype", protocoltype);
                                            stmprotocolInfo.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                            stmprotocolInfo.setValue(rowNum, "prevmoprotocol", prevProtocol);
                                            stmprotocolInfo.setValue(rowNum, "prevmoprotocoltype", prevProtocoltype);
                                        }
                                        rowNum = 0;
                                    } else
                                        logger.debug("MOLWSaction", "sample not found for testcode status ");
                                }
                            } else if (("20x Stain Imaging".equalsIgnoreCase(dsInFilter.getString(0, "protocol", ""))) || (dsInFilter.getString(0, "protocol", "").contains("20x Stain Imaging"))) {
                                if (!Util.isNull(dsInFilter.getString(0, "slideid", ""))) {
                                    hmFilter.clear();
                                    hmFilter.put("teststatus", "MOStainCompleted");
                                    dsInFilter = dsInFilter.getFilteredDataSet(hmFilter);

                                    if ((dsInFilter != null) && (dsInFilter.getRowCount() > 0)) {
                                        rowNum = 0;
                                        rowNum = protocolInfo.addRow();
                                        protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                        protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                        protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                        protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                        protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                        protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                        for (int k = 0; k < dsInFilter.size(); k++) {
                                            rowNum = addMoImage.addRow();
                                            addMoImage.setValue(rowNum, "tramstop", "MOStain");
                                            addMoImage.setValue(rowNum, "sampleid", dsInFilter.getString(k, "slideid", ""));
                                            addMoImage.setValue(rowNum, "imagetype", "Stained");
                                            addMoImage.setValue(rowNum, "u_moreceivecomment", "Stain Slide Imaging Completed");
                                            addMoImage.setValue(rowNum, "u_mostatus", "Stain Slide Imaging Completed");
                                            addMoImage.setValue(rowNum, "teststatus", "MOStainedImage");
                                            addMoImage.setValue(rowNum, "testcodeid", dsInFilter.getString(k, "lvtestcodeid", ""));
                                            addMoImage.setValue(rowNum, "lvtestpanelid", dsInFilter.getString(k, "lvtestpanelid", ""));
                                            addMoImage.setValue(rowNum, "batchid", dsInFilter.getString(k, "batchid", ""));
                                            addMoImage.setValue(rowNum, "keyid1", dsInFilter.getString(k, "u_sampletestcodemapid", ""));
                                            addMoImage.setValue(rowNum, "auditreason", "Stain Slide Imaging Completed");
                                            addMoImage.setValue(rowNum, "currentstatus", "");

                                            rowNum = 0;
                                            rowNum = stmprotocolInfo.addRow();
                                            stmprotocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(k, "u_sampletestcodemapid", ""));
                                            stmprotocolInfo.setValue(rowNum, "moprotocolid", protocolid);
                                            stmprotocolInfo.setValue(rowNum, "moprotocol", protocolname);
                                            stmprotocolInfo.setValue(rowNum, "moprotocoltype", protocoltype);
                                            stmprotocolInfo.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                            stmprotocolInfo.setValue(rowNum, "prevmoprotocol", prevProtocol);
                                            stmprotocolInfo.setValue(rowNum, "prevmoprotocoltype", prevProtocoltype);

                                        }

                                        rowNum = 0;
                                    } else
                                        logger.debug("MOLWSaction", "sample not found for testcode status ");
                                }
                            } else if ("20x Bleached Imaging QC".equalsIgnoreCase(dsInFilter.getString(0, "protocol", "")) || (dsInFilter.getString(0, "protocol", "").contains("20x Bleached Imaging QC"))) {
                                if (!Util.isNull(dsInFilter.getString(0, "slideid", ""))) {
                                    hmFilter.clear();
                                    hmFilter.put("teststatus", "MOBleachedImage");
                                    dsInFilter = dsInFilter.getFilteredDataSet(hmFilter);
                                    if (dsInFilter != null && dsInFilter.size() > 0) {
                                        rowNum = 0;
                                        rowNum = protocolInfo.addRow();
                                        protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                        protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                        protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                        protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                        protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                        protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                        String prevProtocoltypeDb = dsInFilter.getString(0, "prevprotocoltype", "");
                                        //String qcStatus="pass";
                                        String qcStatus = newPL.getProperty("qcstatus", "");
                                        //if(!Util.isNull(prevProtocoltypeDb) && prevProtocoltypeDb.equalsIgnoreCase(protocoltype))
                                        //qcStatus="fail";

                                        rowNum = 0;
                                        rowNum = moSlideQC.addRow();
                                        moSlideQC.setValue(rowNum, "auditreason", newPL.getProperty("qcnotes", ""));
                                        moSlideQC.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                        moSlideQC.setValue(rowNum, "qcstatus", qcStatus);
                                        moSlideQC.setValue(rowNum, "callws", "N");
                                        moSlideQC.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                        moSlideQC.setValue(rowNum, "stmid", dsInFilter.getString(0, "qc", ""));


                                        rowNum = 0;
                                        rowNum = moBleachStainSlide.addRow();
                                        moBleachStainSlide.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                        moBleachStainSlide.setValue(rowNum, "previousstatus", "MOBleachedImage");
                                        moBleachStainSlide.setValue(rowNum, "currentstatus", "MOBIQCPassed");
                                        moBleachStainSlide.setValue(rowNum, "qcflag", "Y");
                                        moBleachStainSlide.setValue(rowNum, "qcstatus", qcStatus);
                                        moBleachStainSlide.setValue(rowNum, "pendingtest", dsInFilter.getString(0, "pendingtest", ""));

                                        if (dsSTMQCPendingList.size() > 0 && "pass".equalsIgnoreCase(qcStatus)) {
                                            if (!Util.isNull(testname)) {
                                                String testnameArr[] = StringUtil.split(testname, ",");
                                                for (int testIndx = 0; testIndx < testnameArr.length; testIndx++) {

                                                    hmap.clear();
                                                    hmap.put("s_sampleid", dsInFilter.getString(0, "slideid", ""));
                                                    hmap.put("testcodedesc", testnameArr[testIndx]);

                                                    DataSet dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);

                                                    if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                                        hmap.clear();
                                                        hmap.put("s_sampleid", dsInFilter.getString(0, "slideid", ""));
                                                        hmap.put("aka", testnameArr[testIndx]);
                                                        dsTempFiltr = dsSTMQCPendingList.getFilteredDataSet(hmap);
                                                    }
                                                    if (dsTempFiltr == null || dsTempFiltr.size() == 0) {
                                                        int rownum = disputedDS.addRow();
                                                        disputedDS.setValue(rownum, "slideid", dsInFilter.getString(0, "slideid", ""));
                                                        disputedDS.setValue(rownum, "message", "There is no testcode having name " + testnameArr[testIndx]);
                                                    }
                                                    if (dsTempFiltr != null && dsTempFiltr.size() > 0) {
                                                        for (int indx = 0; indx < dsTempFiltr.size(); indx++) {
                                                            rowNum = resultSTMDS.addRow();
                                                            resultSTMDS.setValue(rowNum, "u_sampletestcodemapid", dsTempFiltr.getValue(indx, "u_sampletestcodemapid", ""));
                                                            resultSTMDS.setValue(rowNum, "moprotocol", protocolname);
                                                            resultSTMDS.setValue(rowNum, "moprotocoltype", protocoltype);
                                                            resultSTMDS.setValue(rowNum, "prevmoprotocol", prevProtocol);
                                                            resultSTMDS.setValue(rowNum, "prevmoprotocoltype", prevProtocoltype);
                                                            resultSTMDS.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                                            resultSTMDS.setValue(rowNum, "moprotocolid", protocolid);
                                                        }
                                                    }
                                                }
                                            } else {
                                                throw new SapphireException("Testname cannot be obtained from the webservice response");
                                            }
                                        } else if ((dsInFilter != null) && (dsInFilter.getRowCount() > 0) && "fail".equalsIgnoreCase(qcStatus)) {
                                            for (int k = 0; k < dsInFilter.size(); k++) {
                                                rowNum = 0;
                                                rowNum = stmprotocolInfo.addRow();
                                                stmprotocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(k, "u_sampletestcodemapid", ""));
                                                stmprotocolInfo.setValue(rowNum, "moprotocolid", protocolid);
                                                stmprotocolInfo.setValue(rowNum, "moprotocol", protocolname);
                                                stmprotocolInfo.setValue(rowNum, "moprotocoltype", protocoltype);
                                                stmprotocolInfo.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                                stmprotocolInfo.setValue(rowNum, "prevmoprotocol", prevProtocol);
                                                stmprotocolInfo.setValue(rowNum, "prevmoprotocoltype", prevProtocoltype);
                                            }
                                        }
                                    }
                                }

                            } else if ("20x Bleached Imaging".equalsIgnoreCase(dsInFilter.getString(0, "protocol", "")) || (dsInFilter.getString(0, "protocol", "").contains("20x Bleached Imaging"))) {
                                if (!Util.isNull(dsInFilter.getString(0, "slideid", ""))) {
                                    hmFilter.clear();
                                    hmFilter.put("teststatus", "MOSlideBleached");
                                    dsInFilter = dsInFilter.getFilteredDataSet(hmFilter);

                                    if (dsInFilter != null && dsInFilter.size() > 0) {
                                        rowNum = protocolInfo.addRow();
                                        protocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(0, "slideid", ""));
                                        protocolInfo.setValue(rowNum, "u_moprotocolid", protocolid);
                                        protocolInfo.setValue(rowNum, "u_moprotocol", protocolname);
                                        protocolInfo.setValue(rowNum, "u_moprotocoltype", protocoltype);
                                        protocolInfo.setValue(rowNum, "u_moprotocolstatus", protocolstatus);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocol", prevProtocol);
                                        protocolInfo.setValue(rowNum, "u_prevmoprotocoltype", prevProtocoltype);
                                        protocolInfo.setValue(rowNum, "u_moscannerid", scannerid);

                                        rowNum = addMoImage.addRow();
                                        addMoImage.setValue(rowNum, "tramstop", "MOBleach");
                                        addMoImage.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                        addMoImage.setValue(rowNum, "imagetype", "Bleached");
                                        addMoImage.setValue(rowNum, "batchid", dsInFilter.getString(0, "batchid", ""));
                                        addMoImage.setValue(rowNum, "currentstatus", "MOBleachedImage");
                                        addMoImage.setValue(rowNum, "auditreason", "Bleached Slide Imaging Completed");
                                        addMoImage.setValue(rowNum, "u_moreceivecomment", "");
                                        addMoImage.setValue(rowNum, "u_mostatus", "");
                                        addMoImage.setValue(rowNum, "teststatus", "");
                                        addMoImage.setValue(rowNum, "testcodeid", "");
                                        addMoImage.setValue(rowNum, "lvtestpanelid", "");
                                        addMoImage.setValue(rowNum, "keyid1", "");

                                        rowNum = moBleachStainSlide.addRow();
                                        moBleachStainSlide.setValue(rowNum, "sampleid", dsInFilter.getString(0, "slideid", ""));
                                        moBleachStainSlide.setValue(rowNum, "previousstatus", "MOSlideBleached");
                                        moBleachStainSlide.setValue(rowNum, "currentstatus", "MOBleachedImage");
                                        moBleachStainSlide.setValue(rowNum, "qcflag", "N");
                                        moBleachStainSlide.setValue(rowNum, "qcstatus", "");
                                        moBleachStainSlide.setValue(rowNum, "pendingtest", "");
                                        rowNum = 0;
                                        if ((dsInFilter != null) && (dsInFilter.getRowCount() > 0)) {
                                            for (int k = 0; k < dsInFilter.size(); k++) {
                                                rowNum = 0;
                                                rowNum = stmprotocolInfo.addRow();
                                                stmprotocolInfo.setValue(rowNum, "keyid1", dsInFilter.getString(k, "u_sampletestcodemapid", ""));
                                                stmprotocolInfo.setValue(rowNum, "moprotocolid", protocolid);
                                                stmprotocolInfo.setValue(rowNum, "moprotocol", protocolname);
                                                stmprotocolInfo.setValue(rowNum, "moprotocoltype", protocoltype);
                                                stmprotocolInfo.setValue(rowNum, "moprotocolstatus", protocolstatus);
                                                stmprotocolInfo.setValue(rowNum, "prevmoprotocol", prevProtocol);
                                                stmprotocolInfo.setValue(rowNum, "prevmoprotocoltype", prevProtocoltype);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    logger.debug("moWSAAction", "sampleid in response of web service was not in input sent to web service " + inputSlideIdArr[inptIndx]);
                }

            }




            ActionBlock ab = new ActionBlock();
            int count=0;

            if (editSample != null && editSample.size() > 0) {
                PropertyList plInput = new PropertyList();
                if(!Util.isNull(editSample.getColumnValues("keyid1", ";"))) {
                    plInput.setProperty("sdcid", "Sample");
                    plInput.setProperty("keyid1", editSample.getColumnValues("keyid1", ";"));
                    plInput.setProperty("u_mocreatedt", editSample.getColumnValues("u_mocreatedt", ";"));
                    plInput.setProperty("u_mocreateby", editSample.getColumnValues("u_mocreateby", ";"));
                    plInput.setProperty("u_moreceivecomment", editSample.getColumnValues("u_moreceivecomment", ";"));
                    plInput.setProperty("u_mostatus", editSample.getColumnValues("u_mostatus", ";"));
                    plInput.setProperty("auditreason", editSample.getColumnValues("auditreason", ";"));
                    plInput.setProperty("u_moprotocolid", editSample.getColumnValues("u_moprotocolid", ";"));
                    plInput.setProperty("u_moprotocol", editSample.getColumnValues("u_moprotocol", ";"));
                    plInput.setProperty("u_moprotocoltype", editSample.getColumnValues("u_moprotocoltype", ";"));
                    plInput.setProperty("u_moprotocolstatus", editSample.getColumnValues("u_moprotocolstatus", ";"));
                    plInput.setProperty("u_prevmoprotocol", editSample.getColumnValues("u_prevmoprotocol", ";"));
                    plInput.setProperty("u_prevmoprotocoltype", editSample.getColumnValues("u_prevmoprotocoltype", ";"));
                    plInput.setProperty("u_moscannerid", editSample.getColumnValues("u_moscannerid", ";"));
//                    getActionProcessor().processAction("EditSDI", "1", plInput);
                    ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                    count++;
                }
            }
            if (skipFloweditSample != null && skipFloweditSample.size() > 0) {
                if(!Util.isNull(skipFloweditSample.getColumnValues("keyid1", ";"))) {
                    PropertyList plInput = new PropertyList();
                    plInput.setProperty("sdcid", "Sample");
                    plInput.setProperty("keyid1", skipFloweditSample.getColumnValues("keyid1", ";"));
                    plInput.setProperty("u_mocreatedt", skipFloweditSample.getColumnValues("u_mocreatedt", ";"));
                    plInput.setProperty("u_mocreateby", skipFloweditSample.getColumnValues("u_mocreateby", ";"));
                    plInput.setProperty("u_moreceivecomment", skipFloweditSample.getColumnValues("u_moreceivecomment", ";"));
                    plInput.setProperty("u_mostatus", skipFloweditSample.getColumnValues("u_mostatus", ";"));
                    plInput.setProperty("auditreason", skipFloweditSample.getColumnValues("auditreason", ";"));
                    plInput.setProperty("u_moprotocolid", skipFloweditSample.getColumnValues("u_moprotocolid", ";"));
                    plInput.setProperty("u_moprotocol", skipFloweditSample.getColumnValues("u_moprotocol", ";"));
                    plInput.setProperty("u_moprotocoltype", skipFloweditSample.getColumnValues("u_moprotocoltype", ";"));
                    plInput.setProperty("u_moprotocolstatus", skipFloweditSample.getColumnValues("u_moprotocolstatus", ";"));
                    plInput.setProperty("u_prevmoprotocol", skipFloweditSample.getColumnValues("u_prevmoprotocol", ";"));
                    plInput.setProperty("u_prevmoprotocoltype", skipFloweditSample.getColumnValues("u_prevmoprotocoltype", ";"));
                    plInput.setProperty("u_moscannerid", skipFloweditSample.getColumnValues("u_moscannerid", ";"));
//                    getActionProcessor().processAction("EditSDI", "1", plInput);
                    ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                    count++;
                }
            }


            if (moBleachStainSlide != null && moBleachStainSlide.size() > 0) {
                moBleachStainSlide.sort("previousstatus,currentstatus");
                ArrayList<DataSet> moBleachStainSlideArr=moBleachStainSlide.getGroupedDataSets("previousstatus,currentstatus");
                if(moBleachStainSlideArr!=null && moBleachStainSlideArr.size()>0) {
                    for (int i=0;i<moBleachStainSlideArr.size();i++) {
                        DataSet tempDS = moBleachStainSlideArr.get(i);
                        if(tempDS!=null && tempDS.size()>0 && !Util.isNull(tempDS.getColumnValues("sampleid", ";"))) {
                            PropertyList plInput = new PropertyList();
                            plInput.setProperty("sampleid", tempDS.getColumnValues("sampleid", ";"));
                            plInput.setProperty("previousstatus", tempDS.getValue(0,"previousstatus", ""));
                            plInput.setProperty("currentstatus", tempDS.getValue(0,"currentstatus", ""));
                            plInput.setProperty("pendingtest", tempDS.getColumnValues("pendingtest", ";"));
                            plInput.setProperty("qcstatus", Util.getUniqueList(tempDS.getColumnValues("qcstatus", ";"),";",true));
                            plInput.setProperty("bypasserror", "Y");
                            String qcflag=Util.getUniqueList(tempDS.getColumnValues("qcflag", ";"),";",true);
                            if("Y".equalsIgnoreCase(qcflag))
                            	plInput.setProperty("qcflag", qcflag);
//                            getActionProcessor().processAction("MOBleachStainSlide", "1", plInput);
                            ab.setAction("MOBleachStainSlide_"+count,"MOBleachStainSlide", "1", plInput);
                            count++;
                        }
                    }
                }
            }


            if (flowCompleteStep != null && flowCompleteStep.size() > 0 && !Util.isNull(flowCompleteStep.getColumnValues("sampleid", ";"))) {
                PropertyList plInput = new PropertyList();
                String sampleid= flowCompleteStep.getColumnValues("sampleid", ";");
                sampleid=Util.getUniqueList(sampleid,";",true);
                plInput.setProperty("sampleid", sampleid);
//                getActionProcessor().processAction("FlowCompleteStep", "1", plInput);
                ab.setAction("FlowCompleteStep_"+count,"FlowCompleteStep", "1", plInput);
                count++;
            }

            if (moSlideQC != null && moSlideQC.size() > 0) {
                moSlideQC.sort("qcstatus,auditreason");
                ArrayList<DataSet> moSlideQCArr=moSlideQC.getGroupedDataSets("qcstatus,auditreason");
                if(moSlideQCArr!=null && moSlideQCArr.size()>0) {
                    for(int i=0;i<moSlideQCArr.size();i++) {
                        DataSet tempDS=moSlideQCArr.get(i);
                        if(tempDS!=null && tempDS.size()>0 && !Util.isNull(tempDS.getColumnValues("sampleid", ";"))) {
                            PropertyList plInput = new PropertyList();
                            plInput.setProperty("sampleid", tempDS.getColumnValues("sampleid", ";"));
                            plInput.setProperty("qcstatus", tempDS.getValue(0,"qcstatus", ""));
                            plInput.setProperty("callws", "N");
                            plInput.setProperty("auditreason", tempDS.getValue(0,"auditreason", ""));
                            plInput.setProperty("stmid", tempDS.getColumnValues("stmid", ";"));
                            plInput.setProperty("batchid", tempDS.getColumnValues("batchid", ";"));
//                            getActionProcessor().processAction("MOSlideQC", "1", plInput);
                            ab.setAction("MOSlideQC_"+count,"MOSlideQC", "1", plInput);
                            count++;
                        }
                    }
                }
            }


            if (addMoImage != null && addMoImage.size() > 0) {
                addMoImage.sort("tramstop,imagetype,currentstatus");
                ArrayList<DataSet> addMoImageArr=addMoImage.getGroupedDataSets("tramstop,imagetype,currentstatus");
                if(addMoImageArr!=null && addMoImageArr.size()>0) {
                    for (int addMoImageIndx=0;addMoImageIndx<addMoImageArr.size();addMoImageIndx++ ) {
                        DataSet dsTemp=addMoImageArr.get(addMoImageIndx);
                        if(dsTemp!=null && dsTemp.size()>0 && !Util.isNull(dsTemp.getColumnValues("sampleid", ";"))) {
                            String tramstop=dsTemp.getValue(0,"tramstop","");
                            String imagetype=dsTemp.getValue(0,"imagetype","");
                            String currentstatus=dsTemp.getValue(0,"currentstatus","");
                            PropertyList plInput = new PropertyList();
                            plInput.setProperty("tramstop", tramstop);
                            plInput.setProperty("sampleid", dsTemp.getColumnValues("sampleid", ";"));
                            plInput.setProperty("imagetype", imagetype);
                            plInput.setProperty("keyid1", dsTemp.getColumnValues("keyid1", ";"));
                            plInput.setProperty("u_moreceivecomment", dsTemp.getColumnValues("u_moreceivecomment", ";"));
                            plInput.setProperty("u_mostatus", dsTemp.getColumnValues("u_mostatus", ";"));
                            plInput.setProperty("teststatus", dsTemp.getColumnValues("teststatus", ";"));
                            plInput.setProperty("testcodeid", dsTemp.getColumnValues("testcodeid", ";"));
                            plInput.setProperty("lvtestpanelid", dsTemp.getColumnValues("lvtestpanelid", ";"));
                            plInput.setProperty("auditreason", dsTemp.getColumnValues("auditreason", ";"));
                            plInput.setProperty("batchid", dsTemp.getColumnValues("batchid", ";"));
                            if(!Util.isNull(currentstatus))
                                plInput.setProperty("currentstatus", currentstatus);
//                            getActionProcessor().processAction("AddMOImage", "1", plInput);
                            ab.setAction("AddMOImage_"+count,"AddMOImage", "1", plInput);
                            count++;
                        }
                    }
                }
            }

            if (skipFlowaddMoImage != null && skipFlowaddMoImage.size() > 0) {
                skipFlowaddMoImage.sort("tramstop,imagetype,currentstatus");
                ArrayList<DataSet> addMoImageArr=skipFlowaddMoImage.getGroupedDataSets("tramstop,imagetype,currentstatus");
                if(addMoImageArr!=null && addMoImageArr.size()>0) {
                    for (int addMoImageIndx=0;addMoImageIndx<addMoImageArr.size();addMoImageIndx++ ) {
                        DataSet dsTemp=addMoImageArr.get(addMoImageIndx);
                        if(dsTemp!=null && dsTemp.size()>0 && !Util.isNull(dsTemp.getColumnValues("sampleid", ";"))) {
                            String tramstop=dsTemp.getValue(0,"tramstop","");
                            String imagetype=dsTemp.getValue(0,"imagetype","");
                            String currentstatus=dsTemp.getValue(0,"currentstatus","");
                            PropertyList plInput = new PropertyList();
                            plInput.setProperty("tramstop", tramstop);
                            plInput.setProperty("sampleid", dsTemp.getColumnValues("sampleid", ";"));
                            plInput.setProperty("imagetype", imagetype);
                            plInput.setProperty("keyid1", dsTemp.getColumnValues("keyid1", ";"));
                            plInput.setProperty("u_moreceivecomment", dsTemp.getColumnValues("u_moreceivecomment", ";"));
                            plInput.setProperty("u_mostatus", dsTemp.getColumnValues("u_mostatus", ";"));
                            plInput.setProperty("teststatus", dsTemp.getColumnValues("teststatus", ";"));
                            plInput.setProperty("testcodeid", dsTemp.getColumnValues("testcodeid", ";"));
                            plInput.setProperty("lvtestpanelid", dsTemp.getColumnValues("lvtestpanelid", ";"));
                            plInput.setProperty("auditreason", dsTemp.getColumnValues("auditreason", ";"));
                            plInput.setProperty("batchid", dsTemp.getColumnValues("batchid", ";"));
                            if(!Util.isNull(currentstatus))
                                plInput.setProperty("currentstatus", currentstatus);
//                            getActionProcessor().processAction("AddMOImage", "1", plInput);
                            ab.setAction("AddMOImage_"+count,"AddMOImage", "1", plInput);
                            count++;
                        }
                    }
                }
            }

            if (protocolInfo != null && protocolInfo.size() > 0 && !Util.isNull(protocolInfo.getColumnValues("keyid1", ";"))) {
                PropertyList plInput = new PropertyList();
                plInput.setProperty("sdcid", "Sample");
                plInput.setProperty("keyid1", protocolInfo.getColumnValues("keyid1", ";"));
                plInput.setProperty("u_moprotocolid", protocolInfo.getColumnValues("u_moprotocolid", ";"));
                plInput.setProperty("u_moprotocol", protocolInfo.getColumnValues("u_moprotocol", ";"));
                plInput.setProperty("u_moprotocoltype", protocolInfo.getColumnValues("u_moprotocoltype", ";"));
                plInput.setProperty("u_moprotocolstatus", protocolInfo.getColumnValues("u_moprotocolstatus", ";"));
                plInput.setProperty("u_prevmoprotocol", protocolInfo.getColumnValues("u_prevmoprotocol", ";"));
                plInput.setProperty("u_prevmoprotocoltype", protocolInfo.getColumnValues("u_prevmoprotocoltype", ";"));
                plInput.setProperty("u_moscannerid", protocolInfo.getColumnValues("u_moscannerid", ";"));
//                getActionProcessor().processAction("EditSDI", "1", plInput);
                ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                count++;
            }
            if (editProtocolType != null && editProtocolType.size() > 0 && !Util.isNull(editProtocolType.getColumnValues("keyid1", ";"))) {
                PropertyList plInput = new PropertyList();
                plInput.setProperty("sdcid", "Sample");
                plInput.setProperty("keyid1", editProtocolType.getColumnValues("keyid1", ";"));
                plInput.setProperty("u_moprotocoltype", editProtocolType.getColumnValues("u_moprotocoltype", ";"));
                plInput.setProperty("u_moprotocolstatus", editProtocolType.getColumnValues("u_moprotocolstatus", ";"));
                plInput.setProperty("u_prevmoprotocoltype", editProtocolType.getColumnValues("u_prevmoprotocoltype", ";"));
//                getActionProcessor().processAction("EditSDI", "1", plInput);
                ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                count++;
            }

            if (stmprotocolInfo != null && stmprotocolInfo.size() > 0 && !Util.isNull(stmprotocolInfo.getColumnValues("keyid1", ";"))) {
                PropertyList plInput = new PropertyList();
                plInput.setProperty("sdcid", "SampleTestCodeMap");
                plInput.setProperty("keyid1", stmprotocolInfo.getColumnValues("keyid1", ";"));
                plInput.setProperty("moprotocolid", stmprotocolInfo.getColumnValues("moprotocolid", ";"));
                plInput.setProperty("moprotocol", stmprotocolInfo.getColumnValues("moprotocol", ";"));
                plInput.setProperty("moprotocoltype", stmprotocolInfo.getColumnValues("moprotocoltype", ";"));
                plInput.setProperty("moprotocolstatus", stmprotocolInfo.getColumnValues("moprotocolstatus", ";"));
                plInput.setProperty("prevmoprotocol", stmprotocolInfo.getColumnValues("prevmoprotocol", ";"));
                plInput.setProperty("prevmoprotocoltype", stmprotocolInfo.getColumnValues("prevmoprotocoltype", ";"));
//                getActionProcessor().processAction("EditSDI", "1", plInput);
                ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                count++;
            }
            if (editSTMProtocolType != null && editSTMProtocolType.size() > 0 && !Util.isNull(editSTMProtocolType.getColumnValues("keyid1", ";"))) {
                PropertyList plInput = new PropertyList();
                plInput.setProperty("sdcid", "SampleTestCodeMap");
                plInput.setProperty("keyid1", editSTMProtocolType.getColumnValues("keyid1", ";"));
                plInput.setProperty("moprotocoltype", editSTMProtocolType.getColumnValues("moprotocoltype", ";"));
                plInput.setProperty("moprotocolstatus", editSTMProtocolType.getColumnValues("moprotocolstatus", ";"));
                plInput.setProperty("prevmoprotocoltype", editSTMProtocolType.getColumnValues("prevmoprotocoltype", ";"));
//                getActionProcessor().processAction("EditSDI", "1", plInput);
                ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                count++;
            }

            if (disputedDS != null && disputedDS.size() > 0) {
                String errMSG = "Update operation cannnot be performed in the Multiomyx db for the below sample(s)\n" +
                        "<table border=1>" +
                        "<tr border=1><th>Slide Id</th><th>Reason</th></tr>";
                for (int i = 0; i < disputedDS.size(); i++) {
                    errMSG += "<tr border=1><td>" + disputedDS.getValue(i, "slideid", "") + "</td><td>" + disputedDS.getValue(i, "message", "") + "</td></tr>";
                }
                errMSG += "</table>";
                throw new SapphireException(errMSG);
            }


            if (resultSTMDS != null && resultSTMDS.size() > 0 && !Util.isNull(resultSTMDS.getColumnValues("u_sampletestcodemapid", ";"))) {
                PropertyList plInput = new PropertyList();
                plInput.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                plInput.setProperty(EditSDI.PROPERTY_KEYID1, resultSTMDS.getColumnValues("u_sampletestcodemapid", ";"));
                plInput.setProperty("moprotocol", resultSTMDS.getColumnValues("moprotocol", ";"));
                plInput.setProperty("moprotocoltype", resultSTMDS.getColumnValues("moprotocoltype", ";"));
                plInput.setProperty("prevmoprotocol", resultSTMDS.getColumnValues("prevmoprotocol", ";"));
                plInput.setProperty("prevmoprotocoltype", resultSTMDS.getColumnValues("prevmoprotocoltype", ";"));
                plInput.setProperty("moprotocolstatus", resultSTMDS.getColumnValues("moprotocolstatus", ";"));
                plInput.setProperty("moprotocolid", resultSTMDS.getColumnValues("moprotocolid", ";"));

//                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plInput);
                ab.setAction("EditSDI_"+count,"EditSDI", "1", plInput);
                count++;
            }
            if(!Util.isNull(roiSelCompltSamples)) {
                if(roiSelCompltSamples.startsWith(";"))
                    roiSelCompltSamples=roiSelCompltSamples.substring(1);
                routeSampleFromPathologyToMO(roiSelCompltSamples,ab,count);
            }
            if(ab!=null && ab.getActionCount()>0){
                getActionProcessor().processActionBlock(ab);
            }
        }
    }

    /*********************************************
     * This method is used to call the
     * cancelSlide operation of LWS service
     *
     * @param props
     * @param proxy
     * @throws SapphireException
     ********************************************/
    private void cancelSlide(PropertyList props, LWSServiceSoap proxy) throws SapphireException {
        String sampleIds = props.getProperty("sampleIdList");
        if(!Util.isNull(sampleIds)) {
            sampleIds=Util.getUniqueList(sampleIds,";",true);
            String[] sampleIdArr = StringUtil.split(sampleIds, ";");
            String sampleData = EMPTY_STRING;
            Map<String, String> responseData = new HashMap<>();
            Map<String, String> messageData = new HashMap<>();
            for (String sample : sampleIdArr) {
                PropertyList pls = new PropertyList();
                pls.setProperty("slideid", sample);
                String response = proxy.cancelSlide(pls.toXMLString());
                PropertyList responseList = new PropertyList();
                responseList.setPropertyList(response);
                responseData.put(pls.getProperty("slideid"), responseList.getProperty("response"));
                messageData.put(pls.getProperty("slideid"), responseList.getProperty("message"));
            }
            for (Map.Entry<String, String> entry : responseData.entrySet()) {
                if ("success".equalsIgnoreCase(entry.getValue())) {
                    sampleData = sampleData + ";" + entry.getKey();
                    messageData.remove(entry.getKey());
                }
            }

            if (!messageData.isEmpty()) {
                String failureMsg = "Below sample(s) cannnot be cancelled in the Multiomyx \n" +
                        "<table border=1>" +
                        "<tr border=1><th>Slide Id</th><th>Reason</th></tr>";
                for (Map.Entry<String, String> msg : messageData.entrySet()) {
                    failureMsg += "<tr border=1><td>" + msg.getKey() + "</td><td>" + msg.getValue() + "</td></tr>";
                }
                failureMsg += "</table>";
                throw new SapphireException(failureMsg);
            }

            if (!isNull(sampleData)) {
                //EditSDI for Sample
                sampleData = sampleData.substring(1);
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleData);
                pl.setProperty("u_mostatus", "Cancelled");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                //EditSDI for SampleTestCodeMap
                String sampleList = StringUtil.replaceAll(sampleData, ";", "','");
                String query = Util.parseMessage(MultiomyxSql.GET_STM_BY_SAMPLEID, sampleList);
                DataSet dsSTM = getQueryProcessor().getSqlDataSet(query);
                if (dsSTM != null && dsSTM.getRowCount() > 0) {
                    pl.clear();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, dsSTM.getColumnValues("u_sampletestcodemapid", ";"));
                    pl.setProperty("teststatus", "Cancelled");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                }

                //EditSDI for MOImage
                query = Util.parseMessage(MultiomyxSql.GET_MOIMAGE_BY_SAMPLEID, sampleList);
                DataSet dsMOImage = getQueryProcessor().getSqlDataSet(query);
                if (dsMOImage != null && dsMOImage.getRowCount() > 0) {
                    pl.clear();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, dsMOImage.getColumnValues("u_moimageid", ";"));
                    pl.setProperty("status", "Cancelled");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                }
            }
        }
    }

    private void undoCancelSlide(PropertyList props, LWSServiceSoap proxy) throws SapphireException {

        String sampleIds = props.getProperty("sampleIdList");
        String protocolIds = props.getProperty("protocolIdList");
        String batchIds = props.getProperty("batchid");

        if(!Util.isNull(sampleIds)) {

            String[] sampleIdArr = StringUtil.split(sampleIds, ";");
            String[] protocolIdArr = StringUtil.split(protocolIds, ";");
            String[] batchIdArr = StringUtil.split(batchIds, ";");
            String sampleData = EMPTY_STRING;
            // Implemented action to update undo cancel in LWS system
            Map<String, String> responseData = new HashMap<>();
            Map<String, String> messageData = new HashMap<>();

            for (int i=0; i<sampleIdArr.length; i++) {
                PropertyList pls = new PropertyList();
                pls.setProperty("slideid", sampleIdArr[i]);
                pls.setProperty("batchid", batchIdArr[i]);
                pls.setProperty("protocolid", protocolIdArr[i]);
                String response = proxy.undoCancelSlide(pls.toXMLString());

                PropertyList responseList = new PropertyList();
                responseList.setPropertyList(response);

                responseData.put(pls.getProperty("slideid"), responseList.getProperty("response"));
                messageData.put(pls.getProperty("slideid"), responseList.getProperty("message"));
            }
            for (Map.Entry<String, String> entry : responseData.entrySet()) {
                if ("success".equalsIgnoreCase(entry.getValue())) {
                    sampleData = sampleData + ";" + entry.getKey();
                    messageData.remove(entry.getKey());
                }
            }

            if (!messageData.isEmpty()) {
                String failureMsg = "Undo-Cancel operation cannot be performed for below sample(s) in the Multiomyx \n" +
                        "<table border=1>" +
                        "<tr border=1><th>Slide Id</th><th>Reason</th></tr>";
                for (Map.Entry<String, String> msg : messageData.entrySet()) {
                    failureMsg += "<tr border=1><td>" + msg.getKey() + "</td><td>" + msg.getValue() + "</td></tr>";
                }
                failureMsg += "</table>";
                throw new SapphireException(failureMsg);
            }
            // If successful in Undo-Cancel ----- Restart the data service automatically
            //datasourceRestart(proxy);
            // Implemented action to update undo cancel in LV system
            PropertyList pl = new PropertyList();
            if(sampleData.startsWith(";"))
                sampleData = sampleData.substring(1);

            if (!isNull(sampleData)) {
                //EditSDI for Sample
                String sampleList = StringUtil.replaceAll(sampleData, ";", "','");
                String query = Util.parseMessage(MultiomyxSql.GET_PREV_MOSTAT_BY_SAMPLEID, sampleList);
                DataSet dsSample = getQueryProcessor().getSqlDataSet(query);
                if (dsSample != null && dsSample.getRowCount() > 0) {

                    pl.clear();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, dsSample.getColumnValues("s_sampleid", ";"));
                    pl.setProperty("u_mostatus", dsSample.getColumnValues("u_prevmostatus", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                }

                //EditSDI for SampleTestCodeMap
                query = Util.parseMessage(MultiomyxSql.GET_STM_BY_SAMPLEID, sampleList);
                DataSet dsSTM = getQueryProcessor().getSqlDataSet(query);
                if (dsSTM != null && dsSTM.getRowCount() > 0) {
                    pl.clear();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, dsSTM.getColumnValues("u_sampletestcodemapid", ";"));
                    pl.setProperty("teststatus", dsSTM.getColumnValues("prevteststatus", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                }

                //EditSDI for MOImage
                query = Util.parseMessage(MultiomyxSql.GET_MOIMAGE_BY_SAMPLEID, sampleList);
                DataSet dsMOImage = getQueryProcessor().getSqlDataSet(query);
                if (dsMOImage != null && dsMOImage.getRowCount() > 0) {
                    pl.clear();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, dsMOImage.getColumnValues("u_moimageid", ";"));
                    pl.setProperty("status", dsMOImage.getColumnValues("prevstatus", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                }
            }

        }

    }

    private void routeSampleFromPathologyToMO(String sampleid,ActionBlock ab,int count) throws SapphireException{
        if(!Util.isNull(sampleid) && ab!=null){
            if(sampleid.startsWith(";"))
                sampleid=sampleid.substring(1);
            String sql=Util.parseMessage(MultiomyxSql.SAMPLE_IN_PATHOLOGY,StringUtil.replaceAll(sampleid,";","','"));
            DataSet dsSampleInfo=getQueryProcessor().getSqlDataSet(sql);

            if(dsSampleInfo!=null && dsSampleInfo.size()>0){
                sampleid=dsSampleInfo.getColumnValues("s_sampleid",";");

                if(!Util.isNull(sampleid)) {
                    sql = Util.parseMessage(MultiomyxSql.MO_TRACKITEMID_FROM_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
                    DataSet dsTIInfo = getQueryProcessor().getSqlDataSet(sql);
                    DataSet result = new DataSet();
                    if (dsTIInfo != null && dsTIInfo.size() > 0) {
                        dsTIInfo.addColumn("destdept", DataSet.STRING);
                        for (int i = 0; i < dsTIInfo.size(); i++) {
                            String tempDept = dsTIInfo.getValue(i, "custodialdepartmentid", "");
                            if (!Util.isNull(tempDept)) {
                                String site = StringUtil.split(tempDept, "-")[0];
                                if (!Util.isNull(site)) {
                                    String destDept = site + "-" + "MOWetLab";
                                    dsTIInfo.setValue(i, "destdept", destDept);
                                    result.copyRow(dsTIInfo, i, 1);
                                }
                            }
                        }
                    }

                    if (result != null && result.size() > 0) {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, result.getColumnValues("linkkeyid1", ";"));
                        pl.setProperty("u_currentmovementstep", "MOImageROI");

//                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                        ab.setAction("EditSDI_"+count,"EditSDI", "1", pl);
                        count++;

                        pl = new PropertyList();
                        pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID, "Sample");
                        pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1, result.getColumnValues("linkkeyid1", ";"));
                        pl.setProperty("custodialdepartmentid", result.getColumnValues("destdept", ";"));
                        pl.setProperty("custodialuserid", StringUtil.repeat("(null)", result.size(), ";"));
                        pl.setProperty("currentstorageunitid", StringUtil.repeat("(null)", result.size(), ";"));
                        pl.setProperty("u_currenttramstop", StringUtil.repeat("MOImageROI", result.size(), ";"));
                        pl.setProperty("__sdcruleconfirm", "Y");

//                        getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID, pl);
                        ab.setAction("EditTrackItem_"+count, EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        count++;

                    }
                }
            }
        }
    }

    private void datasourceRestart(LWSServiceSoap proxy) throws SapphireException{
        if(proxy!=null) {
            String responseXML = proxy.restartDataServices();
            PropertyList responsePL=new PropertyList();
            responsePL.setPropertyList(responseXML);
            String response=responsePL.getProperty("response","");
            String message=responsePL.getProperty("message","");
            if(!"success".equalsIgnoreCase(response))
                throw new SapphireException("Unable to Restart Data Service.. " +message);
        }
    }

    private void sampleRollBk(PropertyList props, LWSServiceSoap proxy)throws SapphireException{
        if(props!=null && proxy!=null){
            String slideid=props.getProperty("slideid","");
            String protocolid=props.getProperty("protocolid","");
            if(Util.isNull(slideid))
                throw new SapphireException("Slide Id obtained as blank");
            if(Util.isNull(protocolid))
                throw new SapphireException("Protocol Id obtained as blank");

            PropertyList pls = new PropertyList();
            pls.setProperty("slideid", slideid);
            pls.setProperty("protocolid", protocolid);
            String responseXML = proxy.rollbackSlide(pls.toXMLString());
            PropertyList responsePL=new PropertyList();
            responsePL.setPropertyList(responseXML);
            String response=responsePL.getProperty("response","");
            String message=responsePL.getProperty("message","");
            if(!"success".equalsIgnoreCase(response))
                throw new SapphireException(message);
        }
    }

}
