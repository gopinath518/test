package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;


public class MOMoveToPathSupport extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String destCurrentmovementStep = "PathSupport";
        String destDept = "";
        String dept = connectionInfo.getDefaultDepartment();

        if (dept.contains("-")) {
            destDept = dept.substring(0, (dept.indexOf("-") + 1)) + "Accessioning";
        } else
            throw new SapphireException("Department for Current User not found");

        if (Util.isNull(sampleid))
            throw new SapphireException("SampleId(s) cannot be obtained.");

        if (!Util.isNull(sampleid)) {

            try {
                PropertyList prop = new PropertyList();
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                prop.setProperty("u_currentmovementstep", destCurrentmovementStep);
                prop.setProperty("u_mostatus", "(null)");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

                PropertyList propTrack = new PropertyList();
                propTrack.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                propTrack.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
                propTrack.setProperty("custodialdepartmentid", destDept);
                propTrack.setProperty("custodialuserid", "");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, propTrack);
            } catch (SapphireException se) {
                String error = getTranslationProcessor().translate("Samples not moved to Path Support. " + se.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }

        }

    }
}
