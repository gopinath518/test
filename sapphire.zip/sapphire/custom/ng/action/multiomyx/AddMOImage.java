package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by aritra.banerjee on 9/7/2017.
 */
public class AddMOImage  extends BaseAction implements MOConstants {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String tramstop = properties.getProperty(CONSTANT_TRAMSTOP, "");
        if(!Util.isNull(tramstop)){
            if(CONSTANT_TRAMSTOP_MOSTAIN.equalsIgnoreCase(tramstop))
                functionalityMOStain(properties);
            else if(CONSTANT_TRAMSTOP_MOIMAGEROI.equalsIgnoreCase(tramstop)
                    || CONSTANT_TRAMSTOP_MOSAMPLEPREP.equalsIgnoreCase(tramstop))
                functionalityAddImage(properties);
            else if(CONSTANT_TRAMSTOP_MOBLEACH.equalsIgnoreCase(tramstop))
                functionalityAddImageBleach(properties);
            else
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: Tramstop Name- "+tramstop+" is not Valid.");
        }else
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: No Tramstop Details found.");
    }

    /**
     * This method is for
     * Updates moreceivecomment, mostatus and auditreason for selected samples in Sample SDC
     * Updates test status for the selected test
     * Also adds Image details into MOImage SDC for tram stop - MOStain
     * @param properties
     * @throws SapphireException
     */

    private void functionalityMOStain(PropertyList properties) throws SapphireException{

        String sampleid = properties.getProperty(SELECTED_SAMPLEID, "");
        String sampletestcodemapid = properties.getProperty(STM_SDC_COL_KEYID1, "");
        if(Util.isNull(sampleid))
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: Sample Id not found.");
        else if (Util.isNull(sampletestcodemapid))
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: SampleTestCodeMap Id not found.");

        //Updates moreceivecomment, mostatus and auditreason for selected samples in Sample SDC
        if(!Util.isNull(sampleid)){

            String moreceivecomment = properties.getProperty(SAMPLE_SDC_COL_MORERCVCOMNTS, "");
            String mostatus = properties.getProperty(SAMPLE_SDC_COL_MOSTATUS, "");
            String auditreason = properties.getProperty(SAMPLE_SDC_COL_AUDITREASON, "");
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_SAMPLE);
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
            pl.setProperty(SAMPLE_SDC_COL_MORERCVCOMNTS, moreceivecomment);
            pl.setProperty(SAMPLE_SDC_COL_MOSTATUS, mostatus);
            pl.setProperty(SAMPLE_SDC_COL_AUDITREASON, auditreason);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

        //Updates test status for the selected tests
        if(!Util.isNull(sampletestcodemapid)){

            String teststatus = properties.getProperty(CONSTANT_TESTSTATUS, "");
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_STM);
            pl.setProperty(EditSDI.PROPERTY_KEYID1, sampletestcodemapid);
            pl.setProperty(CONSTANT_TESTSTATUS, teststatus);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }

        // Adds Image details into MOImage SDC for tram stop - MOStain
        if(!Util.isNull(sampleid)){

            String imagetype = properties.getProperty(CONSTANT_IMAGETYPE, "");
            String testcodeid = properties.getProperty(SAMPLE_SDC_COL_TCODEID, "");
            String lvtestpanelid = properties.getProperty(SAMPLE_SDC_COL_PANELID, "");
            String batchid = properties.getProperty(CONSTANT_BATCHID, "");
            PropertyList pl = new PropertyList();
            pl.setProperty(AddSDI.PROPERTY_SDCID, SDC_NAME_MOIMAGE);
            pl.setProperty(AddSDI.PROPERTY_COPIES, ""+sampleid.split(";").length);
            pl.setProperty(CONSTANT_IMAGETYPE, imagetype);
            pl.setProperty(SAMPLE_SDC_COL_TCODEID, testcodeid);
            pl.setProperty(SAMPLE_SDC_COL_PANELID, lvtestpanelid);
            pl.setProperty(SELECTED_SAMPLEID, sampleid);
            pl.setProperty(CONSTANT_BATCHID, batchid);
            pl.setProperty(CONSTANT_SAMPLETESTCODEMAPID, sampletestcodemapid);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            String moImgId = pl.getProperty("newkeyid1");

            if(!Util.isNull(moImgId)){
                assignImagePanelStp(moImgId,lvtestpanelid);
            }
        }

    }

    /**
     * This method assigns Routing steps with the newly created Stained Images into MOImagePanelStpMap SDC
     * @param moImgId
     */
    private void assignImagePanelStp(String moImgId, String lvtestpanelid) throws SapphireException {

        DataSet dsResult = new DataSet();
        dsResult.addColumn("moimageid",DataSet.STRING);
        dsResult.addColumn("panelid",DataSet.STRING);
        dsResult.addColumn("stepname",DataSet.STRING);
        dsResult.addColumn("stepno",DataSet.STRING);
        dsResult.addColumn("status",DataSet.STRING);

        String uniquePanelid = Util.getUniqueList(lvtestpanelid,";",true);
        String sql = Util.parseMessage(MultiomyxSql.GET_TCODE_BY_PANELID, StringUtil.replaceAll(uniquePanelid, ";", "','"));
        DataSet dsPanelwiseTcode = getQueryProcessor().getSqlDataSet(sql);
        DataSet dsAllPanelTcodeSteps = null;

        if(dsPanelwiseTcode != null && dsPanelwiseTcode.size() > 0){
            String allTcodes = dsPanelwiseTcode.getColumnValues("indtestcodeid",";");
            String allPanelTcodeSteps = uniquePanelid + ";" + allTcodes;
            sql = Util.parseMessage(MultiomyxSql.GET_STEPS_BY_TCODEID_AL, StringUtil.replaceAll(allPanelTcodeSteps, ";", "','"));
            dsAllPanelTcodeSteps = getQueryProcessor().getSqlDataSet(sql);
        }
        if(dsPanelwiseTcode == null)
            throw new SapphireException("Error: Unable to fetch Panel-Test_code Details.");

        if(dsAllPanelTcodeSteps == null)
            throw new SapphireException("Error: Unable to fetch Step Details.");

        sql = Util.parseMessage(MultiomyxSql.GET_MOIMAGE_DETAIL_BY_IMAGEID, StringUtil.replaceAll(moImgId, ";", "','"));
        DataSet dsData = getQueryProcessor().getSqlDataSet(sql);

        if(dsData == null || dsData.size() == 0)
            throw new SapphireException("Error: Unable to fetch MOImage Details.");

        for(int i=0;i<dsData.size();i++){
            String moimageid = dsData.getValue(i,"u_moimageid");
            String pnlid = dsData.getValue(i,"lvtestpanelid");

            HashMap hm = new HashMap();
            hm.put("moimageid",moimageid);
            hm.put("panelid",pnlid);

            DataSet dsFilter = dsResult.getFilteredDataSet(hm);

            if(dsFilter.size() == 0){
                hm.clear();
                hm.put("u_testcodeid", pnlid);
                DataSet dsFilterStep = dsAllPanelTcodeSteps.getFilteredDataSet(hm);
                if(dsFilterStep.size() > 0){ // panel has steps defined

                    for(int j=0;j<dsFilterStep.size();j++){
                        int rowId = dsResult.addRow();
                        dsResult.setValue(rowId,"moimageid",moimageid);
                        dsResult.setValue(rowId,"panelid",pnlid);
                        dsResult.setValue(rowId,"stepname", dsFilterStep.getValue(j,"stepname"));
                        dsResult.setValue(rowId,"stepno", dsFilterStep.getValue(j,"stepno"));
                        dsResult.setValue(rowId,"status","Pending");
                    }
                }
                else { // panel doesnt have steps defined, hence tcode steps needs to be considered
                    hm.clear();
                    hm.put("u_testcodeid",pnlid);
                    DataSet dsfilterTcode = dsPanelwiseTcode.getFilteredDataSet(hm);
                    if(dsfilterTcode.size() == 0)
                        throw new SapphireException("Error: No Test code details found for Panel -"+pnlid);

                    if(dsfilterTcode.size() > 0){
                        for(int j=0;j<dsfilterTcode.size();j++){
                            hm.clear();
                            hm.put("u_testcodeid", dsfilterTcode.getValue(j, "indtestcodeid"));
                            DataSet dsFilterTcodeStep = dsAllPanelTcodeSteps.getFilteredDataSet(hm);
                            if(dsFilterTcodeStep.size() > 0) { // current tcode has steps defined
                                for(int k=0;k<dsFilterTcodeStep.size();k++) {
                                    int rowId = dsResult.addRow();
                                    dsResult.setValue(rowId, "moimageid", moimageid);
                                    dsResult.setValue(rowId, "panelid", pnlid);
                                    dsResult.setValue(rowId, "stepname", dsFilterTcodeStep.getValue(k, "stepname"));
                                    dsResult.setValue(rowId, "stepno", dsFilterTcodeStep.getValue(k, "stepno"));
                                    dsResult.setValue(rowId, "status", "Pending");
                                }
                            }
                            break;
                        }
                    }
                }

            }
        }

        if(dsResult.size() > 0){
            try {
                PropertyList pl = new PropertyList();
                pl.setProperty(AddSDI.PROPERTY_SDCID, "MOImagePanelStpMap");
                pl.setProperty(AddSDI.PROPERTY_COPIES, ""+dsResult.size());
                pl.setProperty("moimageid", dsResult.getColumnValues("moimageid",";"));
                pl.setProperty("lvpanelid", dsResult.getColumnValues("panelid",";"));
                pl.setProperty("stepname", dsResult.getColumnValues("stepname",";"));
                pl.setProperty("stepno", dsResult.getColumnValues("stepno",";"));
                pl.setProperty("status", dsResult.getColumnValues("status",";"));


                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);


            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to add data into ImagePanelStpMap.");
            }
        }

    }

    /**
     * This method Adds Image details into MOImage SDC for tram stops - MOImageROI/ MOSamplePrep/ MOBleach.
     * @param properties
     * @throws SapphireException
     */

    private void functionalityAddImage(PropertyList properties) throws SapphireException{

        String imagetype = properties.getProperty(CONSTANT_IMAGETYPE, "");
        String sampleid = properties.getProperty(SELECTED_SAMPLEID, "");
        String batchid = properties.getProperty(CONSTANT_BATCHID, "");

        if(!Util.isNull(sampleid)){

            PropertyList pl = new PropertyList();
            pl.setProperty(AddSDI.PROPERTY_SDCID, SDC_NAME_MOIMAGE);
            pl.setProperty(AddSDI.PROPERTY_COPIES, ""+sampleid.split(";").length);
            pl.setProperty(CONSTANT_IMAGETYPE, imagetype);
            pl.setProperty(CONSTANT_BATCHID, batchid);
            pl.setProperty(SELECTED_SAMPLEID, sampleid);
            pl.setProperty("status", "In Progress");

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        }else
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: Sample Id not found.");
    }

    /**
     * This method Adds Image details into MOImage SDC for tram stops -  MOBleach.
     * @param properties
     * @throws SapphireException
     */
    private void functionalityAddImageBleach(PropertyList properties) throws SapphireException{
        String imagetype = properties.getProperty(CONSTANT_IMAGETYPE, "");
        String sampleid = properties.getProperty(SELECTED_SAMPLEID, "");
        String batchid = properties.getProperty(CONSTANT_BATCHID, "");
        String currentstatus = properties.getProperty(CONSTANT_CURRENTTESTSTATUS, "");
        if(!Util.isNull(currentstatus)) {
            String sqldata = Util.parseMessage(MultiomyxSql.GET_SAMPLETESTCODEMAPID_BY_TESTSTATUS, currentstatus,StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsTestcodeMapid = getQueryProcessor().getSqlDataSet(sqldata);
            if(dsTestcodeMapid == null || dsTestcodeMapid.size() == 0) {
                logger.info("functionalityAddImageBleach : Query not returning any row");
//                throw new SapphireException("Error occur. Please contact to administrator");
                return;
            }

            PropertyList pl = new PropertyList();
            pl.setProperty(AddSDI.PROPERTY_SDCID, SDC_NAME_MOIMAGE);
            pl.setProperty(AddSDI.PROPERTY_COPIES, "" + dsTestcodeMapid.size());
            pl.setProperty(CONSTANT_SAMPLETESTCODEMAPID,dsTestcodeMapid.getColumnValues(SAMPLETESTCODEMAP_COL_MAPID,";"));
            pl.setProperty(CONSTANT_IMAGETYPE, imagetype);
            pl.setProperty(CONSTANT_BATCHID, batchid);
            pl.setProperty(SELECTED_SAMPLEID, sampleid);
            pl.setProperty(SAMPLE_SDC_COL_PANELID, dsTestcodeMapid.getColumnValues(SAMPLE_SDC_COL_PANELID,";"));
            pl.setProperty(SAMPLE_SDC_COL_TCODEID, dsTestcodeMapid.getColumnValues(CONSTATNT_SQL_LVTESTCODEID,";"));

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        }else
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: CurrentStatus not found.");
    }








}
