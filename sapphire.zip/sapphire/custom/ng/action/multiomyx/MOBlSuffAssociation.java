/**
 * 
 */
package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class MOBlSuffAssociation extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sampleId = properties.getProperty("ctrlsampleid", "");
		String auditId = properties.getProperty("moregauditid", "");
		String bleachRound = properties.getProperty("blround", "");
		String marker = properties.getProperty("markerid", "");
		String regLotId = properties.getProperty("reglotid", "");
		int copies = StringUtil.split(auditId, ";").length;
		
		if(!Util.isNull(sampleId)){
			String query = Util.parseMessage(MultiomyxSql.GET_BLEACH_SUFFICIENT_SAMPLE, StringUtil.replaceAll(sampleId, ";", "','"));
			DataSet blDS = getQueryProcessor().getSqlDataSet(query);
			if(blDS != null && blDS.getRowCount() > 0){
				String sample = blDS.getColumnValues("ctrlsampleid", ",");
				if(!Util.isNull(sample)){
					throw new SapphireException("ERROR_TYPE",ErrorDetail.TYPE_VALIDATION,
							"\nBleach Sufficiency has been already performed on the following samples :: \n"+Util.getUniqueList(sample, ",", true));
				}
			}
		}
		
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDI.PROPERTY_SDCID, "MORegMarkerSelAudit");
		pl.setProperty(AddSDI.PROPERTY_COPIES, ""+copies);
		pl.setProperty("ctrlsampleid", sampleId);
		pl.setProperty("bleachroundno", StringUtil.repeat(bleachRound, copies, ";"));
		pl.setProperty("markerid", StringUtil.repeat(marker, copies, ";"));
		pl.setProperty("parentinitdcauditid", auditId);
		pl.setProperty("operation", StringUtil.repeat("BleachSufficiency", copies, ";"));
		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
		
	}
}
