package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by aritra.banerjee on 8/29/2017.
 * This Action will be called for Auto Routing Logic of Multiomyx.
 *
 * @Input : Sample Ids and Image Ids
 * @Input : Flag to determine the LAB
 */
public class FlowCompleteStep extends BaseAction implements MOConstants{

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty(SELECTED_SAMPLEID, "");
        String moimgId = properties.getProperty("moimgid", "");

        String flag = properties.getProperty("flag", "");

/*        if(Util.isNull(flag))
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, " Unable to determine the Lab for which routing will be done.");*/

        if("AL".equalsIgnoreCase(flag)) {
            if (Util.isNull(moimgId))
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, " Insuffient Data: Image Id missing.");
            else {
                moimgId = Util.getUniqueList(moimgId, ";", true);
                setNextStepForAL(moimgId);
                properties.setProperty(FLOWCMPLTSTP_OUTPUT_PROP_MSG, moimgId + " - have been moved to next Step");
            }
        } else {
            if (Util.isNull(sampleId))
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, " Insuffient Data: SampleId missing.");
            else {
                sampleId = Util.getUniqueList(sampleId, ";", true);
                setNextStep(sampleId);
                properties.setProperty(FLOWCMPLTSTP_OUTPUT_PROP_MSG, sampleId + " - have been moved to next Step");
            }
        }

    }

    /**
     * The setNextStep method creates two DataSet
     * Among them one contains the step details which needs tobe completed
     * And another contains the details where needs tobe Routed
     *
     * @param sampleId
     * @throws SapphireException
     */

    private void setNextStep(String sampleId) throws SapphireException {

        // Below SQL is to Fetch Pending Routing Step Details of Sampleid from SamplePanelStpMap SDC
        String sql = Util.parseMessage(MultiomyxSql.GET_STEPS_BY_SAMPLEID, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        // Checking whether sql is returning Null value/Empty or not
        if (dsSql == null || dsSql.isEmpty())
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: Unable to fetch Panel Step Details.");

        DataSet dsComplete = new DataSet();
        dsComplete.addColumn(DSCOMPLETE_COL1_SAMPLEPANELSTPMAPID, DataSet.STRING);
        dsComplete.addColumn(DSCOMPLETE_COL2_STATUS, DataSet.STRING);

        DataSet dsNextStep = new DataSet();
        dsNextStep.addColumn(SELECTED_SAMPLEID, DataSet.STRING);
        dsNextStep.addColumn(CONSTANT_STEPNAME, DataSet.STRING);

        if (dsSql.size() > 0)
            dsSql.sort(SAMPLE_SDC_COL_SAMPLEID); // Sorting the dataset sample wise
        ArrayList<DataSet> dsFinalArr = dsSql.getGroupedDataSets(SAMPLE_SDC_COL_SAMPLEID);

        if (dsFinalArr != null && dsFinalArr.size() > 0) {
            for (DataSet tempDs : dsFinalArr) { // Dataset sampleid wise
                if (tempDs != null && tempDs.size() > 0) {
                    tempDs.sort(CONSTANT_STEPNO);// Sorting the dataset step no wise
                    // Taking 0th Row to take the immediate next pending step
                    int rowId = dsComplete.addRow();
                    dsComplete.setValue(rowId, DSCOMPLETE_COL1_SAMPLEPANELSTPMAPID, tempDs.getValue(0, TABLE_COL_SAMPLEPANELSTPMAPID));
                    dsComplete.setValue(rowId, DSCOMPLETE_COL2_STATUS, CONSTANT_COMPLETED);
                    // 1st Row is to take the next routing step to which the sample will move forward
                    int rowIdnext = dsNextStep.addRow();
                    dsNextStep.setValue(rowIdnext, SELECTED_SAMPLEID, tempDs.getValue(1, SAMPLE_SDC_COL_SAMPLEID));
                    dsNextStep.setValue(rowIdnext, CONSTANT_STEPNAME, tempDs.getValue(1, CONSTANT_STEPNAME));
                }
            }
        }
        // dsComplete DataSet contains step Details of the sample from SamplePanelStpMap which needs tobe completed
        if (dsComplete.size() > 0)

        {
            PropertyList updateProp = new PropertyList();
            updateProp.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_SAMPLEPANELSTPMAP);
            updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsComplete.getColumnValues(DSCOMPLETE_COL1_SAMPLEPANELSTPMAPID, ";"));
            updateProp.setProperty(DSCOMPLETE_COL2_STATUS, dsComplete.getColumnValues(DSCOMPLETE_COL2_STATUS, ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);
        }
        // dsNextStep DataSet contains step Details of the sample where needs to be routed
        if (dsNextStep.size() > 0) {
            processNextStep(dsNextStep);
        }
    }


    /**
     * This method updates currentmovement steps for the selected samples in Sample SDC
     * and also updates custodialuserid,custodialdepartmentid according to sample Movement step details master data in Trackitem.
     *
     * @param dsNextStep
     * @throws SapphireException
     */

    private void processNextStep(DataSet dsNextStep) throws SapphireException {

        // dsNextStep DataSet contains step Details of the sample where needs to be routed
        if (!Util.isNull(dsNextStep.getColumnValues(SELECTED_SAMPLEID, ";"))) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_SAMPLE);
            pl.setProperty(EditSDI.PROPERTY_KEYID1, dsNextStep.getColumnValues(SELECTED_SAMPLEID, ";"));
            pl.setProperty(CONSTANT_CURRENTMOVEMENTSTEP, dsNextStep.getColumnValues(CONSTANT_STEPNAME, ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } else
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: No further Routing step is defined for the selected sample(s).");


        String stepNames = dsNextStep.getColumnValues(CONSTANT_STEPNAME, ";");
        // Below SQL is to Fetch Pending Routing Department Details of Step Name from u_samplestepmovmntmap table
        String sql = Util.parseMessage(MultiomyxSql.GET_DEPT__DETAILS_BY_STEPNAME, StringUtil.replaceAll(stepNames, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        // Checking whether sql is returning Null value/Empty or not
        if (dsSql == null || dsSql.isEmpty())
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: No Routing Department Details defined for the Step Name in samplestepmovmntmap.");

        if (dsSql.size() > 0) {
            dsNextStep.addColumn(DSNEXTSTEP_COL_CURMVSTP, DataSet.STRING);
            dsNextStep.addColumn(DSNEXTSTEP_COL_WORKINGDEPT, DataSet.STRING);
            dsNextStep.addColumn(DSNEXTSTEP_COL_WORKINGTRAMSTOP, DataSet.STRING);
            dsNextStep.addColumn(CONSTANT_CUSTODIALUSERID, DataSet.STRING);

            if (dsNextStep.size() > 0) {
                for (int i = 0; i < dsNextStep.size(); i++) {
                    String stpName = dsNextStep.getValue(i, CONSTANT_STEPNAME);
                    HashMap<String, String> hm = new HashMap();
                    hm.put(CONSTANT_STEPNAME, stpName);

                    DataSet dsFilter = dsSql.getFilteredDataSet(hm); // Filtering Details according to Step Name

                    //The below fraction of code decides the routing currentmovementstep,workingdepartment,custodialuserid,workingtramstop for selected samples
                    if (dsFilter.size() > 0) {
                        dsNextStep.setValue(i, DSNEXTSTEP_COL_CURMVSTP, dsFilter.getValue(0, DSNEXTSTEP_COL_CURMVSTP));

                        if(!"(system)".equalsIgnoreCase(connectionInfo.getSysuserId()) ) {

                            String workingDepartment = dsFilter.getValue(0, DSNEXTSTEP_COL_WORKINGDEPT);
                            if (!dsFilter.getValue(0, DSNEXTSTEP_COL_WORKINGDEPT).contains("-"))
                                workingDepartment = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0] + "-" + dsFilter.getValue(0, DSNEXTSTEP_COL_WORKINGDEPT);

                            dsNextStep.setValue(i, DSNEXTSTEP_COL_WORKINGDEPT, workingDepartment);
                            dsNextStep.setValue(i, CONSTANT_CUSTODIALUSERID, (connectionInfo.getDefaultDepartment().equalsIgnoreCase(workingDepartment)) ? (connectionInfo.getSysuserId()) : (""));
                        }

                        dsNextStep.setValue(i, DSNEXTSTEP_COL_WORKINGTRAMSTOP, dsFilter.getValue(0, DSNEXTSTEP_COL_WORKINGTRAMSTOP));

                    }
                }
            }


        }
        // updates details in Trackitem for selected samples
        if (dsNextStep.size() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, SDC_NAME_SAMPLE);
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, dsNextStep.getColumnValues(SELECTED_SAMPLEID, ";"));
            if(!"(system)".equalsIgnoreCase(connectionInfo.getSysuserId()) ) {
                pl.setProperty(CONSTANT_CUSTODIALUSERID, dsNextStep.getColumnValues(CONSTANT_CUSTODIALUSERID, ";"));
                pl.setProperty(CONSTANT_CUSTODIALDEPTID, dsNextStep.getColumnValues(DSNEXTSTEP_COL_WORKINGDEPT, ";"));
            }
            pl.setProperty(CONSTANT_CURRTRAMSTOP, dsNextStep.getColumnValues(DSNEXTSTEP_COL_CURMVSTP, ";"));

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }


    }


    //*****************************Logic for Analytics Lab*************************


    /**
     * The setNextStepForAL method creates two DataSet
     * Among them one contains the step details which needs tobe completed
     * And another contains the details where needs tobe Routed
     *
     * @param moimgId
     * @throws SapphireException
     */

    private void setNextStepForAL(String moimgId) throws SapphireException {

        // Below SQL is to Fetch Pending Routing Step Details of Imageid from MOImagePanelStpMap SDC
        String sql = Util.parseMessage(MultiomyxSql.GET_STEPS_BY_IMAGEID, StringUtil.replaceAll(moimgId, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        // Checking whether sql is returning Null value/Empty or not
        if (dsSql == null || dsSql.isEmpty())
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: Unable to fetch Image-Panel Step Details.");

        DataSet dsComplete = new DataSet();
        dsComplete.addColumn(DSCOMPLETE_COL1_IMAGEPANELSTPMAPID, DataSet.STRING);
        dsComplete.addColumn(DSCOMPLETE_COL2_STATUS, DataSet.STRING);

        DataSet dsNextStep = new DataSet();
        dsNextStep.addColumn(SELECTED_IMAGEID, DataSet.STRING);
        dsNextStep.addColumn(CONSTANT_STEPNAME, DataSet.STRING);

        if (dsSql.size() > 0)
            dsSql.sort("moimageid"); // Sorting the dataset image wise
        ArrayList<DataSet> dsFinalArr = dsSql.getGroupedDataSets("moimageid");

        if (dsFinalArr != null && dsFinalArr.size() > 0) {
            for (DataSet tempDs : dsFinalArr) { // Dataset imageid wise
                if (tempDs != null && tempDs.size() > 0) {
                    tempDs.sort(CONSTANT_STEPNO);// Sorting the dataset step no wise
                    // Taking 0th Row to take the immediate next pending step
                    int rowId = dsComplete.addRow();
                    dsComplete.setValue(rowId, DSCOMPLETE_COL1_IMAGEPANELSTPMAPID, tempDs.getValue(0, "u_moimagepanelstpmapid"));
                    dsComplete.setValue(rowId, DSCOMPLETE_COL2_STATUS, CONSTANT_COMPLETED);
                    // 1st Row is to take the next routing step to which the sample will move forward
                    int rowIdnext = dsNextStep.addRow();
                    dsNextStep.setValue(rowIdnext, SELECTED_IMAGEID, tempDs.getValue(1, "moimageid"));
                    dsNextStep.setValue(rowIdnext, CONSTANT_STEPNAME, tempDs.getValue(1, CONSTANT_STEPNAME));
                }
            }
        }
        // dsComplete DataSet contains step Details of the sample from IMAGEPANELSTPMAPID which needs tobe completed
        if (dsComplete.size() > 0)

        {
            PropertyList updateProp = new PropertyList();
            updateProp.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_MOIMAGEPANELSTPMAP);
            updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsComplete.getColumnValues(DSCOMPLETE_COL1_IMAGEPANELSTPMAPID, ";"));
            updateProp.setProperty(DSCOMPLETE_COL2_STATUS, dsComplete.getColumnValues(DSCOMPLETE_COL2_STATUS, ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);
        }
        // dsNextStep DataSet contains step Details of the sample where needs to be routed
        if (dsNextStep.size() > 0) {
            processNextStepForAL(dsNextStep);
        }
    }


    /**
     * This method updates currentmovement steps for the selected images in MOImage SDC
     *
     * @param dsNextStep
     * @throws SapphireException
     */

    private void processNextStepForAL(DataSet dsNextStep) throws SapphireException {

        String stepNames = dsNextStep.getColumnValues(CONSTANT_STEPNAME, ";");
        // Below SQL is to Fetch Pending Routing Department Details of Step Name from u_samplestepmovmntmap table
        String sql = Util.parseMessage(MultiomyxSql.GET_DEPT__DETAILS_BY_STEPNAME, StringUtil.replaceAll(stepNames, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        // Checking whether sql is returning Null value/Empty or not
        if (dsSql == null || dsSql.isEmpty())
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: No Routing Department Details defined for the Step Name in samplestepmovmntmap.");

        if (dsSql.size() > 0) {
            dsNextStep.addColumn(DSNEXTSTEP_COL_CURMVSTP, DataSet.STRING);

            if (dsNextStep.size() > 0) {
                for (int i = 0; i < dsNextStep.size(); i++) {
                    String stpName = dsNextStep.getValue(i, CONSTANT_STEPNAME);
                    HashMap<String, String> hm = new HashMap();
                    hm.put(CONSTANT_STEPNAME, stpName);

                    DataSet dsFilter = dsSql.getFilteredDataSet(hm); // Filtering Details according to Step Name

                    //The below fraction of code decides the routing currentmovementstep for selected images
                    if (dsFilter.size() > 0) {
                        dsNextStep.setValue(i, DSNEXTSTEP_COL_CURMVSTP, dsFilter.getValue(0, DSNEXTSTEP_COL_CURMVSTP));
                    }
                }
            }


        }
        // dsNextStep DataSet contains step Details of the images where needs to be routed
        if (!Util.isNull(dsNextStep.getColumnValues(SELECTED_IMAGEID, ";"))) {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_MOIMAGE);
            pl.setProperty(EditSDI.PROPERTY_KEYID1, dsNextStep.getColumnValues(SELECTED_IMAGEID, ";"));
            pl.setProperty(DSNEXTSTEP_COL_CURMVSTP, dsNextStep.getColumnValues(DSNEXTSTEP_COL_CURMVSTP, ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } else
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, "Error: No further Routing step is defined for the selected image(s).");

    }
}




