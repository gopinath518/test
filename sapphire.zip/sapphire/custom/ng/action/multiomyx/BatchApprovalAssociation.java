package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.AddSDIApproval;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by rrmandal on 10/5/2017.
 */
public class BatchApprovalAssociation extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchid=properties.getProperty("batchid","");
        if(Util.isNull(batchid))
            throw new SapphireException("Batach id cannot be obtained");
        addApprovalSteps(batchid);
    }

    private void addApprovalSteps(String batchid) throws SapphireException{
        if(!Util.isNull(batchid)){
            String sql = Util.parseMessage(MultiomyxSql.BATCH_APPROVAL_CONDITION_BY_BATCHID, StringUtil.replaceAll(batchid,";","','"));
            DataSet dsBatchDetail = getQueryProcessor().getSqlDataSet(sql);

            if(dsBatchDetail == null){
                throw new SapphireException("Multiomyx Batch Approval Information can not be obtained from database.");
            }

            if(dsBatchDetail.size() > 0){
                batchid = "";

                for(int i=0; i<dsBatchDetail.size(); i++){
                    int moimgcont= dsBatchDetail.getInt(i, "moimagecount",-1);
                    int stmidcnt= dsBatchDetail.getInt(i, "stmcount",-1);
                    int approvalcnt= dsBatchDetail.getInt(i, "approvalcnt",0);

                    if(approvalcnt==0 && moimgcont == stmidcnt){
                        batchid += ";"+dsBatchDetail.getValue(i, "u_mobatchid","");
                    }
                }

                if(!Util.isNull(batchid) ) {

                    if(batchid.startsWith(";")){
                       batchid = batchid.substring(1);
                    }

                    batchid = Util.getUniqueList(batchid, ";", true);
                    String batchidArr[] = StringUtil.split(batchid, ";");
                    if (batchidArr != null && batchidArr.length > 0) {
                        PropertyList pl = new PropertyList();
                        for (int i = 0; i < batchidArr.length; i++) {
                            if (!Util.isNull(batchidArr[i])) {
                                pl.clear();
                                pl.setProperty(AddSDIApproval.PROPERTY_SDCID, "MOBatch");
                                pl.setProperty(AddSDIApproval.PROPERTY_KEYID1, batchidArr[i]);
                                pl.setProperty(AddSDIApproval.PROPERTY_APPROVALTYPEID, "MoBatchReview");
                                pl.setProperty(AddSDIApproval.PROPERTY_APPROVALFUNCTION, "Acceptance");
                                pl.setProperty(AddSDIApproval.PROPERTY_ADDSTEPS, "Y");
                                pl.setProperty(AddSDIApproval.PROPERTY_READY, "Y");
                                getActionProcessor().processAction(AddSDIApproval.ID, AddSDIApproval.VERSIONID, pl);
                            }
                        }
                    }
                }

            }

        }
    }
}
