/**
 * 
 */
package sapphire.custom.ng.action.multiomyx;

import java.util.HashMap;
import java.util.Map;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/*********************************************
 * This action checks the number of testcode(s) 
 * and number of reagent type(s) associated with 
 * testcode(s) in a Multiomyx panel and based on 
 * these parameters Multiomyx QC panel is passed
 * 
 * @author sudeepta.pal
 *********************************************/
public class MOPanelQCPassAction extends BaseAction implements MOConstants {
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		if(properties == null){
			throw new SapphireException(ERROR_TYPE,ErrorDetail.TYPE_INFORMATION,
					"\nThere is no property defined for the action :: "+this.getClass().getSimpleName());
		}else{
			String panelId = properties.getProperty("panelId");
			
			String testcodeSql = Util.parseMessage(MultiomyxSql.TESTCODE_ADDED_BY_LABUSER_BY_PANEL, panelId);
			DataSet testcodeDS = getQueryProcessor().getSqlDataSet(testcodeSql);
			if(testcodeDS == null){
				throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_FAILURE,
						"\nProblem occured while executing following query :: \n"+testcodeSql);
			}
			if(testcodeDS.getRowCount() == 0){
				throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_VALIDATION,
						"\nThere is no testcode given by the lab user for Multiomyx panel :: "+panelId);
			}
			
			String uniqueTestCodes = Util.getUniqueList(testcodeDS.getColumnValues("testcodeid", ";"), ";", true);
			String[] uniqueTestCodeArr = StringUtil.split(uniqueTestCodes, ";");
			if(testcodeDS.getRowCount() > uniqueTestCodeArr.length){
				throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_VALIDATION,
						"\nDuplicate testcode(s) can't be added by lab user for Multiomyx panel :: "+panelId);
			}
			
			String reagentSql = Util.parseMessage(MultiomyxSql.REAGENT_BY_TESTCODE, panelId);
			DataSet reagentDS = getQueryProcessor().getSqlDataSet(reagentSql);
			if(reagentDS == null){
				throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_FAILURE,
						"\nProblem occured while executing following query :: \n"+reagentSql);
			}
			if(reagentDS.getRowCount() == 0){
				throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_VALIDATION,
						"\nThere is no reagent type information given by lab user for Multiomyx panel :: "+panelId);
			}
			
			String uniqueRegTestCodes = Util.getUniqueList(reagentDS.getColumnValues("regtestcodeid", ";"), ";", true);
			String[] uniqueRegTestCodeArr = StringUtil.split(uniqueRegTestCodes, ";");
			Map<String, String> map = new HashMap<>();
			if(reagentDS.getRowCount() > uniqueRegTestCodeArr.length){
				for(String uniqueRegTestCode : uniqueRegTestCodeArr){
					HashMap<String, Object> hm = new HashMap<>();
					hm.put("regtestcodeid", uniqueRegTestCode);
					DataSet filteredDS = reagentDS.getFilteredDataSet(hm);
					if(filteredDS != null && filteredDS.getRowCount() > 1){
						map.put(filteredDS.getValue(0, "regtestcodeid"), filteredDS.getValue(0, "reagenttypeid"));
					}
				}
				if (map.size() > 0) {
	                String failureMsg = "Below Testcode and Reagent Type combination exists already :: \n\n" +
	                        "<table border=1>" +
	                        "<tr border=1><th>Testcode</th><th>Reagent Type</th></tr>";
	                for (Map.Entry<String, String> entry : map.entrySet()) {
	                    failureMsg += "<tr border=1><td>" + entry.getKey() + "</td><td>" + entry.getValue() + "</td></tr>";
	                }
	                failureMsg += "</table>";
	                throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_VALIDATION, failureMsg);
	            }
			}
			
			String testCodeData = testcodeDS.getColumnValues("testcodeid", ";");
			String[] testCodeArr = StringUtil.split(testCodeData, ";");
			HashMap<String, Object> hm = new  HashMap<>();
			String reagentLessTestcode = EMPTY_STRING;
			for(String testcode : testCodeArr){
				hm.clear();
				hm.put("regtestcodeid", testcode);
				DataSet filteredDS = reagentDS.getFilteredDataSet(hm);
				if(filteredDS.getRowCount() == 0){
					reagentLessTestcode = reagentLessTestcode+","+testcode;
				}
			}
			if(!Util.isNull(reagentLessTestcode)){
				reagentLessTestcode = reagentLessTestcode.substring(1);
				if(!Util.isNull(reagentLessTestcode)){
					String testCodeDescSql = Util.parseMessage(MultiomyxSql.TESTCODEDESC_BY_TESTCODE, StringUtil.replaceAll(reagentLessTestcode,",","','"));
					DataSet tcDescDS = getQueryProcessor().getSqlDataSet(testCodeDescSql);
					if(tcDescDS == null){
						throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_FAILURE,
								"\nProblem occured while executing following query :: \n"+testCodeDescSql);
					}
					if(tcDescDS.getRowCount() > 0){
						throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_VALIDATION, 
								"\nLab user has not provided reagent type information for the below test(s) :: \n"
								+tcDescDS.getColumnValues("testcodedesc", ","));
					}
				}
			}
			
			PropertyList pl = new PropertyList();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "testcode");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, panelId);
            pl.setProperty("moqcpass", "Y");
            pl.setProperty("panelvalidation", "(null)");
            pl.setProperty("isdummy", "(null)");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		}
	}
}
