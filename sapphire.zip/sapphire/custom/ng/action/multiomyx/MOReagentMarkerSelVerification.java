/**
 *
 */
package sapphire.custom.ng.action.multiomyx;

import com.labvantage.opal.validation.misc.ConvertUnits;
import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sudeepta.pal
 */
public class MOReagentMarkerSelVerification extends BaseAction implements MOConstants {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        // TODO Auto-generated method stub
        String moRegMarkerSelId = properties.getProperty("moregmarkerselid", "");
        String approvedBy = properties.getProperty("approvedby", "");
        String approvedDt = properties.getProperty("approveddt", "");
        String regLotId = properties.getProperty("reglotid", "");
        String origConcentration = properties.getProperty("origconcentration", "");
        String workConcentration = properties.getProperty("workconcentration", "");
        String origConUnit = properties.getProperty("origconunit", "");
        String workConUnit = properties.getProperty("workconunit", "");
        String approvalStatus = properties.getProperty("approvalstatus", "");
        String ops = properties.getProperty("operation", "");
        String sampleId = properties.getProperty("sampleid", "");
        String approvalComments = properties.getProperty("approvalcomments", "");
        String flag = properties.getProperty("flag", "");

        if (DOWNSELECTION.equalsIgnoreCase(ops) || PHASEIN.equalsIgnoreCase(ops)
                || ANTIGEN_EFFECTS.equalsIgnoreCase(ops)) {
            String query = Util.parseMessage(MultiomyxSql.GET_REG_LOT_ASSOCIATION_WITH_CTRL_SAMPLEID, sampleId);
            DataSet ds = getQueryProcessor().getSqlDataSet(query);
            if (ds != null && ds.getRowCount() == 1 &&
                    "AB".equalsIgnoreCase(ds.getColumnValues("u_molottype", ";"))) {
                throw new SapphireException(ERROR_TYPE, ErrorDetail.TYPE_VALIDATION,
                        "\nFor " + ops + ", lab user should associate also either secondary "
                                + "or isotype reagent lot with primary reagent lot on the control sample :- " + sampleId);
            }
        }

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "MORegMarkerSelAudit");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, moRegMarkerSelId);
        pl.setProperty("approvedby", approvedBy);
        pl.setProperty("approveddt", approvedDt);
        pl.setProperty("approvalstatus", approvalStatus);
        pl.setProperty("approvalcomments", approvalComments);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSION, pl);

        if (APPROVAL_PASS.equalsIgnoreCase(approvalStatus) && !Util.isNull(ops)
                && !BLEACH_SUFFICIENCY.equalsIgnoreCase(ops) && !ANTIGEN_EFFECTS.equalsIgnoreCase(ops)) {
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "LV_ReagentLot");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, regLotId);
            //pl.setProperty("u_stockconc", origConcentration);
            pl.setProperty("u_workconc", workConcentration);
            //pl.setProperty("u_origconunit", origConUnit);
            pl.setProperty("u_workconunit", workConUnit);
            if (DOWNSELECTION.equalsIgnoreCase(ops)) {
                pl.setProperty("u_downselapproved", "Y");
            } else if (INITIALDC.equalsIgnoreCase(ops)) {
                pl.setProperty("u_initdcapproved", "Y");
            } else if (PHASEIN.equalsIgnoreCase(ops)) {
                pl.setProperty("u_phaseinapproved", "Y");
            }
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSION, pl);
        }
        if(Util.isNull(flag))
            calculateReagentVolumeAfterUsage(sampleId);

    }

    private void calculateReagentVolumeAfterUsage(String sampleId) throws SapphireException {
        if (Util.isNull(sampleId)) {
            throw new SapphireException("Sampleid could not be blank");
        }
            String sampleIds = StringUtil.replaceAll(sampleId, ";", "','");
            DataSet dsFinal = new DataSet();
            dsFinal.addColumn("reglotid", DataSet.STRING);
            dsFinal.addColumn("rgtamtusedinslide", DataSet.STRING);
            dsFinal.addColumn("rgtamtunitusedinslide", DataSet.STRING);
            dsFinal.addColumn("qtycurrent", DataSet.STRING);
            dsFinal.addColumn("qtyunits", DataSet.STRING);
            DataSet dsUpdatedAmt = new DataSet();
            dsUpdatedAmt.addColumn("reglotid", DataSet.STRING);
            dsUpdatedAmt.addColumn("qtycurrent", DataSet.STRING);
            DataSet dsError = new DataSet();
            dsError.addColumn("reglotid", DataSet.STRING);
            dsError.addColumn("reqqty", DataSet.STRING);
            dsError.addColumn("availableqty", DataSet.STRING);


            String rgtQry = Util.parseMessage(MultiomyxSql.RGTLOTID_BY_CNTRLSAMPLEID, sampleIds);
            DataSet rgtDetails = getQueryProcessor().getSqlDataSet(rgtQry);
            if (rgtDetails != null && rgtDetails.getRowCount() > 0) {
                ArrayList<DataSet> dsrgtDtlArr = rgtDetails.getGroupedDataSets("reglotid");
                if (dsrgtDtlArr != null && dsrgtDtlArr.size() > 0) {
                    for (DataSet dstemp : dsrgtDtlArr) {
                        double totalAmt = 0.0d;
                        for (int i = 0; i < dstemp.size(); i++) {
                            Double rgtUsedamt = dstemp.getDouble(i, "rgtamtusedinslide");
                            totalAmt += rgtUsedamt;

                        }
                        int rowId = dsFinal.addRow();
                        dsFinal.setValue(rowId, "reglotid", dstemp.getValue(0, "reglotid", null));
                        dsFinal.setValue(rowId, "rgtamtusedinslide", String.valueOf(totalAmt));
                        dsFinal.setValue(rowId, "rgtamtunitusedinslide", dstemp.getValue(0, "rgtamtunitusedinslide", null));
                        dsFinal.setValue(rowId, "qtycurrent", dstemp.getValue(0, "qtycurrent", null));
                        dsFinal.setValue(rowId, "qtyunits", dstemp.getValue(0, "qtyunits", null));

                    }
                    if (dsFinal != null & dsFinal.size() > 0) {
                        for (int i = 0; i < dsFinal.size(); i++) {
                            String existingQty = dsFinal.getValue(i, "qtycurrent", "");
                            double existingAmt =Double.parseDouble(existingQty);
                            String existingUnit = dsFinal.getValue(i, "qtyunits", "");
                            String usedAmt = dsFinal.getValue(i, "rgtamtusedinslide", "");
                            String usedUnit = dsFinal.getValue(i, "rgtamtunitusedinslide", "");
                            String qtyStr = "";
                            if (!Util.isNull(usedUnit) && !usedUnit.equalsIgnoreCase(existingUnit) && !Util.isNull(existingUnit) ) {
                                qtyStr = ConvertUnits.convertUnits(getQueryProcessor(), usedUnit, existingUnit, usedAmt);
                            } else {
                                qtyStr = usedAmt;
                            }
                            double useAmt = Double.parseDouble(qtyStr);
                            double newAmt = existingAmt - useAmt;
                            if (newAmt < 0) {
                                int rowID = dsError.addRow();
                                dsError.setValue(rowID, "reglotid", dsFinal.getValue(i, "reglotid", ""));
                                dsError.setValue(rowID, "reqqty", usedAmt);
                                dsError.setValue(rowID, "availableqty", String.valueOf(existingAmt));


                            } else {
                                int rowId = dsUpdatedAmt.addRow();
                                dsUpdatedAmt.setValue(rowId, "reglotid", dsFinal.getValue(i, "reglotid", ""));
                                dsUpdatedAmt.setValue(rowId, "qtycurrent", String.valueOf(newAmt));
                            }


                        }
                        if (dsError != null && dsError.size() > 0) {
                            String failureMsg = "The available amount of the below mentioned reagent lot is not sufficient for use \n" +
                                    "<table border=1>" +
                                    "<tr border=1><th>Reagent Lot</th><th>Required Qty</th><th>Available Qty</th></tr>";
                            for (int i=0;i<dsError.size();i++){

                                failureMsg += "<tr border=1><td>" + dsError.getValue(i,"reglotid") + "</td><td>" + dsError.getValue(i,"reqqty")+ "</td><td>" +dsError.getValue(i,"availableqty")+"</td></tr>";
                            }
                            failureMsg += "</table>";
                            throw new SapphireException(failureMsg);

                        }
                        if(dsUpdatedAmt !=null && dsUpdatedAmt.size()>0){
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, dsUpdatedAmt.getColumnValues("reglotid",";"));
                            pl.setProperty("qtycurrent", dsUpdatedAmt.getColumnValues("qtycurrent",";"));
                            try {
                                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                            }catch (ActionException ae) {
                                throw new SapphireException("Error: Unable to Update Trackitem. Reason: " + ae.getMessage());
                            }
                        }
                    }


                }


            }



    }
}
