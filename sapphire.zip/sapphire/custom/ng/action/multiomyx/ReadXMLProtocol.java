package sapphire.custom.ng.action.multiomyx;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

/**
 * Created by DMondal on 8/21/2017.
 * Description : This action is parsing an XML, finding protocols,id and name and making a data set.
 */
public class ReadXMLProtocol extends BaseAction {
    /**
     * Description:Taking sample(s) and path of XMl and creating required DataSet
     * @param properties
     * @throws SapphireException
     */
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String uploadedfiles = properties.getProperty("path");
        try {
            File inputFile = new File(uploadedfiles);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("Protocol");
            DataSet dsProtocol=new DataSet();
            dsProtocol.addColumn("Id",DataSet.STRING);
            dsProtocol.addColumn("Type",DataSet.STRING);
            dsProtocol.addColumn("Name",DataSet.STRING);
            int incr=0;
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String id=eElement.getElementsByTagName("Id").item(0).getTextContent();
                    String type=eElement.getElementsByTagName("Type").item(0).getTextContent();
                    String name=eElement.getElementsByTagName("Name").item(0).getTextContent();
                    incr= dsProtocol.addRow();
                    dsProtocol.setValue(incr,"Id",id);
                    dsProtocol.setValue(incr,"Type",type);
                    dsProtocol.setValue(incr,"Name",name);
                }
            }
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Error in XML.");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
