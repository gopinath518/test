package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.DeleteSDIWorkItem;

import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class MOPanelDeletion extends BaseAction {
    /****************************************************
     * This method is for delete dummy Panel from Sample
     *
     * @param properties
     * @throws SapphireException
     ***************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("sampleid");
        String panelId = properties.getProperty("panelid");

        if (Util.isNull(sampleId))
            throw new SapphireException("Sampleid couldn't be blank.");
        if (Util.isNull(panelId))
            throw new SapphireException("Panelid couldn't be blank.");

        DataSet dsMap = new DataSet();
        dsMap.addColumn("sampleid#panelid", DataSet.STRING);
        String[] sampleArr = StringUtil.split(sampleId, ";");
        String[] panelArr = StringUtil.split(panelId, ";");
        for (String sample : sampleArr) {
            for (String panel : panelArr) {
                int rowId = dsMap.addRow();
                dsMap.setValue(rowId, "sampleid#panelid", sample + "#" + panel);
            }
        }
        String samplePanelCombo = dsMap.getColumnValues("sampleid#panelid", "','");

        PropertyList pl = new PropertyList();
        DataSet dsSampleTestCDMap = getSampleTestcodeMapData(samplePanelCombo);
        if (dsSampleTestCDMap != null && dsSampleTestCDMap.size() > 0) {
            pl.clear();
            pl.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            pl.setProperty(DeleteSDI.PROPERTY_KEYID1, dsSampleTestCDMap.getColumnValues("u_sampletestcodemapid", ";"));
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete sampleTestCodeMap Data.");
            }

        }
        DataSet dsSdiWorkitemData = getSdiWorkitemData(sampleId);
        if (dsSdiWorkitemData != null && dsSdiWorkitemData.size() > 0) {
            pl.clear();
            pl.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1, dsSdiWorkitemData.getColumnValues("keyid1", ";"));
            pl.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID, dsSdiWorkitemData.getColumnValues("workitemid", ";"));
            pl.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE, dsSdiWorkitemData.getColumnValues("workiteminstance", ";"));
            pl.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES, "Y");
            pl.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s).");
            }
        }
        DataSet dsSamplestpMap = getSamplePanelStpMapData(samplePanelCombo);
        if (dsSamplestpMap != null && dsSamplestpMap.size() > 0) {
            pl.clear();
            pl.setProperty(DeleteSDI.PROPERTY_SDCID, "SamplePanelStpMap");
            pl.setProperty(DeleteSDI.PROPERTY_KEYID1, dsSamplestpMap.getColumnValues("u_samplepanelstpmapid", ";"));
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete samplepanelStpMap Data.");
            }

        }


    }


    private DataSet getSampleTestcodeMapData(String samplePanelCombo) throws SapphireException {
        DataSet dsSampleTestCDMap = new DataSet();
        if (!Util.isNull(samplePanelCombo)) {
            String sampletestcodemapSql = Util.parseMessage(MultiomyxSql.GET_SAMPLETESTCODEMAPID_BY_SAMPLE_PANEL,samplePanelCombo );
            dsSampleTestCDMap = getQueryProcessor().getSqlDataSet(sampletestcodemapSql);

        }
        return dsSampleTestCDMap;
    }

    private DataSet getSdiWorkitemData(String sampleId) throws SapphireException {
        DataSet dsSdiWorkitemData = new DataSet();
        if (!Util.isNull(sampleId)) {
            String sdiworkitemdataSql = Util.parseMessage(MultiomyxSql.GET_SDIWORKITEMDATA_BY_SAMPLE, StringUtil.replaceAll(sampleId, "%3B", "','"));
            dsSdiWorkitemData = getQueryProcessor().getSqlDataSet(sdiworkitemdataSql);

        }
        return dsSdiWorkitemData;
    }

    private DataSet getSamplePanelStpMapData(String samplePanelCombo) throws SapphireException {
        DataSet dsSamplePanelStpMap = new DataSet();
        if (!Util.isNull(samplePanelCombo)) {
            String samplePanelStpMapSql = Util.parseMessage(MultiomyxSql.GET_SAMPLEPANELSTPMAP_BY_SAMPLE_PANEL,samplePanelCombo );
            dsSamplePanelStpMap = getQueryProcessor().getSqlDataSet(samplePanelStpMapSql);

        }
        return dsSamplePanelStpMap;

    }

}

