package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;


public class MOSdfMainOutputComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid", "");
        String moImgId = properties.getProperty("keyid1", "");
        String status = properties.getProperty("status", "");

        if (Util.isNull(moImgId))
            throw new SapphireException("Please select atleast one.");
        if (Util.isNull(status))
            throw new SapphireException("Status not found.");

        try {
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, moImgId);
            pl.setProperty("status", status);

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

        } catch (SapphireException se) {
            throw new SapphireException("Unable to upadate Image Status. Reason : " + se.getMessage());
        }

        try {
            if (!Util.isNull(sampleid)) {
                sampleid = Util.getUniqueList(sampleid,";",true);

                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                pl.setProperty("u_reportingdts", "n");

                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            } else {
                logger.info("No Sample id not found. ");
            }

        } catch (SapphireException se) {
            logger.info("Unable to update reporting date. Reason : " + se.getMessage());
        }
    }
}
