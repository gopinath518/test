package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class MOWorkFlowComplete extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid=properties.getProperty("sampleid","");
        if(Util.isNull(sampleid))
            throw new SapphireException("Please select atleast one sampleid");

        PropertyList pl=new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1,sampleid);
        pl.setProperty("u_currentmovementstep","MOCompletedSlide");
        pl.setProperty("u_mocomplete","Y");

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);

        String sql = Util.parseMessage(MultiomyxSql.GET_MOVEANALYTICS_DETAILS, StringUtil.replaceAll(sampleid,";","','") );
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);

        if(dsSql != null && dsSql.size() > 0){
            HashMap hm = new HashMap();
            hm.put("movetoanalytics","N");

            DataSet dsFilter = dsSql.getFilteredDataSet(hm);

            if(dsFilter.size() > 0){
                String keyid1 = dsFilter.getColumnValues("s_sampleid",";");
                pl.clear();

                if(!Util.isNull(keyid1)){
                    pl.setProperty(EditSDI.PROPERTY_SDCID,"Sample");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1,keyid1);
                    pl.setProperty("u_reportingdts", "n");

                    try{
                        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,pl);
                    } catch(SapphireException se){
                        logger.info("Unable to update reporting date. Reason : " + se.getMessage());
                    }
                }

            }
        }

        pl.clear();
        pl.setProperty("operationName","updateSlideStatus");
        pl.setProperty("slideid",sampleid);

        getActionProcessor().processAction("MOLWSAction", "1", pl);
    }
}
