package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by ssen on 9/1/2017.
 */
public class MOBleachStainSlide extends BaseAction implements MOConstants {
    public void processAction(PropertyList properties) throws SapphireException {
        try {
            String sampleid = properties.getProperty("sampleid");
            String previousStatus = properties.getProperty("previousstatus");
            String currentStatus = properties.getProperty("currentstatus");
            String pendingTest = properties.getProperty("pendingtest");

            // only for qc button****
            String qcstatus = properties.getProperty("qcstatus");
            String qcflag = properties.getProperty("qcflag", "");
            //**********
            if (Util.isNull(sampleid))
                //throw new SapphireException("Select atleast one sample");
                return;
            DataSet dsalldata = getFilteredData(sampleid, previousStatus);
            if (dsalldata == null || dsalldata.size() == 0) {
                throw new SapphireException("Invalid steps");
            }
            checkAllData(dsalldata, sampleid);
            // qcflag is null when called from other button of MO Bleach tramstop
            // and qcflag will be y , when called from QC button.
            // When called from QC button , the update action will be taken care by MOSlideQC Action.
            if (Util.isNull(qcflag)) {
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                props.setProperty("u_moreceivecomment", currentStatus);
                props.setProperty("u_mostatus", currentStatus);
                props.setProperty("auditreason", currentStatus);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to Edit Data into Sample. Reason: " + ae.getMessage());
                }
                try {
                    props.clear();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsalldata.getColumnValues("u_sampletestcodemapid", ";"));
                    props.setProperty("teststatus", currentStatus);
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to Edit Data into SampleTestCodeMap. Reason: " + ae.getMessage());
                }
            }

            if ("pass".equalsIgnoreCase(qcstatus)) {
                updateSampleMovement(pendingTest, sampleid);// added by aritra.banerjee on 06-SEPT-2017
            }
        }
        catch (Exception exp){
            if(!"Y".equalsIgnoreCase(properties.getProperty("bypasserror","")))
                throw new SapphireException(exp.getMessage());
        }

        //updateMOImage(currentStatus,dsalldata, qcstatus);
    }

    /**
     *
     * @param pendingTest
     * @param sampleid
     * @throws SapphireException
     */
    private void updateSampleMovement(String pendingTest,String sampleid) throws SapphireException{
        if(!Util.isNull(pendingTest) && !Util.isNull(sampleid) ){
            String[] pendingTestArr = StringUtil.split(pendingTest,";");
            String[] sampleidArr = StringUtil.split(sampleid,";");
            String eligibleSample= "";
            for(int i=0;i<pendingTestArr.length;i++){
                if(Integer.parseInt(pendingTestArr[i]) > 0 )
                    eligibleSample += ";"+ sampleidArr[i];
            }
            if(eligibleSample.startsWith(";"))
                eligibleSample = eligibleSample.substring(1);
            if(!Util.isNull(eligibleSample)){
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, eligibleSample);
                pl.setProperty("u_currentmovementstep", "MOStaining");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                pl.clear();
                pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID,"Sample");
                pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1,eligibleSample);
                pl.setProperty("u_currenttramstop", "MOStaining");

                getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID,pl);

                updateStepStatus(eligibleSample);
            }
        }

    }

    /**
     *
     * @param sampleid
     * @throws SapphireException
     */
    private void updateStepStatus(String sampleid) throws SapphireException{
        // need to implement
        String sql = Util.parseMessage(MultiomyxSql.GET_CMPLETED_STEPS_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
        if(dsSql == null || dsSql.isEmpty())
            throw new SapphireException("Error: Unable to fetch Panel Step Details.");
        String samplepanelstpmapid= "";
        if(dsSql.size() > 0){
            dsSql.sort("s_sampleid");
            ArrayList<DataSet> dsFinalArr = dsSql.getGroupedDataSets("s_sampleid");
            if(dsFinalArr!=null && dsFinalArr.size()>0) {
                for (int i = 0; i < dsFinalArr.size(); i++) {
                    DataSet tempDs = dsFinalArr.get(i); // s_sampleid wise
                    if (tempDs != null && tempDs.size() > 0) {
                        tempDs.sort("stepno");
                        samplepanelstpmapid += ";" + tempDs.getValue((tempDs.size() -1),"u_samplepanelstpmapid");
                    }
                }
            }
        }
        if(samplepanelstpmapid.startsWith(";"))
            samplepanelstpmapid = samplepanelstpmapid.substring(1);
        if(!Util.isNull(samplepanelstpmapid)){
            PropertyList updateProp = new PropertyList();
            updateProp.setProperty(EditSDI.PROPERTY_SDCID, "SamplePanelStpMap");
            updateProp.setProperty(EditSDI.PROPERTY_KEYID1, samplepanelstpmapid);
            updateProp.setProperty("status", "Pending");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);
        }
    }

    /**
     * This method fetching status from sampleTestCodeMap
     * @param sampleid
     * @param previousStatus
     * @return
     */

    private DataSet getFilteredData(String sampleid, String previousStatus)throws SapphireException{
        String allsampleid = StringUtil.replaceAll(sampleid, ";", "','");
        previousStatus += ";"+"MOBIQCFailed"+";"+"MOBIQCReImage";
        String allpreviousStatus = StringUtil.replaceAll(previousStatus, ";", "','");
        String sqldata = Util.parseMessage(MultiomyxSql.GET_TESTSTATUS, allsampleid,allpreviousStatus);
        DataSet dsAlldata = getQueryProcessor().getSqlDataSet(sqldata);
        return dsAlldata;
    }

    /**
     *This method comp
     * @param dsalldata
     * @param sampleid
     * @throws SapphireException
     */
    private void checkAllData(DataSet dsalldata,String sampleid) throws SapphireException{
        String errsample = "";
        String [] allsamplearr = StringUtil.split(sampleid,";");
        if(allsamplearr.length==0)
            throw new SapphireException("No sampleid found");
        HashMap hm = new HashMap();
        for (int i = 0; i < allsamplearr.length; i++) {
            hm.clear();
            hm.put("s_sampleid", allsamplearr[i]);
            if (dsalldata.getFilteredDataSet(hm).size()== 0)
                errsample += ";"+allsamplearr[i];
        }
        if(!Util.isNull(errsample)){
            errsample= errsample.substring(1);
            throw new SapphireException(errsample +":-are not completed Previous Step");
        }


    }

    private void updateMOImage(String currentStatus,DataSet dsalldata, String qcstatus)throws SapphireException {
        //if (currentStatus.equalsIgnoreCase("MOBIQCPassed")) {
        if (!Util.isNull(qcstatus)) {
            String sampletestcodeids = StringUtil.replaceAll(dsalldata.getColumnValues("u_sampletestcodemapid", ";"), ";", "','");
            String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
            String sqldata = Util.parseMessage(MultiomyxSql.GET_MOIMAGEID_BY_SAMPLETESTCODEMAPID, sampletestcodeids);
            DataSet dsMoImageId = getQueryProcessor().getSqlDataSet(sqldata);
            if (dsMoImageId != null || dsMoImageId.size()> 0) {
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
                pl.setProperty(EditSDI.PROPERTY_KEYID1, dsMoImageId.getColumnValues("u_moimageid", ";"));
                pl.setProperty("qcby", currentuser);
                pl.setProperty("qcdt", "n");
                if("pass".equalsIgnoreCase(qcstatus)) {
                    pl.setProperty("qcstatus", "QCPass");
                    pl.setProperty("qccomment", "Bleached Pass");
                }
                else if("fail".equalsIgnoreCase(qcstatus)) {
                    pl.setProperty("qcstatus", "QCFail");
                    pl.setProperty("qccomment", "Bleached Fail");
                }
                else if("reimage".equalsIgnoreCase(qcstatus)) {
                    pl.setProperty("qcstatus", "QCReImage");
                    pl.setProperty("qccomment", "Bleached Re-Image");
                }
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
            }


        }

    }
}
