package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by ssen on 10/5/2017.
 */
public class FinalLogUpload extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String moimageid = properties.getProperty("moimageid");
        String status = properties.getProperty("status");
        String sampleid = properties.getProperty("sampleid");
        if(Util.isNull(moimageid))
            throw new SapphireException("moimageid can't be found");
        if(Util.isNull(status))
            throw new SapphireException("statush can't be found");
        if(Util.isNull(sampleid))
            throw new SapphireException("sampleid can't be found");
        String envid = "MOLogPath";
        String finalsample ="";
        if(!Util.isNull(sampleid)) {
            String[] sampleidarr = sampleid.split(";");
            Set<String> mySet = new HashSet(Arrays.asList(sampleidarr));
            for (String temp : mySet) {
                finalsample += ";" + temp;
            }
            if (finalsample.startsWith(";"))
                finalsample = finalsample.substring(1);
        }

        String sqldata = Util.parseMessage(MultiomyxSql.GET_PATH_FROM_ENVPROP, envid);
        DataSet dspath = getQueryProcessor().getSqlDataSet(sqldata);

        PropertyList prop = new PropertyList();
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, moimageid);
        prop.setProperty("status",status);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. EditSdi on MOImage  " + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, finalsample);
        prop.setProperty("u_mologpath",dspath.getValue(0,"propvalue"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. EditSdi on Sample  " + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }





    }

}
