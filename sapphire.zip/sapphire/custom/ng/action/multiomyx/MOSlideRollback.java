package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class MOSlideRollback extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String protocolComb = properties.getProperty("protocolcomb");
        String sampleid = properties.getProperty("sampleid");
        String protocolStatus = properties.getProperty("protocolstatus", "Pending");
        String panelid = properties.getProperty("panelid", "Pending");
        String batchid = properties.getProperty("batchid", "Pending");

        if (Util.isNull(protocolComb) || Util.isNull(sampleid)) {
            throw new SapphireException("Protocol combination or sampleid cannot not be blank");
        }
        if (Util.isNull(panelid))
            throw new SapphireException("Panel Id cannot be obtained");
        if (Util.isNull(batchid))
            throw new SapphireException("Batch Id cannot be obtained");

        sampleid = Util.getUniqueList(sampleid, ";", true);
        panelid = Util.getUniqueList(panelid, ";", true);
        batchid = Util.getUniqueList(batchid, ";", true);

        String sampleidArr[] = StringUtil.split(sampleid, ";");
        if (sampleidArr != null && sampleidArr.length > 1)
            throw new SapphireException("More than one sampleid obtained as an input.");

        String protocolCombArr[] = StringUtil.split(protocolComb, "|");

        if (protocolCombArr != null && protocolCombArr.length == 2) {
            String protocolId = protocolCombArr[0];
            String protocolName = protocolCombArr[1];
            String queryInputProtocol = "";

            if (Util.isNull(protocolId))
                throw new SapphireException("Protocol Id cannot be obtained from the selected combination");
            if (Util.isNull(protocolName))
                throw new SapphireException("Protocol cannot be obtained from the selected combination");
            if (protocolName.contains(":")) {
                String protocolNameArr[] = StringUtil.split(protocolName, ":");
                if (protocolNameArr != null && protocolNameArr.length > 0) {
                    queryInputProtocol = protocolNameArr[0];
                    if (!Util.isNull(queryInputProtocol)) {
                        if (queryInputProtocol.contains("Antibody Staining"))
                            queryInputProtocol = "Antibody Staining";
                        else if (queryInputProtocol.contains("20x Stain Imaging"))
                            queryInputProtocol = "20x Stain Imaging";
                    }
                }
            }

            String sql = "";
            if (!Util.isNull(queryInputProtocol))
                sql = Util.parseMessage(MultiomyxSql.GET_ROLLBACKDATA_FROM_PROTOCOL, queryInputProtocol);
            else
                sql = Util.parseMessage(MultiomyxSql.GET_ROLLBACKDATA_FROM_PROTOCOL, protocolName);
            DataSet dsSqlData = getQueryProcessor().getSqlDataSet(sql);
            if (dsSqlData == null)
                throw new SapphireException("The below query cannot be executed.\n" + sql);
            if (dsSqlData.size() > 1)
                throw new SapphireException("More than one rollback info record is obtained for the selected combination");
            if (dsSqlData.size() > 0) {
                sampleRecordRollback(dsSqlData, sampleid, protocolName, protocolId, protocolStatus);
                sampleTestCodeMapRollback(dsSqlData, sampleid, protocolId, protocolName, protocolStatus, panelid);
                samplePanelStepMapRollback(sampleid, dsSqlData, panelid);
                moImageRollback(dsSqlData, sampleid, protocolId, panelid);
                callRollBkWS(sampleid, protocolId);
                analyticsRollback(dsSqlData, batchid, panelid, protocolId, sampleid);
            }
        }
    }

    private void sampleRecordRollback(DataSet dsprotocolDtl, String sampleid, String protocolName, String protocolId, String protocolStatus) throws SapphireException {
        if (dsprotocolDtl != null && dsprotocolDtl.size() > 0 && !Util.isNull(sampleid)
                && !Util.isNull(protocolName) && !Util.isNull(protocolId)) {
            try {
                PropertyList Prop = new PropertyList();
                Prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                Prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
                Prop.setProperty("u_mostatus", dsprotocolDtl.getValue(0, "mostatus", ""));
                Prop.setProperty("u_currentmovementstep", dsprotocolDtl.getValue(0, "step", ""));
                Prop.setProperty("u_moprotocol", protocolName);
                Prop.setProperty("u_moprotocolid", protocolId);
                Prop.setProperty("u_moprotocolstatus", protocolStatus);
                Prop.setProperty("u_moprotocoltype", dsprotocolDtl.getValue(0, "protocoltype", ""));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, Prop);

            } catch (Exception ex) {
                throw new SapphireException("Error: Unable to edit in Sample. Reason" + ex.getMessage());
            }


        }
    }

    private void sampleTestCodeMapRollback(DataSet dsprotocolDtl, String sampleid, String protocolid, String protocolName, String protocolStatus, String panelid) throws SapphireException {
        if (dsprotocolDtl != null && dsprotocolDtl.size() > 0) {
            String category = dsprotocolDtl.getValue(0, "category", "");
            String protocolType = dsprotocolDtl.getValue(0, "protocoltype", "");
            if (!Util.isNull(sampleid)) {
                String sql = Util.parseMessage(MultiomyxSql.GET_SAMPLETESTCODEMAP_FROM_SAMPLE, sampleid, panelid);
                DataSet dssampleTestcodemap = getQueryProcessor().getSqlDataSet(sql);
                DataSet dsFilterSampleTCmapofsameRound = new DataSet();
                DataSet dsFilterSampleTCmapofgrtrRound = new DataSet();
                String teststatus = dsprotocolDtl.getValue(0, "teststatus", "");
                if (dssampleTestcodemap != null && dssampleTestcodemap.size() > 0) {
                    if (Util.isNull(category)) {
                        try {
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                            pl.setProperty(EditSDI.PROPERTY_KEYID1, dssampleTestcodemap.getColumnValues("u_sampletestcodemapid", ";"));
                            pl.setProperty("teststatus", "In Progress");
                            pl.setProperty("moprotocol", "(null)");
                            pl.setProperty("moprotocolid", "(null)");
                            pl.setProperty("moprotocolstatus", "(null)");
                            pl.setProperty("moprotocoltype", "(null)");
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                        } catch (Exception e) {
                            throw new SapphireException("Error: Unable to Edit Data into SampleTestCodeMap. Reason: " + e.getMessage());
                        }


                    } else {
                        String round = "";

                        if (!Util.isNull(protocolid)) {
//                            String protocolidarr[] = protocolid.split(".");
                            String protocolidarr[] = StringUtil.split(protocolid, ".");
                            if (protocolidarr != null && protocolidarr.length > 0)
                                round = protocolidarr[0];
                            if (Util.isNull(round))
                                throw new SapphireException("Round cannot be obtained");
                            String sqlofmptm = Util.parseMessage(MultiomyxSql.GET_MOPANELTESTCODEMAP_FROM_ROUND, round, panelid);
                            DataSet dsMopanelTestcodeMapRcd = getQueryProcessor().getSqlDataSet(sqlofmptm);
                            if (dsMopanelTestcodeMapRcd != null && dsMopanelTestcodeMapRcd.size() > 0) {
                                int inputround = Integer.parseInt(round);
                                HashMap<String, String> hm = new HashMap<>();
//                                hm.put("round", round);
//                                DataSet dsFilterofprotocolRound = dsMopanelTestcodeMapRcd.getFilteredDataSet(hm);
//                                if (dsFilterofprotocolRound != null && dsFilterofprotocolRound.size() > 0) {
//                                    for (int i = 0; i < dsFilterofprotocolRound.size(); i++) {
//                                        hm.clear();
//                                        hm.put("lvtestcodeid", dsFilterofprotocolRound.getValue(i, "testcodeid"));
//                                        DataSet dsFilter = dssampleTestcodemap.getFilteredDataSet(hm);
//                                        if (dsFilter.size() > 0) {
//                                            dsFilterSampleTCmapofsameRound.copyRow(dsFilter, -1, 1);
//                                        }
//                                    }
//                                }

                                for (int j = 0; j < dsMopanelTestcodeMapRcd.size(); j++) {
                                    String roundval = dsMopanelTestcodeMapRcd.getValue(j, "round");
                                    int roundnm = Integer.parseInt(roundval);
                                    if (roundnm > inputround) {
                                        hm.clear();
                                        hm.put("lvtestcodeid", dsMopanelTestcodeMapRcd.getValue(j, "testcodeid"));
                                        DataSet filterds = dssampleTestcodemap.getFilteredDataSet(hm);
                                        if (filterds.size() > 0) {
                                            dsFilterSampleTCmapofgrtrRound.copyRow(filterds, -1, 1);
                                        }
                                    } else if (roundnm == inputround) {
                                        hm.clear();
                                        hm.put("lvtestcodeid", dsMopanelTestcodeMapRcd.getValue(j, "testcodeid"));
                                        DataSet filterds = dssampleTestcodemap.getFilteredDataSet(hm);
                                        if (filterds.size() > 0) {
                                            dsFilterSampleTCmapofsameRound.copyRow(filterds, -1, 1);
                                        }
                                    }
                                }
                            }

                        }
                    }

                    DataSet dsmerge = mergeDatasetfilterByRound(dsFilterSampleTCmapofsameRound, dsFilterSampleTCmapofgrtrRound, protocolid, protocolName, protocolType, protocolStatus, teststatus);
                    if (dsmerge != null && dsmerge.size() > 0) {
                        try {
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                            pl.setProperty(EditSDI.PROPERTY_KEYID1, dsmerge.getColumnValues("sampletestcodemapid", ";"));
                            pl.setProperty("teststatus", dsmerge.getColumnValues("teststatus", ";"));
                            pl.setProperty("moprotocol", dsmerge.getColumnValues("moprotocol", ";"));
                            pl.setProperty("moprotocolid", dsmerge.getColumnValues("moprotocolid", ";"));
                            pl.setProperty("moprotocolstatus", dsmerge.getColumnValues("moprotocolstatus", ";"));
                            pl.setProperty("moprotocoltype", dsmerge.getColumnValues("moprotocoltype", ";"));
                            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                        } catch (Exception e) {
                            throw new SapphireException("Error: Unable to Edit Data into SampleTestCodeMap. Reason: " + e.getMessage());
                        }

                    }

                }
            }
        }
    }

    private DataSet mergeDatasetfilterByRound(DataSet dsSameRound, DataSet dsGrtrRound, String protocolid,
                                              String protocolName, String protocolType, String protocolStatus, String teststatus) throws SapphireException {
        DataSet dsMerge = new DataSet();
        dsMerge.addColumn("teststatus", DataSet.STRING);
        dsMerge.addColumn("moprotocol", DataSet.STRING);
        dsMerge.addColumn("moprotocolid", DataSet.STRING);
        dsMerge.addColumn("moprotocolstatus", DataSet.STRING);
        dsMerge.addColumn("moprotocoltype", DataSet.STRING);
        dsMerge.addColumn("sampletestcodemapid", DataSet.STRING);
        if (dsSameRound != null && dsSameRound.size() > 0) {
            for (int i = 0; i < dsSameRound.size(); i++) {
                int rowId = dsMerge.addRow();
                dsMerge.setValue(rowId, "teststatus", teststatus);
                dsMerge.setValue(rowId, "moprotocol", protocolName);
                dsMerge.setValue(rowId, "moprotocolid", protocolid);
                dsMerge.setValue(rowId, "moprotocolstatus", protocolStatus);
                dsMerge.setValue(rowId, "moprotocoltype", protocolType);
                dsMerge.setValue(rowId, "sampletestcodemapid", dsSameRound.getValue(i, "u_sampletestcodemapid", ""));
            }
        }
        if (dsGrtrRound != null && dsGrtrRound.size() > 0) {
            for (int i = 0; i < dsGrtrRound.size(); i++) {
                int rowId = dsMerge.addRow();
                dsMerge.setValue(rowId, "teststatus", "In Progress");
                dsMerge.setValue(rowId, "moprotocol", "(null)");
                dsMerge.setValue(rowId, "moprotocolid", "(null)");
                dsMerge.setValue(rowId, "moprotocolstatus", "(null)");
                dsMerge.setValue(rowId, "moprotocoltype", "(null)");
                dsMerge.setValue(rowId, "sampletestcodemapid", dsGrtrRound.getValue(i, "u_sampletestcodemapid", ""));

            }
        }
        return dsMerge;

    }

    private void samplePanelStepMapRollback(String sampleid, DataSet dsRollbackRcd, String panelid) throws SapphireException {
        if (dsRollbackRcd != null && dsRollbackRcd.size() > 0 && !Util.isNull(sampleid)) {
            String sql = Util.parseMessage(MultiomyxSql.GET_MOPANELSTEPMAP_BY_SAMPLE, sampleid, panelid);
            DataSet dsSamplePanelData = getQueryProcessor().getSqlDataSet(sql);
            DataSet dssameStepNm;

            if (dsSamplePanelData != null && dsSamplePanelData.size() > 0) {
                DataSet resultEdit = new DataSet();
                resultEdit.addColumn("u_samplepanelstpmapid", DataSet.STRING);
                resultEdit.addColumn("status", DataSet.STRING);

                HashMap<String, String> hm = new HashMap<>();
                hm.put("stepname", dsRollbackRcd.getValue(0, "step", ""));
                dssameStepNm = dsSamplePanelData.getFilteredDataSet(hm);

                if (dssameStepNm == null || dssameStepNm.size() == 0)
                    throw new SapphireException("Steps info cannot be obtained for the sample " + sampleid + " " +
                            "corresponding to the step " + dsRollbackRcd.getValue(0, "step", ""));

                String inputstepnum = dssameStepNm.getValue(0, "stepno");
                String inputstepname = dssameStepNm.getValue(0, "stepname");

                if (Util.isNull(inputstepnum)) {
                    throw new SapphireException("Step number not define for the step:" + inputstepname);
                }
                int inputstepnumber = Integer.parseInt(inputstepnum);
                for (int i = 0; i < dsSamplePanelData.size(); i++) {
                    String stepnm = dsSamplePanelData.getValue(i, "stepno", "");
                    String samplepanelstpmapid = dsSamplePanelData.getValue(i, "u_samplepanelstpmapid", "");
                    int stepnum = Integer.parseInt(stepnm);
                    if (stepnum >= inputstepnumber) {
                        int rowNum = resultEdit.addRow();
                        resultEdit.setValue(rowNum, "u_samplepanelstpmapid", samplepanelstpmapid);
                        resultEdit.setValue(rowNum, "status", "Pending");
                    } else if (stepnum < inputstepnumber) {
                        int rowNum = resultEdit.addRow();
                        resultEdit.setValue(rowNum, "u_samplepanelstpmapid", samplepanelstpmapid);
                        resultEdit.setValue(rowNum, "status", "Completed");
                    }
                }
                if (resultEdit != null && resultEdit.size() > 0) {
                    try {
                        PropertyList prop = new PropertyList();
                        prop.setProperty(EditSDI.PROPERTY_SDCID, "SamplePanelStpMap");
                        prop.setProperty(EditSDI.PROPERTY_KEYID1, resultEdit.getColumnValues("u_samplepanelstpmapid", ";"));
                        prop.setProperty("status", resultEdit.getColumnValues("status", ";"));

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

                    } catch (Exception ex) {
                        throw new SapphireException("Error: Unable to edit in SamplePanelStpMap. Reason" + ex.getMessage());
                    }
                }
            }
        }
    }

    private void moImageRollback(DataSet dsRollbackRcd, String sampleid, String protocolid, String panelid) throws SapphireException {
        if (dsRollbackRcd != null && dsRollbackRcd.size() > 0 && !Util.isNull(sampleid)) {
            String category = dsRollbackRcd.getValue(0, "category", "");
            String sql = Util.parseMessage(MultiomyxSql.GET_MOIMAGEID_BY_SAMPLE_SAMPLETESTCODEMAP, sampleid, sampleid, panelid);
            DataSet dsmoImageData = getQueryProcessor().getSqlDataSet(sql);
            if (dsmoImageData != null && dsmoImageData.size() > 0) {
                if (Util.isNull(category)) {
                    String imagetypeprotocol = dsRollbackRcd.getValue(0, "imagetypetodel");
                    if (!Util.isNull(imagetypeprotocol)) {
                        String imagetypeprotocolarr[] = imagetypeprotocol.split(",");
                        if (imagetypeprotocolarr != null && imagetypeprotocolarr.length > 0) {
                            HashMap<String, String> hm = new HashMap<String, String>();
                            DataSet resultDS = new DataSet();
                            for (int i = 0; i < imagetypeprotocolarr.length; i++) {
                                hm.clear();
                                hm.put("imagetype", imagetypeprotocolarr[i]);
                                DataSet filterds = dsmoImageData.getFilteredDataSet(hm);
                                if (filterds.size() > 0) {
                                    resultDS.copyRow(filterds, -1, 1);
                                }

                            }
                            if (resultDS != null && resultDS.size() > 0) {
                                try {
                                    PropertyList prop = new PropertyList();
                                    prop.setProperty(DeleteSDI.PROPERTY_SDCID, "MOImage");
                                    prop.setProperty(DeleteSDI.PROPERTY_KEYID1, resultDS.getColumnValues("u_moimageid", ";"));

                                    getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                                } catch (Exception ex) {
                                    throw new SapphireException("Can not delete Moimge Record : " + ex.getMessage());
                                }
                            }
                        }
                    }
                } else {
                    String round = "";
                    HashMap<String, String> hm = new HashMap<>();
                    DataSet dsFilterofSameRound = new DataSet();
                    DataSet dsFilterofGrtrRound = new DataSet();
                    if (!Util.isNull(protocolid)) {
                        String protocolidarr[] = StringUtil.split(protocolid, ".");
                        if (protocolidarr != null && protocolidarr.length > 0)
                            round = protocolidarr[0];
                        if (Util.isNull(round))
                            throw new SapphireException("Round cannot be obtained");
                        String sqlofmptm = Util.parseMessage(MultiomyxSql.GET_MOPANELTESTCODEMAP_FROM_ROUND, round, panelid);
                        DataSet dsMopanelTestcodeMapRcd = getQueryProcessor().getSqlDataSet(sqlofmptm);
                        int inputround = Integer.parseInt(round);
                        for (int j = 0; j < dsMopanelTestcodeMapRcd.size(); j++) {
                            String roundval = dsMopanelTestcodeMapRcd.getValue(j, "round");
                            int roundnm = Integer.parseInt(roundval);
                            if (roundnm == inputround) {
                                dsFilterofSameRound.copyRow(dsMopanelTestcodeMapRcd, j, 1);
                            }
                            if (roundnm > inputround) {
                                dsFilterofGrtrRound.copyRow(dsMopanelTestcodeMapRcd, j, 1);
                            }
                        }
                        if (dsFilterofSameRound != null && dsFilterofSameRound.size() > 0) {
                            DataSet dsfilterofSameRoundMOImgToDel = new DataSet();
                            String imagetypeprotocolarr[] = null;
                            String sqlofimage = Util.parseMessage(MultiomyxSql.GET_MOIMAGEID_BY_SAMPLETESTCODEMAP, sampleid,
                                    StringUtil.replaceAll(dsFilterofSameRound.getColumnValues("testcodeid", ";"), ";", "','"));
                            DataSet dsImageofSamerRoundMOImgInfo = getQueryProcessor().getSqlDataSet(sqlofimage);
                            if (dsImageofSamerRoundMOImgInfo != null && dsImageofSamerRoundMOImgInfo.size() > 0) {
                                String imagetypeprotocol = dsRollbackRcd.getValue(0, "imagetypetodel");
                                if (!Util.isNull(imagetypeprotocol)) {
                                    imagetypeprotocolarr = StringUtil.split(imagetypeprotocol, ",");
                                    if (imagetypeprotocolarr != null && imagetypeprotocolarr.length > 0) {
                                        for (int i = 0; i < imagetypeprotocolarr.length; i++) {
                                            hm.clear();
                                            hm.put("imagetype", imagetypeprotocolarr[i]);
                                            DataSet filterds = dsImageofSamerRoundMOImgInfo.getFilteredDataSet(hm);
                                            if (filterds.size() > 0) {
                                                dsfilterofSameRoundMOImgToDel.copyRow(filterds, -1, 1);
                                            }

                                        }
                                    }
                                }
                            }
                            if (dsfilterofSameRoundMOImgToDel != null && dsfilterofSameRoundMOImgToDel.size() > 0) {
                                try {
                                    PropertyList prop = new PropertyList();
                                    prop.setProperty(DeleteSDI.PROPERTY_SDCID, "MOImage");
                                    prop.setProperty(DeleteSDI.PROPERTY_KEYID1, dsfilterofSameRoundMOImgToDel.getColumnValues("u_moimageid", ";"));

                                    getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                                } catch (Exception ex) {
                                    throw new SapphireException("Can not delete Moimge Record : " + ex.getMessage());
                                }
                            }

                        }
                        if (dsFilterofGrtrRound != null && dsFilterofGrtrRound.size() > 0) {
                            String sqlofimage = Util.parseMessage(MultiomyxSql.GET_MOIMAGEID_BY_SAMPLETESTCODEMAP, sampleid,
                                    StringUtil.replaceAll(dsFilterofGrtrRound.getColumnValues("testcodeid", ";"), ";", "','"));
                            DataSet dsImageofgrtrRoundMOImgInfo = getQueryProcessor().getSqlDataSet(sqlofimage);
                            if (dsImageofgrtrRoundMOImgInfo != null && dsImageofgrtrRoundMOImgInfo.size() > 0) {
                                DataSet dsImageofgrtrRoundMOImgToDel = new DataSet();

                                HashMap<String, String> hmap = new HashMap<String, String>();
                                hm.clear();
                                hm.put("imagetype", "Stained");
                                DataSet filterds = dsImageofgrtrRoundMOImgInfo.getFilteredDataSet(hm);
                                if (filterds.size() > 0) {
                                    dsImageofgrtrRoundMOImgToDel.copyRow(filterds, -1, 1);
                                }
                                hm.clear();
                                hm.put("imagetype", "Bleached");
                                filterds = dsImageofgrtrRoundMOImgInfo.getFilteredDataSet(hm);
                                if (filterds.size() > 0) {
                                    dsImageofgrtrRoundMOImgToDel.copyRow(filterds, -1, 1);
                                }

                                if (dsImageofgrtrRoundMOImgToDel != null && dsImageofgrtrRoundMOImgToDel.size() > 0) {
                                    try {
                                        PropertyList prop = new PropertyList();
                                        prop.setProperty(DeleteSDI.PROPERTY_SDCID, "MOImage");
                                        prop.setProperty(DeleteSDI.PROPERTY_KEYID1, dsImageofgrtrRoundMOImgToDel.getColumnValues("u_moimageid", ";"));

                                        getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, prop);
                                    } catch (Exception ex) {
                                        throw new SapphireException("Can not delete Moimge Record : " + ex.getMessage());
                                    }
                                }
                            }

                        }

                    }

                }

            }

        }
    }

    private void callRollBkWS(String slideid, String protocolid) throws SapphireException {
        if (!Util.isNull(slideid) && !Util.isNull(protocolid)) {
            PropertyList props = new PropertyList();
            props.setProperty("operationName", "sampleRollBack");
            props.setProperty("slideid", slideid);
            props.setProperty("protocolid", protocolid);
            getActionProcessor().processAction("MOLWSAction", "1", props);

//            props.clear();
//            props.setProperty("operationName", "datasourceRestart");
//            getActionProcessor().processAction("MOLWSAction", "1", props);
        }
    }

    private void analyticsRollback(DataSet dsRollbackrcd, String batchId, String panelId, String protocolId, String sampleId) throws SapphireException {
        if (dsRollbackrcd != null && dsRollbackrcd.size() > 0) {
            String flagAnalyticsRollback = dsRollbackrcd.getValue(0, "analyticsrollback", "");
            if (flagAnalyticsRollback.equalsIgnoreCase("Y")) {
                if (!Util.isNull(batchId) && !Util.isNull(panelId)) {
                    String round = "";
                    if (!Util.isNull(protocolId)) {
                        String protocolidarr[] = StringUtil.split(protocolId, ".");
                        if (protocolidarr != null && protocolidarr.length > 0)
                            round = protocolidarr[0];
                        if (Util.isNull(round))
                            throw new SapphireException("Round cannot be obtained");
                        String sqlofmptm = Util.parseMessage(MultiomyxSql.GET_MOPANELTESTCODEMAP_FROM_ROUND, round, panelId);
                        DataSet dsMopanelTestcodeMapRcd = getQueryProcessor().getSqlDataSet(sqlofmptm);
                        if (dsMopanelTestcodeMapRcd != null && dsMopanelTestcodeMapRcd.size() > 0) {
                            int inputround = Integer.parseInt(round);
                            String testcode="";
                            for (int j = 0; j < dsMopanelTestcodeMapRcd.size(); j++) {
                                String roundval = dsMopanelTestcodeMapRcd.getValue(j, "round");
                                String currTestcode = dsMopanelTestcodeMapRcd.getValue(j, "testcodeid");
                                int roundnm = Integer.parseInt(roundval);
                                if (roundnm == inputround) {
                                    testcode +=";"+currTestcode;


                                }
                            }
                            if(!Util.isNull(testcode)) {
                                String allTestcode="";
                                if(testcode.startsWith(";"))
                                    allTestcode = testcode.substring(1);
                                String sqlofmoimage = Util.parseMessage(MultiomyxSql.MOIMAGEID_BY_BATCHID_TESTCODE, sampleId, batchId, StringUtil.replaceAll(allTestcode, ";", "','"));
                                DataSet dsMOimagedtl = getQueryProcessor().getSqlDataSet(sqlofmoimage);
                                if (dsMOimagedtl != null && dsMOimagedtl.size() > 0) {
                                    try {
                                        PropertyList prop = new PropertyList();
                                        prop.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
                                        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsMOimagedtl.getColumnValues("u_moimageid", ";"));
                                        prop.setProperty("startmoanalysis", "(null)");
                                        prop.setProperty("status", "(null)");
                                        prop.setProperty("assignto", "(null)");
                                        prop.setProperty("assignby", "(null)");
                                        prop.setProperty("assigndt", "(null)");
                                        prop.setProperty("bioqcby", "(null)");
                                        prop.setProperty("bioqcdt", "(null)");
                                        prop.setProperty("bioqccomment", "(null)");
                                        prop.setProperty("analysisscriptversion", "(null)");

                                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);

                                    } catch (Exception ex) {
                                        throw new SapphireException("Error: Unable to update in MOImage. Reason" + ex.getMessage());
                                    }
                                }
                            }


                        }


                    }

                }
            }
        }
    }


}