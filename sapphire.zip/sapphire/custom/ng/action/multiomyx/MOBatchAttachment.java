package sapphire.custom.ng.action.multiomyx;

import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import static sapphire.custom.ng.util.Util.isNull;

/**
 * Created by ssen on 10/4/2017.
 */
public class MOBatchAttachment extends BaseAction implements MOConstants {


    public void processAction(PropertyList properties) throws SapphireException {
        String batchid = properties.getProperty("batchid","");
        String status = properties.getProperty("status","");
        String imageid = properties.getProperty("imageid","");
        String file = properties.getProperty("path","");
        String comments = properties.getProperty("comments","");
        String attachtype = properties.getProperty("type","");
        String nodeid = properties.getProperty("nodeid","");
        if (isNull(imageid))
            throw new SapphireException("Moimage can't be found");
        if (isNull(nodeid))
            throw new SapphireException("Nodeid can't be found");
        if (isNull(batchid))
            throw new SapphireException("batchid can't be found");
        if (isNull(file))
            throw new SapphireException("File path can't be found");
        String filearr[] = file.split(";");
        for(int i =0;i<filearr.length;i++) {
            String newfile = attachFile(batchid, filearr[i],nodeid);
            //String newfile2 = Util.generateLocationPath(newfile,"file_","","");
            if(isNull(newfile))
                throw new SapphireException("File Path not generated");
            String[] batcharr = batchid.split(";");
            Set<String> mySet = new HashSet(Arrays.asList(batcharr));
            PropertyList prop = new PropertyList();
            for (String temp : mySet) {
                if (!Util.isNull(temp)) {
                    prop.clear();
                    prop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "MOBatch");
                    prop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, temp);
                    prop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, newfile);
                    prop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
                    prop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, comments);
                    if (!Util.isNull(attachtype))
                        prop.setProperty("u_attachmenttype", attachtype);

                    try {
                        getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, prop);
                    } catch (SapphireException ex) {
                        String msg = getTranslationProcessor().translate("Action failed. Attachment not added  " + ex.getMessage());
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
                    }
                }
            }


            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, imageid);
            prop.setProperty("status", status);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. EditSdi on MOImage  " + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
        }



    }

    private String attachFile(String batchid, String file,String nodeid) throws SapphireException {
        String FILELOCATIONPOLICY = "FileLocationPolicy";
        String NODEID = nodeid;
        String PROPS_LOCATION = "location";
        String PROPS_LOCATIONS = "locations";
        String newFile = "";
        if(isNull(NODEID))
            throw new SapphireException("Node id Cannot be found");
        if (!Util.isNull(batchid) && !Util.isNull(file)) {
            PropertyList plCaseFilePolicy = getConfigurationProcessor().getPolicy(FILELOCATIONPOLICY, NODEID);
            if (plCaseFilePolicy == null)
                throw new SapphireException("File Location path can't be found");
            PropertyListCollection plc = plCaseFilePolicy.getCollection(PROPS_LOCATIONS);
            String newfileLocation = "";
            String path = "";
            if (plc != null) {
                path = plc.getPropertyList(0).getProperty(PROPS_LOCATION);
                String uniqbatch =Util.getUniqueList(batchid,";",true);
                DataSet dsInput=new DataSet();
                dsInput.addColumn("batchid",DataSet.STRING);
                int rowNum=dsInput.addRow();
                dsInput.setValue(rowNum,"batchid",uniqbatch);
                newfileLocation = Util.generateLocationPath(path,dsInput);
                if (Util.isNull(newfileLocation))
                    throw new SapphireException("Please specify the path for keeping the plate maps in the policy " + FILELOCATIONPOLICY + " under the node " + NODEID);
                newFile = Util.copyFile(file, newfileLocation, ("file" + "_"));
                if (Util.isNull(newFile))
                    throw new SapphireException("File can't be created in the location " + newfileLocation);
            }

        }
          return newFile;


    }
}
