package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by ssen on 9/18/2017.
 */
public class PanelActivationDeactivation extends BaseAction implements MOConstants {
    public void processAction(PropertyList properties) throws SapphireException {
        String flag = properties.getProperty(CONSTANT_FLAG);
        String panelid = properties.getProperty(CONSTANT_TESTCODE);
        if(Util.isNull(panelid))
            throw new SapphireException("Please select atleast one panel");
        DataSet dsreagent = fetchAssociateReagent(panelid);
        if(flag.equalsIgnoreCase(CONSTANT_INACTIVE))
            panelValidation(panelid);
        PropertyList props = new PropertyList();
        props.setProperty(EditSDI.PROPERTY_SDCID, SDC_TESTCODE);
        props.setProperty(EditSDI.PROPERTY_KEYID1,panelid);
        if(flag.equalsIgnoreCase(CONSTANT_INACTIVE))
            props.setProperty(CONSTANT_DEACTIVATED,CONSTANT_Y);
        if(flag.equalsIgnoreCase(CONSTANT_ACTIVE))
            props.setProperty(CONSTANT_DEACTIVATED,"");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        }catch (ActionException ae) {
            throw new SapphireException("Error: Unable to Edit Data into Testcode. Reason: " + ae.getMessage());
        }
        if(dsreagent.size()>0) {
            props.clear();
            props.setProperty(EditSDI.PROPERTY_SDCID, SDC_LV_REAGENTLOT);
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsreagent.getColumnValues(CONSTANT_REAGENTLOTID, ";"));
            if (flag.equalsIgnoreCase(CONSTANT_INACTIVE))
                props.setProperty(CONSTANT_REAGENTSTATUS, CONSTANT_INACTIVE);
            if (flag.equalsIgnoreCase(CONSTANT_ACTIVE))
                props.setProperty(CONSTANT_REAGENTSTATUS, CONSTANT_ACTIVE);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (ActionException ae) {
                throw new SapphireException("Error: Unable to Edit Data into Reagentlot. Reason: " + ae.getMessage());
            }
        }




    }

    /**
     * This method fetch reagentlotid which are associated with panel
     * @param panelid
     * @return
     */
    private DataSet fetchAssociateReagent(String panelid) throws SapphireException {
        DataSet dsreagent =  new DataSet();
        if(!Util.isNull(panelid)){
            String allpanel = StringUtil.replaceAll(panelid, ";", "','");
            String sqldata = Util.parseMessage(MultiomyxSql.GET_REAGENTID_FROM_PANEL, allpanel);
            dsreagent = getQueryProcessor().getSqlDataSet(sqldata);
        }
        return dsreagent;
    }

    /**
     *
     * @param panelid
     */
    private void panelValidation(String panelid) throws SapphireException {
        String allpanel = StringUtil.replaceAll(panelid, ";", "','");
        String sqldata = Util.parseMessage(MultiomyxSql.GET_PANEL_DEACTIVATION_STATUS, allpanel);
        DataSet dspanel = getQueryProcessor().getSqlDataSet(sqldata);
        if(dspanel != null) {
            for (int i = 0; i < dspanel.size(); i++) {
                if (dspanel.getValue(i, CONSTANT_DEACTIVATED).equalsIgnoreCase(CONSTANT_Y)) {
                    throw new SapphireException("Panel:" + dspanel.getValue(i, CONSTANT_U_TESTCODEID) + " is already deactive.");
                }
            }
        }


    }

}
