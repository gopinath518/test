package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * Created by ssen on 10/6/2017.
 */
public class AssociateFinalScript extends BaseAction  {
    public void processAction(PropertyList properties) throws SapphireException {
        String moimageid = properties.getProperty("moimageid");
        String batchid = properties.getProperty("batchid");
        String version = properties.getProperty("version");
        String status = properties.getProperty("status");
        if(Util.isNull(moimageid))
            throw new SapphireException("Moimage id can't be blank");
        if(Util.isNull(batchid))
            throw new SapphireException("Batchid can't be blank");
        if(Util.isNull(status))
            throw new SapphireException("status can't be blank");

        PropertyList prop = new PropertyList();
        if(!Util.isNull(moimageid)) {
            prop.clear();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, moimageid);
            prop.setProperty("status", status);
            prop.setProperty("analysisscriptversion", version);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (SapphireException ex) {
                String msg = getTranslationProcessor().translate("Action failed. EditSdi on MOBatch  " + ex.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
            }
        }





    }
}
