package sapphire.custom.ng.action.multiomyx;

import com.labvantage.opal.validation.misc.ConvertUnits;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;


/**
 * Created by ssen on 8/28/2017.
 */
public class SlideReagentAssociation extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleTestCodeMapID = properties.getProperty("sampletestcodemapid");
        String testCode = properties.getProperty("testcode");
        if (Util.isNull(sampleTestCodeMapID)) {
            throw new SapphireException("Sampletestcodemap id not found");
        }
        DataSet dsAll = getAllData(sampleTestCodeMapID);
        if (dsAll == null || dsAll.size() == 0)
            throw new SapphireException("Staining cannot be performed \n Reagent information cannot be obtained.");
        dsAll = reagentValidationandFilteration(dsAll);
        reagentTestcodeMapValidation(dsAll, sampleTestCodeMapID, testCode);
        reagentPanelValidation(dsAll);

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "MOSampleRegMap");
        props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsAll.getRowCount()));
        props.setProperty("sampletestcodemapid", dsAll.getColumnValues("u_sampletestcodemapid", ";"));
        props.setProperty("sampleid", dsAll.getColumnValues("s_sampleid", ";"));
        props.setProperty("reagentlotid", dsAll.getColumnValues("reagentlotid", ";"));
        props.setProperty("reagentlotversionid", dsAll.getColumnValues("reagenttypeversionid", ";"));
        props.setProperty("volume", dsAll.getColumnValues("volume", ";"));
        props.setProperty("volunit", dsAll.getColumnValues("volunits", ";"));
        props.setProperty("type", dsAll.getColumnValues("type", ";"));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            DataSet dsreturnVol = reagentVolumeCheck(dsAll);
            props.clear();
            props.setProperty(EditTrackItem.PROPERTY_TRACKITEMID, dsreturnVol.getColumnValues("trackitemid", ";"));
            props.setProperty("qtycurrent", dsreturnVol.getColumnValues("finalvol", ";"));
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);

        } catch (ActionException ae) {
            throw new SapphireException("Error: Unable to Add Data into MOSampleRegMap Reason: " + ae.getMessage());
        }


    }

    private DataSet getAllData(String sampleTestCodeMapID) throws SapphireException {
        DataSet dsAlldata = new DataSet();
        if(!Util.isNull(sampleTestCodeMapID)) {
            String allSampleTestCodeMapID = StringUtil.replaceAll(sampleTestCodeMapID, ";", "','");
            String sqldata = Util.parseMessage(MultiomyxSql.GET_REAGENT_INFO, allSampleTestCodeMapID);
            dsAlldata = getQueryProcessor().getSqlDataSet(sqldata);
        }
        return dsAlldata;

    }

    /*private void reagentExpiryValidation(DataSet dsAll) throws SapphireException {
        String[] lotidarr = dsAll.getColumnValues("reagentlotid", ";").split(";");
        String[] reagenttype = dsAll.getColumnValues("reagenttypeid", ";").split(";");
        if (dsAll != null || dsAll.size() > 0) {
            for (int i = 0; i < dsAll.size(); i++) {
                if (!dsAll.getValue(i, "trackitemstatus").equalsIgnoreCase("Valid"))
                    throw new SapphireException("The Status of :  " + reagenttype[i] + " Reagent id: " + lotidarr[i] + " is not Valid");
                if (!dsAll.getValue(i, "reagentstatus").equalsIgnoreCase("Active"))
                    throw new SapphireException("The Status of :  " + reagenttype[i] + " Reagent id: " + lotidarr[i] + " is not Active");
                Calendar dateobj = dsAll.getCalendar(i, "expirydt", null);
                Calendar cal = Calendar.getInstance();
                if (dateobj.before(cal))
                    throw new SapphireException("The expire date of Reagent type:  " + reagenttype[i] + " Reagent id: " + lotidarr[i] + " is expired");

            }
        }
    }*/
    private DataSet reagentValidationandFilteration(DataSet dsMain) throws SapphireException {
        DataSet dsFilter = new DataSet();
        DataSet dsError = new DataSet();
        dsFilter.addColumn("u_sampletestcodemapid", DataSet.STRING);
        dsFilter.addColumn("s_sampleid", DataSet.STRING);
        dsFilter.addColumn("reagentlotid", DataSet.STRING);
        dsFilter.addColumn("expirydt", DataSet.STRING);
        dsFilter.addColumn("reagenttypeversionid", DataSet.STRING);
        dsFilter.addColumn("volume", DataSet.STRING);
        dsFilter.addColumn("volunits", DataSet.STRING);
        dsFilter.addColumn("type", DataSet.STRING);
        dsFilter.addColumn("reagenttypeid", DataSet.STRING);
        dsFilter.addColumn("trackitemstatus", DataSet.STRING);
        dsFilter.addColumn("reagentstatus", DataSet.STRING);
        dsFilter.addColumn("testname", DataSet.STRING);
        dsFilter.addColumn("lvtestpanelid", DataSet.STRING);
        dsFilter.addColumn("u_lvpanelid", DataSet.STRING);
        //dsError.addColumn("reagentlotid", DataSet.STRING);
        dsError.addColumn("reagenttypeid", DataSet.STRING);
        dsError.addColumn("panelid", DataSet.STRING);
        //dsError.addColumn("reagentstatus", DataSet.STRING);
        //dsError.addColumn("expirydt", DataSet.STRING);

        if (dsMain != null && dsMain.size() > 0) {
            dsMain.sort("u_lvpanelid,reagenttypeid,u_sampletestcodemapid");
            ArrayList<DataSet> dsMainArr = dsMain.getGroupedDataSets("u_lvpanelid,reagenttypeid,u_sampletestcodemapid");
            if (dsMainArr.size() > 0) {
                for (int i = 0; i < dsMainArr.size(); i++) {
                    DataSet dsreagentType = dsMainArr.get(i);
                    int flag = 0;
                    int rownum = 0;
                    int row;
                    for (int j = 0; j < dsreagentType.size(); j++) {
                        if (dsreagentType.getValue(j, "reagentstatus").equalsIgnoreCase("Active")) {
                            if (dsreagentType.getValue(j, "trackitemstatus").equalsIgnoreCase("Valid")) {
                                Calendar dateobj = dsreagentType.getCalendar(j, "expirydt", null);
                                Calendar cal = Calendar.getInstance();
                                if (dateobj.after(cal) || dateobj.equals(cal)) {
                                    flag = 1;
                                    rownum = j;

                                }

                            }
                        }


                    }
                    if (flag == 1) {
                        dsFilter.copyRow(dsreagentType, rownum, 1);
                    } else {
                        row = dsError.addRow();
                        //dsError.setValue(row, "reagentlotid", dsreagentType.getValue(k, "reagentlotid"));
                        dsError.setValue(row, "reagenttypeid", dsreagentType.getValue(0, "reagenttypeid"));
                        dsError.setValue(row, "panelid", dsreagentType.getValue(0, "u_lvpanelid"));
                        // dsError.setValue(row, "reagentstatus", dsreagentType.getValue(k, "reagentstatus"));
                        // dsError.setValue(row, "expirydt", dsreagentType.getValue(k, "expirydt"));
                        // }
                    }
                }
                if (dsError.size() > 0) {
                    String target = "_blank";
                    String url = "rc?command=page&amp;page=LV_ReagentLotMaint&amp;&amp;sdcid=LV_ReagentLot&amp;mode=Add";


                    String errCodes = "<table border=1 style='border-collapse: collapse;border: 1px solid #000;background:#E0F8F7;color:#000;'><tr>" +
                            //"<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Reagent ID</b></th>" +
                            "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Reagent Type</b></th>" +
                            //// "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Trackitem Status</b></th>"+
                            //"<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Reagent Status</b></th>"+
                            "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Panel ID</b></th></tr>";
                    for (int i = 0; i < dsError.size(); i++) {
                        //errCodes += "<tr><td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><a href=" + url + "" + dsError.getValue(i, "reagentlotid", "") + " target=" + target + ">" + dsError.getValue(i, "reagentlotid", "") + "</a></td>";
                        errCodes += "<tr><td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "reagenttypeid", "") + "</td>";
                        //errCodes += "<td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "trackitemstatus", "") + "</td>";
                        //errCodes += "<td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "reagentstatus", "") + "</td>";
                        errCodes += "<td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "panelid", "") + "</td></tr>";
                    }
                    errCodes += "</table>";
//                    throw new SapphireException("Below are the combinations of reagent type on which valid reagentlot cannot be obtain :\n" + errCodes+"<tr> To add new reagent lot: <a href=" + url + " target="+target+"> Click here</a><tr>");
                    throw new SapphireException("Below are the combinations of reagent type on which valid reagentlot cannot be obtain :\n" + errCodes);

                }

            }
        }
        return dsFilter;
    }


    private DataSet reagentVolumeCheck(DataSet dsAll) throws SapphireException {
        int row;
        DataSet dsTotalvol = new DataSet();
        DataSet dsFinalvol = new DataSet();
        DataSet dsError = new DataSet();
        dsTotalvol.addColumn("reagentid", DataSet.STRING);
        dsTotalvol.addColumn("totalvol", DataSet.STRING);
        dsTotalvol.addColumn("unit", DataSet.STRING);

        dsFinalvol.addColumn("linkkeyid1", DataSet.STRING);
        dsFinalvol.addColumn("finalvol", DataSet.STRING);
        dsFinalvol.addColumn("trackitemid", DataSet.STRING);

        dsError.addColumn("reagentid",DataSet.STRING);
        dsError.addColumn("requiredvol",DataSet.STRING);
        dsError.addColumn("availablevol",DataSet.STRING);

        if (dsAll != null && dsAll.size() > 0) {
            dsAll.sort("reagentlotid");
            ArrayList<DataSet> dsAllArr = dsAll.getGroupedDataSets("reagentlotid");
            for (int i = 0; i < dsAllArr.size(); i++) {
                double num = 0;
                DataSet dstemp = dsAllArr.get(i);
                for (int j = 0; j < dstemp.size(); j++) {
                    num += Double.parseDouble(dstemp.getValue(j, "volume"));
                }
                row = dsTotalvol.addRow();
                dsTotalvol.setValue(row, "reagentid", dstemp.getValue(0, "reagentlotid"));
                dsTotalvol.setValue(row, "totalvol", String.valueOf(num));
                dsTotalvol.setValue(row, "unit", dstemp.getValue(0, "volunits"));
            }

            for (int i = 0; i < dsTotalvol.size(); i++) {
                double totalVol;
                String sqldata = Util.parseMessage(MultiomyxSql.GET_CURRVAL_REAGENT, dsTotalvol.getValue(i, "reagentid"));
                DataSet dstrackitemdata = getQueryProcessor().getSqlDataSet(sqldata);
                if (dstrackitemdata != null && dstrackitemdata.size() > 0) {
                    String trackitemUnit = dstrackitemdata.getValue(0, "qtyunits");
                    String reagentUnit = dsTotalvol.getValue(i, "unit");
                    if (!trackitemUnit.equalsIgnoreCase(reagentUnit) && !Util.isNull(trackitemUnit) && !Util.isNull(reagentUnit))
                        totalVol = Double.parseDouble(ConvertUnits.convertUnits(getQueryProcessor(), reagentUnit, trackitemUnit, String.valueOf(dsTotalvol.getValue(i, "totalvol", "0"))));
                    else
                        totalVol = Double.parseDouble(dsTotalvol.getValue(i, "totalvol", "0"));
                    //double trackitemVol = Integer.parseInt(dstrackitemdata.getValue(0, "qtycurrent", "0"));
                    double trackitemVol = Double.parseDouble(dstrackitemdata.getValue(0, "qtycurrent", "0"));
                    if (totalVol > trackitemVol) {
                        row = dsError.addRow();
                        dsError.setValue(row, "reagentid", dsTotalvol.getValue(i, "reagentid"));
                        dsError.setValue(row, "requiredvol", String.valueOf(totalVol));
                        dsError.setValue(row, "availablevol", String.valueOf(trackitemVol));

                    }
                    //throw new SapphireException("Sufficient amount of this  "+dsTotalvol.getValue(i,"reagentid")+"  is not available");
                    else {
                        trackitemVol -= totalVol;
                        row = dsFinalvol.addRow();
                        dsFinalvol.setValue(row, "linkkeyid1", dsTotalvol.getValue(i, "reagentid"));
                        dsFinalvol.setValue(row, "finalvol", String.valueOf(trackitemVol));
                        dsFinalvol.setValue(row, "trackitemid", dstrackitemdata.getValue(0, "trackitemid"));
                    }
                }

            }
            if (dsError.size() > 0) {
                String target = "_blank";
                String url = "rc?command=page&amp;page=LV_ReagentLotMaint&amp;&amp;sdcid=LV_ReagentLot&amp;mode=Edit&keyid1=";

                String errCodes = "<table border=1 style='border-collapse: collapse;border: 1px solid #000;background:#E0F8F7;color:#000;'><tr>" +
                        "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Reagent ID</b></th>" +
                        "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Required Amount</b></th>" +
                        "<th style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><b>Available Amount</b></th></tr>";
                for (int i = 0; i < dsError.size(); i++) {
//                    errCodes += "<tr><td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'><a href=" + url + "" + dsError.getValue(i, "reagentid", "") + " target=" + target + ">" + dsError.getValue(i, "reagentid", "") + "</a></td>";
                    errCodes += "<tr><td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "reagentid", "") + "</td>";
                    errCodes += "<td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "requiredvol", "") + "</td>";
                    errCodes += "<td style='padding-left:5px;padding-right:5px;padding-top:3px;padding-bottom:3px;font-family: Arial, Verdana, sans-serif;'>" + dsError.getValue(i, "availablevol", "") + "</td></tr>";
                }
                errCodes += "</table>";
                throw new SapphireException("Insufficient amount found for these reagent lot:\n" + errCodes);

            }


        }
        return dsFinalvol;
    }

    private void reagentTestcodeMapValidation(DataSet dsAll, String sampletestcodemap, String testcode) throws SapphireException {
        String[] sampletcodemaparr = sampletestcodemap.split(";");
        String[] testcodearr = testcode.split(";");
        HashMap hm = new HashMap();
        for (int i = 0; i < sampletcodemaparr.length; i++) {
            hm.clear();
            hm.put("u_sampletestcodemapid", sampletcodemaparr[i]);
            if (dsAll.getFilteredDataSet(hm).size() == 0)
                throw new SapphireException("Testcode: " + testcodearr[i] + " does not have any associate reagentlot ");
        }

    }

    private void reagentPanelValidation(DataSet dsAll) throws SapphireException {
        String[] sampletestcodepanelarr = StringUtil.split(dsAll.getColumnValues("lvtestpanelid", ";"), ";");
        String[] reagentpanelarr = StringUtil.split(dsAll.getColumnValues("u_lvpanelid", ";"), ";");
        for (int i = 0; i < dsAll.size(); i++) {
            if (!sampletestcodepanelarr[i].equalsIgnoreCase(reagentpanelarr[i]))
                throw new SapphireException("No reagentlot found for panelid : " + sampletestcodepanelarr[i]);
        }
    }


}



