package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.MOConstants;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

import com.labvantage.sapphire.actions.storage.EditTrackItem;

/**
 * Created by aritra.banerjee on 10/20/2017.
 * This Action Updates Mo Status and implements auto Routing Logic.
 */
public class MOSlideQC extends BaseAction implements MOConstants {

    private String qcPassList = "";


    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("sampleid", "");
        String smpltstcdmpid = properties.getProperty("stmid", "");
        String qcstatus = properties.getProperty("qcstatus", ""); // values can be : pass or fail or reImage

        String auditreason = properties.getProperty("auditreason", "");
        String comment = properties.getProperty("comment", "");
        String bleachqc = properties.getProperty("bleachqc", "N");

        if (auditreason.contains("others")) {
            if (Util.isNull(comment)) {
                throw new SapphireException("Error: Comment section can not be blank if 'Others' option is selected as Reason");
            } else {
                auditreason = auditreason.replaceAll("others", comment);
                properties.setProperty("auditreason", auditreason);
            }
        }

        //String batchid = props.getProperty("batchid", "");
        String callws = properties.getProperty("callws", "");

        if (Util.isNull(sampleid))
            throw new SapphireException("Error: Sample Id missing..");

        sampleid = Util.getUniqueList(sampleid, ";", true);
        /*Getting stm data-START*/
        if (!"Y".equalsIgnoreCase(bleachqc)) {
            String stmSql = Util.parseMessage(MultiomyxSql.STM_BY_SAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet stmDS = getQueryProcessor().getSqlDataSet(stmSql);
            if (stmDS != null && stmDS.getRowCount() > 0) {
                properties.setProperty("stmid", stmDS.getColumnValues("u_sampletestcodemapid", ";"));
                smpltstcdmpid = properties.getProperty("stmid", "");
            }
        }
        /*Getting stm data-END*/
        String sql = Util.parseMessage(MultiomyxSql.GET_MOSTATUS_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsStatus = getQueryProcessor().getSqlDataSet(sql);

        if (dsStatus == null || dsStatus.size() == 0)
            throw new SapphireException("Error: Unable to fetch Status for the selected samples.");

        if (!Util.isNull(smpltstcdmpid)) {
            updateSTM(properties);
        }
        if (dsStatus.size() > 0) {
            updateStatus(properties, dsStatus);
        }

        if (!"N".equalsIgnoreCase(callws)) {
            calWSMethod(sampleid, qcstatus);
        }

        routeSampleFromPathologyToMO(qcPassList);

    }

    /**
     * This method update mo status in SampleTestcodeMap
     *
     * @param props
     * @throws SapphireException
     */

    private void updateSTM(PropertyList props) throws SapphireException {

        String stmid = props.getProperty("stmid", "");
        if (Util.isNull(stmid))
            return;
        if (stmid.startsWith(";"))
            stmid = stmid.substring(1);
        String qcstatus = props.getProperty("qcstatus", ""); // pass or fail or reImage
        if (Util.isNull(qcstatus))
            throw new SapphireException("Error: QC status missing..");

        if (stmid.contains("#semicolon#")) {
            stmid = StringUtil.replaceAll(stmid, "#semicolon#", ";");
        }
        stmid = Util.getUniqueList(stmid, ";", true);
//        String sql = Util.parseMessage(MultiomyxSql.GET_TESTSTATUS_BY_SAMPLETESTCODEMAPID, StringUtil.replaceAll(stmid, ";", "','"));
        String sql = Util.parseMessage(MultiomyxSql.SIBLING_SAMPLETESTCODEMAPIS_BY_SAMPLETESTCODEMAPID, StringUtil.replaceAll(stmid, ";", "','"));
        DataSet dsTestStatus = getQueryProcessor().getSqlDataSet(sql);

        if (dsTestStatus == null)
            throw new SapphireException("Error: Unable to fetch  Test Status from sampletestcodemap.");
        if (dsTestStatus.size() == 0)
            return;

        dsTestStatus.addColumn("newstatus", DataSet.STRING);
        dsTestStatus.addColumn("imagetype", DataSet.STRING);

        DataSet result = new DataSet();

        for (int i = 0; i < dsTestStatus.size(); i++) {
            String currStatus = dsTestStatus.getValue(i, "teststatus");
            String prevStatus = dsTestStatus.getValue(i, "prevteststatus");
            if ("Stain Slide Imaging Completed".equalsIgnoreCase(currStatus) || "MOStainedImage".equalsIgnoreCase(currStatus)
                    || "MOSIQCFail".equalsIgnoreCase(currStatus) || "MOSIQCReImage".equalsIgnoreCase(currStatus)) { //for 'Stained QC Pass' in Staining
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    dsTestStatus.setValue(i, "newstatus", "MOSIQCPass");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
                        dsTestStatus.setValue(i, "newstatus", "MOStainCompleted");
                    } else {
                        dsTestStatus.setValue(i, "newstatus", "MOStainCompleted");
                    }
                }
                dsTestStatus.setValue(i, "imagetype", "Stained");
                result.copyRow(dsTestStatus, i, 1);
            } else if ("MOBleachedImage".equalsIgnoreCase(currStatus) ||
                    "MOBIQCFailed".equalsIgnoreCase(currStatus) || "MOBIQCReImage".equalsIgnoreCase(currStatus)) { //for 'Bleach QC Pass' in Bleaching
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    dsTestStatus.setValue(i, "newstatus", "MOBIQCPassed");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
                        dsTestStatus.setValue(i, "newstatus", "MOSlideBleached");
                    } else {
                        dsTestStatus.setValue(i, "newstatus", "MOSlideBleached");
                    }
                }
                dsTestStatus.setValue(i, "imagetype", "Bleached");
                result.copyRow(dsTestStatus, i, 1);
            }
        }
        if (dsTestStatus.size() > 0) {
            if (result != null && result.size() > 0) {
                try {
                    PropertyList pl = new PropertyList();
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, result.getColumnValues("u_sampletestcodemapid", ";"));
                    pl.setProperty("teststatus", result.getColumnValues("newstatus", ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                } catch (ActionException ae) {
                    throw new SapphireException("Error: Unable to Edit Data into SampleTestCodeMap. Reason: " + ae.getMessage());
                }
            }
            dsTestStatus.addColumn("id#imgtype", DataSet.STRING);
            for (int i = 0; i < dsTestStatus.size(); i++) {
                String cmbination = dsTestStatus.getValue(i, "u_sampletestcodemapid") + "#" + dsTestStatus.getValue(i, "imagetype");
                dsTestStatus.setValue(i, "id#imgtype", cmbination);
            }

            updateMOImage(dsTestStatus, qcstatus, props);
        }

    }

    /**
     * This method updates mo status in Sample SDc depending on the QC status selected by User.
     *
     * @param props
     * @param dsStatus
     * @throws SapphireException
     */
    private void updateStatus(PropertyList props, DataSet dsStatus) throws SapphireException {

        String auditreason = props.getProperty("auditreason", "");

        String qcstatus = props.getProperty("qcstatus", ""); // pass or fail or reImage
        if (Util.isNull(qcstatus))
            throw new SapphireException("Error: QC status missing..");

        dsStatus.addColumn("newstatus", DataSet.STRING);
        dsStatus.addColumn("routing", DataSet.STRING);
        dsStatus.addColumn("imagetype", DataSet.STRING);

        //String qcFailedSampleData = EMPTY_STRING;
        DataSet qcFailedSampleDS = new DataSet();
        for (int i = 0; i < dsStatus.size(); i++) {
            String currStatus = dsStatus.getValue(i, "u_mostatus");
            String prevMOStatus = dsStatus.getValue(i, "u_prevmostatus");
            String moreceivecomment = dsStatus.getValue(i, "u_moreceivecomment");

            if ("MOUnstained10xImage".equalsIgnoreCase(currStatus) ||
                    "MOUIQCFailed".equalsIgnoreCase(currStatus) || "MOUIQCReImage".equalsIgnoreCase(currStatus)) { //for 'QC pass' in Image ROI
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    dsStatus.setValue(i, "newstatus", "MOUIQCPassed");
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", "QC passed for image");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
//                        dsStatus.setValue(i, "newstatus", prevMOStatus);
                        dsStatus.setValue(i, "newstatus", "MOUnstained2xImage");
                        //qcFailedSampleData = qcFailedSampleData+";"+dsStatus.getValue(i, "s_sampleid");
                        qcFailedSampleDS.copyRow(dsStatus, i, 1);
                    } else {
//                        dsStatus.setValue(i, "newstatus", prevMOStatus);
                        dsStatus.setValue(i, "newstatus", "MOUnstained2xImage");
                    }
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", moreceivecomment);
                }
                dsStatus.setValue(i, "imagetype", "10x Unstained");
            } else if ("MOROISelectionCompleted".equalsIgnoreCase(currStatus) ||
                    "MOROISelectionQCFailed".equalsIgnoreCase(currStatus) || "MOROISelectionQCReImage".equalsIgnoreCase(currStatus)) { //for 'Complete Image QC' in Image ROI
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    String tempSample = dsStatus.getValue(i, "s_sampleid", "");
                    if (!Util.isNull(tempSample))
                        qcPassList += ";" + tempSample;
                    dsStatus.setValue(i, "newstatus", "MOROISelectionQCCompleted");
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", "Image ROI Selection QC Completed");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
//                        dsStatus.setValue(i, "newstatus", prevMOStatus);
                        dsStatus.setValue(i, "newstatus", "MOUIQCPassed");
                    } else {
//                        dsStatus.setValue(i, "newstatus", prevMOStatus);
                        dsStatus.setValue(i, "newstatus", "MOUIQCPassed");
                    }
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", moreceivecomment);
                }
                dsStatus.setValue(i, "imagetype", "ROI");

            } else if ("MOImageROICompleted".equalsIgnoreCase(currStatus) ||
                    "MOImageROIQCFail".equalsIgnoreCase(currStatus) || "MOImageROIQCReImage".equalsIgnoreCase(currStatus)) { //for 'Image ROI QC' in Image ROI
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    String tempSample = dsStatus.getValue(i, "s_sampleid", "");
                    if (!Util.isNull(tempSample))
                        qcPassList += ";" + tempSample;
                    dsStatus.setValue(i, "newstatus", "MOImageROIQCPass");
                    dsStatus.setValue(i, "routing", "Y");
                    dsStatus.setValue(i, "u_moreceivecomment", "Image ROI QC Pass");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
                        dsStatus.setValue(i, "newstatus", "MOROISelectionQCCompleted");
                    } else {
                        dsStatus.setValue(i, "newstatus", "MOROISelectionQCCompleted");
                    }
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", moreceivecomment);
                }
                dsStatus.setValue(i, "imagetype", "20x ROI Background");

            } else if ("Stain Slide Imaging Completed".equalsIgnoreCase(currStatus) || "MOStainedImage".equalsIgnoreCase(currStatus)
                    || "MOSIQCFail".equalsIgnoreCase(currStatus) || "MOSIQCReImage".equalsIgnoreCase(currStatus)) { //for 'Stained QC Pass' in Staining
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    dsStatus.setValue(i, "newstatus", "MOSIQCPass");
                    dsStatus.setValue(i, "routing", "Y");
                    dsStatus.setValue(i, "u_moreceivecomment", "Stain QC Passed");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
                        dsStatus.setValue(i, "newstatus", "Staining Completed");
                    } else {
                        dsStatus.setValue(i, "newstatus", "Staining Completed");
                    }
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", moreceivecomment);
                }
                dsStatus.setValue(i, "imagetype", "Stained");
            } else if ("MOBleachedImage".equalsIgnoreCase(currStatus) ||
                    "MOBIQCFailed".equalsIgnoreCase(currStatus) || "MOBIQCReImage".equalsIgnoreCase(currStatus)) { //for 'Bleach QC Pass' in Bleaching
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    dsStatus.setValue(i, "newstatus", "MOBIQCPassed");
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", "MOBIQCPassed");
                } else {
                    if ("fail".equalsIgnoreCase(qcstatus)) {
                        dsStatus.setValue(i, "newstatus", "MOSlideBleached");
                    } else {
                        dsStatus.setValue(i, "newstatus", "MOSlideBleached");
                    }
                    dsStatus.setValue(i, "routing", "N");
                    dsStatus.setValue(i, "u_moreceivecomment", moreceivecomment);
                }
                dsStatus.setValue(i, "imagetype", "Bleached");
            }
        }
        dsStatus.addColumn("id#imgtype", DataSet.STRING);
        for (int i = 0; i < dsStatus.size(); i++) {
            String cmbination = dsStatus.getValue(i, "s_sampleid") + "#" + dsStatus.getValue(i, "imagetype");
            dsStatus.setValue(i, "id#imgtype", cmbination);
        }
        executeRouting(dsStatus, auditreason, props);

        //For backward routing of Multiomyx samples
        if (qcFailedSampleDS != null && qcFailedSampleDS.getRowCount() > 0) {
            //String sampleData = qcFailedSampleData.substring(1);
            //String sampleData = qcFailedSampleDS.getColumnValues("s_sampleid", ";");
            this.updateStepStatus(qcFailedSampleDS, auditreason);
        }

        //** code to add Image to MOImage when ROI gets completed
        /*String batchid = props.getProperty("batchid", "");
        addImageforROI(dsStatus, batchid);*/
    }

    /**
     * This method updates mo status in DB and evoke Routing logic by Implementing FlowCompleteStep Action.
     *
     * @param dsFinal, auditreason
     * @throws SapphireException
     */
    private void executeRouting(DataSet dsFinal, String auditreason, PropertyList props) throws SapphireException {

        if (dsFinal.size() > 0) {
            String samples = dsFinal.getColumnValues("s_sampleid", ";");

            if (!Util.isNull(samples)) {
                try {
                    PropertyList updateProp = new PropertyList();
                    updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditSDI.PROPERTY_KEYID1, samples);
                    updateProp.setProperty("u_mocreatedt", "n");
                    updateProp.setProperty("u_mocreateby", connectionInfo.getSysuserId());
                    updateProp.setProperty("u_moreceivecomment", dsFinal.getColumnValues("moreceivecomment", ";"));
                    updateProp.setProperty("u_mostatus", dsFinal.getColumnValues("newstatus", ";"));
                    updateProp.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);


                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                } catch (Exception ex) {
                    throw new SapphireException("Error: Unable to edit mo status in Sample.");
                }
            }

            updateMOImage(dsFinal, props.getProperty("qcstatus"), props);


            HashMap<String, String> hm = new HashMap<>();
            hm.put("routing", "Y");

            DataSet dsFilter = dsFinal.getFilteredDataSet(hm);

            if (dsFilter.size() > 0) {
                try {
                    PropertyList pl = new PropertyList();
                    pl.setProperty("sampleid", dsFilter.getColumnValues("s_sampleid", ";"));

                    getActionProcessor().processAction("FlowCompleteStep", "1", pl);

                } catch (Exception ex) {
                    throw new SapphireException("Error while Routing. Error : " + ex.getMessage());
                }
            }

        }
    }

    /**
     * This method adds Image to MOImage when IMage ROI gets completed
     *
     * @param dsFinal
     * @param batchid
     * @throws SapphireException
     */

    private void addImageforROI(DataSet dsFinal, String batchid) throws SapphireException {

        String sampleToAddImage = "";
        for (int j = 0; j < dsFinal.size(); j++) {
            if ("MOImageROICompleted".equalsIgnoreCase(dsFinal.getValue(j, "newstatus"))) {
                sampleToAddImage += ";" + dsFinal.getValue(j, "s_sampleid");
            }

        }
        if (sampleToAddImage.startsWith(";"))
            sampleToAddImage = sampleToAddImage.substring(1);

        if (!Util.isNull(sampleToAddImage)) {
            try {
                PropertyList moimgprop = new PropertyList();
                moimgprop.setProperty("tramstop", "MOImageROI");
                moimgprop.setProperty("imagetype", "ROI");
                moimgprop.setProperty("sampleid", sampleToAddImage);
                moimgprop.setProperty("batchid", batchid);

                getActionProcessor().processAction("AddMOImage", "1", moimgprop);

            } catch (Exception ex) {
                throw new SapphireException("Error while adding Image to MOImage. Error : " + ex.getMessage());
            }
        }
    }


    /**
     * This method callse WS methods from MOLWSAction Action
     *
     * @param sampleid
     * @throws SapphireException
     */
    private void calWSMethod(String sampleid, String status) throws SapphireException {

        PropertyList props = new PropertyList();

        if (Util.isNull(status)) {
            throw new SapphireException("Qc Status missing.");
        }

        if ("pass".equalsIgnoreCase(status))
            status = "Pass";
        else if ("fail".equalsIgnoreCase(status) || "reimage".equalsIgnoreCase(status))
            status = "Fail";

        try {
            props.setProperty("operationName", "updateQCStatus");
            props.setProperty("slideid", sampleid);
            props.setProperty("status", StringUtil.repeat(status, sampleid.split(";").length, ";"));

            getActionProcessor().processAction("MOLWSAction", "1", props);

        } catch (Exception ex) {
            throw new SapphireException("Error while calling updateQCStatus WS. " + ex.getMessage());
        }

    }

    private void updateMOImage(DataSet dsalldata, String qcstatus, PropertyList props) throws SapphireException {

        String smplid = props.getProperty("sampleid", "");
        String stmid = props.getProperty("stmid", "");

        if (!Util.isNull(qcstatus)) {
            DataSet dsMoImageId = null;

            String sqldata = "";
            if (!Util.isNull(stmid)) {
                sqldata = Util.parseMessage(MultiomyxSql.GET_MOIMAGEID_BY_SAMPLETESTCODEMAPID, dsalldata.getColumnValues("id#imgtype", "','"));
                dsMoImageId = getQueryProcessor().getSqlDataSet(sqldata);
            } else {
                sqldata = Util.parseMessage(MultiomyxSql.GET_MOIMAGEID_BY_SAMPLEIMGTYPECOMB, dsalldata.getColumnValues("id#imgtype", "','"));
                dsMoImageId = getQueryProcessor().getSqlDataSet(sqldata);
            }
            if (dsMoImageId == null) {
                throw new SapphireException("Unable to execute below query. Please Contact Administrator.\n" + sqldata);
            }

            if (dsMoImageId.size() > 0) {
                PropertyList pl = new PropertyList();
                if ("pass".equalsIgnoreCase(qcstatus)) {
                    pl.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
                    pl.setProperty(EditSDI.PROPERTY_KEYID1, dsMoImageId.getColumnValues("u_moimageid", ";"));
                    pl.setProperty("qcby", getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId());
                    pl.setProperty("qcdt", "n");
                    pl.setProperty("qcstatus", "QCPass");
                    pl.setProperty("qccomment", "QC Pass");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                } else if ("fail".equalsIgnoreCase(qcstatus) || "reimage".equalsIgnoreCase(qcstatus)) {
                    pl.clear();
                    pl.setProperty(DeleteSDI.PROPERTY_SDCID, "MOImage");
                    pl.setProperty(DeleteSDI.PROPERTY_KEYID1, dsMoImageId.getColumnValues("u_moimageid", ";"));
                    getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, pl);
                }
//                else if("reimage".equalsIgnoreCase(qcstatus)) {
//                    pl.setProperty("qcstatus", "QCReImage");
//                    pl.setProperty("qccomment", "QC Re-Image");
//                }

            }


        }

    }

    /**************************************
     *  Updating step after QC failure of sample
     * @param qcFailedSampleDS
     * @param auditreason
     * @throws SapphireException
     **************************************/
    private void updateStepStatus(DataSet qcFailedSampleDS, String auditreason) throws SapphireException {
        // need to implement
        String qcFailedSampleData = qcFailedSampleDS.getColumnValues("s_sampleid", ";");
        if (!Util.isNull(qcFailedSampleData)) {
            String sql = Util.parseMessage(MultiomyxSql.GET_CMPLETED_STEPS_BY_SAMPLEID, StringUtil.replaceAll(qcFailedSampleData, ";", "','"));
            DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
            if (dsSql == null || dsSql.isEmpty())
                throw new SapphireException("Error: Unable to fetch Panel Step Details.");
            String samplepanelstpmapid = EMPTY_STRING;
            if (dsSql.getRowCount() > 0) {
                dsSql.sort("s_sampleid");
                ArrayList<DataSet> dsFinalArr = dsSql.getGroupedDataSets("s_sampleid");
                if (dsFinalArr != null && dsFinalArr.size() > 0) {
                    for (DataSet dsFinal : dsFinalArr) {
                        DataSet tempDs = dsFinal; // s_sampleid wise
                        if (tempDs != null && tempDs.getRowCount() > 0) {
                            tempDs.sort("stepno");
                            samplepanelstpmapid += ";" + tempDs.getValue((tempDs.size() - 1), "u_samplepanelstpmapid");
                        }
                    }
                }
            }
            if (samplepanelstpmapid.startsWith(";")) {
                samplepanelstpmapid = samplepanelstpmapid.substring(1);
            }
            if (!Util.isNull(samplepanelstpmapid)) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "SamplePanelStpMap");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, samplepanelstpmapid);
                updateProp.setProperty("status", "Pending");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);
            }

            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, SDC_NAME_SAMPLE);
            pl.setProperty(EditSDI.PROPERTY_KEYID1, qcFailedSampleDS.getColumnValues("s_sampleid", ";"));
            pl.setProperty(CONSTANT_CURRENTMOVEMENTSTEP, "MOSlideList");
            pl.setProperty(EditSDI.PROPERTY_AUDITREASON, auditreason);
            pl.setProperty("u_mostatus", qcFailedSampleDS.getColumnValues("newstatus", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            pl.clear();
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, SDC_NAME_SAMPLE);
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, qcFailedSampleDS.getColumnValues("s_sampleid", ";"));
            pl.setProperty(CONSTANT_CURRTRAMSTOP, "MOSlideList");
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }
    }

    private void routeSampleFromPathologyToMO(String sampleid) throws SapphireException {
        if (!Util.isNull(sampleid)) {
            if (sampleid.startsWith(";"))
                sampleid = sampleid.substring(1);
            String sql = Util.parseMessage(MultiomyxSql.SAMPLE_IN_PATHOLOGY, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);

            if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
                sampleid = dsSampleInfo.getColumnValues("s_sampleid", ";");

                if (!Util.isNull(sampleid)) {
                    sql = Util.parseMessage(MultiomyxSql.MO_TRACKITEMID_FROM_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
                    DataSet dsTIInfo = getQueryProcessor().getSqlDataSet(sql);
                    DataSet result = new DataSet();
                    if (dsTIInfo != null && dsTIInfo.size() > 0) {
                        dsTIInfo.addColumn("destdept", DataSet.STRING);
                        for (int i = 0; i < dsTIInfo.size(); i++) {
                            String tempDept = dsTIInfo.getValue(i, "custodialdepartmentid", "");
                            if (!Util.isNull(tempDept)) {
                                String site = StringUtil.split(tempDept, "-")[0];
                                if (!Util.isNull(site)) {
                                    String destDept = site + "-" + "MOWetLab";
                                    dsTIInfo.setValue(i, "destdept", destDept);
                                    result.copyRow(dsTIInfo, i, 1);
                                }
                            }
                        }
                    }

                    if (result != null && result.size() > 0) {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, result.getColumnValues("linkkeyid1", ";"));
                        pl.setProperty("u_currentmovementstep", "MOImageROI");

                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

                        pl.clear();
                        pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_SDCID, "Sample");
                        pl.setProperty(sapphire.action.EditTrackItem.PROPERTY_KEYID1, result.getColumnValues("linkkeyid1", ";"));
                        pl.setProperty("custodialdepartmentid", result.getColumnValues("destdept", ";"));
                        pl.setProperty("custodialuserid", StringUtil.repeat("(null)", result.size(), ";"));
                        pl.setProperty("currentstorageunitid", StringUtil.repeat("(null)", result.size(), ";"));
                        pl.setProperty("u_currenttramstop", StringUtil.repeat("MOImageROI", result.size(), ";"));

                        getActionProcessor().processAction(sapphire.action.EditTrackItem.ID, sapphire.action.EditTrackItem.VERSIONID, pl);

                    }
                }
            }
        }
    }

}
