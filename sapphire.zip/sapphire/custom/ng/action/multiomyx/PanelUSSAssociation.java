package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.sql.multiomyx.MultiomyxSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

import static sapphire.custom.ng.util.Util.isNull;

/**
 * Created by aritra.banerjee on 8/28/2017.
 */
public class PanelUSSAssociation extends BaseAction {

	public void processAction(PropertyList properties) throws SapphireException {

		String sampleids = properties.getProperty("sampleid");
		String tcodes = properties.getProperty("tcodes");
		String panelname = properties.getProperty("panelname");
		String flag = properties.getProperty("flag");
		String stmid = properties.getProperty("stmid");

		if (isNull(sampleids))
			throw new SapphireException("Error: No Samples found to associate with selected Test codes");

		if (isNull(tcodes)) {
			throw new SapphireException("Error: No Test code found to associate with selected Unstained slide(s)");
		}

		if (validatePanel(panelname)) {
			if ("Y".equalsIgnoreCase(flag)) {
				sampleids = Util.getUniqueList(sampleids, ";", true);
				cancelDummyPanel(sampleids);
				addTestCodeToUSS(sampleids, tcodes, panelname, stmid);
				updateBatchidSeq(sampleids, tcodes);
				// updateMOProjPanelMap(sampleids, panelname);
			} else {
				addTestCodeToUSS(sampleids, tcodes, panelname, stmid);
			}
		} else {
			throw new SapphireException("MO Panel is not QC pass so can't apply to sample)");
		}
	}

	/**
	 * This method validate that
	 */

	private boolean validatePanel(String panelname) {
		String sql = Util.parseMessage(MultiomyxSql.CHECK_MOPANEL_QCPASS, StringUtil.replaceAll(panelname, ";", "','"));
		DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);
		String unkTest = Util.getUniqueList(panelname, ";", true);
		if (dsFinal.getRowCount() > 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method updates Sequence by batch id in SampleTestCodeMap
	 * 
	 * @param sampleids
	 * @param tcodes
	 * @throws SapphireException
	 */

	private void updateBatchidSeq(String sampleids, String tcodes) throws SapphireException {

		String sql = Util.parseMessage(MultiomyxSql.GET_SEQUENCE_BY_SAMPLEID, StringUtil.replaceAll(tcodes, ";", "','"),
				StringUtil.replaceAll(sampleids, ";", "','"));
		DataSet dsFinal = getQueryProcessor().getSqlDataSet(sql);

		if (dsFinal == null)
			throw new SapphireException("Error: Unable to fetch Sample Test Code map ID.");

		if (dsFinal.size() > 0) {
			if (!Util.isNull(dsFinal.getColumnValues("u_sampletestcodemapid", ";"))) {
				try {
					PropertyList pl = new PropertyList();
					pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
					pl.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("u_sampletestcodemapid", ";"));
					/* Batchseq changed with round */
					pl.setProperty("batchseq", dsFinal.getColumnValues("round", ";"));
					/* Batchseq changed with round */

					getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

				} catch (ActionException ae) {
					throw new SapphireException(
							"Error: Unable to Edit batchid Sequence into SampleTestCodeMap. Reason: "
									+ ae.getMessage());
				}
			}

		}

	}

	/**
	 * This method add test code to selected samples in SampleTestCodeMap
	 *
	 * @param sampleids
	 * @param tcodes
	 * @param panelname
	 * @param inputstmid
	 * @throws SapphireException
	 */

	private void addTestCodeToUSS(String sampleids, String tcodes, String panelname, String inputstmid)
			throws SapphireException {

		String stmid = "";
		DataSet dsFinal = new DataSet();
		dsFinal.addColumn("sid", DataSet.STRING);
		dsFinal.addColumn("tcode", DataSet.STRING);
		dsFinal.addColumn("pnlid", DataSet.STRING);
		dsFinal.addColumn("sidpnlidcomb", DataSet.STRING);

		String[] sampleidsArr = StringUtil.split(sampleids, ";");
		String[] tcodesArr = StringUtil.split(tcodes, ";");
		String[] panelnameArr = StringUtil.split(panelname, ";");

		for (int i = 0; i < sampleidsArr.length; i++) {
			for (int j = 0; j < tcodesArr.length; j++) {
				int rowId = dsFinal.addRow();
				dsFinal.setValue(rowId, "sid", sampleidsArr[i]);
				dsFinal.setValue(rowId, "tcode", tcodesArr[j]);
				if (!isNull(panelnameArr[j]))
					dsFinal.setValue(rowId, "pnlid", panelnameArr[j]);
				dsFinal.setValue(rowId, "sidpnlidcomb", sampleidsArr[i] + "@*@" + panelnameArr[j]);
			}
		}

		if (dsFinal.size() > 0) {
			PropertyList props = new PropertyList();
			props.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, dsFinal.getColumnValues("sid", ";"));
			props.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, dsFinal.getColumnValues("tcode", ";"));

			// getActionProcessor().processAction(AssignTestCode.ID,
			// AssignTestCode.VERSION_ID, props);
			// stmid = props.getProperty("sampletestcodemapid");

			String sql = Util.parseMessage(MultiomyxSql.SAMPLETESTCODEMAPID_BY_SAMPLEPANELCOMB,
					dsFinal.getColumnValues("sidpnlidcomb", "','"));
			DataSet dsSTMInfo = getQueryProcessor().getSqlDataSet(sql);
			if (dsSTMInfo == null)
				throw new SapphireException("Below query cannot be executed by database server.\n" + sql);
			if (dsSTMInfo.size() > 0)
				updateRoundInfoOfSTM(dsSTMInfo.getColumnValues("u_sampletestcodemapid", ";"), dsFinal);
		}

	}

	private void updateRoundInfoOfSTM(String stmid, DataSet dsFinal) throws SapphireException {

		String sql = Util.parseMessage(MultiomyxSql.STM_INFO_STMID, StringUtil.replaceAll(stmid, ";", "','"));
		DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);
		if (dsSql == null)
			throw new SapphireException("Error: Unable to fetch information of Unstained slide(s)");

		/* For adding round */
		dsSql.addColumn("tc_round", DataSet.STRING);
		String uniquePanelIds = Util.getUniqueList(dsFinal.getColumnValues("pnlid", ";"), ";", true);
		DataSet dsRoundData = null;
		if (!isNull(uniquePanelIds)) {
			String roundSql = Util.parseMessage(MultiomyxSql.TESTCODE_INFO_BY_PANELID,
					StringUtil.replaceAll(uniquePanelIds, ";", "','"));
			if (isNull(roundSql)) {
				throw new SapphireException("Problem in executing following query :: \n" + roundSql);
			}
			dsRoundData = getQueryProcessor().getSqlDataSet(roundSql);
		}
		/* For adding round */
		if (dsSql.size() > 0) {
			for (int i = 0; i < dsSql.size(); i++) {
				HashMap hm = new HashMap();
				hm.put("sid", dsSql.getValue(i, "s_sampleid"));
				hm.put("tcode", dsSql.getValue(i, "lvtestcodeid"));

				DataSet dsFilter = dsFinal.getFilteredDataSet(hm);

				if (dsFilter != null && dsFilter.size() > 0) {
					dsSql.setValue(i, "lvtestpanelid", dsFilter.getValue(0, "pnlid"));

					/* For adding round */
					HashMap<String, Object> roundHM = new HashMap<>();
					roundHM.put("testcodeid", dsSql.getValue(i, "lvtestcodeid"));
					roundHM.put("panelid", dsFilter.getValue(0, "pnlid"));
					DataSet roundFilterDS = dsRoundData.getFilteredDataSet(hm);
					if (roundFilterDS != null && roundFilterDS.getRowCount() > 0) {
						dsSql.setValue(i, "tc_round", roundFilterDS.getValue(0, "round"));
					}
					/* For adding round */
				}

			}
		}

		/*
		 * if (!Util.isNull(dsSql.getColumnValues("u_sampletestcodemapid",
		 * ";"))) {
		 * 
		 * PropertyList updateProp = new PropertyList();
		 * updateProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
		 * updateProp.setProperty(EditSDI.PROPERTY_KEYID1,
		 * dsSql.getColumnValues("u_sampletestcodemapid", ";"));
		 * updateProp.setProperty("round", dsSql.getColumnValues("tc_round",
		 * ";"));
		 * 
		 * getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID,
		 * updateProp); }
		 */

		updateTrancData(dsSql);
	}

	private void updateTrancData(DataSet dsData) throws SapphireException {

		DataSet dsResult = new DataSet();
		dsResult.addColumn("sampleid", DataSet.STRING);
		dsResult.addColumn("panelid", DataSet.STRING);
		dsResult.addColumn("stepname", DataSet.STRING);
		dsResult.addColumn("stepno", DataSet.STRING);
		dsResult.addColumn("status", DataSet.STRING);

		String uniquePanelid = Util.getUniqueList(dsData.getColumnValues("lvtestpanelid", ";"), ";", true);
		String sql = Util.parseMessage(MultiomyxSql.GET_TCODE_BY_PANELID,
				StringUtil.replaceAll(uniquePanelid, ";", "','"));
		DataSet dsPanelwiseTcode = getQueryProcessor().getSqlDataSet(sql);
		DataSet dsAllPanelTcodeSteps = null;

		if (dsPanelwiseTcode != null && dsPanelwiseTcode.size() > 0) {
			String allTcodes = dsPanelwiseTcode.getColumnValues("indtestcodeid", ";");
			String allPanelTcodeSteps = uniquePanelid + ";" + allTcodes;
			sql = Util.parseMessage(MultiomyxSql.GET_STEPS_BY_TCODEID,
					StringUtil.replaceAll(allPanelTcodeSteps, ";", "','"));
			dsAllPanelTcodeSteps = getQueryProcessor().getSqlDataSet(sql);
		}
		if (dsPanelwiseTcode == null)
			throw new SapphireException("Error: Unable to fetch Panel-Test_code Details.");

		if (dsAllPanelTcodeSteps == null)
			throw new SapphireException("Error: Unable to fetch Step Details.");

		for (int i = 0; i < dsData.size(); i++) {
			String sampleid = dsData.getValue(i, "s_sampleid");
			String pnlid = dsData.getValue(i, "lvtestpanelid");

			HashMap hm = new HashMap();
			hm.put("sampleid", sampleid);
			hm.put("panelid", pnlid);

			DataSet dsFilter = dsResult.getFilteredDataSet(hm);

			if (dsFilter.size() == 0) {
				hm.clear();
				hm.put("u_testcodeid", pnlid);
				DataSet dsFilterStep = dsAllPanelTcodeSteps.getFilteredDataSet(hm);
				if (dsFilterStep.size() > 0) { // panel has steps defined

					for (int j = 0; j < dsFilterStep.size(); j++) {
						int rowId = dsResult.addRow();
						dsResult.setValue(rowId, "sampleid", sampleid);
						dsResult.setValue(rowId, "panelid", pnlid);
						dsResult.setValue(rowId, "stepname", dsFilterStep.getValue(j, "stepname"));
						dsResult.setValue(rowId, "stepno", dsFilterStep.getValue(j, "stepno"));
						dsResult.setValue(rowId, "status", "Pending");
					}
				} else { // panel doesnt have steps defined, hence tcode steps
							// needs to be considered
					hm.clear();
					hm.put("u_testcodeid", pnlid);
					DataSet dsfilterTcode = dsPanelwiseTcode.getFilteredDataSet(hm);
					if (dsfilterTcode.size() == 0)
						throw new SapphireException("Error: No Test code details found for Panel -" + pnlid);

					if (dsfilterTcode.size() > 0) {
						for (int j = 0; j < dsfilterTcode.size(); j++) {
							hm.clear();
							hm.put("u_testcodeid", dsfilterTcode.getValue(j, "indtestcodeid"));
							DataSet dsFilterTcodeStep = dsAllPanelTcodeSteps.getFilteredDataSet(hm);
							if (dsFilterTcodeStep.size() > 0) { // current tcode
																// has steps
																// defined
								for (int k = 0; k < dsFilterTcodeStep.size(); k++) {
									int rowId = dsResult.addRow();
									dsResult.setValue(rowId, "sampleid", sampleid);
									dsResult.setValue(rowId, "panelid", pnlid);
									dsResult.setValue(rowId, "stepname", dsFilterTcodeStep.getValue(k, "stepname"));
									dsResult.setValue(rowId, "stepno", dsFilterTcodeStep.getValue(k, "stepno"));
									dsResult.setValue(rowId, "status", "Pending");
								}
							}
							break;
						}
					}
				}

			}
		}

		if (dsResult.size() > 0) {
			try {
				PropertyList pl = new PropertyList();
				pl.setProperty(AddSDI.PROPERTY_SDCID, "SamplePanelStpMap");
				pl.setProperty(AddSDI.PROPERTY_COPIES, "" + dsResult.size());
				pl.setProperty("s_sampleid", dsResult.getColumnValues("sampleid", ";"));
				pl.setProperty("lvpanelid", dsResult.getColumnValues("panelid", ";"));
				pl.setProperty("stepname", dsResult.getColumnValues("stepname", ";"));
				pl.setProperty("stepno", dsResult.getColumnValues("stepno", ";"));
				pl.setProperty("status", dsResult.getColumnValues("status", ";"));

				getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

			} catch (Exception ex) {
				throw new SapphireException("Error: Unable to add data into SamplePanelStpMap.");
			}
		}

	}

	private void cancelDummyPanel(String sampleids) throws SapphireException {

		String uniqueSampleid = Util.getUniqueList(sampleids, ";", true);
		String sql = Util.parseMessage(MultiomyxSql.GET_STMID_BY_SAMPLEID,
				StringUtil.replaceAll(uniqueSampleid, ";", "','"));
		DataSet dsSTMid = getQueryProcessor().getSqlDataSet(sql);

		if (dsSTMid == null)
			throw new SapphireException("Error: Unable to fetch Sample Test Code map ID.");

		if (!Util.isNull(dsSTMid.getColumnValues("u_sampletestcodemapid", ";"))) {
			try {
				PropertyList updateProp = new PropertyList();
				updateProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
				updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsSTMid.getColumnValues("u_sampletestcodemapid", ";"));
				updateProp.setProperty("teststatus", "Cancelled");
				// updateProp.setProperty("isdummy", "Y");

				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

			} catch (Exception ex) {
				throw new SapphireException("Error: Unable to edit teststatus in SampleTestCodeMap.");
			}
		}

	}

	private void updateMOProjPanelMap(String sampleids, String panelname) throws SapphireException {

		DataSet dsMap = new DataSet();
		dsMap.addColumn("projectid", DataSet.STRING);
		dsMap.addColumn("panelid", DataSet.STRING);
		dsMap.addColumn("projectid#panelid", DataSet.STRING);

		String uniqueSampleid = Util.getUniqueList(sampleids, ";", true);
		String uniquePanelid = Util.getUniqueList(panelname, ";", true);

		String sql = Util.parseMessage(MultiomyxSql.GET_PROJID_BY_SAMPLEID,
				StringUtil.replaceAll(uniqueSampleid, ";", "','"));
		DataSet dsProjid = getQueryProcessor().getSqlDataSet(sql);
		if (dsProjid == null)
			throw new SapphireException("Error: Unable to fetch Sample Project ID.");

		if (dsProjid.size() > 0) {
			String uniqueProjid = Util.getUniqueList(dsProjid.getColumnValues("bioprojectname", ";"), ";", true);

			String[] uniqueProjidArr = StringUtil.split(uniqueProjid, ";");
			String[] uniquePanelidArr = StringUtil.split(uniquePanelid, ";");

			for (String proj : uniqueProjidArr) {
				for (String pnl : uniquePanelidArr) {
					int rowId = dsMap.addRow();
					dsMap.setValue(rowId, "projectid", proj);
					dsMap.setValue(rowId, "panelid", pnl);
					dsMap.setValue(rowId, "projectid#panelid", proj + "#" + pnl);
				}
			}

			if (!Util.isNull(dsMap.getColumnValues("projectid#panelid", ";"))) {
				sql = Util.parseMessage(MultiomyxSql.GET_VALID_PROJPANEL_ENTRY,
						StringUtil.replaceAll(dsMap.getColumnValues("projectid#panelid", ";"), ";", "','"));
				DataSet dsValidProjPnlMap = getQueryProcessor().getSqlDataSet(sql);

				if (dsValidProjPnlMap == null)
					throw new SapphireException(
							"Error: Unable to fetch valid Project Panel entry from MOProjectPanelMap.");

				if (dsMap.size() > 0) {
					dsMap.addColumn("addflag", DataSet.STRING);
					for (int i = 0; i < dsMap.size(); i++) {
						String mapElement = dsMap.getValue(i, "projectid#panelid");
						HashMap<String, String> hm = new HashMap<>();
						hm.put("projpnl", mapElement);

						DataSet dsFilter = dsValidProjPnlMap.getFilteredDataSet(hm);

						if (dsFilter.size() == 0) {
							dsMap.setValue(i, "addflag", "Y");
						}
					}

				}
			}
		} else {
			throw new SapphireException("Error: Project Id for the selected Sample not found.");
		}
		HashMap<String, String> hm = new HashMap<>();
		hm.put("addflag", "Y");
		DataSet dsFinal = dsMap.getFilteredDataSet(hm);
		if (dsFinal.size() > 0) {
			try {
				PropertyList pl = new PropertyList();
				pl.setProperty(AddSDI.PROPERTY_SDCID, "MOProjectPanelMap");
				pl.setProperty(AddSDI.PROPERTY_COPIES, "" + dsFinal.size());
				pl.setProperty("projectid", dsFinal.getColumnValues("projectid", ";"));
				pl.setProperty("panelid", dsFinal.getColumnValues("panelid", ";"));

				getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

			} catch (Exception ex) {
				throw new SapphireException("Error: Unable to Add into MOProjectPanelMap.");
			}
		}

	}

}
