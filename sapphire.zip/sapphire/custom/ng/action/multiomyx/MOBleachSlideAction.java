/**
 * 
 */
package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class MOBleachSlideAction extends BaseAction{
	/* (non-Javadoc)
	 * @see sapphire.action.BaseAction#processAction(sapphire.xml.PropertyList)
	 */
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		try {
			if(properties.isEmpty()){
				throw new SapphireException("No properties found.");
			}else{
				String sampleId = properties.getProperty("sampleId");
				String previousStatus = properties.getProperty("previousStatus");
				String currentStatus = properties.getProperty("currentStatus");
				String opertationName = properties.getProperty("operationName");
				//MOBleachStainSlide
				PropertyList bleachProps = new PropertyList();
				bleachProps.setProperty("sampleid", sampleId);
				bleachProps.setProperty("previousstatus", previousStatus);
				bleachProps.setProperty("currentstatus", currentStatus);
				getActionProcessor().processAction("MOBleachStainSlide", "1", bleachProps);
				//MOLWSAction
				PropertyList molwsProps = new  PropertyList();
				molwsProps.setProperty("operationName", opertationName);
				molwsProps.setProperty("slideid", sampleId);
				getActionProcessor().processAction("MOLWSAction", "1", molwsProps);
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new SapphireException(e.getMessage());
		}
	}
}
