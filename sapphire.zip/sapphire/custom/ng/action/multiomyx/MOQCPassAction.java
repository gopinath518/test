package sapphire.custom.ng.action.multiomyx;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class MOQCPassAction extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        // properties of FlowCompleteStep action.
        String moimageid = properties.getProperty("moimgid");
        String flag = properties.getProperty("flag");
        //properties of BatchApprovalAssociation action.
        String batchid = properties.getProperty("batchid");
        // properties of EDISDI
        String status = properties.getProperty("status");
        String bioqcby = properties.getProperty("bioqcby");
        String bioqcdt = properties.getProperty("bioqcdt");
        String bioqccomment = properties.getProperty("bioqccomment");
        try {

            //FlowCompleteStep
            PropertyList fcsProps = new PropertyList();
            fcsProps.setProperty("moimgid", moimageid);
            fcsProps.setProperty("flag", flag);
            getActionProcessor().processAction("FlowCompleteStep", "1", fcsProps);
            //EditSdi
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "MOImage");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, moimageid);
            prop.setProperty("status", status);
            prop.setProperty("bioqcby", bioqcby);
            prop.setProperty("bioqcdt", bioqcdt);
            prop.setProperty("bioqccomment", bioqccomment);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            //BatchApprovalAssociation
            PropertyList baaProps = new PropertyList();
            baaProps.setProperty("batchid",batchid);
            getActionProcessor().processAction("BatchApprovalAssociation", "1", baaProps);
        }
        catch (Exception e) {
            // TODO: handle exception
            throw new SapphireException(e.getMessage());
        }


    }
}
