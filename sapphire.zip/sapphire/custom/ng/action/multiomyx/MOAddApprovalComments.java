package sapphire.custom.ng.action.multiomyx;

import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

public class MOAddApprovalComments extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String moRegMarkerSelId = properties.getProperty("moregmarkerselid", "");
		String approvalComments = properties.getProperty("approvalcomments", "");
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "MORegMarkerSelAudit");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, moRegMarkerSelId);
		pl.setProperty("approvalcomments", approvalComments);
		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSION, pl);
	}
}
