package sapphire.custom.ng.action;

import java.io.File;

import com.labvantage.sapphire.actions.sdi.DeleteSDIAttachment;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

/**
 * This is used for add to todo list entry.This will be used for delete temp xlsx
 * @author debasis.mondal
 *
 */
public class InventoryReportingTempDeleteAction extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String id = properties.getProperty("id", "");
		String filename = properties.getProperty("filename", "");
		String location = properties.getProperty("location", "");
		//1...............delete from a location
		try{
    		File file = new File(location);
    		if(file.delete()){
    			logger.info(file.getName() + " is deleted!");
    		}else{
    			logger.info("Delete operation is failed.");
    		}
    	}catch(Exception e){
             throw new SapphireException(ErrorDetail.TYPE_FAILURE, e.getMessage());
    	}
		//2.............delete from SDC
		PropertyList attachprop = new PropertyList();
		attachprop.clear();
		attachprop.setProperty(DeleteSDIAttachment.PROPERTY_SDCID, "Dummy");
		attachprop.setProperty(DeleteSDIAttachment.PROPERTY_KEYID1, id);

		try {
			getActionProcessor().processAction(DeleteSDIAttachment.ID, DeleteSDIAttachment.VERSIONID, attachprop);
		} catch (SapphireException ex) {
				logger.info(ex.getMessage());
	            throw new SapphireException(ErrorDetail.TYPE_FAILURE, ex.getMessage());
		}
    }
}
