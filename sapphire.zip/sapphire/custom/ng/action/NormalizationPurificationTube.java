package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdi.EditSDI;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by msubhra on 6/16/2016.
 */
public class NormalizationPurificationTube extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

    String sampleids = properties.getProperty("s_sampleid");
    String newsampleids = StringUtil.replaceAll(sampleids,";","','");
    String lvtestcode = properties.getProperty("lvtestcodeid");
    String currentuser = connectionInfo.getSysuserId();
    String custodialdepartmentid = connectionInfo.getDefaultDepartment();

    /**
     * createPurificationTube method is for create daughter tube from dilution tube, this method takes multiple
     * sampleids as input and create one daughter tube for each samples
     */
    String purificationtubeid = createPurificationTube(sampleids);
    properties.setProperty("newkeyid1", purificationtubeid);

    /**
     * updateTrackitem method is for update the created purification tubes in trackitem. This method takes
     * the newly created purification tube,the current user and the custodil department as input
     */

    String trackitem = updateTrackitem(purificationtubeid, currentuser, custodialdepartmentid);

    /**
     * addTestCodeOnPurificationTube method is for add test in the purification tube. This method takes the purification tubes and
     * the selected testcode id as input
     */

    addTestCodeOnPurificationTube(newsampleids,purificationtubeid,lvtestcode);
    String returnmessage = "Purification Tube" +purificationtubeid+" has been created successfully";
    properties.setProperty("msg",returnmessage);


}

    /**
     *
     * @param sampleids
     * @return
     * @throws SapphireException
     */

    private String createPurificationTube(String sampleids) throws SapphireException {

        if (sampleids.contains(";")) {
            String err = "Please select only one sample.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        String childextractionid = "";
        String newchildextractionid = "";
        DataSet dsextraction = new DataSet();
        DataSet childextraction = new DataSet();

        PropertyList prop = new PropertyList();
        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, sampleids);
        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "1");
        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");

        try {
            getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot Create Purification tube.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }


        String newkeyid = prop.getProperty("newkeyid1");
        String sql = "select  sm.destsampleid from trackitem t,s_samplemap sm,s_sample s\n" +
                "where s.s_sampleid = sm.sourcesampleid and sm.destsampleid = t.linkkeyid1 " +
                "and t.containertypeid = 'Purification Tube' and s.s_sampleid = '" + sampleids + "'";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds.size() == 0 || ds.getRowCount() == 0) {
            String extractionsql = "select u_extractionid||'-Q' as u_extractionid from s_sample where s_sampleid ='" + sampleids + "'";
            dsextraction = getQueryProcessor().getSqlDataSet(extractionsql);
            if (dsextraction.size() == 0 || dsextraction.getRowCount() == 0) {
                String err = "Extraction id not found for sample" + sampleids;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            } else {
                PropertyList p = new PropertyList();
                p.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                p.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid);
                p.setProperty("u_extractionid", dsextraction.getValue(0, "u_extractionid"));

                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p);
                } catch (SapphireException e) {
                    String errMsg = getTranslationProcessor().translate("Cannot Create Purification tube.");
                    errMsg += "\nError Detail:" + e.getMessage();
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                }

            }

        } else {
            String destsampleid = ds.getString(0, "destsampleid");
            String childextractionsql = "select u_extractionid as u_extractionid from s_sample where s_sampleid ='" + destsampleid + "'";
            childextraction = getQueryProcessor().getSqlDataSet(childextractionsql);
            if (childextraction.size() == 0 || childextraction.getRowCount() == 0) {
                String err = "Extraction id not found for sample" + sampleids;
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            } else {
                childextractionid = childextraction.getValue(0, "u_extractionid");
                if (childextractionid.endsWith("-Q")) {
                    newchildextractionid = childextractionid.replaceAll("-Q", "-Q2");
                    PropertyList p = new PropertyList();
                    p.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    p.setProperty(EditSDI.PROPERTY_KEYID1, newkeyid);
                    p.setProperty("u_extractionid", newchildextractionid);

                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, p);
                    } catch (SapphireException e) {
                        String errMsg = getTranslationProcessor().translate("Cannot Create Purification tube.");
                        errMsg += "\nError Detail:" + e.getMessage();
                        throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
                    }



                }

            }
        }

        return newkeyid;
    }

    /**
     *
     * @param aliquotid
     * @param currentuser
     * @param custodialdepartmentid
     * @return
     * @throws SapphireException
     */

    private String updateTrackitem(String aliquotid, String currentuser, String custodialdepartmentid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, aliquotid);
        props.setProperty("containertypeid", "Purification Tube");
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", custodialdepartmentid);
        props.setProperty("custodytakendt", "n");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for Purification Tube.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
        String msg = "Trackeitem Updated for sampleids" + aliquotid;
        return msg;
    }

    /**
     *
     * @param parentSample
     * @param aliquotid
     * @param testcodeid
     * @throws SapphireException
     */


    private void addTestCodeOnPurificationTube(String parentSample, String aliquotid,String testcodeid) throws SapphireException {
        String[] testcode = StringUtil.split(testcodeid,";");
        String ss_parentTest = "select distinct lvtestcodeid,testcode,testname,methodology,ispanel,los,concentrationratio from u_sampletestcodemap" +
                " where lvtestcodeid = '"+testcode[0]+"'";
        DataSet dsParentTest = getQueryProcessor().getSqlDataSet(ss_parentTest);
        String[] samparr = StringUtil.split(aliquotid, ";");

        if (dsParentTest == null) {
            String error = getTranslationProcessor().translate("Query failed");
            error += ss_parentTest;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsParentTest.size() == 0) {//todo
            String e=getTranslationProcessor().translate("No Test is assigned to the Parent");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,e);
        }
        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc
        dsSamplefinal.addColumn("concentrationratio",DataSet.STRING);


        for (String currentsamp : samparr) {
            for (int j = 0; j < dsParentTest.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dsParentTest.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dsParentTest.getValue(j, "ispanel", ""));
                dsSamplefinal.setValue(rowID,"concentrationratio",dsParentTest.getValue(j,"concentrationratio"));

            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        hsAddTestCode.setProperty("concentrationratio",dsSamplefinal.getColumnValues("concentrationratio",";"));
        hsAddTestCode.setProperty("bypassvalidation", "Y");
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }

    }
}
