package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.DecimalFormat;

/**
 * Created by akumar on 3/27/2017.
 */
public class CalculateVolumeLibrary extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String sql = "select s_sampleid,u_finalconillu,u_finalvolillu,u_startingcon,u_volumelibrary,u_rsbtodilute from s_sample where s_sampleid in('" + StringUtil.replaceAll(sampleid, ";", "','") + "') and u_volumelibrary is null";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);

        float volumelib,rsbtodilute;
        if (ds.size() > 0) {
            DecimalFormat df = new DecimalFormat("#.#");

            for (int i = 0; i < ds.size(); i++) {
                if (ds.getValue(i, "u_startingcon") != null && ds.getValue(i, "u_finalvolillu") != null && ds.getValue(i, "u_finalconillu") != null) {
                    if (!ds.getValue(i, "u_startingcon").equalsIgnoreCase("") && !ds.getValue(i, "u_finalvolillu").equalsIgnoreCase("")) {
                        if (!ds.getValue(i, "u_finalconillu").equalsIgnoreCase("")) {

                            float conc = Float.parseFloat(ds.getValue(i, "u_startingcon"));
                            float vol = Float.parseFloat(ds.getValue(i, "u_finalvolillu"));
                            float finalconc = Float.parseFloat(ds.getValue(i, "u_finalconillu"));
                            volumelib = Float.parseFloat(df.format((finalconc * vol) / conc));
                            rsbtodilute=vol-volumelib;
                            ds.setValue(i, "u_volumelibrary", String.valueOf(volumelib));
                            ds.setValue(i, "u_rsbtodilute", String.valueOf(rsbtodilute));
                        }
                    }
                }
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
            prop.setProperty("u_volumelibrary", ds.getColumnValues("u_volumelibrary", ";"));
            prop.setProperty("u_rsbtodilute", ds.getColumnValues("u_rsbtodilute", ";"));

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        }
    }
}


