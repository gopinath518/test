package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.AddPackage;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;


/**
 * Created by akumar on 10/6/2016.
 *
 * @desc :Creates a package id and put the scanned samples
 * inside that package and also captures the current user department
 * who has created the package.
 */


public class CreatePackage extends BaseAction {
    private static final String pageid="LV_NewPackageMaint";
    private static final String returntolistPage="LV_PackageList";
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleids", "");
        if (sampleids == null || sampleids.equalsIgnoreCase("")) {
            throw new SapphireException("Sample value is null");
        }
        String sample = StringUtil.replaceAll(sampleids, ";", "','");
        String sql = "select trackitemid from trackitem where linksdcid='Sample' and linkkeyid1 in ('" + sample + "')";
        DataSet logistic = getQueryProcessor().getSqlDataSet(sql);
        if (logistic == null || logistic.size() == 0) {
            throw new SapphireException("Trackitem for sample is not defined");
        }
        String trackitem = logistic.getColumnValues("trackitemid", ";");
        String department = connectionInfo.getDefaultDepartment();


        PropertyList prop = new PropertyList();
        prop.setProperty(AddPackage.PROPERTY_PACKAGETYPE, "PKG");
        prop.setProperty(AddPackage.PROPERTY_TRACKITEMID, trackitem);
        prop.setProperty("senderdepartmentid", department);
        try {
            getActionProcessor().processAction(AddPackage.ID, AddPackage.VERSIONID, prop);

        } catch (SapphireException se) {
            String error = getTranslationProcessor().translate("Package not createdt");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        String packageid = prop.getProperty("newkeyid1");
        String url = "<script>sapphire.page.navigate('rc?command=page&page="+pageid+"&sdcid=&mode=Edit&keyid1=" + packageid + "&returntolistpage="+returntolistPage+"', 'Y', '_top')</script>";
        properties.setProperty("msg",url);

        PropertyList prsample = new PropertyList();
        prsample.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prsample.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
        prsample.setProperty("u_currentmovementstep", "InsidePackage");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prsample);
        } catch (Exception e) {
            String er = getTranslationProcessor().translate("Sample not updated successfully");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, er);
        }
    }
}

