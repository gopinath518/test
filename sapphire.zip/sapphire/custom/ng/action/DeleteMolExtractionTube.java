package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class DeleteMolExtractionTube extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("keyid1");
        String auditreason = properties.getProperty("auditreason");
        String sql = Util.parseMessage(MolecularSql.GET_EXTRACTION_TUBES_ONLY_BY_SAMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsExtractionTubes = getQueryProcessor().getSqlDataSet(sql);
        if (dsExtractionTubes.size() == 0) {
            throw new SapphireException("Onle extraction tube(s) can be deleted only.");
        }
        if (dsExtractionTubes.size() > 0) {
            sampleid = dsExtractionTubes.getColumnValues("s_sampleid", ";");
            sql = Util.parseMessage(ApSql.GET_TESTS_ONLY_BY_SPECIMENS, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsTestInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsTestInfo.size() > 0) {
                String maspids = dsTestInfo.getColumnValues("sampletestmapid", ";");
                deleteTestcode(maspids, auditreason);
            }
            deleteSpecimen(sampleid, auditreason);
            /*sql = Util.parseMessage(MolecularSql.GET_SAMPLE_BY_EXTRACTION, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsNormalSampleTestInfo = getQueryProcessor().getSqlDataSet(sql);
            if (dsNormalSampleTestInfo.size() > 0) {
                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsNormalSampleTestInfo.getColumnValues("u_sampletestcodemapid", ";"));
                props.setProperty("extractiontype", "(null)");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                } catch (Exception ex) {
                    throw new SapphireException("Unable to delete testcode(s).");
                }
            }*/
        }
    }

    private void deleteSpecimen(String keyid1, String evntreason) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty(DeleteSDI.PROPERTY_AUDITREASON, evntreason);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete testcode(s).");
            }
        }
    }

    private void deleteTestcode(String keyid1, String evntreason) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty(DeleteSDI.PROPERTY_AUDITREASON, evntreason);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete testcode(s).");
            }
        }
    }
}
