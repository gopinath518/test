package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

public class AssignTestcodeOnSlides extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {

        String inputsampleids = properties.getProperty("sampleids");
        String sqls = Util.parseMessage(ApSql.GET_ADDIGN_TESTS, StringUtil.replaceAll(inputsampleids, ";", "','"));
        DataSet dsPanelFilter = getQueryProcessor().getSqlDataSet(sqls);
        HashMap hm = new HashMap();

        //CREATE MAIN DATASET
        DataSet dsMain = new DataSet();
        dsMain.addColumn("s_sampleid", DataSet.STRING);
        dsMain.addColumn("lvtestcodeid", DataSet.STRING);
        dsMain.addColumn("lvpanelid", DataSet.STRING);
        dsMain.addColumn("testname", DataSet.STRING);
        dsMain.addColumn("u_clientspecimenid", DataSet.STRING);
        dsMain.addColumn("u_accessionid", DataSet.STRING);
        dsMain.addColumn("hneflag", DataSet.STRING);
        //dsMain.addColumn("specimentype", DataSet.STRING);

        dsPanelFilter.sort("s_sampleid,lvtestpanelid");
        ArrayList<DataSet> dsReceipeDtlDbInfoArr = dsPanelFilter.getGroupedDataSets("s_sampleid,lvtestpanelid");
        for (int j = 0; j < dsReceipeDtlDbInfoArr.size(); j++) {
            DataSet dsEach = (DataSet) dsReceipeDtlDbInfoArr.get(j);
            if (dsReceipeDtlDbInfoArr.size() != dsEach.size()) {
                throw new SapphireException("Test(s) and Slide(s) counts does not match. No of Test(s) available in this panel is: " + dsEach.size() + "\n" + "Testcode(s) is/are "
                        + dsEach.getColumnValues("lvtestcodeid", ", "));
            }
            String clientspecid = dsEach.getValue(0, "u_clientspecimenid", "");
            if (Util.isNull(clientspecid))
                throw new SapphireException("Slide(s) must have client specimen id.");

            int rowid = dsMain.addRow();
            dsMain.setValue(rowid, "s_sampleid", dsEach.getValue(0, "s_sampleid", ""));
            dsMain.setValue(rowid, "u_clientspecimenid", dsEach.getValue(0, "u_clientspecimenid", ""));
            dsMain.setValue(rowid, "lvpanelid", dsEach.getValue(0, "lvtestpanelid", ""));
            dsMain.setValue(rowid, "u_accessionid", dsEach.getValue(0, "u_accessionid", ""));
        }
        if (dsMain != null && dsMain.size() > 0) {
            dsPanelFilter.sort("u_clientspecimenid");
            ArrayList<DataSet> dsClispec = dsPanelFilter.getGroupedDataSets("u_clientspecimenid");
            if (dsClispec.size() > 1) {
                throw new SapphireException("Slide(s) must have same client specimen id.");
            }
            String lvpanels = Util.getUniqueList(dsMain.getColumnValues("lvpanelid", ";"), ";", true);
            String sql = Util.parseMessage(ApSql.GET_PANEL_TESTS, StringUtil.replaceAll(lvpanels, ";", "','"));
            DataSet dsIndTests = getQueryProcessor().getSqlDataSet(sql);
            if (dsIndTests.size() == 0)
                throw new SapphireException("No Test(s) found into the Panel.");
            for (int i = 0; i < dsIndTests.size(); i++) {
                dsMain.setValue(i, "lvtestcodeid", dsIndTests.getValue(i, "testcodeid"));
                dsMain.setValue(i, "testname", dsIndTests.getValue(i, "testname"));
                dsMain.setValue(i, "hneflag", dsIndTests.getValue(i, "hneflag"));
                //dsMain.setValue(i, "specimentype", dsIndTests.getValue(i, "specimentype"));
            }
        }
        if (dsMain.size() > 0) {
            DataSet dsDelete = new DataSet();
            dsDelete.addColumn("sampleid", DataSet.STRING);
            dsDelete.addColumn("workitemid", DataSet.STRING);
            dsDelete.addColumn("mapid", DataSet.STRING);
            dsDelete.addColumn("testcodeid", DataSet.STRING);
            dsDelete.addColumn("testname", DataSet.STRING);
            dsDelete.addColumn("specimentype", DataSet.STRING);
            dsDelete.addColumn("u_clientspecimenid", DataSet.STRING);
            dsDelete.addColumn("lvtestpanelid", DataSet.STRING);
            dsDelete.addColumn("u_accessionid", DataSet.STRING);

            DataSet dsApplyWorkItem = new DataSet();
            dsApplyWorkItem.addColumn("sampleid", DataSet.STRING);
            dsApplyWorkItem.addColumn("workitemid", DataSet.STRING);
            dsApplyWorkItem.addColumn("mapid", DataSet.STRING);
            dsApplyWorkItem.addColumn("testcodeid", DataSet.STRING);
            dsApplyWorkItem.addColumn("testname", DataSet.STRING);
            dsApplyWorkItem.addColumn("specimentype", DataSet.STRING);
            dsApplyWorkItem.addColumn("u_clientspecimenid", DataSet.STRING);
            dsApplyWorkItem.addColumn("lvtestpanelid", DataSet.STRING);
            dsApplyWorkItem.addColumn("u_accessionid", DataSet.STRING);

            String sampleids = StringUtil.replaceAll(dsMain.getColumnValues("s_sampleid", ";"), ";", "','");
            String sql = Util.parseMessage(ApSql.GET_ADDIGN_TESTS, sampleids);
            DataSet dsAssignTests = getQueryProcessor().getSqlDataSet(sql);
            if (dsAssignTests.size() > 0) {
                for (int i = 0; i < dsAssignTests.size(); i++) {
                    hm.clear();
                    hm.put("s_sampleid", dsAssignTests.getValue(i, "s_sampleid"));
                    hm.put("lvtestcodeid", dsAssignTests.getValue(i, "lvtestcodeid"));
                    DataSet dsTestFilter = dsMain.getFilteredDataSet(hm);
                    if (dsTestFilter.size() == 0) {
                        int rowID = dsDelete.addRow();
                        dsDelete.setValue(rowID, "sampleid", dsAssignTests.getValue(i, "s_sampleid"));
                        dsDelete.setValue(rowID, "workitemid", dsAssignTests.getValue(i, "testname"));
                        dsDelete.setValue(rowID, "testname", dsAssignTests.getValue(i, "testname"));
                        dsDelete.setValue(rowID, "mapid", dsAssignTests.getValue(i, "u_sampletestcodemapid"));
                        dsDelete.setValue(rowID, "testcodeid", dsAssignTests.getValue(i, "lvtestcodeid"));
                        dsDelete.setValue(rowID, "specimentype", dsAssignTests.getValue(i, "specimentype"));
                        dsDelete.setValue(rowID, "u_clientspecimenid", dsAssignTests.getValue(i, "u_clientspecimenid"));
                        dsDelete.setValue(rowID, "lvtestpanelid", dsAssignTests.getValue(i, "lvpanelid"));
                        dsDelete.setValue(rowID, "u_accessionid", dsAssignTests.getValue(i, "u_accessionid"));
                    } else {
                        int rowID = dsApplyWorkItem.addRow();
                        dsApplyWorkItem.setValue(rowID, "sampleid", dsAssignTests.getValue(i, "s_sampleid"));
                        dsApplyWorkItem.setValue(rowID, "workitemid", dsAssignTests.getValue(i, "testname"));
                        dsApplyWorkItem.setValue(rowID, "testname", dsAssignTests.getValue(i, "testname"));
                        dsApplyWorkItem.setValue(rowID, "mapid", dsAssignTests.getValue(i, "u_sampletestcodemapid"));
                        dsApplyWorkItem.setValue(rowID, "testcodeid", dsAssignTests.getValue(i, "lvtestcodeid"));
                        dsApplyWorkItem.setValue(rowID, "specimentype", dsAssignTests.getValue(i, "specimentype"));
                        dsApplyWorkItem.setValue(rowID, "u_clientspecimenid", dsAssignTests.getValue(i, "u_clientspecimenid"));
                        dsApplyWorkItem.setValue(rowID, "lvtestpanelid", dsAssignTests.getValue(i, "lvtestpanelid"));
                        dsApplyWorkItem.setValue(rowID, "u_accessionid", dsAssignTests.getValue(i, "u_accessionid"));
                    }
                }
            }
            if (dsDelete.size() > 0) {
                String mapid = dsDelete.getColumnValues("mapid", ";");
                sql = Util.parseMessage(ApSql.GET_DATASET_BY_SAMPLETESTCODEMAP_ID, StringUtil.replaceAll(mapid, ";", "','"),
                        StringUtil.replaceAll(mapid, ";", "','"));
                DataSet dsTest = getQueryProcessor().getSqlDataSet(sql);

                sql = Util.parseMessage(ApSql.GET_WORKITEM_BY_SAMPLETESTCODEMAP_ID, StringUtil.replaceAll(mapid, ";", "','"),
                        StringUtil.replaceAll(mapid, ";", "','"));
                DataSet dsWorkItem = getQueryProcessor().getSqlDataSet(sql);
                deleteDataSet(dsTest);
                deleteSDIWorkItem(dsWorkItem);
                deleteTestcode(mapid);
                editPanelName(dsApplyWorkItem);
                applyWorkItemWithSlideForPanel(dsApplyWorkItem);
                applyPanelWorkItemSlide(dsApplyWorkItem);
                changeSlideType(dsMain, dsApplyWorkItem);

            }
            //throw new SapphireException("test");
        }
    }

    private void editPanelName(DataSet dsApplyPanel) throws SapphireException {
        if (dsApplyPanel.size() > 0) {
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsApplyPanel.getColumnValues("mapid", ";"));
            prop.setProperty("lvtestpanelid", dsApplyPanel.getColumnValues("lvtestpanelid", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete testcode(s).");
            }
        }
    }

    private void deleteTestcode(String keyid1) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "SampleTestCodeMap");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, keyid1);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete testcode(s).");
            }
        }
    }

    private void deleteDataSet(DataSet dsTest) throws SapphireException {
        if (dsTest != null && dsTest.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteDataSet.PROPERTY_KEYID1, dsTest.getColumnValues("keyid1", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTID, dsTest.getColumnValues("paramlistid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTVERSIONID, dsTest.getColumnValues("paramlistversionid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_VARIANTID, dsTest.getColumnValues("variantid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_DATASET, dsTest.getColumnValues("dataset", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteDataSet.ID, DeleteDataSet.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s).");
            }

        }
    }

    private void deleteSDIWorkItem(DataSet deleteWorkItem) throws SapphireException {
        if (deleteWorkItem != null && deleteWorkItem.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDIWorkItem.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_KEYID1, deleteWorkItem.getColumnValues("keyid1", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMID, deleteWorkItem.getColumnValues("workitemid", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_WORKITEMINSTANCE, deleteWorkItem.getColumnValues("workiteminstance", ";"));
            props.setProperty(DeleteSDIWorkItem.PROPERTY_CASCADEDELETES, "Y");
            props.setProperty(DeleteSDIWorkItem.PROPERTY_FORCEDELETE, "Y");
            try {
                getActionProcessor().processAction(DeleteSDIWorkItem.ID, DeleteSDIWorkItem.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete test dataset(s).");
            }

        }
    }

    private void applyWorkItemWithSlideForPanel(DataSet dsApplyWorkItem) throws SapphireException {
        String alltestcodeIDs = Util.getUniqueList(dsApplyWorkItem.getColumnValues("testcodeid", ";"), ";", true);
        String sql = Util.parseMessage(ApSql.GET_WORKITEM_BY_TESTCODE, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsWorkItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsWorkItem.size() == 0) {
            String errStr = "No work items found for below testcode(s)" + alltestcodeIDs;
            logger.error(errStr);
            return; // don't need to throw error
        }
        // CHECK WORKITEMITEM, PARAMLIST, PARAMLISTITEM
        sql = Util.parseMessage(ApSql.GET_PARAMLISTS_BY_TESTCODE, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsWorkItemItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItemItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (!dsApplyWorkItem.isValidColumn("workitemidexists")) {
            dsApplyWorkItem.addColumn("workitemidexists", DataSet.STRING);//
        }
        if (!dsApplyWorkItem.isValidColumn(DATASET_PROPERTY_WORK_ITEM_ID)) {
            dsApplyWorkItem.addColumn(DATASET_PROPERTY_WORK_ITEM_ID, DataSet.STRING);//
        }
        if (!dsApplyWorkItem.isValidColumn(DATASET_PROPERTY_WORK_ITEM_VERSION_ID)) {
            dsApplyWorkItem.addColumn(DATASET_PROPERTY_WORK_ITEM_VERSION_ID, DataSet.STRING);//
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsApplyWorkItem.getRowCount(); i++) {
            hm.clear();
            hm.put("u_testcodeid", dsApplyWorkItem.getValue(i, "testcodeid", ""));

            DataSet dsFilter = dsWorkItem.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                dsApplyWorkItem.setValue(i, DATASET_PROPERTY_WORK_ITEM_ID, dsFilter.getValue(0, "workitemid", ""));
                dsApplyWorkItem.setValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID,
                        dsFilter.getValue(0, "workitemversionid", ""));
                dsApplyWorkItem.setValue(i, "workitemidexists", "Y");
            }
            hm.clear();
            hm.put("u_testcodeid", dsApplyWorkItem.getValue(i, "testcodeid", ""));
            DataSet dsWorkItemItemFilter = dsWorkItemItem.getFilteredDataSet(hm);
            if (dsWorkItemItemFilter != null && dsWorkItemItemFilter.size() > 0) {
                dsApplyWorkItem.setValue(i, DATASET_PROPERTY_WORK_ITEM_ID, dsFilter.getValue(0, "workitemid", ""));
                dsApplyWorkItem.setValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID,
                        dsFilter.getValue(0, "workitemversionid", ""));
                dsApplyWorkItem.setValue(i, "workitemidexists", "Y");
            } else {
                dsApplyWorkItem.setValue(i, DATASET_PROPERTY_WORK_ITEM_ID, dsFilter.getValue(0, "workitemid", ""));
                dsApplyWorkItem.setValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID,
                        dsFilter.getValue(0, "workitemversionid", ""));
                dsApplyWorkItem.setValue(i, "workitemidexists", "N");
            }
        }

        DataSet dsApplyWI = new DataSet();
        dsApplyWI.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsApplyWI.addColumn("workitemidexists", DataSet.STRING);
        dsApplyWI.addColumn(DATASET_PROPERTY_WORK_ITEM_ID, DataSet.STRING);
        dsApplyWI.addColumn(DATASET_PROPERTY_WORK_ITEM_VERSION_ID, DataSet.STRING);
        for (int i = 0; i < dsApplyWorkItem.size(); i++) {
            String workitemid = dsApplyWorkItem.getValue(i, DATASET_PROPERTY_WORK_ITEM_ID, "");
            if (!Util.isNull(workitemid)) {
                int rowId = dsApplyWI.addRow();
                dsApplyWI.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID, dsApplyWorkItem.getValue(i, "sampleid", ""));
                dsApplyWI.setValue(rowId, "workitemidexists", dsApplyWorkItem.getValue(i, "workitemidexists", ""));
                dsApplyWI.setValue(rowId, DATASET_PROPERTY_WORK_ITEM_ID, dsApplyWorkItem.getValue(i, DATASET_PROPERTY_WORK_ITEM_ID, ""));
                dsApplyWI.setValue(rowId, DATASET_PROPERTY_WORK_ITEM_VERSION_ID, dsApplyWorkItem.getValue(i, DATASET_PROPERTY_WORK_ITEM_VERSION_ID, ""));
            }
        }
        if (dsApplyWI != null && dsApplyWI.size() > 0) {
            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Sample");
            propswi.setProperty("keyid1", dsApplyWI.getColumnValues(DATASET_PROPERTY_SAMPLE_ID, ";"));
            propswi.setProperty("applyworkitem", dsApplyWI.getColumnValues("workitemidexists", ";"));
            propswi.setProperty("workitemid", dsApplyWI.getColumnValues(DATASET_PROPERTY_WORK_ITEM_ID, ";"));
            propswi.setProperty("workitemversionid", dsApplyWI.getColumnValues(DATASET_PROPERTY_WORK_ITEM_VERSION_ID, ";"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
        // APPLY SPEC WITH SAMPLE
        //addSpecWithSample(dsFinalWithApplyWI);
        addSpecWithSample(dsApplyWorkItem);
    }

    private void addSpecWithSample(DataSet dsFinalWithApplyWI) throws SapphireException {
        HashMap<String, String> hm = new HashMap<String, String>();
        DataSet dsSpecDetails = new DataSet();
        dsSpecDetails.addColumn(DATASET_PROPERTY_SAMPLE_ID, DataSet.STRING);
        dsSpecDetails.addColumn(DATASET_PROPERTY_SPEC_ID, DataSet.STRING);
        dsSpecDetails.addColumn(DATASET_PROPERTY_SPEC_VERSION_ID, DataSet.STRING);
        dsSpecDetails.addColumn("isduplicate", DataSet.STRING);

        // ------------------------APPLY SDI SPEC WITH
        // SAMPLE---------------------------/
        String uniqueWorkitemid = Util
                .getUniqueList(dsFinalWithApplyWI.getColumnValues(DATASET_PROPERTY_WORK_ITEM_ID, ";"), ";", true);
        String sql = Util.parseMessage(ApSql.GET_SPECIFICATION_BY_WORKITEMID, StringUtil.replaceAll(uniqueWorkitemid, ";", "','"));
        DataSet dsSpec = getQueryProcessor().getSqlDataSet(sql);
        if (dsSpec != null && dsSpec.size() != 0) {
            for (int i = 0; i < dsSpec.size(); i++) {
                String specid = dsSpec.getValue(i, "specid", "");
                String specversionid = dsSpec.getValue(i, "specversionid", "");
                hm.clear();
                hm.put(DATASET_PROPERTY_WORK_ITEM_ID, specid);
                DataSet dsFilter = dsFinalWithApplyWI.getFilteredDataSet(hm);
                if (dsFilter != null && dsFilter.size() != 0) {
                    String uniqueSampleid[] = StringUtil.split(
                            Util.getUniqueList(dsFilter.getColumnValues("sampleid", ";"), ";", true),
                            ";");
                    for (int k = 0; k < uniqueSampleid.length; k++) {
                        hm.clear();
                        hm.put("sampleid", uniqueSampleid[k]);
                        hm.put(DATASET_PROPERTY_WORK_ITEM_ID, specid);
                        DataSet dsFilterFinal = dsFilter.getFilteredDataSet(hm);
                        for (int j = 0; j < dsFilterFinal.size(); j++) {
                            int rowId = dsSpecDetails.addRow();
                            if (j == 0) {
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID,
                                        dsFilterFinal.getValue(j, "sampleid", ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_ID,
                                        dsFilterFinal.getValue(j, DATASET_PROPERTY_WORK_ITEM_ID, ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_VERSION_ID, specversionid);
                                dsSpecDetails.setValue(rowId, "isduplicate", "N");
                            } else {
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SAMPLE_ID,
                                        dsFilterFinal.getValue(j, "sampleid", ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_ID,
                                        dsFilterFinal.getValue(j, DATASET_PROPERTY_WORK_ITEM_ID, ""));
                                dsSpecDetails.setValue(rowId, DATASET_PROPERTY_SPEC_VERSION_ID, specversionid);
                                dsSpecDetails.setValue(rowId, "isduplicate", "Y");
                            }
                        }
                    }
                }
            }

            hm.clear();
            hm.put("isduplicate", "N");
            DataSet dsFilter = dsSpecDetails.getFilteredDataSet(hm);
            if (dsFilter != null && dsFilter.size() > 0) {
                PropertyList prop = new PropertyList();
                prop.setProperty(AddSDISpec.PROPERTY_SDCID, "Sample");
                prop.setProperty(AddSDISpec.PROPERTY_KEYID1, dsFilter.getColumnValues("sampleid", ";"));
                prop.setProperty("specid",
                        Util.getUniqueList(dsFilter.getColumnValues(DATASET_PROPERTY_SPEC_ID, ";"), ";", true));
                prop.setProperty("specversionid",
                        Util.getUniqueList(dsFilter.getColumnValues(DATASET_PROPERTY_SPEC_VERSION_ID, ";"), ";", true));
                try {
                    getActionProcessor().processAction(AddSDISpec.ID, AddSDISpec.VERSIONID, prop);
                } catch (ActionException e) {
                    String errMSG = getTranslationProcessor().translate("Action failed.AddSDISpec ") + e.getMessage();
                    throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
                }
            }
        }
    }

    private void changeSlideType(DataSet dsMain, DataSet dsApply) throws SapphireException {
        if (!dsApply.isValidColumn("hneflag"))
            dsApply.addColumn("hneflag", DataSet.STRING);//specimentype
        if (!dsApply.isValidColumn("slidetype"))
            dsApply.addColumn("slidetype", DataSet.STRING);
        if (!dsApply.isValidColumn("u_clientspecimenid"))
            dsApply.addColumn("u_clientspecimenid", DataSet.STRING);
        if (!dsApply.isValidColumn("lvtestpanelid"))
            dsApply.addColumn("lvtestpanelid", DataSet.STRING);
        if (!dsApply.isValidColumn("u_accessionid"))
            dsApply.addColumn("u_accessionid", DataSet.STRING);
        for (int i = 0; i < dsApply.size(); i++) {
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("s_sampleid", dsApply.getValue(i, "sampleid"));
            hm.put("lvtestcodeid", dsApply.getValue(i, "testcodeid"));
            DataSet dsFilterSlide = dsMain.getFilteredDataSet(hm);
            if (dsFilterSlide.size() > 0) {
                dsApply.setValue(i, "hneflag", dsFilterSlide.getValue(0, "hneflag", ""));
                dsApply.setValue(i, "u_accessionid", dsFilterSlide.getValue(0, "u_accessionid", ""));
                dsApply.setValue(i, "u_clientspecimenid", dsFilterSlide.getValue(0, "u_clientspecimenid", ""));
                dsApply.setValue(i, "lvtestpanelid", dsFilterSlide.getValue(0, "lvtestpanelid", ""));
            }
        }
        if (dsApply.size() > 0) {
            for (int i = 0; i < dsApply.size(); i++) {
                String ishne = dsApply.getValue(i, "hneflag", "");
                String specimentype = dsApply.getValue(i, "specimentype", "");

                if ("Y".equalsIgnoreCase(ishne) && "Client H&E Slide".equalsIgnoreCase(specimentype))
                    dsApply.setValue(i, "slidetype", "CH");
                else if ("Y".equalsIgnoreCase(ishne) && "H&E Slide".equalsIgnoreCase(specimentype))
                    dsApply.setValue(i, "slidetype", "CH");
                else if ("Y".equalsIgnoreCase(ishne) && "Unstained Slide".equalsIgnoreCase(specimentype))
                    dsApply.setValue(i, "slidetype", "H");
                else if (!"Y".equalsIgnoreCase(ishne) && "Unstained Slide".equalsIgnoreCase(specimentype))
                    dsApply.setValue(i, "slidetype", "CU");
                else if ("Y".equalsIgnoreCase(ishne) && "Stained Slide".equalsIgnoreCase(specimentype))
                    dsApply.setValue(i, "slidetype", "H");
                else if (!"Y".equalsIgnoreCase(ishne) && "Stained Slide".equalsIgnoreCase(specimentype))
                    dsApply.setValue(i, "slidetype", "CS");
                else if ("Y".equalsIgnoreCase(ishne) && (!"Unstained Slide".equalsIgnoreCase(specimentype) || !"Stained Slide".equalsIgnoreCase(specimentype)))
                    dsApply.setValue(i, "slidetype", "H");
                else
                    dsApply.setValue(i, "slidetype", "U");
            }
            PropertyList prop = new PropertyList();
            prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            prop.setProperty(EditSDI.PROPERTY_KEYID1, dsApply.getColumnValues("sampleid", ";"));
            prop.setProperty("u_type", dsApply.getColumnValues("slidetype", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
            } catch (Exception ex) {
                throw new SapphireException("Unable to change to slide type.");
            }
        }

    }

    private void applyPanelWorkItemSlide(DataSet dsFinal) throws SapphireException {
        DataSet dsPanel = new DataSet();
        dsPanel.addColumn("lvtestpanelid", DataSet.STRING);
        dsPanel.addColumn("u_clientspecimenid", DataSet.STRING);
        dsPanel.addColumn("u_accessionid", DataSet.STRING);
        dsFinal.sort("u_clientspecimenid,lvtestpanelid,u_accessionid");
        ArrayList<DataSet> dsLVPanel = dsFinal.getGroupedDataSets("u_clientspecimenid,lvtestpanelid,u_accessionid");
        if (dsLVPanel != null && dsLVPanel.size() > 0) {
            for (int i = 0; i < dsLVPanel.size(); i++) {
                DataSet temDs = (DataSet) dsLVPanel.get(i);
                int rowID = dsPanel.addRow();
                dsPanel.setValue(rowID, "u_accessionid", Util.getUniqueList(temDs.getColumnValues("u_accessionid", ";"), ";", true));
                dsPanel.setValue(rowID, "u_clientspecimenid", Util.getUniqueList(temDs.getColumnValues("u_clientspecimenid", ";"), ";", true));
                dsPanel.setValue(rowID, "lvtestpanelid", Util.getUniqueList(temDs.getColumnValues("lvtestpanelid", ";"), ";", true));
            }
        }
        String alltestcodeIDs = Util.getUniqueList(dsPanel.getColumnValues("lvtestpanelid", ";"), ";", true);
        if (!dsPanel.isValidColumn("panelworkitem"))
            dsPanel.addColumn("panelworkitem", DataSet.STRING);

        String sql = Util.parseMessage(ApSql.GET_PANEL_NAME_BY_PANELID, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsLvPanelDetails = getQueryProcessor().getSqlDataSet(sql);
        for (int i = 0; i < dsPanel.size(); i++) {
            String lvpanelid = dsPanel.getValue(i, "lvtestpanelid");
            HashMap hmFilter = new HashMap();
            hmFilter.clear();
            hmFilter.put("u_testcodeid", lvpanelid);
            DataSet dsPanelFilter = dsLvPanelDetails.getFilteredDataSet(hmFilter);
            if (dsPanelFilter.size() > 0) {
                String panelname = dsPanelFilter.getValue(0, "testname", "");
                dsPanel.setValue(i, "panelworkitem", panelname);
            }
        }

        sql = Util.parseMessage(ApSql.GET_WORKITEM_BY_TEST, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsWorkItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsWorkItem.size() == 0) {
            String errStr = "No work items found for below testcode(s)" + alltestcodeIDs;
            logger.error(errStr);
            return; // don't need to throw error
        }
        // CHECK WORKITEMITEM, PARAMLIST, PARAMLISTITEM
        sql = Util.parseMessage(ApSql.GET_WORKITEMITEM_BY_TEST, StringUtil.replaceAll(alltestcodeIDs, ";", "','"));
        DataSet dsWorkItemItem = getQueryProcessor().getSqlDataSet(sql);
        if (dsWorkItemItem == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + sql;
            logger.error(errStr);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (!dsPanel.isValidColumn("isapplyworkitem"))
            dsPanel.addColumn("isapplyworkitem", DataSet.STRING);
        if (!dsPanel.isValidColumn("workitemversionid"))
            dsPanel.addColumn("workitemversionid", DataSet.STRING);
        HashMap hmFilter = new HashMap();
        for (int i = 0; i < dsPanel.size(); i++) {
            hmFilter.clear();
            hmFilter.put("workitemid", dsPanel.getValue(i, "panelworkitem"));
            DataSet dsWorkItemFilter = dsWorkItem.getFilteredDataSet(hmFilter);
            if (dsWorkItemFilter.size() > 0) {
                dsPanel.setValue(i, "workitemversionid", dsWorkItemFilter.getValue(0, "workitemversionid"));
            }
            hmFilter.clear();
            hmFilter.put("workitemid", dsPanel.getValue(i, "panelworkitem"));
            DataSet dsApplyWorkItemFilter = dsWorkItemItem.getFilteredDataSet(hmFilter);
            if (dsApplyWorkItemFilter.size() > 0) {
                dsPanel.setValue(i, "isapplyworkitem", "Y");
            }
        }
        if (dsPanel != null && dsPanel.size() > 0) {
            PropertyList propswi = new PropertyList();
            propswi.setProperty("sdcid", "Accession");
            propswi.setProperty("keyid1", dsPanel.getColumnValues("u_accessionid", ";"));
            propswi.setProperty("keyid2", dsPanel.getColumnValues("u_clientspecimenid", ";"));
            //propswi.setProperty("keyid3", dsPanel.getColumnValues("u_clientspecimenid", ";"));
            propswi.setProperty("applyworkitem", dsPanel.getColumnValues("isapplyworkitem", ";"));
            propswi.setProperty("workitemid", dsPanel.getColumnValues("panelworkitem", ";"));
            propswi.setProperty("workitemversionid", dsPanel.getColumnValues("workitemversionid", ";"));
            propswi.setProperty("propsmatch", "Y");
            try {
                getActionProcessor().processAction("AddSDIWorkItem", "1", propswi);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed.AddWorkitem ") + e.getMessage();
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
        }
    }

    private static final String DATASET_PROPERTY_LV_TEST_CODE = "lvtestcodeid";
    private static final String DATASET_PROPERTY_WORK_ITEM_ID = "workitemid";
    private static final String DATASET_PROPERTY_WORK_ITEM_VERSION_ID = "workitemversionid";
    private static final String DATASET_PROPERTY_SAMPLE_ID = "s_sampleid";
    private static final String DATASET_PROPERTY_SPEC_ID = "specid";
    private static final String DATASET_PROPERTY_SPEC_VERSION_ID = "specversionid";
}
