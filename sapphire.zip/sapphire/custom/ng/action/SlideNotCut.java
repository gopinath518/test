package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class SlideNotCut extends BaseAction {
    private DataSet dsFinal = null;

    public void processAction(PropertyList properties) throws SapphireException {
        String sdcid = properties.getProperty("sdcid");
        String sampleids = properties.getProperty("keyid1");
        String u_iscut = properties.getProperty("u_iscut");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");

        populateDataSet(sampleids,u_iscut,u_currentmovementstep);
        updateSampleMovement(dsFinal,sdcid,properties,sampleids);

    }
    public void populateDataSet(String samples,String iscut,String movementstep) throws  SapphireException{
        String sampleid=StringUtil.replaceAll(samples,";","','");
        String sql= Util.parseMessage(ApSql.GET_METHODOLOGY,sampleid);
        DataSet dsMethodologyInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsFinal == null) {
            dsFinal = new DataSet();
            dsFinal.addColumn("sampleid", DataSet.STRING);
            dsFinal.addColumn("iscut", DataSet.STRING);
            dsFinal.addColumn("movementstep", DataSet.STRING);
        }
        int rowID = 0;
        for (int i = 0; i < dsMethodologyInfo.size(); i++) {
            rowID = dsFinal.addRow();
            dsFinal.setValue(rowID, "sampleid", dsMethodologyInfo.getValue(i,"s_sampleid"));
            dsFinal.setValue(rowID, "iscut", iscut);
            if("FISH".equalsIgnoreCase(dsMethodologyInfo.getValue(i,"methodology"))){
                dsFinal.setValue(rowID, "movementstep", "FISHQC");
            }
            else {
                dsFinal.setValue(rowID, "movementstep", movementstep);
            }
        }
    }

    private void updateSampleMovement(DataSet dsFinal,String sdcid,PropertyList properties,String sampleids) throws SapphireException{
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, sdcid);
        prop.setProperty(EditSDI.PROPERTY_KEYID1, dsFinal.getColumnValues("sampleid",";"));
        prop.setProperty("u_iscut", dsFinal.getColumnValues("iscut",";"));
        prop.setProperty("u_currentmovementstep", dsFinal.getColumnValues("movementstep",";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
        updateMicrotomyComment(properties, sampleids);
    }

    private void updateMicrotomyComment(PropertyList properties, String selectedSamples) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_DISTINCT_PARENT_SAMPLE, StringUtil.replaceAll(selectedSamples, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        String blockId = Util.getUniqueList(dsSampleInfo.getColumnValues("parentsampleid", ";"), ";", true);
        if (Util.isNull(blockId)) {
            return;
        }

        String newComment = properties.getProperty("comment");
        String previouscommentSQL = Util.parseMessage(ApSql.PREVIOUS_COMMENT, StringUtil.replaceAll(blockId, ";", "','"));
        DataSet dsPreviousComment = getQueryProcessor().getSqlDataSet(previouscommentSQL);
        String previousCommentFromDB = dsPreviousComment.getValue(0, "u_microtomycomment", "");
        String finalComment = "";
        if (!newComment.equals("")) {
            finalComment = newComment + " --" + previousCommentFromDB;
        }

        try {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, selectedSamples);
            props.setProperty("u_microtomycomment", finalComment);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (Exception ae) {
            String error = getTranslationProcessor().translate("Can't update in sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
