package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Constants;
import sapphire.xml.PropertyList;

import java.util.Iterator;

import static sapphire.util.StringUtil.repeat;
import static sapphire.util.StringUtil.split;

/**************************************************
 * Created by smitra on 10/6/2017.
 *
 * This ACTION class needed to do the routing
 * between two tramstops and changing department
 *************************************************/
public class SetDeptCMS extends BaseAction implements Constants{

    /*****************************************
     * This action method deals with
     * updating latest Sample and TrackItem
     * data to DB which were populated with
     * the request parameters passed into
     * this ACTION
     * @param props
     * @throws SapphireException
     *****************************************/
    @Override
    public void processAction(PropertyList props) throws SapphireException {
        String userDepartment = connectionInfo.getDefaultDepartment();
        String site = userDepartment.substring(0, userDepartment.indexOf("-")+1);

        PropertyList sampleProps = getSampleProperties(props);
        PropertyList trackItemProps = getTrackItemProperties(props, site);

        if(sampleProps.size()>0)
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, sampleProps);

        if(trackItemProps.size()>0)
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, trackItemProps);
    }

    /********************************************
     * Method to check whether
     * multiple samples are selecte for editing
     * @param plInput
     * @return int
     *******************************************/
    private int multiplePropertyLength(PropertyList  plInput, String param){
        return (split(plInput.getProperty(param), ";")).length;
    }

    /***********************************
     * Populating Sample SDC properties
     * @param sampleProps
     * @return PropertyList
     **********************************/
    private PropertyList getSampleProperties(PropertyList sampleProps){
        String column = EMPTY_STRING;
        Iterator itr = sampleProps.keySet().iterator();
        PropertyList result = new PropertyList();
        int num = this.multiplePropertyLength(sampleProps,SAMPLE_KEYID1);
        while(itr.hasNext()){
            Object key = itr.next();
            if(key instanceof String) {
                String propKey = (String) key;
                if (propKey.startsWith(SAMPLE_PREFIX)) {
                    String propVal = sampleProps.getProperty(propKey);
                    if ((num > 1) && (!SAMPLE_SDCID.equalsIgnoreCase(propKey))
                            && (!SAMPLE_KEYID1.equalsIgnoreCase(propKey))) {
                        propVal = repeat(propVal, num, ";");
                    }
                    column = propKey.substring(SAMPLE_PREFIX.length());
                    result.setProperty(column, propVal);
                    itr.remove();
                }
            }
        }
        return result;
    }

    /**************************************
     * Populating TrackItem SDC properties
     * @param trackItemProps
     * @return PropertyList
     **************************************/
    private PropertyList getTrackItemProperties(PropertyList trackItemProps, String site){
        String column = EMPTY_STRING;
        Iterator itr = trackItemProps.keySet().iterator();
        PropertyList result = new PropertyList();
        int num = this.multiplePropertyLength(trackItemProps, TRACKITEM_KEYID1);
        while(itr.hasNext()){
            Object key = itr.next();
            if(key instanceof String) {
                String propKey = (String) key;
                if(propKey.startsWith(TRACKITEM_PREFIX)){
                    String propVal = trackItemProps.getProperty(propKey);
                    if(TRACKITEM_CUSTODIALDEPARTMENTID.equalsIgnoreCase(propKey)){
                        propVal = site + propVal;
                    }
                    if(num > 1 && (!TRACKITEM_KEYID1.equalsIgnoreCase(propKey))){
                        propVal = repeat(propVal, num, ";");
                    }
                    column = propKey.substring(TRACKITEM_PREFIX.length());
                    result.setProperty(column, propVal);
                    itr.remove();
                }
            }
        }
        return result;
    }
}