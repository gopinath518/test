package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Action Name- ChangeExtractionType
 * Description: This Action is use to change extraction type .
 * input :-
 * param1-extractionid
 * param2-changeextractiontype
 * throws SapphireException
 * Created by mpandey on 9/26/2016.
 */
public class ChangeExtractionType extends BaseAction {

    public void processAction(PropertyList properties) throws SapphireException {
        String extractionid=properties.getProperty("extractionid");
        String changeextractiontype=properties.getProperty("changeextractiontype");

        String testcodemapid=getTestcodeMapId(extractionid);
        updateExtractionType(testcodemapid,changeextractiontype);
    }

    /**
     * This method is use to update extraction type.
     * @param testcodemapid
     * @param changeextractiontype
     * @throws SapphireException
     */
    private void updateExtractionType(String testcodemapid, String changeextractiontype) throws SapphireException {
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1,testcodemapid);
        editProp.setProperty("extractiontype", changeextractiontype);

        try {
            getActionProcessor().processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to update extraction type. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }

    }

    /**
     * This method is use to get all the testcodes associated with a sample.
     * @param extractionid
     * @return
     * @throws SapphireException
     */
    private String getTestcodeMapId(String extractionid) throws SapphireException {
        String sql="select u_sampletestcodemapid from u_sampletestcodemap where s_sampleid in ('"+extractionid.replaceAll(";","','")+"')";
    DataSet dstestcodemap=getQueryProcessor().getSqlDataSet(sql);
        if(dstestcodemap==null || dstestcodemap.size()==0){
            String errMSG = getTranslationProcessor().translate("Action failed ClientSpecimenID ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMSG);
        }
        return dstestcodemap.getColumnValues("u_sampletestcodemapid",";");
    }
}
