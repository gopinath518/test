package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.io.File;
import java.util.HashMap;

/**
 * Created by dgupta on 7/18/2016.
 * Depricated Not in Use
 */
public class OpenVMSForScoring extends BaseAction {
    String filenames = "388473.tif;388470.tif;388472.tif;388471.tif;388468.tif;388466.tif;388465.tif;388467.tif;388464.tif;388481.tif;" +
            "388475.tif;388476.tif;388477.tif;388478.tif;388479;tif;388468-001.tif;388466-001.tif;388465-001.tif;388467-001.tif;388464-001.tif;388464-002.tif;" +
            "15980481.tif;388487.tif;388483.tif;388483-001.tif;388484.tif;388485.tif;388486.tif;15985818.tif;388500.tif;388499.tif;388498.tif;388502.tif;388501.tif;" +
            "388507.tif;388509.tif;388506.tif;388505.tif;388514.tif;388515.tif;388511.tif;388512.tif;388513.tif;388514-001.tif;388515-001.tif;388511-001.tif;" +
            "388512-001.tif;388513-001.tif;388518.tif;388519.tif;388520.tif;388521.tif;388582.tif;388581.tif;388580.tif;388579.tif;388583.tif;388592.tif;388593.tif;388595.tif;" +
            "388596.tif;388608_C.tif;388708.tif;388608_C-001.tif;388609_C.tif;388610_C.tif;388611_C.tif;388612.tif;388608.tif;388609.tif;388610.tif;388611.tif;88601.tif;" +
            "388602.tif;388603.tif;388601_C.tif;388605.tif;88604_C.tif;388604.tif;388603_C.tif;388602_C.tif;388704.tif;388;03.tif;388706.tif;388707.tif;388701.tif;388702.tif;" +
            "388699.tif;388693.tif;388694.tif;388695.tif;388696.tif;388697.tif;test ray.tif;389329.tif;389328.tif;389333_C.tif;389333.tif;389338_C.tif;389338.tif;389339.tif;" +
            "389344.tif;89343.tif;389355.tif;389342.tif;389341.tif;389345.tif;389341_C.tif;389344_C.tif;389342_C.tif;389343_C.tif;389358.tif;389357.tif;389354.tif;389356.tif;" +
            "389344-001.tif;389343-001.tif;389342-001.tif;389341-001.tif;389345-001.tif;389341_C-001.tif;389344_C-001.tif;389607.tif;389342_C-001.tif;389343_C-001.tif;389586.tif;" +
            "389587.tif;389584.tif;389585.tif;389588.tif;389609.tif;389610.tif;389606.tif;389608.tif;389640.tif;389638.tif;389637.tif;389639.tif;936033.tif;389666.tif;389670.tif;" +
            "389668.tif;389667.tif;389696.tif;389698.tif;389697.tif;389700.tif;389989_C.tif;389989.tif;389988_C.tif;389987_C.tif;389988.tif;389987.tif;389975_C.tif;389986_C.tif;" +
            "389986.tif;389985.tif;389985_C.tif;389991.tif;389982.tif;389982_C.tif;389983_C.tif;389983.tif;389975.tif;389978_C.tif;389978.tif;389979.tif;389977_C.tif;389976.tif;" +
            "389977.tif;389976_C.tif;389706.tif;389703_C.tif;389703.tif;389702_C.tif;389704.tif;389702.tif;389704_C.tif;389705.tif;390064.tif;390063.tif;390063_C.tif;390064_C.tif;" +
            "390065.tif;390066.tif;390058_C.tif;390065_C.tif;390066_C.tif;390067.tif;390067_C.tif;390060_C.tif;390060.tif;390061_C.tif;390059_C.tif;390059.tif;390061.tif;390058.tif;" +
            "390057_C.tif;390057.tif;390056_C.tif;390056.tif;390055_C.tif;390055.tif;390053_C.tif;390053.tif;390052_C.tif;390052.tif;390051_C.tif;390051.tif;390049_C.tif;" +
            "390049.tif;390048_C.tif;390048.tif;390140_C.tif;390140.tif;390139.tif;390139_C.tif;390142.tif;390154.tif;390153.tif;390152.tif;390151.tif;390150.tif;390148.tif;" +
            "390146.tif;390145.tif;390144.tif390143.tif;16021137.tif;";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String typeopen = properties.getProperty("typeopen");
        String sampleid = "";
        sampleid = properties.getProperty("sampleid");
        if ("VMS".equalsIgnoreCase(typeopen)) {
            String sql = Util.parseMessage(ApSql.GET_IMAGEDETAILS_BY_ID, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet dsImagePath = getQueryProcessor().getSqlDataSet(sql);
            sampleid = dsImagePath.getColumnValues("sampleid", ";");
        } else {
            sampleid = properties.getProperty("sampleid");
        }
        sampleid = StringUtil.replaceAll(sampleid, ";", "','");
        /*String sql = "select distinct u_accessionid , stcm.LOS los  FROM s_sample s,u_sampletestcodemap stcm   WHERE  s.s_sampleid = stcm.s_sampleid and stcm.LOS is not null " +
                " and stcm.teststatus !='Cancelled' and  s.s_sampleid in ('" + sampleid + "')  ";*/
        String sql = Util.parseMessage(ApSql.GET_LOS_BY_SAMPLEID_VMS_SCORING, sampleid);
        DataSet dsAccess = getQueryProcessor().getSqlDataSet(sql);
        if (dsAccess == null) throw new SapphireException("Problem - may be test code not assigned to Sample ");
        //TODO CATTER MULIPLE IMAGES FOR VMS
        /*if (dsAccess.getRowCount() > 1) {
            HashMap hm = new HashMap();
            hm.put("los", dsAccess.getString(0, "los"));
            DataSet dsFilter = dsAccess.getFilteredDataSet(hm);
            if (dsFilter.getRowCount() != dsAccess.getRowCount()) {
                throw new SapphireException("Select sample from a Accession id and  same LOS, can not process samples from different accession or LOS = " + dsAccess.getColumnValues("los", " and "));
            }
        }*/
        String userid = connectionInfo.getSysuserId();
        sql = Util.parseMessage(ApSql.GET_IMAGEDETAILS_BY_SaMPLEID, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsImagePath = getQueryProcessor().getSqlDataSet(sql);
        //TODO CATTER MULIPLE IMAGES FOR VMS
        /*String filepath = dsImagePath.getValue(0, "folderpath", "");
        String filename = dsImagePath.getValue(0, "filename", "");
        String randomImageFile = filepath + File.separator + filename;
        System.out.println("image path   " + randomImageFile);*/
        //DataSet dsuser = getQueryProcessor().getSqlDataSet("select sysuserdesc from sysuser where sysuserid='" + userid + "'");
        DataSet dsuser = getQueryProcessor().getSqlDataSet(Util.parseMessage(ApSql.GET_USER_INFO_VMS_SCORING, userid));
        /*String strSql = "select distinct s.s_sampleid, s.sampletypeid, ac.u_accessionid u_accessionid, ac.patientid, sb.u_firstname,tc.u_testcodeid," +
                " tc.testcodedesc testname, sm.lvtestcodeid, " +
                "  sb.u_lastname, sb.u_middlename, ac.clientid, cpm.physicianid, ph.firstname,  ph.lastname, sb.u_birthdt, sb.genderflag, s.u_type, s.u_clientspecimenid   " +
                "   from s_sample s, u_accession ac, s_subject sb, u_clientphysicianmap cpm, u_sampletestcodemap sm, u_physician ph, u_testcode tc  " +
                "   where s.s_sampleid = sm.s_sampleid and sm.lvtestcodeid = tc.u_testcodeid  and tc.methodology='IHC'  and " +
                "   s.u_accessionid =ac.u_accessionid(+)  and ac.patientid =sb.s_subjectid (+) and ac.clientid= cpm.clientid(+)  and cpm.physicianid =ph.u_physicianid (+) " +
                "  and sm.teststatus !='Cancelled' and s.u_type in ('U', 'CH', 'H', 'CU', 'CST','PC','NC','CS')  and s.s_sampleid in ('" + sampleid + "')" +
                "  order by tc.testcodedesc ";  // and s.u_currentmovementstep in ('QCPass', 'QCSuboptimal')*/
        String strSql = Util.parseMessage(ApSql.GET_SAMPLEINFO_VMS_SCORING, sampleid);
        DataSet dsSample = getQueryProcessor().getSqlDataSet(strSql);
        StringBuffer sbVmsQc = new StringBuffer();
        sbVmsQc.append("<VMSSession Version=\"1.0\" Accessor=\"{226D4CB8-C5FD-4f68-A8B8-B7E4756F7B0A}\" UserID=\"" + userid + "\" UserDisplayName=\"" + dsuser.getString(0, "sysuserdesc") + "\">\n" +
                "  <MenuItems>\n" +
                "    <MenuItem Id=\"mnuPrevious\" Type=\"Button\" OnClick=\"PreviousImage();\" Img=\"images/Previous.jpg\" ImgOver=\"images/Previous.jpg\" Text=\"Previous\" />\n" +
                "    <MenuItem Id=\"mnuNext\" Type=\"Button\" OnClick=\"NextImage();\" Img=\"images/Next.jpg\" ImgOver=\"images/Next.jpg\" Text=\"Next\" />\n" +
                //"    <MenuItem Id=\"mnuSlideLabel\" Type=\"Button\" OnClick=\"ShowSlideLabel();\" Img=\"images/slidelabel.gif\" ImgOver=\"images/slideLabel_Over.gif\" Text=\"Slide Label\" />\n" +
                "  </MenuItems>\n" +
                "  <MetaData>\n" +
                "    <DataItem Name=\"LISPlugIn\" Value=\"LabVantage\" />\n");
        if (null == dsuser) {
            sbVmsQc.append("    <DataItem Name=\"User\" Value=\"" + userid + "\" />\n");
        } else {
            sbVmsQc.append("    <DataItem Name=\"User\" Value=\"" + dsuser.getString(0, "sysuserdesc") + "\" />\n");
        }
        sbVmsQc.append("    <DataItem Name=\"Level of Service\" Value=\"" + dsAccess.getString(0, "los") + "\" />\n");
        sbVmsQc.append("    <DataItem Name=\"Patient Name\" Value=\"" + dsSample.getString(0, "u_lastname") + ", " + dsSample.getString(0, "u_firstname") + "\" />\n");
        sbVmsQc.append("    <DataItem Name=\"Case Number\" Value=\"" + dsAccess.getString(0, "u_accessionid") + "\" />\n");
        sbVmsQc.append(" </MetaData>\n");

        String testName = "";
        sbVmsQc.append("    <Images>\n");
        for (int i = 0; i < dsSample.getRowCount(); i++) {
            String s_sampleid = dsSample.getString(i, "s_sampleid", "");
            HashMap hm = new HashMap();
            hm.clear();
            hm.put("sampleid", s_sampleid);
            DataSet dsFilter = dsImagePath.getFilteredDataSet(hm);
            String filepath = dsFilter.getValue(0, "folderpath", "");
            String filename = dsFilter.getValue(0, "filename", "");
            String randomImageFile = filepath + File.separator + filename;
            System.out.println("image path   " + randomImageFile);
            testName = dsSample.getString(i, "testname", "");
            if ("H".equalsIgnoreCase(dsSample.getString(i, "u_type", ""))) {
                sbVmsQc.append("\n").append(createHNEXml(dsSample, dsAccess, i, randomImageFile, typeopen));
            } else if (testName.contains("Estrogen Receptor")) {
                sbVmsQc.append("\n").append(createTestXml(dsSample, dsAccess, i, randomImageFile, typeopen));
            } else if (testName.contains("Progesterone Receptor")) {
                sbVmsQc.append("\n").append(createTestXml(dsSample, dsAccess, i, randomImageFile, typeopen));
            } else if (testName.contains("HER-2")) {
                sbVmsQc.append("\n").append(createTestXml(dsSample, dsAccess, i, randomImageFile, typeopen));
            } else if (testName.contains("Ki-67")) {
                sbVmsQc.append("\n").append(createTestXml(dsSample, dsAccess, i, randomImageFile, typeopen));
            } else {
                sbVmsQc.append("\n").append(createTestXml(dsSample, dsAccess, i, randomImageFile, typeopen));
            }
        }
        sbVmsQc.append("  </Images>\n");
        sbVmsQc.append("    </VMSSession>\n");
        properties.setProperty("inputXml", StringUtil.replaceAll(sbVmsQc.toString(), "&", "&amp;"));
        getActionProcessor().processAction("CallVMSWebService", "1", properties);
    }

    private String createTestXml(DataSet dsSample, DataSet accessDs, int i, String imageFile, String typeopen) {
        StringBuffer sbVmsQc = new StringBuffer();
        DataSet dsAlgo = getQueryProcessor().getSqlDataSet("select distinct  va.name, va.friendlyname, va.vendor, va.pluginassembly, va.parameterset  " +
                "   from u_vmsalgotestlink atk, u_vmsalgorithm va   " +
                "  where atk.algorithmid = va.u_vmsalgorithmid and atk.testid = '" + dsSample.getString(i, "u_testcodeid", "") + "'");

        sbVmsQc.append("    <Image ExternalIdentifier=\"" + dsSample.getString(i, "s_sampleid") + "\" ImageSource=\"APERIO\" ");
        if ("VMS".equalsIgnoreCase(typeopen)) {
            sbVmsQc.append(" DefaultImage=\"" + (i == 0 ? "true" : "false") + "\" AllowEdit=\"false\" ");
        } else {
            sbVmsQc.append(" DefaultImage=\"" + (i == 0 ? "true" : "false") + "\" AllowEdit=\"true\" ");
        }
        sbVmsQc.append(" TitleBar=\"" + dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname") + " - " + dsSample.getString(i, "testname") +
                " - " + dsSample.getString(i, "s_sampleid") + " - Accession# " + dsSample.getString(i, "u_accessionid") + "\" " +
                " Description=\"" + dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname") + " - " + dsSample.getString(i, "testname") + "\"" +
                "  Icon=\"images/PatientSlide.gif\" >\n");
        if (dsSample.getString(i, "testname", "").contains("HER2")) {
            sbVmsQc.append("   <MenuItems>\n" +
                    "           <MenuItem Id=\"mnuTestAddOn\" Type=\"Button\" OnClick=\"TestAddOn('3094X');\" Img=\"images/TestAdd.gif\" ImgOver=\"images/TestAdd.gif\" Text=\"Reflex to HER2 FISH Global\" />\n" +
                    "      </MenuItems>\n");
        }
        sbVmsQc.append("        <MetaData>\n");
        sbVmsQc.append("            <DataItem Name=\"Date Slide Run\" Value=\"" + "21 2122" + "\"/>\n");
        sbVmsQc.append("            <DataItem Name=\"Test Name\" Value=\"" + dsSample.getString(i, "testname", "No Name") + "\" />\n");
        sbVmsQc.append("            <DataItem Name=\"Specimen Barcode\" Value=\"" + dsSample.getString(i, "s_sampleid") + "\" />\n");
        sbVmsQc.append("            <DataItem Name=\"Parent Specimen\" Value=\"" + dsSample.getString(i, "u_clientspecimenid", "") + "\" />\n");
        if (null != dsAlgo && (dsAlgo.getRowCount() > 0)) {
            sbVmsQc.append("            <DataItem Name=\"Analysis Algorithm\" Value=\"" + dsAlgo.getString(0, "friendlyname", "") + "\" />\n");
        }
        sbVmsQc.append("        </MetaData>\n");
        sbVmsQc.append("        <ImageDetails>\n");
        sbVmsQc.append("            <ImageDetail Name=\"FilePath\" Value=\"" + imageFile + "\" />\n");
        if ("VMS".equalsIgnoreCase(typeopen)) {
            sbVmsQc.append("            <ImageDetail Name=\"PerformAnalysis\" Value=\"0\" />\n");
        } else {
            sbVmsQc.append("            <ImageDetail Name=\"PerformAnalysis\" Value=\"0\" />\n");
        }
        sbVmsQc.append("            <ImageDetail Name=\"TestCode\" Value=\"" + dsSample.getString(i, "lvtestcodeid") + "\" />\n");
        if (null != dsAlgo && (dsAlgo.getRowCount() > 0)) {
            sbVmsQc.append("            <ImageDetail Name=\"AlgorithmName\" Value=\"" + dsAlgo.getString(0, "name", "") + "\" />\n");
            sbVmsQc.append("            <ImageDetail Name=\"AlgorithmVendor\" Value=\"" + dsAlgo.getString(0, "vendor", "") + "\" />\n");
            sbVmsQc.append("            <ImageDetail Name=\"AlgorithmPlugInAssembly\" Value=\"" + dsAlgo.getString(0, "pluginassembly", "") + "\" />\n");
            sbVmsQc.append("            <ImageDetail Name=\"AlgorithmParameterSet\" Value=\"" + dsAlgo.getString(0, "parameterset", "") + "\" />\n");
        }
        sbVmsQc.append("        </ImageDetails>\n");
        sbVmsQc.append("        </Image>\n");
        sbVmsQc.append("  ");
        return sbVmsQc.toString();
    }

    private String createHNEXml(DataSet dsSample, DataSet accessDs, int i, String imageFile, String typeopen) {
        StringBuffer sbVmsQc = new StringBuffer();
        sbVmsQc.append("    <Image ExternalIdentifier=\"" + dsSample.getString(i, "s_sampleid") + "\" ImageSource=\"APERIO\" ");// +
        if ("VMS".equalsIgnoreCase(typeopen)) {
            sbVmsQc.append(" DefaultImage=\"" + (i == 0 ? "true" : "false") + "\" AllowEdit=\"false\" ");
        } else {
            sbVmsQc.append(" DefaultImage=\"" + (i == 0 ? "true" : "false") + "\" AllowEdit=\"true\" ");
        }
        sbVmsQc.append(" TitleBar=\"" + dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname") + " - " + dsSample.getString(i, "testname") +
                " - " + dsSample.getString(i, "s_sampleid") + " - Accession# " + dsSample.getString(i, "u_accessionid") + "\" " +
                " Description=\"" + dsSample.getString(i, "u_lastname") + ", " + dsSample.getString(i, "u_firstname") + " - " + dsSample.getString(i, "testname") + "\">" +
                "  Icon=\"images/SlideType_HE.gif\"\n");
        sbVmsQc.append("        <MetaData>\n");
        sbVmsQc.append("            <DataItem Name=\"Date Slide Run\" Value=\"" + "21 2122" + "\"/>\n");
        sbVmsQc.append("            <DataItem Name=\"Test Name\" Value=\"" + dsSample.getString(i, "testname") + "\" />\n");
        sbVmsQc.append("            <DataItem Name=\"Specimen Barcode\" Value=\"" + dsSample.getString(i, "s_sampleid") + "\" />\n");
        sbVmsQc.append("            <DataItem Name=\"Parent Specimen\" Value=\"" + dsSample.getString(i, "u_clientspecimenid", "") + "\" />\n");
        sbVmsQc.append("        </MetaData>\n");
        sbVmsQc.append("        <ImageDetails>\n");
        sbVmsQc.append("            <ImageDetail Name=\"FilePath\" Value=\"" + imageFile + "\" />\n");
        sbVmsQc.append("            <ImageDetail Name=\"PerformAnalysis\" Value=\"0\" />\n");
        sbVmsQc.append("            <ImageDetail Name=\"TestCode\" Value=\"" + dsSample.getString(i, "lvtestcodeid") + "\" />\n");
        sbVmsQc.append("        </ImageDetails>\n");
        sbVmsQc.append("        </Image>\n");
        sbVmsQc.append("  ");
        return sbVmsQc.toString();
    }
}
