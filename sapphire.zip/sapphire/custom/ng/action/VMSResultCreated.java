package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdidata.*;
import com.labvantage.sapphire.actions.sdidata.AddDataSet;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.action.EditDataItem;
import sapphire.action.EnterDataSet;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.Iterator;

/**
 * Created by dgupta on 7/25/2016.
 */
public class VMSResultCreated extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("externalimageidentifier");
        String cartoonregionimagepath = properties.getProperty("cartoonregionimagepath");
        String displayid = properties.getProperty("displayid");
        String regionid = properties.getProperty("regionid");
        String userid = properties.getProperty("userid");
        String version = properties.getProperty("version");
        String resultParamid="ResultCreated" ;
        String sumParamid="SumResult" ;
        String dataset = "1";
        PropertyList resultProps = properties.getPropertyList("results");
        PropertyList plEnterDataSet = new PropertyList();


        // find out work item is there or not if it is then check its HER2 or some thing else
        // accordingly apply result level param list HEr2 or other ER, PR etc.
        DataSet dsWorkitem = getQueryProcessor().getSqlDataSet("select keyid1, workitemid, workiteminstance, sdiworkitemid from sdiworkitem where sdcid='Sample' and keyid1='" + sampleid + "'");
        if(dsWorkitem == null || dsWorkitem.getRowCount() ==0) {               //throw new SapphireException("Test code not applied to sample  " + sampleid);
            properties.setProperty("Testcode", "Test code not applied to sample, workitem not found");
        }else{
            if(dsWorkitem.getString(0,"workitemid", "").contains("HER2")) {
                resultParamid = "ResultCreatedHer2";
                sumParamid = "SumResultHer2" ;
            } // else not required becuase defaul value is already set
        }
    // first apply sum level
        ApplySumParamList(sampleid, sumParamid, dsWorkitem);

        // check its new region and result created or region is moved and for the same region new result is created
        DataSet dsRegion = getQueryProcessor().getSqlDataSet("select distinct dataset, paramid  from sdidataitem " +
                " where paramlistid ='" + resultParamid +
                "'  and paramid='Regionid'  and ENTEREDTEXT='" + regionid + "'");
        // check if region does notexist then add new region level paramlist
        if (dsRegion == null || dsRegion.getRowCount() == 0) {
            dataset = applyNewResult(sampleid, resultParamid, properties, dsWorkitem);
        }else{
            // in case of existing regionid get the dataset of corresponding result
            dataset = dsRegion.getBigDecimal(0,"dataset").intValue() +"";
            plEnterDataSet.setProperty(EnterDataSet.PROPERTY_DATASET, dataset);
            editResult(sampleid, resultParamid,dataset,properties,dsWorkitem);
        }

        ///getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, plEnterDataSet);

    }

    private String editResult(String sampleid, String resultParamid, String dataset, PropertyList properties, DataSet dsWorkitem) throws ActionException {

        PropertyList resultProps = properties.getPropertyList("results");
        String otherColumn="displayidregionidcartoonregionimagepathuseridversionid";
        String paramName="" ;

        DataSet dsParam = getQueryProcessor().getSqlDataSet("select paramid, paramtype, numreplicates, usersequence, displayunderparamname,  ' ' entertext from PARAMLISTITEM " +
                "  where paramlistid='" + resultParamid + "' and lower(paramid) != 'regionid' order by usersequence") ;

        PropertyList props = new PropertyList();
        props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, resultParamid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset);


        DataSet dsCopy = dsParam.copy();
        for(int i=0 ; i< dsCopy.getRowCount(); i++){
            if(dsCopy.getRowCount() >0)
                dsCopy.deleteRow(i);
        }
        for(int i=0 ; i< dsParam.getRowCount(); i++){
            paramName = dsParam.getString(i, "displayunderparamname") ;
            if(otherColumn.contains(paramName)){
                if(properties.containsKey(paramName)) {
                    dsParam.setString(i, "entertext", properties.getProperty(paramName));
                    dsCopy.copyRow(dsParam, i, 1);
                }
            }else{
                if(resultProps.containsKey(paramName)) {
                    dsParam.setString(i, "entertext", resultProps.getProperty(paramName));
                    dsCopy.copyRow(dsParam, i, 1);
                }
            }
        }
        for(int i=1 ; i<= dsCopy.getRowCount(); i++){
            props.setProperty("paramid" + i,dsCopy.getString(i-1, "paramid") );
            props.setProperty("paramtype" + i,dsCopy.getString(i-1, "paramtype") );
            props.setProperty("replicateid" + i,dsCopy.getBigDecimal(i-1, "numreplicates").intValue() +"" );
            props.setProperty("enteredtext" + i, dsCopy.getString(i-1, "entertext") );
        }
        props.setProperty("params"  , "" + dsCopy.getRowCount() );
        props.setProperty("matchusersequence"  , "Y" );

        getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, props);

        return dataset;
    }
    private String applyNewResult(String sampleid, String resultParamid, PropertyList properties, DataSet dsWorkitem) throws ActionException {

        PropertyList resultProps = properties.getPropertyList("results");
        String otherColumn="displayidregionidcartoonregionimagepathuseridversionid";
        String paramName="" ;
        String dataset = "";

        DataSet dsParam = getQueryProcessor().getSqlDataSet("select paramid, paramtype, numreplicates, usersequence, displayunderparamname, u_show, ' ' entertext from PARAMLISTITEM " +
                "  where paramlistid='" + resultParamid + "'  order by usersequence") ;

        PropertyList props = new PropertyList();
        props.setProperty(AddDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(AddDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(AddDataSet.PROPERTY_PARAMLISTID, resultParamid);
        props.setProperty(AddDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(AddDataSet.PROPERTY_VARIANTID, "1");
        if(dsWorkitem == null || dsWorkitem.getRowCount() ==0){}else {
            props.setProperty("sourceworkitemid", dsWorkitem.getString(0, "workitemid", ""));
            props.setProperty("sourceworkiteminstance", "" + dsWorkitem.getBigDecimal(0, "workiteminstance").longValue());
        }
        props.setProperty("matchusersequence"  , "Y" );

        getActionProcessor().processAction(AddDataSet.ID, AddDataSet.VERSIONID, props);
        DataSet dsPl = new DataSet(props.getProperty("newdatasetinstancexml")) ;
        dataset = dsPl.getString(0, "dataset") ;
        props.clear();   props.clear();

        props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, resultParamid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset);

        for(int i=0 ; i< dsParam.getRowCount(); i++){
            paramName = dsParam.getString(i, "displayunderparamname") ;
            if(otherColumn.contains(paramName)){
                if(properties.containsKey(paramName.trim()))
                dsParam.setString(i,"entertext", properties.getProperty(paramName) ) ;
            }else{
                if(resultProps.containsKey(paramName.trim()))
                dsParam.setString(i,"entertext", resultProps.getProperty(paramName) ) ;
            }
        }
        for(int i=1 ; i<= dsParam.getRowCount(); i++){
            props.setProperty("paramid" + i,dsParam.getString(i-1, "paramid") );
            props.setProperty("paramtype" + i,dsParam.getString(i-1, "paramtype") );
            props.setProperty("replicateid" + i, "" +dsParam.getBigDecimal(i-1, "numreplicates").intValue() );
            props.setProperty("enteredtext" + i, dsParam.getString(i-1, "entertext") );
        }
        props.setProperty("params"  , "" + dsParam.getRowCount() );
        props.setProperty("matchusersequence"  , "Y" );

        getActionProcessor().processAction(EnterDataSet.ID, EnterDataSet.VERSIONID, props);

        props = new PropertyList();
        props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
        props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, resultParamid);
        props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
        props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
        props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset);
        props.setProperty("paramid" ,dsParam.getColumnValues("paramid", ";") );
        props.setProperty("paramtype" ,dsParam.getColumnValues( "paramtype", ";") );
        props.setProperty("replicateid" ,  dsParam.getColumnValues("numreplicates", ";") );
        props.setProperty("u_show" , dsParam.getColumnValues( "u_show", ";") );

        getActionProcessor().processAction(EditDataItem.ID, EditDataItem.VERSIONID, props);

        return dataset;
    }

    private void ApplySumParamList(String sampleid, String sumParamid, DataSet dsWorkitem) throws ActionException {
        DataSet dsSumParamlist = getQueryProcessor().getSqlDataSet("select keyid1, paramlistid, paramlistversionid from sdidata where sdcid='Sample' " +
                "  and paramlistid='" +  sumParamid + "'  and keyid1='" + sampleid + "'");

//Check Sum level aramlist applied or not if not applied apply one , only one instance of
// SumImageRegion need to apply not more
        if(dsSumParamlist == null || dsSumParamlist.getRowCount() ==0){

            DataSet dsParam = getQueryProcessor().getSqlDataSet("select paramid, paramtype, numreplicates, usersequence, displayunderparamname, u_show, ' ' entertext from PARAMLISTITEM " +
                    "  where paramlistid='" + sumParamid + "'  order by usersequence") ;

            PropertyList props = new PropertyList();
            props.setProperty(AddDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(AddDataSet.PROPERTY_KEYID1, sampleid);
            props.setProperty(AddDataSet.PROPERTY_PARAMLISTID, sumParamid);
            props.setProperty(AddDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
            props.setProperty(AddDataSet.PROPERTY_VARIANTID, "1");
            if(dsWorkitem == null || dsWorkitem.getRowCount() ==0){}else {
                props.setProperty("sourceworkitemid", dsWorkitem.getString(0, "workitemid", ""));
                props.setProperty("sourceworkiteminstance", "" + dsWorkitem.getBigDecimal(0, "workiteminstance").longValue());
            }
            getActionProcessor().processAction(AddDataSet.ID, AddDataSet.VERSIONID, props);
            DataSet dsPl = new DataSet(props.getProperty("newdatasetinstancexml")) ;
            String dataset = dsPl.getString(0, "dataset") ;

            props = new PropertyList();
            props.setProperty(EnterDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(EnterDataSet.PROPERTY_KEYID1, sampleid);
            props.setProperty(EnterDataSet.PROPERTY_PARAMLISTID, sumParamid);
            props.setProperty(EnterDataSet.PROPERTY_PARAMLISTVERSIONID, "1");
            props.setProperty(EnterDataSet.PROPERTY_VARIANTID, "1");
            props.setProperty(EnterDataSet.PROPERTY_DATASET, dataset);
            props.setProperty("paramid" ,dsParam.getColumnValues("paramid", ";") );
            props.setProperty("paramtype" ,dsParam.getColumnValues( "paramtype", ";") );
            props.setProperty("replicateid" ,  dsParam.getColumnValues("numreplicates", ";") );
            props.setProperty("u_show" , dsParam.getColumnValues( "u_show", ";") );

            getActionProcessor().processAction(EditDataItem.ID, EditDataItem.VERSIONID, props);
        }
    }
}


       /* DataSet dsVms = getQueryProcessor().getSqlDataSet("select * from u_vmsimageregion where s_sampleid = '" + sampleid + "' and regionid='" + regionid
                + "' and displayid='" + displayid + "'");
        if (null == dsVms || dsVms.getRowCount() == 0) {
            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID, "Sample");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1, sampleid);
            props.setProperty("displayid", displayid);
            props.setProperty("regionid", regionid);
            props.setProperty("cartoonimagepath", cartoonregionimagepath);
            props.setProperty("userid", userid);
            props.setProperty("version", version);
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "vmsimageregion_link");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        }else{
            newkeyid = dsVms.getString(0, "aperiostatusid");
            PropertyList props = new PropertyList();
            props.setProperty(EditSDIDetail.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDIDetail.PROPERTY_KEYID1, sampleid);
            props.setProperty("aperiostatusid", newkeyid);
            props.setProperty("displayid", displayid);
            props.setProperty("regionid", regionid);
            props.setProperty("cartoonimagepath", cartoonregionimagepath);
            props.setProperty("userid", userid);
            props.setProperty("version", version);
            props.setProperty(AddSDIDetail.PROPERTY_LINKID, "vmsimageregion_link");
            getActionProcessor().processAction(EditSDIDetail.ID, EditSDIDetail.VERSIONID, props);
        }*/


       /* DataSet dsVms = getQueryProcessor().getSqlDataSet("select * from u_vmsimageregion where s_sampleid = '" + sampleid + "' and regionid='" + regionid + "' and displayid='" + displayid + "'");

        if (null != dsVms && dsVms.getRowCount() > 0) {
            newkeyid = dsVms.getString(0, "aperiostatusid");
        }*/
/*
        StringBuilder sbDisplayid = new StringBuilder();
        StringBuilder sbRegionid = new StringBuilder();
        StringBuilder sbDetailPk = new StringBuilder();
        StringBuilder resultId = new StringBuilder();
        StringBuilder resultValue = new StringBuilder();
        Iterator it = resultProps.keySet().iterator();
        int i=1;
        while (it.hasNext()) {
            resultkey = (String) it.next();
            resultId.append(";").append(resultkey);
            resultValue.append(";").append(resultProps.getProperty(resultkey));
           // System.out.println("result props -" + resultkey + "   value  " + resultProps.getProperty(resultkey));
            sbDisplayid.append(";").append(displayid);
            sbRegionid.append(";").append(regionid);
            sbDetailPk.append(";").append(regionid+i);
            i++;
        }
        PropertyList vmsResult = new PropertyList();
        vmsResult.setProperty(AddSDIDetail.PROPERTY_SDCID, "Sample");
        vmsResult.setProperty(AddSDIDetail.PROPERTY_KEYID1, sampleid);
        vmsResult.setProperty("displayid", sbDisplayid.toString().substring(1));
        vmsResult.setProperty("regionid", sbRegionid.toString().substring(1));
        vmsResult.setProperty("vmsresultid", sbDetailPk.toString().substring(1));
        vmsResult.setProperty("resultid", resultId.toString().substring(1));
        vmsResult.setProperty("resultvalue", resultValue.toString().substring(1));
        vmsResult.setProperty(AddSDIDetail.PROPERTY_SEPARATOR, ";");
        vmsResult.setProperty(AddSDIDetail.PROPERTY_LINKID, "vmsresult_link");
        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, vmsResult);
        System.out.println("result props -" + resultId.toString() + "   value  " + resultValue.toString());*/

