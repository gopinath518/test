package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;


/**
 * Created by dgupta on 8/16/2016.
 */
public class Check72Hour extends BaseAction {


    /*
    *   This class is used to find sample laying in one tramstop for more than 72 hours
    *
    * */
    public void processAction(PropertyList properties) throws SapphireException {
        String sql = "select s_sampleid, collectiondt, ROUND(24*(sysdate -collectiondt), 2) || ' passed'  hr from s_sample where 24*(sysdate -collectiondt) > 68 and u_currentmovementstep = 'FreshPrep'";
        DataSet dsSample = getQueryProcessor().getSqlDataSet(sql);
        if (dsSample != null && dsSample.getRowCount() > 0) {
            PropertyList pl = new PropertyList();
            pl.setProperty("sdcid", "Sample");
            pl.setProperty("keyid1", dsSample.getColumnValues("s_sampleid", ";"));
            pl.setProperty("u_morethan72", dsSample.getColumnValues("hr", ";"));
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
    }
}
