package sapphire.custom.ng.action.flow;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowAddPanel extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException  {
        String cellsuspID = properties.getProperty("sampleid","");
        String panelID = properties.getProperty("panelid","");
        String batchID = properties.getProperty("batchid","");
        String comments = properties.getProperty("comments", "");
        String allsampleID;
        String parentID;
        String tubeID;
        String sampleTestcodeMapID;
        DataSet dsfilter;


        if(Util.isNull(cellsuspID)){
            throw new SapphireException("Specimen id could not be blank");
        }
        if(Util.isNull(panelID)){
            throw new SapphireException("Panel id could not be blank");
        }
        if(Util.isNull(batchID)){
            throw new SapphireException("Batch id could not be blank");
        }
        String sql = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, StringUtil.replaceAll(cellsuspID, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds != null && ds.size() >0) {
            tubeID = ds.getColumnValues("s_sampleid", ";");
            parentID = ds.getColumnValues("u_rootsample", ";");
            parentID = Util.getUniqueList(parentID,";",true);
            allsampleID = parentID+";"+tubeID+";"+ cellsuspID;


            String panelsql = Util.parseMessage(FlowSql.GET_TESTSTATUS_BY_SAMPLE_PANEL, StringUtil.replaceAll(panelID, ";", "','"), StringUtil.replaceAll(allsampleID, ";", "','"));
            DataSet dspanel = getQueryProcessor().getSqlDataSet(panelsql);
            if (dspanel != null && dspanel.size() > 0) {
                HashMap<String, String> hmap = new HashMap<>();
                hmap.put("teststatus", "Cancelled");
                dsfilter = dspanel.getFilteredDataSet(hmap);
                if (dsfilter.size() == 0) {
                    throw new SapphireException("Panel"+Util.getUniqueList(dspanel.getColumnValues("lvtestpanelid", ";"),";",true)+" is already attached with this sample");
                } else {
                    String panelarr[]= panelID.split(";");
                    String dsfilterpanel =Util.getUniqueList(dsfilter.getColumnValues("lvtestpanelid", ";"),";",true);
                    for(int i=0;i<panelarr.length;i++){
                            if(!dsfilterpanel.contains(panelarr[i])){
                               addPanel(parentID, cellsuspID,panelarr[i],batchID);
                            }
                    }
                    sampleTestcodeMapID = dsfilter.getColumnValues("U_SAMPLETESTCODEMAPID", ";");
                    activatePanel(sampleTestcodeMapID);
                }

            } else {
                addPanel(parentID, cellsuspID, panelID,batchID);


            }
            /**
             * Function to update accession comment while
             * adding new panel to tube
             */
            this.updateAccessionComment(comments, 
            		Util.getUniqueList(ds.getColumnValues("u_accessionid", ";"), ";", true));
            /**
             * END
             */
        }

//        throw new SapphireException("Test");


    }

	private void addPanel(String parentid,String cellsuspid, String panelid,String batchid)throws SapphireException {
        String allsample = parentid+";"+cellsuspid;
        int copy = StringUtil.split(allsample, ";").length;
        String panelarr[] = StringUtil.split(panelid, ";");
        String tubesample="";
        String parentsamplearr[] = parentid.split(";");
        PropertyList pl = new PropertyList();
        for(int i=0;i<panelarr.length;i++) {
            pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID, allsample);
            pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE, StringUtil.repeat(panelarr[i], copy, ";"));
            pl.setProperty("flowtubesample", "Y");

            try {
                getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
            } catch (Exception e) {
                throw new SapphireException("Error.Unable to add panel : " + e.getMessage());
            }
        }
        for(int i =0;i<parentsamplearr.length;i++){
            pl.clear();
            pl.setProperty(CreateFlowWorkFlowSample.PROPERTY_KEYID1,parentsamplearr[i]);
            pl.setProperty(CreateFlowWorkFlowSample.PROPERTY_FLAG, "flowaddpanel");
            pl.setProperty(CreateFlowWorkFlowSample.PROPERTY_PANEL, panelid);
            try {
                getActionProcessor().processAction(CreateFlowWorkFlowSample.ID, CreateFlowWorkFlowSample.VERSIONID, pl);
            }
             catch(Exception e){
                throw new SapphireException("Error.Unable to CreateFlowWorkFlowSample : "+e.getMessage());
            }
            tubesample += pl.getProperty("tubeid","");
        }
        if(!Util.isNull(tubesample)) {
            pl.clear();
            pl.setProperty("sampleid", tubesample);
            pl.setProperty("currentmovementstep", "FlowStainingBatch");
            pl.setProperty("totramstop", "StainingBatch");
            pl.setProperty("currentuser", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction("FlowNextStep", "1", pl);
            } catch (Exception ex) {
                throw new SapphireException("Error.Unable to process FlowNextStep : " + ex.getMessage());
            }
            pl.clear();
            int copyoftube = StringUtil.split(tubesample, ";").length;
            pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatchFlowSample");
            pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copyoftube));
            pl.setProperty("u_ngbatchid", StringUtil.repeat(batchid, copyoftube, ";"));
            pl.setProperty("sampleid", tubesample);
            try {
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
            } catch (Exception ex) {
                throw new SapphireException("Error.Unable to process FlowNextStep : " + ex.getMessage());
            }
        }


    }

    private void activatePanel(String sampletestcodemapid)throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        pl.setProperty(EditSDI.PROPERTY_KEYID1,sampletestcodemapid );
        pl.setProperty("teststatus", "In Progress");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

    }

    /***********************************
     * Method to update accesion comment
     * while adding panel to existing tube
     * @param comment
     * @param accessionId
     * @throws SapphireException
     ***********************************/
    private void updateAccessionComment(String comment, String accessionId) throws SapphireException{
		// TODO Auto-generated method stub
    	if(!Util.isNull(accessionId) && !Util.isNull(comment)){
    		PropertyList pl = new PropertyList();
    		pl.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
    		pl.setProperty(AddSDI.PROPERTY_COPIES, ""+StringUtil.split(accessionId, ";").length);
    		pl.setProperty("comments", comment);
    		pl.setProperty("accessionid", accessionId);
    		pl.setProperty("commentby", connectionInfo.getSysuserId());
    		pl.setProperty("commentdt", "n");
    		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
    	}
	}


}
