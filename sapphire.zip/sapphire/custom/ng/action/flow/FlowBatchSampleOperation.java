package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
/**
 * Created by soumik.sen on 8/2/2018.
 */

public class FlowBatchSampleOperation extends BaseAction {
    String currmovstep = "";
    String currtramstop = "";
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("sampleid","");
        String ngBatchFlowSampleId = properties.getProperty("ngbatchflowsampleid","");
        String batchId = properties.getProperty("batchid","");
        String batchOrigin = properties.getProperty("origin","");
        String mode = properties.getProperty("mode","");

        if(Util.isNull(sampleId)) {
            logger.info("Sampleid is blank ");
            throw new SapphireException("Something went wrong please contact your administrator");
        }
        
        if(Util.isNull(batchOrigin))  {
            logger.info("batchOrigin is blank ");
            throw new SapphireException("Something went wrong please contact your administrator");
        }
        if(batchOrigin.equalsIgnoreCase("FlowLysing"))
            addSampleLysingBatch(batchId,ngBatchFlowSampleId,sampleId,mode);
        else if(batchOrigin.equalsIgnoreCase("FlowStaining"))
            addSampleStainingBatch(batchId,ngBatchFlowSampleId,sampleId,mode);
        
        else if(batchOrigin.equalsIgnoreCase("FlowAcquisition"))
            addSampleAcquisitionBatch(batchId,ngBatchFlowSampleId,sampleId,mode);
//        throw new SapphireException("Test");
    }
    private void addSampleLysingBatch(String batchId,String ngBatchFlowSampleId,String sampleId,String mode) throws SapphireException {

        if (!Util.isNull(sampleId) && !Util.isNull(mode) ) {
                if ("Add".equalsIgnoreCase(mode)) {
                    currmovstep = "LysingBatch";
                    currtramstop = "Lysing Batch";
                    addSampleDetail(sampleId,batchId);
                }else if("Remove".equalsIgnoreCase(mode)){
                    currmovstep = "FlowLysing";
                    currtramstop = "Lysing";
                    removeSampleDetail(sampleId,ngBatchFlowSampleId, batchId);
                }
                changeSampleCurrentMovement(sampleId,currmovstep);
                changeSampleCurrentTramstop(sampleId,currtramstop,"");
        }
    }
    private void addSampleStainingBatch(String batchId,String ngBatchFlowSampleId,String sampleId,String mode) throws SapphireException {
        String tubeSampleId = "";
        String allsampleids = sampleId;
        if (!Util.isNull(sampleId) && !Util.isNull(mode)) {
        	String sql = Util.parseMessage(FlowSql.VERIFY_FOR_CHILD_CS, StringUtil.replaceAll(sampleId, ";", "','"));
        	DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            sql = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, StringUtil.replaceAll(ds.getColumnValues("p_sample", ";"), ";", "','"));
            ds = getQueryProcessor().getSqlDataSet(sql);
            if(ds != null && ds.size() >0) {
                tubeSampleId = ds.getColumnValues("s_sampleid", ";");
                //ngBatchFlowSampleId += ";" + ds.getColumnValues("u_ngbatchflowsampleid", ";");
                allsampleids += ";" + tubeSampleId;
                if ("Add".equalsIgnoreCase(mode)) {
                    currmovstep = "FlowStainingBatch";
                    currtramstop = "Staining";
                    addSampleDetail(allsampleids, batchId);
                    changeSampleCurrentMovement(allsampleids, currmovstep);
                    changeSampleCurrentTramstop(allsampleids, currtramstop, "staining");
                } else if ("Remove".equalsIgnoreCase(mode)) {
                    currmovstep = "FlowStaining";
                    currtramstop = "Staining Batch";
                    changeSampleCurrentMovement(sampleId, currmovstep);
                    changeSampleCurrentTramstop(sampleId, currtramstop, "staining");
                    removeSampleDetail(allsampleids, ngBatchFlowSampleId, batchId);
                    removeTubeSampleMovementstep(tubeSampleId);
                }
            }else{
            	currmovstep = "FlowStaining";
                currtramstop = "Staining Batch";
                changeSampleCurrentMovement(sampleId, currmovstep);
                changeSampleCurrentTramstop(sampleId, currtramstop, "staining");
                removeSampleDetail(allsampleids, ngBatchFlowSampleId, batchId);
            }
        }
    }
    private void addSampleAcquisitionBatch(String batchId,String ngBatchFlowSampleId,String sampleId,String mode) throws SapphireException {

        if (!Util.isNull(sampleId) && !Util.isNull(mode) ) {
            if ("Add".equalsIgnoreCase(mode)) {
                currmovstep = "AcquisitionBatch";
                currtramstop = "Acquisition Batch";
                addSampleDetail(sampleId,batchId);
            }else if("Remove".equalsIgnoreCase(mode)){
                currmovstep = "FlowAcquisition";
                currtramstop = "Acquisition";
                removeSampleDetail(sampleId,ngBatchFlowSampleId, batchId);
            }
            changeSampleCurrentMovement(sampleId,currmovstep);
            changeSampleCurrentTramstop(sampleId,currtramstop,"");
        }
    }


    private void changeSampleCurrentMovement(String sampleid, String sampleCurrStep) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currentmovementstep", sampleCurrStep);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
        catch (SapphireException se) {
            throw new SapphireException("Error.Unable to add into  Sample : "+se.getMessage());
        }
    }
    private void changeSampleCurrentTramstop(String sampleid, String sampleCurrTramstop,String flag) throws SapphireException {
        String currentdept = connectionInfo.getDefaultDepartment();
        PropertyList pl = new PropertyList();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currenttramstop", sampleCurrTramstop);
        if(flag.equalsIgnoreCase("staining")) {
            pl.setProperty("custodialdepartmentid", currentdept);
        }

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }
        catch (SapphireException se) {
            throw new SapphireException("Error.Unable to add into  Trackitem : "+se.getMessage());
        }
    }
    private void addSampleDetail(String sampleid,String batchid) throws SapphireException {
        PropertyList pl = new PropertyList();
        int copy = StringUtil.split(sampleid, ";").length;
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatchFlowSample");
        pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copy));
        pl.setProperty("u_ngbatchid", StringUtil.repeat(batchid, copy, ";"));
        pl.setProperty("sampleid", sampleid);
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
        } catch (SapphireException se) {
            throw new SapphireException("Error.Unable to add into  NGBatch : "+se.getMessage());
        }

    }
    private void removeSampleDetail(String sampleid,String ngBatchFlowSampleId,String batchId) throws SapphireException {
    	
    	String query = Util.parseMessage(FlowSql.GET_BATCH_FLOW_SAMPLE_ID, StringUtil.replaceAll(sampleid,";","','"),StringUtil.replaceAll(batchId,";","','"));
    	DataSet ds = getQueryProcessor().getSqlDataSet(query);
    	PropertyList pl = new PropertyList();
    	if(ds != null && ds.getRowCount() > 0){
    		try {
    			pl.setProperty(DeleteSDI.PROPERTY_SDCID, "NGBatchFlowSample");
    			pl.setProperty(DeleteSDI.PROPERTY_KEYID1, ds.getColumnValues("u_ngbatchflowsampleid", ";"));
    			getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID,pl);
    		} catch (SapphireException se) {
    			throw new SapphireException("Error.Unable to delete from  NGBatch : "+se.getMessage());
    		}
    	}

    }
    private void removeTubeSampleMovementstep(String sampleid) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currentmovementstep", "");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
        catch (SapphireException se) {
            throw new SapphireException("Error.Unable to remove  Sample in staining : "+se.getMessage());
        }
        pl.clear();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currenttramstop", "");
        pl.setProperty("custodialdepartmentid", "");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }
        catch (SapphireException se) {
            throw new SapphireException("Error.Unable to remove from  Trackitem in staining : "+se.getMessage());
        }


}
}
