package sapphire.custom.ng.action.flow;

import java.io.File;
import java.io.FileWriter;

import sapphire.SapphireException;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDIAttachment;
import sapphire.custom.ng.flow.xml.launchfile.GenerateFCSLaunchFile;
import sapphire.custom.ng.flow.xml.launchfile.LauchFileProperty;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class LaunchFCSExpress extends BaseAction{
	
	String outputLaunchFileFolder = "";
	String batFilePath="";
	String unixPath = "";
	String mappedWindowPath = "";
	String lmdOutputPath = "";
	String labname = "";
	String launchSubFolderPath = "";
	String windowPath = "";
	DataSet folderDS = null;
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String accessionId = properties.getProperty("accessionid", "");
		if("".equals(accessionId))
			throw new SapphireException("Accession Id not found");
			
		getLaunchPath(accessionId);
		generateLaunchFile(accessionId);
	}
	
	private void getLaunchPath(String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_FLOW_LAUNCH_PATH,connectionInfo.getDefaultDepartment()); 
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		
		if(ds != null && ds.size()>0){
			unixPath = ds.getValue(0, "unixpath", "").trim();
			launchSubFolderPath = ds.getValue(0, "launchfileoutputpath", "").trim();
			labname = ds.getValue(0, "labname", "").trim();
			mappedWindowPath = ds.getValue(0, "windowpath", "").trim();
			lmdOutputPath = ds.getValue(0, "lmdoutputpath", "").trim();
		}
		
		 getFolderPath(accessionId);
		 outputLaunchFileFolder =  Util.generateIHCLocPath(unixPath+File.separator+labname, folderDS.getValue(0, "sponcername", ""), 
					folderDS.getValue(0, "projname", ""), "Flow", launchSubFolderPath);
		 
		 windowPath = mappedWindowPath+File.separator+outputLaunchFileFolder.substring(outputLaunchFileFolder.lastIndexOf(labname));
		 
		 batFilePath = outputLaunchFileFolder;
		
		if("".equals(outputLaunchFileFolder) || "".equals(batFilePath))
			throw new SapphireException("Please specify the output directories of FCS Express Launch files/Batch File in the Site/Environment Prop Tramstop");
	}
	
	private void generateLaunchFile(String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_LAUNCH_FILE_DETAIL, accessionId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		
		if(ds != null && ds.size()>0){
			String filePath = StringUtil.replaceAll(ds.getValue(0, "filename", ""), "\\", "/");
			String fileName = StringUtil.split(filePath.substring(filePath.lastIndexOf("/")+1), " ")[0]+"*.LMD" ;
			String finalPath =  filePath.substring(0, filePath.lastIndexOf("/"))+File.separator+fileName;
			String windowPath = mappedWindowPath+File.separator+lmdOutputPath+File.separator+finalPath.substring(finalPath.lastIndexOf("success"));
			windowPath = windowPath.replaceAll("/", "\\\\");
			
			LauchFileProperty fileProperty = new LauchFileProperty();
			fileProperty.setVersion("1");
			fileProperty.setDelete_on_load("false");
			fileProperty.setLayout_ID("A");
			fileProperty.setFile_mask(windowPath);
//			fileProperty.setFile_mask("C:\\Users\\subhendu.pal\\Desktop\\Sample LMD file.LMD");
			fileProperty.setType("file_list");
			
			String keywordName = "";
			String keywordValue = "";
			String [] columnList = ds.getColumns();
			for(int i=0; i<columnList.length; i++){
				
				if(!"filename".equalsIgnoreCase(columnList[i])){
					if("specdetail".equalsIgnoreCase(columnList[i]))
						keywordName += "SpecimenId;SpecimenType;";
					else
						keywordName += columnList[i]+";";
					
					keywordValue += ds.getValue(0, columnList[i], "")+";";
				}
			}
			fileProperty.setName(keywordName);
			fileProperty.setValue(keywordValue);
			
			fileProperty.setOutputLaunchFilePath(outputLaunchFileFolder);
			fileProperty.setLaunchFileName("file_"+accessionId+".fe_launch");
			
			GenerateFCSLaunchFile fcsLaunchFile = new GenerateFCSLaunchFile();
			fcsLaunchFile.setFCSLaunchValue(fileProperty);
			
			launchFCSExpress("file_"+accessionId+".fe_launch",accessionId);
		}
	}
	
	
	
	private void launchFCSExpress(String fileName, String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_FCS_VERSION_AND_PATH, accessionId,connectionInfo.getSysuserId());
		String fcsPath = "";
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.size()>0){
			String ver = ds.getValue(0, "fcsversion", "");
			if("".equals(ver))
				throw new SapphireException("FCS Version Id not set in the Project Level ");
			else if("4".equals(ver))
				fcsPath = ds.getValue(0, "u_flowfcsexp4location", "");
			else if("6".equals(ver))
				fcsPath = ds.getValue(0, "u_flowfcsexp6location", "");
		}
		File f1 = new File(outputLaunchFileFolder+File.separator+fileName);
		FileWriter writer = null;
		File file = null;
			
		try{
			
			String tempWindowPath = windowPath+File.separator+fileName;
			tempWindowPath = tempWindowPath.replaceAll("/", "\\\\");
			String batFileName = "bat_fcs_"+connectionInfo.getSysuserId()+".bat";
			String content = "start \"FCS\" \""+fcsPath+"\" \""+tempWindowPath+"\"";  
			file = new File(batFilePath+File.separator+batFileName);
			  
			
			if(f1.isFile() && f1.exists()){
				if (file.createNewFile()){
				}
				writer = new FileWriter(file);
				writer.write(content);
				writer.close();
				loadSDIAttachment( accessionId, "Batch",batFilePath,batFileName);
			}
		}catch (Exception e) {
			throw new SapphireException("Error in FCS Express"+e.getMessage());
		}finally{
			file.delete();
		}
		
	}
	
	private void loadSDIAttachment(String keyid1, String type, String filePath,String fileName) throws SapphireException{
		PropertyList pl = new PropertyList();
		
		pl.setProperty(DeleteSDIAttachment.PROPERTY_SDCID, "Accession");
		pl.setProperty(DeleteSDIAttachment.PROPERTY_KEYID1, keyid1);
		pl.setProperty(DeleteSDIAttachment.PROPERTY_KEYID2, "FCSBatch");
		
		getActionProcessor().processAction(DeleteSDIAttachment.ID, DeleteSDIAttachment.VERSIONID, pl);
		
		pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
		pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1);
		pl.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "FCSBatch");
		pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, fileName);
		pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filePath+File.separator+fileName);
		pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "S");
		pl.setProperty("u_attachmenttype", type);
        getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
	}
	
	private DataSet getFolderPath(String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_GENERIC_FOLDER_DETAIL, accessionId);
		folderDS = getQueryProcessor().getSqlDataSet(sql);
		if(folderDS == null || folderDS.size() == 0){
			logger.error("Please specify the Flow Launch file directories");
			throw new SapphireException("Please specify the Launch file directories");
		}
		
		return folderDS;
	}

}
