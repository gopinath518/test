package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.AddSDIAttribute;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

public class FlowNextStep extends BaseAction {
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String sampleId = properties.getProperty("sampleid", "");
		if(Util.isNull(sampleId))
			properties.setProperty("msg", "No sample found");
		else {
			String toCurrentMovementStep = properties.getProperty("currentmovementstep", "");
			String stepName = properties.getProperty("stepname", "");
			String toTramStop = properties.getProperty("totramstop", "");
			String currentUser = connectionInfo.getSysuserId();
			String previousMovementStep = properties.getProperty("previousmovementstep", "");
			
			if(!Util.isNull(previousMovementStep)){
				toTramStop = "Staining Batch";
				if("FlowLysing".equalsIgnoreCase(previousMovementStep)){
					toTramStop = "Lysing Batch";
				}
				toCurrentMovementStep = previousMovementStep;
			}

			moveFlowSample(sampleId, toCurrentMovementStep, stepName, toTramStop,currentUser);
			properties.setProperty("msg", "Sample successfully moved " + sampleId);
		}
	}
	
	private void moveFlowSample(String sampleId,String toCurrentMovementStep,String stepName, String toTramStop,String currentUser) throws SapphireException{
		 
		 PropertyList pl = new PropertyList();
		 pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		 pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
		 pl.setProperty("u_currentmovementstep", toCurrentMovementStep);
		 pl.setProperty("u_previousmovementstep", "(null)");
		 pl.setProperty("u_flowsamplereceivedt", "n");
		 
		 getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		 
		 updateTrackItem(sampleId,toTramStop,currentUser);
		 if("Processing".equalsIgnoreCase(stepName)){
			 addProcessingComplete(sampleId);
		 }
		 if("Lysing".equalsIgnoreCase(stepName)){
		 	addLysingComplete (sampleId);
		 }
	}
	
	private void updateTrackItem(String sampleId,String toTramStop, String currentUser) throws SapphireException{
		 PropertyList pl = new PropertyList();
		 pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		 pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
		 pl.setProperty("u_currenttramstop", toTramStop);
		 pl.setProperty("custodialuserid", currentUser);
		 pl.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
		 
		 getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	 }
	private void addProcessingComplete(String sampleId) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDIAttribute.PROPERTY_SDCID,"Sample");
		pl.setProperty(AddSDIAttribute.PROPERTY_ATTRIBUTEID,"fprocesscompleteby;fprocesscompletedt");
		pl.setProperty(AddSDIAttribute.PROPERTY_VALUE,connectionInfo.getSysuserId()+";n");
		pl.setProperty(AddSDIAttribute.PROPERTY_KEYID1, sampleId);
		getActionProcessor().processAction(AddSDIAttribute.ID, AddSDIAttribute.VERSIONID, pl);
	}
	private void addLysingComplete(String sampleId) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDIAttribute.PROPERTY_SDCID,"Sample");
		pl.setProperty(AddSDIAttribute.PROPERTY_ATTRIBUTEID,"lysedby;lyseddate");
		pl.setProperty(AddSDIAttribute.PROPERTY_VALUE,connectionInfo.getSysuserId()+";n");
		pl.setProperty(AddSDIAttribute.PROPERTY_KEYID1, sampleId);
		getActionProcessor().processAction(AddSDIAttribute.ID, AddSDIAttribute.VERSIONID, pl);
	}
}
