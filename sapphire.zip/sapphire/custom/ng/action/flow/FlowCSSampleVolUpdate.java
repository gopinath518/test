/**
 * 
 */
package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.CalcCellCount;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 * 
 * Action added for providing volume to 
 * concentrated cell suspension sample 
 * and diluted cell suspension sample
 *
 */
public class FlowCSSampleVolUpdate extends BaseAction{

	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String keyId1 = properties.getProperty("keyid1", "");
		String volume = properties.getProperty("volume", "");
		String volumeUnit = properties.getProperty("volumeunit", "");
		String cellCount = properties.getProperty("cellcount", "");
		String cellCountUnit = properties.getProperty("cellcountunit", "");
		String modifiedVolume = properties.getProperty("modifiedvol", "");
		
		//String[] sample = StringUtil.split(keyId1, ";");
		//for(int i=0; i<sample.length; i++){
			this.updateCellCount(keyId1, volume, volumeUnit, cellCount, cellCountUnit);
			this.updateCSVolume(keyId1, volume, cellCount);
		//}
		
	}

	/************************************
	 * Updating CS volume based on 
	 * initial amount and used flow volume
	 * @param keyId1
	 * @param modifiedVolume
	 * @param cellCount 
	 * @throws ActionException
	 ************************************/
	private void updateCSVolume(String keyId1, String changeVol, String changeCellCount) throws SapphireException {
		String flowSampleId = "";
		String tempSampleId = "";
		String[] tempKeyId1 = StringUtil.split(keyId1, ";", true);
		
		PropertyList pl = new PropertyList();
		String query = Util.parseMessage(FlowSql.GET_INTERNAL_ID_BY_SAMPLE, StringUtil.replaceAll(keyId1,";","','"));
		DataSet ds = getQueryProcessor().getSqlDataSet(query);
		if(ds != null && ds.getRowCount() > 0){
			
			for(int i=0; i<tempKeyId1.length; i++){
				String[] modifiedVolume = StringUtil.split(changeVol, ";", true);
				String[] cellCount = StringUtil.split(changeCellCount, ";", true);
				int dsRowNum = ds.findRow("s_sampleid", tempKeyId1[i]);
				
				flowSampleId = ds.getValue(dsRowNum, "u_flowsampleid", "");
				tempSampleId = ds.getValue(dsRowNum, "s_sampleid", "");

				if(!Util.isNull(flowSampleId)){
					if(flowSampleId.contains("CSd")){
						double dilutedQty = 0.0d;
				        
				        String sql = Util.parseMessage(FlowSql.GET_SOURCE_FROM_DEST_SAMPLE, tempSampleId);
				        DataSet rs = getQueryProcessor().getSqlDataSet(sql);
				        if(rs != null && rs.getRowCount() > 0){
				        	dilutedQty = Double.parseDouble(modifiedVolume[i]);
				        	double remQty = rs.getDouble(i, "qtycurrent", 0.0d);
				        	if(dilutedQty > remQty){
				        		throw new SapphireException("The volume of dilution tube can't be greater than cell suspension specimen");
				        	}else{
				        		this.setInitialAmount(tempSampleId, modifiedVolume[i], pl, cellCount[i]);
				        		double remainingCSQty = remQty - dilutedQty;
				        		
				        		pl.clear();
				        		pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
				        		pl.setProperty(EditTrackItem.PROPERTY_KEYID1, rs.getValue(i, "s_sampleid", ""));
				        		pl.setProperty("qtycurrent", ""+remainingCSQty);
				        		getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
				        	}
				        	pl.clear();
				        	pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
							pl.setProperty(EditSDI.PROPERTY_KEYID1, flowSampleId);
							pl.setProperty("u_flowvoltobeused", rs.getValue(i, "sourcesampleid", ""));
					        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
					        
					        pl.clear();
					        double initialAmt = rs.getDouble(i, "u_initialamount", 0.0d);
					        double usedVol = rs.getDouble(i, "u_flowvoltobeused", 0.0d);
					        double remainQty = initialAmt - usedVol;
					        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
					        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, rs.getValue(i, "sourcesampleid", ""));
					        pl.setProperty("qtycurrent", ""+remainQty);
					        pl.setProperty("qtyunits", "ml");
					        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
				        }
					}else{
						this.setInitialAmount(tempSampleId, modifiedVolume[i], pl, cellCount[i]);
					}
				}
			}
		}
	}

	/**********************************
	 * Setting initial amount of CS sample
	 * @param keyId1
	 * @param modifiedVolume
	 * @param pl
	 * @param cellCount 
	 * @throws ActionException
	 **********************************/
	private void setInitialAmount(String keyId1, String modifiedVolume, PropertyList pl, String cellCount) throws ActionException {
		pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, keyId1);
		pl.setProperty("u_initialamount", modifiedVolume);
		pl.setProperty("u_initialvolunit", "ml");
		pl.setProperty("u_flowsamplesufficient", "Y");
		pl.setProperty("u_cellcount", cellCount);
		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	}

	/********************************************
	 * Method to update cell count of a given sample
	 * @param keyId1
	 * @param volume
	 * @param volumeUnit
	 * @param cellCount
	 * @param cellCountUnit
	 * @return
	 * @throws ActionException
	 ********************************************/
	private void updateCellCount(String keyId1, String volume, String volumeUnit, String cellCount,
			String cellCountUnit) throws ActionException {
		PropertyList pl = new PropertyList();
		pl.setProperty("s_sampleid", keyId1);
		pl.setProperty("volume", volume);
		pl.setProperty("volumeunit", volumeUnit);
		pl.setProperty("cellcount", cellCount);
		pl.setProperty("cellcountunit", cellCountUnit);
		getActionProcessor().processAction(CalcCellCount.class.getSimpleName(), "1", pl);
	}
	
	
}
