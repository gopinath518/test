/**
 * 
 */
package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class RemoveFlowTube extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sampleId = properties.getProperty("sampleids", "");
		String sampleStatus = properties.getProperty("samplestatus", "");
		PropertyList pl = new PropertyList();
		if(!Util.isNull(sampleId)){
			pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
			if(Util.isNull(sampleStatus)){
				pl.setProperty("disposalstatus", "Disposed");
				pl.setProperty("disposaldt", "n");
				pl.setProperty("disposedby", connectionInfo.getSysuserId());
			}else{
				pl.setProperty("disposalstatus", "(null)");
				pl.setProperty("disposaldt", "(null)");
				pl.setProperty("disposedby", "(null)");
				pl.setProperty("samplestatus", sampleStatus);
			}
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		}
	}
}
