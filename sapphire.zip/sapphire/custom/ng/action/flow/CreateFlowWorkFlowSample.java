package sapphire.custom.ng.action.flow;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class CreateFlowWorkFlowSample extends BaseAction implements FlowConstants{
	
	public static final String ID = "CreateFlowWorkFlowSample";
	public static final String VERSIONID = "1";
	public static final String PROPERTY_KEYID1 = "keyid1";
	public static final String PROPERTY_FLAG = "flag";
	public static final String PROPERTY_PANEL = "panelid";

	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleId = properties.getProperty("keyid1","");
		String flag = properties.getProperty("flag","");
		String panelid = properties.getProperty("panelid","");
		String labelType = properties.getProperty("labeltypeparam","");
		String tramline = properties.getProperty("tramlineparam",""); 
		String tramstop = properties.getProperty("tramstopparam","");
		
		this.checkTubesAndOtherTypesPresent(sampleId);
		
		String newkeyId1= getFlowSampleInfoByPanel(sampleId,flag,panelid);
		labelPrint(sampleId,newkeyId1,labelType,tramline,tramstop);
		
		properties.setProperty("tubeid",newkeyId1);
		//throw new SapphireException("Test");
	}
	
	private void checkTubesAndOtherTypesPresent(String sampleId) throws SapphireException{
		// TODO Auto-generated method stub
		String query = Util.parseMessage(FlowSql.GET_TUBE_AND_OTHER_SAMPLE, sampleId);
		DataSet ds = getQueryProcessor().getSqlDataSet(query);
		if(ds != null && ds.getRowCount() > 0){
			throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_VALIDATION, 
					"\nThe internal specimens of the below specimen already were generated :: \n"+sampleId);
		}
	}

	private String getFlowSampleInfoByPanel(String sampleId,String flag,String panelid) throws SapphireException {
		String tempInternalId="";
		String newKeyId1 = "";
		String andClause="";
		if("flowaddpanel".equalsIgnoreCase(flag))
			andClause="and lvtestpanelid in('"+StringUtil.replaceAll(panelid, ";", "','")+"')";
		String sql = Util.parseMessage(FlowSql.GET_SAMPLE_ABB_AND_REAGENT, StringUtil.replaceAll(sampleId, ";", "','"),andClause);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		HashMap<String,String> hm = new HashMap<String, String>();
		
		if(ds != null && ds.size()>0){
			String [] tempArr = StringUtil.split(sampleId, ";");
			
			for(int i = 0; i < tempArr.length; i++){
				hm.clear();
				hm.put("s_sampleid", tempArr[i]);
				DataSet filterDS = ds.getFilteredDataSet(hm);
				if(flag.equalsIgnoreCase("flowaddpanel"))
					 tempInternalId = Util.getUniqueList(filterDS.getColumnValues("sampleabbreviation", ";"), ";", true);
				else{
					String cytoSpinFlag = filterDS.getValue(0, "cytospinflag", "");
					String wrigthGiemsaFlag = filterDS.getValue(0, "wrightgiemsaflag", "");
					String csFreezingFlag = filterDS.getValue(0, "csfreezingflag", "");
					tempInternalId = FLOW_CS_SAMPLE_TYPE;
					
					if("Y".equalsIgnoreCase(cytoSpinFlag)){
						tempInternalId += FLOW_SPIN_SAMPLE_TYPE+";";
					}
					if("Y".equalsIgnoreCase(wrigthGiemsaFlag)){
						tempInternalId += FLOW_GIEMSA1_AND_GIEMSA2_SAMPLE_TYPE;
					}
					if("Y".equalsIgnoreCase(csFreezingFlag)){
						tempInternalId += FLOW_CRYO_SAMPLE_DEFAULT_TYPE;
					}
					
					tempInternalId += Util.getUniqueList(filterDS.getColumnValues("sampleabbreviation", ";"), ";", true);
				}
				
				String tempFlowId = Util.getUniqueList(filterDS.getColumnValues("u_flowsampleid", ";"), ";", true);
				String [] tempPanelId = StringUtil.split(Util.getUniqueList(filterDS.getColumnValues("lvtestpanelid", ";"), ";", true),";");
				PropertyList prop = new PropertyList();
				int copy = StringUtil.split(tempInternalId, ";").length;
				
				prop.clear();
		        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, tempArr[i]);
		        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES , String.valueOf(copy));
		        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");
		        prop.setProperty(CreateChildSamples.PROPERTY_ADD_EXTRA_PROPERTY, "u_flowsampleid");
		        prop.setProperty("u_flowsampleid", generateFlowInternalId(tempFlowId,tempInternalId));
		        prop.setProperty("u_currentmovementstep", StringUtil.repeat("", copy, ";"));
		        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
		        
		        newKeyId1 += prop.getProperty("newkeyid1","")+";";
		        for(int j = 0;j<tempPanelId.length;j++){
			        if(!"".equals(tempPanelId[j]))
						 addPanelToChildSample(newKeyId1,tempPanelId[j]);
		        }
			}
			DataSet specDS = this.getSpecimenTransportTypeToChildSample(newKeyId1);
			this.setSpecimenTransportData(specDS);
		}
		return newKeyId1;
	}
	
	private String generateFlowInternalId (String parentFlowInternalId, String abbreviation){
		String returnString = "";
		String [] tempAbbreviation = StringUtil.split(abbreviation, ";");
		for(int i = 0; i < tempAbbreviation.length; i++){
			returnString += parentFlowInternalId+""+tempAbbreviation[i]+";";
		}
		
		return returnString.substring(0, returnString.length()-1);
	}
	
	private void addPanelToChildSample(String childSampleId, String testName)throws SapphireException {
		if(!Util.isNull(childSampleId)){
			childSampleId = childSampleId.substring(0, childSampleId.length() - 1);
		 	int copy = StringUtil.split(childSampleId, ";").length; 
		 	PropertyList pl = new PropertyList();
			pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,childSampleId);
			pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,StringUtil.repeat(testName, copy,";"));
			pl.setProperty("flowtubesample",YES_VALUE);
			getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
		}
	 }
	
	 /**
     * Description : This labelPrint method added for automatic printing of Flow tube label.
     * @param Tube And Cell Suspension Sample Id
     * @throws SapphireException
     */
    private void labelPrint(String srcSampleId, String tubeSampleId,String labelType,String tramline, String tramstop) throws SapphireException {
		try {
			if (!Util.isNull(tubeSampleId) && tubeSampleId.endsWith(";")) {
				tubeSampleId = tubeSampleId.substring(0, tubeSampleId.length() - 1);
				if (!Util.isNull(tubeSampleId)) {
					tubeSampleId = StringUtil.replaceAll(tubeSampleId, ";", "','");
					String sql = Util.parseMessage(FlowSql.GET_OTHER_THAN_CRYO_SAMPLE, tubeSampleId);
					DataSet ds = getQueryProcessor().getSqlDataSet(sql);
					PropertyList props = new PropertyList();
					props.setProperty(PrintLabel.SDCID_PROP, "Sample");
					props.setProperty(PrintLabel.KEYID1_PROP, ds.getColumnValues("s_sampleid", ";")+";"+srcSampleId);
					props.setProperty(PrintLabel.LABELTYPE_PROP, labelType);
					props.setProperty(PrintLabel.TRAMLINE_PROP, tramline);
					props.setProperty(PrintLabel.TRAMSTOP_PROP, tramstop);
					getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
				}
			}
		} catch (SapphireException e) {
			String errMsg = getTranslationProcessor().translate("Unable To Print Label");
			errMsg += "\nError Detail:" + e.getMessage();
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
		}
    }
    
    private DataSet getSpecimenTransportTypeToChildSample(String newKeyId1) {
		// TODO Auto-generated method stub
    	DataSet newDS = new DataSet();
		if(!Util.isNull(newKeyId1)){
			String samples = newKeyId1.substring(0, newKeyId1.length()-1);
			String sql = Util.parseMessage(FlowSql.GET_INTERNAL_ID_BY_SAMPLE, StringUtil.replaceAll(samples, ";", "','"));
			DataSet internalDS = getQueryProcessor().getSqlDataSet(sql);
			//DataSet specimenTportDS = getQueryProcessor().getSqlDataSet(FlowSql.GET_SPECIMEN_TRANSPORT_TYPE);
			newDS.addColumn("s_sampleid", DataSet.STRING);
			newDS.addColumn("sampletypeid", DataSet.STRING);
			newDS.addColumn("containertypeid", DataSet.STRING);
			if(internalDS != null && internalDS.getRowCount() > 0){
				for(int i=0; i<internalDS.getRowCount(); i++){
					int row = newDS.addRow();
					String flowSampleId = internalDS.getValue(i, "u_flowsampleid", "");
					String childSample = internalDS.getValue(i, "s_sampleid", "");
					String rootSampleType = internalDS.getValue(i, "sampletype","");
					newDS.setValue(row, "s_sampleid", childSample);
					if(flowSampleId.contains(FLOW_SPIN_SAMPLE_TYPE)){
						newDS.setValue(row, "sampletypeid", "Cyto Spin");
						newDS.setValue(row, "containertypeid", "Slide");
					}else if(flowSampleId.contains(FLOW_WRIG_SAMPLE_TYPE)){
						newDS.setValue(row, "sampletypeid", rootSampleType);
						newDS.setValue(row, "containertypeid", "Smear - Stained Slide");
					}else if(flowSampleId.contains(FLOW_CRYO_SAMPLE_TYPE)){
						newDS.setValue(row, "sampletypeid", "Cell Suspension");
						newDS.setValue(row, "containertypeid", "Cryotube");
					}else if(flowSampleId.contains(FLOW_CELL_SUSP_SAMPLE_TYPE)){
						newDS.setValue(row, "sampletypeid", "Cell Suspension");
						newDS.setValue(row, "containertypeid", "Tube");
					}else{
						newDS.setValue(row, "sampletypeid", "Cell Suspension");
						newDS.setValue(row, "containertypeid", "Staining Tube");
					}
				}
			}
		}
		return newDS;
	}
    
    private void setSpecimenTransportData(DataSet ds) throws SapphireException{
		// TODO Auto-generated method stub
		if(ds != null && ds.getRowCount() > 0){
			PropertyList pl = new PropertyList();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
			pl.setProperty("sampletypeid", ds.getColumnValues("sampletypeid", ";"));
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
			
			pl.clear();
			pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("s_sampleid", ";"));
			pl.setProperty("containertypeid", ds.getColumnValues("containertypeid", ";"));
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
		}
	}
}
