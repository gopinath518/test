package sapphire.custom.ng.action.flow;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.Barcode128;
import com.lowagie.text.pdf.PdfWriter;

import sapphire.SapphireException;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDIAttachment;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class GenerateFlowManifest extends BaseAction {
	
	private static String  flowManifestLocation = "";
	String unixPath = "";
	String labname = "";
	DataSet folderDS = null;
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String accessionId = properties.getProperty("accessionid",""); 
		getManifestProcessingPath(accessionId);
		generateManifest(accessionId);
		properties.setProperty("msg", Util.parseMessage(FlowConstants.FLOW_MANIFEST_SCRIPT,accessionId));
	}
	
	private void getManifestProcessingPath(String accessionId) throws SapphireException{
		
		String sql = Util.parseMessage(FlowSql.GET_FLOW_LAUNCH_PATH,connectionInfo.getDefaultDepartment()); 
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		
		if(ds != null && ds.size()>0){
			unixPath = ds.getValue(0, "unixpath", "").trim();
			labname = ds.getValue(0, "labname", "").trim();
		}
		
		getFolderPath(accessionId);
		flowManifestLocation =  Util.generateIHCLocPath(unixPath+File.separator+labname, folderDS.getValue(0, "sponcername", ""), 
				folderDS.getValue(0, "projname", ""), "Flow", "flow_manifest");
		if("".equals(flowManifestLocation) )
			throw new SapphireException("Please specify the Flow Manifest directories for PDF file in the EnvironmentProp Tramstop");
	}
	
	private void generateManifest(String accessionId) throws  SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_MANIFEST_DETAIL_BY_ACCESSIONID, accessionId,accessionId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		String subjectName = "";
		File myFile = null;
		if (ds != null && ds.size()>0){
			subjectName = ds.getValue(0, "u_firstname","" )+" ";
			if(!"".equals(ds.getValue(0, "u_middlename","" )))
				subjectName += ds.getValue(0, "u_middlename","" )+" ";
			
			subjectName += ds.getValue(0, "u_lastname","" );
			try {
				Document document = new Document();    
				PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(flowManifestLocation+File.separator+accessionId+".pdf"));
				
				document.open();
//				document.add(new com.lowagie.text.Phrase("Project Id: "+ds.getValue(0, "bioprojectname","-")));
//				document.add( Chunk.NEWLINE );
				document.add(new com.lowagie.text.Phrase("Project Id: "+ds.getValue(0, "projectname","-")));
				document.add( Chunk.NEWLINE );
				document.add(new com.lowagie.text.Phrase("Panel Name: "+ds.getValue(0, "listpanelname","-")));
				document.add( Chunk.NEWLINE );
				document.add( Chunk.NEWLINE );
				
				Barcode128 code128 = new Barcode128();
				code128.setGenerateChecksum(true);
				code128.setCode(accessionId);
				code128.setBarHeight(50f); 
				code128.setX(2f);
				document.add(new com.lowagie.text.Phrase(accessionId));
				document.add( Chunk.NEWLINE );
				document.add(code128.createImageWithBarcode(writer.getDirectContent(), null, null));
				
				document.add( Chunk.NEWLINE );
				document.add( Chunk.NEWLINE );
				if("".equals(subjectName.trim()))
					document.add(new Paragraph("Subject name not Found"));
				else{
					code128.setCode(subjectName);
					document.add(new com.lowagie.text.Phrase(subjectName));
					document.add( Chunk.NEWLINE );
					document.add(code128.createImageWithBarcode(writer.getDirectContent(), null, null));
				}
				document.close();
					myFile = new File(flowManifestLocation+File.separator+accessionId+".pdf");
					loadSDIAttachment( accessionId, "Manifest",flowManifestLocation,accessionId+".pdf");
			} catch (IOException | DocumentException ex) {
				throw new SapphireException("Error occured::"+ex.getMessage());
			}
		}
	}
	
	private void loadSDIAttachment(String keyid1, String type, String filePath,String fileName) throws SapphireException{
		PropertyList pl = new PropertyList();
		
		pl.setProperty(DeleteSDIAttachment.PROPERTY_SDCID, "Accession");
		pl.setProperty(DeleteSDIAttachment.PROPERTY_KEYID1, keyid1);
		pl.setProperty(DeleteSDIAttachment.PROPERTY_KEYID2, "FCSManifest");
		
		getActionProcessor().processAction(DeleteSDIAttachment.ID, DeleteSDIAttachment.VERSIONID, pl);
		
		pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
		pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1);
		pl.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "FCSManifest");
		pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, fileName);
		pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filePath+File.separator+fileName);
		pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
		pl.setProperty("u_attachmenttype", type);
        getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
	}
	
	private DataSet getFolderPath(String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_GENERIC_FOLDER_DETAIL, accessionId);
		folderDS = getQueryProcessor().getSqlDataSet(sql);
		if(folderDS == null || folderDS.size() == 0){
			logger.error("Please specify the Flow Image/PDF directories");
			throw new SapphireException("Please specify the Image/Flow PDF directories");
		}
		
		return folderDS;
	}
}
