package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.util.Util;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * 
 * @author sudeepta.pal
 *
 */
public class FlowCSSampleRouting extends BaseAction {
	public static final String ID = "FlowCSSampleRouting";
	public static final String VERSIONID = "1";
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sampleId = properties.getProperty("keyid1","");
		String csSampleId = properties.getProperty("cssampleid","");
		String intenalId = properties.getProperty("internalid","");
		String nextmovementstep = properties.getProperty("movementstep", "");
		String tramstop = properties.getProperty("tramstop", "");
		String department = "";//properties.getProperty("department", "");
		String performRouting = properties.getProperty("performrouting", "");
		String performTubeCreation = properties.getProperty("performtubecreation", "");
		
		PropertyList pl = new PropertyList();
		if("Y".equalsIgnoreCase(performTubeCreation)){
			pl.setProperty(CreateFlowStainingTube.PROPERTY_KEYID1, Util.getUniqueList(sampleId, ";", true));
			pl.setProperty("intenalid", intenalId);
			getActionProcessor().processAction(CreateFlowStainingTube.ID, CreateFlowStainingTube.VERSIONID, pl);
		}
		
		if("Y".equalsIgnoreCase(performRouting)){
			pl.clear();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, csSampleId);
			pl.setProperty("u_currentmovementstep", nextmovementstep);//FlowStaining
			pl.setProperty("u_flowsamplesufficient", "Y");
			pl.setProperty("u_flowsampletype", "");
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
			
			department = connectionInfo.getDefaultDepartment();
			if(!Util.isNull(department) && department.contains("-")){
				department = StringUtil.split(department, "-")[0];
				department = department+"-FlowWetLab";
			}
			pl.clear();
			pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditTrackItem.PROPERTY_KEYID1, csSampleId);
			pl.setProperty("u_currenttramstop", tramstop);
			pl.setProperty("custodialdepartmentid", department);
			pl.setProperty("custodialuserid", "(null)");
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
		}
		
		//throw new SapphireException("Error occured");
	}
}
