package sapphire.custom.ng.action.flow;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
/**
 * Created by soumik.sen on 8/2/2018.
 */

public class FlowBatchCompletion  extends BaseAction  {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String batchId = properties.getProperty("batchid","");
        String batchOrigin = properties.getProperty("origin","");
        String toCurrentmovementstep = properties.getProperty("tocurrentmovementstep","");
        String toTramstop = properties.getProperty("totramstop","");
        String batchType = properties.getProperty("batchtype","");
        String batchStatusView = properties.getProperty("batchstatusview","");
		String sampleIds = "";

		if(Util.isNull(batchId))
            throw new SapphireException("Batchid couldn't be blank");
        if(Util.isNull(batchOrigin))
            throw new SapphireException("Batch origin couldn't be blank");
        
        this.isReagentPresentInLysingBatch(batchOrigin, batchId, batchType);
        
        this.isReagentPresentInStainingBatch(batchOrigin, batchId, batchType);
        
        this.isInstrumentPresent(batchOrigin, batchId);

        DataSet ds = getSampleIdFromBatch(batchId);
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "NGBatch");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, batchId);
		pl.setProperty("batchtype", batchType);
		pl.setProperty("batchstatusview", batchStatusView);
		pl.setProperty("batchcompletedts", "n");
		pl.setProperty("batchcompleteflag", "Y");
		try {
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		}
		catch (ActionException ex) {
			String error = getTranslationProcessor().translate("Unable to edit on NGBatch");
			throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
		}
		if(ds.size()>0){
			sampleIds = ds.getColumnValues("sampleid",";") ;
			if(!Util.isNull(sampleIds)){
	            if("FlowStaining".equalsIgnoreCase(batchOrigin)){
	            	completeStainingBatch(ds, toCurrentmovementstep, toTramstop);
	            }
	            else if("FlowAcquisition".equalsIgnoreCase(batchOrigin)){
	            	completeAcquisitionBatch(ds, toCurrentmovementstep, toTramstop);
	            }
	            else {
					pl.clear();
					pl.setProperty("sampleid", sampleIds);
					pl.setProperty("currentmovementstep", toCurrentmovementstep);
					pl.setProperty("totramstop", toTramstop);
					try {
						getActionProcessor().processAction("FlowNextStep", "1", pl);
					}
					catch (Exception ex) {
						throw new SapphireException("Error.Unable to process FlowNextStep : " + ex.getMessage());
					}
				}
	        }
        }
        //throw new SapphireException("Test");
    }
    
	private  DataSet getSampleIdFromBatch(String batchId) throws SapphireException{
    	DataSet ds = new DataSet();
        if(!Util.isNull(batchId)) {
            batchId = StringUtil.replaceAll(batchId, ";", "','");
            String sql = Util.parseMessage(FlowSql.GET_SAMPLE_FROM_BATCH, batchId);
            ds = getQueryProcessor().getSqlDataSet(sql);
        }
        return ds;
    }
    
    private void completeStainingBatch(DataSet ds, String toCurrentmovementstep, String toTramstop) throws SapphireException{
    	HashMap<String,String> hm = new HashMap<String, String>();
    	hm.put("tubeflag", "Y");
    	DataSet filterDS = ds.getFilteredDataSet(hm);
    	PropertyList pl = new PropertyList();
    	if(filterDS != null && filterDS.size() >0){
	    	pl.setProperty("sampleid", Util.getUniqueList(filterDS.getColumnValues("sampleid", ";"),";",true));
	        pl.setProperty("currentmovementstep", toCurrentmovementstep);
	        pl.setProperty("totramstop", toTramstop);
	        getActionProcessor().processAction("FlowNextStep", "1", pl);
	        filterDS.clear();
    	}
    	pl.clear();
    	hm.clear();
    	hm.put("tubeflag", "N");
    	
    	filterDS = ds.getFilteredDataSet(hm);
    	if(filterDS != null && filterDS.size() >0){
	    	pl.setProperty("sampleid", Util.getUniqueList(filterDS.getColumnValues("sampleid", ";"),";",true));
	        pl.setProperty("currentmovementstep", "FlowCSStorage");
	        pl.setProperty("totramstop", "Cell Suspension Storage");
	        getActionProcessor().processAction("FlowNextStep", "1", pl);
	        filterDS.clear();
    	}
    		enableCytoSpinSample(ds);
//    		enableCryoSample(ds);
    }
    
    public void enableCytoSpinSample(DataSet ds) throws SapphireException{
    	PropertyList prop = new PropertyList();
    	
    		String sampleId = Util.getUniqueList(ds.getColumnValues("sampleid", ";"), ";", true);
    		String query = Util.parseMessage(FlowSql.GET_SPIN_BY_ROOT_SAMPLE, StringUtil.replaceAll(sampleId, ";", "','"));
    		DataSet spinDS = getQueryProcessor().getSqlDataSet(query);
    		if(spinDS != null && spinDS.size()>0){
	    		String sampleIds = spinDS.getColumnValues("s_sampleid", ";");
		        
	    		prop.clear();
	    		prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
	    		prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleIds);
		        prop.setProperty("u_currentmovementstep", "FlowCytoSpin");
		        prop.setProperty("u_flowsamplereceivedt", "n");
		        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
	    		
		        String newKeyId1 = sampleIds;// prop.getProperty("newkeyid1","");
		        prop.clear();
		        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, newKeyId1);
		        prop.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
		        prop.setProperty("custodialuserid", connectionInfo.getSysuserId());
		        
		        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
    		}
    }
    
    public void enableCryoSample(DataSet ds) throws SapphireException{
    	PropertyList prop = new PropertyList();
    	
    		String sampleId = Util.getUniqueList(ds.getColumnValues("s_sampleid", ";"), ";", true);
    		String query = Util.parseMessage(FlowSql.GET_CRYO_BY_ROOT_SAMPLE, sampleId);
    		DataSet spinDS = getQueryProcessor().getSqlDataSet(query);
    		if(spinDS != null && spinDS.size()>0){
	    		String sampleIds = spinDS.getColumnValues("s_sampleid", ";");
		        
	    		prop.clear();
	    		prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
	    		prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleIds);
		        prop.setProperty("u_currentmovementstep", "FlowCSFreezing");
		        prop.setProperty("u_flowsamplereceivedt", "n");
		        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
	    		
		        String newKeyId1 = sampleIds;// prop.getProperty("newkeyid1","");
		        prop.clear();
		        prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		        prop.setProperty(EditTrackItem.PROPERTY_KEYID1, newKeyId1);
		        prop.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
		        prop.setProperty("custodialuserid", connectionInfo.getSysuserId());
		        
		        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
    		}
    }
    
//    private void addPanelToChildSample(String childSampleId, String testName)throws SapphireException {
//	 	int copy = StringUtil.split(childSampleId, ";").length; 
//	 	PropertyList pl = new PropertyList();
//		pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,childSampleId);
//		pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,StringUtil.repeat(testName, copy,";"));
//		pl.setProperty("flowtubesample","Y");
//		getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
//    }
    
    private void completeAcquisitionBatch(DataSet ds, String toCurrentmovementstep, String toTramstop) throws ActionException{
    	String department = connectionInfo.getDefaultDepartment();
    	if(!Util.isNull(department) && department.contains("-")){
	    	PropertyList pl = new PropertyList();
	    	if(ds != null && ds.size() >0){
		    	pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
		    	pl.setProperty(EditSDI.PROPERTY_KEYID1, Util.getUniqueList(ds.getColumnValues("u_accessionid", ";"), ";", true));
		        pl.setProperty("flowstatus", "FlowAnalysis");
		        pl.setProperty("flowxmlstatus", "Pending");
		        pl.setProperty("flowlmdstatus", "Pending");
		        pl.setProperty("flowreceivedate", "n");
		        pl.setProperty("flowdepartment", StringUtil.split(department, "-")[0]);
		        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	        
	        	department = StringUtil.split(department, "-")[0];
	        	department = department+"-FlowWetLab";
	        }
	        
	        pl.clear();
	        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
	    	pl.setProperty(EditSDI.PROPERTY_KEYID1, Util.getUniqueList(ds.getColumnValues("sampleid", ";"), ";", true));
	        pl.setProperty("u_currentmovementstep", "FlowStainingStorage");
	        pl.setProperty("u_flowsamplereceivedt", "n");
	        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	        
	        pl.clear();
	        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
	        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, Util.getUniqueList(ds.getColumnValues("sampleid", ";"), ";", true));
	        pl.setProperty("custodialdepartmentid", department);
			pl.setProperty("custodialuserid", connectionInfo.getSysuserId());
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	        
	        String cryoSampleQuery = Util.parseMessage(FlowSql.GET_CRYOGEN_SAMPLE_BY_ACCESSION, 
	        		StringUtil.replaceAll(Util.getUniqueList(ds.getColumnValues("u_accessionid", ";"), ";", true), ";", "','"));
	        DataSet crypSampleSet = getQueryProcessor().getSqlDataSet(cryoSampleQuery);
	        
	        if(crypSampleSet != null && crypSampleSet.getRowCount() > 0){
	        	pl.clear();
	        	pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
	        	pl.setProperty(EditSDI.PROPERTY_KEYID1, Util.getUniqueList(crypSampleSet.getColumnValues("s_sampleid", ";"), ";", true));
	        	pl.setProperty("u_currentmovementstep", "FlowCSFreezing");
	        	pl.setProperty("u_flowsamplereceivedt", "n");
	        	getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	        	
	        	
	        	pl.clear();
	        	pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
	        	pl.setProperty(EditTrackItem.PROPERTY_KEYID1, Util.getUniqueList(crypSampleSet.getColumnValues("s_sampleid", ";"), ";", true));
	        	pl.setProperty("u_currenttramstop", "Cell Suspension Freezing");
	        	pl.setProperty("custodialdepartmentid", department);
	        	pl.setProperty("custodialuserid", "(null)");
	        	getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	        }
			
			/**
			 * Code to reset the total number of LMD file generation 
			 * and updating number of flow tube 
			 */
			pl.clear();
			String sample = Util.getUniqueList(ds.getColumnValues("sampleid", ";"), ";", true);
			String query = Util.parseMessage(FlowSql.GET_ACCESSION_SAMPLE_COUNT, StringUtil.replaceAll(sample, ";", "','"));
			DataSet rs = getQueryProcessor().getSqlDataSet(query);
			if(rs != null && rs.getRowCount() > 0){
				pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
				pl.setProperty(EditSDI.PROPERTY_KEYID1, rs.getColumnValues("u_accessionid", ";"));
				pl.setProperty("totalflowtubesent", rs.getColumnValues("samplecount", ";"));
				pl.setProperty("totalnooflmdgen", "0");
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
			}
			/**
			 * END
			 */
    	}
    }
    
    /********************************************
     * Checking whether reagent lot is present 
     * in the selected Lysing Batch
     * @param batchOrigin
     * @param batchId
     * @param batchType
     * @throws SapphireException :: If no reagent is 
     * present with the CS sample in Lysing batch
     ********************************************/
    private void isReagentPresentInLysingBatch(String batchOrigin, String batchId, String batchType)throws SapphireException {
		// TODO Auto-generated method stub
    	if("FlowLysing".equalsIgnoreCase(batchOrigin)){
    		String query  = Util.parseMessage(FlowSql.GET_REAGENT_COUNT_OF_LYSING_BATCH, batchId);
    		DataSet ds = getQueryProcessor().getSqlDataSet(query);
    		if(ds == null || ds.getRowCount() == 0){
    			String sql = Util.parseMessage(FlowSql.GET_BATCH_NAME_BATCH_ID, batchId);
    			DataSet rs = getQueryProcessor().getSqlDataSet(sql);
    			if(rs != null && rs.getRowCount() > 0){
    				String batchName = rs.getValue(0, "batchname", "");
    				throw new SapphireException("Please associate reagent with the following "+batchOrigin
    						+" batch before completing it :: \n\n"+batchName);
    			}
    		}
    	}
		
	}
    
    /************************************
     * Check whether instrument is present 
     * in acquisition or not
     * @param batchOrigin
     * @param batchId
     ************************************/
    private void isInstrumentPresent(String batchOrigin, String batchId)throws SapphireException {
		// TODO Auto-generated method stub
		if("FlowAcquisition".equalsIgnoreCase(batchOrigin)){
			String query = Util.parseMessage(FlowSql.GET_INSTRUMENT_COUNT_OF_BATCH, batchId);
			DataSet ds = getQueryProcessor().getSqlDataSet(query);
			if(ds == null || ds.getRowCount() == 0){
				String sql = Util.parseMessage(FlowSql.GET_BATCH_NAME_BATCH_ID, batchId);
    			DataSet rs = getQueryProcessor().getSqlDataSet(sql);
    			if(rs != null && rs.getRowCount() > 0){
    				String batchName = rs.getValue(0, "batchname", "");
    				throw new SapphireException("Please associate instrument with the following "+batchOrigin
    						+" batch before completing it :: \n\n"+batchName);
    			}
			}
		}
	}
    
    /**********************************************
     * Checking whether reagent lot is present 
     * in the selected Staining Batch
     * @param batchOrigin
     * @param batchId
     * @param batchType
     * @throws SapphireException :: If no reagent is 
     * present for every staining tube in Staining batch
     **********************************************/
    private void isReagentPresentInStainingBatch(String batchOrigin, String batchId, String batchType)throws SapphireException {
		// TODO Auto-generated method stub
    	if("FlowStaining".equalsIgnoreCase(batchOrigin)){
    		String query  = Util.parseMessage(FlowSql.GET_REAGENT_COUNT_OF_STAINING_BATCH, batchId, batchId);
    		DataSet ds = getQueryProcessor().getSqlDataSet(query);
    		if(ds == null || ds.getRowCount() > 0){
    			int difference = ds.getInt(0, "difference", 0);
    			if(difference != 0){
    				String sql = Util.parseMessage(FlowSql.GET_BATCH_NAME_BATCH_ID, batchId);
    				DataSet rs = getQueryProcessor().getSqlDataSet(sql);
    				if(rs != null && rs.getRowCount() > 0){
    					String batchName = rs.getValue(0, "batchname", "");
    					throw new SapphireException("Please associate reagent with the following "+batchOrigin
    							+" batch for all staining tubes before completing it :: \n\n"+batchName);
    				}
    			}
    		}
    	}
	}
    
}
