package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowAssignToDoctor extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("keyid1", "");
        String flowstatus = properties.getProperty("flowstatus", "");
        String assignedtodoctor = properties.getProperty("u_assignedtodoctor", "");

        String sql = Util.parseMessage(FlowSql.GET_DATA_BY_SAMPLE, StringUtil.replaceAll(sampleId, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        if (dsInfo == null) {
            throw new SapphireException("Specimen(s) is mandatory.");
        }
        if (dsInfo.size() == 0) {
            throw new SapphireException("Specimen(s) is mandatory.");
        }
        PropertyList prop = new PropertyList();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
        prop.setProperty("u_assignedtodoctor", assignedtodoctor);
        prop.setProperty("u_assigndoctordt", "n");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to assign doctor to the specimens.");
        }
        prop.clear();
        prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        prop.setProperty(EditSDI.PROPERTY_KEYID1, Util.getUniqueList(dsInfo.getColumnValues("u_accessionid",";"), ";", true));
        prop.setProperty("flowstatus", flowstatus);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
        } catch (Exception ex) {
            throw new SapphireException("Unable to assign doctor to the Accession.");
        }
    }
}
