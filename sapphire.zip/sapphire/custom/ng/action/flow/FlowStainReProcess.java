package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowStainReProcess extends BaseAction {
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String sampleId = properties.getProperty("s_sampleid", "");
		callReProcess(sampleId);
//		throw new SapphireException("Test");
	}
	
	private void callReProcess(String sampleId) throws SapphireException{
		
		
		String sql = Util.parseMessage(FlowSql.GET_SRC_SAMPLE_BY_CS, sampleId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		String srcSample = ds.getValue(0, "srcsample", "");
		
		sql = Util.parseMessage(FlowSql.GET_STORAGE_ID_BY_SAMPLE_ID, srcSample);
		ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.getRowCount() > 0){
			if(!"".equals(ds.getValue(0, "currentstorageunitid","")))
				throw new SapphireException("The selected Mother/Daughter specimen is currently in Storage. Kindly checkout the specimen before performing Re-Processing");
			
			PropertyList pl = new PropertyList();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, srcSample);
			pl.setProperty("u_currentmovementstep", "FPCOCComplete");
			
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
			
			String department = getConnectionProcessor().getConnectionInfo(getConnectionId()).getDefaultDepartment();
			if(!Util.isNull(department) && department.contains("-")){
				department = StringUtil.split(department, "-")[0];
				department = department+"-Fresh Prep";
			}
			pl.clear();
			pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
			pl.setProperty(EditTrackItem.PROPERTY_KEYID1, srcSample);
			pl.setProperty("u_currenttramstop", "Fresh Prep QC");
			pl.setProperty("custodialdepartmentid", department);
			pl.setProperty("custodialuserid", "(null)");
			getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
			
			pl.clear();
			pl.setProperty("keyid1", sampleId);
			getActionProcessor().processAction("FlowCSAndTubeMovement", "1", pl);			
		}
	}
}
