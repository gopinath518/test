package sapphire.custom.ng.action.flow;

import java.io.File;
import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.util.Date;

import sapphire.SapphireException;
import sapphire.action.AddSDIAttachment;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ProcessFlowLMDFile extends BaseAction {
	
	private static String inputFolder=""; 
	private static String outputFolder=""; 
	String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		getLMDProcessingPath();
	}
	
	private void getLMDProcessingPath() throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_FLOW_FOLDER_PATH);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		
		if(ds != null && ds.size()>0){
			for(int i=0;i<ds.size();i++){
				inputFolder = ds.getValue(i, "unixpath", "")+File.separator+ds.getValue(i, "lmdinputpath", "");
				outputFolder = ds.getValue(i, "unixpath", "")+File.separator+ds.getValue(i, "lmdoutputpath", "");
				
				if("".equals(inputFolder) || "".equals(outputFolder)){
					logger.error("Please specify the input and output directories of LMD files in the"+ds.getValue(i, "sitename", "")+" Site Tramstomp");
					continue;
				}
				processPendingLMDFile();
			}
		}
		
	}
	private void processPendingLMDFile() throws SapphireException{
		File f = new File(inputFolder);
        File[] files = f.listFiles(new FilenameFilter() {
  	       public boolean accept(File dir, String name) {
	           return name.startsWith(FlowConstants.FLOW_FILE_STARTWITH) && name.toUpperCase().endsWith(FlowConstants.FLOW_LMD_FILE_EXT);
	       }
	    });
        
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile()) {
                    parseFileName(file.getName());
                    moveToSuccessFolder(file.getName());
                }
            }
        }
	}
	private void parseFileName(String fileName) throws SapphireException{
		String accesionId = StringUtil.split(fileName, " ")[0];
		String sql = Util.parseMessage(FlowSql.GET_TOTAL_TUBE_BY_ACCESSION, accesionId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.size()>0){
			int tubeSent = ds.getInt(0, "totalflowtubesent",0);
			int lmdGen = ds.getInt(0, "totalnooflmdgen",0)+1;
			if(tubeSent >0){
				PropertyList pl = new PropertyList();
				pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
				pl.setProperty(EditSDI.PROPERTY_KEYID1, accesionId);
				if(lmdGen >= tubeSent )
					pl.setProperty("flowlmdstatus", "Completed");
				else
					pl.setProperty("flowlmdstatus", "In Progress");
				
				pl.setProperty("totalnooflmdgen", (lmdGen+""));
				getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
				
				pl.clear();
				pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
				pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, accesionId);
				pl.setProperty(AddSDIAttachment.PROPERTY_KEYID2, "FlowLMD");
				pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, fileName);
				pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, outputFolder + File.separator+"success"+File.separator + folderDt + File.separator+fileName);
				pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
				pl.setProperty("u_attachmenttype", "LMD");
		        getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
			}
		}
	}
	private void moveToSuccessFolder(String fileName) throws SapphireException {
        
        File file = new File(inputFolder +File.separator+ fileName);
        File dir = new File(outputFolder + File.separator+"success"+File.separator + folderDt + File.separator);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if (file.isFile()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                Logger.logInfo(file.getName() + ":: File Moved to Success folder");
        }
    }
	
}
