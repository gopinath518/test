package sapphire.custom.ng.action.flow;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.codec.binary.Base64;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIAttachment;
import sapphire.action.AddSDIWorkItem;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EnterDataItem;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.flow.xml.fcsxmlreader.Data_Source;
import sapphire.custom.ng.flow.xml.fcsxmlreader.Exported_Item;
import sapphire.custom.ng.flow.xml.fcsxmlreader.Fcs_Express_Results;
import sapphire.custom.ng.flow.xml.fcsxmlreader.Iteration;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class ProcessFlowFCSXMLFile extends BaseAction{
	public static String xmlInputDir = "";
	public static String xmlFilePath = "";
	public static String xmlOutputDir = "";
	public static String mappedWindowPath = "";
	public static String unixPath = "";
	public static String imgSubFolderPath = "";
	public static String pdfSubFolderPath = "";
	public static String labname = "";
	String folderDt = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
	String currentTime = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss").format(new Date());
	
	String panelId = "";
	DataSet folderDS = null;
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		getXMLProcessingPath();
//		throw new SapphireException("Test");
	}
	
	private void getXMLProcessingPath() throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_FLOW_FOLDER_PATH);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		
		if(ds != null && ds.size()>0){
			for(int i=0;i<ds.size();i++){
				xmlInputDir = ds.getValue(i, "unixpath", "")+File.separator+ds.getValue(i, "fcsxmlinputpath", "");   
				xmlOutputDir = ds.getValue(i, "unixpath", "")+File.separator+ds.getValue(i, "fcsxmloutputpath", "");
				xmlFilePath = ds.getValue(i, "fcsxmlinputpath", ""); 
				mappedWindowPath = ds.getValue(i, "windowpath", "");
				unixPath = ds.getValue(i, "unixpath", "");
				labname = ds.getValue(i, "labname", "");
				imgSubFolderPath = ds.getValue(i, "fcsxmlimagepath", "");
				pdfSubFolderPath = ds.getValue(i, "fcsxmlpdfpath", "");
				
//				xmlInputDir = "\\\\av1-isilon.neogen.local\\lvb-sbx1\\clientdata\\flow\\fcs_xml_input"; 
//				xmlOutputDir = "\\\\av1-isilon.neogen.local\\lvb-sbx1\\clientdata\\flow\\fcs_xml_output";
//				xmlFilePath = "flow\\fcs_xml_input"; 
//				mappedWindowPath = "\\\\av1-isilon.neogen.local";
//				unixPath = mappedWindowPath;
//				labname = "clientdata";
//				imgSubFolderPath = "fcs_image";
//				pdfSubFolderPath = "fcs_pdf";
				
				if("".equals(xmlInputDir) || "".equals(xmlOutputDir)){
					logger.error("Please specify the Input/Output directories for XML files in the"+ds.getValue(i, "sitename", "")+" Site Tramstop");
					continue;
				}
				
				processPendingXMLFile();
			}
		}
		
	}
	private void processPendingXMLFile() throws SapphireException{
		File f = new File(xmlInputDir);
		File[] files = f.listFiles(new FilenameFilter() {
	  	       public boolean accept(File dir, String name) {
		           return name.startsWith(FlowConstants.FLOW_FILE_STARTWITH) && name.toUpperCase().endsWith(FlowConstants.FLOW_FCS_FILE_EXT);
		       }
		});
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile()) {
                	readingFCSXMLFile(file.getName());
                    moveToSuccessFolder(file.getName());
                }
            }
        }
	}
	
	private void readingFCSXMLFile(String fileName) throws SapphireException{
		try{
			File file = new File(xmlInputDir+File.separator+fileName);
			JAXBContext jaxbContext = JAXBContext.newInstance(Fcs_Express_Results.class);
			
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			Fcs_Express_Results fcs = (Fcs_Express_Results) jaxbUnmarshaller.unmarshal(file);
			loadXMLDataIntoLVSystem(fcs, fileName, file);
		}catch(JAXBException je){
			moveToFailureFolder(fileName);
			throw new SapphireException("Exception while parsing XML data::"+je.getMessage());
		}
	}
	
	private void loadXMLDataIntoLVSystem(Fcs_Express_Results fcs, String fileName, File file) throws SapphireException{
		DataSet xmlDS = new DataSet();
				xmlDS = initilizeDataSet(xmlDS);
		String accessionId = StringUtil.split(fileName, " ")[0];
		getFolderPath(accessionId);
		convertXMLIntoDataSet(xmlDS, fcs, accessionId,fileName);
		extractFileTypeData(xmlDS, fileName,accessionId);
		loadDataIntoStagging(xmlDS, fileName, accessionId);
		loadTransactionalData(xmlDS, fileName, accessionId);
		loadSDIAttachment(accessionId, "FlowFCSXML","XML", file);
		completeXMLStatus(accessionId);
	}
	private void convertXMLIntoDataSet(DataSet xmlDS, Fcs_Express_Results fcs, String accessionId, String fileName) throws SapphireException{
		
		String fcsDate =fcs.getDate();
		String fcsTime = fcs.getTime();
		List<Exported_Item> exportItemList = null;
		Exported_Item exported_Item = null;
		try{
		List<Iteration> iterationList = fcs.getIteration();
		Iteration it = null;
		
		for(int i=0;i<iterationList.size();i++){
			it = new Iteration();
			it = iterationList.get(i);
			String iterNumber = it.getNumber();
			
			exportItemList = it.getExported_item();
			for(int j =0; j<exportItemList.size();j++){
				exported_Item = exportItemList.get(j);
				String type = exported_Item.getType();
				if(type != null ){
					xmlDS.addRow();
					if("Token".equalsIgnoreCase(type)){
						xmlDS.setValue(j, "exported_item_type", type);
						xmlDS.setValue(j, "exported_item_name", exported_Item.getName());
						xmlDS.setValue(j, "exported_item_value", exported_Item.getValue());
					}else if("picture".equalsIgnoreCase(type) || "pdf".equalsIgnoreCase(type)){
						xmlDS.setValue(j, "exported_item_type", type);
						xmlDS.setValue(j, "exported_item_name", exported_Item.getName());
						xmlDS.setValue(j, "exported_item_format", exported_Item.getFormat());
						xmlDS.setValue(j, "exported_item_resolution", exported_Item.getResolution());
						xmlDS.setValue(j, "exported_item_width", exported_Item.getWidth());
						xmlDS.setValue(j, "exported_item_height", exported_Item.getHeight());
						
						Data_Source source = exported_Item.getData_source();
						if(source != null){
							xmlDS.setValue(j, "data_source_type", source.getType());
							xmlDS.setValue(j, "data_source_size", source.getSize());
							xmlDS.setValue(j, "data_source_base64_data", source.getBase64_data());
						}
					}
					
					xmlDS.setValue(j, "fcsdate", fcsDate);
					xmlDS.setValue(j, "fcstime", fcsTime);
					xmlDS.setValue(j, "iterationnumber", iterNumber);
					xmlDS.setValue(j, "accessionid", accessionId);
					xmlDS.setValue(j, "rowid", j+"");
				}
			}
			addMarkerPanel(xmlDS,accessionId);
		}
		}catch (Exception e) {
			moveToFailureFolder(fileName);
			throw new SapphireException("Error occured during converting XMl Data Into DataSet. Method Name: convertXMLIntoDataSet");
		}
	}
	
	private void addMarkerPanel(DataSet xmlDS, String accessionId) throws SapphireException {
		panelId = getCurrentPanelId(accessionId); //"FlowBP001";//If present then Add Panel and if not Edit Panel
		
		String sql = Util.parseMessage(FlowSql.GET_MARKER_PANEL_ID_BY_XML_TAG_NAME,  StringUtil.replaceAll(panelId, ";", "','"), xmlDS.getColumnValues("exported_item_name", "','"));
		DataSet tempDs = getQueryProcessor().getSqlDataSet(sql); // Get the XmlTag Mapping for panel
		
		sql = Util.parseMessage(FlowSql.GET_DIFF_XMLTAG_BY_ACC, StringUtil.replaceAll(panelId, ";", "','"));
		DataSet tempDiff = getQueryProcessor().getSqlDataSet(sql);// Get the XmlTag Mapping for panel and Differtial section
		tempDs.copyRow(tempDiff, -1, 1);// Copy the differential section XML mapping data into Panel Xml mapping data
		
		HashMap<String, String> hm = new HashMap<>();
		
		if(tempDs != null && tempDs.size() > 0){
			for(int i =0; i<tempDs.size(); i++){
				String xmlTag = tempDs.getValue(i, "flowxmltagname");
				hm.put("exported_item_name", xmlTag);
				
				DataSet filterDS = xmlDS.getFilteredDataSet(hm);
				if(filterDS != null && filterDS.size() ==1){
					int row_num = xmlDS.findRow("exported_item_name", xmlTag);
					xmlDS.setValue(row_num, "markerid", tempDs.getValue(i, "markername",""));
					xmlDS.setValue(row_num, "lvtestcodeid", tempDs.getValue(i, "markerid",""));
					xmlDS.setValue(row_num, "gateid", tempDs.getValue(i, "gateid",""));
					xmlDS.setValue(row_num, "workitemid", tempDs.getValue(i, "testname",""));
				}
				else if(filterDS != null && filterDS.size() >1){
					
					for(int j=0; j<filterDS.size(); j++){
						int row_num = tempDs.getInt(j, "rowid",-1);
						xmlDS.setValue(row_num, "markerid", tempDs.getValue(i, "markername",""));
						xmlDS.setValue(row_num, "lvtestcodeid", tempDs.getValue(i, "markerid",""));
						xmlDS.setValue(row_num, "gateid", tempDs.getValue(i, "gateid",""));
						xmlDS.setValue(row_num, "workitemid", tempDs.getValue(i, "testname",""));
					}
				}
			}
		}
	}
	
	private String getCurrentPanelId(String accessionId){
		String sql = Util.parseMessage(FlowSql.GET_CURRENT_PANEL_BY_ACCESSION, accessionId,accessionId);
		DataSet panelDS = getQueryProcessor().getSqlDataSet(sql);
		if(panelDS != null && panelDS.size() > 0){
			return panelDS.getColumnValues("lvtestpanelid", ";");
		}else{
			sql = Util.parseMessage(FlowSql.GET_CURRENT_ACTIVE_PANEL, accessionId);
			panelDS = getQueryProcessor().getSqlDataSet(sql);
			return panelDS.getColumnValues("lvtestpanelid", ";");
		}
	}
	
	private void setPanelAndReportIdInDataSet(DataSet xmlDS,String accessionId) throws SapphireException{
		String reportId = generateReportOptionId(accessionId);
		for(int j=0;j<xmlDS.size();j++){
			xmlDS.setValue(j, "panelid", panelId);
			xmlDS.setValue(j, "reportoptionid", reportId);
		}
	}
	
	private void loadDataIntoStagging(DataSet xmlDS, String fileName, String accessionId) throws SapphireException{
		setPanelAndReportIdInDataSet(xmlDS, accessionId);
		
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("exported_item_type", "token");
		DataSet filterXMLDS = xmlDS.getFilteredDataSet(hm);// XML Token Data are filter 

		PropertyList pl = new PropertyList();
		try{
			String sql = Util.parseMessage(FlowSql.GET_CURRENT_VERSION_STAGGING_DATABY_ACCESSION, accessionId,panelId);
			DataSet staggingDS = getQueryProcessor().getSqlDataSet(sql);// Check if any Current Data exist with combination of Accession and Panel 
			if(staggingDS != null ){
				String versionSQL = Util.parseMessage(FlowSql.GET_STAGGING_VER_BY_ACCESSION, accessionId,accessionId);
				DataSet verDS = getQueryProcessor().getSqlDataSet(versionSQL);
				String versionId = verDS.getValue(0, "verid", "1");
				
				if(Integer.parseInt(versionId) > 1){ //If any existing record then make the current status as Null 
					pl.setProperty(EditSDI.PROPERTY_SDCID, "FlowXMLDataStagging");
					pl.setProperty(EditSDI.PROPERTY_KEYID1, verDS.getColumnValues("u_flowxmldatastaggingid", ";"));
					pl.setProperty("status", StringUtil.repeat("(null)", verDS.size(), ";"));
					
					getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
				}
				
				if(staggingDS.size() > 0){
					updateDataSetForNewValueInSamePanel(xmlDS,staggingDS); // Update the current DataSet with new Dataset for same Accession and Panel
					pl.setProperty(EditSDI.PROPERTY_SDCID, "FlowXMLDataStagging");
					pl.setProperty(EditSDI.PROPERTY_KEYID1, staggingDS.getColumnValues("u_flowxmldatastaggingid", ";"));
					pl.setProperty("status", StringUtil.repeat("Active", staggingDS.size(), ";"));
					
					pl.setProperty("markervalue", staggingDS.getColumnValues("markervalue", ";"));
					getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
				
				}else{ // Add new Data in the system when there is no data for combination of Accession and Panel
					pl.setProperty(AddSDI.PROPERTY_SDCID, "FlowXMLDataStagging");
					pl.setProperty(AddSDI.PROPERTY_COPIES, filterXMLDS.size()+"");
					pl.setProperty("accessionid", filterXMLDS.getColumnValues("accessionid", ";")); 
					pl.setProperty("panelid", filterXMLDS.getColumnValues("panelid", ";"));
					pl.setProperty("gateid", filterXMLDS.getColumnValues("gateid", ";"));
					pl.setProperty("markerid", filterXMLDS.getColumnValues("markerid", ";"));
					pl.setProperty("markervalue", filterXMLDS.getColumnValues("exported_item_value", ";"));
					pl.setProperty("lvtestcodeid", filterXMLDS.getColumnValues("lvtestcodeid", ";"));
					
					pl.setProperty("xmlfilename", StringUtil.repeat(fileName, filterXMLDS.size(), ";"));
					pl.setProperty("versionid", StringUtil.repeat(versionId, filterXMLDS.size(), ";"));
					pl.setProperty("status", StringUtil.repeat("Active", filterXMLDS.size(), ";"));
					
					getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
					
					loadDataIntoSDITestCode(accessionId);
				}
			}
			
		}catch (SapphireException se) {
			se.printStackTrace();
			moveToFailureFolder(fileName);
			throw new SapphireException("Error Occured during loading Data into Stagging Table. Method name: loadDataIntoStagging");
		}
	}
	
	private void loadDataIntoSDITestCode(String accessionId) throws SapphireException{
		
		try{
			String sql = Util.parseMessage(FlowSql.GET_TESTCODE_BY_PANELID, StringUtil.replaceAll(panelId, ";", "','"),StringUtil.replaceAll(panelId, ";", "','"));
			DataSet sdiTestCodeDS = getQueryProcessor().getSqlDataSet(sql);
			
			PropertyList pl = new PropertyList();
			DataSet isNotPanelDS = Util.filterNotEqualValue(sdiTestCodeDS,"ispanel","Y");
				
			pl.setProperty(AddSDI.PROPERTY_SDCID, "SDITestCode");
			pl.setProperty(AddSDI.PROPERTY_COPIES, isNotPanelDS.size()+"");
			pl.setProperty("linksdcid", "Accession");
			pl.setProperty("linkkeyid1", StringUtil.repeat(accessionId, isNotPanelDS.size(), ";"));
			pl.setProperty("lvtestcodeid", isNotPanelDS.getColumnValues("u_testcodeid", ";"));
			pl.setProperty("testname", isNotPanelDS.getColumnValues("testname", ";"));
			pl.setProperty("methodology", isNotPanelDS.getColumnValues("methodology", ";"));
			pl.setProperty("los", isNotPanelDS.getColumnValues("los", ";"));
			pl.setProperty("teststatus", StringUtil.repeat("Active", isNotPanelDS.size(), ";"));
			
			getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
			
			pl.clear();
			HashMap<String,String> hm = new HashMap<String,String>();
			hm.put("ispanel", "Y");
			DataSet filterDS = sdiTestCodeDS.getFilteredDataSet(hm);
				
			pl.setProperty(AddSDI.PROPERTY_SDCID, "SDITestCode");
			pl.setProperty(AddSDI.PROPERTY_COPIES, filterDS.size()+"");
			pl.setProperty("linksdcid", "Accession");
			pl.setProperty("linkkeyid1", StringUtil.repeat(accessionId, filterDS.size(), ";"));
			pl.setProperty("testname", filterDS.getColumnValues("testname", ";"));
			pl.setProperty("lvtestpanelid", filterDS.getColumnValues("u_testcodeid", ";"));
			pl.setProperty("ispanel", filterDS.getColumnValues("ispanel", ";"));
			pl.setProperty("methodology", filterDS.getColumnValues("methodology", ";"));
			pl.setProperty("los", filterDS.getColumnValues("los", ";"));
			pl.setProperty("teststatus", StringUtil.repeat("Active", filterDS.size(), ";"));
			
			getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
		}catch (Exception e) {
			e.printStackTrace();
			throw new SapphireException("Error Occured during loading Data into Stagging Table. Method name: loadDataIntoSDITestCode");
		}
	}
	
	private void loadTransactionalData(DataSet xmlDS, String fileName, String accessionId) throws SapphireException{
		
		try{
		DataSet transactionDS = Util.filterNotEqualValue(xmlDS,"workitemid","null");
		transactionDS = Util.filterNotEqualValue(transactionDS,"workitemid","FlowDiffOtherPanel");// Different Panel Other than PNH Panel
		transactionDS = Util.filterNotEqualValue(transactionDS,"workitemid","FlowDiffPNHPanel"); //Different Panel only PNH Panel
		
		identifyRowForAddWorkItem(transactionDS);
		PropertyList pl = new PropertyList();
		if(transactionDS.size()>0){
			//Adding Data for Gates & Marker
			pl.setProperty(AddSDIWorkItem.PROPERTY_SDCID, "Accession");
			pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID1, transactionDS.getColumnValues("accessionid", ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID2, transactionDS.getColumnValues("gateid", ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID3, transactionDS.getColumnValues("reportoptionid", ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID, transactionDS.getColumnValues("workitemid", ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID, StringUtil.repeat("1", transactionDS.size(),";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM, StringUtil.repeat("Y", transactionDS.size(),";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_PROPSMATCH, "Y");
			
			getActionProcessor().processAction(AddSDIWorkItem.ID, AddSDIWorkItem.VERSIONID, pl);
			
			//Display On Report Functionality in Flow -- Start
			String uniqueGateId = Util.getUniqueList(transactionDS.getColumnValues("gateid", ";"), ";", true);
			int gateSize = StringUtil.split(uniqueGateId, ";").length;
			pl.setProperty(AddSDIWorkItem.PROPERTY_SDCID, "Accession");
			pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID1, StringUtil.repeat(transactionDS.getValue(0, "accessionid", ""), gateSize, ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID2, uniqueGateId);
			pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID3, StringUtil.repeat(transactionDS.getValue(0, "reportoptionid", ""), gateSize, ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID, StringUtil.repeat("FlowDisplayOnReport", gateSize, ";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID, StringUtil.repeat("1", gateSize,";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM, StringUtil.repeat("Y", gateSize,";"));
			pl.setProperty(AddSDIWorkItem.PROPERTY_PROPSMATCH, "Y");
			getActionProcessor().processAction(AddSDIWorkItem.ID, AddSDIWorkItem.VERSIONID, pl);
			
			
			pl.clear();
	        pl.setProperty(EnterDataItem.PROPERTY_SDCID, "Accession");
	        pl.setProperty(EnterDataItem.PROPERTY_KEYID1, StringUtil.repeat(transactionDS.getValue(0, "accessionid", ""), gateSize, ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_KEYID2, uniqueGateId);
	        pl.setProperty(EnterDataItem.PROPERTY_KEYID3, StringUtil.repeat(transactionDS.getValue(0, "reportoptionid", ""), gateSize, ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, StringUtil.repeat("FlowDisplayOnReport", gateSize, ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, StringUtil.repeat("1", gateSize,";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMID, StringUtil.repeat("FlowDisplayOnReport", gateSize, ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, StringUtil.repeat("Y", gateSize, ";"));
	        pl.setProperty("displayvalue", StringUtil.repeat("Y", gateSize, ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_VARIANTID, StringUtil.repeat("1", gateSize,";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, StringUtil.repeat("Standard", gateSize,";"));
	        pl.setProperty(EnterDataItem.PROPERTY_REPLICATEID, StringUtil.repeat("1", gateSize,";"));
	        pl.setProperty(EnterDataItem.PROPERTY_DATASET, StringUtil.repeat("1", gateSize,";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");
	        
	        getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, pl);
	        
		}
		//Display On Report Functionality in Flow -- End
		if(identifyRowForAddingDifferential(transactionDS, accessionId) == -1){ // This determine whether Differential Data added for Accession or not
	        transactionDS = Util.filterNotEqualValue(xmlDS,"workitemid","null");
	        String differtialValue = FlowConstants.FLOW_DIFF_PANEL;
	        if(panelId.contains(FlowConstants.FLOW_DIFF_PNH_PANEL_CODE))
	        	differtialValue = FlowConstants.FLOW_DIFF_PNH_PANEL;
	        	
				pl.clear();
				
				pl.setProperty(AddSDIWorkItem.PROPERTY_SDCID, "Accession");
				pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID1, xmlDS.getValue(0,"accessionid", ""));
				pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID2, differtialValue);// Gate Id
				pl.setProperty(AddSDIWorkItem.PROPERTY_KEYID3, xmlDS.getValue(0,"reportoptionid", ""));
				pl.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID, differtialValue);// Workitem Id
				pl.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID, "1");
				pl.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM, "Y");
				pl.setProperty(AddSDIWorkItem.PROPERTY_PROPSMATCH, "Y");
				
				getActionProcessor().processAction(AddSDIWorkItem.ID, AddSDIWorkItem.VERSIONID, pl);
		}
		
		
		pl.clear();
		transactionDS = Util.filterNotEqualValue(xmlDS,"workitemid","null");
		if(transactionDS.size()>0){
			
			pl.setProperty(EnterDataItem.PROPERTY_SDCID, "Accession");
	        pl.setProperty(EnterDataItem.PROPERTY_KEYID1, transactionDS.getColumnValues("accessionid", ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_KEYID2, transactionDS.getColumnValues("gateid", ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_KEYID3, transactionDS.getColumnValues("reportoptionid", ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, transactionDS.getColumnValues("workitemid", ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, StringUtil.repeat("1", transactionDS.size(),";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMID, transactionDS.getColumnValues("markerid", ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, transactionDS.getColumnValues("EXPORTED_ITEM_VALUE", ";"));
	        pl.setProperty("displayvalue", transactionDS.getColumnValues("EXPORTED_ITEM_VALUE", ";"));
	        pl.setProperty(EnterDataItem.PROPERTY_VARIANTID, StringUtil.repeat("1", transactionDS.size(),";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, StringUtil.repeat("Standard", transactionDS.size(),";"));
	        pl.setProperty(EnterDataItem.PROPERTY_REPLICATEID, StringUtil.repeat("1", transactionDS.size(),";"));
	        pl.setProperty(EnterDataItem.PROPERTY_DATASET, StringUtil.repeat("1", transactionDS.size(),";"));
	        pl.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");
        
        	getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, pl);
		}
        
		}catch (SapphireException se) {
			moveToFailureFolder(fileName);
			throw new SapphireException("Error occured in loading data in Transaction Table. Method name: loadTransactionalData");
		}
		
	}
	
	private void identifyRowForAddWorkItem(DataSet transactionDS){
		String sql = Util.parseMessage(FlowSql.GET_WORKITEM_DETAIL, transactionDS.getValue(0,"accessionid", ""));
		DataSet workitemDS = getQueryProcessor().getSqlDataSet(sql);
		HashMap<String, String> hm = new HashMap<>();
		int row_num = -1;
		for(int k =0; k<workitemDS.size(); k++){
			hm.put("gateid", workitemDS.getValue(k, "keyid2",""));
			hm.put("workitemid", workitemDS.getValue(k, "workitemid",""));
			while(true){
				row_num = transactionDS.findRow(hm);
				if(row_num >=0)
					transactionDS.deleteRow(row_num);
				else
					break;
			}
		}
	}
	private int identifyRowForAddingDifferential(DataSet transactionDS, String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_WORKITEM_DETAIL, accessionId);
		DataSet diffDS = getQueryProcessor().getSqlDataSet(sql);
		int i = -1;
		if(diffDS.size()>0){
			 i = diffDS.findRow("workitemid", FlowConstants.FLOW_DIFF_PANEL);
			 if(i == -1)
				 i = diffDS.findRow("workitemid", FlowConstants.FLOW_DIFF_PNH_PANEL);
		}
		return i;
		
	}
	
	private String generateReportOptionId(String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_EXISTING_REPORT_OPTION_ID, accessionId);
		DataSet reportDS = getQueryProcessor().getSqlDataSet(sql);
		String newReportOptionId = "";
		if(reportDS != null){
			if(reportDS.size() ==0){
				PropertyList pl = new PropertyList();
				pl.setProperty(AddSDI.PROPERTY_SDCID, "ReportOption");
				pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
				pl.setProperty("reportoptiondesc", "Flow Report Add SDI");
				pl.setProperty("accessionid", accessionId);
				pl.setProperty("methodologyid", "Flow");
				pl.setProperty("los", "Global");
				getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
				newReportOptionId = pl.getProperty("newkeyid1");
			}else{
				newReportOptionId = reportDS.getValue(0, "u_reportoptionid", "");
			}
		}
		
		return newReportOptionId;
	}
	
	private void extractFileTypeData(DataSet xmlDS, String fileName, String accessionId) throws  SapphireException{
		
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("exported_item_type", "picture");
		
		DataSet filterDS = xmlDS.getFilteredDataSet(hm);
		if(filterDS != null && filterDS.size()>0){
			loadJEPG(filterDS, fileName,accessionId);
			filterDS.clear();
		}
		
		hm.put("exported_item_type", "PDF");
		filterDS = xmlDS.getFilteredDataSet(hm);
		if(filterDS != null && filterDS.size()>0)
			loadPDF(filterDS, fileName, accessionId);
	}
	
	private void loadJEPG(DataSet filterDS, String fileName,String accessionId) throws SapphireException{
		
		String imgFolderUnixPath =  Util.generateIHCLocPath(unixPath+File.separator+labname, folderDS.getValue(0, "sponcername", ""), 
				folderDS.getValue(0, "projname", ""), "Flow", imgSubFolderPath);
		String imgFolderWindowPath = imgFolderUnixPath.replace(unixPath, mappedWindowPath);
		imgFolderWindowPath = imgFolderWindowPath.replaceAll("/", "\\\\");
		
		
		PropertyList pl =new PropertyList();
		pl.setProperty("inputfile", mappedWindowPath+File.separator+xmlFilePath+File.separator+fileName);
		pl.setProperty("outputimgpath", imgFolderWindowPath);
		
		getActionProcessor().processAction(ProcessFlowImage.ID, ProcessFlowImage.VERSIONID, pl);
		String response = pl.getProperty("response");
		File file = null;
		if(response != null && response.equalsIgnoreCase("Success")){
			int j=1;
			for(int i=0 ; i<j ;i++){
				String imgName = pl.getProperty("fcsjpegimg"+j,"");
				if("".equals(imgName))
					break;
					
				file = new File(imgFolderUnixPath+File.separator+imgName);
				loadSDIAttachment( accessionId,"FlowImage", "JPEG",file);
				j++;
			}
		}
	}
	private void loadPDF(DataSet filterDS, String fileName,String accessionId) throws SapphireException{
		
		String pdfFolderPath =  Util.generateIHCLocPath(unixPath+File.separator+labname, folderDS.getValue(0, "sponcername", ""), 
				folderDS.getValue(0, "projname", ""), "Flow", pdfSubFolderPath);
		
			
		for(int i=0;i<filterDS.size();i++){
			byte[] base64Val= Base64.decodeBase64(filterDS.getValue(i, "data_source_base64_data", "")); 
			try{
				File file = new File(pdfFolderPath+File.separator+StringUtil.split(fileName, " ")[0]+"-"+currentTime+"-"+(i+1)+".pdf");
				file.createNewFile();
				FileOutputStream fop = new FileOutputStream(file);
				
				fop.write(base64Val);
				fop.flush();
				fop.close();
				loadSDIAttachment( accessionId,"FlowWorkBook", "PDF",file);
			}catch (Exception e) {
				moveToFailureFolder(fileName);
				throw new SapphireException("Error occured while procesing xml file pdf- FileName::"+fileName+"\n"+e.getMessage());
			}
		}
	}
	
	private void loadSDIAttachment(String keyid1, String keyid2, String type,File file) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
		pl.setProperty(AddSDIAttachment.PROPERTY_KEYID1, keyid1);
		pl.setProperty(AddSDIAttachment.PROPERTY_KEYID2, keyid2);
		pl.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, file.getName());
		pl.setProperty(AddSDIAttachment.PROPERTY_FILENAME, file.getPath());
		pl.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
		pl.setProperty("u_attachmenttype", type);
        getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, pl);
	}
	
	private void completeXMLStatus(String accessionId) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, accessionId);
		pl.setProperty("flowxmlstatus", "Completed");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	}
	
	private void updateDataSetForNewValueInSamePanel(DataSet xmlDS,DataSet staggingDS){
		for(int i=0;i<xmlDS.size();i++){
			String value = xmlDS.getValue(i, "markerid", "");
			if(!"".equals(value))
				staggingDS.setValue(staggingDS.findRow("markerid", value), "markervalue",xmlDS.getValue(i, "exported_item_value", ""));
		}
	}
	
	private DataSet initilizeDataSet(DataSet xmlDS){
		xmlDS.addColumn("markerid", DataSet.STRING);
		xmlDS.addColumn("gateid", DataSet.STRING);
		xmlDS.addColumn("panelid", DataSet.STRING);
		xmlDS.addColumn("accessionid", DataSet.STRING);
		xmlDS.addColumn("lvtestcodeid", DataSet.STRING);
		xmlDS.addColumn("reportoptionid", DataSet.STRING);
		xmlDS.addColumn("rowid", DataSet.STRING);
		xmlDS.addColumn("workitemid", DataSet.STRING);
		xmlDS.addColumn("fcsdate", DataSet.STRING);
		xmlDS.addColumn("fcstime", DataSet.STRING);
		xmlDS.addColumn("iterationnumber", DataSet.STRING);
		xmlDS.addColumn("exported_item_type", DataSet.STRING);
		xmlDS.addColumn("exported_item_name", DataSet.STRING);
		xmlDS.addColumn("exported_item_value", DataSet.STRING);
		xmlDS.addColumn("exported_item_format", DataSet.STRING);
		xmlDS.addColumn("exported_item_resolution", DataSet.STRING);
		xmlDS.addColumn("exported_item_width", DataSet.STRING);
		xmlDS.addColumn("exported_item_height", DataSet.STRING);
		xmlDS.addColumn("data_source_type", DataSet.STRING);
		xmlDS.addColumn("data_source_size", DataSet.STRING);
		xmlDS.addColumn("data_source_base64_data", DataSet.STRING);
		
		return xmlDS;
	}
	
	private void moveToSuccessFolder(String fileName) throws SapphireException {
        
        File file = new File(xmlInputDir +File.separator+ fileName);
        File dir = new File(xmlOutputDir + File.separator+"Success"+File.separator + folderDt + File.separator);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if (file.isFile()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                Logger.logInfo(file.getName() + ":: File Moved to Success folder");
        }
    }
	
	private void moveToFailureFolder(String fileName) throws SapphireException {
        
        File file = new File(xmlInputDir +File.separator+ fileName);
        File dir = new File(xmlOutputDir + File.separator+"Failure"+File.separator + folderDt + File.separator);

        if (!dir.exists())
            if (dir.mkdirs())
                Logger.logInfo(dir.getPath() + ":: created successfully");

        if (file.isFile()) {
            if (file.renameTo(new File(dir.getPath() + File.separator + file.getName())))
                Logger.logInfo(file.getName() + ":: File Moved to Failure folder");
        }
    }
	
	private DataSet getFolderPath(String accessionId) throws SapphireException{
		String sql = Util.parseMessage(FlowSql.GET_GENERIC_FOLDER_DETAIL, accessionId);
		folderDS = getQueryProcessor().getSqlDataSet(sql);
		if(folderDS == null || folderDS.size() == 0){
			logger.error("Please specify the Flow Image/PDF directories");
			throw new SapphireException("Please specify the Image/Flow PDF directories");
		}
		
		return folderDS;
	}
}
