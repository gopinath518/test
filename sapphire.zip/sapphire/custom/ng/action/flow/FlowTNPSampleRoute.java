package sapphire.custom.ng.action.flow;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class FlowTNPSampleRoute extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String accessionID = properties.getProperty("keyid","");
        String sampleID = "";
        String tubeSampleID = "";
        if(Util.isNull(accessionID))
            throw new SapphireException("accession id could not be blank");
        String sql = Util.parseMessage(FlowSql.GET_CSSAMPLE_BY_ACCESIONID, StringUtil.replaceAll(accessionID, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds == null || ds.size()==0)
            throw new SapphireException("Samples are not in Storage. Accession could not move");
        else{
            sampleID = ds.getColumnValues("s_sampleid",";");
            routeCellSuspensionSample(sampleID);
        }
        String tubesql = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, StringUtil.replaceAll(sampleID, ";", "','"));
        DataSet dstube = getQueryProcessor().getSqlDataSet(tubesql);
        if(dstube != null && dstube.size()>0){
            tubeSampleID = dstube.getColumnValues("s_sampleid",";");
            routetubeSample(tubeSampleID);
        }
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, accessionID);
        pl.setProperty("flowstatus", "");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);






    }

    private void routeCellSuspensionSample(String sampleid)throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currentmovementstep", "FlowStaining");
        pl.setProperty("u_flowsampletype", "");
        pl.setProperty("u_flowsamplesufficient", "Y");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        }
        catch (SapphireException se) {
            throw new SapphireException("Error.Unable to Edit Sample : "+se.getMessage());
        }
        pl.clear();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currenttramstop", "Staining");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        }
        catch (SapphireException se) {
            throw new SapphireException("Error.Unable to Edit Trackitem : "+se.getMessage());
        }
    }
    private void routetubeSample(String sampleid)throws SapphireException {
        String stmsql = Util.parseMessage(FlowSql.GET_SAMPLETESTCODEMAPID_BY_SAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsstmstatus = getQueryProcessor().getSqlDataSet(stmsql);
        if(dsstmstatus != null && dsstmstatus.size()>0){
            DataSet dsFilter;
            HashMap<String, String> hmap = new HashMap<>();
            hmap.put("teststatus", "Discard");
            dsFilter = dsstmstatus.getFilteredDataSet(hmap);
            if(dsFilter != null && dsFilter.size()>0){
                PropertyList pl = new PropertyList();
                pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                pl.setProperty(EditSDI.PROPERTY_KEYID1,dsFilter.getColumnValues("u_sampletestcodemapid",";") );
                pl.setProperty("teststatus", "In Progress");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

            }

        }


    }

    }
