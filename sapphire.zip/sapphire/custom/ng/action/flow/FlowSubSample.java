package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.AddSDIAttribute;
import sapphire.action.AdjustTrackItemInv;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowSubSample extends BaseAction {
	public static final String ID = "FlowSubSample";
	public static final String VERSIONID = "1";
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		String sampleId = properties.getProperty("sampleid","");
        String volUsed = properties.getProperty("volused","");
        String transportType = properties.getProperty("transporttype","");
        String testName = StringUtil.replaceAll(properties.getProperty("testname",""), ",", ";");
        String stepName = properties.getProperty("stepname","");
        
        String newSampleId = createChildSample(sampleId,volUsed,testName,transportType, stepName);
        properties.setProperty("newkeyid1", newSampleId);
	}
	
	private String createChildSample(String sampleId,String volUsed, String testName, String transportType, String stepName) throws SapphireException{
		 
		String sql = Util.parseMessage(FlowSql.GET_ROOT_SAMPLE_FROM_CS_SAMPLE,sampleId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		PropertyList prop = new PropertyList();
        //prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, ds.getValue(0, "u_rootsample"));
        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, sampleId);
        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES, "1");
        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");

        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
		 
		 String newKeyId1 = prop.getProperty("newkeyid1","");
		 if(stepName != null && "FlowProcessing".equalsIgnoreCase(stepName)) {
			 markFlowChildSample(newKeyId1);
			 adjustTrackitemVolume(sampleId, volUsed);// Update volume of Parent Sample
		 }
		 else if(stepName != null && "FlowLysing".equalsIgnoreCase(stepName))
			 markFlowLysingChildSample(newKeyId1);
		 updateTrackItem(newKeyId1,volUsed,transportType); //update child sample Trackitem
		 String panelId =getPanelId(StringUtil.replaceAll(testName, ",", ";"));
		 if(!"".equals(panelId)){
			 addPanelToChildSample(newKeyId1,panelId );
			 updateDilutionTubeInternalId(newKeyId1);
		 }
		 else
			  throw new SapphireException("Panel id not Found.");
		 return newKeyId1;
	 }
	private String getPanelId(String testName){
		String sql  = Util.parseMessage(FlowSql.GET_PANEL_ID, StringUtil.replaceAll(testName,";","','"));
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.size() > 0)
			return ds.getColumnValues("u_testcodeid", ";");
			
		return "";
	}
	 
	 private void updateTrackItem(String newKeyId1,String volUsed,String transportType) throws SapphireException{
		 PropertyList pl = new PropertyList();
		 pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		 pl.setProperty(EditTrackItem.PROPERTY_KEYID1, newKeyId1);
		 //pl.setProperty("qtycurrent", volUsed);
		 //pl.setProperty("qtyunits", "ml");
		 pl.setProperty("containertypeid", transportType);
		 pl.setProperty("u_currenttramstop", "Processing");
		 
		 getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	 }
	 
	 private void adjustTrackitemVolume(String sampleId, String volUsed) throws SapphireException{
		 String sql = Util.parseMessage(FlowSql.GET_TRACKITEM_ID, sampleId);
		 DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		 if(ds != null && ds.size()>0){
			 PropertyList pl = new PropertyList();
			 pl.setProperty(AdjustTrackItemInv.PROPERTY_TRACKITEMID, ds.getValue(0, "trackitemid"));
			 pl.setProperty(AdjustTrackItemInv.PROPERTY_QUANTITY, "-"+volUsed);
			 getActionProcessor().processAction(AdjustTrackItemInv.ID, AdjustTrackItemInv.VERSIONID, pl);
		 }
	 }
	 
	 private void markFlowChildSample(String sampleId) throws SapphireException{
			PropertyList pl = new PropertyList();
			pl.setProperty(AddSDIAttribute.PROPERTY_SDCID,"Sample");
			pl.setProperty(AddSDIAttribute.PROPERTY_ATTRIBUTEID,"flowrootsample");
			pl.setProperty(AddSDIAttribute.PROPERTY_VALUE,"N");
			pl.setProperty(AddSDIAttribute.PROPERTY_KEYID1, sampleId);
			getActionProcessor().processAction(AddSDIAttribute.ID, AddSDIAttribute.VERSIONID, pl);
		}
	 private void markFlowLysingChildSample(String sampleId) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDIAttribute.PROPERTY_SDCID,"Sample");
		pl.setProperty(AddSDIAttribute.PROPERTY_ATTRIBUTEID,"flowsampletype");
		pl.setProperty(AddSDIAttribute.PROPERTY_VALUE,"LysingSub");
		pl.setProperty(AddSDIAttribute.PROPERTY_KEYID1, sampleId);
		getActionProcessor().processAction(AddSDIAttribute.ID, AddSDIAttribute.VERSIONID, pl);
	}
	 
	 private void addPanelToChildSample(String childSampleId, String testName)throws SapphireException {
//		 Util.copyTestCodeFromParent(childSampleId, getQueryProcessor(), getActionProcessor());
		 	int copy = StringUtil.split(testName, ";").length; 
		 	PropertyList pl = new PropertyList();
			pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,StringUtil.repeat(childSampleId, copy,";"));
			pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,testName);
			pl.setProperty("flowtubesample","Y");
			getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
	 }
	 
	 private void updateDilutionTubeInternalId(String newKeyId1)throws SapphireException{
		 String sql = Util.parseMessage(FlowSql.GET_DILUTION_TUBE_BY_CS, newKeyId1, newKeyId1);
		 DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		 String[] internalIdArr = StringUtil.split(ds.getValue(0, "u_flowsampleid", ""), ".");
		 
		 String interId = internalIdArr[0]+FlowConstants.FLOW_DILUTION_TUBE_TYPE+(ds.getInt(0, "cnt")+1);
		 
		 PropertyList props = new PropertyList();
		 props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
         props.setProperty(EditSDI.PROPERTY_KEYID1, newKeyId1);
         props.setProperty("u_flowsampleid", interId);
         props.setProperty("u_currentmovementstep", "FlowLysing");
         props.setProperty("u_flowsamplereceivedt", "n");
         props.setProperty("sampletypeid", "Cell Suspension");
         
         getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
         
        props.clear();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, newKeyId1);
        props.setProperty("containertypeid", "Tube");
        
		getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
	 }
}
