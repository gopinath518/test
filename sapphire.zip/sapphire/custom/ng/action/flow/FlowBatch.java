package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowBatch extends BaseAction {
	
	 String newkeyid1 = "";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String sampleid = properties.getProperty("sampleid", "");
        String batchName = properties.getProperty("batchname", "");
        String origin = properties.getProperty("origin", "");
        String nxtMovementStep = properties.getProperty("nxtmovementstep", "");
        String nxtTramStop = properties.getProperty("nxttramstop", "");

        if (batchName.contains("/")) {
            throw new SapphireException("Batch name does not support ' <b>/</b> ' operator as system can not recognize.");
        }

        Util.validateDuplicateBatchName(batchName, origin, getQueryProcessor());

        addNgBatchName(sampleid,origin, batchName);
        addNgBatchSample(newkeyid1, sampleid);
        changeSampleCurrentMovement(sampleid, nxtMovementStep);
        changeCurrentTramstop(sampleid, nxtTramStop);
        if("FlowStaining".equalsIgnoreCase((origin))){
        	String sql = Util.parseMessage(FlowSql.VERIFY_FOR_CHILD_CS, StringUtil.replaceAll(sampleid, ";", "','"));
        	DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        	String tubeIds = enableTubeSample(ds.getColumnValues("p_sample", ";"));
        	addNgBatchSample(newkeyid1,tubeIds);
        }

        properties.setProperty("msg", "Batch: "+batchName+" created Successfully");
    }

    public void addNgBatchName(String sampleid,String origin, String batchName) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatch");
        pl.setProperty("batchtype", origin);
        pl.setProperty("origin", origin);
        pl.setProperty("batchname", batchName);
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        newkeyid1 = pl.getProperty("newkeyid1");
    }

    public void addNgBatchSample(String newkeyid1, String sampleid) throws SapphireException {
    	PropertyList pl = new PropertyList();
        int copy = StringUtil.split(sampleid, ";").length;
        pl.setProperty(AddSDI.PROPERTY_SDCID, "NGBatchFlowSample");
        pl.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copy));
        pl.setProperty("u_ngbatchid", newkeyid1);
//        pl.setProperty("linkid", "u_ngbatch_sample_link");
        pl.setProperty("sampleid", sampleid);

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
    }

    public void changeSampleCurrentMovement(String sampleid, String nxtMovementStep) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currentmovementstep", nxtMovementStep);

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    public void changeCurrentTramstop(String sampleid, String nxtTramStop) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
        pl.setProperty("u_currenttramstop", nxtTramStop);

        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
    }
    public void changeCurrentTramstop(String sampleid, String nxtTramStop,String toDepartment) throws SapphireException {
    	PropertyList pl = new PropertyList();
    	pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
    	pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
    	pl.setProperty("u_currenttramstop", nxtTramStop);
    	pl.setProperty("custodialdepartmentid", toDepartment);
    	pl.setProperty("custodialuserid", "(null)");
    	
    	getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
    }
    
    public String enableTubeSample(String sampleId) throws SapphireException{
    	String sql = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, StringUtil.replaceAll(sampleId, ";", "','"));
    	DataSet ds = getQueryProcessor().getSqlDataSet(sql);
    	String tubeIds = "";
    	if(ds != null && ds.size() >0){
    		tubeIds = ds.getColumnValues("s_sampleid", ";");
	    	String departmentId = connectionInfo.getDefaultDepartment();
	    	changeSampleCurrentMovement( tubeIds, "FlowStainingBatch") ;
	    	changeCurrentTramstop(tubeIds,  "Staining", departmentId);
	    	/**
	    	 * Section to set flow receive date of tubes in Sample SDC-TODO
	    	 */
	    	PropertyList pl = new PropertyList();
	    	pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
	    	pl.setProperty(EditSDI.PROPERTY_KEYID1, tubeIds);
	    	pl.setProperty("u_flowsamplereceivedt", "n");
	    	getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	    	/**
	    	 * Section to set flow receive date of tubes in Sample SDC-TODO
	    	 */
    	}
    	return tubeIds;
    }
}
