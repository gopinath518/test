/**
 * 
 */
package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class CreateExtraCryogenTube extends BaseAction implements FlowConstants{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String rootSample = properties.getProperty("mastersampleid", "");
		String sampleCount = properties.getProperty("samplecount", "");
		String panel = properties.getProperty("flowpanel", "");
		String sampleId = properties.getProperty("sampleid", "");
		String internalId = FLOW_CRYO_SAMPLE_TYPE;
		if(!Util.isNull(rootSample) && !Util.isNull(sampleCount) && !Util.isNull(sampleId)){
			int noOfCryoTubeToBeCreated = Integer.parseInt(sampleCount);
			String query = Util.parseMessage(FlowSql.GET_CRYO_TUBE_COUNT, sampleId, sampleId);
			DataSet ds = getQueryProcessor().getSqlDataSet(query);
			if(ds != null && ds.getRowCount() > 0){
				int count = ds.getInt(0, "cryosamplecount", 0);
				String tempInternalId = ds.getValue(0, "flowinternalid", "");
				
				PropertyList prop = new PropertyList();
		        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, rootSample);
		        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES , String.valueOf(noOfCryoTubeToBeCreated));
		        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, YES_VALUE);
		        prop.setProperty(CreateChildSamples.PROPERTY_ADD_EXTRA_PROPERTY, "u_flowsampleid;u_currentmovementstep;u_flowsamplereceivedt");
		        prop.setProperty("u_flowsampleid", this.generateFlowInternalId(tempInternalId, internalId, noOfCryoTubeToBeCreated, count));
		        prop.setProperty("u_currentmovementstep", StringUtil.repeat(FLOW_CS_FREEZING, noOfCryoTubeToBeCreated, ";"));
		        prop.setProperty("u_flowsamplereceivedt", "n");
		        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
		        
		        String newKeyId1 = prop.getProperty("newkeyid1","");
		        updateTrackItem(newKeyId1);
		        Util.setSampleTypeContainerType(newKeyId1, "Cell Suspension", "Cryotube", getActionProcessor());
		        String[] panelArr = StringUtil.split(panel, ";");
		        for(String panelData : panelArr){
	        		if(!Util.isNull(panelData)){
	        			this.addPanelToChildSample(newKeyId1, panelData);
	        		}
		        }
			}
		}
	}
	
	private void updateTrackItem(String sampleId) throws SapphireException{
		PropertyList pl = new PropertyList();
    	pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
    	pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
    	pl.setProperty("u_currenttramstop", "Cell Suspension Freezing");
    	pl.setProperty("custodialdepartmentid", connectionInfo.getDefaultDepartment());
    	pl.setProperty("custodialuserid", "(null)");
    	
    	getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	}
	
	private String generateFlowInternalId (String parentFlowInternalId, String internalId, int sampleCount, int cryoSampleCount){
		String returnString = "";
		for(int i = 0; i < sampleCount; i++){
			int cryoNum = cryoSampleCount+i+1;
			returnString += parentFlowInternalId+internalId+cryoNum+";";
		}
		
		return returnString.substring(0, returnString.length()-1);
	}
	
	private void addPanelToChildSample(String childSampleId, String testName)throws SapphireException {
	 	int copy = StringUtil.split(childSampleId, ";").length; 
	 	PropertyList pl = new PropertyList();
		pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,childSampleId);
		pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,StringUtil.repeat(testName, copy,";"));
		pl.setProperty("flowtubesample",YES_VALUE);
		getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
	}
}
