/**
 * 
 */
package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class CreateCytoSpinInStaining extends BaseAction implements FlowConstants{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sampleIds = properties.getProperty("sampleids", "");
		if(Util.isNull(sampleIds)){
			throw new SapphireException("ERROR_TYPE", ErrorDetail.TYPE_FAILURE, "Sample(s) not found");
		}
		String tempInternalId = FLOW_SPIN_SAMPLE_TYPE;
		String newKeyId1 = EMPTY_STRING;
		String sql = Util.parseMessage(FlowSql.GET_ROOT_SAMPLE_FROM_CS_SAMPLE, StringUtil.replaceAll(sampleIds, ";", "','"));
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.getRowCount() > 0){
			for(int i=0; i<ds.getRowCount(); i++){
				String masterSampleId = ds.getValue(i, "u_rootsample", "");
				String tempFlowId = ds.getValue(i, "u_flowsampleid", "");
				PropertyList prop = new PropertyList();
				int copy = StringUtil.split(tempInternalId, ";").length;
				
				prop.clear();
		        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, masterSampleId);
		        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES , String.valueOf(copy));
		        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, YES_VALUE);
		        prop.setProperty(CreateChildSamples.PROPERTY_ADD_EXTRA_PROPERTY, "u_flowsampleid;u_currentmovementstep");
		        prop.setProperty("u_flowsampleid", generateFlowInternalId(tempFlowId,tempInternalId));
		        prop.setProperty("u_currentmovementstep", StringUtil.repeat(FLOW_CYTO_SPIN, copy, ";"));
		        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
		        
		        newKeyId1 += ";"+prop.getProperty("newkeyid1","");
			}
			if(!Util.isNull(newKeyId1)){
				newKeyId1 = newKeyId1.substring(1);
				properties.setProperty("newkeyid1", "Generated new CytoSpin specimen :: "+newKeyId1);
				String[] panelArr = StringUtil.split(ds.getColumnValues("lvtestpanelid", ";"), ";");
				for(String panelData : panelArr){
					if(!Util.isNull(panelData)){
						this.addPanelToChildSample(newKeyId1, panelData);
					}
				}
				Util.setSampleTypeContainerType(newKeyId1, "Cyto Spin", "Slide", getActionProcessor());
			}
		}
	}
	
	private String generateFlowInternalId (String parentFlowInternalId, String abbreviation){
		String returnString = "";
		String [] tempAbbreviation = StringUtil.split(abbreviation, ";");
		for(int i = 0; i < tempAbbreviation.length; i++){
			returnString += parentFlowInternalId+""+tempAbbreviation[i]+";";
		}
		
		return returnString.substring(0, returnString.length()-1);
	}
	
	private void addPanelToChildSample(String childSampleId, String testName)throws SapphireException {
	 	int copy = StringUtil.split(childSampleId, ";").length; 
	 	PropertyList pl = new PropertyList();
		pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,childSampleId);
		pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,StringUtil.repeat(testName, copy,";"));
		pl.setProperty("flowtubesample",YES_VALUE);
		getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
	}
}
