/**
 * 
 */
package sapphire.custom.ng.action.flow;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import org.tempuri.neogen.flowimageservice.ImageServiceSoap;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.handler.multiomyx.LWSServiceWSSecurityHandler;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.EncryptDecrypt;
import sapphire.custom.ng.util.GenericServiceUtil;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 *Action to call remote service to generate flow image
 */
public class ProcessFlowImage extends BaseAction implements FlowConstants{

	public static final String ID = ProcessFlowImage.class.getSimpleName();
	public static final String VERSIONID = "1";
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String inputFile = properties.getProperty("inputfile","");
		String outputPath = properties.getProperty("outputimgpath","");
		
		DataSet ds = getQueryProcessor().getSqlDataSet(FlowSql.GET_FLOW_IMAGE_SERVICE_INFO);
		String endPoint = Util.getRemoteServicePropsData(ds, FLOW_SERVICE_URL);
		String token = Util.getRemoteServicePropsData(ds, FLOW_IMAGESERVICE_TOKEN);
		ImageServiceSoap proxy = GenericServiceUtil.getImageServiceProxy(endPoint);
		
		BindingProvider bp = (BindingProvider)proxy;
        List<Handler> handlerChain = new ArrayList<>();
        handlerChain.add(new LWSServiceWSSecurityHandler(EncryptDecrypt.decrypt(token)));
        bp.getBinding().setHandlerChain(handlerChain);
        bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endPoint);
		
		PropertyList pl = new PropertyList();
		pl.setProperty("inputfile", inputFile);
		pl.setProperty("outputimgpath", outputPath);
		
		String result = proxy.extractFCSImages(pl.toXMLString());
		
		properties.setPropertyList(result);
	}
}
