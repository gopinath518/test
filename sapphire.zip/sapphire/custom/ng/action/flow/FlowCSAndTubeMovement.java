/**
 * 
 */
package sapphire.custom.ng.action.flow;

import com.labvantage.sapphire.actions.sdi.EditSDI;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * @author sudeepta.pal
 *
 */
public class FlowCSAndTubeMovement extends BaseAction {

	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String csSample = properties.getProperty("keyid1", "");
		if(Util.isNull(csSample)){
			throw new SapphireException("Cell Suspension specimen not found");
		}
		this.updateCurrentMoementStep(csSample, "FlowCSStorage");
		String query = Util.parseMessage(FlowSql.VERIFY_FOR_CHILD_CS, StringUtil.replaceAll(csSample, ";", "','"));
		DataSet tempDS = getQueryProcessor().getSqlDataSet(query);
		
		query = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, tempDS.getColumnValues("p_sample", ";"));
		DataSet ds = getQueryProcessor().getSqlDataSet(query);
		ds= Util.filterNullValue(ds,"u_currentmovementstep","null");
		if(ds != null && ds.getRowCount() > 0){
			String tubeSample = ds.getColumnValues("s_sampleid", ";");
			this.updateCurrentMoementStep(tubeSample, "FlowStainingStorage");
		}
//		throw new SapphireException("Test");
		
	}

	/********************************************
	 * Method to move CS sample to CS storage 
	 * and tubes to Tube storage
	 * @param csSample
	 * @param step
	 * @throws SapphireException
	 ********************************************/
	private void updateCurrentMoementStep(String csSample, String step) throws SapphireException {
		PropertyList pl = new PropertyList();
		pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
		pl.setProperty(EditSDI.PROPERTY_KEYID1, csSample);
		pl.setProperty("u_currentmovementstep", step);
		getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
	}
}
