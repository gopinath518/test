package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * 
 * @author sudeepta.pal
 *
 */
public class FlowQCComplete extends BaseAction{
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		// TODO Auto-generated method stub
		String sdcId = properties.getProperty("sdcid", "");
		String keyId1 = properties.getProperty("keyid1", "");
		String flowStatus = properties.getProperty("flowstatus", "");
		String currentUser = connectionInfo.getSysuserId();
		
		PropertyList pl = new PropertyList();
		
		String query = Util.parseMessage(FlowSql.GET_SITE_FROM_SYS_USER, currentUser);
		DataSet ds = getQueryProcessor().getSqlDataSet(query);
		
		String sql = Util.parseMessage(FlowSql.GET_SDITESTCODEID_FROM_ACCESSION, StringUtil.replaceAll(keyId1, ";", "','"));
		DataSet rs = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.getRowCount() > 0 && rs != null && rs.getRowCount() > 0){
			pl.setProperty(EditSDI.PROPERTY_SDCID, sdcId);
			pl.setProperty(EditSDI.PROPERTY_KEYID1, keyId1);
			pl.setProperty("flowstatus", flowStatus);
			pl.setProperty("flowreceivedate", "n");
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
			
			pl.clear();
			pl.setProperty(EditSDI.PROPERTY_SDCID, "SDITestCode");
			pl.setProperty(EditSDI.PROPERTY_KEYID1, rs.getColumnValues("u_sditestcodeid", ";"));
			pl.setProperty("tca", ds.getValue(0, "u_site", ""));
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		}
	}
}
