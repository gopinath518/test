package sapphire.custom.ng.action.flow;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowReplacePanel extends BaseAction{
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleId = properties.getProperty("sampleid","");
		String newPanelId = properties.getProperty("newpanelid","");
		String cancelPanelName = properties.getProperty("cancelpanelname","");
		String cancelPanelId = getPanelId(cancelPanelName);
		
		if("".equals(sampleId) || "".equals(newPanelId) || "".equals(cancelPanelId))
			throw new SapphireException("SampleId, New PanelId, and Cancel Panel Id is required");
		
		Util.replacePanel(sampleId, cancelPanelId , newPanelId, getActionProcessor());
	}
	
	private String getPanelId(String testName){
		String sql  = Util.parseMessage(FlowSql.GET_PANEL_ID, StringUtil.replaceAll(testName, ";", "','"));
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		if(ds != null && ds.size() > 0)
			return ds.getColumnValues("u_testcodeid", ";");
			
		return "";
	}
}
