package sapphire.custom.ng.action.flow;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.AssignTestCode;
import sapphire.custom.ng.action.util.CreateChildSamples;
import sapphire.custom.ng.constants.FlowConstants;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * 
 * @author sudeepta.pal
 *
 */

public class CreateFlowStainingTube extends BaseAction implements FlowConstants{
	
	public static final String ID = "CreateFlowStainingTube";
	public static final String VERSIONID = "1";
	public static final String PROPERTY_KEYID1 = "keyid1";
	public static final String PROPERTY_FLAG = "flag";
	public static final String PROPERTY_PANEL = "panelid";

	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		String sampleId = properties.getProperty("keyid1","");
		String intenalId = properties.getProperty("intenalid","");
		String flag = properties.getProperty("flag","");
		String panelid = properties.getProperty("panelid","");
		String newkeyid1= getFlowSampleInfoByPanel(sampleId,flag,panelid,intenalId);
		properties.setProperty("tubeid",newkeyid1);
//		throw new SapphireException("Test");
	}
	
	private String getFlowSampleInfoByPanel(String sampleId,String flag,String panelid, String intenalId) throws SapphireException {
		String tempInternalId="";
		String newKeyId1 = "";
		String andClause="";
//		if(flag.equalsIgnoreCase("flowaddpanel"))
//			andClause="and lvtestpanelid in('"+StringUtil.replaceAll(panelid, ";", "','")+"')";
		String sql = Util.parseMessage(FlowSql.GET_SAMPLE_ABB_AND_REAGENT, StringUtil.replaceAll(sampleId, ";", "','"),andClause);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		HashMap<String,String> hm = new HashMap<String, String>();
		
		if(ds != null && ds.size()>0){
			String [] tempArr = StringUtil.split(sampleId, ";");
			
			for(int i = 0; i < tempArr.length; i++){
				hm.clear();
				hm.put("s_sampleid", tempArr[i]);
				DataSet filterDS = ds.getFilteredDataSet(hm);
				tempInternalId = Util.getUniqueList(filterDS.getColumnValues("sampleabbreviation", ";"), ";", true);
//				
//				String tempFlowId = Util.getUniqueList(filterDS.getColumnValues("u_flowsampleid", ";"), ";", true);
				String [] tempPanelId = StringUtil.split(Util.getUniqueList(filterDS.getColumnValues("lvtestpanelid", ";"), ";", true),";");
				PropertyList prop = new PropertyList();
				int copy = StringUtil.split(intenalId, ";").length;
				
				prop.clear();
		        prop.setProperty(CreateChildSamples.PROPERTY_PARENT_SAMPLEID, sampleId);
		        prop.setProperty(CreateChildSamples.PROPERTY_CHILD_COPIES , String.valueOf(copy));
		        prop.setProperty(CreateChildSamples.PROPERTY_SYNCPARENT, "Y");
		        prop.setProperty(CreateChildSamples.PROPERTY_ADD_EXTRA_PROPERTY, "u_flowsampleid;containertypeid;u_currentmovementstep;sampletypeid");
		        prop.setProperty("u_flowsampleid", generateFlowInternalId(sampleId,intenalId));
		        prop.setProperty("u_currentmovementstep", StringUtil.repeat("", copy, ";"));
		        prop.setProperty("sampletypeid", StringUtil.repeat("Cell Suspension", copy, ";"));
		        getActionProcessor().processAction(CreateChildSamples.ID, CreateChildSamples.VERSIONID, prop);
		        
		        newKeyId1 = prop.getProperty("newkeyid1","");
		        updateTrackitem(newKeyId1);
		        for(int j = 0;j<tempPanelId.length;j++){
			        if(!"".equals(tempPanelId[j]))
						 addPanelToChildSample(newKeyId1,tempPanelId[j]);
		        }
			}
		}
		return newKeyId1;
	}
	private void updateTrackitem(String sampleid) throws SapphireException{
		PropertyList pl = new PropertyList();
		pl.clear();
		pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
		pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleid);
		pl.setProperty("containertypeid", "Staining Tube");
		getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
	}
	
	private String generateFlowInternalId ( String sampleId, String intenalId){
		String sql = Util.parseMessage(FlowSql.GET_TUBE_COUNT, sampleId);
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		String returnString = "";
		boolean tubeFlag = true;
		String [] tempAbbreviation = StringUtil.split(intenalId, ";");
		if(ds != null && ds.getRowCount() > 0){
			for(int i = 0; i < tempAbbreviation.length; i++){
				tubeFlag = true;
				for(int j=0;j<ds.size();j++){
					String[] tubeAbb = StringUtil.split(tempAbbreviation[i],".");
					if(ds.getValue(j, "tubeid").contains(tubeAbb[1])){
						tubeFlag = false;
						returnString += tempAbbreviation[i]+".R"+ds.getValue(j, "tubecount")+";";
						break;
					}
				}
				if(tubeFlag)
					returnString += tempAbbreviation[i]+".R1;";
				
			}
		}else{
			for(int i = 0; i < tempAbbreviation.length; i++){
				returnString += tempAbbreviation[i]+".R1;";
			}
		}
		
		return returnString.substring(0, returnString.length()-1);
	}
	
	private void addPanelToChildSample(String childSampleId, String testName)throws SapphireException {
		 	int copy = StringUtil.split(childSampleId, ";").length; 
		 	PropertyList pl = new PropertyList();
			pl.setProperty(AssignTestCode.INPUT_PROPERTY_SAMPLE_ID,childSampleId);
			pl.setProperty(AssignTestCode.INPUT_PROPERTY_LV_TEST_CODE,StringUtil.repeat(testName, copy,";"));
			pl.setProperty("flowtubesample",YES_VALUE);
			getActionProcessor().processAction(AssignTestCode.ID, AssignTestCode.VERSION_ID, pl);
	 }
}
