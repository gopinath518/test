package sapphire.custom.ng.action.flow;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.action.util.CancelPanelForSample;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
/**
 * Created by soumik.sen on 14/2/2018.
 */

public class FlowRemovePanel extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException  {
        String tubeId="";
        String allSampleId ="";
        String parentId = "";
        String cellSuspId = properties.getProperty("sampleid","");
        String panelid = properties.getProperty("panelid","");

        if(Util.isNull(cellSuspId))
            throw new SapphireException("Sampleid could not be blank");
        if(Util.isNull(panelid))
            throw new SapphireException("panelid could not be blank");

        String sql = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, StringUtil.replaceAll(cellSuspId, ";", "','"));
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if(ds != null && ds.size() >0) {
            tubeId = ds.getColumnValues("s_sampleid", ";");
            parentId = ds.getColumnValues("u_rootsample", ";");
            parentId = Util.getUniqueList(parentId,";",true);
            allSampleId = cellSuspId+";"+tubeId+";"+parentId;
            String allsamplearr [] = allSampleId.split(";");
            for(int i=0;i<allsamplearr.length;i++) {
                PropertyList pl = new PropertyList();
                pl.setProperty(CancelPanelForSample.PROPERTY_SAMPLEID, allsamplearr[i]);
                pl.setProperty(CancelPanelForSample.PROPERTY_PANELID, panelid);

                getActionProcessor().processAction(CancelPanelForSample.ID, CancelPanelForSample.VERSIONID, pl);
            }

        }
    }
}
