package sapphire.custom.ng.action.flow;

import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.flow.FlowSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class FlowChangeSampleSufficient extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleId = properties.getProperty("sampleid", "");
        String sampleSuff = properties.getProperty("samplesufficient", "");
        String sampleType = properties.getProperty("sampletype", "");
        String accessionid = properties.getProperty("accessionid", "");
        String flowAccessionType = properties.getProperty("flowaccessiontype", "");

        changeSampleType(sampleId, sampleSuff, sampleType,accessionid,flowAccessionType);
    }

    private void changeSampleType(String sampleId, String sampleSuff, String sampleType,String accessionId, String flowAccessionType) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
        pl.setProperty("u_flowsamplesufficient", sampleSuff);
        pl.setProperty("u_flowsampletype", sampleType);

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

        if ("N".equalsIgnoreCase(sampleSuff) && "QNS".equalsIgnoreCase(sampleType)) {
            moveSampleToFlowPathSupport(sampleId,accessionId,flowAccessionType);
        }
    }

    private void moveSampleToFlowPathSupport(String sampleId,String accesionId, String flowAccessionType) throws SapphireException {
        //String currentUsrdepartment = connectionInfo.getDefaultDepartment();
        //if (!Util.isNull(currentUsrdepartment)) {
           // String site = StringUtil.split(currentUsrdepartment, "-")[0];
           // if (!Util.isNull(site)) {
               // String destDept = site + "-" + "Accessioning";
                String tubesamplesql = Util.parseMessage(FlowSql.GET_TUBE_SAMPLE_FROM_CELL_SUSPENSION_ID, StringUtil.replaceAll(sampleId, ";", "','"));
                DataSet dstubesample = getQueryProcessor().getSqlDataSet(tubesamplesql);
                DataSet ds = new DataSet();

                if (dstubesample != null && dstubesample.size() > 0) {
                	String allsampleid = sampleId + ";" + dstubesample.getColumnValues("s_sampleid", ";");
                	String sql = Util.parseMessage(FlowSql.GET_NGFLOWSAMPLEID_BY_SAMPLEID, StringUtil.replaceAll(allsampleid, ";", "','"));
                	ds = getQueryProcessor().getSqlDataSet(sql);
                	updateSample(sampleId, "FlowCSStorage");
                	updateTrackitem(sampleId, "Cell Suspension Storage");
                	updateAccession(accesionId,flowAccessionType);
                    String sampleid = dstubesample.getColumnValues("s_sampleid", ";");
                    //updateSample(sampleid, "");
                    //updateTrackitem(sampleid, "", "");
                    String sampletestcodemapid = Util.parseMessage(FlowSql.GET_SAMPLETESTCODEMAPID_BY_SAMPLE, StringUtil.replaceAll(sampleid, ";", "','"));
                    DataSet dsstm = getQueryProcessor().getSqlDataSet(sampletestcodemapid);
                    DataSet dsFilter;
                    HashMap<String, String> hmap = new HashMap<>();
                    hmap.put("teststatus", "In Progress");
                    dsFilter = dsstm.getFilteredDataSet(hmap);
                    if(dsFilter != null && dsFilter.size()>0) {
                        PropertyList pl = new PropertyList();
                        pl.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
                        pl.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("u_sampletestcodemapid", ";"));
                        pl.setProperty("teststatus", "Discard");
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
                    }

                }
                if(ds != null && ds.size() > 0) {
                    PropertyList pl = new PropertyList();
                    pl.setProperty(DeleteSDI.PROPERTY_SDCID, "NGBatchFlowSample");
                    pl.setProperty(DeleteSDI.PROPERTY_KEYID1, ds.getColumnValues("u_ngbatchflowsampleid", ";"));
                    getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, pl);
                }
           // }
        //}
    }

    private void updateSample(String sampleId, String movementstep) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, sampleId);
        pl.setProperty("u_currentmovementstep", movementstep);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

    private void updateTrackitem(String sampleId, String currenttramstop) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        pl.setProperty(EditTrackItem.PROPERTY_KEYID1, sampleId);
        pl.setProperty("u_currenttramstop", currenttramstop);
        //pl.setProperty("custodialdepartmentid", deprtid);
        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
    }
    private void updateAccession(String accessionId, String flowAccessionType) throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, accessionId);
        pl.setProperty("flowstatus", "FlowPathSupport");
        pl.setProperty("flowaccessiontype", flowAccessionType);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
    }

}