package sapphire.custom.ng.action;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EnterDataItem;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
/**
 * Created by gpandi on 11/2/2016.
 */
public class ExcelParserAction extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String plateId = properties.getProperty("selplateid");
        String fileName = properties.getProperty("path");
        String fileType = properties.getProperty("filetype");
        Logger.logInfo("Selected Plate Id::"+plateId+"::Path::"+fileName+"::Filetype::"+fileType);

        LinkedHashMap<String,Integer> headerPositionMap = new LinkedHashMap<String,Integer>();
        LinkedHashMap<String,ArrayList<String>> wellPostionWithExcelRowValues = new LinkedHashMap<String,ArrayList<String>>();
        DataSet dsSampleWell  = getSampleIdsWithWellPositionMap (plateId,fileType);
        parseExcelData(fileName,headerPositionMap,wellPostionWithExcelRowValues);
        updateExcelDataForParamValues(fileType,dsSampleWell,headerPositionMap,wellPostionWithExcelRowValues);
    }

    public DataSet getSampleIdsWithWellPositionMap (String plateId,String filetype){

//        String paramValueList = "";
        String testCode = "";
        if(filetype.equalsIgnoreCase("BCL1")) {
//            paramValueList = "'% POSITIVITY BCL1','BCL1',CT','IC'";
            testCode = "'4002X'";
        }
        else if(filetype.equalsIgnoreCase("BCR")) {
//            paramValueList = "'ABL CT','ABL PG','BCR-190 CT','BCR-190 PG','BCR-M CT','BCR-M PG'";
            testCode = "'4005X'";
        }
        else if(filetype.equalsIgnoreCase("PML")) {
//            paramValueList = "'ABL PG','LONG PG','LONG RATIO','PML SHORT CT','SHORT PG','SHORT RATIO','PML LONG CT','ABL','AML','AML RATIO','AML CT','ABL','INV16','INV16 RATIO','INV16 CT','ABL','TEL-AML','TEL-AML RATIO','TEL-AML CT','WT','EGFRVIII','EGFRVIII RATIO','EGFRVIII CT'";
            testCode = "'4015X','4038X','4039X','4040X','4208X'";
        }else if(filetype.equalsIgnoreCase("MLH1")){
        	testCode = "'4083X'";
        }
        else if(filetype.equalsIgnoreCase("MGMT")){
        	testCode = "'4084X'";
        }
        
        /** Query Functionality -> With the selected plate -> Sample Id and well position will be retrieved -> Corresponding well position pcr analyte will be mapped to reporting analyte
         *  Assuming the new field column name "POSITION" of table U_NGBATCH_CONTROL and U_BATCH_SAMPLE_DETAIL will not be null
         */
             
        String sampleWell = new StringBuffer("SELECT MAPDATA.SAMPLEID,   MAPDATA.ANALYTEID,   MAPDATA.POSITION,   MAPDATA.TESTCODEID,   MAPDATA.REPORTINGANALYTE,  MAPDATA.PCRANALYTE, ")
        					.append( " MAPDATA.PARAMLISTID,    MAPDATA.PARAMLISTVERSIONID,    MAPDATA.VARIANTID,    MAPDATA.DATASET,    MAPDATA.PARAMID,    MAPDATA.PARAMTYPE,    MAPDATA.REPLICATEID,   MAPDATA.WORKITEMID ")
							.append(" FROM ") 
							.append("  (SELECT SAMPLEDATA.SAMPLEID,  SAMPLEDATA.ANALYTEID,  SAMPLEDATA.POSITION, SAMPLEDATA.TESTCODEID,  PR.REPORTINGANALYTE, PR.PCRANALYTE, ")
							.append(" 	 SDI.PARAMLISTID,    SDI.PARAMLISTVERSIONID,    SDI.VARIANTID,    SDI.DATASET,    SDI.PARAMID,    SDI.PARAMTYPE,    SDI.REPLICATEID,   SWI.WORKITEMID ")
							.append("  FROM ") 
							.append("    (SELECT SAMPLEID, ANALYTEID, POSITION, TESTCODEID FROM U_BATCH_SAMPLE_DETAIL ") 
							.append("    UNION ") 
							.append("    SELECT SAMPLEID, ANALYTE, POSITION, TESTCODEID FROM U_NGBATCH_CONTROL " )
							.append("    ) SAMPLEDATA, " )
							.append("    U_PCRREPANALYTEMAP PR, ") 
							.append("    SDIDATAITEM SDI, " )
							.append("    SDIWORKITEM SWI, " )
							.append("    SDIDATA SD " )
							.append("  WHERE SAMPLEDATA.SAMPLEID  = SWI.KEYID1 ") 
							.append("  AND SWI.SDCID              = SD.SDCID " )
							.append("  AND SWI.KEYID1             = SD.KEYID1 ")
							.append("  AND SWI.WORKITEMID         = SD.SOURCEWORKITEMID ") 
							.append("  AND SD.SDCID               = SDI.SDCID ") 
							.append("  AND SD.KEYID1              = SDI.KEYID1 ") 
							.append("  AND SD.PARAMLISTID         = SDI.PARAMLISTID ")
							.append("  AND SD.PARAMLISTVERSIONID  = SDI.PARAMLISTVERSIONID " )
							.append("  AND SD.VARIANTID           = SDI.VARIANTID ")
							.append("  AND SD.DATASET             = SDI.DATASET ") 
							.append("  AND SDI.PARAMID            = PR.REPORTINGANALYTE ") 
							.append("  AND SDI.DATATYPES         <> 'NC' " )
							.append("  AND SAMPLEDATA.ANALYTEID   = PR.PCRANALYTE " )
							.append("  AND SAMPLEDATA.TESTCODEID IN("+testCode+") " )
							.append("  AND SAMPLEDATA.TESTCODEID  = PR.TESTCODE " )
							.append("  AND SAMPLEDATA.POSITION   IS NOT NULL ") 
							.append("  ) MAPDATA, " )
							.append("  ARRAYITEM A1, " )
							.append("  ARRAYITEMCONTENT A2, ")
							.append("  U_TESTCODE TC " )
							.append("WHERE A1.ARRAYID     = '"+plateId+"' " )
							.append("AND A1.ARRAYITEMID   = A2.ARRAYITEMID " )
							.append("AND A2.CONTENTKEYID1 = MAPDATA.SAMPLEID " )
							.append("AND TC.U_TESTCODEID  = MAPDATA.TESTCODEID " )
							.append("AND A1.ITEMLABEL     = MAPDATA.POSITION").toString();

        DataSet dsSampleWell = getQueryProcessor().getSqlDataSet(sampleWell);
        Logger.logInfo("dsSampleWell Result");
        dsSampleWell.showData();
        return dsSampleWell;
    }

    public void parseExcelData(String fileName,LinkedHashMap<String,Integer> headerPositionMap,
                               LinkedHashMap<String,ArrayList<String>> wellPostionWithExcelRowValues)throws SapphireException {
            final String cellContent = "Well";
            ArrayList<String> rowValues = null;
            try {
                XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(new File(fileName)));
                XSSFSheet sheet = wb.getSheetAt(0);
                int startPosition = findRow(sheet,cellContent );
                for (int rowNum = startPosition; rowNum < sheet.getPhysicalNumberOfRows(); rowNum++) {
                    Row row = sheet.getRow(rowNum);
                    if (rowNum == startPosition) {
                        for (int i = 0; i < row.getLastCellNum(); i++) {
                            Cell cell = row.getCell(i);
                            headerPositionMap.put(cell.getStringCellValue().toUpperCase(),i);
                        }
                        Logger.logInfo("Excel header Position Value ::"+headerPositionMap);
                    } else {
                        rowValues = new ArrayList<String>();
                        if(row==null || getWellPosition(row,headerPositionMap) == null || getWellPosition(row,headerPositionMap).equals(""))
                            continue;
                        for (int i = 0; i <row.getLastCellNum(); i++) {
                            Cell cell = row.getCell(i);
                            if (cell != null) {
                                switch (cell.getCellType()) {
                                    case Cell.CELL_TYPE_NUMERIC:
                                        rowValues.add(String.valueOf(cell.getNumericCellValue()));
                                        continue;
                                    case Cell.CELL_TYPE_STRING:
                                        rowValues.add(cell.getStringCellValue());
                                        continue;
                                    case Cell.CELL_TYPE_BOOLEAN:
                                        rowValues.add(String.valueOf(cell.getBooleanCellValue()));
                                        continue;
                                    case Cell.CELL_TYPE_BLANK:
                                        rowValues.add("");
                                        continue;
                                }
                            }else
                                rowValues.add("");
                          }
                        wellPostionWithExcelRowValues.put(getWellPosition(row,headerPositionMap),rowValues);
                    }
                    Logger.logInfo("Excel Row Position Value ::"+wellPostionWithExcelRowValues);
                }
            }catch(Exception e) {
                e.printStackTrace();
                String __errorMssg = "Error During parsing Excel Sheet " + e.getMessage();
                Logger.logError(__errorMssg);
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, __errorMssg);
            }
        }

    private String getWellPosition(Row row, LinkedHashMap<String,Integer> headerPositionMap){
        Cell cell = row.getCell(headerPositionMap.get("WELL"));
        String wellPositionId = "";
        try {
            if (cell != null) {
                switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_NUMERIC:
                        wellPositionId =  String.valueOf((int)cell.getNumericCellValue());
                        break;
                    case Cell.CELL_TYPE_STRING:
                        wellPositionId = "";
                        break;
                }
            }
            if(!"".equals(wellPositionId)) {
            	Logger.logInfo("Before wellPositionId ::"+wellPositionId);
            	int id = (Integer.parseInt(wellPositionId) / 12) + 1;
        	    int posNumber = Integer.parseInt(wellPositionId) % 12;
        	    if(posNumber == 0){
        	    	posNumber = 12;
        	    	id = id-1;
        	    }
        	    String posAlphabet = id > 0 && id < 27 ? String.valueOf((char) (id + 'A' - 1)) : null;
        	    wellPositionId = posAlphabet + posNumber;
        	    Logger.logInfo("After wellPositionId ::"+wellPositionId);
            }
        }catch (Exception e){
            Logger.logError("Well Position Id not found in Excel sheet"+e.getMessage());
        }
        return wellPositionId;
    }

    public void updateExcelDataForParamValues( String fileType, DataSet dsSampleWell,
                                              LinkedHashMap<String,Integer> headerPositionMap,
                                              LinkedHashMap<String,ArrayList<String>> wellPostionWithExcelRowValues)throws SapphireException {
        PropertyList props = new PropertyList();
        if(dsSampleWell != null && dsSampleWell.size()>0) {
            try {
                DataSet dsResult = setEnteredTextValues(fileType, dsSampleWell, wellPostionWithExcelRowValues, headerPositionMap);
                Logger.logInfo("dsResult Result");
                dsResult.showData(); 
                props.setProperty(EnterDataItem.PROPERTY_SDCID, "Sample");
                props.setProperty(EnterDataItem.PROPERTY_KEYID1, dsResult.getColumnValues("sampleid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsResult.getColumnValues("paramlistid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsResult.getColumnValues("paramlistversionid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsResult.getColumnValues("variantid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_DATASET, StringUtil.repeat("1", dsResult.size(), ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMID, dsResult.getColumnValues("paramid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsResult.getColumnValues("paramtype", ";"));
                props.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsResult.getColumnValues("replicateid", ";"));
                props.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y" );
                props.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsResult.getColumnValues("enteredtext", ";"));

                getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, props);

            } catch (Exception e) {
                Logger.logError("Error during updating values in SDIDataItems");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "Not able to update the Analyte values please contact the administrator. ");
            }
        }
    }
    public DataSet setEnteredTextValues(String fileType, DataSet dsSampleWell,LinkedHashMap<String,
                                     ArrayList<String>> wellPostionWithExcelRowValues,
                                     LinkedHashMap<String,Integer> headerPositionMap){
        String []wellIdArr = StringUtil.split(dsSampleWell.getColumnValues("position",";"),";");
        String []pramIdArr = StringUtil.split(dsSampleWell.getColumnValues("paramid",";"),";");

        ArrayList<String> rowValueList = new ArrayList<String>();
        DataSet dsResult = new DataSet();

        if(wellIdArr != null && pramIdArr!= null && wellIdArr.length > 0 && pramIdArr.length > 0 ) {
            dsResult.addColumn("enteredtext", DataSet.STRING);
            String val = "";
            for (int i = 0; i < wellIdArr.length; i++) {
                val = "";
                if(wellPostionWithExcelRowValues.containsKey(wellIdArr[i])) {
                    rowValueList = wellPostionWithExcelRowValues.get(wellIdArr[i]);

                    val = getParameterValue(fileType, rowValueList, headerPositionMap, pramIdArr[i]);
                    Logger.logInfo("wellId ::"+wellIdArr[i]+":: Value ::"+val);
                    try {
                        Float.parseFloat(val);
                        dsResult.copyRow(dsSampleWell, i, 1);
                        dsResult.setValue(dsResult.getRowCount()-1, "enteredtext", val);
                    }catch (Exception e){
                        continue;
                    }
                }
            }
        }
        return dsResult;
    }
    

    private String getParameterValue(String fileType, ArrayList<String> rowValueList, LinkedHashMap<String,Integer> headerPositionMap, String paramName){
        String paramValue = "";
        try {
            if (fileType.equalsIgnoreCase("BCL1")) {
                if (paramName.equalsIgnoreCase("BCL1") || paramName.equalsIgnoreCase("IC"))
                    paramValue = rowValueList.get(headerPositionMap.get("QUANTITY"));
                else if (paramName.equalsIgnoreCase("CT") || paramName.equalsIgnoreCase("BCL1 CT"))
                    paramValue = rowValueList.get(headerPositionMap.get("CT"));
            } 
            else if (fileType.equalsIgnoreCase("BCR")) {
                if (paramName.equalsIgnoreCase("ABL PG") || paramName.equalsIgnoreCase("BCR-190 PG") || paramName.equalsIgnoreCase("BCR-M PG"))
                    paramValue = rowValueList.get(headerPositionMap.get("QUANTITY"));
                else if (paramName.equalsIgnoreCase("ABL CT") || paramName.equalsIgnoreCase("BCR-190 CT") || paramName.equalsIgnoreCase("BCR-M CT"))
                    paramValue = rowValueList.get(headerPositionMap.get("CT"));
            } 
            else if (fileType.equalsIgnoreCase("PML")) {

                if (paramName.equalsIgnoreCase("ABL PG") || paramName.equalsIgnoreCase("LONG PG") || paramName.equalsIgnoreCase("SHORT PG")
                        || paramName.equalsIgnoreCase("ABL") || paramName.equalsIgnoreCase("AML") || paramName.equalsIgnoreCase("INV16")
                        || paramName.equalsIgnoreCase("TEL-AML") || paramName.equalsIgnoreCase("WT") || paramName.equalsIgnoreCase("EGFRVIII"))
                    paramValue = rowValueList.get(headerPositionMap.get("QUANTITY"));
                
                else if (paramName.equalsIgnoreCase("ABL CT") || paramName.equalsIgnoreCase("PML SHORT CT") || paramName.equalsIgnoreCase("PML LONG CT") 
                		|| paramName.equalsIgnoreCase("AML CT") || paramName.equalsIgnoreCase("INV16 CT") || paramName.equalsIgnoreCase("TEL-AML CT") 
                		|| paramName.equalsIgnoreCase("WT CT")|| paramName.equalsIgnoreCase("EGFRvII CT"))
                    paramValue = rowValueList.get(headerPositionMap.get("CRT"));
            }
            else if(fileType.equalsIgnoreCase("MLH1") || fileType.equalsIgnoreCase("MGMT")){
            	
            	if (paramName.equalsIgnoreCase("UNMETHYLATED") || paramName.equalsIgnoreCase("METHYLATED"))
                    paramValue = rowValueList.get(headerPositionMap.get("QUANTITY"));
            	
            	else if (paramName.equalsIgnoreCase("UNMETHYLATED CT") || paramName.equalsIgnoreCase("METHYLATED CT"))
            		paramValue = rowValueList.get(headerPositionMap.get("CT"));
            }
           
            Logger.logInfo("fileType::"+fileType+":: paramValue ::"+paramValue);
        }catch( Exception e){
            Logger.logError("Unable to get param values from Excel sheet.");
        }
        return paramValue;
    }

    private int findRow(XSSFSheet sheet, String cellContent){
        int rowNum = 0;
        for(Row row : sheet) {
            for(Cell cell : row) {
                if(cell.getCellType() == Cell.CELL_TYPE_STRING){
                    if(cell.getStringCellValue().trim().equalsIgnoreCase(cellContent)){
                        rowNum = row.getRowNum();
                        return rowNum;
                    }
                }
            }
        }
        return rowNum;
    }
    
    
    public String enterDataItemCommonJoin(String aliasSDIWORKITEMTable, String aliasSDIDATAITEMTable, String aliasSDIDATATable){
    	
    	return   aliasSDIWORKITEMTable+".SDCID ="+aliasSDIDATATable+".SDCID AND " +
    			 aliasSDIWORKITEMTable+".KEYID1            = "+aliasSDIDATATable+".KEYID1 AND " +
    			 aliasSDIWORKITEMTable+".WORKITEMID        = "+aliasSDIDATATable+".SOURCEWORKITEMID AND " +
    			 aliasSDIDATATable+".SDCID              = "+aliasSDIDATAITEMTable+".SDCID AND " +
    			 aliasSDIDATATable+".KEYID1             = "+aliasSDIDATAITEMTable+".KEYID1 AND " +
    			 aliasSDIDATATable+".PARAMLISTID        = "+aliasSDIDATAITEMTable+".PARAMLISTID AND " +
    			 aliasSDIDATATable+".PARAMLISTVERSIONID = "+aliasSDIDATAITEMTable+".PARAMLISTVERSIONID AND " +
    			 aliasSDIDATATable+".VARIANTID          = "+aliasSDIDATAITEMTable+".VARIANTID AND " +
    			 aliasSDIDATATable+".DATASET            = "+aliasSDIDATAITEMTable+".DATASET ";
    }

}
