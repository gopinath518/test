package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by SBaitalik on 12/5/2016.
 * Description: This is used to complete best H&E to the next tramstop and others specimens to the next specimens
 */
public class CompletePathSupportRecon extends BaseAction {

    String msg = "Operation Successful";

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid");
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Please select atleast one specimen.");
        }
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), sampleid);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }
            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String sql = Util.parseMessage(ApSql.GET_SPECIMEN_INFO_ALL, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        if (dsInfo.size() > 0) {
            hm.clear();
            hm.put("u_isbesthne", "Y");
            DataSet dsBestHNEFiletr = dsInfo.getFilteredDataSet(hm);
            if (dsBestHNEFiletr.size() > 0) {
                String bstsampleids = StringUtil.replaceAll(dsBestHNEFiletr.getColumnValues("s_sampleid", ";"), ";", "','");
                sql = Util.parseMessage(ApSql.GET_BEST_HNE_TESTCODES_BY_SAMPLEID, bstsampleids);
                DataSet dsBestHNE = getQueryProcessor().getSqlDataSet(sql);
                if (dsBestHNE.size() > 0) {
                    String site = StringUtil.split(connectionInfo.getDefaultDepartment(), "-")[0];
                    PropertyList prop = new PropertyList();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, dsBestHNEFiletr.getColumnValues("s_sampleid", ";"));
                    prop.setProperty("u_currentmovementstep", "Accession");
                    prop.setProperty("u_accessioningcomplete", "N");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                    msg += "Specimen(s): " + dsBestHNEFiletr.getColumnValues("s_sampleid", ",");
                    prop.clear();
                    prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditTrackItem.PROPERTY_KEYID1, dsBestHNEFiletr.getColumnValues("s_sampleid", ";"));
                    prop.setProperty("custodialdepartmentid", site + "-Accessioning");
                    prop.setProperty("custodialuserid", "(null)");
                    prop.setProperty("u_currenttramstop", "Choose best specimen/Accessioning");
                    try {
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                    String blocks = dsBestHNEFiletr.getColumnValues("u_rootsample", ";");
                    storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), blocks);
                    if (storageStaus != null && storageStaus.size() > 0) {
                        DataSet dsDisplayMsg = new DataSet();
                        dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
                        dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
                        for (int i = 0; i < storageStaus.size(); i++) {
                            int rowID = dsDisplayMsg.addRow();
                            dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                            dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
                        }
                        String errCodes = Util.getDisplayMessage(dsDisplayMsg);
                        throw new SapphireException("Please Check-Out sample(s) from the storage." + errCodes);
                    }
                    String u_accessionid = dsBestHNEFiletr.getColumnValues("u_accessionid", ";");
                    prop.clear();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, blocks);
                    prop.setProperty("u_currentmovementstep", "Accession");
                    prop.setProperty("u_accessioningcomplete", "N");
                    prop.setProperty("u_isbesthne", "Y");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                    prop.clear();
                    prop.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    prop.setProperty(EditTrackItem.PROPERTY_KEYID1, blocks);
                    prop.setProperty("custodialdepartmentid", site + "-Accessioning");
                    prop.setProperty("custodialuserid", "(null)");
                    prop.setProperty("u_currenttramstop", "Choose best specimen/Accessioning");
                    try {
                        getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                    prop.clear();
                    prop.setProperty(EditSDI.PROPERTY_SDCID, "Accession");
                    prop.setProperty(EditSDI.PROPERTY_KEYID1, u_accessionid);
                    prop.setProperty("stauts", "(null)");
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                    } catch (Exception ec) {
                        throw new SapphireException("Action failed to update Best H&E" + ec.getMessage());
                    }
                    msg += "," + blocks + " has/have been moved to <b>Choose Best Specimen</b> in Accession Tramline.";
                } else {
                    PropertyList prop = new PropertyList();
                    prop.setProperty("sampleid", bstsampleids);
                    prop.setProperty("u_currentmovementstep", u_currentmovementstep);
                    prop.setProperty("custodialdepartmentid", custodialdepartmentid);
                    try {
                        getActionProcessor().processAction("AssignToMySite", "1", prop);
                    } catch (Exception ec) {
                        throw new SapphireException(ec.getMessage());
                    }
                }
            } else {
                throw new SapphireException("Please select best H&E specimen.");
            }
        }
        properties.setProperty("msg", msg);
        //throw new SapphireException("test");
    }
}