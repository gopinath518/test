package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

/**
 * Created by kshahbaz on 6/29/2016.
 */
public class GenerateBatchManifest extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException{
        String batchId = properties.getProperty("u_ngbatchid");
        String url = "rc?command=ViewReport&reportid=BatchManifest&reportversionid=1&batchId=" +batchId+ "&mode=submitarg&displaytype=pdf";
        String text = "<script>" +
                "var form = document.createElement(\"form\");" +
                "document.body.appendChild(form);" +
                "form.method = \"POST\";" +
                "form.action= \"" + url + "\";" +
                "form.target=\"_blank\";" +
                "form.submit();" +
                "document.body.removeChild(form);" +
                "</script>";


        properties.setProperty("msg", text);

    }
}
