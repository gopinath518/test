package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.RecordIncident;
import sapphire.action.SubmitSDIForApproval;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 11/18/2016.
 */
public class IhcTestAddOn extends BaseAction {


    public void processAction(PropertyList properties) throws SapphireException {
        String accessionid = properties.getProperty("accessionid");
        String parentid = properties.getProperty("parentid");
        String testcodeid = properties.getProperty("testcodeid");
        String description = properties.getProperty("description");
        String userid = properties.getProperty("userid");
        String version = properties.getProperty("version");
        String dept ="";
        String user =  getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        if(department == null){
            dept = "";
        }else
         dept = department.substring(0, department.indexOf("-"));

    PropertyList recordProp = new PropertyList();
    recordProp.setProperty("sourcesdcid", "Sample");
    recordProp.setProperty("sourcekeyid1", parentid);
    recordProp.setProperty("incidentcategory", "UnPlanned");
    recordProp.setProperty("incidentdesc", "Test add on" + testcodeid + " for accession- " + accessionid + " specimen id " + parentid);
    recordProp.setProperty("explanation", "Request to Test add on " + testcodeid + " for accession- " + accessionid + " specimen id " + parentid + "\n" + description);
    recordProp.setProperty("rootcause", "Test add on" + testcodeid + " for accession- " + accessionid + " specimen id " + parentid);
    recordProp.setProperty("u_fromdepartment", department);
    recordProp.setProperty("initialstatus", "PendingApproval");
    recordProp.setProperty("reportedby", user);
    recordProp.setProperty("departmentid", dept + "-ClientServices");
    recordProp.setProperty("departmentid", "FM-ClientServices");
    recordProp.setProperty("u_message", "Request to Test add on " + testcodeid + " for accession- " + accessionid + " specimen id " + parentid + "\n" + description);
    getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);

    PropertyList approvalProps = new PropertyList();
    approvalProps.setProperty("sdcid", "LV_Incdt");
    approvalProps.setProperty("keyid1", recordProp.getProperty("newkeyid1"));
    approvalProps.setProperty("pendingapprovalstatus", "PendingApproval");
    approvalProps.setProperty("approvalstatus", "Approved");
    approvalProps.setProperty("approvalstatuscolumn", "incidentstatus");
    getActionProcessor().processAction(SubmitSDIForApproval.ID, SubmitSDIForApproval.VERSIONID, approvalProps);

    }
}
