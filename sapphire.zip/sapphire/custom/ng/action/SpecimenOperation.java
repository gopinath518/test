package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class SpecimenOperation extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String keyid1 = properties.getProperty("keyid1");
        String eventtype = properties.getProperty("eventtype");
        String currentstep = properties.getProperty("currentstep");
        String evntreason = properties.getProperty("evntreason");
        if (Util.isNull(keyid1)) {
            throw new SapphireException("Specimen(s) can't be blank");
        }
        DataSet storageStaus = Util.checkPermanentStorageStatus(getQueryProcessor(), keyid1);
        if (storageStaus != null && storageStaus.size() > 0) {
            DataSet dsDisplayMsg = new DataSet();
            dsDisplayMsg.addColumn("specimen_id", DataSet.STRING);
            dsDisplayMsg.addColumn("storage_location", DataSet.STRING);
            for (int i = 0; i < storageStaus.size(); i++) {
                int rowID = dsDisplayMsg.addRow();
                dsDisplayMsg.setValue(rowID, "specimen_id", storageStaus.getValue(i, "s_sampleid", ""));
                dsDisplayMsg.setValue(rowID, "storage_location", storageStaus.getValue(i, "permanentloc", ""));
            }

            String errCodes = Util.getDisplayMessage(dsDisplayMsg);
            throw new SapphireException("Please Check-Out specimen(s) from the storage." + errCodes);
        }
        String sql = Util.parseMessage(ApSql.GET_SPECIMNES_BY_ID, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsSampleInfo = getQueryProcessor().getSqlDataSet(sql);
        sql = Util.parseMessage(ApSql.GET_TESTS_ONLY_BY_SPECIMENS, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsTestInfo = getQueryProcessor().getSqlDataSet(sql);
        if (!dsSampleInfo.isValidColumn("hastest")) {
            dsSampleInfo.addColumn("hastest", DataSet.STRING);
        }
        if (!dsSampleInfo.isValidColumn("sampletestmapid")) {
            dsSampleInfo.addColumn("sampletestmapid", DataSet.STRING);
        }
        HashMap hm = new HashMap();
        if (dsSampleInfo != null && dsSampleInfo.size() > 0) {
            for (int i = 0; i < dsSampleInfo.size(); i++) {
                String sampleid = dsSampleInfo.getValue(i, "s_sampleid");
                hm.clear();
                hm.put("s_sampleid", sampleid);
                DataSet dsTestFilter = dsTestInfo.getFilteredDataSet(hm);
                if (dsTestFilter.size() > 0) {
                    dsSampleInfo.setValue(i, "hastest", "Y");
                    dsSampleInfo.setValue(i, "sampletestmapid", dsTestFilter.getColumnValues("u_sampletestcodemapid", ";"));
                } else {
                    dsSampleInfo.setValue(i, "hastest", "N");
                    dsSampleInfo.setValue(i, "sampletestmapid", "");
                }
            }
        }
        if ("delete".equalsIgnoreCase(eventtype)) {

            hm.clear();
            hm.put("hastest", "N");
            DataSet dsNotestFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsNotestFilter.size() > 0) {
                deleteSpecimen(keyid1, evntreason);
            }
            hm.clear();
            hm.put("hastest", "Y");
            DataSet dsHasTestFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsHasTestFilter.size() > 0) {
                String maspids = StringUtil.replaceAll(dsHasTestFilter.getColumnValues("sampletestmapid", ";"), "#semicolon#", ";");
                PropertyList prop = new PropertyList();
                prop.setProperty("keyid1", maspids);
                prop.setProperty("eventtype", eventtype);
                prop.setProperty("evntreason", evntreason);
                try {
                    //getActionProcessor().processAction("PerformTestcodeDel", "1", prop);//TODO NO NEED TO PERFORM OPERATION ON TESTCODE
                } catch (Exception ex) {
                    throw new SapphireException(ex.getMessage());
                }
                deleteSpecimen(keyid1, evntreason);
            }


        }
        if ("cancel".equalsIgnoreCase(eventtype)) {
            hm.clear();
            hm.put("hastest", "N");
            DataSet dsNotestFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsNotestFilter.size() > 0) {
                cancelSpecimens(keyid1, evntreason);
            }
            hm.clear();
            hm.put("hastest", "Y");
            DataSet dsHasTestFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsHasTestFilter.size() > 0) {
                String maspids = StringUtil.replaceAll(dsHasTestFilter.getColumnValues("sampletestmapid", ";"), "#semicolon#", ";");
                PropertyList prop = new PropertyList();
                prop.setProperty("keyid1", maspids);
                prop.setProperty("eventtype", eventtype);
                prop.setProperty("evntreason", evntreason);
                try {
                    //getActionProcessor().processAction("PerformTestcodeDel", "1", prop);//TODO NO NEED TO PERFORM OPERATION ON TESTCODE
                } catch (Exception ex) {
                    throw new SapphireException(ex.getMessage());
                }
                cancelSpecimens(keyid1, evntreason);
            }
            //cancelSpecimens(keyid1);
        }
        if ("undo".equalsIgnoreCase(eventtype)) {
            hm.clear();
            hm.put("hastest", "N");
            DataSet dsNotestFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsNotestFilter.size() > 0) {
                undoSpecimens(keyid1, currentstep);
            }
            hm.clear();
            hm.put("hastest", "Y");
            DataSet dsHasTestFilter = dsSampleInfo.getFilteredDataSet(hm);
            if (dsHasTestFilter.size() > 0) {
                String maspids = StringUtil.replaceAll(dsHasTestFilter.getColumnValues("sampletestmapid", ";"), "#semicolon#", ";");
                PropertyList prop = new PropertyList();
                prop.setProperty("keyid1", maspids);
                prop.setProperty("eventtype", eventtype);
                prop.setProperty("evntreason", evntreason);
                try {
                    //getActionProcessor().processAction("PerformTestcodeDel", "1", prop);//TODO NO NEED TO PERFORM OPERATION ON TESTCODE
                } catch (Exception ex) {
                    throw new SapphireException(ex.getMessage());
                }
                undoSpecimens(keyid1, currentstep);
            }
        }
    }

    private void cancelSpecimens(String keyid1, String evntreason) throws SapphireException {
        String sql = Util.parseMessage(ApSql.GET_CURRENTSTEP_BY_SAMPLE, StringUtil.replaceAll(keyid1, ";", "','"));
        DataSet dsCUrrentStep = getQueryProcessor().getSqlDataSet(sql);
        if (dsCUrrentStep.size() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, dsCUrrentStep.getColumnValues("s_sampleid", ";"));
            props.setProperty("u_previoustep", dsCUrrentStep.getColumnValues("u_currentmovementstep", ";"));
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canceled specimen(s)." + ex.getMessage());
            }
        }
        //u_previoustep
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty(EditSDI.PROPERTY_AUDITREASON, evntreason);
            props.setProperty("u_currentmovementstep", "Disposed");
            props.setProperty("samplestatus", "Disposed");
            props.setProperty("disposaldt", "n");
            props.setProperty("disposedby", connectionInfo.getSysuserId());
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canceled specimen(s).");
            }
        }
    }

    private void undoSpecimens(String keyid1, String currentstep) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            String sql = Util.parseMessage(ApSql.GET_PREVIOUS_STEP_BY_SAMPLE, StringUtil.replaceAll(keyid1, ";", "','"));
            DataSet dsSpecStps = getQueryProcessor().getSqlDataSet(sql);
            if (dsSpecStps != null && dsSpecStps.size() > 0) {
                String[] specArry = StringUtil.split(keyid1, ";");
                DataSet dsSample = new DataSet();
                dsSample.addColumn("sampleid", DataSet.STRING);
                dsSample.addColumn("currentsteps", DataSet.STRING);
                HashMap hm = new HashMap();
                for (int i = 0; i < specArry.length; i++) {
                    hm.clear();
                    hm.put("s_sampleid", specArry[i]);
                    DataSet dsStepFilter = dsSpecStps.getFilteredDataSet(hm);
                    int rowid = dsSample.addRow();
                    dsSample.setValue(rowid, "sampleid", specArry[i]);
                    dsSample.setValue(rowid, "currentsteps", dsStepFilter.getValue(0, "u_previoustep", ""));
                    //dsSample.setValue(rowid, "currentsteps", currentstep);
                }
                if (dsSample != null && dsSample.size() > 0) {
                    PropertyList props = new PropertyList();
                    props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    props.setProperty(EditSDI.PROPERTY_KEYID1, dsSample.getColumnValues("sampleid", ";"));
                    props.setProperty("u_currentmovementstep", dsSample.getColumnValues("currentsteps", ";"));
                    props.setProperty("samplestatus", StringUtil.repeat("Initial", dsSample.size(), ";"));
                    props.setProperty("storagestatus", StringUtil.repeat("In Circulation", dsSample.size(), ";"));
                    props.setProperty("disposaldt", StringUtil.repeat("(null)", dsSample.size(), ";"));
                    props.setProperty("disposedby", StringUtil.repeat("(null)", dsSample.size(), ";"));
                    props.setProperty("u_previoustep", StringUtil.repeat("(null)", dsSample.size(), ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
                    } catch (Exception ex) {
                        throw new SapphireException("Unable to undo specimen(s)." + ex.getMessage());
                    }
                }
            }
            /*PropertyList props = new PropertyList();
            props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(EditSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty("u_currentmovementstep", currentstep);
            props.setProperty("samplestatus", "Initial");
            props.setProperty("storagestatus", "In Circulation");
            props.setProperty("disposaldt", "(null)");
            props.setProperty("disposedby", "(null)");
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to canceled specimen(s).");
            }*/
        }
    }

    private void deleteSpecimen(String keyid1, String evntreason) throws SapphireException {
        if (!Util.isNull(keyid1)) {
            PropertyList props = new PropertyList();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, keyid1);
            props.setProperty(DeleteSDI.PROPERTY_AUDITREASON, evntreason);
            try {
                getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
            } catch (Exception ex) {
                throw new SapphireException("Unable to delete specimen(s)." + ex.getMessage());
            }
        }
    }

}
