package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.HashMap;

/**
 * Action Name- MolBatchSampleAddOn
 * Description: This Action is use add additional sample on a vatch
 * input :-
 * param1-batchid
 * param2-addonsampleid
 * throws SapphireException
 * Created by mpandey on 9/23/2016.
 */
public class MolBatchSampleAddOn extends BaseAction {
    ActionProcessor ap;
    QueryProcessor qp;
    String ngBatchId = "";
    String latestContent = "";
    String addOnSampleId = "";
    DataSet dsNGBatchInfo = null;
    private String boxId = "";
    private String new_control = "";
    private String batchName = "";
    private String extractiontype = "";
    public static final String batchSdcId = "NGBatch";

    public void processAction(PropertyList properties) throws SapphireException {
        ap = getActionProcessor();
        qp = getQueryProcessor();
        ngBatchId = properties.getProperty("batchid", "");
        addOnSampleId = properties.getProperty("addonsampleid", "");

        if (ngBatchId.length() > 0) {
            validateBatchNGetContent();

            if (dsNGBatchInfo.size() > 0) {
                addControlFlag();
                clearStorage();
                deleteControlSample();
                deleteAttachment();
                attachDetailInBatch();

            }
        } else {
            String err = "BatchId not found.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        properties.setProperty("boxid", boxId);
    }

    /**
     * This function is use to get the position in box
     * to load the dna type of extraction .
     *
     * @param plc
     * @param elTubeNo
     * @return
     * @throws SapphireException
     */
    private String getBoxPosToLdDNA(PropertyListCollection plc, String elTubeNo) throws SapphireException {
        if (plc != null && plc.size() > 0) {
            for (int i = 0; i < plc.size(); i++) {
                PropertyList tempPl = plc.getPropertyList(i);
                if (tempPl != null && tempPl.size() > 0) {
                    String sampleNo = tempPl.getProperty("noofsamples", "");
                    if (elTubeNo.equalsIgnoreCase(sampleNo))
                        return tempPl.getProperty("boxpos", "");
                }
            }
        }
        return "";
    }

    /**
     * This method is use to attach additional details in batch.
     *
     * @throws SapphireException
     */
    private void attachDetailInBatch() throws SapphireException {
        HashMap filter = new HashMap();
        filter.put("controlflag", "N");
        DataSet dsFiltered = dsNGBatchInfo.getFilteredDataSet(filter);
        if (dsFiltered.size() > 0) {
            latestContent = dsFiltered.getColumnValues("sampleid", ";") + ";" + addOnSampleId;
        } else
            latestContent = addOnSampleId;
        crtEluTubeForAddOnExtTubes();
        extractiontype = getExtractionType(latestContent);
        if (!Util.isNull(boxId)) {
            if (extractiontype.equalsIgnoreCase("Manual") || extractiontype.equalsIgnoreCase("TNA") || extractiontype.equalsIgnoreCase("Plasma")) {
                manualTubeChkInBox(boxId, latestContent, extractiontype);
            } else {
                //drnaTubeChkInBox(boxId, latestContent, extractiontype);
                manualTubeChkInBox(boxId, latestContent, extractiontype);
            }
            if (!Util.isNull(new_control)) {
                addOnSampleId = addOnSampleId + ";" + new_control;
            }
            attachAddOnSampleDetail(addOnSampleId, ngBatchId);
        }

    }

    /**
     * This method is use to attach sample details in batch.
     *
     * @param addOnSampleId
     * @param ngBatchId
     * @throws ActionException
     */
    private void attachAddOnSampleDetail(String addOnSampleId, String ngBatchId) throws ActionException {
        if (!Util.isNull(ngBatchId) && !Util.isNull(addOnSampleId)) {
            PropertyList pl = new PropertyList();
            pl.clear();
            pl.setProperty(AddSDIDetail.PROPERTY_SDCID, "NGBatch");
            pl.setProperty(AddSDIDetail.PROPERTY_KEYID1, ngBatchId);
            pl.setProperty(AddSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
            pl.setProperty("sampleid", addOnSampleId);
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, pl);
        }
    }

    /**
     * This method is use to check in samples in box where extraction type is dna.
     *
     * @param boxId
     * @param latestContent
     * @param extractiontype
     * @throws SapphireException
     */
    private void drnaTubeChkInBox(String boxId, String latestContent, String extractiontype) throws SapphireException {
        if (!Util.isNull(boxId) && !Util.isNull(latestContent)) {
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid =(select storageunitid from storageunit where linkkeyid1=?)";
            DataSet dsStorage = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{boxId});
            if (dsStorage != null && dsStorage.size() > 0) {
                PropertyList plElLdPolicy = getConfigurationProcessor().getPolicy("EllutionTubeLoadingPolicy", "custom");
                if (plElLdPolicy == null)
                    throw new SapphireException("Ellution tube loading policy is  not found in the system");
                PropertyListCollection plc = plElLdPolicy.getCollection("comb");
                if (plc == null || plc.size() == 0)
                    throw new SapphireException("EllutionTubeLoadingPolicy policy is not configured properly.");
                String elTubeArr[] = StringUtil.split(latestContent, ";");
                if (elTubeArr != null && elTubeArr.length > 0) {
                    //String boxPosToLd = getBoxPosToLdDNA(plc, Integer.toString(elTubeArr.length));
                    String boxPosToLd = getBoxPosToLdDNA(plc, Integer.toString(elTubeArr.length + 1)); // 1 for Control
                    if (!Util.isNull(boxPosToLd)) {
                        String boxPosArr[] = StringUtil.split(boxPosToLd, ";");
                        // if (boxPosArr.length != elTubeArr.length)
                        //    throw new SapphireException("Number of box positions to be loaded for " + elTubeArr.length + " " +
                        //            "ellution tube is not configured properly in the EllutionTubeLoadingPolicy policy");

                        DataSet result = new DataSet();
                        result.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
                        result.addColumn("currentstorageunitid", DataSet.STRING);
                        result.addColumn("boxposition", DataSet.STRING);
                        result.addColumn("iscontrol", DataSet.STRING);
                        HashMap<String, String> hmap = new HashMap<String, String>();
                        for (int i = 0; i < boxPosArr.length; i++) {
                            hmap.clear();
                            hmap.put("storageunitlabel", boxPosArr[i]);
                            DataSet dsStgFiltr = dsStorage.getFilteredDataSet(hmap);
                            if (dsStgFiltr != null && dsStgFiltr.size() > 0) {
                                int rowIndex = result.addRow();
                                String temStgId = dsStgFiltr.getValue(0, "storageunitid", "");
                                if (!Util.isNull(temStgId)) {
                                    if (i < elTubeArr.length) {
                                        result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, elTubeArr[i]);
                                        result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                        result.setValue(rowIndex, "boxposition", boxPosArr[i]);
                                        result.setValue(rowIndex, "iscontrol", "N");
                                    } else {
                                        result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, "");
                                        result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                        result.setValue(rowIndex, "boxposition", boxPosArr[i]);
                                        result.setValue(rowIndex, "iscontrol", "Y");
                                    }
                                }
                            }
                        }

                        hmap.clear();
                        hmap.put("iscontrol", "Y");
                        DataSet dsControl = result.getFilteredDataSet(hmap);
                        if (dsControl != null && dsControl.size() > 0) {
                            String controlSampleBoxPos = dsControl.getValue(0, "boxposition", "");
                            String temStgId = dsStorage.getValue(Integer.parseInt(controlSampleBoxPos) - 1, "storageunitid", "");
                            String temStgLblId = dsStorage.getValue(Integer.parseInt(controlSampleBoxPos) - 1, "storageunitlabel", "");
                            if (!Util.isNull(temStgId)) {
                                new_control = crateControlSample(batchName, temStgLblId);
                                // dsControl.setValue(0, EditTrackItem.PROPERTY_KEYID1, CONTROL_SAMPLE);
                                if (new_control.length() > 0) {
                                    PropertyList pl = new PropertyList();
                                    pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                                    pl.setProperty(EditTrackItem.PROPERTY_KEYID1, new_control);
                                    pl.setProperty("currentstorageunitid", temStgId);
                                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                                }
                            }
                        }

                        if (result != null && result.size() > 0) {
                            hmap.clear();
                            hmap.put("iscontrol", "N");
                            DataSet dsSample = result.getFilteredDataSet(hmap);
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, dsSample.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                            pl.setProperty("currentstorageunitid", dsSample.getColumnValues("currentstorageunitid", ";"));
                            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        }
                    }
                }
            }
        }
    }

    /**
     * This method is use to check in samples in box where extraction type is manual.
     *
     * @param boxId
     * @param latestContent
     * @param extractiontype
     * @throws SapphireException
     */
    private void manualTubeChkInBox(String boxId, String latestContent, String extractiontype) throws SapphireException {
        if (!Util.isNull(boxId) && !Util.isNull(latestContent)) {
            String sql = "select storageunitid,storageunitlabel,storageunitindex from storageunit where parentid =(select storageunitid from storageunit where linkkeyid1=?)";
            DataSet dsStorage = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{boxId});
            if (dsStorage != null && dsStorage.size() > 0) {
                String elTubeArr[] = StringUtil.split(latestContent, ";");
                if (elTubeArr != null && elTubeArr.length > 0) {
                    String boxPosToLd = getBoxPosToLdManual(extractiontype);
                    if (!Util.isNull(boxPosToLd)) {
                        String boxPosArr[] = StringUtil.split(boxPosToLd, ";");
                        DataSet result = new DataSet();
                        result.addColumn(EditTrackItem.PROPERTY_KEYID1, DataSet.STRING);
                        result.addColumn("currentstorageunitid", DataSet.STRING);
                        for (int i = 0; i < elTubeArr.length; i++) {
                            int rowIndex = result.addRow();
                            String temStgId = dsStorage.getValue(Integer.parseInt(boxPosArr[i]) - 1, "storageunitid", "");
                            if (!Util.isNull(temStgId)) {
                                result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, elTubeArr[i]);
                                result.setValue(rowIndex, "currentstorageunitid", temStgId);
                            }
                        }
                        String maxBoxPos = getMaxBoxPos(boxPosToLd, elTubeArr);
                        if (maxBoxPos.length() > 0) {
                            int rowIndex = result.addRow();
                            String temStgId = dsStorage.getValue(Integer.parseInt(maxBoxPos), "storageunitid", "");
                            String temStgLblId = dsStorage.getValue(Integer.parseInt(maxBoxPos), "storageunitlabel", "");
                            if (!Util.isNull(temStgId)) {
                                new_control = crateControlSample(batchName, temStgLblId);
                                //  result.setValue(rowIndex, EditTrackItem.PROPERTY_KEYID1, CONTROL_SAMPLE);
                                // result.setValue(rowIndex, "currentstorageunitid", temStgId);
                                if (new_control.length() > 0) {
                                    PropertyList pl = new PropertyList();
                                    pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_ReagentLot");
                                    pl.setProperty(EditTrackItem.PROPERTY_KEYID1, new_control);
                                    pl.setProperty("currentstorageunitid", temStgId);
                                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                                }
                            }
                        }
                        if (result != null && result.size() > 0) {
                            PropertyList pl = new PropertyList();
                            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, result.getColumnValues(EditTrackItem.PROPERTY_KEYID1, ";"));
                            pl.setProperty("currentstorageunitid", result.getColumnValues("currentstorageunitid", ";"));
                            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
                        }
                    }
                }
            }
        }
    }

    /**
     * This method is use to create elution tube for additional extraction tube.
     *
     * @throws SapphireException
     */
    private void crtEluTubeForAddOnExtTubes() throws SapphireException {
        PropertyList pl = new PropertyList();
        pl.setProperty("exttubeid", addOnSampleId);
        pl.setProperty("copies", "1");
        getActionProcessor().processAction("CrtElutionTube", "1", pl, false, false);
        String elTube = pl.getProperty("elTube", "");
        if (Util.isNull(elTube)) {
            throw new SapphireException("Failed to create Elution tube(s).");
        }
    }

    /**
     * This method is use to get extraction type for a sample.
     *
     * @param extTube
     * @return
     * @throws SapphireException
     */
    private String getExtractionType(String extTube) throws SapphireException {
        String uniqueext = "";

        String sql = "select extractiontype from u_sampletestcodemap where s_sampleid in ('" + extTube.replaceAll(";", "','") + "')";
        DataSet dsext = getQueryProcessor().getSqlDataSet(sql);
        if (dsext == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsext.size() == 0) {
            throw new SapphireException("Extraction type not found for samples");
        }
        uniqueext = Util.getUniqueList(dsext.getColumnValues("extractiontype", ";"), ";", true);
        String[] extarr = uniqueext.split(";");
        if (extarr.length > 1)
            throw new SapphireException("Extraction type must be same for all samples");


        return uniqueext;
    }


    /**
     * This method is use to mark control sample.
     *
     * @throws SapphireException
     */
    private void addControlFlag() throws SapphireException {
        String sql = "select s_sampleid from s_sample where s_sampleid in ('" + dsNGBatchInfo.getColumnValues("sampleid", "','") + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (!dsNGBatchInfo.isValidColumn("controlflag")) {
            dsNGBatchInfo.addColumn("controlflag", DataSet.STRING);
        }
        for (int i = 0; i < dsNGBatchInfo.size(); i++) {
            if (ds.findRow("s_sampleid", dsNGBatchInfo.getValue(i, "sampleid")) >= 0)
                dsNGBatchInfo.setValue(i, "controlflag", "N");
            else
                dsNGBatchInfo.setValue(i, "controlflag", "Y");

        }


    }

    /**
     * This method is use to delete existing attachment from  a batch.
     *
     * @throws SapphireException
     */
    private void deleteAttachment() throws SapphireException {

        PropertyList prop = new PropertyList();
        try {
            prop.setProperty(DeleteSDIAttachment.PROPERTY_SDCID, batchSdcId);
            prop.setProperty(DeleteSDIAttachment.PROPERTY_KEYID1, ngBatchId);
            getActionProcessor().processAction(DeleteSDIAttachment.ID, DeleteSDIAttachment.VERSIONID, prop);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from Attachment SDC");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }

    /**
     * This function is use to delete control sample from batch detail and reagent lot.
     *
     * @throws SapphireException
     */
    private void deleteControlSample() throws SapphireException {
        HashMap filter = new HashMap();
        filter.put("controlflag", "Y");
        DataSet dsFiltered = dsNGBatchInfo.getFilteredDataSet(filter);
        PropertyList props = new PropertyList();
        props.setProperty(DeleteSDIDetail.PROPERTY_SDCID, "NGBatch");
        props.setProperty(DeleteSDIDetail.PROPERTY_KEYID1, ngBatchId);
        props.setProperty("sampleid", dsFiltered.getColumnValues("sampleid", ";"));
        props.setProperty(DeleteSDIDetail.PROPERTY_LINKID, "u_ngbatch_sample_link");
        try {
            getActionProcessor().processAction(DeleteSDIDetail.ID, DeleteSDIDetail.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from NG_Batch_Sample");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
        try {
            props.clear();
            props.setProperty(DeleteSDI.PROPERTY_SDCID, "LV_ReagentLot");
            props.setProperty(DeleteSDI.PROPERTY_KEYID1, dsFiltered.getColumnValues("sampleid", ";"));
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't delete record from LV_ReagentLot SDC");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);

        }
    }

    /**
     * This method is use to clear all contents from storage .
     *
     * @throws SapphireException
     */
    private void clearStorage() throws SapphireException {
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String userDepartment = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String sql = "select trackitemid,currentstorageunitid,custodialdepartmentid from TRACKITEM where linkkeyid1 in ('" + dsNGBatchInfo.getColumnValues("sampleid", "','") + "') ";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String trackitemid = ds.getColumnValues("trackitemid", ";");
        PropertyList props = new PropertyList();


        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("currentstorageunitid", "");
            props.setProperty("custodialdepartmentid", userDepartment);
            props.setProperty("custodialuserid", currentUser);
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }
    }

    /**
     * This method is use to get content and validate the box.
     *
     * @throws SapphireException
     */
    private void validateBatchNGetContent() throws SapphireException {
        String sql = "select b.batchname,bs.sampleid,bp.plateid from u_ngbatch b, u_ngbatch_sample bs,u_ngbatch_plate bp where b.u_ngbatchid=bs.u_ngbatchid and b.u_ngbatchid=bp.u_ngbatchid " +
                "and b.u_ngbatchid='" + ngBatchId + "'";
        dsNGBatchInfo = qp.getSqlDataSet(sql);
        if (dsNGBatchInfo == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (dsNGBatchInfo.size() == 0) {
            String err = "BatchId : " + ngBatchId + " not exists in LV system.";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        batchName = dsNGBatchInfo.getValue(0, "batchname");
        boxId = Util.getUniqueList(dsNGBatchInfo.getColumnValues("plateid", ";"), ";", true);
        String[] boxarr = boxId.split(";");
        if (boxarr.length > 1)
            throw new SapphireException("Samples are present in multiple boxes.");

    }

    /**
     * This function is use to get the top most
     * position of box.
     *
     * @param boxPosToLd
     * @param elTubeArr
     * @return
     */
    private String getMaxBoxPos(String boxPosToLd, String[] elTubeArr) {
        String[] posarr = boxPosToLd.split(";");
        int length = posarr.length;
        String maxpos = "";
        if (length > 0) {
            for (int i = 0; i < elTubeArr.length; i++) {
                if (posarr[i].compareToIgnoreCase(maxpos) > 0)
                    maxpos = posarr[i];
            }
        }
        return maxpos;
    }

    /**
     * This function is use to create control sample.
     *
     * @param batchName
     * @param temStgLblId
     * @return
     * @throws SapphireException
     */
    private String crateControlSample(String batchName, String temStgLblId) throws SapphireException {
      /*  PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "Sample");
        // props.setProperty("sampletypeid", "QC");
        props.setProperty("sampletypeid", "NSC");//todo
        props.setProperty("storagestatus", "In Circulation");
        props.setProperty("u_extractionid", batchName + "_" + temStgLblId);
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        String newkeyid = props.getProperty("newkeyid1");
        return newkeyid;*/

        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "LV_ReagentLot");
        props.setProperty(AddSDI.PROPERTY_OVERRIDEAUTOKEY, "Y");//todo
        props.setProperty(AddSDI.PROPERTY_KEYID1, batchName + "_" + temStgLblId);
        props.setProperty("reagenttypeid", "NSC");//todo
        props.setProperty("reagenttypeversionid", "1");//todo
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        String newkeyid = props.getProperty("newkeyid1");
        return newkeyid;
    }

    /**
     * This function is use to get the
     * loading pattern for manual,plasma and tna type of
     * extraction .
     *
     * @param extractiontype
     * @return
     * @throws SapphireException
     */
    private String getBoxPosToLdManual(String extractiontype) throws SapphireException {
        String boxPosToLd = "";
        if (extractiontype.equalsIgnoreCase("Manual"))
            boxPosToLd = "1;16;2;17;3;18;4;19;5;20;6;21;7;22;8;23;9;24;10;25;11;26;12;27;13;28;14;29;15;30";
        if (extractiontype.equalsIgnoreCase("TNA") || extractiontype.equalsIgnoreCase("Plasma"))
            boxPosToLd = "1;16;2;17;3;18;4;19;5;20;6;21;7;22;8;23;9;24;10;25;11;26;12;27;13;28;14;29;15;30";

        //boxPosToLd = "1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;18;19;20;21;22;23;24";

        return boxPosToLd;
    }
}