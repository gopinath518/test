package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 7/6/2016.
 * @desc This action creates the additional ellusion tube on demand
 * and assigns the currentuser  to the custodian whenever new ellusion tubes
 * are created .This action also  assigns all the tests to the newly created ellusion tube
 * which are applied on the sample from which ellusion has been created.
 *
 */
public class AdditionalEllusionTube extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleid");
        if(sampleids==null){
            throw new SapphireException("No Sample is selected");
        }
        if(sampleids.equalsIgnoreCase("")){
            throw new SapphireException("No Sample is selected");
        }
        String newsampleids = StringUtil.replaceAll(sampleids, ";", "','");
        String currentuser = connectionInfo.getSysuserId();
        String custodialdepartmentid = connectionInfo.getDefaultDepartment();

        String ellusiontube = createDilutionTube(newsampleids);
        if(ellusiontube==null){
            throw new SapphireException("Ellusion Tube is not created");
        }
        if(ellusiontube.equalsIgnoreCase("")){
            throw new SapphireException("Ellusion Tube is not created");
        }
        updateTrackitem(ellusiontube,currentuser,custodialdepartmentid);
        addTestCodeOnAliquot(newsampleids,ellusiontube);

    }

    /**
     * @desc: Create Additional dilution tube from ellusion tube.
     * @param newsampleids -parent sample id
     * @return: newly created ellusion id
     * @throws SapphireException
     */
    private String createDilutionTube(String newsampleids) throws SapphireException {
        PropertyList prop = new PropertyList();
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, newsampleids);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_markminimal;u_sampleinformation;u_accessionid;u_currentmovementstep");

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot create Ellusion Tube.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

    /**
     * @desc : Assigns currentuser to a custodian whenever additional ellusion tube is created.
     * @param ellusiontube :ellusion tube id
     * @param currentuser:currentuser who logged in
     * @param custodialdepartmentid:Department of the currentuser
     * @throws SapphireException
     */
    private void updateTrackitem(String ellusiontube, String currentuser, String custodialdepartmentid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, ellusiontube);
        props.setProperty("containertypeid", "Ellution Tube");
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", custodialdepartmentid);
        props.setProperty("custodytakendt", "n");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for sample.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }

    /**
     * @desc: Applies all the test on the ellusion tube which are applied on the sample
     * from which the ellusion has been created
     * @param newsampleids:sample id from which new ellusion tube has been created
     * @param ellusiontube:ellusion tube id
     * @throws SapphireException
     */
    private void addTestCodeOnAliquot(String newsampleids, String ellusiontube) throws SapphireException {
        String ss_parentTest = "select distinct lvtestcodeid,ispanel from u_sampletestcodemap" +
                " where s_sampleid in('" + newsampleids + "')";
        DataSet dsParentTest = getQueryProcessor().getSqlDataSet(ss_parentTest);
        String[] samparr = StringUtil.split(ellusiontube, ";");
        if (dsParentTest == null) {
            String error = getTranslationProcessor().translate("Query failed");
            error += ss_parentTest;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsParentTest.size() == 0) {
            String e = getTranslationProcessor().translate("No Test is assigned to the Parent");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, e);
        }
        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

        for (String currentsamp : samparr) {
            for (int j = 0; j < dsParentTest.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dsParentTest.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dsParentTest.getValue(j, "ispanel", ""));

            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
       // hsAddTestCode.setProperty("bypassvalidation", "Y");//Closed by debasis
        hsAddTestCode.setProperty("bypass", "Y");//added by debasis
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Test is not assigned on the ellution tube.Error: "+e.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }
}
