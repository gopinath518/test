package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;

import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;



/**
 * Created by kshahbaz on 5/13/2016.
 * @desc : This action is used to store heme samples into box
 * Mandatory Input:
 * @param1 : sampleid
 * @param2 : boxid
 * @throws SapphireException
 */
public class PutIntoHeme extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException{
        String sampleid = properties.getProperty("sampleid");

        String boxid = properties.getProperty("boxid");
        String sampid = StringUtil.replaceAll(sampleid, ";", "','");
        String tarckitem_sql="select  trackitemid from trackitem where linksdcid='Sample' and linkkeyid1 in ('"+sampid+"')";
        String box_sql="select storageunitid from storageunit where linksdcid='LV_Box' and linkkeyid1='"+boxid+"'";
        DataSet trackitem_ds=getQueryProcessor().getSqlDataSet(tarckitem_sql);
        if (trackitem_ds == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happen. Contact your Administrator.");
            errmsg += " Query failed:\n" + tarckitem_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (trackitem_ds.getRowCount() == 0) {
            String errmsg = getTranslationProcessor().translate("No Trackitem Id found for the selected samples.") + sampleid;
            errmsg += " Query failed:\n" + tarckitem_sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errmsg);
        }

        String trackitemid=trackitem_ds.getColumnValues("trackitemid",";");
        DataSet box_ds=getQueryProcessor().getSqlDataSet(box_sql);
        if (box_ds == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happen. Contact your Administrator.");
            errmsg += " Query failed:\n" + box_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (box_ds.getRowCount() == 0) {
            String errmsg = getTranslationProcessor().translate("No Storage Id found for the selected samples.") + sampleid;
            errmsg += " Query failed:\n" + box_sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errmsg);
        }
        String storageid=box_ds.getValue(0,"storageunitid");
        updateStorageUnit(trackitemid, storageid);
           }

    /**
     * @desc : This method updated trackitem and storage unit for heme samples which are stored into the boxes
     * @param trackitemid
     * @param storageunitid
     * @throws SapphireException
     */
    private void updateStorageUnit(String trackitemid, String storageunitid) throws SapphireException {
        PropertyList props = new PropertyList();
        try {
            props.setProperty(EditSDI.PROPERTY_SDCID, "TrackItemSDC");
            props.setProperty(EditSDI.PROPERTY_KEYID1, trackitemid);
            props.setProperty("currentstorageunitid", storageunitid);
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
        } catch (SapphireException ae) {
            String error = getTranslationProcessor().translate("Can't update track item SDC");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);

        }

    }
}
