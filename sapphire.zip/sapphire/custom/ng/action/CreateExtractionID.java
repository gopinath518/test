package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.accessor.ActionProcessor;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.accessor.ActionException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyListCollection;

import java.util.Calendar;

/**
 * Created by mpandey on 6/6/2016.
 * purpose- Create Extractionid on the basis of sampletype and extractiontype
 * mandatory input - sampleid,extractionid
 * addtional input - Suffix
 */
public class CreateExtractionID extends BaseAction {

    String CURRENT_YEAR = "";
    String LATESTSEQ = "";
    String neoflag = "";

    private static final String HOMOGENEOUSLOSPOLICYID = "ExtractionPrefixPolicy";
    private static final String NODEID = "MolecularExtraction";
    private static final String POLICY_MAPPING = "extractiontypelist";
    private static final String POLICY_CHILD_EXTRACTION_TYPE = "extractiontype";
    private static final String POLICY_CHILD_EXTRACTION_PREFIX = "extractionprefix";
    PropertyList extractionprefixpolicy = null;

    public void processAction(PropertyList properties) throws SapphireException {
        CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        LATESTSEQ = "0000001";
        String sampleid = properties.getProperty("sampleid");
        String extractiontype = properties.getProperty("extractiontype");
        String suffix = properties.getProperty("suffix");

        if (extractiontype.length() == 0) {
            String error = getTranslationProcessor().translate("Sample doesn't have any Extraction Type");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
        getExtractionPrefix();
        neoflag = checkForNeoFlag(sampleid);
        getLatestSeq(sampleid, extractiontype);
        String extractionid = generateExtractionID(sampleid, extractiontype, suffix);
        properties.put("extractionid", extractionid);

        //throw new SapphireException("test");

    }

    private String checkForNeoFlag(String sampleid) throws SapphireException {
        String sql = Util.parseMessage(MolecularSql.EXTRAC_NEO_FLG, sampleid);
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String errmsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errmsg += "\nQuery failed:\n" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }
        if (ds.size() > 0) {
            //int ntprownum = ds.findRow("ispanel", "Y");
            int ntpnrownum = ds.findRow("ispanel", "N");
            int nlrownum = ds.findRow("isneolab", "Y");
            String lvtestpanelid = ds.getValue(0, "lvtestpanelid", "");
            if (ntpnrownum >= 0 && "N".equalsIgnoreCase(lvtestpanelid)) {
                String isNGS = ds.getValue(ntpnrownum, "molecularworkflow", "");
                if (isNGS.length() > 0)
                    return "NT";
            }
            if (ntpnrownum >= 0 && !"N".equalsIgnoreCase(lvtestpanelid)) {
                sql = Util.parseMessage(MolecularSql.EXTRAC_NEO_NOT_NORMAL, sampleid);
                DataSet dsPanel = getQueryProcessor().getSqlDataSet(sql);
                int ntprownum = dsPanel.findRow("ispanel", "Y");
                String isneolab = dsPanel.getValue(ntprownum, "isneolab", "");
                String isNGS = dsPanel.getValue(ntprownum, "molecularsubmethodology", "");
                if (isNGS.length() > 0 && !"Y".equalsIgnoreCase(isneolab))
                    return "NTP";
                /*ISPANEL="Y" & ISNEOLAB="Y" (SURAJIT 06-05-17) START*/
                if (isNGS.length() > 0 && "Y".equalsIgnoreCase(isneolab))
                    return "NLP";
                /*ISPANEL="Y" & ISNEOLAB="Y" (SURAJIT 06-05-17) END*/
            }
            /*if (ntprownum >= 0) {
                String isNGS = ds.getValue(ntprownum, "molecularworkflow", "");
                if (isNGS.length() > 0)
                    return "NTP";
            }*/
            if (nlrownum >= 0) {
                String isHEME = ds.getValue(nlrownum, "sampletypeid", "");
                if (!isHEME.equalsIgnoreCase("Tissue")) ;
                return "NL";

            }

        }
        return "";

    }

    /**
     * This method is use to generate unique Extraction id for sample.
     *
     * @param sampleid
     * @param extractiontype
     * @param suffix
     * @throws SapphireException
     */

    private String generateExtractionID(String sampleid, String extractiontype, String suffix) throws SapphireException {

        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();

        String newExtractionID = "";
        if (sampleid.length() > 0) {
            /*char head = extractiontype.charAt(0);
            String YY = CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length());
            int seq = Integer.parseInt(LATESTSEQ);
            newExtractionID = head + YY + "-" + String.format("%06d", seq);*/
            if (extractionprefixpolicy != null) {
                String head = extractionprefixpolicy.getProperty(extractiontype);
                String YY = CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length());
                int seq = Integer.parseInt(LATESTSEQ);
                newExtractionID = head + YY + "-" + String.format("%06d", seq);
            }
        }
        if (suffix.length() > 0)
            newExtractionID = newExtractionID + "-" + suffix;

        if (neoflag.length() > 0)
            newExtractionID = neoflag + newExtractionID;

        editProp.setProperty("sdcid", "Sample");
        editProp.setProperty("keyid1", sampleid);
        editProp.setProperty("u_extractionid", newExtractionID);

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
        return newExtractionID;
    }

    /**
     * This method is use to get the latest sequence of extraction id .
     *
     * @param sampleid
     * @param extractiontype
     */
    private void getLatestSeq(String sampleid, String extractiontype) {
        //String extractionMatch = extractiontype.charAt(0) + CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length());
        String extractionMatch = "";
        if (extractionprefixpolicy != null) {
            String extractionprefix = extractionprefixpolicy.getProperty(extractiontype);
            extractionMatch = extractionprefix + CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length());
        }
        if (neoflag.length() > 0)
            extractionMatch = neoflag + extractionMatch;
        String sql_sample = "select max(u_extractionid)u_extractionid from s_sample where  u_extractionid like '" + extractionMatch + "-%' ";
        DataSet dsAccess = getQueryProcessor().getSqlDataSet(sql_sample);
        if (dsAccess.size() > 0 && dsAccess.getString(0, "u_extractionid", "").length() > 0) {
            LATESTSEQ = dsAccess.getString(0, "u_extractionid").split("-")[1];
            int seq = Integer.parseInt(LATESTSEQ) + 1;
            LATESTSEQ = String.valueOf(seq);
        }
    }

    private void getExtractionPrefix() throws SapphireException {
        if (extractionprefixpolicy == null) {
            extractionprefixpolicy = new PropertyList();
            PropertyList plExtractionPolicy = getConfigurationProcessor().getPolicy(HOMOGENEOUSLOSPOLICYID, NODEID);
            if (plExtractionPolicy == null)
                throw new SapphireException("Extraction Type Prefix policy is not define in System Admin-> Policy.");
            PropertyListCollection plclosmap = plExtractionPolicy.getCollection(POLICY_MAPPING);
            if (plclosmap != null) {
                for (int i = 0; i < plclosmap.size(); i++) {
                    String propExtractionType = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_EXTRACTION_TYPE);
                    String propExtractionPrefix = plclosmap.getPropertyList(i).getProperty(POLICY_CHILD_EXTRACTION_PREFIX);

                    extractionprefixpolicy.setProperty(propExtractionType, propExtractionPrefix);
                }
            }
        }
    }
}



