package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sms.CreateSamplePool;
import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**Action Name- CreatePoolSample
 * Description: This Action is use create pool sample.
 *
 * Mandatory inputs
 * param1-sampleid
 * Created by mpandey on 6/6/2016.
 */
public class CreatePoolSample extends BaseAction {
    String EXTRACTIONTYPE = "";
    String SUFFIX = "";

    public void processAction(PropertyList properties) throws SapphireException {
        String parentsampleid = properties.getProperty("keyid1");
        String exttype = properties.getProperty("changeextractiontype", "");

       // isparent(parentsampleid);
        String newsampleid ="";

        newsampleid=hemeextractiontube(properties) ;


        properties.put("newkeyid1", newsampleid);
    }

    /** This method is use to create extraction for non tissue type sample.
     *
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String hemeextractiontube(PropertyList properties)throws SapphireException {
        String newkey = "";
        String parentsampleid = properties.getProperty("keyid1");
        String exttype = properties.getProperty("changeextractiontype", "");
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql =  "SELECT  distinct sm.extractiontype" +
                " FROM U_SAMPLETESTCODEMAP sm " +
                " WHERE  sm.s_sampleid  IN ('"+qrsample+"') and sm.extractiontype is not null";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sql);
        if (dsSamp.size()>1) {
            for (int i = 0; i < dsSamp.size(); i++){
               String newsampleid = createPoolSample(properties);
            editSampleSDI(newsampleid, parentsampleid,SUFFIX );
            createExtractionID(newsampleid, dsSamp.getValue(i,"extractiontype") , SUFFIX);
            addHEMETestCode(newsampleid, parentsampleid,dsSamp.getValue(i,"extractiontype"));
            isSacraped(parentsampleid);
            updateExtractionType(newsampleid, dsSamp.getValue(i,"extractiontype"));
                newkey=newkey+";"+newsampleid;
        }

        }else{
            newkey  = tissueextractiontube(properties);
        }
        if(newkey.startsWith(";"))
            newkey=newkey.substring(1);
        return newkey;
    }

    /**
     * This method is use to dd testcode in extraction tube where sampletype
     * is non tissue.
     * @param newsampleid
     * @param parentsampleid
     * @param extractiontype
     * @throws SapphireException
     */
    private void addHEMETestCode(String newsampleid, String parentsampleid, String extractiontype)throws SapphireException {

            String psample = StringUtil.replaceAll(parentsampleid, ";", "','");

            String tc_sql = "select distinct lvtestcodeid,ispanel from u_sampletestcodemap where extractiontype='"+extractiontype+"' and lvtestpanelid is null and ispanel is null and s_sampleid in('" + psample + "')";
            DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
            String tp_sql = "select distinct lvtestpanelid,ispanel from u_sampletestcodemap where extractiontype='"+extractiontype+"' and lvtestpanelid is not null and s_sampleid in('" + psample + "')";
            DataSet dstespanel = getQueryProcessor().getSqlDataSet(tp_sql);
            String[] samparr = StringUtil.split(newsampleid, ";");

            if (dstestcode.size() == 0 && dstespanel.size() == 0) {
                String error = getTranslationProcessor().translate("SampleID " + psample + " doesn't have any Test !");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
            }

            DataSet dsSamplefinal = new DataSet();
            dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
            dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
            dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

            for (String currentsamp : samparr) {
                for (int j = 0; j < dstestcode.getRowCount(); j++) {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                    dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                    dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));

                }
            }

            for (String currentsamp : samparr) {
                for (int j = 0; j < dstespanel.getRowCount(); j++) {
                    int rowID = dsSamplefinal.addRow();
                    dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                    dsSamplefinal.setValue(rowID, "lvtestcode", dstespanel.getValue(j, "lvtestpanelid"));
                    dsSamplefinal.setValue(rowID, "ispanel", dstespanel.getValue(j, "ispanel", ""));

                }
            }
            PropertyList hsAddTestCode = new PropertyList();
            hsAddTestCode.clear();
            hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
            hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
            hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
            try {
                getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
            } catch (ActionException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
    }

    /**
     * This method is use to create extraction tube where sample type is tissue.
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String tissueextractiontube(PropertyList properties) throws SapphireException {
        String newkey = "";
        String parentsampleid = properties.getProperty("keyid1");
        String exttype = properties.getProperty("changeextractiontype", "");
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "select distinct u_sampleinformation from s_sample where s_sampleid in ('" + qrsample + "')";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sql);
        if (dsSamp.getValue(0, "u_sampleinformation").equalsIgnoreCase("Tumor/Normal"))
        {
           String newsampleid = createPoolSample(properties);
            editSampleSDI(newsampleid, parentsampleid,"Tumor");
            if (exttype.length() > 0)
                if (!exttype.equalsIgnoreCase("manual"))
                    EXTRACTIONTYPE = exttype;
            createExtractionID(newsampleid, EXTRACTIONTYPE, "Tumor");
            addTestCode(newsampleid, parentsampleid);
            isSacraped(parentsampleid);
            updateExtractionType(newsampleid, EXTRACTIONTYPE);
            newkey=newsampleid;

            String newsampleid2 = createPoolSample(properties);
            editSampleSDI(newsampleid2, parentsampleid, "Normal");
            if (exttype.length() > 0)
                if (!exttype.equalsIgnoreCase("manual"))
                    EXTRACTIONTYPE = exttype;
            String s_sql = "select u_extractionid  from s_sample where s_sampleid = '"+newsampleid+"'";
            DataSet extract = getQueryProcessor().getSqlDataSet(s_sql);

            NormalExtractionID(newsampleid2, extract.getValue(0,"u_extractionid",""), "Normal");
            addNormalTestCode(newsampleid2);
            isSacraped(parentsampleid);
            updateExtractionType(newsampleid2, EXTRACTIONTYPE);
            newkey=newkey+";"+newsampleid2;

        }
        else{

            //isparent(parentsampleid);
            String newsampleid = createPoolSample(properties);
            editSampleSDI(newsampleid, parentsampleid,SUFFIX);
            if (exttype.length() > 0)
                if (!exttype.equalsIgnoreCase("manual"))
                    EXTRACTIONTYPE = exttype;
            createExtractionID(newsampleid, EXTRACTIONTYPE,SUFFIX);
            addTestCode(newsampleid, parentsampleid);
            isSacraped(parentsampleid);
            updateExtractionType(newsampleid, EXTRACTIONTYPE);
            newkey=newsampleid;
        }
        return newkey;
    }

    /**
     * This method is use to extraction id for  sample where sample information is normal.
     * @param newsampleid
     * @param u_extractionid
     * @param normal
     * @throws SapphireException
     */
    private void NormalExtractionID(String newsampleid, String u_extractionid, String normal)throws SapphireException {
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();

        String []newExtractionID = u_extractionid.split("-");
        editProp.setProperty("sdcid", "Sample");
        editProp.setProperty("keyid1", newsampleid);
        editProp.setProperty("u_extractionid", newExtractionID[0]+"-"+newExtractionID[1]+"-"+"N");

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This method is use to add testcode in sample where sample information is normal.
     * @param newsampleid
     * @throws SapphireException
     */
    private void addNormalTestCode(String newsampleid) throws SapphireException{
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", newsampleid);
        hsAddTestCode.setProperty("lvtestcode", "4047x");
        hsAddTestCode.setProperty("ispanel", "N");
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * This method is use to update information in sample sdc.
     * @param newsampleid
     * @param parentsampleid
     * @param sampleinfo
     * @throws SapphireException
     */
    private void editSampleSDI(String newsampleid, String parentsampleid, String sampleinfo) throws SapphireException {
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "select DISTINCT u_accessionid,u_sampleinformation,u_clientspecimenid,u_currentmovementstep  from s_sample where s_sampleid " +
                " in('" + qrsample + "')";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sql);

        if (dsSamp.size() == 0) {
            String error = getTranslationProcessor().translate("Sample must belongs to same accesion ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, newsampleid);
        editProp.setProperty("u_accessionid", dsSamp.getValue(0, "u_accessionid", ""));
        editProp.setProperty("u_sampleinformation", sampleinfo);
        editProp.setProperty("u_clientspecimenid", dsSamp.getValue(0, "u_clientspecimenid", ""));
        editProp.setProperty("u_currentmovementstep", dsSamp.getValue(0, "u_currentmovementstep", ""));

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This method is use to update extraction type for a sample.
     *
     * @param sampleid
     * @param extractiontype
     * @throws SapphireException
     */
    private void updateExtractionType(String sampleid, String extractiontype) throws SapphireException {
        String sample_sql = "select u_sampletestcodemapid from u_sampletestcodemap where s_sampleid='" + sampleid + "'";
        DataSet dsSamp = getQueryProcessor().getSqlDataSet(sample_sql);

        if (dsSamp == null) {
            String error = getTranslationProcessor().translate("Query Failed");
            error += sample_sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();
        editProp.setProperty(EditSDI.PROPERTY_SDCID, "SampleTestCodeMap");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, dsSamp.getColumnValues("u_sampletestcodemapid", ";"));
       // editProp.setProperty("extractiontype", StringUtil.repeat(extractiontype, dsSamp.getRowCount()));
        editProp.setProperty("extractiontype", extractiontype);
       // editProp.setProperty("propsmatch", "Y");

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This method is use to add test code in a sample.
     * @param newsampleid
     * @param parentsampleid
     * @throws SapphireException
     */
    private void addTestCode(String newsampleid, String parentsampleid) throws SapphireException {

        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");

        String tc_sql = "select distinct lvtestcodeid,ispanel from u_sampletestcodemap where lvtestpanelid is null and ispanel is null and s_sampleid in('" + psample + "')";
        DataSet dstestcode = getQueryProcessor().getSqlDataSet(tc_sql);
        String tp_sql = "select distinct lvtestpanelid,ispanel from u_sampletestcodemap where lvtestpanelid is not null and s_sampleid in('" + psample + "')";
        DataSet dstespanel = getQueryProcessor().getSqlDataSet(tp_sql);
        String[] samparr = StringUtil.split(newsampleid, ";");

        if (dstestcode.size() == 0 && dstespanel.size() == 0) {
            String error = getTranslationProcessor().translate("SampleID " + psample + " doesn't have any Test !");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }

        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

        for (String currentsamp : samparr) {
            for (int j = 0; j < dstestcode.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstestcode.getValue(j, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstestcode.getValue(j, "ispanel", ""));

            }
        }

        for (String currentsamp : samparr) {
            for (int j = 0; j < dstespanel.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", currentsamp);
                dsSamplefinal.setValue(rowID, "lvtestcode", dstespanel.getValue(j, "lvtestpanelid"));
                dsSamplefinal.setValue(rowID, "ispanel", dstespanel.getValue(j, "ispanel", ""));

            }
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * This method is use to flag out parent sample.
     * @param parentsampleid
     * @throws SapphireException
     */
    private void isparent(String parentsampleid) throws SapphireException {

        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String s_sql = "SELECT   s.s_sampleid,a.SOURCESAMPLEID" +
                "  FROM labvantage.s_samplemap a," +
                "    labvantage.s_sample s" +
                "  WHERE s.s_sampleid IN ('" + psample + "')" +
                "  AND s.s_sampleid=a.destsampleid (+)" +
                "  AND s.POOLEDFLAG   IS NULL";
        DataSet dsChild = getQueryProcessor().getSqlDataSet(s_sql);
        if (dsChild.size() == 0 || dsChild == null) {
            String error = getTranslationProcessor().translate("Please select some Sample");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        for (int i = 0; i < dsChild.size(); i++) {
            if (dsChild.getValue(i, "SOURCESAMPLEID", "").length() == 0) {
                String error = getTranslationProcessor().translate("Samples: " + dsChild.getValue(i, "s_sampleid", "") + " is a Parent Sample");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }

        }
        String uniqueParent = Util.getUniqueList(dsChild.getColumnValues("SOURCESAMPLEID", ";"), ";", true);
        if (uniqueParent.split(";").length > 1) {
            String error = getTranslationProcessor().translate("Samples must belongs to same Parent");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * This method is use to mark scrapped sample.
     * @param parentsampleid
     * @throws SapphireException
     */
    private void isSacraped(String parentsampleid) throws SapphireException {
        PropertyList propEditSDI = new PropertyList();
        propEditSDI.setProperty("sdcid", "Sample");
        propEditSDI.setProperty("keyid1", parentsampleid);
        propEditSDI.setProperty("u_isscrap", "Y");


        try {
            getActionProcessor().processAction("EditSDI", "1", propEditSDI);
        } catch (ActionException e) {
            String error = getTranslationProcessor().translate("Please select atleast a sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
    }

    /**
     * This method is use to create extraction id for a sample.
     * @param newsampleid
     * @param EXTRACTIONTYPE
     * @param SUFFIX
     * @throws SapphireException
     */
    private void createExtractionID(String newsampleid, String EXTRACTIONTYPE, String SUFFIX) throws SapphireException {
        PropertyList hsCreateExtractionID = new PropertyList();
        hsCreateExtractionID.clear();
        hsCreateExtractionID.setProperty("sampleid", newsampleid);
        hsCreateExtractionID.setProperty("EXTRACTIONTYPE", EXTRACTIONTYPE);
        hsCreateExtractionID.setProperty("SUFFIX", SUFFIX);

        try {
            getActionProcessor().processAction("CreateExtractionID", "1", hsCreateExtractionID);
        } catch (ActionException e) {
            String errMSG = getTranslationProcessor().translate("Action failed CreateExtractionID ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }
    }

    /**
     * This method is use to create pool sample.
     * @param properties
     * @return
     * @throws SapphireException
     */
    private String createPoolSample(PropertyList properties) throws SapphireException {
        //String poolcopies = properties.getProperty("poolcopies", "1");
        String parentsampleid = properties.getProperty("keyid1");
        String psample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String s_sql = "SELECT DISTINCT tc.extractiontype" +
                " FROM U_SAMPLETESTCODEMAP sm," +
                "  u_testcode tc" +
                " WHERE sm.lvtestcodeid=tc.u_testcodeid" +
                " AND s_sampleid   in " +
                " ('" + psample + "')" +
                "   and  tc.extractiontype is not null";
        DataSet dsextrac = getQueryProcessor().getSqlDataSet(s_sql);
        if (dsextrac.size() == 0 || dsextrac.getValue(0, "extractiontype", "").length() == 0) {
            String error = getTranslationProcessor().translate("Extraction type is not defined for Samples");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
     /*   if (dsextrac.size() > 1) {
            String error = getTranslationProcessor().translate("Samples must have same Extraction type");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }*/
        EXTRACTIONTYPE = dsextrac.getValue(0, "extractiontype");
        //String sampletype = properties.getProperty("sampletype");
        String qrsample = StringUtil.replaceAll(parentsampleid, ";", "','");
        String sql = "SELECT distinct t.qtycurrent,t.containertypeid,t.custodialdepartmentid," +
                "  t.qtyunits,s.u_sampleinformation" +
                " FROM trackitem t," +
                "  s_sample s" +
                " WHERE t.linksdcid = 'Sample'" +
                " AND t.linkkeyid1  = s.s_sampleid" +
                " AND s.s_sampleid " +
                " in('" + qrsample + "')";
        DataSet dstrack = getQueryProcessor().getSqlDataSet(sql);

        if (dstrack.size() == 0) {
            String error = getTranslationProcessor().translate("Trackitem is not defined for sample ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        SUFFIX = dstrack.getValue(0, "u_sampleinformation", "");
        PropertyList props = new PropertyList();
        String newkeyid1;
        props.setProperty("sampleid", parentsampleid);
        props.setProperty("quantity", "10");
        props.setProperty("poolquantity", "10");
        props.setProperty("poolcontainertypeid", dstrack.getValue(0, "containertypeid"));
        props.setProperty("poolcustodialdepartmentid", dstrack.getValue(0, "custodialdepartmentid")); //todo
        //   props.setProperty("sstudyid", "NeoClinical"); ///TODO Hadcoded need to remove later
        //   props.setProperty("u_currentmovementstep", currentmovementstep);
        //  props.setProperty("u_accessionid", accessionid);
        //  props.setProperty("copydowncolumns", "sstudyid;u_currentmovementstep;u_accessionid;sampletypeid");

        try {
            getActionProcessor().processAction(CreateSamplePool.ID, CreateSamplePool.VERSION, props);

        } catch (Exception e) {
            throw new SapphireException("Unable to create pool sample  ");

        }
        newkeyid1 = props.getProperty("newkeyid1", "");
        //Start-------------------setRootForPoolSample() method is added for updating root sample of child which is created from pool samples -------------------
        Util.setRootForPoolSample(newkeyid1, parentsampleid,getTranslationProcessor(), getActionProcessor());
        //End----------------------------------------------------------------------------------------------------------------------------------------------------

        return newkeyid1;
    }
}
