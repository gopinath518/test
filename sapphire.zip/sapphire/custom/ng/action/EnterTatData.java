/**
 * Created By Subhendu 27/11/2018 
 * */

package sapphire.custom.ng.action;

import java.util.Calendar;
import java.util.Date;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.TatCalculation;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class EnterTatData extends BaseAction {
	
	public static String SDCID = "SDITatData";
	public static String ID = "EnterTatData";
	public static String VERSIONID = "1";
	
	@Override
	public void processAction(PropertyList properties) throws SapphireException {
		
		
		String mode = properties.getProperty("mode", "");
		DataSet tatDS = new DataSet(properties.getProperty("tatDS",""));
		if("UPDATE".equalsIgnoreCase(mode))
			updateTATData(tatDS);
		
		insertTATData(tatDS);
		
	}
	
	private void updateTATData(DataSet tatDS) throws SapphireException{
		String sql = Util.parseMessage(CommonSql.GET_TAT_DATA_BY_ACC,  Util.getUniqueValueInDataSetByColumn(tatDS, "sampleid").getColumnValues("sampleid", "','"),
					 tatDS.getValue(0, "methodology"), tatDS.getColumnValues("panelcode", "','"),tatDS.getColumnValues("testcode", "','")); 
		DataSet ds = getQueryProcessor().getSqlDataSet(sql);
		
		if(ds != null && ds.size()>0){
			Calendar dd = ds.getCalendar(0, "starttime");
			PropertyList pl = new PropertyList();
			pl.setProperty(EditSDI.PROPERTY_SDCID, SDCID);
			pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("u_sditatdataid", ";"));
			pl.setProperty("endtime", StringUtil.repeat("n", ds.size(), ";"));
			
			getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
		}
	}
	
	private void insertTATData(DataSet tatDS) throws SapphireException{
		
		String department = connectionInfo.getDefaultDepartment();

        tatDS.addColumn("department",DataSet.STRING);
        tatDS.addColumn("site",DataSet.STRING);

		String inputSite="";
		String inputDept="";
        
        for(int i=0;i<tatDS.size();i++){
        	String tempDept=tatDS.getValue(i,"custodialdepartmentid","");
        	if(Util.isNull(tempDept)){
				if(!Util.isNull(department) && department.contains("-")){
					inputSite = StringUtil.split(department, "-")[0];
					inputDept = StringUtil.split(department, "-")[1];
				}
			}
			else{
        		if(tempDept.contains("-")) {
					inputSite = StringUtil.split(tempDept, "-")[0];
					inputDept = StringUtil.split(tempDept, "-")[1];
				}
			}
			tatDS.setValue(i,"department",inputDept);
			tatDS.setValue(i,"site",inputSite);
		}
		
		PropertyList pl = new PropertyList();
		pl.setProperty(AddSDI.PROPERTY_SDCID, SDCID);
		pl.setProperty(AddSDI.PROPERTY_COPIES, tatDS.size()+"");
		
		pl.setProperty("accessionid", tatDS.getColumnValues("accessionid", ";"));
		pl.setProperty("sampleid", tatDS.getColumnValues("sampleid", ";"));
		pl.setProperty("sampletestcodemapid", tatDS.getColumnValues("sampletestcodemapid", ";"));
		pl.setProperty("rootsampleid", tatDS.getColumnValues("rootsampleid", ";"));
		pl.setProperty("parentsampleid", tatDS.getColumnValues("parentsampleid", ";"));
		pl.setProperty("tramstop", tatDS.getColumnValues("tramstop", ";"));
		pl.setProperty("starttime", StringUtil.repeat("n", tatDS.size(), ";"));
		pl.setProperty("methodology", tatDS.getColumnValues("methodology", ";"));
		pl.setProperty("tattimeinhours", tatDS.getColumnValues("tattimeinhours", ";"));
		pl.setProperty("tattimeindays", tatDS.getColumnValues("tattimeindays", ";"));
		pl.setProperty("testcode", tatDS.getColumnValues("testcode", ";"));
		pl.setProperty("panelcode", tatDS.getColumnValues("panelcode", ";"));
		pl.setProperty("department", tatDS.getColumnValues("department", ";"));
		pl.setProperty("site", tatDS.getColumnValues("site", ";"));
		
		getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);
	}
}
