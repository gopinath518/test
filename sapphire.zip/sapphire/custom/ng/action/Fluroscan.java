package sapphire.custom.ng.action;


import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.ExcelParsing;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * Created by ssen on 10/12/2016.
 */
public class Fluroscan extends BaseAction {
    /**
     * This action is used for FulroScan File parse.
     *
     * @param properties
     * @throws sapphire.SapphireException
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String file = properties.getProperty("path", "");
        String columnname = properties.getProperty("columnid", "");
        String batchid = properties.getProperty("batchid", "");
        String sampleIdSQL="";
        DataSet dsfinal = new DataSet();
        dsfinal.addColumn("sample", DataSet.STRING);
        dsfinal.addColumn("concentration", DataSet.STRING);
        if (Util.isNull(file))
            throw new SapphireException("file is not found. Please upload a valid file.");
        if (file.length() <= 0)
            // if (file.indexOf(".xlsx") <= 0)
            throw new SapphireException("Invalid file format obtained. Please upload a excel file format.");
        else {
            DataSet ds = ExcelParsing.fluroScanExcelFileParse(file);
            if (ds != null && ds.size() > 0) {

                if(Util.isNull(batchid)){
                    sampleIdSQL = "SELECT s.s_sampleid as sampleid ,s.u_extractionid as extractionid " +
                            "FROM s_sample s,trackitem t " +
                            "WHERE s.s_sampleid= t.linkkeyid1 " +
                            "AND s.U_EXTRACTIONID in ('" + StringUtil.replaceAll(ds.getColumnValues("sample", ";"), ";", "','") + "') " +
                            "AND ( t.containertypeid= 'Ellution Tube') ";
                }
                else{
                    sampleIdSQL ="select b.sampleid,s.u_extractionid as extractionid from u_ngbatch_sample b,s_sample s where u_ngbatchid = '"+batchid+"' " +
                            "and s.u_extractionid in('" + StringUtil.replaceAll(ds.getColumnValues("sample", ";"), ";", "','") + "') " +
                            "and b.sampleid = s.s_sampleid";
                }

                DataSet dssample = getQueryProcessor().getSqlDataSet(sampleIdSQL);
                if (dssample == null || dssample.size() == 0)
                    throw new SapphireException("Query " + sampleIdSQL + " is not returning any row.");
                HashMap<String, String> hmap = new HashMap<>();

                for (int i = 0; i < ds.size(); i++) {
                    String sample = ds.getValue(i, "sample", "");
                    if (!Util.isNull(sample)) {
                        String querysample = "";
                        for (int j = 0; j < dssample.size(); j++) {
                            querysample = dssample.getValue(j, "extractionid");
                            if (sample.equals(querysample)) {
                                break;
                            }
                            continue;
                        }
                        if (!sample.equalsIgnoreCase(querysample)) {
                            throw new SapphireException("Extraction Id  " + sample + " is not a valid extraction id ");
                        }
                    }
                }

                for (int i = 0; i < dssample.size(); i++) {
                    String sampleid = dssample.getValue(i, "sampleid", "");
                    String extraction = dssample.getValue(i, "extractionid", "");
                    hmap.clear();
                    hmap.put("sample", extraction);
                    DataSet tempFiltrDs = ds.getFilteredDataSet(hmap);
                    if (tempFiltrDs == null || tempFiltrDs.size() == 0)
                        throw new SapphireException("Extraction id " + extraction + " is not valid ");
                    if (tempFiltrDs != null && tempFiltrDs.size() >= 0) {
                        int row = dsfinal.addRow();
                        dsfinal.setValue(row, "sample", sampleid);
                        dsfinal.setValue(row, "concentration", tempFiltrDs.getValue(0, "concentration"));
                    }
                }

                PropertyList props = new PropertyList();
                props.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                props.setProperty(EditSDI.PROPERTY_KEYID1, dsfinal.getColumnValues("sample", ";"));
                if (columnname == "")
                    props.setProperty("concentration", dsfinal.getColumnValues("concentration", ";"));
                else
                    props.setProperty(columnname, dsfinal.getColumnValues("concentration", ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, props);
            }
        }
    }

}




