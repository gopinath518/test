package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

public class QuantAverageSizeWrap extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        //ProcessFile
        PropertyList prop = new PropertyList();
        prop.setProperty("processactionversionid", properties.getProperty("processactionversionid"));
        prop.setProperty("filecontentpropertyid", properties.getProperty("filecontentpropertyid"));
        prop.setProperty("processactionid", properties.getProperty("processactionid"));
        prop.setProperty("readactionversionid", properties.getProperty("readactionversionid"));
        prop.setProperty("readactionid", properties.getProperty("readactionid"));
        prop.setProperty("tagpropertyid", properties.getProperty("tagpropertyid"));
        prop.setProperty("readfilecontent", properties.getProperty("readfilecontent"));
        prop.setProperty("retainonfailure", properties.getProperty("retainonfailure"));
        prop.setProperty("path", properties.getProperty("path"));
        //prop.setProperty("auditactivity", properties.getProperty("auditactivity"));
        prop.setProperty("messagetypeid", properties.getProperty("messagetypeid"));
        prop.setProperty("retainonsuccess", properties.getProperty("retainonsuccess"));
        prop.setProperty("batchid", properties.getProperty("batchid"));
        getActionProcessor().processAction("ProcessFile", "1", prop,false,false);
        String sampleid = prop.getProperty("sampleid");
    }
}
