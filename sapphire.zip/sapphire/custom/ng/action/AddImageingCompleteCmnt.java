package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

public class AddImageingCompleteCmnt extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String comments = properties.getProperty("comment");
        String accessionid = properties.getProperty("accessionid");
        String sampleid = properties.getProperty("sampleid");
        String commentby = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String departmentId = properties.getProperty("departmentid");
        String isCommentAdd = properties.getProperty("iscomment","N");
        if ("N".equalsIgnoreCase(isCommentAdd)) {
            return;
        }
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "AccessionComment");
        props.setProperty(AddSDI.PROPERTY_COPIES, "" + StringUtil.split(accessionid, ";").length);
        props.setProperty("sampleid", sampleid);
        props.setProperty("comments", comments);
        props.setProperty("accessionid", accessionid);
        props.setProperty("commentby", commentby);
        props.setProperty("commentdt", "n");
        props.setProperty("departmentid", departmentId);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Can't move next step");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
