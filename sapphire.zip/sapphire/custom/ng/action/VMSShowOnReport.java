package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.sdidata.AddDataSet;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditDataSet;
import sapphire.action.EnterDataSet;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * Created by dgupta on 7/25/2016.
 */
public class VMSShowOnReport extends BaseAction {


    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("externalimageidentifier");
        String analysisRegion = properties.getProperty("analysisregion");
        String displayid = properties.getProperty("displayid");
        String regionid = properties.getProperty("regionid");
        String dataset = properties.getProperty("dataset");
        String regionimagepath = properties.getProperty("regionimagepath");
        String userid = properties.getProperty("userid");
        String version = properties.getProperty("version");
        String showReport = properties.getProperty("showonreport");
        showReport = showReport.equalsIgnoreCase("Yes") ? "Y" : showReport.equalsIgnoreCase("No") ? "N" : showReport ;


    // find out which dataset to update for show on report flag or property
        DataSet dsRegion = getQueryProcessor().getSqlDataSet("select distinct d.keyid1, d.paramlistid, d.paramlistversionid, d.variantid, d.dataset,  " +
                " CASE WHEN (d.dataset='" + dataset + "')" +
                " THEN  'Y' ELSE  'N' END    showrpt " +
                " from sdidata d, sdidataitem di  " +
                " where d.sdcid=di.sdcid and d.keyid1=di.keyid1 and d.PARAMLISTID = di.PARAMLISTID and d.PARAMLISTVERSIONID=di.PARAMLISTVERSIONID  and d.VARIANTID= di.VARIANTID " +   //paramlistid ='RegionCreated' and ? or Result created
                " and d.dataset= di.dataset and di.paramlistid ='RegionCreated'  and di.keyid1='" +sampleid+ "' ");

        if(dsRegion != null && dsRegion.getRowCount() > 0) {
            PropertyList props = new PropertyList();
            props.setProperty(EditDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(EditDataSet.PROPERTY_KEYID1, dsRegion.getColumnValues("keyid1", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTID, dsRegion.getColumnValues("paramlistid", ";"));
            props.setProperty(EditDataSet.PROPERTY_PARAMLISTVERSIONID, dsRegion.getColumnValues("paramlistversionid", ";"));
            props.setProperty(EditDataSet.PROPERTY_VARIANTID, dsRegion.getColumnValues("variantid", ";"));
            props.setProperty(EditDataSet.PROPERTY_DATASET, dsRegion.getColumnValues("dataset", ";") );
            props.setProperty("u_showonreport",dsRegion.getColumnValues("showrpt", ";"));

            getActionProcessor().processAction(EditDataSet.ID, EditDataSet.VERSIONID, props);
        }


    }
}
