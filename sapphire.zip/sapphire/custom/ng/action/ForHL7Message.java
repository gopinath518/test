package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.sql.ihc.IHCSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;


import java.util.HashMap;

/**
 * Created by dgupta on 7/22/2016.
 */
public class ForHL7Message extends BaseAction {

    /*
    *   OOB method overrided to find block sample and child samples and pass the childe
    *   samples to appropriate tramstop
    *
    *   @param props  Property List of input values
    * */
    public void processAction(PropertyList props) throws SapphireException {
        // for DSBlcok sample simple query based on u_accessioningcomplete is not null (Y or N) for Block sample
        // below is complex query to find block sample by parent child relationship, does not depends on u_accessioningcomplete flag
       /* "select distinct s.s_sampleid,s.u_microtomycompleteflag, s.U_ACCESSIONINGCOMPLETE, s.u_accessionid from s_sample s where s.s_sampleid not in " +
        " (SELECT DESTSAMPLEID FROM s_SAMPLEMAP  CONNECT BY PRIOR sourcesampleid=destsampleid START WITH sourceSAMPLEID in ( select s_sampleid from s_sample where" +
        " u_accessionid=( select distinct u_accessionid from s_sample where s_sampleid in ('"+sampleid+"'))) ) and " +
        " s.u_accessionid=( select distinct u_accessionid from s_sample where s_sampleid in ('"+sampleid+"')) order by s.s_sampleid, s.u_microtomycompleteflag"*/
        String sampleid = props.getProperty("sampleid");
        String accession = props.getProperty("accessionid");
        String sendMessage = props.getProperty("sendMessage");
        String filepath = props.getProperty("filepath");
        HashMap hmFilter = new HashMap();
        sampleid = sampleid.startsWith(";") ? StringUtil.replaceAll(sampleid.substring(1), ";", "','") : StringUtil.replaceAll(sampleid, ";", "','");
        DataSet dsBlockSample = new DataSet();

        // collect sample detail if sampleid or accession id provided as input
        if ((null != sampleid) && sampleid.trim().length() > 0) {
            dsBlockSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.FORHL7_BLOCKSAMPLE_SAMPLE, sampleid));
        } else {
            dsBlockSample = getQueryProcessor().getSqlDataSet(Util.parseMessage(IHCSql.FORHL7_BLOCKSAMPLE_ACCESSION, accession));
        }

        // check all samples are from same accession otherwiswe throw exception
        hmFilter.put("u_accessionid", dsBlockSample.getString(0, "u_accessionid"));
        DataSet dsFilter = dsBlockSample.getFilteredDataSet(hmFilter);
        if (dsBlockSample.getRowCount() != dsFilter.getRowCount())
            throw new SapphireException(getTranslationProcessor().translate("All Blocks are not from same accession"));  // all blocks are not yet cut

        // filter for block for which mcrotomy has performed
        DataSet dsSample = null;
        hmFilter.clear();
        hmFilter.put("u_microtomycompleteflag", "Y");
        dsFilter = dsBlockSample.getFilteredDataSet(hmFilter);

        //  now select all sample from same accession adn with IHC test but not the block samples so s_sampleid not in (block sampleids)
        String strSql = IHCSql.FORHL7_NOTBLOCK_SAMPLES;
        if (dsFilter.getRowCount() > 0) {
            strSql = strSql + " and s.u_accessionid = '" + dsBlockSample.getString(0, "u_accessionid") + "'  and s.s_sampleid not in( '" + dsFilter.getColumnValues("s_sampleid", "','") + "')  ";
        } else if (dsBlockSample.getRowCount() > 0) {
            strSql = strSql + " and s.u_accessionid = '" + dsBlockSample.getString(0, "u_accessionid") + "'  and s.s_sampleid not in( '" + dsBlockSample.getColumnValues("s_sampleid", "','") + "')  ";
        } else {
            strSql = strSql + " and s.s_sampleid in ('" + sampleid + "')";
        }
        dsSample = getQueryProcessor().getSqlDataSet(strSql);
        String[] los = StringUtil.split(Util.getUniqueList(dsSample.getColumnValues("los", ";"), ";", true), ";");


        String currentDepartment = connectionInfo.getDefaultDepartment();
        String site = currentDepartment.substring(0, currentDepartment.indexOf("-"));
        String destinationpartment = site + "-AP";
        if (!Util.validateDepartment(destinationpartment, getQueryProcessor(), getTranslationProcessor()))
            throw new SapphireException("Unable to roupte sample as department: " + destinationpartment + " does not exist");
        PropertyList plStain = null;
        if ((null != dsSample) && (dsSample.getRowCount() > 0)) {
            hmFilter.clear();
            hmFilter.put("u_type", "H");
            hmFilter.put("los", "Morphology");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() == dsSample.getRowCount()) {
                String sql = Util.parseMessage(IHCSql.FORHL7_SAMPLEMOVEMENTSTEP, dsFilter.getColumnValues("s_sampleid", "','"));
                DataSet dsStep = getQueryProcessor().getSqlDataSet(sql);
                if ((null != dsStep) && (dsStep.getRowCount() > 0)) {  // it mean sample has passed microtomy to pathsupport flow not move to IHC QC
                    PropertyList updateProp = new PropertyList();
                    updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                    updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                    updateProp.setProperty("u_hl7result", "AA");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                    // Updating trackitem
                    updateProp.clear();
                    updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                    updateProp.setProperty("custodialdepartmentid", currentDepartment);
                    updateProp.setProperty("custodialuserid", "(null)");
                    updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                    updateProp.setProperty("u_currenttramstop", "StainCompleted");
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
                    // because no other slide is there  so return
                    return;
                } else {
                    /*PropertyList updateProp = new PropertyList();
                    updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                    updateProp.setProperty("u_currentmovementstep", "PathSupport");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                    // Updating trackitem
                    updateProp.clear();
                    updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                    updateProp.setProperty("custodialdepartmentid", site + "-Accessioning");
                    updateProp.setProperty("custodialuserid", "(null)");
                    updateProp.setProperty("u_currentmovementstep", "PathSupport");
                    updateProp.setProperty("u_currenttramstop", "PathSupport");
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
                    // because no other slide is there  so return*/
                    PropertyList updateProp = new PropertyList();
                    updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                    updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                    updateProp.setProperty("u_hl7result", "AA");
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                    // Updating trackitem
                    updateProp.clear();
                    updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                    updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                    updateProp.setProperty("custodialdepartmentid", currentDepartment);
                    updateProp.setProperty("custodialuserid", "(null)");
                    updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                    updateProp.setProperty("u_currenttramstop", "StainCompleted");
                    getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
                    // because no other slide is there  so return
                    return;
                }
            }
            hmFilter.clear();
            hmFilter.put("u_type", "U");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", destinationpartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);

            }
            hmFilter.clear();
            hmFilter.put("u_type", "CU");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", destinationpartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("specimentype", "Unstained Slide");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", destinationpartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("specimentype", "Stained Slide");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", currentDepartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_currenttramstop", "StainCompleted");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("u_type", "H");
            hmFilter.put("u_isbesthne", null);
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", currentDepartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("u_type", "H");
            hmFilter.put("u_isbesthne", "Y");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", currentDepartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_currenttramstop", "StainCompleted");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("u_type", "CH");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", currentDepartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("u_type", "CST");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", currentDepartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_currenttramstop", "StainCompleted");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("u_type", "PC");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                //updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", destinationpartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("u_type", "NC");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", destinationpartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "IHCSetup");
                updateProp.setProperty("u_currenttramstop", "IHCSetup");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            hmFilter.clear();
            hmFilter.put("sampletypeid", "Paraffin Tissue");
            hmFilter.put("specimentype", "Stained Slide");
            dsFilter = dsSample.getFilteredDataSet(hmFilter);
            if (dsFilter.getRowCount() > 0) {
                PropertyList updateProp = new PropertyList();
                updateProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditSDI.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_hl7result", "AA");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, updateProp);

                // Updating trackitem
                updateProp.clear();
                updateProp.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
                updateProp.setProperty(EditTrackItem.PROPERTY_KEYID1, dsFilter.getColumnValues("s_sampleid", ";"));
                updateProp.setProperty("custodialdepartmentid", currentDepartment);
                updateProp.setProperty("custodialuserid", "(null)");
                updateProp.setProperty("u_currentmovementstep", "StainCompleted");
                updateProp.setProperty("u_currenttramstop", "StainCompleted");
                getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, updateProp);
            }
            if (sendMessage.equalsIgnoreCase("Y")) {
                for (String strLos : los) {
                    hmFilter.clear();
                    hmFilter.put("los", strLos);
                    dsFilter = dsSample.getFilteredDataSet(hmFilter);
                    if (dsFilter.getRowCount() > 0) {
                        plStain = new PropertyList();
                        plStain.setProperty("sampleid", dsFilter.getColumnValues("s_sampleid", ";"));
                        plStain.setProperty("filepath", filepath);
                        plStain.setProperty("type", "new");
                        getActionProcessor().processAction("Hl7MessageCreator", "1", plStain);
                    }
                }
            }
        }

    }

}
