package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.misc.SendBulletin;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Date;
import java.lang.String;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;


/**
 * Created by ssen on 4/26/2017.
 */
public class SendDelayBulletin extends BaseAction {
    DataSet dsBuletin = null;
    private static final String USER_TYPE = "AP";
    private static final int SPLIT_NUMBER = 80;

    public void processAction(PropertyList properties) throws SapphireException {
        DataSet dsSample = getPendingSamplesForAP();
        if (dsSample == null || dsSample.size() == 0) {
            logger.info("There is no pendinig list to send bulletin.");
            return;
        }

        DataSet dsUser = getAPUsers();
        if (dsUser == null || dsUser.size() == 0) {
            logger.info("NO " + USER_TYPE + " user define in the system");
            return;
        }
        DataSet dsfinal = mergeSampleAndUser(dsSample, dsUser);
        if (dsfinal != null && dsfinal.size() > 0) {
            DataSet dssplit = splitBulletin(dsfinal);
            try {
                PropertyList props = new PropertyList();
                for (int i = 0; i < dssplit.size(); i++) {
                    props.setProperty(SendBulletin.PROPERTY_USER, dssplit.getValue(i, "user"));
                    props.setProperty(SendBulletin.PROPERTY_DESCRIPTION, "sample pending for more than 4 hrs");
                    props.setProperty(SendBulletin.PROPERTY_BODY, "Accession id:-" + dssplit.getValue(i, "accession") + " Client Speciment id:-" +
                            dssplit.getValue(i, "clientspecimen") + "  Sample id:- " + dssplit.getValue(i, "sample") + " " +
                            "pending for more than 4 hrs....");
                    props.setProperty(SendBulletin.PROPERTY_SOURCE, "System");
                    getActionProcessor().processAction(SendBulletin.ID, SendBulletin.VERSIONID, props);
                }
            } catch (Exception e) {
                throw new SapphireException("Error occured while executing:: ActionProcessor ::" + e.getMessage(), ErrorDetail.TYPE_VALIDATION);
            }
        }
    }


    public DataSet getPendingSamplesForAP() throws SapphireException {
        String filtersample = "";
        String samplesql = "select s.s_sampleid sampleid,s.u_currentmovementstep currmovmentstep,t.custodialdepartmentid,s.u_accessionid accessionid," +
                " s.u_clientspecimenid clientspecimenid from s_sample s,u_sampletestcodemap stm,trackitem t" +
                " where s.s_sampleid=stm.s_sampleid  and s.s_sampleid=t.linkkeyid1 and stm.methodology='IHC'" +
                " and s.u_currentmovementstep in('IHCSetup' , 'InStaining', 'StainRejected') and t.custodialdepartmentid like'%" + USER_TYPE + "'";
        DataSet dsapsample = getQueryProcessor().getSqlDataSet(samplesql);
        if (dsapsample == null || dsapsample.size() == 0) {
            return null;// no pending list
        }
        samplesql = "select sampleid, to_char(max(createdt),'dd/mm/yy hh:mm:ss') currdate from u_samplemovementsteps " +
                " where sampleid in('" + StringUtil.replaceAll(dsapsample.getColumnValues("sampleid", ";"), ";", "','") + "') group by sampleid ";
        DataSet dssampleanddate = getQueryProcessor().getSqlDataSet(samplesql);
        if (dsapsample == null || dsapsample.size() == 0) {
            return null;//no pending list
        }
        try {
            for (int i = 0; i < dssampleanddate.getRowCount(); i++) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/mm/yy hh:mm:ss");
                Date date1 = dateFormat.parse(dssampleanddate.getValue(i, "currdate"));
                Date date2 = new Date();
                long diffInMillies = date2.getTime() - date1.getTime();
                long diffHours = diffInMillies / (60 * 60 * 1000);
                if (diffHours > 4) {
                    filtersample = filtersample + ";" + dssampleanddate.getValue(i, "sampleid");
                }
            }
        } catch (Exception e) {
            //throw new SapphireException("Error occured while executing:: Date format method ::" + e.getMessage(), ErrorDetail.TYPE_VALIDATION);
            throw new SapphireException( ErrorDetail.TYPE_VALIDATION,"Error occured while executing:: Date format method ::" + e.getMessage());

        }
        if (filtersample.startsWith(";")) {
            filtersample = filtersample.substring(1);
        }

        String filtersamplearr[] = filtersample.split(";");
        HashMap hmfltr = new HashMap();

        DataSet tempFiltrDs = new DataSet();
        tempFiltrDs.addColumn("sampleid", DataSet.STRING);
        tempFiltrDs.addColumn("currmovmentstep", DataSet.STRING);
        tempFiltrDs.addColumn("custodialdepartmentid", DataSet.STRING);
        tempFiltrDs.addColumn("accessionid", DataSet.STRING);
        tempFiltrDs.addColumn("clientspecimenid", DataSet.STRING);
        int incr = 0;
        for (int i = 0; i < filtersamplearr.length; i++) {
            hmfltr.clear();
            //hmfltr.put("sampleid", dssampleanddate.getValue(i, "sampleid"));
            hmfltr.put("sampleid", filtersamplearr[i]);
            DataSet dsFilter = dsapsample.getFilteredDataSet(hmfltr);
            if(dsFilter!=null && dsFilter.size()>0) {
                incr = tempFiltrDs.addRow();
                tempFiltrDs.setValue(incr, "sampleid", dsFilter.getValue(0, "sampleid", ""));
                tempFiltrDs.setValue(incr, "currmovmentstep", dsFilter.getValue(0, "currmovmentstep", ""));
                tempFiltrDs.setValue(incr, "custodialdepartmentid", dsFilter.getValue(0, "custodialdepartmentid", ""));
                tempFiltrDs.setValue(incr, "accessionid", dsFilter.getValue(0, "accessionid", ""));
                tempFiltrDs.setValue(incr, "clientspecimenid", dsFilter.getValue(0, "clientspecimenid", ""));
            }
        }
        return tempFiltrDs;


    }

    public DataSet getAPUsers() {
        String userSQL = "select departmentid,listagg(sysuserid, ';') within group (order by departmentid) sysuserid" +
                " from departmentsysuser where departmentid like '%" + USER_TYPE + "%'" +
                " group by departmentid";


        DataSet dsuser = getQueryProcessor().getSqlDataSet(userSQL);
        if (dsuser == null || dsuser.size() == 0) {
            return null;
        }
        return dsuser;
    }

    public DataSet mergeSampleAndUser(DataSet dsSample, DataSet dsUser) {
        if (dsBuletin == null) {
            dsBuletin = new DataSet();
            dsBuletin.addColumn("dept", DataSet.STRING);
            dsBuletin.addColumn("sample", DataSet.STRING);
            dsBuletin.addColumn("user", DataSet.STRING);
            dsBuletin.addColumn("accession", DataSet.STRING);
            dsBuletin.addColumn("clientspecimen", DataSet.STRING);
        }
        HashMap hmap = new HashMap();
        DataSet filterdataSet = new DataSet();
        int inr = 0;
        for (int i = 0; i < dsUser.size(); i++) {
            hmap.clear();
            hmap.put("custodialdepartmentid", dsUser.getValue(i, "departmentid"));
            filterdataSet = dsSample.getFilteredDataSet(hmap);
            if (filterdataSet != null && filterdataSet.size() > 0) {
                inr = dsBuletin.addRow();
                dsBuletin.setValue(inr, "dept", dsUser.getValue(i, "departmentid"));
                dsBuletin.setValue(inr, "sample", filterdataSet.getColumnValues("sampleid", ";"));
                dsBuletin.setValue(inr, "user", dsUser.getValue(i, "sysuserid")); //IN QUEREY THERE IS HASH SEPERATED LISTAGG
                dsBuletin.setValue(inr, "accession", filterdataSet.getColumnValues("accessionid", ";"));
                dsBuletin.setValue(inr, "clientspecimen", filterdataSet.getColumnValues("clientspecimenid", ";"));

            }
        }
        return dsBuletin;
    }

    public DataSet splitBulletin(DataSet dsfinal) throws SapphireException {
        String sample = "";
        String accession = "";
        String clientspecimen = "";

        String sample1 = "";
        String accession1 = "";
        String clientspecimen1 = "";

        int len = 0;
        int count = 0;
        DataSet ds = new DataSet();
        ds.addColumn("dept", DataSet.STRING);
        ds.addColumn("sample", DataSet.STRING);
        ds.addColumn("user", DataSet.STRING);
        ds.addColumn("accession", DataSet.STRING);
        ds.addColumn("clientspecimen", DataSet.STRING);

        for (int i = 0; i < dsfinal.size(); i++) {
            String[] samplearr = dsfinal.getValue(i, "sample").split(";");
            String[] accessionarr = dsfinal.getValue(i, "accession").split(";");
            String[] clientarr = dsfinal.getValue(i, "clientspecimen").split(";");
            len = samplearr.length;
            int inr = 0;
            int arrnum = 0;
            while (len > SPLIT_NUMBER) {
                inr = ds.addRow();
                for (int j = 0; j < SPLIT_NUMBER; j++) {
                    arrnum = arrnum + 1;
                    sample = sample + ";" + samplearr[arrnum];
                    accession = accession + ";" + accessionarr[arrnum];
                    clientspecimen = clientspecimen + ";" + clientarr[arrnum];
                }
                sample = sample.substring(1);
                accession = accession.substring(1);
                clientspecimen = clientspecimen.substring(1);
                ds.setValue(inr, "dept", dsfinal.getValue(i, "dept"));
                ds.setValue(inr, "sample", sample);
                ds.setValue(inr, "user", dsfinal.getValue(i, "user"));
                ds.setValue(inr, "accession", accession);
                ds.setValue(inr, "clientspecimen", clientspecimen);
                len = len - SPLIT_NUMBER;
                count++;
                sample = "";
                accession = "";
                clientspecimen = "";
            }
            int at = (SPLIT_NUMBER * count);


            if (at != 0) {
                for (int l = 0; l < len; l++) {
                    sample1 = sample1 + ";" + samplearr[arrnum];
                    accession1 = accession1 + ";" + accessionarr[arrnum];
                    clientspecimen1 = clientspecimen1 + ";" + clientarr[arrnum];
                    arrnum++;
                }
                sample1 = sample1.substring(1);
                accession1 = accession1.substring(1);
                clientspecimen1 = clientspecimen1.substring(1);
            } else {
                sample1 = dsfinal.getValue(i, "sample");
                accession1 = dsfinal.getValue(i, "accession");
                clientspecimen1 = dsfinal.getValue(i, "clientspecimen");
            }


            inr = ds.addRow();

            ds.setValue(inr, "dept", dsfinal.getValue(i, "dept"));
            ds.setValue(inr, "sample", sample1);
            ds.setValue(inr, "user", dsfinal.getValue(i, "user"));
            ds.setValue(inr, "accession", accession1);
            ds.setValue(inr, "clientspecimen", clientspecimen1);

            count = 0;

        }
        return ds;


    }


}

