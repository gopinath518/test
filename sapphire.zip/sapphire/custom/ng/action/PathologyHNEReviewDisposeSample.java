package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;


/**
 * Created by DMondal on 10/17/2016.
 * This action is used for dispose selected samples from batch.IOt will find all the sample present in the batch with backup slides. If Backup slides
 * present department will be the BlockRoom and back slides is not present department will be the Histology.
 */
public class PathologyHNEReviewDisposeSample extends BaseAction {
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("keyid1");
        String status = properties.getProperty("status");
        String comment = properties.getProperty("disposalcomment");
        /*  9 May 17 dg
            below code is commented out because its not require for Bio Pharma system
        */
        /*createDataSet();
        checkBackUpSlides(sampleids);
        getClientspecimenAccession();
        incidentCreateForDispose(comment);*/

        /*   END OF COMMENT */


        String movementstep = getCurrentmovementStep(sampleids);
        if (movementstep.contains("PathologyBatch")) {
            removeFromBatch(sampleids);
        }
        editCurrentMovement(sampleids, status, comment);


    }

    private String getCurrentmovementStep(String sampleids) throws SapphireException {
        String sampleid = StringUtil.replaceAll(sampleids, ";", "','");
        String sqlcurrntStep = "select s_sampleid,u_currentmovementstep from s_Sample where s_sampleid in('" + sampleid + "') ";
        DataSet dsCurrntStep = getQueryProcessor().getSqlDataSet(sqlcurrntStep);
        if (dsCurrntStep == null) {
            throw new SapphireException("Something wrong happened. Contact your Administrator");
        }
        if (dsCurrntStep.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample id not found");
            errMsg += "\nQuery retuns no rows:" + sqlcurrntStep;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        String currentMovementStep = "";
        String currentStep = "";
        for (int i = 0; i < dsCurrntStep.size(); i++) {
            currentStep = dsCurrntStep.getString(i, "u_currentmovementstep");
            if (Util.isNull(currentStep)) {
                String errMsg = getTranslationProcessor().translate("Current movementstep not found for sample:" + dsCurrntStep.getString(i, "s_sampleid"));
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
            }
            currentMovementStep = currentMovementStep + ";" + currentStep;
        }
        return currentMovementStep;
    }

    /**
     * This mothod is used for searching backup slides present or not if backup slides present it will go to Histology otherwise
     * it will go to BlockRoom.
     *
     * @param sampleids
     * @throws SapphireException
     */
/*

    private void checkBackUpSlides(String sampleids) throws SapphireException {
        String currentuser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String department = getConnectionProcessor().getConnectionInfo(getConnectionid()).getDefaultDepartment();
        String dept = department.substring(0, department.indexOf("-"));
        String sampleid = StringUtil.replaceAll(sampleids, ";", "','");
        String sqlSorcDest = "SELECT  s_samplemap.sourcesampleid,s_sample.s_sampleid FROM s_samplemap ,s_sample " +
                "where s_sample.s_sampleid in('" + sampleid + "') " +
                "and s_samplemap.destsampleid=s_sample.s_sampleid and  s_sample.pooledflag is null";
        DataSet dsSorcDest = getQueryProcessor().getSqlDataSet(sqlSorcDest);
        if (dsSorcDest == null) {
            throw new SapphireException("Something wrong happened. Contact your Administrator");
        }
        if (dsSorcDest.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample id not found");
            errMsg += "\nQuery retuns no rows:" + sqlSorcDest;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }

        String sqlSorcDestType = "select sm1.sourcesampleid, sm1.destsampleid,s1.u_type " +
                "from s_samplemap sm1,s_sample s1 where s1.s_sampleid=sm1.destsampleid and sm1.sourcesampleid in  (select sm.sourcesampleid " +
                "from s_samplemap sm,s_sample s " +
                "where sm.destsampleid=s.s_sampleid and  s.pooledflag is null and " +
                "s.s_sampleid in('" + sampleid + "'))";
        HashMap hm = new HashMap();
        int rowcnt = 0;
        DataSet dsSorcDestType = getQueryProcessor().getSqlDataSet(sqlSorcDestType);
        if (dsSorcDestType == null) {
            throw new SapphireException("Something wrong happened. Contact your Administrator");
        }
        if (dsSorcDestType.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample id not found");
            errMsg += "\nQuery retuns no rows:" + sqlSorcDestType;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        for (int i = 0; i < dsSorcDest.size(); i++) {
            hm.clear();
            hm.put("sourcesampleid", dsSorcDest.getValue(i, "sourcesampleid"));
            hm.put("u_type", "B");
            DataSet dsFilter = dsSorcDestType.getFilteredDataSet(hm);
            if (dsFilter.size() > 0) {
                String siteDept = dept + "-AP";
                String validateDept = deptValidate(siteDept);
                rowcnt = dsMain.addRow();
                dsMain.setValue(rowcnt, "sample", dsSorcDest.getValue(i, "s_sampleid"));
                dsMain.setValue(rowcnt, "fromdept", department);
                dsMain.setValue(rowcnt, "todept", validateDept);
                dsMain.setValue(rowcnt, "user", currentuser);
            } else {
                String siteDept = dept + "-BlockRoom";
                String validateDept = deptValidate(siteDept);
                rowcnt = dsMain.addRow();
                dsMain.setValue(rowcnt, "sample", dsSorcDest.getValue(i, "s_sampleid"));
                dsMain.setValue(rowcnt, "fromdept", department);
                dsMain.setValue(rowcnt, "todept", validateDept);
                dsMain.setValue(rowcnt, "user", currentuser);
            }
        }
    }
*/

    /**
     * Description : This method is used for remove sample from batch
     *
     * @throws SapphireException
     */
    private void removeFromBatch(String sampleid) throws SapphireException {
        String sampleids = StringUtil.replaceAll(sampleid, ";", "','");
        StringBuilder sqlString = new StringBuilder();
        sqlString.append("SELECT u_hnebatchdetailid as batchdetailid FROM u_hnebatchdetail WHERE sampleid IN('");
        sqlString.append(sampleids);
        sqlString.append("')");
        DataSet dsBatchDetailId = getQueryProcessor().getSqlDataSet(sqlString.toString());
        if (dsBatchDetailId == null) {
            throw new SapphireException("Something wrong happened. Contact your Administrator");
        }
        if (dsBatchDetailId.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Hne batchdetailid id not found.For sample id:" + sampleids);
            errMsg += "\nQuery retuns no rows:" + sqlString;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        PropertyList props = new PropertyList();
        props.setProperty(DeleteSDI.PROPERTY_SDCID, "HNEBatchDetail");
        props.setProperty(DeleteSDI.PROPERTY_KEYID1, dsBatchDetailId.getColumnValues("batchDetailId", ";"));
        try {
            getActionProcessor().processAction(DeleteSDI.ID, DeleteSDI.VERSIONID, props);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in Remove from batch");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * Description :This is used for updating u_currentmovementstep as null for dispose from batch list.
     *
     * @throws SapphireException
     */
    private void editCurrentMovement(String sampleids, String status, String comment) throws SapphireException {
        PropertyList editProp = new PropertyList();
        int i = 0;
        if(sampleids.startsWith(";")) sampleids= sampleids.substring(1) ;
        if(sampleids.contains(";"))
            i = StringUtil.split(sampleids, ";").length + 1;
        else
            i=1 ;

        editProp.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        editProp.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
        editProp.setProperty("u_currentmovementstep", StringUtil.repeat("Disposed",i, ";"));
        editProp.setProperty("storagestatus", StringUtil.repeat("Disposed", i, ";"));
        editProp.setProperty("storagedisposalstatus", StringUtil.repeat(status, i, ";"));
        editProp.setProperty("u_disposalcomment", StringUtil.repeat(comment, i, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editProp);
        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Error in edit u_currentmovementstep in EditSDI.");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * Description : This method will search u_clientspecimenid,u_accessionid for creating message
     *
     * @throws SapphireException
     *//*
    private void getClientspecimenAccession() throws SapphireException {
        HashMap hm = new HashMap();
        String sqlClientSpecimen = "select s_sampleid,u_clientspecimenid,u_accessionid from s_sample where s_sampleid in ('" + StringUtil.replaceAll(dsMain.getColumnValues(DATASET_PROPERTY_SAMPLEID, ";"), ";", "','") + "')";
        DataSet dsClientSpecimen = getQueryProcessor().getSqlDataSet(sqlClientSpecimen);
        if (dsClientSpecimen == null) {
            throw new SapphireException("Something wrong happened. Contact your Administrator");
        }
        if (dsClientSpecimen.size() == 0) {
            String errStr = getTranslationProcessor().translate(" Sampleid not found. ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        for (int i = 0; i < dsClientSpecimen.size(); i++) {
            String sampleid = dsClientSpecimen.getValue(i, "s_sampleid");
            String specimen = dsClientSpecimen.getValue(i, "u_clientspecimenid");
            String accession = dsClientSpecimen.getValue(i, "u_accessionid");
            hm.clear();
            hm.put("sample", sampleid);
            DataSet filteDs = dsMain.getFilteredDataSet(hm);
            if (filteDs != null && filteDs.getRowCount() > 0) {
                dsMain.setValue(i, DATASET_PROPERTY_CLIENTSPECIMENTID, specimen);
                dsMain.setValue(i, DATASET_PROPERTY_ACCESSIONID, accession);
            }
        }
    }
*/
/*

    */
/**
     * Description : This method will create request
     *
     * @throws SapphireException
     *//*

    private void incidentCreateForDispose(String comment) throws SapphireException {
        for (int i = 0; i < dsMain.getRowCount(); i++) {
            String msg = "Disposed sample :" + dsMain.getString(i, DATASET_PROPERTY_SAMPLEID) + ", Block id :" + dsMain.getString(i, DATASET_PROPERTY_CLIENTSPECIMENTID)
                    + " from accession : " + dsMain.getString(i, DATASET_PROPERTY_ACCESSIONID);
            PropertyList recordProp = new PropertyList();
            recordProp.setProperty("sourcesdcid", "Sample");
            recordProp.setProperty("sourcekeyid1", dsMain.getString(i, DATASET_PROPERTY_SAMPLEID));
            recordProp.setProperty("incidentcategory", "UnPlanned");
            recordProp.setProperty("explanation", comment + ".See the message for details");
            recordProp.setProperty("rootcause", comment + ".See the message for details");
            recordProp.setProperty("u_fromdepartment", dsMain.getString(i, DATASET_PROPERTY_FROMDEPT));
            recordProp.setProperty("initialstatus", "PendingApproval");
            recordProp.setProperty("reportedby", dsMain.getString(i, DATASET_PROPERTY_USER));
            recordProp.setProperty("u_message", comment + "\n" + msg);
            recordProp.setProperty("departmentid", dsMain.getString(i, DATASET_PROPERTY_TODEPT));
            try {
                getActionProcessor().processAction(RecordIncident.ID, RecordIncident.VERSIONID, recordProp);
            } catch (ActionException ex) {
                String error = getTranslationProcessor().translate("Error in RecordIncident.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

            }

            PropertyList approvalProps = new PropertyList();
            approvalProps.setProperty("sdcid", "LV_Incdt");
            approvalProps.setProperty("keyid1", recordProp.getProperty("newkeyid1"));
            approvalProps.setProperty("pendingapprovalstatus", "PendingApproval");
            approvalProps.setProperty("approvalstatus", "Approved");
            approvalProps.setProperty("approvalstatuscolumn", "incidentstatus");


            try {
                getActionProcessor().processAction(SubmitSDIForApproval.ID, SubmitSDIForApproval.VERSIONID, approvalProps);
            } catch (ActionException e) {
                String error = getTranslationProcessor().translate("Error in SubmitSDIForApproval.");
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

            }
        }
    }
*/

    /**
     * Description : This method will check department is valid or not.
     *
     * @param siteDept
     * @return
     * @throws SapphireException
     */
    private String deptValidate(String siteDept) throws SapphireException {
        String site = siteDept.substring(0, siteDept.indexOf("-"));
        String targetDept = siteDept.substring(siteDept.indexOf("-") + 1, siteDept.length());
        String department = "";
        String dept = "select departmentid from department where departmentid='" + siteDept + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor().translate(targetDept + " Department not found in site " + site);
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
        }
        return department;
    }


    /**
     * Description : This method is for creating dataset
     *
     * @throws SapphireException
     */
   /* private DataSet dsMain = null;
    private static final String DATASET_PROPERTY_SAMPLEID = "sample";
    private static final String DATASET_PROPERTY_FROMDEPT = "fromdept";
    private static final String DATASET_PROPERTY_TODEPT = "todept";
    private static final String DATASET_PROPERTY_USER = "user";
    private static final String DATASET_PROPERTY_CLIENTSPECIMENTID = "clientspecimenid";
    private static final String DATASET_PROPERTY_ACCESSIONID = "accessionid";
*/
   /* private void createDataSet() throws SapphireException {
        if (dsMain == null) {
            dsMain = new DataSet();
            dsMain.addColumn(DATASET_PROPERTY_SAMPLEID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_FROMDEPT, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_TODEPT, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_USER, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_CLIENTSPECIMENTID, DataSet.STRING);
            dsMain.addColumn(DATASET_PROPERTY_ACCESSIONID, DataSet.STRING);
        }
    }*/
}
