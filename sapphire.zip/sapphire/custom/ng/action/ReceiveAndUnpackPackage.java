package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

public class ReceiveAndUnpackPackage extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        String packageId = properties.getProperty("packageid", "");
        if (packageId == null || packageId.equalsIgnoreCase("")) {
            throw new SapphireException("PackageId not Found");
        }
        receivePackage(packageId);
        sampleCheckOutFromPackage(packageId);
        unPackPackage(packageId);
        properties.setProperty("msg", "Package & Samples successfully unpacked");
    }

    private void receivePackage(String packageId) throws SapphireException {
        try {
            Logger.logInfo("Receiving Package for packageId:: " + packageId);
            PropertyList pl = new PropertyList();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "LV_Package");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, packageId);
            pl.setProperty("packagestatus", "Received");

            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (Exception e) {
            Logger.logInfo("Error occured while changing package status::" + packageId);
            throw new SapphireException("Error occured while changing package status ::" + packageId);
        }
    }

    private void unPackPackage(String packageId) throws SapphireException {
        PropertyList pl = new PropertyList();
        try {
            Logger.logInfo("Updating custodial information for packageId:: " + packageId);
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "LV_Package");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, packageId);
            pl.setProperty("currentstorageunitid", "(null)");
            pl.setProperty("custodialuserid", "(null)");
            pl.setProperty("custodialdepartmentid", "(null)");

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        } catch (Exception e) {
            Logger.logInfo("Error occured while changing package custodialuserid and custodialdepartmentid ::" + packageId);
            throw new SapphireException("Error occured while changing package custodialuserid and custodialdepartmentid ::" + packageId);
        }
        try {
            Logger.logInfo("Updating package status to Emptied for packageid:: " + packageId);
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "LV_Package");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, packageId);
            pl.setProperty("packagestatus", "Emptied");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (Exception e) {
            Logger.logInfo("Error occured while changing package status::" + packageId);
            throw new SapphireException("Error occured while changing package status::" + packageId);
        }


    }

    private void sampleCheckOutFromPackage(String packageId) throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String departmentId = connectionInfo.getDefaultDepartment();
        String sql = "select linkkeyid1 from trackitem "
                + " where currentstorageunitid =(select storageunitid from storageunit where linkkeyid1='" + packageId + "')";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        Logger.logInfo("Package ID:: " + packageId + " :: contains sample information as below::");
        ds.showData();
        PropertyList pl = new PropertyList();
        try {
            pl.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditTrackItem.PROPERTY_KEYID1, ds.getColumnValues("linkkeyid1", ";"));
            pl.setProperty("currentstorageunitid", "(null)");
            pl.setProperty("custodialuserid", currentuser);
            pl.setProperty("custodialdepartmentid", departmentId);
            pl.setProperty("u_currenttramstop", "");

            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, pl);
        } catch (Exception e) {
            Logger.logInfo("Error occured while changing sample custodial information ::" + ds.getColumnValues("linkkeyid1", ";"));
            throw new SapphireException("Error occured while changing sample custodial information ::" + ds.getColumnValues("linkkeyid1", ";"));
        }
        try {
            Logger.logInfo("Updating QC Pending for sample id :: " + ds.getColumnValues("linkkeyid1", ";"));
            pl.clear();
            pl.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
            pl.setProperty(EditSDI.PROPERTY_KEYID1, ds.getColumnValues("linkkeyid1", ";"));
            pl.setProperty("u_isshipedsampleqcpending", "Y");
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);
        } catch (Exception e) {
            Logger.logInfo("Error occured while changing sample QC Pending ::" + ds.getColumnValues("linkkeyid1", ";"));
            throw new SapphireException("Error occured while changing sample QC Pending ::" + ds.getColumnValues("linkkeyid1", ";"));
        }
    }
}
