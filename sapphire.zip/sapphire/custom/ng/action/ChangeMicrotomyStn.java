package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 8/5/2016.
 * @desc: Changes the Microtomy Station based on the provided input
 * from a prompt page.The input value is the microstationid which will
 * be associated with the current logged in user.
 * 
 */
public class ChangeMicrotomyStn extends BaseAction {
    public void processAction(PropertyList prop) throws SapphireException{
        String microtomyStn=prop.getProperty("microtomystnprompt");
        String currentUser=connectionInfo.getSysuserId();
        PropertyList propertyList=new PropertyList();
        propertyList.setProperty(EditSDI.PROPERTY_SDCID,"User");
        propertyList.setProperty(EditSDI.PROPERTY_KEYID1,currentUser);
        propertyList.setProperty("u_microtomystn",microtomyStn);

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,propertyList);
    }
}
