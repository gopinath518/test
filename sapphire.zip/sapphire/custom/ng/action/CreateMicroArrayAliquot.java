package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.action.MultiSampleChild;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by akumar on 6/14/2016.
 */
public class CreateMicroArrayAliquot extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String parentSample = properties.getProperty("parentsample");
        String psample = StringUtil.replaceAll(parentSample, ";", "','");
        String currentuser = connectionInfo.getSysuserId();
        String custodialdepartmentid = connectionInfo.getDefaultDepartment();

        String aliquotid = createAliquot(parentSample);
        properties.setProperty("newkeyid1", aliquotid);
        String sql = "select containertypeid,custodialdepartmentid from trackitem where linksdcid='Sample' and linkkeyid1 in ('" + psample + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String containertype = ds.getColumnValues("containertypeid", ";");
        //updateAliquot(aliquotid);
        updateTrackitem(aliquotid, currentuser, containertype, custodialdepartmentid);
        addTestCodeOnAliquot(psample, aliquotid);
    }

    private String createAliquot(String parentSample) throws SapphireException {
        PropertyList prop = new PropertyList();
        //String []samparr =StringUtil.split(parentSample,";");
        //for (String currentsamp:samparr) {
        prop.setProperty(MultiSampleChild.PROPERTY_PARENT_SAMPLEID, parentSample);
        prop.setProperty(MultiSampleChild.PROPERTY_CHILD_COPIES, "1");
        prop.setProperty(MultiSampleChild.PROPERTY_SYNCPARENT, "Y");
        prop.setProperty(MultiSampleChild.PROPERTY_COPYDOWNCOLUMNS, "sampletypeid;u_markminimal;u_sampleinformation;u_accessionid;u_currentmovementstep,u_extractionid");

        try {
            getActionProcessor().processAction(MultiSampleChild.ID, MultiSampleChild.VERSIONID, prop);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Cannot Create Aliquot.");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        //}
        String newkeyid = prop.getProperty("newkeyid1");
        return newkeyid;
    }

    private void updateAliquot(String aliquotid) throws SapphireException {
        PropertyList prop1 = new PropertyList();
        prop1.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
        prop1.setProperty(EditSDI.PROPERTY_KEYID1, aliquotid);
        //prop1.setProperty("storagestatus","In Circulation");
        //prop1.setProperty("storagestatus","In Circulation");
        //prop1.setProperty("storagestatus","In Circulation");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop1);
    }

    private void updateTrackitem(String aliquotid, String currentuser, String containertype, String custodialdepartmentid) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        props.setProperty(EditTrackItem.PROPERTY_KEYID1, aliquotid);
        props.setProperty("containertypeid", containertype);
        props.setProperty("custodialuserid", currentuser);
        props.setProperty("custodialdepartmentid", custodialdepartmentid);
        props.setProperty("custodytakendt", "n");

        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, props);
        } catch (SapphireException e) {
            String err = getTranslationProcessor().translate("Cannot update Trackitem for Aliquot.");
            err += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
    }


    private void addTestCodeOnAliquot(String parentSample, String aliquotid) throws SapphireException {
        String ss_parentTest = "select distinct lvtestcodeid,testcode,testname,methodology,ispanel,los from u_sampletestcodemap" +
                " where s_sampleid in('" + parentSample + "')";
        DataSet dsParentTest = getQueryProcessor().getSqlDataSet(ss_parentTest);
        String[] samparr = StringUtil.split(aliquotid, ";");

        if (dsParentTest == null) {
            String error = getTranslationProcessor().translate("Query failed");
            error += ss_parentTest;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);
        }
        if (dsParentTest.size() == 0) {//todo
            String e=getTranslationProcessor().translate("No Test is assigned to the Parent");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE,e);
        }
        DataSet dsSamplefinal = new DataSet();
        dsSamplefinal.addColumn("s_sampleid", DataSet.STRING);
        dsSamplefinal.addColumn("lvtestcode", DataSet.STRING);// transport
        dsSamplefinal.addColumn("ispanel", DataSet.STRING);//aacc

        for (int i=0;i<samparr.length;i++) {
           // for (int j = 0; j < dsParentTest.getRowCount(); j++) {
                int rowID = dsSamplefinal.addRow();
                dsSamplefinal.setValue(rowID, "s_sampleid", samparr[i]);
                dsSamplefinal.setValue(rowID, "lvtestcode", dsParentTest.getValue(i, "lvtestcodeid"));
                dsSamplefinal.setValue(rowID, "ispanel", dsParentTest.getValue(i, "ispanel", ""));

            //}
        }
        PropertyList hsAddTestCode = new PropertyList();
        hsAddTestCode.clear();
        hsAddTestCode.setProperty("s_sampleid", dsSamplefinal.getColumnValues("s_sampleid", ";"));
        hsAddTestCode.setProperty("lvtestcode", dsSamplefinal.getColumnValues("lvtestcode", ";"));
        hsAddTestCode.setProperty("ispanel", dsSamplefinal.getColumnValues("ispanel", ";"));
        hsAddTestCode.setProperty("bypassvalidation", "Y");
        try {
            getActionProcessor().processAction("AddTestCode", "1", hsAddTestCode);
        } catch (SapphireException e) {
            String errMSG = getTranslationProcessor().translate("Action failed. Data Mismatch/Junk Data. ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
        }

    }
}

