package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

public class ValidateSlideReconComplete extends BaseAction {
    String msg = "Operation successful";

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("sampleid");
        String u_currentmovementstep = properties.getProperty("u_currentmovementstep");
        String custodialdepartmentid = properties.getProperty("custodialdepartmentid");
        if (Util.isNull(sampleid)) {
            throw new SapphireException("Please select atleast one specimen.");
        }
        String sql = Util.parseMessage(ApSql.GET_SPECIMEN_INFO_ALL, StringUtil.replaceAll(sampleid, ";", "','"));
        DataSet dsInfo = getQueryProcessor().getSqlDataSet(sql);
        HashMap hm = new HashMap();
        if (dsInfo.size() > 0) {
            hm.clear();
            hm.put("u_isbesthne", "N");
            hm.put("issharehne", "N");
            DataSet dsHNEFilter = dsInfo.getFilteredDataSet(hm);
            if (dsHNEFilter.size() > 0) {
                String sampleids = dsHNEFilter.getColumnValues("s_sampleid", ";");
                PropertyList prop = new PropertyList();
                prop.setProperty("sampleid", sampleids);
                prop.setProperty("u_currentmovementstep", u_currentmovementstep);
                prop.setProperty("custodialdepartmentid", custodialdepartmentid);
                try {
                    getActionProcessor().processAction("AssignToMySite", "1", prop);
                } catch (Exception ec) {
                    throw new SapphireException(ec.getMessage());
                }
            }
            hm.clear();
            hm.put("u_isbesthne", "Y");
            hm.put("issharehne", "N");
            DataSet dsBestHNEFilter = dsInfo.getFilteredDataSet(hm);
            if (dsBestHNEFilter.size() > 0) {
                String sampleids = dsBestHNEFilter.getColumnValues("s_sampleid", ",");
                sql = "select u_sampletestcodemapid from u_sampletestcodemap where s_sampleid in('" + StringUtil.replaceAll(sampleids, ";", "','") + "')" +
                        " and lvtestcodeid in('93BPQ','94BPQ') and teststatus !='Cancelled'";
                DataSet dsBestHNE = getQueryProcessor().getSqlDataSet(sql);
                if (dsBestHNE.size() == 0) {
                    PropertyList prop = new PropertyList();
                    prop.setProperty("sampleid", sampleids);
                    prop.setProperty("u_currentmovementstep", u_currentmovementstep);
                    prop.setProperty("custodialdepartmentid", custodialdepartmentid);
                    try {
                        getActionProcessor().processAction("AssignToMySite", "1", prop);
                    } catch (Exception ec) {
                        throw new SapphireException(ec.getMessage());
                    }
                } else {
                    throw new SapphireException("Only Best H&E Specimen(s): " + sampleids + " should be route via <b>Move To Choose Best Specimen</b> to Accession Tramline.");
                }
            }
            hm.clear();
            hm.put("u_type", "SH");
            hm.put("issharehne", "Y");
            DataSet dsShareHNEFiletr = dsInfo.getFilteredDataSet(hm);
            if (dsShareHNEFiletr.size() > 0) {
                String sharesample = dsShareHNEFiletr.getColumnValues("s_sampleid", ";");
                PropertyList props = new PropertyList();
                props.clear();
                props.setProperty("sampleid", sharesample);
                try {
                    getActionProcessor().processAction("IHCFlowCompleteStep", "1", props);
                } catch (Exception ex) {
                    throw new SapphireException("Unable to route share h&e." + ex.getMessage());
                }
                msg += props.getProperty("msg");
            }

        }
        properties.setProperty("msg", msg);
    }
}
