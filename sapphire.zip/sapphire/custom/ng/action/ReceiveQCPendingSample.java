package sapphire.custom.ng.action;

import java.util.ArrayList;
import java.util.HashMap;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDI;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.action.EditTrackItem;
import sapphire.custom.ng.action.util.MannualSampleRouting;
import sapphire.custom.ng.action.util.NGSendMail;
import sapphire.custom.ng.action.util.PrintLabel;
import sapphire.custom.ng.sql.ap.ApSql;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/*  Created By Subhendu 3 Apr 2017 - For Sample Receive Logic - Same code is copied from Generate Accession Action
 *  with only exception that label will not be printed when this action will be performed */

public class ReceiveQCPendingSample extends BaseAction {

    String message = "Operation Successful.";

    public void processAction(PropertyList properties) throws SapphireException {
        String sampleIds = properties.getProperty("sampleid", "");
        String overridedefaultrouting = properties.getProperty("overridedefaultrouting", "N");
        String destDept = properties.getProperty("destdept", "");
        if ("Y".equalsIgnoreCase(overridedefaultrouting) && Util.isNull(destDept))
            throw new SapphireException("Please provide the destination department.");
        String sampleForLabel = "";
        HashMap<String, String> hm = new HashMap<String, String>();
        if (sampleIds.equalsIgnoreCase("")) {
            throw new SapphireException("Sample Id is blank");
        }

       /* String sql = "select s.s_sampleid,s.sampletypeid,t.containertypeid, s.u_previousmovementstep, s.u_previoustramstop,s.u_previouscustodialdept, " +
                " sc.u_movementstep,sc.u_methodology,sc.u_los, sc.u_nextmovementstep,"
                + " s.u_performingsite,stm.methodology testmethodology, stm.los, "
                + " case when sc.u_methodology is null then 'NA' when stm.methodology = sc.u_methodology then 'true' else 'false' end as methodologyresult, "
                + " case when sc.u_los is null then 'NA' when stm.los = sc.u_los then 'true' else 'false' end as losresult" +
                " from s_sample s,trackitem t,s_sampletypecontainertype sc, u_sampletestcodemap stm  " +
                " where s.s_sampleid=t.linkkeyid1 and s.s_sampleid in('" + StringUtil.replaceAll(sampleIds, ";", "','") + "') and s.s_sampleid = stm.s_sampleid(+) " +
                " and sc.s_sampletypeid (+)=s.sampletypeid and sc.containertypeid (+)=t.containertypeid and s.u_isshipedsampleqcpending = 'Y'";*/
        String sql = Util.parseMessage(CommonSql.GET_SAMPLE_DETAILS, StringUtil.replaceAll(sampleIds, ";", "','"));

        DataSet dsMove = getQueryProcessor().getSqlDataSet(sql);
        if (dsMove == null) {
            String err = getTranslationProcessor().translate("Contact you Administrator. SQL failed:");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, err);
        }
        if (dsMove.size() == 0) {
            String errmsg = getTranslationProcessor().translate("Steps is not defined in master data. SQL failed:");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errmsg);
        }

//        sql = Util.parseMessage(ApSql.GET_SITE_BY_DEPARTMENT, connectionInfo.getDefaultDepartment());
//        DataSet dsDefaultSiteInfo = getQueryProcessor().getSqlDataSet(sql);
//        if (dsDefaultSiteInfo == null)
//            throw new SapphireException("The below query cannot be executed.\n" + sql);
//        if (dsDefaultSiteInfo.size() == 0)
//            throw new SapphireException("Current logged in department doesn't have site info.");
//        String defaultSite = dsDefaultSiteInfo.getValue(0, "u_site", "");

        DataSet dsMoveFinal = new DataSet();
        dsMoveFinal.addColumn("sampleid", DataSet.STRING);
        dsMoveFinal.addColumn("u_movementstep", DataSet.STRING);
        dsMoveFinal.addColumn("newmovement", DataSet.STRING);
        dsMoveFinal.addColumn("currentmovementstep", DataSet.STRING);
        dsMoveFinal.addColumn("normalroute", DataSet.STRING);
        dsMoveFinal.addColumn("u_accessioningcomplete", DataSet.STRING);

			 /* Change By Subhendu for Performing Site in Sample 4th Mar 2017 + */
        dsMoveFinal.addColumn("previouscustodialdept", DataSet.STRING);
        dsMoveFinal.addColumn("previousmovementstep", DataSet.STRING);
        dsMoveFinal.addColumn("performingsite", DataSet.STRING);

        String uniqueSampleId = Util.getUniqueList(dsMove.getColumnValues("s_sampleid", ";"), ";", true);
        String[] tempUniqueSampleId = uniqueSampleId.split(";");
        String nxtMovementStep = "";
        String u_accessioningcomplete = "";
//			String nxtTramStop = "";

        for (int i = 0; i < tempUniqueSampleId.length; i++) {
            int row = dsMoveFinal.addRow();
            dsMoveFinal.setValue(row, "sampleid", dsMove.getValue(i, "s_sampleid"));
            dsMoveFinal.setValue(row, "u_movementstep", dsMove.getValue(i, "u_movementstep"));
            dsMoveFinal.setValue(row, "performingsite", dsMove.getValue(i, "u_performingsite"));
            dsMoveFinal.setValue(row, "previousmovementstep", dsMove.getValue(i, "u_previousmovementstep"));
            dsMoveFinal.setValue(row, "previouscustodialdept", dsMove.getValue(i, "u_previouscustodialdept"));
            hm.clear();
            hm.put("s_sampleid", tempUniqueSampleId[i]);
            DataSet filterDS = dsMove.getFilteredDataSet(hm);

            if ("Y".equalsIgnoreCase(overridedefaultrouting)) {
                dsMoveFinal.setValue(row, "normalroute", "N");
                dsMoveFinal.setValue(row, "u_accessioningcomplete", "Y");
            } else {
                for (int j = 0; j < filterDS.size(); j++) {
                    if (!Util.isNull(filterDS.getValue(j, "u_performingsite")) && !Util.isNull(filterDS.getValue(j, "u_previousmovementstep"))) {
                        nxtMovementStep = filterDS.getValue(j, "u_previousmovementstep");
                        u_accessioningcomplete = "Y";
                        break;
                    } else if ("true".equalsIgnoreCase(filterDS.getValue(j, "methodologyresult"))
                            && ("true".equalsIgnoreCase(filterDS.getValue(j, "losresult")) || "NA".equalsIgnoreCase(filterDS.getValue(j, "losresult")))) {
                        nxtMovementStep = filterDS.getValue(j, "u_nextmovementstep");
                        u_accessioningcomplete = "Y";
                        break;
                    } else if ("true".equalsIgnoreCase(filterDS.getValue(j, "methodologyresult")) && "NA".equalsIgnoreCase(filterDS.getValue(j, "losresult"))) {
                        nxtMovementStep = filterDS.getValue(j, "u_nextmovementstep");
                        u_accessioningcomplete = "Y";
                        break;
                    }
                    /*****INCORPORATE MOLECULAR EMBEDDING WORKFLOW FOR 1.7.1 RELEASE ****/
                    else if ("Embedding".equalsIgnoreCase(filterDS.getValue(j, "u_movementstep")) && "NA".equalsIgnoreCase(filterDS.getValue(j, "methodologyresult"))
                            && "NA".equalsIgnoreCase(filterDS.getValue(j, "losresult")) &&
                            "Molecular".equalsIgnoreCase(filterDS.getValue(j, "testmethodology")) && ("H".equalsIgnoreCase(filterDS.getValue(j, "u_type"))
                            || "CH".equalsIgnoreCase(filterDS.getValue(j, "u_type")) || "U".equalsIgnoreCase(filterDS.getValue(j, "u_type"))
                            || "CU".equalsIgnoreCase(filterDS.getValue(j, "u_type")))) {
                        nxtMovementStep = "Microtomy";
                        u_accessioningcomplete = "";
                        break;
                    } else if ("Molecular".equalsIgnoreCase(filterDS.getValue(j, "testmethodology")) && "EB".equalsIgnoreCase(filterDS.getValue(j, "u_type"))) {
                        nxtMovementStep = filterDS.getValue(j, "u_previousmovementstep");
                        u_accessioningcomplete = "Y";
                    } else {
                        nxtMovementStep = filterDS.getValue(j, "u_movementstep");
                        u_accessioningcomplete = "Y";
                    }
                }
                dsMoveFinal.setValue(row, "newmovement", nxtMovementStep);
                dsMoveFinal.setValue(row, "normalroute", "Y");
                dsMoveFinal.setValue(row, "u_accessioningcomplete", u_accessioningcomplete);
            }

        }
            /* Change By Subhendu for Performing Site in Sample 4th Mar 2017 - */
        /*********************SAMPLE ROUTING FOR Esophageal Brushing,Unstained Slide(s),IHC***************************/
            /*IF ( Sample is having sampletype = Esophageal Brushing and Containertype= Unstained Slide(s)
                    and testcode methodology is only IHC ) THEN
	        Route the sample to Histo-Setup
	        ELSE
	        Route the sample to Fresh Prep*/
        hm.clear();
        hm.put("sampletypeid", "Esophageal Brushing");
        hm.put("containertypeid", "Unstained Slide(s)");
//	        hm.put("u_performingsite", null);

        DataSet dsFilter = dsMove.getFilteredDataSet(hm);
        if (dsFilter != null && dsFilter.size() > 0) {
            sql = "select distinct stm.methodology t_methodology,s.s_sampleid,s.sampletypeid,t.containertypeid,sc.u_movementstep,sc.u_methodology,sc.u_los,sc.u_nextmovementstep" +
                    " from s_sample s,trackitem t,s_sampletypecontainertype sc,u_accession ac, u_sampletestcodemap stm" +
                    " where s.u_accessionid=ac.u_accessionid and" +
                    " s.s_sampleid=t.linkkeyid1" +
                    " and s.s_sampleid in('" + StringUtil.replaceAll(dsFilter.getColumnValues("s_sampleid", ";"), ";", "','") + "')" +
                    " and sc.s_sampletypeid=s.sampletypeid" +
                    " and stm.s_sampleid=s.s_sampleid" +
                    " and sc.containertypeid=t.containertypeid and s.u_accessioningcomplete='N'";
            DataSet dsResults = getQueryProcessor().getSqlDataSet(sql);
            for (int i = 0; i < dsResults.size(); i++) {
                String nextmovementstep = dsResults.getValue(i, "u_nextmovementstep", "");
                String los = dsResults.getValue(i, "u_los", "");
                String sc_methodology = dsResults.getValue(i, "u_methodology", "");
                String t_methodology = dsResults.getValue(i, "t_methodology", "");
                String sampleid = dsResults.getValue(i, "s_sampleid", "");
                String movementstep = dsResults.getValue(i, "u_movementstep", "");

                //FILTERED SAMPLE FROM u_movementstep
                for (int j = 0; j < dsMoveFinal.size(); j++) {
                    if (sampleid.equalsIgnoreCase(dsMoveFinal.getValue(j, "sampleid", ""))) {
                        if ((!Util.isNull(nextmovementstep) && !Util.isNull(sc_methodology)) &&
                                t_methodology.equalsIgnoreCase(sc_methodology)) {
                            dsMoveFinal.setValue(j, "newmovement", nextmovementstep);
                        } else {
                            dsMoveFinal.setValue(j, "newmovement", movementstep);
                        }
                    }
                }
            }
        }
        //CHECK TEST CODE ASSOCIATE WITH SAMPLE OR NOT
        String sampleWOTocdes = "";
//	        sql = "select s.s_sampleid,ac.u_accessionid from s_sample s, u_accession ac where" +
//	                " s.u_accessionid = ac.u_accessionid and" +
//	                " s.u_accessionid='" + accessionid + "' and s.u_accessioningcomplete='N'";

        sql = "select s_sampleid,u_accessionid from s_sample "
                + " where s_sampleid in('" + StringUtil.replaceAll(sampleIds, ";", "','") + "') and u_isshipedsampleqcpending = 'Y'";

        DataSet dsAllSamplesByAccession = getQueryProcessor().getSqlDataSet(sql);
//	        sql = "select distinct stm.methodology t_methodology,s.s_sampleid,s.sampletypeid,t.containertypeid,sc.u_movementstep,stm.methodology,stm.los,sc.u_nextmovementstep" +
//	                " from s_sample s,trackitem t,s_sampletypecontainertype sc,u_accession ac, u_sampletestcodemap stm" +
//	                " where s.u_accessionid=ac.u_accessionid and" +
//	                " s.s_sampleid=t.linkkeyid1" +
//	                " and s.u_accessionid in('" + accessionid + "')" +
//	                " and sc.s_sampletypeid=s.sampletypeid" +
//	                " and stm.s_sampleid=s.s_sampleid" +
//	                " and sc.containertypeid=t.containertypeid and s.u_accessioningcomplete='N'";

        sql = "select  stm.methodology t_methodology,s.s_sampleid,s.sampletypeid,t.containertypeid,sc.u_movementstep,stm.methodology,stm.los,sc.u_nextmovementstep "
                + "from s_sample s,trackitem t,s_sampletypecontainertype sc, u_sampletestcodemap stm "
                + "where s.s_sampleid=t.linkkeyid1 and s.s_sampleid in('" + StringUtil.replaceAll(sampleIds, ";", "','") + "')"
                + "and sc.s_sampletypeid=s.sampletypeid and stm.s_sampleid=s.s_sampleid and "
                + "sc.containertypeid=t.containertypeid and s.u_isshipedsampleqcpending='Y'";


        DataSet dsTestCodeMap = getQueryProcessor().getSqlDataSet(sql);
        for (int i = 0; i < dsAllSamplesByAccession.size(); i++) {
            String sampleidWOTcode = dsAllSamplesByAccession.getValue(i, "s_sampleid", "");
            //CHECK REST SAMPLES WHICH HAVE NO TESTCODE(S) ASSOCIATE
            hm.clear();
            hm.put("s_sampleid", sampleidWOTcode);
            DataSet dsFilterRest = dsTestCodeMap.getFilteredDataSet(hm);
            if (dsFilterRest.size() == 0) {
                sampleWOTocdes += ";" + dsAllSamplesByAccession.getValue(i, "s_sampleid", "");
            }
        }

        /***** Set first step for Consult ****/
        hm.clear();
        hm.put("methodology", "IHC");
        hm.put("los", "Consult");
//	        hm.put("u_performingsite", null);
        DataSet dsFilterConsult = dsTestCodeMap.getFilteredDataSet(hm);
        if (dsFilterConsult != null && dsFilterConsult.size() > 0) {
            String allConsultSampleToProcess = Util.getUniqueList(dsFilterConsult.getColumnValues("s_sampleid", ";"), ";", true);
            //String allConsultSampleArray[] =StringUtil.split(allConsultSample,";");
            for (int h = 0; h < dsMoveFinal.getRowCount(); h++) {
                if (allConsultSampleToProcess.contains(dsMoveFinal.getValue(h, "sampleid", ""))) {
                    dsMoveFinal.setValue(h, "newmovement", "PathSupport");
                }
            }
        }


        if (!Util.isNull(sampleWOTocdes)) {
            sampleWOTocdes = sampleWOTocdes.substring(1);
            message += "\nBelow sample(s) have no testcode(s): " + StringUtil.replaceAll(sampleWOTocdes, ";", ",");

        }
        properties.setProperty("msg", message);
        /************************************************************************************************************/

        if (dsMoveFinal == null) {
            throw new SapphireException("DataSet containing Sample information is null");
        }
        if (dsMoveFinal.size() == 0) {
            throw new SapphireException("Sample movement step is not defined in master data");
        }


        try {
            HashMap<String, String> hmap = new HashMap<String, String>();
            hmap.clear();
            hmap.put("normalroute", "Y");
            DataSet dsMoveFinalNormalRoute = dsMoveFinal.getFilteredDataSet(hmap);
            PropertyList prop = new PropertyList();
            if (dsMoveFinalNormalRoute != null && dsMoveFinalNormalRoute.size() > 0) {
                prop.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                prop.setProperty(EditSDI.PROPERTY_KEYID1, dsMoveFinalNormalRoute.getColumnValues("sampleid", ";"));
                prop.setProperty("u_currentmovementstep", dsMoveFinalNormalRoute.getColumnValues("newmovement", ";"));
                //prop.setProperty("u_accessioningcomplete", "Y");
                prop.setProperty("u_accessioningcomplete", dsMoveFinalNormalRoute.getColumnValues("u_accessioningcomplete", ";"));
                prop.setProperty("u_isshipedsampleqcpending", "N");
                prop.setProperty("u_previousmovementstep", "(null)");
                prop.setProperty("u_previoustramstop", "(null)");
                prop.setProperty("u_previouscustodialdept", "(null)");
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, prop);
                //createSampleMovementSteps(dsMoveFinal);
                DataSet dsCurrntMove = getCurrentMovementStep(dsMoveFinalNormalRoute);
                updateTrackItem(dsCurrntMove);
            }
            hmap.clear();
            hmap.put("normalroute", "N");
            DataSet dsInternalDeptRoute = dsMoveFinal.getFilteredDataSet(hmap);
            if (dsInternalDeptRoute != null && dsInternalDeptRoute.size() > 0) {
                prop.clear();
                prop.setProperty(MannualSampleRouting.PROPERTY_SAMPLEID, dsInternalDeptRoute.getColumnValues("sampleid", ";"));
                prop.setProperty(MannualSampleRouting.PROPERTY_DEPARTMENTID, StringUtil.repeat(destDept, dsInternalDeptRoute.size(), ";"));
                prop.setProperty(MannualSampleRouting.PROPERTY_SAMPLE_COL_TO_BE_MODIFIED, "u_accessioningcomplete,u_isshipedsampleqcpending,u_previousmovementstep,u_previoustramstop,u_previouscustodialdept");
                //prop.setProperty("u_accessioningcomplete", StringUtil.repeat("Y", dsInternalDeptRoute.size(), ";"));
                prop.setProperty("u_accessioningcomplete", dsInternalDeptRoute.getColumnValues("u_accessioningcomplete", ";"));
                prop.setProperty("u_isshipedsampleqcpending", StringUtil.repeat("N", dsInternalDeptRoute.size(), ";"));
                prop.setProperty("u_previousmovementstep", StringUtil.repeat("(null)", dsInternalDeptRoute.size(), ";"));
                prop.setProperty("u_previoustramstop", StringUtil.repeat("(null)", dsInternalDeptRoute.size(), ";"));
                prop.setProperty("u_previouscustodialdept", StringUtil.repeat("(null)", dsInternalDeptRoute.size(), ";"));
                getActionProcessor().processAction("MannualSampleRouting", "1", prop);
            }
//	            sampleForLabel = dsMoveFinal.getColumnValues("sampleid", ";");
            //printNGLabel(sampleForLabel); //ToDO List for Generate Print Label
//	            labelPrint(sampleForLabel);
            sendEmailNotificationForBioPharma(dsMoveFinal.getColumnValues("sampleid", ";"));
        } catch (SapphireException ex) {
            throw ex;
        }
        //throw new SapphireException("test");
    }

    private void sendEmailNotificationForBioPharma(String sampleid) throws SapphireException {
        // method for email notification whenever user generating the accession for bio pharma.

        if (!Util.isNull(sampleid)) {
            PropertyList prop = new PropertyList();
            String sql = Util.parseMessage(CommonSql.PROJECT_EMAIL, StringUtil.replaceAll(sampleid, ";", "','"));
            DataSet ds = getQueryProcessor().getSqlDataSet(sql);
            String toList = "";
                /* Code Block for Project having email at project level   ++*/
            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("projtype", "Email");
                            hmap.put("projevent", "Accession Notification");
                            DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);

                            toList = tempDsFiltr.getColumnValues("emailorsftp", ";");
                            if (!Util.isNull(toList)) {
                                toList = Util.getUniqueList(toList, ";", true);
                                String sponcerName = tempDsFiltr.getColumnValues("sponcername", ";");
                                if (!Util.isNull(sponcerName))
                                    sponcerName = Util.getUniqueList(sponcerName, ";", true);

                                if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Non-Clinical"))
                                    prop.setProperty(NGSendMail.NODE_ID, "ProjectAccessionMail");
                                else if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Clinical")) {
                                    prop.setProperty(NGSendMail.NODE_ID, "ClinicalAccession");
                                    prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                                    prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_biopharmasubjectid", ";"), ";", true));
                                }

                                prop.setProperty(NGSendMail.MODE, "SendMail");
                                prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
                                prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectprotocolid", ";"), ";", true));
                                prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                            }
                        }
                    }
                }
            }

				/* Code Block for Project having email at project level   --*/
                /* Code Block for Project having email at Investigator level  ++*/
            sql = Util.parseMessage(CommonSql.INVESTIGATOR_QC_PENDING_LEVEL_EMAIL, StringUtil.replaceAll(sampleid, ";", "','"));
            ds = getQueryProcessor().getSqlDataSet(sql);

            if (ds != null && ds.size() != 0) {
                ArrayList<DataSet> dsArr = ds.getGroupedDataSets("u_accessionid");
                HashMap<String, String> hmap = new HashMap<>();
                if (dsArr != null && dsArr.size() > 0) {
                    for (int i = 0; i < dsArr.size(); i++) {
                        DataSet tempDs = dsArr.get(i);
                        hmap.clear();
                        if (tempDs != null && tempDs.size() > 0) {
                            hmap.put("type", "Email");
                            hmap.put("event", "Accession Notification");
                            DataSet tempDsFiltr = tempDs.getFilteredDataSet(hmap);
                            if (tempDsFiltr != null && tempDsFiltr.size() > 0) {
                                toList = tempDsFiltr.getColumnValues("email", ";") + ";" + toList;
                                if (!Util.isNull(toList)) {
                                    toList = Util.getUniqueList(toList, ";", true);
                                    String invistigatoName = tempDsFiltr.getColumnValues("invesitagtorname", ";");
                                    if (!Util.isNull(invistigatoName))
                                        invistigatoName = Util.getUniqueList(invistigatoName, ";", true);

                                    String sponcerName = tempDsFiltr.getColumnValues("sponcername", ";");
                                    if (!Util.isNull(sponcerName))
                                        sponcerName = Util.getUniqueList(sponcerName, ";", true);


                                    if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Non-Clinical")) {
                                        prop.setProperty(NGSendMail.NODE_ID, "ProjectAccessionMail");
                                        prop.setProperty(NGSendMail.SPONCER_NAME, StringUtil.replaceAll(sponcerName, ";", "/"));
                                    } else if (tempDsFiltr.getValue(0, "emailtemplate", "").equalsIgnoreCase("Clinical"))
                                        prop.setProperty(NGSendMail.NODE_ID, "Accession");

                                    prop.setProperty(NGSendMail.MODE, "SendMail");
                                    prop.setProperty(NGSendMail.SAMPLEID, Util.getUniqueList(tempDsFiltr.getColumnValues("s_sampleid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.ACCESSIONID, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.KEYID1, Util.getUniqueList(tempDsFiltr.getColumnValues("u_accessionid", "','"), ";", true));
                                    prop.setProperty(NGSendMail.INVESTIGATOR_SITE_ID, Util.getUniqueList(tempDsFiltr.getColumnValues("sitename", ";"), ";", true));
                                    prop.setProperty(NGSendMail.INVESTIGATOR_NAME, StringUtil.replaceAll(invistigatoName, ";", "/"));
                                    prop.setProperty(NGSendMail.PROJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("projectid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.SUBJECTID, Util.getUniqueList(tempDsFiltr.getColumnValues("patientid", ";"), ";", true));
                                    prop.setProperty(NGSendMail.EMAILTOLIST, toList.trim());
                                }
                            }
                        }
                    }
                }
            }
                /* Code Block for Project having email at Investigator level  --*/
            if (toList != null && !"".equals(toList)) {
                prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, NGSendMail.ID);
                prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, NGSendMail.VERSIONID);
                prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
                prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");
                getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);
            }
        }
    }


    /**
     * Not Required. As per current requirement direct insert not necessary on SampleMovementSteps
     *
     * @param dsMoveFinal :Contains Samples ,currentmovementstep and new movementstep
     * @throws SapphireException
     * @desc: This method sets the completedstep as 'AccessioningCompleted' and also sets
     * completedby and completed date after Generate Accession is completed
     */
    private void createSampleMovementSteps(DataSet dsMoveFinal) throws SapphireException {
        String currentuser = connectionInfo.getSysuserId();
        String sample = dsMoveFinal.getColumnValues("sampleid", ";");
        String sampleid[] = StringUtil.split(sample, ";");
        int copies = sampleid.length;
        PropertyList prop1 = new PropertyList();
        prop1.setProperty(AddSDI.PROPERTY_SDCID, "SampleMovementSteps");
        prop1.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(copies));
        prop1.setProperty("sampleid", sample);
        prop1.setProperty("completedstep", "AccessioningCompleted");
        prop1.setProperty("completedby", currentuser);
        prop1.setProperty("completeddt", "n");

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, prop1);
    }

    private DataSet getCurrentMovementStep(DataSet dsMoveFinal) throws SapphireException {
        String sql = "select s_sampleid,u_currentmovementstep,u_performingsite from s_sample where s_sampleid in('" + StringUtil.replaceAll(dsMoveFinal.getColumnValues("sampleid", ";"), ";", "','") + "')";
        DataSet dsCurrentMovement = getQueryProcessor().getSqlDataSet(sql);
        if (dsCurrentMovement == null) {
            String errMsg = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator.");
            errMsg += "\nQuery returns null, Query failed:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
        if (dsCurrentMovement.size() == 0) {
            String errMsg = getTranslationProcessor().translate("Sample id not found");
            errMsg += "\nQuery retuns no rows:" + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errMsg);
        }
        HashMap<String, String> hm = new HashMap<String, String>();
        for (int i = 0; i < dsMoveFinal.size(); i++) {
            String sample = dsMoveFinal.getValue(i, "sampleid", "");
            hm.clear();
            hm.put("s_sampleid", sample);
//	            hm.put("u_performingsite", null);
            DataSet dsFilter = dsCurrentMovement.getFilteredDataSet(hm);
            String currentmovementstep = dsFilter.getValue(0, "u_currentmovementstep");
                /*if (Util.isNull(currentmovementstep)) {
                    String errMsg = getTranslationProcessor().translate("Currentmovementstep not found in for sample id:" + sample);
	                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
	            }*/
            dsMoveFinal.setValue(i, "currentmovementstep", currentmovementstep);
        }
        return dsMoveFinal;
    }

    private void updateTrackItem(DataSet dsMoveFinal) throws SapphireException {
        String defaultdepartment = connectionInfo.getDefaultDepartment();
        String site = defaultdepartment.substring(0, defaultdepartment.indexOf("-"));

        dsMoveFinal.addColumn("custodialdepartmentid", DataSet.STRING);
        for (int i = 0; i < dsMoveFinal.size(); i++) {
            String currentmovementstep = dsMoveFinal.getValue(i, "currentmovementstep");

            if (!"".equals(dsMoveFinal.getValue(i, "previousmovementstep", ""))) {
                String transferDepartment = dsMoveFinal.getValue(i, "previouscustodialdept", "").split("-")[1];
                String destDeptCheck = site + "-" + transferDepartment;
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            } else if ("fresh prep".equalsIgnoreCase(currentmovementstep) || "freshprep".equalsIgnoreCase(currentmovementstep)) {
                String destDeptCheck = site + "-Fresh Prep";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            } else {
                String destDeptCheck = site + "-AP";
                deptValidate(destDeptCheck);
                dsMoveFinal.setValue(i, "custodialdepartmentid", destDeptCheck);
            }
        }
        PropertyList editTIProps = new PropertyList();
        editTIProps.setProperty(EditTrackItem.PROPERTY_SDCID, "Sample");
        editTIProps.setProperty(EditTrackItem.PROPERTY_KEYID1, dsMoveFinal.getColumnValues("sampleid", ";"));
        editTIProps.setProperty("u_currenttramstop", dsMoveFinal.getColumnValues("currentmovementstep", ";"));
        editTIProps.setProperty("custodialuserid", StringUtil.repeat("(null)", dsMoveFinal.size(), ";"));
        editTIProps.setProperty("custodialdepartmentid", dsMoveFinal.getColumnValues("custodialdepartmentid", ";"));
        try {
            getActionProcessor().processAction(EditTrackItem.ID, EditTrackItem.VERSIONID, editTIProps);
        } catch (ActionException ae) {
            String error = getTranslationProcessor().translate("Error in edit track item.");
            error += ae.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
//			throw new SapphireException(ErrorDetail.TYPE_VALIDATION, "error");
    }

    /**
     * Description: This method is used for generating print label of the samples during 'Generate Accession'.
     * It will take all the samples as an input and
     * call PrintLabel action to print the label of the input samples.
     *
     * @param sampleForLabel
     * @throws SapphireException
     */
    private void labelPrint(String sampleForLabel) throws SapphireException {
        PropertyList props = new PropertyList();
        props.setProperty(PrintLabel.SDCID_PROP, "Sample");
        props.setProperty(PrintLabel.KEYID1_PROP, sampleForLabel);
        props.setProperty(PrintLabel.LABELTYPE_PROP, "Accession");
        try {
            getActionProcessor().processAction("PrintLabel", PrintLabel.VERSION, props);
        } catch (SapphireException e) {
            String errMsg = getTranslationProcessor().translate("Unable To Print Label");
            errMsg += "\nError Detail:" + e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMsg);
        }
    }

    /**
     * Description : This method will check department is valid or not.
     *
     * @param destinationDepartment
     * @return
     * @throws SapphireException
     */
    private void deptValidate(String destinationDepartment) throws SapphireException {
        // destinationDepartment = destinationDepartment.substring(0, destinationDepartment.length() - 1);
        String department = "";
        String dept = "select departmentid from department where departmentid='" + destinationDepartment + "'";
        DataSet dsdept = getQueryProcessor().getSqlDataSet(dept);
        if (dsdept == null) {
            String errStr = getTranslationProcessor().translate("Something wrong happened. Contact your Administrator");
            errStr += "\n Query failed: " + dept;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        if (dsdept.size() == 0) {
            String errStr = getTranslationProcessor().translate(destinationDepartment + " is not valid destination Department.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        } else {
            department = dsdept.getValue(0, "departmentid");
            if (Util.isNull(department)) {
                String errStr = getTranslationProcessor().translate("Destination Department can't be null.Please contact your Administrator. ");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
            }
        }

    }

}
