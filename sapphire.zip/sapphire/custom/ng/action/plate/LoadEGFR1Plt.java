package sapphire.custom.ng.action.plate;

import sapphire.SapphireException;
import sapphire.action.AddArrayContent;
import sapphire.action.BaseAction;
import sapphire.action.CreateArray;
import sapphire.action.EditSDI;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;
/**
 * NOT IN USE ; NOMINATED FOR DELETION..
 */

/**
 * Created by rrmandal on 5/24/2016.
 */
public class LoadEGFR1Plt extends BaseAction {

    private static final String SAMPLE_PROP = "sample";
    private static final String ARRAYMETHODS_VAL[] = {"EGFR11","EGFR12","EGFR13"};
    private static final String ARRAYLAYOUTS_VAL[] = {"EGFR11","EGFR12","EGFR13"};
    private static final String ARRAYMETHODVERSION_VAL[] = {"1","1","1"};
    private static final String ARRAYLAYOUTVERSION_VAL[] = {"1","1","1"};

    //@Override
    /*public void processAction(PropertyList properties) throws SapphireException {
        *//*String samples = properties.getProperty(SAMPLE_PROP,"");
        if(Util.isNull(samples)){
            throw new SapphireException("Samples cannot be found.Please select at least one sample");
        }
        String newArrays = createArray();
        if(Util.isNull(newArrays))
            throw new SapphireException("Arrays cannot not be created");

        lodintoArray(samples,newArrays);

        String newArraysArr[]= StringUtil.split(newArrays,";",true);
        if(newArraysArr!=null && newArraysArr.length>0){
            String url = "rc?command=page&page=LV_ArrayList&keyid1="+newArrays;
            String msg = "<a href=\"javascript:sapphire.page.navigate('"+url+"','Y','_top',null)\">"+newArraysArr.length+"</a>";
            properties.setProperty("msg",msg);
        }*//*

    }*/


    /**
     * This method creates one plate for each arraymethod specified in the global array ARRAYMETHODS_VAL
     * and returns the newly created arrayids.
     * @return
     */

   /* private String createArray(){
        String newArrays = "";
        PropertyList plCrtArr = new PropertyList();
        try {
*//**
 * In below logic CreateArray action is being executed in a loop because CreateArray action does not support multiple inputs
  *//*
            for (int i = 0; i < ARRAYMETHODS_VAL.length; i++) {
                plCrtArr.clear();
                plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYMETHODID, ARRAYMETHODS_VAL[i]);
                plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYMETHODVERSIONID, ARRAYMETHODVERSION_VAL[i]);
                plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYLAYOUTID, ARRAYLAYOUTS_VAL[i]);
                plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYLAYOUTVERSIONID, ARRAYLAYOUTVERSION_VAL[i]);
                plCrtArr.setProperty(CreateArray.PROPERTY_COPIES, "1");
                getActionProcessor().processAction(CreateArray.ID, CreateArray.VERSIONID, plCrtArr);
                newArrays+=";"+plCrtArr.getProperty(CreateArray.RETURN_ARRAYID,"");
            }
        }
        catch (Exception e){
            logger.debug(e.getMessage());
        }
        if(!Util.isNull(newArrays)){
            if(newArrays.startsWith(";"))
                newArrays = newArrays.substring(1);
        }
        return newArrays;
    }*/


    /**
     * This method loads same samples to the arrays corresponding to each defined zone.
     * @param samples
     * @param arrays
     * @throws SapphireException
     */

    /*private void lodintoArray(String samples,String arrays) throws SapphireException{
        if(!Util.isNull(arrays) && !Util.isNull(samples)){
            String sql = "select a.arrayid,a.arrayitemid,c.zone " +
                    "from arrayitem a,arrayitemarrayzone b,arrayzone c " +
                    "where a.arrayitemid=b.arrayitemid and b.arrayzoneid=c.arrayzoneid and a.arrayid=c.arrayid and a.arrayid in('"+StringUtil.replaceAll(arrays,";","','")+"') " +
                    "and c.zone !='(FullArray)' ";
            DataSet dsArrItmInfo = getQueryProcessor().getSqlDataSet(sql);
            DataSet result = null;
            if(dsArrItmInfo!=null && dsArrItmInfo.size()>0){
                HashMap<String,String> hmap = new HashMap<String,String>();
                String arrsArr[] = StringUtil.split(arrays,";",true);
                if(arrsArr!=null && arrsArr.length>0) {
                    String sampleArr[] = StringUtil.split(samples,";");
                    if(sampleArr!=null && sampleArr.length>0) {
                        result = new DataSet();
                        result.addColumn(AddArrayContent.PROPERTY_ARRAYID, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_ARRAYITEMID, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_CONTENTSDCID, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_CONTENTKEYID1, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_CONTENTLABEL, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_VOLUME, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_VOLUMEUNITS, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_CONTENTITEM, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_CONCENTRATION, DataSet.STRING);
                        result.addColumn(AddArrayContent.PROPERTY_CONCENTRATIONUNITS, DataSet.STRING);
                        for (int i = 0; i < arrsArr.length; i++) {
                            String arrayId = arrsArr[i];
                            hmap.clear();
                            hmap.put("arrayid", arrayId);
                            DataSet dsArrItmInfoByArr = dsArrItmInfo.getFilteredDataSet(hmap);
                            if (dsArrItmInfoByArr != null && dsArrItmInfoByArr.size() > 0) {
                                dsArrItmInfoByArr.sort("zone");
                                ArrayList<DataSet> dsPerZoneInfo = dsArrItmInfoByArr.getGroupedDataSets("zone");
                                if (dsPerZoneInfo != null && dsPerZoneInfo.size() > 0) {
                                    for (int j = 0; j < dsPerZoneInfo.size(); j++) {
                                        DataSet dsPltPerZone = dsPerZoneInfo.get(j);
                                        if (dsPltPerZone != null && dsPltPerZone.size() > 0) {
                                            //dsPltPerZone.sort("arrayitemid");
                                            String zone = dsPltPerZone.getValue(0, "zone", "");
                                            if (!"Positive Control".equalsIgnoreCase(zone)) {
                                                int sampleIndex = 0;
                                                for (int k = 0; k < dsPltPerZone.size(); k++) {
                                                    int index = result.addRow();
                                                    result.setValue(index, AddArrayContent.PROPERTY_ARRAYID, arrayId);
                                                    result.setValue(index, AddArrayContent.PROPERTY_ARRAYITEMID, dsPltPerZone.getValue(k, "arrayitemid", ""));
                                                    result.setValue(index, AddArrayContent.PROPERTY_CONTENTSDCID, "Sample");
                                                    try {
                                                        result.setValue(index, AddArrayContent.PROPERTY_CONTENTKEYID1, sampleArr[sampleIndex]);
                                                        result.setValue(index, AddArrayContent.PROPERTY_CONTENTLABEL, sampleArr[sampleIndex++]);
                                                    }
                                                    catch (ArrayIndexOutOfBoundsException exp){
                                                        throw new SapphireException("Number of sample selected is not matching with the number of wells for the zone "+zone+" " +
                                                                "corresponding to the plate "+arrayId);
                                                    }
                                                    result.setValue(index, AddArrayContent.PROPERTY_VOLUME, "1");
                                                    result.setValue(index, AddArrayContent.PROPERTY_CONCENTRATION, "1");
                                                    result.setValue(index, AddArrayContent.PROPERTY_VOLUMEUNITS, "ul");
                                                    result.setValue(index, AddArrayContent.PROPERTY_CONCENTRATIONUNITS, "ul");
                                                    result.setValue(index, AddArrayContent.PROPERTY_CONTENTITEM, "Unknown");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(result!=null && result.size()>0){
                        PropertyList pl = new PropertyList();
                        pl.setProperty( AddArrayContent.PROPERTY_ARRAYID, result.getColumnValues(AddArrayContent.PROPERTY_ARRAYID,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_ARRAYITEMID, result.getColumnValues(AddArrayContent.PROPERTY_ARRAYITEMID,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_CONTENTSDCID, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTSDCID,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_CONTENTKEYID1, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTKEYID1,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_CONTENTLABEL, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTLABEL,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_VOLUME, result.getColumnValues(AddArrayContent.PROPERTY_VOLUME,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_VOLUMEUNITS, result.getColumnValues(AddArrayContent.PROPERTY_VOLUMEUNITS,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_CONTENTITEM, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTITEM,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_CONCENTRATION, result.getColumnValues(AddArrayContent.PROPERTY_CONCENTRATION,";") );
                        pl.setProperty( AddArrayContent.PROPERTY_CONCENTRATIONUNITS, result.getColumnValues(AddArrayContent.PROPERTY_CONCENTRATIONUNITS,";") );
                        getActionProcessor().processAction( AddArrayContent.ID, AddArrayContent.VERSIONID, pl );

                        PropertyList plEditSDI = new PropertyList();
                        plEditSDI.setProperty( EditSDI.PROPERTY_SDCID, "LV_Array" );
                        plEditSDI.setProperty( EditSDI.PROPERTY_KEYID1, arrays );
                        plEditSDI.setProperty( "arraystatus", "Loaded" );
                        getActionProcessor().processAction( EditSDI.ID, EditSDI.VERSIONID, plEditSDI );
                    }
                }
                else{
                    logger.debug("******************************************* DEBUG MESSAGE FROM lodintoArray METHOD*******************************************");
                    logger.debug("arrsArr array is null or is having length 0");
                    logger.debug("******************************************************************************************************************************");
                }
            }
            else{
                logger.debug("******************************************* DEBUG MESSAGE FROM lodintoArray METHOD*******************************************");
                if(dsArrItmInfo==null)
                    logger.debug("dsArrItmInfo dataset is obtained as null");
                else if(dsArrItmInfo.size()==0)
                    logger.debug("dsArrItmInfo dataset size is 0");
                logger.debug("******************************************************************************************************************************");
            }
        }
        else{
            logger.debug("******************************************* DEBUG MESSAGE FROM lodintoArray METHOD*******************************************");
            if(Util.isNull(samples))
                logger.debug("Samples to be loaded are not found");
            if(Util.isNull(arrays))
                logger.debug("Arrays used for loading is not found");
            logger.debug("******************************************************************************************************************************");
        }
    }*/
}
