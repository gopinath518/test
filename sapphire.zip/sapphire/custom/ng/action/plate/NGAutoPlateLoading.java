package sapphire.custom.ng.action.plate;

import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.custom.ng.util.Util;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;
/**
 * NOT IN USE ; NOMINATED FOR DELETION..
 */

/**
 * Created by rrmandal on 6/14/2016.
 */
public class NGAutoPlateLoading extends BaseAction {

    /*private static final String BATCHTYPE_PROP = "batchtypeid";
    private static final String BATCHID_PROP = "batchid";
    public static final String RETURN_PLATES_PROP = "newplateid";

    private HashMap<String, String> arrayArrayLayoutMap = null;*/

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        /*String batchTypeid = properties.getProperty(BATCHTYPE_PROP, "");
        String batchid = properties.getProperty(BATCHID_PROP, "");
        String newPlates = "";
        if (!Util.isNull(batchid) && !Util.isNull(batchTypeid)) {
            newPlates = createArray(batchTypeid,batchid);
            lodintoArray(batchid,batchTypeid,newPlates);
            associatePlsToBatch(batchid,newPlates);
            properties.setProperty(RETURN_PLATES_PROP, newPlates);
        }*/
    }

    /**
     * This method creates one plate for each arraymethod specified in u_createplatemapping table for batchTypeid
     * and returns the newly created arrayids.
     *
     * @param batchTypeid
     * @return
     */

   /* private String createArray(String batchTypeid,String batchid) {
        String newArrays = "";
        if (!Util.isNull(batchTypeid) && !Util.isNull(batchid)) {
            try {
                boolean isSequencing = false;
                if(batchTypeid.indexOf("Sequencing")>0)
                    isSequencing = true;
                String sql = "select arraylayoutid,arraylayoutversionid,arraymethodid,arraymethodversionid,noofplates " +
                        "from u_createplatemapping where u_ngbatchtypeid=?";

                DataSet dsPltCreationInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{batchTypeid});
                if (dsPltCreationInfo != null && dsPltCreationInfo.size() > 0) {

                    PropertyList plCrtArr = new PropertyList();
*//**
 * In below logic CreateArray action is being executed in a loop because CreateArray action does not support multiple inputs
 *//*
                    for (int i = 0; i < dsPltCreationInfo.size(); i++) {

                        String layoutId = dsPltCreationInfo.getValue(i, "arraylayoutid", "");
                        String layoutVerId = dsPltCreationInfo.getValue(i, "arraylayoutversionid", "");
                        String coppiesStr = dsPltCreationInfo.getValue(i, "noofplates", "1");
                        int copy = Integer.parseInt(coppiesStr);

                        String newArraysPerLayout="";
                        for(int j=1;j<=copy;j++) {
                            plCrtArr.clear();
                            if(isSequencing){
                                if(j==1)
                                    plCrtArr.setProperty("arraydesc",batchid+"-R");
                                else if(j==2)
                                    plCrtArr.setProperty("arraydesc",batchid+"-F");
                            }
                            plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYMETHODID, dsPltCreationInfo.getValue(i, "arraymethodid", ""));
                            plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYMETHODVERSIONID, dsPltCreationInfo.getValue(i, "arraymethodversionid", ""));
                            plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYLAYOUTID, layoutId);
                            plCrtArr.setProperty(CreateArray.PROPERTY_ARRAYLAYOUTVERSIONID, layoutVerId);
                            plCrtArr.setProperty(CreateArray.PROPERTY_COPIES, "1");
                            getActionProcessor().processAction(CreateArray.ID, CreateArray.VERSIONID, plCrtArr);
                            newArrays += ";" + plCrtArr.getProperty(CreateArray.RETURN_ARRAYID, "");
                            newArraysPerLayout+=";"+plCrtArr.getProperty(CreateArray.RETURN_ARRAYID, "");
                        }
                        if (!Util.isNull(newArraysPerLayout)) {
                            if (newArraysPerLayout.startsWith(";"))
                                newArraysPerLayout = newArraysPerLayout.substring(1);
                        }
                        if (arrayArrayLayoutMap == null)
                            arrayArrayLayoutMap = new HashMap<String, String>();
                        arrayArrayLayoutMap.put(layoutId + "@*@" + layoutVerId, newArraysPerLayout);
                    }
                } else {
                    throw new SapphireException("No data is found in u_createplatemapping table for the batch type " + batchTypeid);
                }
            } catch (Exception e) {
                logger.debug(e.getMessage());
            }
            if (!Util.isNull(newArrays)) {
                if (newArrays.startsWith(";"))
                    newArrays = newArrays.substring(1);
            }

        }
        return newArrays;
    }*/


    /**
     * This method samples/controls present in a batch to the plates as per the loading logic defined in the respective batchtype
     * @param batchId
     * @param batchType
     * @param arrays
     * @throws SapphireException
     */

   /* private void lodintoArray(String batchId, String batchType, String arrays) throws SapphireException {
        if (!Util.isNull(batchId) && !Util.isNull(batchType) && !Util.isNull(arrays)) {
            DataSet result = new DataSet();
            result.addColumn(AddArrayContent.PROPERTY_ARRAYID, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_ARRAYITEMID, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_CONTENTSDCID, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_CONTENTKEYID1, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_CONTENTLABEL, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_VOLUME, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_VOLUMEUNITS, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_CONTENTITEM, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_CONCENTRATION, DataSet.STRING);
            result.addColumn(AddArrayContent.PROPERTY_CONCENTRATIONUNITS, DataSet.STRING);

            String sql = "select arraylayoutid,arraylayoutversionid,zone,testcode,analyte,contenttype,noofsamples,noofrepeats,direction " +
                    "from u_plateloadingmap where u_ngbatchtypeid=? order by arraylayoutid,arraylayoutversionid,zone,testcode,analyte";

            DataSet dsPlateMapInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{batchType});
            if (dsPlateMapInfo != null && dsPlateMapInfo.size() > 0) {

                sql = "select sampleid,NVL(analyte,'Not Required') analyte from u_ngbatch_sample where u_ngbatchid=?";
                DataSet dsSampleAnalyteInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{batchId});

                sql = "select sampleid,NVL(analyte,'Not Required') analyte,position from u_ngbatch_control where u_ngbatchid=? order by analyte,position";
                DataSet dsControlAnalyteInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{batchId});

                sql = "select a.arrayid,a.arrayitemid,c.zone,a.xpos,a.ypos,a.itemlabel,a.horizontallabel,a.verticallabel,e.contentitem," +
                        "e.volumetarget,e.volumetargetunits,e.concentrationtarget,e.concentrationtargetunits " +
                        "from arrayitem a,arrayitemarrayzone b,arrayzone c,arrayarraymethoditem d,arraymethodcontent e " +
                        "where a.arrayitemid=b.arrayitemid and b.arrayzoneid=c.arrayzoneid and a.arrayid=c.arrayid " +
                        "and a.arrayid=d.arrayid and  d.arraymethodid=e.arraymethodid and d.arraymethodversionid=e.arraymethodversionid and c.zone=e.zone " +
                        "and a.arrayid " +
                        "in('" + StringUtil.replaceAll(arrays, ";", "','") + "') and c.zone !='(FullArray)'";

                DataSet dsArrItmInfo = getQueryProcessor().getSqlDataSet(sql);

                if (dsSampleAnalyteInfo != null && dsSampleAnalyteInfo.size() > 0 && dsArrItmInfo != null && dsArrItmInfo.size() > 0) {
                    ArrayList<DataSet> dsPlateMapInfoArrGrpPerAnalyte = dsPlateMapInfo.getGroupedDataSets("arraylayoutid,arraylayoutversionid,zone,testcode,analyte");
                    if (dsPlateMapInfoArrGrpPerAnalyte != null && dsPlateMapInfoArrGrpPerAnalyte.size() > 0) {
                        for (int i = 0; i < dsPlateMapInfoArrGrpPerAnalyte.size(); i++) {
                            DataSet dsPlateMapInfoPerAnalyte = dsPlateMapInfoArrGrpPerAnalyte.get(i);
                            if (dsPlateMapInfoPerAnalyte != null && dsPlateMapInfoPerAnalyte.size() > 0) {
                                String arraylayoutid = dsPlateMapInfoPerAnalyte.getValue(0, "arraylayoutid", "");
                                String arraylayoutversionid = dsPlateMapInfoPerAnalyte.getValue(0, "arraylayoutversionid", "");
                                String zone = dsPlateMapInfoPerAnalyte.getValue(0, "zone", "");
                                String testcode = dsPlateMapInfoPerAnalyte.getValue(0, "testcode", "");
                                String analyte = dsPlateMapInfoPerAnalyte.getValue(0, "analyte", "");
                                String contenttype = dsPlateMapInfoPerAnalyte.getValue(0, "contenttype", "");
                                String noofsamples = dsPlateMapInfoPerAnalyte.getValue(0, "noofsamples", "0");
                                String noofrepeats = dsPlateMapInfoPerAnalyte.getValue(0, "noofrepeats", "0");
                                String direction = dsPlateMapInfoPerAnalyte.getValue(0, "direction", "H");
                                if (!Util.isNull(arraylayoutid) && !Util.isNull(arraylayoutversionid) && !Util.isNull(zone) && !Util.isNull(testcode) && !Util.isNull(analyte)) {
                                    if ("Sample".equalsIgnoreCase(contenttype)) {
                                        HashMap<String, String> hmap = new HashMap<String, String>();
                                        hmap.put("analyte", analyte);
                                        DataSet dsSamplesPerAnalyte = dsSampleAnalyteInfo.getFilteredDataSet(hmap);
                                        if (dsSamplesPerAnalyte != null && dsSamplesPerAnalyte.size() > 0) {
                                            try {
                                                loadContents(dsSamplesPerAnalyte, dsArrItmInfo, arraylayoutid, arraylayoutversionid, zone, noofsamples,noofrepeats,direction, result);
                                            } catch (SapphireException exp) {
                                                throw new SapphireException(exp.getMessage()+" Please check the plate loading setup in the Plate Loading Map detail " +
                                                        "for the batch type "+batchType+".");
                                            }
                                        }
                                    } else if ("Control".equalsIgnoreCase(contenttype)) {
                                        if (dsControlAnalyteInfo != null && dsControlAnalyteInfo.size() > 0) {
                                            HashMap<String, String> hmap = new HashMap<String, String>();
                                            hmap.put("analyte", analyte);
                                            DataSet dsControlPerAnalyte = dsControlAnalyteInfo.getFilteredDataSet(hmap);
                                            if (dsControlPerAnalyte != null && dsControlPerAnalyte.size() > 0) {
                                                try {
                                                    loadContents(dsControlPerAnalyte, dsArrItmInfo, arraylayoutid, arraylayoutversionid, zone, noofsamples,noofrepeats,direction, result);
                                                } catch (SapphireException exp) {
                                                    throw new SapphireException(exp.getMessage()+" Please check the plate loading setup in the Plate Loading Map detail " +
                                                            "for the batch type "+batchType+".");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if(result!=null && result.size()>0){
                PropertyList pl = new PropertyList();
                pl.setProperty( AddArrayContent.PROPERTY_ARRAYID, result.getColumnValues(AddArrayContent.PROPERTY_ARRAYID,";") );
                pl.setProperty( AddArrayContent.PROPERTY_ARRAYITEMID, result.getColumnValues(AddArrayContent.PROPERTY_ARRAYITEMID,";") );
                pl.setProperty( AddArrayContent.PROPERTY_CONTENTSDCID, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTSDCID,";") );
                pl.setProperty( AddArrayContent.PROPERTY_CONTENTKEYID1, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTKEYID1,";") );
                pl.setProperty( AddArrayContent.PROPERTY_CONTENTLABEL, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTLABEL,";") );
                pl.setProperty( AddArrayContent.PROPERTY_VOLUME, result.getColumnValues(AddArrayContent.PROPERTY_VOLUME,";") );
                pl.setProperty( AddArrayContent.PROPERTY_VOLUMEUNITS, result.getColumnValues(AddArrayContent.PROPERTY_VOLUMEUNITS,";") );
                pl.setProperty( AddArrayContent.PROPERTY_CONTENTITEM, result.getColumnValues(AddArrayContent.PROPERTY_CONTENTITEM,";") );
                pl.setProperty( AddArrayContent.PROPERTY_CONCENTRATION, result.getColumnValues(AddArrayContent.PROPERTY_CONCENTRATION,";") );
                pl.setProperty( AddArrayContent.PROPERTY_CONCENTRATIONUNITS, result.getColumnValues(AddArrayContent.PROPERTY_CONCENTRATIONUNITS,";") );
                getActionProcessor().processAction( AddArrayContent.ID, AddArrayContent.VERSIONID, pl );

                PropertyList plEditSDI = new PropertyList();
                plEditSDI.setProperty( EditSDI.PROPERTY_SDCID, "LV_Array" );
                plEditSDI.setProperty( EditSDI.PROPERTY_KEYID1, arrays );
                plEditSDI.setProperty( "arraystatus", "Loaded" );
                getActionProcessor().processAction( EditSDI.ID, EditSDI.VERSIONID, plEditSDI );
            }
        }
    }*/


    /**
     * This method loads the content to a particular array,particular zone
     * @param dsContentAnalyteInfo
     * @param dsArrItmInfo
     * @param arraylayout
     * @param arraylayoutversionid
     * @param zone
     * @param noofcontent
     * @param noofrepeats
     * @param direction
     * @param result
     * @throws SapphireException
     */

    /*private void loadContents(DataSet dsContentAnalyteInfo, DataSet dsArrItmInfo, String arraylayout, String arraylayoutversionid, String zone, String noofcontent,String noofrepeats,String direction, DataSet result) throws SapphireException {
        if (dsContentAnalyteInfo != null && dsContentAnalyteInfo.size() > 0 && dsArrItmInfo != null && dsArrItmInfo.size() > 0 && !Util.isNull(arraylayout)
                && !Util.isNull(arraylayoutversionid) && !Util.isNull(zone) && !Util.isNull(noofcontent)) {
            String layoutVerComb = arraylayout + "@*@" + arraylayoutversionid;
            String arrayid = arrayArrayLayoutMap.get(layoutVerComb);
            if (!Util.isNull(arrayid)) {
                String arridArr[] = StringUtil.split(arrayid, ";");
                if (arridArr != null && arridArr.length > 0) {
                    HashMap<String, String> hmap = new HashMap<String, String>();
                    for (int arrindex = 0; arrindex < arridArr.length; arrindex++) {
                        hmap.clear();
                        hmap.put("arrayid", arridArr[arrindex]);
                        hmap.put("zone", zone);
                        DataSet dsArrItmInfoFiltr = dsArrItmInfo.getFilteredDataSet(hmap);
                        if (dsArrItmInfoFiltr == null) {
                            logger.debug("dsArrItmInfoFiltr dataset is null.");
                            throw new SapphireException("Plate Loading info is not found");
                        }
                        if (dsArrItmInfoFiltr.size() > 0) {
                            int contentNo = Integer.parseInt(noofcontent);
                            int repeats = Integer.parseInt(noofrepeats);
                            int actualContentNo = dsContentAnalyteInfo.size() * repeats;
                            if (contentNo <= 0)
                                throw new SapphireException("Invalid number is given for the column Number Of Samples/Controls in the Plate Loading Map Detail for Array Layout = " + arraylayout + "" +
                                        ",Array Layout Version = " + arraylayoutversionid + ", Array Zone = " + zone + ".");
                            if (actualContentNo > contentNo)
                                throw new SapphireException("Maximum number of contents(Given in the column Number Of Samples/Controls) that can be loaded in the Array Zone " + zone + " for the Array Layout " + arraylayout + " (Array Layout Version=" + arraylayoutversionid + ") is " + contentNo + "" +
                                        ". But system found the number of contents need to be loaded is " + actualContentNo + ".");

                            if ("H".equalsIgnoreCase(direction))
                                dsArrItmInfoFiltr.sort("xpos,ypos");
                            else if ("V".equalsIgnoreCase(direction)) ;
                            dsArrItmInfoFiltr.sort("ypos,xpos");
                            int arrContIndex = 0;
                            for (int i = 0; i < dsContentAnalyteInfo.size(); i++) {
                                String content = dsContentAnalyteInfo.getValue(i, "sampleid", "");
                                if (!Util.isNull(content)) {
                                    for (int j = 1; j <= repeats; j++) {
                                        int index = result.addRow();
                                        if (arrContIndex < dsArrItmInfoFiltr.size()) {
                                            result.setValue(index, AddArrayContent.PROPERTY_ARRAYID, arridArr[arrindex]);
                                            result.setValue(index, AddArrayContent.PROPERTY_ARRAYITEMID, dsArrItmInfoFiltr.getValue(arrContIndex, "arrayitemid", ""));
                                            result.setValue(index, AddArrayContent.PROPERTY_CONTENTSDCID, "Sample");
                                            result.setValue(index, AddArrayContent.PROPERTY_CONTENTKEYID1, content);
                                            result.setValue(index, AddArrayContent.PROPERTY_CONTENTLABEL, content);
                                            result.setValue(index, AddArrayContent.PROPERTY_VOLUME, dsArrItmInfoFiltr.getValue(arrContIndex, "volumetarget", "1"));
                                            result.setValue(index, AddArrayContent.PROPERTY_CONCENTRATION, dsArrItmInfoFiltr.getValue(arrContIndex, "concentrationtarget", "1"));
                                            result.setValue(index, AddArrayContent.PROPERTY_VOLUMEUNITS, dsArrItmInfoFiltr.getValue(arrContIndex, "volumetargetunits", "ul"));
                                            result.setValue(index, AddArrayContent.PROPERTY_CONCENTRATIONUNITS, dsArrItmInfoFiltr.getValue(arrContIndex, "concentrationtargetunits", "ul"));
                                            result.setValue(index, AddArrayContent.PROPERTY_CONTENTITEM, dsArrItmInfoFiltr.getValue(arrContIndex++, "contentitem", ""));
                                        }
                                    }
                                }
                            }

                        } else {
                            throw new SapphireException("Zone " + zone + " is invalid for the Array Layout = " + arraylayout + ", Array Layout Version = " + arraylayoutversionid + ".");
                        }
                    }
                }
            }
        }
    }

*/
   /* private void associatePlsToBatch(String batchid,String plates) throws SapphireException{
        if(!Util.isNull(batchid) && !Util.isNull(plates)){
            PropertyList props = new PropertyList();
            props.setProperty(AddSDIDetail.PROPERTY_SDCID,"NGBatch");
            props.setProperty(AddSDIDetail.PROPERTY_KEYID1,batchid);
            props.setProperty("plateid",plates);
            props.setProperty(AddSDIDetail.PROPERTY_LINKID,"u_ngbatch_plate_link");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);
        }
    }*/
}
