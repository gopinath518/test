package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.DeleteDataSet;
import sapphire.action.DeleteSDIDetail;
import sapphire.action.RedoCalculations;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.io.File;

/**
 * Created by dgupta on 7/25/2016.
 */
public class VMSDeleteRegion extends BaseAction {

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("externalimageidentifier");
        String displayid = properties.getProperty("displayid");
        String regionid = properties.getProperty("regionid");
        String userid = properties.getProperty("userid");
        String version = properties.getProperty("version");

        String datsetSql = "select d.keyid1, d.paramlistid, d.paramlistversionid, d.variantid, d.dataset from sdidata d, sdidataitem di " +
                " where d.sdcid=di.sdcid and d.keyid1=di.keyid1 and d.PARAMLISTID = di.PARAMLISTID and  " +
                " d.PARAMLISTVERSIONID=di.PARAMLISTVERSIONID  and d.VARIANTID= di.VARIANTID and d.dataset= di.dataset and  " +
                " d.sdcid='Sample'  and d.paramlistid in ('ResultCreated', 'ResultCreatedHer2', 'RegionCreated') and di.paramid='Regionid'  " +
                " and d.keyid1 = '" +sampleid+ "'  and di.enteredtext =  '" + regionid +"'";

        DataSet dsParamlist = getQueryProcessor().getSqlDataSet(datsetSql);

        if(dsParamlist != null && dsParamlist.getRowCount() > 0){
            PropertyList props = new PropertyList();
            props.setProperty(DeleteDataSet.PROPERTY_SDCID, "Sample");
            props.setProperty(DeleteDataSet.PROPERTY_KEYID1, sampleid);
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTID, dsParamlist.getColumnValues("paramlistid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_PARAMLISTVERSIONID, dsParamlist.getColumnValues("paramlistversionid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_VARIANTID, dsParamlist.getColumnValues("variantid", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_DATASET, dsParamlist.getColumnValues("dataset", ";"));
            props.setProperty(DeleteDataSet.PROPERTY_FORCEDELETE, "Y");
            getActionProcessor().processAction(DeleteDataSet.ID, DeleteDataSet.VERSIONID, props);

            String paramlists  = dsParamlist.getColumnValues("paramlistid", ";");
            //if(paramlists.contains("ResultCreated")  ||  paramlists.contains("ResultCreatedHer2")){
                PropertyList propRedo = new PropertyList();
                propRedo.setProperty(RedoCalculations.PROPERTY_SDCID, "Sample");
                propRedo.setProperty(RedoCalculations.PROPERTY_KEYID1, sampleid);
                getActionProcessor().processAction(RedoCalculations.ID, RedoCalculations.VERSIONID, propRedo);
            //}
        }
    }
}
