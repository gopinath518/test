package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.custom.ng.sql.molecular.MolecularSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * Created by gpandi on 01/12/2017.
 * Description : This Action used for update the sample count in InstrumentQuantific SDC.
 * Table Used : u_instrumentquantific
 */

public class UpdateQuantCount extends BaseAction{

    public void processAction(PropertyList properties) throws SapphireException {
        String instQuantid = properties.getProperty("keyid1", "");
        String sampleid = properties.getProperty("sampleid", "");
        if (Util.isNull(instQuantid))
            throw new SapphireException("Keyid1 can't found");
        if (Util.isNull(sampleid))
            throw new SapphireException("Specimen ID can't found");
        String instSql = Util.parseMessage(MolecularSql.GET_INSTID_INSTQUANT, instQuantid);
        DataSet dsInstSql = getQueryProcessor().getSqlDataSet(instSql);
        String instrumentused="";
        String batchid= "";
        if (dsInstSql.size() != 0){
           instrumentused = dsInstSql.getValue(0,"u_instrumentused", "");
           batchid= dsInstSql.getValue(0,"u_ngbatchid", "");
        }
        String sql=Util.parseMessage(MolecularSql.GET_UPLOADCOUNT, sampleid, instrumentused);
        DataSet dssql= getQueryProcessor().getSqlDataSet(sql);
        if(dssql.size() == 0)
        {
            String errStr = getTranslationProcessor().translate("Specimen Count can't found with that instrument.");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, errStr);
        }
        int cnt = dssql.getInt(0, "uploadcount", 0);
        cnt = cnt + 1;
        try{
            PropertyList plEditSDI = new PropertyList();
            plEditSDI.setProperty( EditSDI.PROPERTY_SDCID, "InstrumentQuantific" );
            plEditSDI.setProperty( EditSDI.PROPERTY_KEYID1, instQuantid );
            plEditSDI.setProperty( "u_ngbatchid", batchid );
            plEditSDI.setProperty( "uploadcount", "" + cnt);
            getActionProcessor().processAction( EditSDI.ID, EditSDI.VERSIONID, plEditSDI );
        }
        catch (SapphireException ae) {
            String error = getTranslationProcessor().translate("Can't update in InstrumentQuantific");
            error += ae.getMessage();
            throw new SapphireException(error, ErrorDetail.TYPE_VALIDATION);
        }
    }
}
