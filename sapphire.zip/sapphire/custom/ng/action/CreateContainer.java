package sapphire.custom.ng.action;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.accessor.ActionProcessor;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import javax.xml.crypto.Data;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Created by mpandey on 5/2/2016.
 * Action Name- UpdateCSpecimenID
 * Description: This Action will generate and update client specimen id  as per sampletype.
 * and associates sample with cassette
 * input
 * param1-sampleid
 * throws SapphireException
 */
public class CreateContainer extends BaseAction {
    String CURRENT_YEAR = "2015";
    int rowIncrement = 0;
    DataSet preEditProp = new DataSet();
    String latestSpecimen = "";


    public void processAction(PropertyList properties) throws SapphireException {
        String sampleids = properties.getProperty("sampleid");
        String sample = StringUtil.replaceAll(sampleids, ";", "','");
        String sql_ac = "select distinct u_accessionid from s_sample where s_sampleid in ('" + sample + "') ";
        DataSet dsaccession = getQueryProcessor().getSqlDataSet(sql_ac);
        if (dsaccession.size() > 1) {
            String error = getTranslationProcessor().translate("Please select Samples under one Accession ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }

        String sql = "select   s.u_clientspecimenid,s.sampletypeid,s.s_sampleid,t.containertypeid,s.u_currentmovementstep from s_sample s,trackitem t where" +
                " s.s_sampleid=t.linkkeyid1 and s.s_sampleid in ('" + sample + "') ";
        DataSet dssample = getQueryProcessor().getSqlDataSet(sql);
        if (dssample.size() == 0) {
            String error = getTranslationProcessor().translate("Please select aleast a  sample ");
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
       /* for (int k = 0; k < dssample.size(); k++) {

            if (dssample.getString(k, "u_clientspecimenid", "").length() > 0) {
                String error = getTranslationProcessor().translate("SampleID " + dssample.getString(k, "s_sampleid") + " already have a Container Label, please try  again with another sample  ");
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
            }
        }*/

        CURRENT_YEAR = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        int sequence = 000001;
        String tail = "A";
        latestSpecimen = "NG" + CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length()) + "-" + String.format("%06d", sequence) + "-" + tail;

        preEditProp.addColumn("s_sampleid", DataSet.STRING);
        preEditProp.addColumn("u_clientspecimenid", DataSet.STRING);
        updateSpecimenID(dssample);
        if (preEditProp.size() > 0)
            editSDISample(sampleids);

    }

    /**
     * This function is use to
     * update client specimen in sample sdc
     *
     * @param sampleids
     * @throws SapphireException
     */
    private void editSDISample(String sampleids) throws SapphireException {
        ActionProcessor ap = getActionProcessor();
        PropertyList editProp = new PropertyList();
        editProp.clear();

        editProp.setProperty("sdcid", "Sample");
        editProp.setProperty("keyid1", preEditProp.getColumnValues("s_sampleid", ";"));
        //  editProp.setProperty("keyid1", sampleids);
        //editProp.setProperty("u_clientspecimenid", preEditProp.getColumnValues("u_clientspecimenid", ";"));//TODO NOT REQUIRED IN 1.5.1 RELEASE
        editProp.setProperty("u_clientspecimenid", "");

        try {
            ap.processAction("EditSDI", "1", editProp);

        } catch (ActionException ex) {
            String error = getTranslationProcessor().translate("Action failed try again,unable to add ");
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, error);

        }
    }

    /**
     * This function is use to
     * Update and create clientspecimen id for sample as per
     * sample type and container type.
     *
     * @param dssample
     */
    private void updateSpecimenID(DataSet dssample) {
        String clientIDMatch = "NG" + CURRENT_YEAR.substring(CURRENT_YEAR.length() - 2, CURRENT_YEAR.length());
        String sql_sample = "select max(u_clientspecimenid)u_clientspecimenid from s_sample where u_accessionid = (select u_accessionid from s_sample where s_sampleid ='" + dssample.getValue(0, "s_sampleid") + "') and  u_clientspecimenid like '" + clientIDMatch + "-%-%' ";
        DataSet dsAccess = getQueryProcessor().getSqlDataSet(sql_sample);
        if (dsAccess.size() > 0 && dsAccess.getString(0, "u_clientspecimenid", "").length() > 0) {
            latestSpecimen = dsAccess.getString(0, "u_clientspecimenid");
        } else {
            String cont_sql = "select max(u_clientspecimenid)u_clientspecimenid from s_sample where  u_clientspecimenid like '" + clientIDMatch + "-%-%'";
            DataSet dscont = getQueryProcessor().getSqlDataSet(cont_sql);
            if (dscont.size() > 0 && dscont.getString(0, "u_clientspecimenid", "").length() > 0) {
                latestSpecimen = dscont.getString(0, "u_clientspecimenid");
                String[] contarr = latestSpecimen.split("-");
                int seq = Integer.parseInt(contarr[1]);
                int ascii = 64;
                char tail = (char) ascii;
                latestSpecimen = contarr[0] + "-" + String.format("%06d", seq + 1) + "-" + tail;
            }
        }

        DataSet sampleFiltered = new DataSet();
        HashMap hmFilter = new HashMap();

        // changed on 19Apl17 - added transport type "10% NBF" this is new transport type for Formalin , formalin is aslo there for compatibility - DG
        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("sampletypeid", "Bone Marrow Core");
        hmFilter.put("containertypeid", "Formalin");
        hmFilter.put("u_clientspecimenid", null);
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            generateSpecimenID(sampleFiltered);
        }

        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("sampletypeid", "Bone Marrow Core");
        hmFilter.put("containertypeid", "10% NBF");
        hmFilter.put("u_clientspecimenid", null);
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            generateSpecimenID(sampleFiltered);
        }
        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("sampletypeid", "Bone Marrow Clot");
        hmFilter.put("containertypeid", "Formalin");
        hmFilter.put("u_clientspecimenid", null);
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            generateSpecimenID(sampleFiltered);
        }

        hmFilter.clear();
        sampleFiltered.clear();

        hmFilter.put("sampletypeid", "Bone Marrow Clot");
        hmFilter.put("containertypeid", "10% NBF");
        hmFilter.put("u_clientspecimenid", null);
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            generateSpecimenID(sampleFiltered);
        }

        hmFilter.clear();
        sampleFiltered.clear();
        hmFilter.put("containertypeid", "RPMI");
        hmFilter.put("u_clientspecimenid", null);
        hmFilter.put("u_currentmovementstep", "HistoGrossing");
        sampleFiltered = dssample.getFilteredDataSet(hmFilter);
        if (sampleFiltered.size() > 0) {
            generateSpecimenID(sampleFiltered);
        }

        DataSet otherSample = new DataSet();
        otherSample.addColumn("s_sampleid", DataSet.STRING);
        otherSample.addColumn("u_clientspecimenid", DataSet.STRING);
        otherSample.addColumn("u_currentmovementstep", DataSet.STRING);
        for (int i = 0; i < dssample.size(); i++) {
            if (!(dssample.getValue(i, "sampletypeid").equalsIgnoreCase("Bone Marrow Core") || dssample.getValue(i, "sampletypeid").equalsIgnoreCase("Bone Marrow Clot") || dssample.getValue(i, "containertypeid").equalsIgnoreCase("RPMI"))) {
                rowIncrement = otherSample.addRow();
                otherSample.setValue(rowIncrement, "s_sampleid", dssample.getString(i, "s_sampleid"));
                otherSample.setValue(rowIncrement, "u_clientspecimenid", dssample.getString(i, "u_clientspecimenid"));
                otherSample.setValue(rowIncrement, "u_currentmovementstep", dssample.getString(i, "u_currentmovementstep"));

            }
        }
        if (otherSample.size() > 0) {
            hmFilter.clear();
            sampleFiltered.clear();
            hmFilter.put("u_clientspecimenid", null);
            hmFilter.put("u_currentmovementstep", "HistoGrossing");
            sampleFiltered = otherSample.getFilteredDataSet(hmFilter);
            generateSpecimenID(sampleFiltered);
        }

    }

    /**
     * This function is use to
     * Implement logic to get latest sequence for client specimen id .
     *
     * @param sampleFiltered
     */
    private void generateSpecimenID(DataSet sampleFiltered) {


        for (int i = 0; i < sampleFiltered.size(); i++) {
            String finaltail = "";
            rowIncrement = preEditProp.addRow();
            preEditProp.setValue(rowIncrement, "s_sampleid", sampleFiltered.getString(i, "s_sampleid"));
            String tail = latestSpecimen.split("-")[2];
            char c = tail.charAt(0);
            int tailacii = c;
            if (tail.length() == 1 && tailacii == 90) {
                finaltail = "AA";
            } else if (tail.length() > 1) {
                tailacii = tailacii + 1;
                finaltail = String.valueOf((char) tailacii);
                finaltail = finaltail + finaltail;
            } else {
                int ascii = tailacii + 1;
                char newc = (char) ascii;
                finaltail = String.valueOf(newc);
            }
            String[] latestarr = latestSpecimen.split("-");
            latestSpecimen = latestarr[0] + "-" + latestarr[1] + "-" + finaltail;
            preEditProp.setValue(rowIncrement, "u_clientspecimenid", latestSpecimen);
        }
    }
}
