package sapphire.custom.ng.action;

import com.labvantage.sapphire.actions.report.GenerateReport;
import com.labvantage.sapphire.actions.sdi.AddSDIAttachment;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.custom.ng.sql.common.CommonSql;
import sapphire.custom.ng.util.Util;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.File;
import java.util.Date;

/**
 * ToDo List. Need Unit testing. As there is no data can't able to test.
 */

/**
 * Description : This action is for creating report for IHC Stain Summary. After creating the report it will
 * attached with the accession of the selected sample and maintain the versioning of the report. This action will call another
 * action GenerateAction which is OOB action of LabVantage. After executing GenerateAction will create a pdf and store in a specific
 * location. Another action AddSDIAttachment will be called after execution of GenerateReport action. It will attached the PDF with
 * the corresponding Accession of the input Sample ID.
 * Created by kshahbaz on 7/18/2016.
 * Modified by msubhra on 11/03/2016
 */
public class GenerateIHCStainSummary extends BaseAction {
    public void processAction(PropertyList properties) throws SapphireException {
        String sampleid = properties.getProperty("s_sampleid");
        String los = properties.getProperty("los");
        //String uniquelos = los.contains(";") ? StringUtil.replaceAll(los, ";", ",") : los;
        //uniquelos = Util.getUniqueList(uniquelos, ",", true);
        String sqlSampleid = sampleid.contains(";") ? StringUtil.replaceAll(sampleid, ";", "','") : sampleid;
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        String timestamp = new java.text.SimpleDateFormat("MMddyyyyhmmssa").format(new Date());
        String sql = "select u_accessionid,u_currentmovementstep from s_sample where s_sampleid in ( '" + sqlSampleid + "') order by createdt desc";
        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        String accessionid = ds.getValue(0, "u_accessionid");
        String currentmovementstep = ds.getValue(0, "u_currentmovementstep");
        if (ds == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.size() == 0) {
            String err = "SampleID is not attached with any accession.\n PLease select correct sample: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        //Los validation
        String sqlLos = "select distinct los from u_sampletestcodemap where s_sampleid in ( '" + sqlSampleid + "') ";
        DataSet dslos = getQueryProcessor().getSqlDataSet(sqlLos);
        String losValidate = "";
        //dslos.getColumnValues("los", ";");

        if (dslos == null) {
            String err = "Something wrong happened. Contact your administrator.\n Sql failed: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }

        if (dslos.size() == 0) {
            String err = "LOS is not associated the selected Sample IDs.\n PLease select correct sample: ";
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        } else if (dslos.size() == 1) {

            losValidate = dslos.getColumnValues("los", ";");

        } else {
            losValidate = "LOS";
        }
    /*    if (StringUtil.split(losValidate, ";").length > 0) {
            //String err = "More than one LOS is not allowed in IHC Stain summary report.";
            //throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            validateLOS(dslos); // Function added By Subhra for validate LOS. LOS should be from only one group
        }*/

        if (!currentmovementstep.equalsIgnoreCase("StainCompleted")) {
            String err = "Current movement step of the selected sample should be Stain Completed.\n PLease select correct sample: " + sql;
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
        }
        if (ds.size() > 0 && currentmovementstep.equalsIgnoreCase("StainCompleted")) {
            String location = getFileLocation(accessionid); //Getting the location where the report should be stored
            if (sampleid.contains(";"))
                sampleid = StringUtil.replaceAll(sampleid, ";", ",");
            String filename = generateReport(sampleid, accessionid, timestamp, location); //method for generate report
            addAttachment(accessionid, timestamp, filename, losValidate); //method for attach PDF with Accession

            /**
             * The below property is for generate the report in the web browser.
             */

            // String url1 = "rc?command=ViewReport&reportid=IHCStainSummary&reportversionid=1&sampleid=" + sampleid + "&mode=submitarg&displaytype=pdf";
            //String url2 = "rc?command=ViewReport&reportid=InternalQCReport&reportversionid=1&sampleid=" + sampleid + "&mode=submitarg&displaytype=pdf";


            //  properties.setProperty("msg1", url1);
            //properties.setProperty("msg2", url2);
        }

    }

    /**
     * getFileLocation() is for fetching the location mentioned in File Location Policy. A specific node is defined in File Location Policy.
     * We need to pass the node name from where it will fetch the Location.
     *
     * @return fileLocation
     * @throws SapphireException
     */

    private String getFileLocation(String accessionid) throws SapphireException {
        String fileLocation = "";

        /*PropertyList fileLocationPolicyProperties = getConfigurationProcessor().getPolicy("FileLocationPolicy", "Report");
        PropertyListCollection plc = fileLocationPolicyProperties.getCollection("locations");
        if (plc != null) {
            fileLocation = plc.getPropertyList(0).getProperty("location");
        }*/
        String sql = Util.parseMessage(CommonSql.GET_ACCESSION_INFO_BY_ACCESSION, StringUtil.replaceAll(accessionid, ";", "','"));
        DataSet dsAccessionIfo = getQueryProcessor().getSqlDataSet(sql);
        String sponsornumber = "", projectprotocolid = "";
        if (dsAccessionIfo.size() > 0) {
            sponsornumber = dsAccessionIfo.getValue(0, "sponsornumber");
            projectprotocolid = dsAccessionIfo.getValue(0, "projectprotocolid");
        }
        sql = CommonSql.GET_FILE_BASE_PATH;
        DataSet dsBasePath = getQueryProcessor().getSqlDataSet(sql);
        if (dsBasePath == null || dsBasePath.size() == 0) {
            throw new SapphireException("Base path not find into the system");
        }
        String baseloc = dsBasePath.getValue(0, "propvalue");
        fileLocation = Util.generateIHCLocPath(baseloc, sponsornumber, projectprotocolid, "IHC", "StainSummery");

        return fileLocation;
    }

    /**
     * @param sampleid
     * @param location
     * @throws SapphireException
     * @desc This method is used for generate the report by calling GenerateReport action and store the report in the location which
     * is obtained from getFileLocation() method.
     */

    public String generateReport(String sampleid, String accessionid, String time, String location) throws SapphireException {
        String filename = "";
        String filename1 = "";
        String filename2 = "";


        if (!Util.isNull(sampleid)) {

            filename1 = location + File.separator + accessionid + time + ".pdf";
            filename2 = location + File.separator + "InternalQCReport" + accessionid + time + ".pdf";

            PropertyList prop = new PropertyList();
            prop.clear();
            prop.setProperty(GenerateReport.PROPERTY_REPORTID, "IHCStainSummary");
            prop.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID, "1");
            prop.setProperty("sampleid", sampleid);
            prop.setProperty(GenerateReport.PROPERTY_DESTINATION, "file");
            prop.setProperty(GenerateReport.PROPERTY_DEBUGLOG, "N");
            prop.setProperty(GenerateReport.PROPERTY_FILENAME, filename1);
            prop.setProperty(GenerateReport.PROPERTY_FILETYPE, "pdf");

            try {
                getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);
            } catch (SapphireException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Stain Summary Report not created. " + e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
            prop.clear();
            prop.setProperty(GenerateReport.PROPERTY_REPORTID, "InternalQCReport");
            prop.setProperty(GenerateReport.PROPERTY_REPORTVERSIONID, "1");
            prop.setProperty("sampleid", sampleid);
            prop.setProperty(GenerateReport.PROPERTY_DESTINATION, "file");
            prop.setProperty(GenerateReport.PROPERTY_DEBUGLOG, "N");
            prop.setProperty(GenerateReport.PROPERTY_FILENAME, filename2);
            prop.setProperty(GenerateReport.PROPERTY_FILETYPE, "pdf");
            try {
                getActionProcessor().processAction(GenerateReport.ID, GenerateReport.VERSIONID, prop);
            } catch (SapphireException e) {
                String errMSG = getTranslationProcessor().translate("Action failed. Internal QC Report not created. " + e.getMessage());
                throw new SapphireException(ErrorDetail.TYPE_FAILURE, errMSG);
            }
            filename = filename1 + ";" + filename2;

        }
        return filename;
    }


    /**
     * @param accessionid
     * @param time
     * @throws SapphireException
     * @desc This method is used for attach the report with the accession for which the report is generated by calling
     * AddSDIAttachment action.
     */


    public void addAttachment(String accessionid, String time, String filename, String los) throws SapphireException {

        String description = accessionid + time + ".pdf";
        String[] filenamearr = filename.split(";");

        PropertyList attachprop = new PropertyList();
        attachprop.clear();
        attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, accessionid);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, los);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "StainSummaryReport");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenamearr[0]);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, description);
        attachprop.setProperty("ATTACHMENTCLASS", "SOP");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");


        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + accessionid + "Accession" + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }

        attachprop.clear();
        attachprop.setProperty(AddSDIAttachment.PROPERTY_SDCID, "Accession");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID1, accessionid);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID2, los);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_KEYID3, "InternalQCReport");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_FILENAME, filenamearr[1]);
        attachprop.setProperty(AddSDIAttachment.PROPERTY_TYPE, "R");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_DESCRIPTION, description);
        attachprop.setProperty("ATTACHMENTCLASS", "SOP");
        attachprop.setProperty(AddSDIAttachment.PROPERTY_INDEX, "Y");
        try {
            getActionProcessor().processAction(AddSDIAttachment.ID, AddSDIAttachment.VERSIONID, attachprop);
        } catch (SapphireException ex) {
            String msg = getTranslationProcessor().translate("Action failed. Attachment not added to the" + accessionid + "Accession" + ex.getMessage());
            throw new SapphireException(ErrorDetail.TYPE_FAILURE, msg);
        }


    }


    /**
     * <12-May-2017><Code Modified  By - Subhra Mandal>
     * Description: Validation for More than one LOS within a category should be allowed for generate Stain Summary Report.
     */

    public void validateLOS(DataSet ds) throws SapphireException {

        for (int j = 0; j < ds.size(); j++) {
            String currentlos = ds.getValue(j, "los");
            if (currentlos.equalsIgnoreCase("Global Manual Quantitative") || currentlos.equalsIgnoreCase("Global Manual Qualitative"))
                ds.setValue(j, "los", "Global");
            else if (currentlos.equalsIgnoreCase("Technical IA") || currentlos.equalsIgnoreCase("Technical Scan Qualitative") || currentlos.equalsIgnoreCase("Technical Scan Quantitative"))
                ds.setValue(j, "los", "Technical");
        }
        String losvalidate = ds.getColumnValues("los", ";");
        String uniquelos = Util.getUniqueList(losvalidate, ";", true);
        if (!Util.isNull(uniquelos)) {
            if (uniquelos.split(";").length > 1) {
                String err = "More than one Category of LOS is not allowed in IHC Stain summary report.";
                throw new SapphireException(ErrorDetail.TYPE_VALIDATION, err);
            }
        }


    }
}


